import type { FC } from 'react';
import type { Theme } from '@mui/material';
import { Chip as MuiChip } from '@mui/material';
import type { IChipProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../../utils';
import {
    constants,
    generateClass,
    getComponentDesignProperty,
    getProviderTheme,
    manageClassNames,
} from '../../../utils';
import useStorage from '../../../hooks/useStorage';
import { chipClasses } from './classes';

const Chip: FC<IChipProps> = ({
    design,
    className,
    variant = 'standard',
    color = 'primary',
    size = 'small',
    leftCornered = false,
    cornered = false,
    rightCornered = false,
    ...rest
}: IChipProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiChip
                className={manageClassNames(
                    generateClass('Chip'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                    {
                        [`${chipClasses.corneredLeft}`]: leftCornered,
                        [`${chipClasses.corneredRight}`]: rightCornered,
                        [`${chipClasses.cornered}`]: cornered,
                    },
                )}
                variant={variant}
                color={color}
                size={size}
                {...rest}
            />
        </ThemeProvider>
    );
};

export default Chip;
