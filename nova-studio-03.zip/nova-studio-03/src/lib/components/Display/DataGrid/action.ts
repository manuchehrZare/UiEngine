import type { GridColumnVisibilityModel } from '@mui/x-data-grid-pro';
import { findIndex } from 'lodash';
import type { ICommonProps } from '../../../utils/types/common';
import { DesignTypeEnum } from '../../../utils/types/common';
import type { pageSizeOptionsType } from './type';

export const getInitialLocalPageSize = (pageSize?: number, rowsPerPageOptions?: pageSizeOptionsType[]): any => {
    if (!pageSize && !rowsPerPageOptions) return undefined;
    if (pageSize) {
        if (rowsPerPageOptions && rowsPerPageOptions.length > 0) {
            const foundIndex: number = rowsPerPageOptions
                ?.map((item) => (typeof item === 'number' ? item : item?.value))
                .findIndex((item: number) => item === pageSize);
            if (foundIndex !== -1) return rowsPerPageOptions[foundIndex];
        }
        return pageSize;
    }
    if (rowsPerPageOptions) {
        if (rowsPerPageOptions.length > 0) return rowsPerPageOptions[0];
        return undefined;
    }
};

export const generateRowsPerPageOptions = (
    rowsPerPageOptions?: pageSizeOptionsType[],
    pageSize?: number,
): pageSizeOptionsType[] => {
    const arr: pageSizeOptionsType[] = rowsPerPageOptions || [];
    if (pageSize) {
        const foundIndex: number = arr.findIndex((item) =>
            typeof item === 'number' ? item === pageSize : item.value === pageSize,
        );
        if (foundIndex === -1) {
            return [pageSize, ...arr];
        }
    }
    return arr;
};

export const generateHiddenColumns = (columns: any, hiddenColumns: string[]): GridColumnVisibilityModel => {
    const hiddenItems = hiddenColumns.reduce((prev, item) => ({ ...prev, [item]: false }), {});
    const visibleItems = columns.reduce(
        (prev: any, item: any) => ({
            ...prev,
            ...(hiddenColumns.findIndex((hItem: string) => hItem === item.field) === -1 && { [item.field]: true }),
        }),
        {},
    );
    return { ...hiddenItems, ...visibleItems };
};

export const getDefaultHeight = (
    options?: Pick<ICommonProps, 'design'>,
): { columnHeaderHeight: number; rowHeight: number } => {
    switch (options?.design) {
        case DesignTypeEnum.SET:
            return { columnHeaderHeight: 24, rowHeight: 24 };
        default:
            return { columnHeaderHeight: 36, rowHeight: 36 };
    }
};

export const getDataIndexes = (data: any[], rows: readonly any[]): number[] => {
    const indexArr: number[] = [];
    data.forEach((item) => {
        indexArr.push(findIndex(rows, item));
    });
    return indexArr;
};
