import type { FC } from 'react';
import { memo } from 'react';
import { Tab } from '@mui/material';
import type { ITabItemProps } from './type';
import { generateClass } from '../../../utils';

const TabItem: FC<ITabItemProps> = ({ text, ...rest }: ITabItemProps) => {
    return <Tab className={generateClass('TabItem')} label={text} disableFocusRipple disableRipple {...rest} />;
};

export default memo(TabItem);
