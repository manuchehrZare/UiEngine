import type { FC } from 'react';
import { useState, useEffect, forwardRef, memo } from 'react';
import type { Theme } from '@mui/material';
import { Box, Typography } from '@mui/material';
import type { INavTitleProps, IBackButtonProps } from '../type';
import KeyboardBackspaceRoundedIcon from '@mui/icons-material/KeyboardBackspaceRounded';
import Tooltip from '../../Tooltip';
import type { DesignType } from '../../../..';
import { Button, constants, useStorage } from '../../../..';
import ThemeProvider from '../../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty, manageClassNames } from '../../../../utils';
import { omit } from 'lodash';
import { getProviderTheme } from '../../../../utils/methods/theme';

const NavTitle: FC<INavTitleProps> = forwardRef(
    ({ title, backButtonProps, design, sx, subTitle = '', label = '', isView = true }: INavTitleProps, ref) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        const initBackProps: IBackButtonProps = {
            disabled: false,
            iconButton: true,
            show: false,
        };
        const [backProps, setBackProps] = useState<IBackButtonProps>(initBackProps);

        const renderButton = () => {
            const { onClick, variant, text, iconLeft, iconRight, color, icon, className, ...rest } = backProps;
            return (
                <Button
                    {...omit(rest, ['show', 'tooltipTitle'])}
                    design={getComponentDesignProperty(design, storageDesign.newValue)}
                    text={text}
                    iconLeft={iconLeft}
                    iconRight={iconRight}
                    icon={!iconLeft && !iconRight && !text && (icon || <KeyboardBackspaceRoundedIcon />)}
                    variant={variant || 'text'}
                    color={color || 'primary'}
                    className={manageClassNames('custom', className)}
                    onClick={() => onClick?.()}
                />
            );
        };

        const renderBackButton = () => {
            const { tooltipTitle } = backProps;
            return (
                <Box className={manageClassNames(generateClass('NavBackButton-box'))}>
                    {tooltipTitle ? (
                        <Tooltip
                            design={getComponentDesignProperty(design, storageDesign.newValue)}
                            title={tooltipTitle}>
                            {renderButton()}
                        </Tooltip>
                    ) : (
                        renderButton()
                    )}
                </Box>
            );
        };

        useEffect(() => {
            setBackProps({ ...initBackProps, ...backButtonProps });
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [backButtonProps]);

        const renderTitle = () => {
            return (
                <ThemeProvider
                    design={getComponentDesignProperty(design, storageDesign.newValue)}
                    theme={getProviderTheme(storageTheme.newValue)}>
                    <Box ref={ref} className={manageClassNames(generateClass('NavTitle-box'))} sx={sx}>
                        {backProps && backProps.show && renderBackButton()}
                        <Box
                            sx={{
                                flexShrink: 1,
                            }}>
                            {label && (
                                <Typography className={generateClass('NavTitle-label')} variant="overline">
                                    {label}
                                </Typography>
                            )}
                            <Typography className={generateClass('NavTitle')} variant="h4">
                                {title}
                            </Typography>
                            {subTitle && (
                                <Typography className={generateClass('NavTitle-sub')} variant="subtitle1">
                                    {subTitle}
                                </Typography>
                            )}
                        </Box>
                    </Box>
                </ThemeProvider>
            );
        };

        return isView ? renderTitle() : null;
    },
);

export default memo(NavTitle);
