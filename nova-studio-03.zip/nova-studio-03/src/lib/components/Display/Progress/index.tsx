import type { FC } from 'react';
import { memo } from 'react';
import type { IProgressProps } from './type';
import { ProgressTypeEnum } from './type';
import CircularProgress from './Circular';
import LinearProgress from './Linear';

const Progress: FC<IProgressProps> = ({ type, thickness = 3.6, ...rest }) => {
    return (
        <>
            {type === ProgressTypeEnum.Circular && <CircularProgress thickness={thickness} {...rest} />}
            {type === ProgressTypeEnum.Linear && <LinearProgress thickness={thickness} {...rest} />}
        </>
    );
};

export default memo(Progress);
