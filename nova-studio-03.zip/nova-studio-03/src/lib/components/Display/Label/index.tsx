import type { FC } from 'react';
import { forwardRef, memo } from 'react';
import type { Theme } from '@mui/material';
import { Typography } from '@mui/material';
import type { ILabelProps } from './type';
import LabelSxProps from './style';
import type { DesignType } from '../../..';
import { Box, constants, manageClassNames, useStorage } from '../../..';
import ThemeProvider from '../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const Label: FC<ILabelProps> = forwardRef(
    ({ color, text, align = 'left', sx, design, fontSize, fontWeight, className, ...rest }: ILabelProps, ref) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });

        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <Box
                    className={manageClassNames(
                        generateClass('Label'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                        className,
                    )}
                    ref={ref}
                    sx={{
                        ...(LabelSxProps({
                            align,
                            design: getComponentDesignProperty(design, storageDesign.newValue),
                            color,
                        }) as any),
                        ...sx,
                    }}
                    {...rest}>
                    <Typography
                        className={getComponentDesignProperty(design, storageDesign.newValue)}
                        fontSize={fontSize}
                        fontWeight={fontWeight}
                        variant="subtitle1"
                        color={color || (sx as any)?.color}>
                        {text}
                    </Typography>
                </Box>
            </ThemeProvider>
        );
    },
);

export default memo(Label);
