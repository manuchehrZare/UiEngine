import { useLocation } from 'react-router-dom';
import type { FC } from 'react';
import { useEffect } from 'react';

export interface IScrollPageTopProps {
    children: any;
    scrollElement: string | null;
}

const ScrollPageTop: FC<IScrollPageTopProps> = ({ children, scrollElement = 'root' }) => {
    const location: any = useLocation();

    useEffect(() => {
        if (scrollElement) {
            const element: any = document.getElementById(scrollElement);
            element?.scrollIntoView({ block: 'start', behavior: 'smooth' });
        }
    }, [location.pathname, scrollElement]);

    return children || null;
};

export default ScrollPageTop;
