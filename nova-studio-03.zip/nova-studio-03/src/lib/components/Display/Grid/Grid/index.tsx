import { Unstable_Grid2 as MuiGrid } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IGridProps } from '../type';
import type { DesignType } from '../../../..';
import { constants, useStorage } from '../../../..';
import { generateClass, getComponentDesignProperty, manageClassNames } from '../../../../utils';

const Grid: FC<IGridProps> = forwardRef(({ children, design, spacingType, className, ...rest }: IGridProps, ref) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });

    const getSpacingType = () => {
        const activeDesign = getComponentDesignProperty(design, storageDesign.newValue);
        switch (spacingType) {
            case 'common':
                return {
                    spacing: constants.design.grid.spacing.common[activeDesign].unit,
                };
            case 'button':
                return { spacing: constants.design.grid.spacing.button[activeDesign].unit };
            case 'form':
                return {
                    columnSpacing: constants.design.grid.spacing.form.column[activeDesign].unit,
                    rowSpacing: constants.design.grid.spacing.form.row[activeDesign].unit,
                };
            case 'joinedForm':
                return {
                    columnSpacing: constants.design.grid.spacing.joinedForm.column[activeDesign].unit,
                    rowSpacing: constants.design.grid.spacing.form.row[activeDesign].unit,
                };
            default:
                return {};
        }
    };

    return (
        <MuiGrid
            className={manageClassNames(
                generateClass('Grid'),
                getComponentDesignProperty(design, storageDesign.newValue),
                className,
            )}
            container
            columns={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 12, xxl: 12 }}
            ref={ref}
            {...getSpacingType()}
            {...rest}>
            {children}
        </MuiGrid>
    );
});

export default Grid;
