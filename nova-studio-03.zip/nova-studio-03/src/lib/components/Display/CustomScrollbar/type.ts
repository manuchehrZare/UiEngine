import type { JSX, ReactNode } from 'react';
import type { positionValues, ScrollbarProps } from 'react-custom-scrollbars-2';
import type { IBoxProps } from '../../..';

export interface ICustomScrollValues extends positionValues {}

export interface ICustomScrollbarProps
    extends Pick<
            ScrollbarProps,
            'autoHide' | 'autoHideTimeout' | 'autoHideDuration' | 'className' | 'height' | 'style' | 'width'
        >,
        Pick<IBoxProps, 'borderRadius' | 'ref'> {
    children: ReactNode | JSX.Element;
    onScroll?: (e: React.UIEvent<any, UIEvent>, values: ICustomScrollValues) => void;
    onScrollFrame?: (values: ICustomScrollValues) => void;
    onScrollStart?: (values: ICustomScrollValues) => void;
    onScrollStop?: (values: ICustomScrollValues) => void;
    onUpdate?: (values: ICustomScrollValues) => void;
    thickness?: number;
    thumbProps?: Pick<IBoxProps, 'sx'>;
    trackProps?: Pick<IBoxProps, 'sx'>;
    viewProps?: Pick<IBoxProps, 'sx'>;
}
