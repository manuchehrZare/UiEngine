import type { Theme } from '@mui/material';
import { Alert as MuiAlert, AlertTitle } from '@mui/material';
import type { FC } from 'react';
import { memo } from 'react';
import ThemeProvider from '../../App/ThemeProvider';
import type { IAlertProps } from './type';
import type { DesignType } from '../../..';
import { View, constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';
import { InfoOutlined } from '@mui/icons-material';

const Alert: FC<IAlertProps> = ({
    title,
    titleProps,
    text,
    type = 'primary',
    action,
    onClose,
    icon,
    design,
    className,
    variant = 'outlined',
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });

    const handleClose = () => {
        onClose?.();
    };

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme?.newValue)}>
            <MuiAlert
                className={manageClassNames(
                    generateClass('Alert'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                {...rest}
                variant={variant}
                icon={icon}
                iconMapping={{
                    primary: <InfoOutlined fontSize="inherit" />,
                }}
                onClose={onClose && handleClose}
                severity={type}
                action={action}>
                <View show={Boolean(title)}>
                    <AlertTitle {...titleProps}>{title}</AlertTitle>
                </View>
                {text}
            </MuiAlert>
        </ThemeProvider>
    );
};

export default memo(Alert);
