import type { TooltipProps } from 'recharts';
import { Tooltip } from 'recharts';
import type { NameType, ValueType } from 'recharts/types/component/DefaultTooltipContent';
import type { ChartDataTypes, ChartTooltipTypes } from '../../commonTypes';
import type { ITooltip } from './type';
import type { JSX } from 'react';

const CustomTooltip = <T extends ChartDataTypes, Y extends ChartTooltipTypes>(
    chartType: 'pie' | 'bar' | 'line',
    tooltip: boolean | ITooltip | Y,
    activeTooltipData?: any,
    data?: T,
    yUnit?: string | [string, string],
): JSX.Element => {
    const defaultSeperator = chartType === 'pie' ? '' : ' ';

    const CustomTooltipContent = ({
        active,
        payload,
        label,
        contentStyle,
        labelStyle,
        itemStyle,
        separator,
    }: TooltipProps<ValueType, NameType>) => {
        if (active) {
            return (
                <div className="recharts-default-tooltip" style={contentStyle}>
                    <p className="recharts-tooltip-label" style={labelStyle}>
                        {label}
                    </p>
                    <ul className="recharts-tooltip-item-list" style={{ padding: 0, margin: 0 }}>
                        {payload?.map((pItem, index) => {
                            return (
                                <li
                                    key={`${pItem.name}-${String(index)}`}
                                    className="recharts-tooltip-item"
                                    style={itemStyle}>
                                    <span
                                        style={{
                                            display: 'inline-block',
                                            marginRight: '5px',
                                            borderRadius: '10px',
                                            width: '8px',
                                            height: '8px',
                                            backgroundColor: pItem?.color || pItem?.payload?.fill,
                                        }}
                                    />
                                    <strong className="recharts-tooltip-item-name">{pItem.name}</strong>
                                    <strong className="recharts-tooltip-item-separator">{separator}</strong>
                                    {chartType === 'pie' && (
                                        <div className="recharts-tooltip-item-value" style={{ paddingLeft: 15 }}>
                                            {/* eslint-disable-next-line no-constant-binary-expression */}
                                            {`${pItem?.payload?.payload?.valueUI} (%${(
                                                activeTooltipData?.percent * 100
                                            ).toFixed(2)})` || pItem.value}
                                        </div>
                                    )}
                                    {chartType !== 'pie' && (
                                        <span className="recharts-tooltip-item-value">
                                            {data &&
                                                ((data as any)[activeTooltipData?.activeTooltipIndex]?.values[index]
                                                    ?.valueUI ||
                                                    `${pItem.value}${
                                                        yUnit ? (typeof yUnit === 'string' ? yUnit : yUnit[0]) : ''
                                                    }`)}
                                        </span>
                                    )}
                                    <span className="recharts-tooltip-item-unit">{pItem.unit}</span>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            );
        }
        return null;
    };

    return (
        <Tooltip
            separator={typeof tooltip !== 'boolean' ? `${tooltip?.seperator || defaultSeperator}` : defaultSeperator}
            cursor={{
                fill:
                    typeof tooltip !== 'boolean' && (tooltip as any).cursorBgColor // for bar chart control
                        ? (tooltip as any).cursorBgColor // for bar chart data
                        : 'var(--color-grey-50)',
            }}
            contentStyle={{
                margin: 0,
                padding: 10,
                whiteSpace: 'nowrap',
                boxShadow: '0 3px 5px var(--color-grey-300)',
                backgroundColor: '#fff',
                border: '1px solid var(--color-grey-100)',
                ...(typeof tooltip !== 'boolean'
                    ? {
                          ...(tooltip.backgroundColor && {
                              backgroundColor: tooltip.backgroundColor,
                          }),
                          ...(tooltip.border && {
                              border: tooltip.border,
                          }),
                          ...(tooltip.radius && {
                              borderRadius: tooltip.radius,
                          }),
                          ...(tooltip.boxShadow && {
                              boxShadow: tooltip.boxShadow,
                          }),
                      }
                    : {}),
            }}
            labelStyle={{
                margin: 0,
                ...(chartType === 'bar' && {
                    color: (tooltip as ITooltip).labelColor || 'var(--color-text)',
                }),
                fontSize: (tooltip as ITooltip).fontSize || 12,
                fontWeight: 'bold',
            }}
            itemStyle={{
                display: 'block',
                paddingTop: 4,
                paddingBottom: 4,
                color: 'var(--color-text)',
                fontSize: (tooltip as ITooltip).fontSize || 12,
                ...(typeof tooltip !== 'boolean'
                    ? {
                          ...(tooltip.valueColor && {
                              color: tooltip.valueColor,
                          }),
                          ...(tooltip?.fontSize && {
                              fontSize: tooltip.fontSize,
                          }),
                      }
                    : {}),
            }}
            content={<CustomTooltipContent />}
        />
    );
};

export default CustomTooltip;
