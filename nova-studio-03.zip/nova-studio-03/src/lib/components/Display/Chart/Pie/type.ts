import type { IChartCommonProps, IChartData, IChartMargin } from '../commonTypes';
import type { ITooltip } from '../utils/Tooltip/type';

interface IFontProps {
    color?: string;
    fontSize?: number;
    fontWeight?: string | number;
    textShadowColor?: string;
}
export interface IInsideRate extends IFontProps {}

export interface IInfoView {
    name?: Pick<IFontProps, 'fontSize' | 'color' | 'fontWeight'>;
    value?: Pick<IFontProps, 'fontSize' | 'color' | 'fontWeight'>;
}

export interface IPartialNameView extends Pick<IFontProps, 'fontSize' | 'color' | 'fontWeight'> {}

interface IActiveShape {
    eventType?: 'hover' | 'click';
    infoView?: boolean | IInfoView;
    insideRate?: boolean | IInsideRate;
    partialNameView?: boolean | IPartialNameView;
    type?: 'default' | 'bold';
}

export interface IPieChartData extends Pick<IChartData, 'name'> {
    value: number;
    valueUI?: string;
}

export interface IPieLabel extends Pick<IFontProps, 'fontSize' | 'color' | 'fontWeight'> {
    offset?: number;
    position?: 'center' | 'outside';
    value: string;
}

export interface IActiveIndex {
    constant?: boolean;
    value: number | number[];
}

export interface IPieTooltip extends ITooltip {}

export interface IPieChartProps extends IChartCommonProps {
    activeIndex?: number | number[] | IActiveIndex;
    activeShape?: IActiveShape;
    data: IPieChartData[];
    insideRadius?: number;
    label?: string | IPieLabel;
    paddingAngle?: number;
    tooltip?: boolean | IPieTooltip;
}

export const initialPieMargin: IChartMargin = { bottom: 0, top: 0 };
