/** For Custom Initialization */
import { i18n, i18nInit, languageStorageKey } from './_i18nInstance';
export declare const i18nInitialize: () => Promise<void>;
export { i18n, i18nInit, languageStorageKey };
//# sourceMappingURL=i18n.d.ts.map