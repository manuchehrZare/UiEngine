export declare enum LocalesEnum {
    TURKISH = "tr",
    ENGLISH = "en"
}
export type LocalesType = `${LocalesEnum}`;
export type ChangeLanguageOptions = {
    callback?: () => void;
    lng: LocalesType;
    reload?: boolean;
};
//# sourceMappingURL=type.d.ts.map