interface IExportHTMLToTextProps {
    data: string;
    fileName: string;
    fontSize?: number;
    marginBottom?: number;
    marginLeft?: number;
    marginRight?: number;
    marginTop?: number;
}
export declare const exportHtmlToText: ({ data, fileName, marginLeft, marginRight, marginTop, marginBottom, fontSize, }: IExportHTMLToTextProps) => void;
export {};
//# sourceMappingURL=exportHtmlToText.d.ts.map