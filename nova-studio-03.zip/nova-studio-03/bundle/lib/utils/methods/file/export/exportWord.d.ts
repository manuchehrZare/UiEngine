import type { IExportPDFProps } from './exportHtmlToPDF';
interface IExportWordProps extends Omit<IExportPDFProps, 'margin'> {
}
export declare const exportWord: ({ data, fileName }: IExportWordProps) => void;
export {};
//# sourceMappingURL=exportWord.d.ts.map