export {};
//# sourceMappingURL=_Font_SourceSansPro-Regular-normal.d.ts.map