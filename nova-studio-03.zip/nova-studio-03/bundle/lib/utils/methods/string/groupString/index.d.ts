type GroupStringOptions = {
    repeatPattern?: boolean;
    returnArray?: boolean;
    separator?: string;
};
/**
 * Function that partitions a string into segments based on specified grouping rules.
 * @param value The string to be partitioned.
 * @param pattern The grouping pattern - can be a single number or an array of numbers.
 * @param repeatPattern Repeat the entire pattern (true) or only the last element (false).
 * @param separator The separator character between groups (default: space).
 * @returns The grouped string.
 */
export declare const groupString: (value: string, pattern: number | number[], options?: GroupStringOptions) => string | string[];
export {};
//# sourceMappingURL=index.d.ts.map