import type { Now, Time, TimeReturnValues } from '../../..';
/**
 * Returns the current system date/time broken into individual components.
 * No parameters required — always fetches current local system time.
 * @returns {Now} Current time snapshot
 */
export declare const getNow: () => Now;
/**
 * Converts a Time object into total milliseconds
 * @param time - Time object to convert
 * @returns total milliseconds
 */
export declare const timeToMilliseconds: (time: Time) => number;
/**
 * Converts milliseconds into a Time object (hours, minutes, seconds, milliseconds)
 * @param ms - Total milliseconds to convert
 * @param returnValues - Object indicating which time components should be returned.
 * @default returnValues : { hours: true, milliseconds: true, minutes: true, seconds: true }
 * @returns Time object with selected components
 */
export declare const millisecondsToTime: (ms: number, returnValues?: TimeReturnValues) => Time;
//# sourceMappingURL=index.d.ts.map