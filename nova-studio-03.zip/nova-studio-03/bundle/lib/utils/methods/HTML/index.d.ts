export { sanitizeHTML } from './sanitizeHTML';
export { stringHTMLToJSX } from './stringHTMLToJSX';
//# sourceMappingURL=index.d.ts.map