import type { domToReact } from 'html-react-parser';
import type { SanitizeOptions } from '../../../..';
/**
 * Converts an HTML string into JSX, with optional sanitization.
 *
 * @param html - The HTML string to be converted to JSX.
 * @param sanitize - Optional. If `true`, the HTML will be sanitized with default settings.
 * If an object like `{ options?: SanitizeOptions }`, it will be sanitized with the specified DOMPurify options.
 * If `false` or `undefined`, no sanitization is performed.
 * @returns The JSX representation of the HTML string.
 */
export declare const stringHTMLToJSX: (html: string, sanitize?: boolean | {
    options?: SanitizeOptions;
}) => ReturnType<typeof domToReact>;
//# sourceMappingURL=index.d.ts.map