import type { AnalyseResult } from 'chardet';
/**
 * Returns decoded base64 data.
 * @param data base64 data to convert.
 * @param encoding Charset of base64 data. It could be one of the ISO family or windows, UTF etc. Default is UTF-8. https://encoding.spec.whatwg.org/
 * @returns T or null
 */
export declare const base64Decryption: <T>(data: string, encoding?: string) => {
    analyse: AnalyseResult;
    data: T | null;
    detectEncoding: string | null;
} | undefined;
//# sourceMappingURL=_decryption.d.ts.map