interface IStringEncryption {
    encoding?: string;
    onLoadingChange?: (isLoading: boolean) => void;
}
interface IFileEncryption {
    onFileLoad?: (onSuccess?: FileConversionResult | null, onError?: DOMException) => void;
    onLoadingChange?: (isLoading: boolean) => void;
}
type FileConversionResult = {
    b64Content: string;
    dataUrl: string;
    filename: string;
    lastModified: number;
    size: number;
    type: string;
    webkitRelativePath: string;
};
type StringConversionResult = {
    base64: string;
    buffer: Buffer;
};
/**
 * Returns decoded base64 data of a string or Promise of converted FileList base64 content with file properties.
 * @param data Data to be converted to base64. When typeof data is FileList or File[] the function need to use with async await because of the ():Promise<any> => () return type.
 * @param options Configuration options for the encryption process:
 * @param options.encoding (For string data only) Charset of base64 data. It could be one of the ISO family or windows, UTF etc. Default is UTF-8. https://encoding.spec.whatwg.org/
 * @param options.onLoadingChange (Optional) Loading state change callback function.
 * @param options.onFileLoad (For FileList data only) Callback function that fires when each file is loaded.
 * @returns Promise<any> Object with keys buffer and base64 depends of given data type.
 */
export declare function base64Encryption(data: string, options?: IStringEncryption): StringConversionResult;
export declare function base64Encryption(data: FileList | File[], options?: IFileEncryption): Promise<FileConversionResult[]>;
export {};
//# sourceMappingURL=_encryption.d.ts.map