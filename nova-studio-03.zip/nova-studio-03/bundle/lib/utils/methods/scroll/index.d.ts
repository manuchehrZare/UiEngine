export declare const scrollToElement: (elementId: string) => void;
export declare const scrollToTop: (_rootElementId?: string) => void;
//# sourceMappingURL=index.d.ts.map