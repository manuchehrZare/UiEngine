import type { IConfirmModalProps } from '../../../components/Display/Confirm/type';
export interface IConfirmMessageModalProps extends Omit<IConfirmModalProps, 'onConfirm'> {
    proceed: any;
}
declare const _default: import("react-confirm").ConfirmableDialog<IConfirmMessageModalProps, unknown>;
export default _default;
//# sourceMappingURL=ConfirmMessageModal.d.ts.map