import { DesignTypeEnum } from '../../types/common';
export declare const design: {
    defaultType: DesignTypeEnum;
    border: {
        paper: {
            common: {
                SET: {
                    width: number;
                };
            };
            borderBox: {
                default: {
                    width: number;
                };
                SET: {
                    width: number;
                };
            };
        };
    };
    gap: {
        button: {
            default: {
                unit: number;
                pixel: number;
            };
            SET: {
                unit: number;
                pixel: number;
            };
        };
    };
    grid: {
        spacing: {
            common: {
                default: {
                    unit: number;
                    pixel: number;
                };
                SET: {
                    unit: number;
                    pixel: number;
                };
            };
            button: {
                default: {
                    unit: number;
                    pixel: number;
                };
                SET: {
                    unit: number;
                    pixel: number;
                };
            };
            form: {
                column: {
                    default: {
                        unit: number;
                        pixel: number;
                    };
                    SET: {
                        unit: number;
                        pixel: number;
                    };
                };
                row: {
                    default: {
                        unit: number;
                        pixel: number;
                    };
                    SET: {
                        unit: number;
                        pixel: number;
                    };
                };
            };
            joinedForm: {
                column: {
                    default: {
                        unit: number;
                        pixel: number;
                    };
                    SET: {
                        unit: number;
                        pixel: number;
                    };
                };
            };
        };
    };
    gridItem: {
        sizeType: {
            common: {
                xs: number;
            };
            form: {
                default: {
                    xs: number;
                };
                SET: {
                    xs: number;
                    sm: number;
                    md: number;
                    lg: number;
                    xl: number;
                    xxl: number;
                };
            };
        };
    };
};
//# sourceMappingURL=index.d.ts.map