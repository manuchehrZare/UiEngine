export declare const classNames: {
    labelEllipsis: string;
};
//# sourceMappingURL=index.d.ts.map