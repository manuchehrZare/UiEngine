import * as yup from 'yup';
import type { IStringOptions } from '../type';
import type { FieldValues } from '../../../hooks/useForm';
export declare const stringValidation: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: IStringOptions<T>) => yup.StringSchema<string | undefined, yup.AnyObject, undefined, "">;
//# sourceMappingURL=index.d.ts.map