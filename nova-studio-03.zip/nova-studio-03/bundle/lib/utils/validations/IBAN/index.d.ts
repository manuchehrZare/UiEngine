import type { FieldValues } from '../../../hooks/useForm';
import type { IIBANOptions } from '../type';
export declare const ibanValidation: <TFormValues extends FieldValues>(options?: IIBANOptions<TFormValues>) => import("yup").StringSchema<string | undefined, import("yup").AnyObject, undefined, "">;
//# sourceMappingURL=index.d.ts.map