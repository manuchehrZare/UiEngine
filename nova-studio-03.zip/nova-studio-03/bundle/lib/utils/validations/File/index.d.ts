import * as yup from 'yup';
import type { IFileOptions } from '../type';
import type { FieldValues } from '../../../hooks/useForm';
export declare const fileValidation: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: IFileOptions<T>) => yup.MixedSchema<{} | undefined, yup.AnyObject, undefined, "">;
//# sourceMappingURL=index.d.ts.map