import type { PaletteColor, PaletteColorOptions, PaletteOptions } from '@mui/material';
declare module '@mui/material' {
    interface Palette {
        dark: Color;
        green: PaletteColor;
        lightGrey: PaletteColor;
        slateGreen: PaletteColor;
    }
    interface PaletteOptions {
        dark?: Partial<Color>;
        green?: PaletteColorOptions;
        lightGrey?: PaletteColorOptions;
        slateGreen?: PaletteColorOptions;
    }
    interface PaletteColor extends Omit<Partial<Color>, 'A100' | 'A200' | 'A400' | 'A700'> {
    }
}
export interface CustomPaletteColorOptions extends Omit<PaletteColor, 'contrastText'> {
}
interface CustomPaletteOptions extends PaletteOptions {
    dark: Pick<CustomPaletteColorOptions, 50 | 100>;
    error: CustomPaletteColorOptions;
    green: CustomPaletteColorOptions;
    grey: Omit<CustomPaletteColorOptions, 'light' | 'main' | 'dark'>;
    info: CustomPaletteColorOptions;
    lightGrey: CustomPaletteColorOptions;
    primary: CustomPaletteColorOptions;
    secondary: CustomPaletteColorOptions;
    slateGreen: CustomPaletteColorOptions;
    success: CustomPaletteColorOptions;
    warning: CustomPaletteColorOptions;
}
export declare const palette: CustomPaletteOptions;
export {};
//# sourceMappingURL=_palette.d.ts.map