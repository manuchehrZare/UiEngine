export declare const getCssReset: () => object;
//# sourceMappingURL=_css_reset.d.ts.map