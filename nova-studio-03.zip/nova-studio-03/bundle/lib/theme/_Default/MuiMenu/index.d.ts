import type { Components } from '@mui/material';
export declare const MuiMenuTheme: Components;
//# sourceMappingURL=index.d.ts.map