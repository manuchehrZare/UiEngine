import type { Components } from '@mui/material';
export declare const MuiBreadcrumbsTheme: Components;
//# sourceMappingURL=index.d.ts.map