import type { Components } from '@mui/material';
export declare const MuiTooltipTheme: Components;
//# sourceMappingURL=index.d.ts.map