import type { Components } from '@mui/material';
export declare const MuiAlertTheme: Components;
//# sourceMappingURL=index.d.ts.map