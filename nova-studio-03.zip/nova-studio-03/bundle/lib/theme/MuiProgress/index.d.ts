import type { Components } from '@mui/material';
export declare const MuiProgressTheme: Components;
//# sourceMappingURL=index.d.ts.map