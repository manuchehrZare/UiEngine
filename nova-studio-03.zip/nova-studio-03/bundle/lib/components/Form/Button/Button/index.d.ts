import type { FC } from 'react';
import type { IButtonProps } from '../type';
declare const Button: FC<IButtonProps>;
export default Button;
//# sourceMappingURL=index.d.ts.map