import type { DesignType } from '../../../../utils';
interface ICalculateEditorContentHeight {
    charCounterCount?: boolean;
    design: DesignType | undefined;
    froalaRef: any;
    height: string | number;
    labelRef?: any;
    wordCounterCount?: boolean;
}
export declare const calculateEditorContentHeight: ({ height, froalaRef, charCounterCount, wordCounterCount, design, labelRef, }: ICalculateEditorContentHeight) => string;
export {};
//# sourceMappingURL=action.d.ts.map