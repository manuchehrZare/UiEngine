import type { FC } from 'react';
declare const NumberInputBaseComponent: FC;
export default NumberInputBaseComponent;
//# sourceMappingURL=NumberInput.d.ts.map