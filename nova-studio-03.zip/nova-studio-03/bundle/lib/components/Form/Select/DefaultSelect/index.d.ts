import { type JSX } from 'react';
import type { ISelectProps } from '../type';
declare const Select: <T>({ helperText, name, id, label, displayEmpty, startAdornment, options, hiddenItems, disabledItems, onChange, control, required, disabled, setValue, size, fullWidth, variant, multiple, readOnly, className, native, nativeProps, onFocus, deps, sx, ...rest }: ISelectProps<T>) => JSX.Element;
export default Select;
//# sourceMappingURL=index.d.ts.map