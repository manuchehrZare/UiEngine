import type { IButtonProps, IInputProps } from '../../..';
export type IEncryptedFiles = {
    b64content: string;
    filename: string;
    lastModified: number;
    size: number;
    type: string;
};
export interface IFileSelectorInputProps extends Omit<IInputProps, 'minRows' | 'maxRows' | 'multiline' | 'autoComplete' | 'mask' | 'maskChar' | 'maskLazy' | 'maxLength' | 'minLength' | 'passwordVisibility' | 'capslockDetector' | 'endAdornment' | 'startAdornment' | 'type' | 'onChange' | 'rows' | 'onKeyPress' | 'readOnly' | 'deps'> {
    adornmentType?: 'hidden' | 'startAdornment' | 'endAdornment';
    /**
     * Controls the usege type of the component.
     * @default 'Input'
     */
    component: 'Input';
    /**
     * Controls the multi file selection.
     * @default false
     */
    multiple?: boolean;
    /**
     * Callback function that returns the selected files as FileList.
     *
     * @param files Current selected FileList.
     */
    onUpdateFile?: (files: FileList) => void;
    /**
     * Controls the file explorer of the local device.
     * If the parameter sends as true, the file selection changes as folder selection.
     * @default false
     */
    webkitDirectory?: boolean;
}
export interface IFileSelectorButtonProps extends Omit<IFileSelectorInputProps, 'component'> {
    /**
     * Partiall ButtonProps are only available when the component sets to Button.
     */
    ButtonProps?: Partial<IButtonProps>;
    component?: 'Button';
}
export type IFileSelectorProps = IFileSelectorInputProps | IFileSelectorButtonProps;
//# sourceMappingURL=type.d.ts.map