import type { MenuProps } from '@mui/material';
export declare const SelectMenuProps: Partial<MenuProps>;
export declare const defaultDatePickerSeparator: {
    default: string;
    SET: string;
};
export declare const defaultTimePickerSeparator: {
    default: string;
    SET: string;
};
export declare const pickerProps: {
    default: {
        datePicker: {
            dateSeparator: string;
            mask: string;
            inputFormat: string;
        };
        dateTimePicker: {
            dateSeparator: string;
            timeSeparator: string;
            mask: string;
            inputFormat: string;
        };
        timePicker: {
            timeSeparator: string;
            mask: string;
            inputFormat: string;
        };
    };
    SET: {
        datePicker: {
            dateSeparator: string;
            mask: string;
            inputFormat: string;
        };
        dateTimePicker: {
            dateSeparator: string;
            timeSeparator: string;
            mask: string;
            inputFormat: string;
        };
        timePicker: {
            timeSeparator: string;
            mask: string;
            inputFormat: string;
        };
    };
};
//# sourceMappingURL=_helper.d.ts.map