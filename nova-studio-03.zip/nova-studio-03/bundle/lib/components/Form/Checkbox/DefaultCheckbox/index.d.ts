import type { FC } from 'react';
import type { ICheckboxProps } from '../type';
declare const DefaultCheckbox: FC<ICheckboxProps>;
export default DefaultCheckbox;
//# sourceMappingURL=index.d.ts.map