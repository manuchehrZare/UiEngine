import type { SxProps, Theme } from '@mui/material';
import type { DesignType } from '../../../utils/types/common';
import type { IUploadProps } from './type';
interface IParams extends Pick<IUploadProps, 'variant'> {
    design: DesignType;
}
declare const MuiUploadSxProps: ({ design, variant }: IParams) => SxProps<Theme>;
export default MuiUploadSxProps;
//# sourceMappingURL=style.d.ts.map