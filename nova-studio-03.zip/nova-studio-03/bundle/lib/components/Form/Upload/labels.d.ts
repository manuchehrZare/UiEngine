import type { t as i18nextTFunction } from 'i18next';
export declare const getLabels: (t: typeof i18nextTFunction) => object;
//# sourceMappingURL=labels.d.ts.map