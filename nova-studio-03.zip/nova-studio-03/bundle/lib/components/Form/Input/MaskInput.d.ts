declare const TextMaskCustom: import("react").ForwardRefExoticComponent<Omit<any, "ref"> & import("react").RefAttributes<unknown>>;
export default TextMaskCustom;
//# sourceMappingURL=MaskInput.d.ts.map