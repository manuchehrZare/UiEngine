import type { Theme } from '@mui/material';
import type { SnackbarProviderProps } from 'notistack';
import { SnackbarProvider as NotistackSnackbarProvider } from 'notistack';
import type { StyledComponent } from '@emotion/styled';
import type { MUIStyledCommonProps } from '@mui/system';
import type { Ref } from 'react';
declare const SnackbarProvider: StyledComponent<SnackbarProviderProps & MUIStyledCommonProps<Theme>, {}, {
    ref?: Ref<NotistackSnackbarProvider> | undefined;
}>;
export default SnackbarProvider;
//# sourceMappingURL=index.d.ts.map