import type { FC } from 'react';
import type { ICarouselItemProps } from './type';
declare const CarouselItem: FC<ICarouselItemProps>;
export default CarouselItem;
//# sourceMappingURL=CarouselItem.d.ts.map