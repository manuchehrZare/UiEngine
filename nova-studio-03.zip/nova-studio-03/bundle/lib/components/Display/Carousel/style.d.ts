import type { SxProps, Theme } from '@mui/material';
import type { ICarouselItemProps, ICarouselProps } from './type';
export declare const MuiCarouselSxProps: ({ height, indicatorsPosition, }: Pick<ICarouselProps, "height" | "indicatorsPosition">) => SxProps<Theme>;
export declare const MuiCarouselItemSxProps: ({ contentPosition, image, }: Pick<ICarouselItemProps, "contentPosition" | "image">) => SxProps<Theme>;
//# sourceMappingURL=style.d.ts.map