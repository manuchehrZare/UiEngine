import type { SxProps } from '@mui/material';
import type { Theme } from '@mui/system';
import type { ReactNode } from 'react';
import type { CarouselNavProps } from 'react-material-ui-carousel/dist/components/types';
export declare enum CarouselContentPositionEnum {
    BottomCenter = "bottom-center",
    BottomEnd = "bottom-end",
    BottomStart = "bottom-start",
    Center = "center",
    CenterEnd = "center-end",
    CenterStart = "center-start",
    TopCenter = "top-center",
    TopEnd = "top-end",
    TopStart = "top-start"
}
export type CarouselContentPositionType = `${CarouselContentPositionEnum}`;
export type CarouselIndicatorsPositionType = 'in' | 'out';
export interface ICarouselProps {
    /** Used to customize the **active** indicator `IconButton`.
     * Type: `{className: string, style: React.CSSProperties}` */
    activeIndicatorIconButtonProps?: CarouselNavProps;
    /** Defines the animation style of the Carousel  */
    animation?: 'fade' | 'slide';
    /** Defines if the component will auto scroll between children */
    autoPlay?: boolean;
    /** Defines if `onChange` prop will be called when the carousel renders for the first time. In `componentDidMount` */
    changeOnFirstRender?: boolean;
    children: ReactNode;
    /** Defines custom class name(s), that will be added to Carousel element */
    className?: string;
    /** Defines if the next button will be visible on the last slide, and the previous button on the first slide. Auto-play also stops on the last slide. Indicators continue to work normally. */
    cycleNavigation?: boolean;
    /** Defines the duration of the animations. For more information refer to the [Material UI Documentation for Transitions](https://material-ui.com/components/transitions/) */
    duration?: number;
    /** Defines if the the next/previous button wrappers will cover the full height of the Item element and show buttons on full height hover */
    fullHeightHover?: boolean;
    /** Defines the carousel's height in `px`. If this is not set, the carousel's height will be the height of its children. */
    height: number | string;
    /** Defines which child (assuming there are more than 1 children) will be displayed. Next and Previous Buttons as well as Indicators will work normally after the first render. When this prop is updated the carousel will display the chosen child. Use this prop to programmatically set the active child. If (index > children.length) then if (strictIndexing) index = last element. index */
    index?: number;
    /** Used to customize the indicators container/wrapper.
     * Type: `{className: string, style: React.CSSProperties}` */
    indicatorContainerProps?: CarouselNavProps;
    /** Defines the element inside the indicator `IconButton`s Refer to [MaterialUI Button Documentation](https://material-ui.com/components/buttons/) for more examples.
     * It is advised to use Material UI Icons, but you could use any element (`<img/>`, `<div/>`, ...) you like.*/
    indicatorIcon?: ReactNode;
    /** Used to customize the **non-active** indicator `IconButton`s.
     * Type: `{className: string, style: React.CSSProperties}` */
    indicatorIconButtonProps?: CarouselNavProps;
    /** Defines the existence of bullet indicators */
    indicators?: boolean;
    indicatorsPosition?: CarouselIndicatorsPositionType;
    /** Defines the interval in ms between active child changes (autoPlay) */
    interval?: number;
    /** Gives full control of the nav buttons. Should return a button that uses the given `onClick`.
     * Works in tandem with all other customization options (`navButtonsProps`, `navButtonsWrapperProps`, `navButtonsAlwaysVisible`, `navButtonsAlwaysInvisible`, `fullHeightHover` ...).
     * Refer to the [example section](README.md) for more information */
    NavButton?: ({ className, next, onClick, prev, style, }: {
        className: string;
        next: boolean;
        onClick: Function;
        prev: boolean;
        style: React.CSSProperties;
    }) => ReactNode;
    /**	Defines if the next/previous buttons will always be invisible or not */
    navButtonsAlwaysInvisible?: boolean;
    /** Defines if the next/previous buttons will always be visible or not */
    navButtonsAlwaysVisible?: boolean;
    /** Used to customize the actual nav `IconButton`s */
    navButtonsProps?: CarouselNavProps;
    /** Used to customize the div surrounding the nav `IconButtons`. Use this to position the buttons onto, below, outside, e.t.c. the carousel. */
    navButtonsWrapperProps?: CarouselNavProps;
    /** Function that is called **after** internal `next()` method. First argument is the child **we are going to display**, while the second argument is the child **that was previously displayed** */
    next?: (now?: number, previous?: number) => any;
    /** Defines the element inside the nav "next" `IconButton`. Refer to [MaterialUI Button Documentation](https://material-ui.com/components/buttons/) for more examples.
     * It is advised to use Material UI Icons, but you could use any element (`<img/>`, `<div/>`, ...) you like. */
    nextNav?: ReactNode;
    /** Function that is called **after** internal `setActive()` method. The `setActive()` method is called when the next and previous buttons are pressed, when an indicator is pressed, or when the `index` prop changes. First argument is the child **we are going to display**, while the second argument is the child **that was previously displayed**. Will be c */
    onChange?: (now?: number, previous?: number) => any;
    /** Function that is called **after** internal `prev()` method. First argument is the child **we are going to display**, while the second argument is the child **that was previously displayed** */
    prev?: (now?: number, previous?: number) => any;
    /** Defines the element inside the nav "prev" `IconButton`. Refer to [MaterialUI Button Documentation](https://material-ui.com/components/buttons/) for more examples.
     * It is advised to use Material UI Icons, but you could use any element (`<img/>`, `<div/>`, ...) you like. */
    prevNav?: ReactNode;
    /** Defines if auto scrolling will continue while mousing over carousel */
    stopAutoPlayOnHover?: boolean;
    /** Defines whether index can be bigger than children length */
    strictIndexing?: boolean;
    /** Defines if swiping left and right (in touch devices) triggers `next` and `prev` behaviour */
    swipe?: boolean;
    /** Defines `sx` props, that will be inserted into Carousel element */
    sx?: SxProps<Theme>;
}
export interface ICarouselItemProps {
    content?: ReactNode;
    contentPosition?: CarouselContentPositionType;
    image?: string;
    sx?: SxProps<Theme>;
}
//# sourceMappingURL=type.d.ts.map