import type { FC } from 'react';
import type { IPaperProps } from './type';
declare const Paper: FC<IPaperProps>;
export default Paper;
//# sourceMappingURL=index.d.ts.map