import type { IPaginationProps } from './type';
declare const _default: import("react").NamedExoticComponent<IPaginationProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map