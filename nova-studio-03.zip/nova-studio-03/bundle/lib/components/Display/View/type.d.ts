export interface IViewProps {
    children: any;
    show: boolean;
}
//# sourceMappingURL=type.d.ts.map