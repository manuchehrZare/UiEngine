import type { ITooltipProps } from './type';
declare const _default: import("react").NamedExoticComponent<ITooltipProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map