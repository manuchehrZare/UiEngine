import type { FC } from 'react';
import type { INumberFormatProps } from './type';
declare const NumberFormat: FC<INumberFormatProps>;
export default NumberFormat;
//# sourceMappingURL=index.d.ts.map