import type { IBreadcrumbsProps } from './type';
declare const _default: import("react").NamedExoticComponent<IBreadcrumbsProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map