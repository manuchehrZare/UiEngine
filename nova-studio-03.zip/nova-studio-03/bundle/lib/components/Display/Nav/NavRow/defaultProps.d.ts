import type { INavRowProps } from '../../../..';
export declare const getDefaultProps: ({ design }: Pick<INavRowProps, "design">) => Pick<INavRowProps, "px">;
//# sourceMappingURL=defaultProps.d.ts.map