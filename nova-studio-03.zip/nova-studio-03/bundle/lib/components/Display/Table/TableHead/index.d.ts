import type { FC } from 'react';
import type { ITableHeadProps } from './type';
declare const TableHead: FC<ITableHeadProps>;
export default TableHead;
//# sourceMappingURL=index.d.ts.map