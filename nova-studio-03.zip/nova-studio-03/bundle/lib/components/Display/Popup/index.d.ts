import type { IPopupProps } from './type';
declare const _default: import("react").NamedExoticComponent<IPopupProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map