import type { IBarChartData } from './Bar/type';
export declare const getDataModelForBarChart: (data: IBarChartData[]) => any[];
//# sourceMappingURL=action.d.ts.map