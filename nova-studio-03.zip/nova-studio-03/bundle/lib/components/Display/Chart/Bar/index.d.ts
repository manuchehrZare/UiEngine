import type { FC } from 'react';
import type { IBarChartProps } from './type';
declare const BarChart: FC<IBarChartProps>;
export default BarChart;
//# sourceMappingURL=index.d.ts.map