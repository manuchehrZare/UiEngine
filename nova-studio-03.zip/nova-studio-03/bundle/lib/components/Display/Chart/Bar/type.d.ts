import type { IChartCommonProps, IChartData, IChartMargin } from '../commonTypes';
import type { AxisDomain } from 'recharts/types/util/types';
import type { ITooltip } from '../utils/Tooltip/type';
interface IAxisLabelData {
    color?: string;
    fontSize?: number;
    xLabel?: string;
    yLabel?: string;
}
interface IAxis {
    label?: IAxisLabelData;
    lineColor?: string;
    xLine?: boolean;
    xOrientation?: 'top' | 'bottom';
    xUnit?: string;
    yLine?: boolean;
    yOrientation?: 'left' | 'right';
    yUnit?: string | [string, string];
}
interface ITickProps {
    x?: number;
    y?: number;
}
export interface ITick {
    angle?: ITickProps;
    color?: string;
    equivalentPoints?: number[];
    fontSize?: number;
    fontWeight?: string | number;
    line?: boolean;
    margin?: ITickProps;
    points?: number[];
    width?: ITickProps;
    xView?: boolean;
    yView?: boolean;
}
interface ICartesianGrid {
    backgroundColor?: string;
    horizontal?: boolean;
    lineColor?: string;
    strokeDashArray?: string | number;
    vertical?: boolean;
}
interface IBarLabel {
    color?: string;
    fontSize?: number;
    position?: 'top' | 'bottom' | 'right' | 'left' | 'center';
}
interface IBar {
    gap?: number;
    label?: boolean | IBarLabel;
    radius?: number | [number, number, number, number];
    size?: number;
}
export interface IBarChartDataValuesItem extends IChartData {
}
export interface IBarChartData {
    name: string;
    values: IBarChartDataValuesItem[];
}
export interface IBarTooltip extends ITooltip {
    cursorBgColor?: string;
}
export interface IBarChartProps extends IChartCommonProps {
    axis?: IAxis;
    bar?: IBar;
    data: any[];
    grid?: boolean | ICartesianGrid;
    layout?: 'horizontal' | 'vertical';
    range?: AxisDomain;
    tick?: ITick;
    tooltip?: boolean | IBarTooltip;
}
export declare const initialBarMargin: IChartMargin;
export {};
//# sourceMappingURL=type.d.ts.map