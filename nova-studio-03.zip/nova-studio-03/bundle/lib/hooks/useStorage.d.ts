export type UseStorageOptions = {
    key: string;
    source: 'local' | 'session';
};
export type StorageValueType<T> = T | null;
export type UseStorageReturnType<T> = {
    newValue: StorageValueType<T>;
    oldValue: StorageValueType<T>;
};
declare const useStorage: <T>({ key, source }: UseStorageOptions) => UseStorageReturnType<T>;
export default useStorage;
//# sourceMappingURL=useStorage.d.ts.map