import type { Now } from '..';
/**
 * Hook: useNow
 *
 * Returns a live, real-time breakdown of the current date and time.
 * Uses requestAnimationFrame (not setInterval or setTimeout) to update smoothly.
 *
 * @returns {Now} An object containing year, month, day, hours, minutes, seconds, and milliseconds.
 */
declare const useNow: () => Now;
export default useNow;
//# sourceMappingURL=useNow.d.ts.map