import type { RefObject, Ref } from 'react';
import type { ComputedStyles } from '..';
export type UseComputedStylesOptions = {
    /**
     * Optional external dependencies for the effect
     */
    effectDeps?: any[];
};
/**
 * Return type for the `useComputedStyles` hook.
 * @template T - Type of the target HTML element (defaults to HTMLDivElement).
 */
export type UseComputedStylesReturnType<T extends HTMLElement = HTMLDivElement> = {
    /**
     * The actual DOM element instance that the ref is attached to.
     * It will be `null` until the element mounts.
     */
    node: T | null;
    /**
     * A React ref that should be attached to the target DOM element.
     */
    ref: Ref<T> | RefObject<T>;
    /**
     * Computed styles of the referenced element, updated reactively.
     */
    styles: ComputedStyles;
};
/**
 * A custom React hook that observes and returns the computed styles of a DOM element in real-time.
 *
 * It uses a combination of:
 * - `ResizeObserver` for size changes,
 * - `MutationObserver` for DOM mutations,
 * - Media queries and window events for environmental changes. (resize, scroll, reset, matchMedia-change)
 *
 * The hook returns a `ref` to be attached to a DOM element and the latest computed styles for that element.
 *
 * @param options - Contains parameters that will affect Hook's operation.
 * @template T - The type of HTML element being observed (e.g., HTMLDivElement).
 * @returns {UseComputedStylesReturnType<T>} An object containing the ref and up-to-date computed styles.
 */
declare const useComputedStyles: <T extends HTMLElement = HTMLDivElement>(options?: UseComputedStylesOptions) => UseComputedStylesReturnType<T>;
export default useComputedStyles;
//# sourceMappingURL=useComputedStyles.d.ts.map