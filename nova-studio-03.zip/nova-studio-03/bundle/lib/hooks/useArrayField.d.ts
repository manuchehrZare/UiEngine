import type { Control, UseFieldArrayReturn } from 'react-hook-form';
export interface IUseArrayFieldProps {
    control: Control;
    key?: any;
    name: any;
}
declare const useArrayField: ({ control, name, key }: IUseArrayFieldProps) => UseFieldArrayReturn;
export default useArrayField;
//# sourceMappingURL=useArrayField.d.ts.map