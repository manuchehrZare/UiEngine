
// ... (same as before)

// REPRO WITH FIX
// MOCK DATA AND RUNNER
const parseBounds = (str: string) => {
    if (!str) return { x: 0, y: 0, width: 0, height: 0 };
    const [x, y, width, height] = str.split(',').map(Number);
    return { x, y, width, height };
};

const mockUserJson = {
    id: "Page",
    type: "Page",
    bounds: { x: 0, y: 0, width: 960, height: 700 }, 
    properties: { pageSize: "960,700", title: "UTC Sunucu Yönetim" },
    children: [
        {
            id: "Page.tbPnMain",
            type: "TabbedPane",
            bounds: parseBounds("10,0,935,645"),
            properties: { bounds: "10,0,935,645" },
            children: [
                {
                    id: "Page.tbPnMain.tbPgServerList",
                    type: "TabPage",
                    bounds: parseBounds("4,4,920,475"),
                    properties: { bounds: "4,4,920,475" },
                    children: []
                },
                {
                    id: "Page.tbPnMain.tbPgCache",
                    type: "TabPage",
                    bounds: parseBounds("1,26,931,616"),
                    properties: { bounds: "1,26,931,616" },
                    children: []
                },
                {
                    id: "Page.tbPnMain.tbFraud",
                    type: "TabPage",
                    bounds: parseBounds("1,26,931,616"),
                    properties: { bounds: "1,26,931,616" },
                    children: []
                }
            ]
        }
    ]
};

console.log("\nRunning nesting logic with fix...");
const nested = nestComponentsByBounds(mockUserJson as ParsedComponent);

const findComponent = (root: ParsedComponent, id: string): ParsedComponent | null => {
    if (root.id === id) return root;
    if (root.children) {
        for (const child of root.children) {
            const found = findComponent(child, id);
            if (found) return found;
        }
    }
    return null;
};

const tabbedPane = findComponent(nested, "Page.tbPnMain");

if (tabbedPane) {
    console.log("\nTabbedPane found:");
    console.log(" - ID:", tabbedPane.id);
    console.log(" - Children count:", tabbedPane.children?.length);
    tabbedPane.children?.forEach(c => {
        console.log("   - Child:", c.id, c.type);
    });
} else {
    console.log("\nTabbedPane NOT found in tree.");
}

