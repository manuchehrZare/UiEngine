import { forwardRef, useRef } from 'react';
import { Scrollbars } from 'react-custom-scrollbars-2';
import { Box, manageClassNames } from '../../..';
import type { ICustomScrollbarProps } from './type';
import { generateClass } from '../../../utils';

const CustomScrollbar = forwardRef<any, ICustomScrollbarProps>(
    (
        {
            children,
            className,
            height,
            width,
            thumbProps,
            trackProps,
            viewProps,
            style,
            onScroll,
            onScrollStart,
            onScrollStop,
            autoHideDuration = 200,
            autoHideTimeout = 1000,
            autoHide = true,
            thickness = 6,
            borderRadius = 3,
            ...rest
        },
        ref,
    ) => {
        const scrollRef: any = useRef(null);
        return (
            <Scrollbars
                ref={ref || scrollRef}
                className={manageClassNames(generateClass('CustomScrollbar'), className)}
                autoHide={autoHide}
                allowFullScreen
                style={{ ...style, height: height, width: width }}
                renderView={(props) => {
                    return (
                        <Box
                            {...props}
                            className={manageClassNames(generateClass('CustomScrollbar-wrapper'))}
                            sx={viewProps?.sx}
                        />
                    );
                }}
                renderThumbVertical={(props) => {
                    return (
                        <Box
                            component="div"
                            className="thumb-vertical"
                            bgcolor={(theme) => theme.palette.primary.light}
                            borderRadius="inherit"
                            {...props}
                            sx={[{ cursor: 'pointer' }, thumbProps?.sx]}
                            zIndex={(theme) => (theme.zIndex as any).appBar}
                        />
                    );
                }}
                renderThumbHorizontal={(props) => {
                    return (
                        <Box
                            component="div"
                            className="thumb-horizontal"
                            bgcolor={(theme) => theme.palette.primary.light}
                            borderRadius="inherit"
                            {...props}
                            sx={[{ cursor: 'pointer' }, thumbProps?.sx]}
                            zIndex={(theme) => (theme.zIndex as any).appBar}
                        />
                    );
                }}
                renderTrackVertical={(props) => {
                    return (
                        <Box
                            component="div"
                            className="track-vertical"
                            borderRadius={borderRadius}
                            width={`${thickness}px !important`}
                            top={2}
                            bottom={2}
                            right={1}
                            {...props}
                            sx={trackProps?.sx}
                            zIndex={(theme) => (theme.zIndex as any).appBar}
                        />
                    );
                }}
                renderTrackHorizontal={(props) => {
                    return (
                        <Box
                            component="div"
                            className="track-horizontal"
                            borderRadius={borderRadius}
                            height={`${thickness}px !important`}
                            width={width}
                            left={2}
                            bottom={1}
                            {...props}
                            sx={trackProps?.sx}
                            zIndex={(theme) => (theme.zIndex as any).appBar}
                        />
                    );
                }}
                onScroll={(e) => {
                    onScroll?.(e, ref ? (ref as any)?.current?.getValues() : scrollRef?.current?.getValues());
                }}
                onScrollStart={() => {
                    onScrollStart?.(ref ? (ref as any)?.current?.getValues() : scrollRef?.current?.getValues());
                }}
                onScrollStop={() => {
                    onScrollStop?.(ref ? (ref as any)?.current?.getValues() : scrollRef?.current?.getValues());
                }}
                autoHideDuration={autoHideDuration}
                autoHideTimeout={autoHideTimeout}
                {...rest}>
                {children}
            </Scrollbars>
        );
    },
);

CustomScrollbar.displayName = 'CustomScrollbar';

export default CustomScrollbar;
