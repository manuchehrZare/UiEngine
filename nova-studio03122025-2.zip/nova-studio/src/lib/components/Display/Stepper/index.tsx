import { useState, useImperativeHandle, forwardRef, Children, useEffect } from 'react';
import type { Theme } from '@mui/material';
import { Stepper as MuiStepper, Step, StepContent, StepLabel } from '@mui/material';
import { Button, Box, useStorage } from '../../..';
import type { DesignType } from '../../../utils';
import {
    constants,
    generateClass,
    getComponentDesignProperty,
    getProviderTheme,
    manageClassNames,
    useTranslation,
} from '../../../utils';
import type { IStepperProps, IStepStepperRef } from './type';
import ThemeProvider from '../../App/ThemeProvider';

const Stepper = forwardRef<IStepStepperRef, IStepperProps>(
    (
        {
            stepItems,
            onFinish,
            showButtons = true,
            onStepChange,
            onCompleted,
            design,
            sx,
            className,
            orientation = 'horizontal',
            ...rest
        },
        ref,
    ) => {
        const { t, locale } = useTranslation();
        const [activeStep, setActiveStep] = useState(0);
        const [isCompleted, setIsCompleted] = useState(false);
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });

        const isLastStep = activeStep === stepItems.length - 1;
        const isFirstStep = activeStep === 0;

        const handleNext = async () => {
            const currentStep = stepItems[activeStep];
            if (currentStep.onNext) {
                const result = await currentStep.onNext();
                if (!result) return;
            }

            if (isLastStep) {
                onFinish?.();
                onCompleted?.();
                setIsCompleted(true);
            } else {
                setActiveStep((prev) => prev + 1);
            }
        };

        const handlePrev = () => {
            const currentStep = stepItems[activeStep];
            currentStep.onBack?.();
            setActiveStep((x) => Math.max(0, x - 1));
        };

        const reset = () => {
            setActiveStep(0);
            setIsCompleted(false);
        };

        const goToStep = (index: number) => {
            if (index >= 0 && index < stepItems.length) {
                setActiveStep(index);
            }
        };

        useImperativeHandle(ref, () => ({
            next: handleNext,
            prev: handlePrev,
            goToStep,
            completed: () => {
                onFinish?.();
                onCompleted?.();
                setIsCompleted(true);
            },
            reset,
        }));

        const renderStepContent = () => {
            const content = stepItems[activeStep]?.content;

            if (!content) return null;

            return (
                <>
                    <Box className={generateClass('step-content')}>{content}</Box>
                    {showButtons && (
                        <Box className={generateClass('step-buttons')}>
                            {!isFirstStep && (
                                <Button
                                    className={generateClass('step-prev-button')}
                                    onClick={handlePrev}
                                    text={t(locale.buttons.prev)}
                                    variant="outlined"
                                />
                            )}
                            <Button
                                text={isLastStep ? t(locale.buttons.finish) : t(locale.buttons.next)}
                                onClick={handleNext}
                                variant={isLastStep ? 'contained' : 'outlined'}
                                className={
                                    isLastStep ? generateClass('step-finish-button') : generateClass('step-next-button')
                                }
                            />
                        </Box>
                    )}
                </>
            );
        };

        useEffect(() => {
            onStepChange?.(activeStep, isFirstStep, isLastStep);
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [activeStep]);

        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <Box
                    className={manageClassNames(
                        generateClass('stepper'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                        className,
                    )}
                    sx={sx}>
                    <MuiStepper activeStep={activeStep} orientation={orientation} {...rest}>
                        {Children.toArray(
                            stepItems.map((step, index) => (
                                <Step className={generateClass('step')} completed={isCompleted || index < activeStep}>
                                    <StepLabel className={generateClass('stepLabel')}>{step.label}</StepLabel>
                                    <StepContent>
                                        {orientation === 'vertical' && index === activeStep && renderStepContent()}
                                    </StepContent>
                                </Step>
                            )),
                        )}
                    </MuiStepper>
                    {orientation === 'horizontal' && renderStepContent()}
                </Box>
            </ThemeProvider>
        );
    },
);

export default Stepper;
