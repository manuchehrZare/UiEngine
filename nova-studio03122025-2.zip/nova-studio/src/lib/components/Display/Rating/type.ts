import type { RatingProps } from '@mui/material';
import type { ICommonFieldProps } from '../../Form/commonTypes';

export interface IRatingProps
    extends Pick<
            RatingProps,
            | 'className'
            | 'color'
            | 'defaultValue'
            | 'disabled'
            | 'emptyIcon'
            | 'highlightSelectedOnly'
            | 'icon'
            | 'max'
            | 'precision'
            | 'ref'
            | 'sx'
            | 'size'
        >,
        Pick<ICommonFieldProps, 'name' | 'readOnly' | 'id' | 'design'> {
    color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
    value?: number;
}
