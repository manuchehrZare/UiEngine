import type { FC } from 'react';
import { memo } from 'react';
import Progress from '../Progress';
import type { ILoadingModalProps } from './type';
import { generateClass, manageClassNames } from '../../../utils';
import { MuiLoadingModalSxProps } from './style';
import { Box } from '../../..';
import { Typography } from '@mui/material';

const LoadingModal: FC<ILoadingModalProps> = ({ text, sx, className, ...rest }) => {
    return (
        <Box
            className={manageClassNames(generateClass('LoadingModal'), className)}
            sx={{
                ...(MuiLoadingModalSxProps() as any),
                ...sx,
            }}
            component="div"
            {...rest}>
            <Box className={generateClass('LoadingModal-progress')}>
                <Progress type="circular" rounded color={(theme) => theme.palette.green.main} />
            </Box>
            <Typography className={generateClass('LoadingModal-text')} variant="caption">
                {text}
            </Typography>
        </Box>
    );
};

export default memo(LoadingModal);
