import type { PopoverProps } from '@mui/material/Popover';
import Popover from '@mui/material/Popover';
import { usePopupState, bindPopover, bindTrigger, bindHover } from 'material-ui-popup-state/hooks';
import HoverPopover from 'material-ui-popup-state/HoverPopover';
import type { FC } from 'react';
import { useEffect, cloneElement, memo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { DesignType } from '../../..';
import { constants, useIsFirstRender, useStorage } from '../../..';
import ThemeProvider from '../../App/ThemeProvider';
import Tooltip from '../Tooltip';
import type { IPopupProps } from './type';
import { defaultAnchorPosition, PopupAnchorTriggerEnum } from './type';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const localId = uuidv4();

const Popup: FC<IPopupProps> = ({
    id,
    children,
    anchorEl,
    anchorTrigger = 'click',
    sx,
    onClose,
    onOpen,
    tooltip,
    design,
    popupPosition = defaultAnchorPosition,
    tooltipPosition = 'bottom',
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const isFirstRender = useIsFirstRender();
    const popupState = usePopupState({ variant: 'popover', popupId: id || localId });

    useEffect(() => {
        if (popupState.isOpen) {
            onOpen?.();
        } else {
            !isFirstRender && onClose?.();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [popupState.isOpen]);

    const getTriggerEvent = () => {
        switch (anchorTrigger) {
            case PopupAnchorTriggerEnum.HOVER:
                return bindHover;
            case PopupAnchorTriggerEnum.CLICK:
                return bindTrigger;
            default:
                return bindTrigger;
        }
    };

    const renderAnchorEl = () => {
        const trigger = getTriggerEvent();
        return cloneElement(anchorEl, {
            ...trigger(popupState),
        });
    };

    const renderElement = () => {
        if (tooltip) {
            return (
                <Tooltip
                    design={getComponentDesignProperty(design, storageDesign.newValue)}
                    title={tooltip}
                    placement={tooltipPosition}>
                    {renderAnchorEl()}
                </Tooltip>
            );
        }

        return renderAnchorEl();
    };

    const popoverProps: PopoverProps = {
        ...bindPopover(popupState),
        ...popupPosition,
        PaperProps: {
            sx,
        },
    };

    const Component = {
        [PopupAnchorTriggerEnum.CLICK]: <Popover {...popoverProps}>{children}</Popover>,
        [PopupAnchorTriggerEnum.HOVER]: <HoverPopover {...popoverProps}>{children}</HoverPopover>,
    };

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {renderElement()}
            {Component[anchorTrigger]}
        </ThemeProvider>
    );
};

export default memo(Popup);
