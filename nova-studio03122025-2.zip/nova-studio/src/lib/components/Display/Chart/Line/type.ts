import type { IChartCommonProps, IChartMargin } from '../commonTypes';
import type { AxisDomain } from 'recharts/types/util/types';
import type { IBarChartData } from '../Bar/type';

interface IAxisLabelData {
    color?: string;
    fontSize?: number;
    xLabel?: string;
    yLabel?: string;
}

interface IAxis {
    label?: IAxisLabelData;
    lineColor?: string;
    xLine?: boolean;
    xOrientation?: 'top' | 'bottom';
    xUnit?: string;
    yLine?: boolean;
    yOrientation?: 'left' | 'right';
    yUnit?: string | [string, string];
}

interface ITickProps {
    x?: number;
    y?: number;
}

export interface ITick {
    angle?: ITickProps;
    color?: string;
    equivalentPoints?: number[];
    fontSize?: number;
    fontWeight?: string | number;
    line?: boolean;
    margin?: ITickProps;
    points?: number[];
    width?: ITickProps;
    xView?: boolean;
    yView?: boolean;
}

interface ICartesianGrid {
    fill?: string;
    horizontal?: boolean;
    strokeDasharray?: string | number;
    vertical?: boolean;
}

interface IReferenceLine {
    labelX?: string;
    labelY?: string;
    strokeX?: string;
    strokeY?: string;
    x?: string;
    y?: string;
}

export interface ILineChartData extends IBarChartData {}

export interface ILineChartProps extends IChartCommonProps {
    axis?: IAxis;
    data: any[];
    grid?: boolean | ICartesianGrid;
    layout?: 'horizontal' | 'vertical';
    lineLabels?: string[];
    lineStrokeDash?: object | any;
    range?: AxisDomain;
    referenceLine?: IReferenceLine;
    tick?: ITick;
}

export const initialLineMargin: IChartMargin = {
    bottom: 5,
    left: 20,
    right: 30,
    top: 5,
};
