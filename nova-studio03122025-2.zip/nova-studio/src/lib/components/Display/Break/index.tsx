import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IBoxProps } from '../../..';
import { Box, manageClassNames } from '../../..';
import { generateClass } from '../../../utils';

export interface IBreakProps
    extends Pick<IBoxProps, 'display' | 'hidden' | 'id' | 'ref' | 'style' | 'sx' | 'visibility'> {}

const Break: FC<IBreakProps> = forwardRef((props, ref) => {
    return (
        <Box className={manageClassNames(generateClass('Break'))} ref={ref} component="div" width="100%" {...props} />
    );
});

export default Break;
