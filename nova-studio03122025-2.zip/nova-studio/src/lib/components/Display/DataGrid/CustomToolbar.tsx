import { Box, MenuItem } from '@mui/material';
import type { GridExportMenuItemProps } from '@mui/x-data-grid-pro';
import {
    GridToolbarColumnsButton,
    GridToolbarContainer,
    GridToolbarDensitySelector,
    GridToolbarExportContainer,
    GridToolbarFilterButton,
    GridToolbarQuickFilter,
} from '@mui/x-data-grid-pro';
import type { GridApiPro } from '@mui/x-data-grid-pro/models/gridApiPro';
import { isEmpty } from 'lodash';
import type { Dispatch, FC, JSX, MutableRefObject, ReactNode, SetStateAction } from 'react';
import type { FileExtentionsEnum } from '../../../utils';
import { MessageTypeEnum, excelToJson, exportTable, message, useTranslation } from '../../../utils';
import Divider from '../Divider';
import Label from '../Label';
import type { DataGridColDef, ToolbarPropsType } from './type';
import { rowUniqueKey } from './type';
import { UploadFile } from '@mui/icons-material';

interface IImportOptions {
    fileType: `${Extract<
        FileExtentionsEnum,
        FileExtentionsEnum.XLSX | FileExtentionsEnum.XLS | FileExtentionsEnum.CSV
    >}`;
}

interface ICustomToolbarProps {
    apiRef: MutableRefObject<GridApiPro>;
    columns: DataGridColDef[];
    setRowsData: Dispatch<SetStateAction<readonly any[]>>;
    toolbarProps?: ToolbarPropsType;
}

interface ICustomMenuItemContainerProps extends GridExportMenuItemProps<any> {
    children: ReactNode;
    clickable?: boolean;
    importOptions?: IImportOptions;
}

const CustomToolbar: FC<ICustomToolbarProps> = ({ columns, setRowsData, apiRef, toolbarProps }): JSX.Element => {
    const { t, locale } = useTranslation();

    const internalToolbarProps: ToolbarPropsType | undefined = {
        ...toolbarProps,
        ...{
            ...(toolbarProps?.showFile !== false && {
                fileOptions: {
                    ...toolbarProps?.fileOptions,
                    import:
                        typeof toolbarProps?.fileOptions?.import === 'undefined'
                            ? false
                            : toolbarProps?.fileOptions?.import,
                    export:
                        typeof toolbarProps?.fileOptions?.export === 'undefined'
                            ? true
                            : toolbarProps?.fileOptions?.export,
                },
            }),
        },
    };

    const visibleColumns = apiRef.current
        .getVisibleColumns()
        .map((item) => item.field)
        .filter((item) =>
            internalToolbarProps?.showFile !== false && typeof internalToolbarProps?.fileOptions?.export !== 'boolean'
                ? !internalToolbarProps?.fileOptions?.export?.hiddenColumns?.includes(item)
                : item,
        );

    const columnsData = columns
        .map((item) => {
            return {
                field: item?.field,
                headerName: item?.headerName,
                type: item?.type,
            };
        })
        .filter((item) => visibleColumns.includes(item.field) && (item.type as any) !== 'counter');

    const columnsOrder = apiRef.current
        .getAllColumns()
        .map((item) => {
            return { field: item.field, headerName: item.headerName };
        })
        .filter((item) => columnsData.map((columnsDataItem) => columnsDataItem.field).includes(item.field));

    const exportData = apiRef?.current
        ?.getDataAsCsv({
            includeHeaders: false,
            delimiter: ';',
            getRowsToExport: (params) => params.apiRef.current?.getAllRowIds(),
            fields: columnsOrder.map((item) => item.field),
        })
        .split('\r\n')
        .map((item) => {
            const obj: any = {};
            columnsOrder.forEach((columnsItem, index) => (obj[`${columnsItem.field}`] = item.split(';')[index]));
            return obj;
        });

    const getExportData = () =>
        internalToolbarProps?.showFile !== false &&
        typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
        internalToolbarProps?.fileOptions?.export?.onExport
            ? internalToolbarProps?.fileOptions?.export?.onExport(exportData)
            : exportData;

    const CustomMenuItemContainer = (props: ICustomMenuItemContainerProps): JSX.Element => {
        const { hideMenu, children, clickable, importOptions } = props;
        return (
            <Box
                onClick={() => {
                    clickable && !importOptions && hideMenu?.();
                    importOptions && (document?.getElementsByName(`import${importOptions.fileType}`)[0] as any).click();
                }}>
                {children}
                {importOptions && (
                    <input
                        name={`import${importOptions.fileType}`}
                        type="file"
                        onChange={(e) => {
                            const file = (e?.target as HTMLInputElement)?.files?.[0];
                            if (file) {
                                excelToJson(file, {
                                    accept: [importOptions.fileType],
                                })
                                    ?.then((data) => {
                                        const importData = data[0].sheetRows.map((item) => {
                                            const obj: any = {};
                                            let counter = 0;
                                            item.forEach((_, index) => {
                                                if (counter === 0 && (columns[index].type as any) === 'counter')
                                                    counter++;
                                                obj[`${columns[index + counter]?.field || index}`] =
                                                    item.find((itemValue) => itemValue.cellIndex === index)?.value ||
                                                    '';
                                            });
                                            return obj;
                                        });
                                        importData.shift();
                                        setRowsData(
                                            (internalToolbarProps?.showFile !== false &&
                                                !!internalToolbarProps?.fileOptions?.import &&
                                                typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                                                internalToolbarProps?.fileOptions?.import
                                                    ?.onImport?.(importData)
                                                    ?.map((item: any, index: any) => {
                                                        return { ...item, [`${rowUniqueKey}`]: index };
                                                    })) ||
                                                importData.map((item, index) => {
                                                    return { ...item, [`${rowUniqueKey}`]: index };
                                                }),
                                        );
                                        hideMenu?.();
                                    })
                                    .catch((err) => {
                                        message({
                                            message: err.description || t(locale.contents.errorDuringFileTransport),
                                            variant: MessageTypeEnum.error,
                                        });
                                    });
                            }
                        }}
                        accept={`.${importOptions.fileType}`}
                        style={{
                            display: 'none',
                        }}
                    />
                )}
            </Box>
        );
    };

    const CustomFileButton = (): JSX.Element => {
        return (
            <GridToolbarExportContainer slotProps={{ button: { startIcon: <UploadFile /> } }}>
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.import === true ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            internalToolbarProps?.fileOptions?.import?.showCSV !== false) ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            internalToolbarProps?.fileOptions?.import?.showXLS !== false) ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            internalToolbarProps?.fileOptions?.import?.showXLSX !== false)) && (
                        <CustomMenuItemContainer>
                            <Label
                                text={t(locale.contents.import)}
                                sx={{ px: 2, py: 0.75 }}
                                color={(theme) => theme.palette.common.black}
                            />
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.import === true ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            internalToolbarProps?.fileOptions?.import?.showCSV !== false)) && (
                        <CustomMenuItemContainer clickable importOptions={{ fileType: 'csv' }}>
                            <MenuItem>{t(locale.contents.csv)}</MenuItem>
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.import === true ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            internalToolbarProps?.fileOptions?.import?.showXLS !== false)) && (
                        <CustomMenuItemContainer clickable importOptions={{ fileType: 'xls' }}>
                            <MenuItem>{t(locale.contents.xls)}</MenuItem>
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.import === true ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            internalToolbarProps?.fileOptions?.import?.showXLSX !== false)) && (
                        <CustomMenuItemContainer clickable importOptions={{ fileType: 'xlsx' }}>
                            <MenuItem>{t(locale.contents.xlsx)}</MenuItem>
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.import === true ||
                        (typeof internalToolbarProps?.fileOptions?.import !== 'boolean' &&
                            typeof internalToolbarProps?.fileOptions?.import !== 'undefined' &&
                            !isEmpty(internalToolbarProps?.fileOptions?.import) &&
                            (internalToolbarProps?.fileOptions?.import?.showCSV !== false ||
                                internalToolbarProps?.fileOptions?.import?.showXLS !== false ||
                                internalToolbarProps?.fileOptions?.import?.showXLSX !== false) &&
                            (internalToolbarProps?.fileOptions?.export === true ||
                                (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                                    typeof internalToolbarProps?.fileOptions?.export !== 'undefined' &&
                                    (internalToolbarProps?.fileOptions?.export?.showCSV !== false ||
                                        internalToolbarProps?.fileOptions?.export?.showXLS !== false ||
                                        internalToolbarProps?.fileOptions?.export?.showXLSX !== false)))) ||
                        (typeof internalToolbarProps.fileOptions?.export !== 'boolean' &&
                            typeof internalToolbarProps.fileOptions?.export !== 'undefined' &&
                            (internalToolbarProps?.fileOptions?.export?.showCSV !== false ||
                                internalToolbarProps?.fileOptions?.export?.showXLS !== false ||
                                internalToolbarProps?.fileOptions?.export?.showXLSX !== false) &&
                            typeof internalToolbarProps.fileOptions?.import !== 'boolean' &&
                            typeof internalToolbarProps.fileOptions?.import !== 'undefined' &&
                            (internalToolbarProps?.fileOptions?.import?.showCSV !== false ||
                                internalToolbarProps?.fileOptions?.import?.showXLS !== false ||
                                internalToolbarProps?.fileOptions?.import?.showXLSX !== false))) && (
                        <CustomMenuItemContainer>
                            <Divider />
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.export === true ||
                        (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                            internalToolbarProps?.fileOptions?.export?.showCSV !== false) ||
                        (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                            internalToolbarProps?.fileOptions?.export?.showXLS !== false) ||
                        (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                            internalToolbarProps?.fileOptions?.export?.showXLSX !== false)) && (
                        <CustomMenuItemContainer>
                            <Label
                                text={t(locale.contents.export)}
                                sx={{ px: 2, py: 0.75 }}
                                color={(theme) => theme.palette.common.black}
                            />
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.export === true ||
                        (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                            internalToolbarProps?.fileOptions?.export?.showCSV !== false)) && (
                        <CustomMenuItemContainer clickable>
                            <MenuItem
                                onClick={() =>
                                    exportTable({
                                        data: getExportData(),
                                        columns: columnsOrder,
                                        fileName:
                                            (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                                                internalToolbarProps?.fileOptions?.export?.fileName) ||
                                            `${t(locale.contents.csv)}_${t(locale.contents.file)}`,
                                        fileExtension: 'csv',
                                        csvSeparator: ';',
                                    })
                                }>
                                {t(locale.contents.csv)}
                            </MenuItem>
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.export === true ||
                        (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                            internalToolbarProps?.fileOptions?.export?.showXLS !== false)) && (
                        <CustomMenuItemContainer clickable>
                            <MenuItem
                                onClick={() =>
                                    exportTable({
                                        data: getExportData(),
                                        columns: columnsOrder,
                                        fileName:
                                            (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                                                internalToolbarProps?.fileOptions?.export?.fileName) ||
                                            `${t(locale.contents.xls)}_${t(locale.contents.file)}`,
                                        fileExtension: 'xls',
                                    })
                                }>
                                {t(locale.contents.xls)}
                            </MenuItem>
                        </CustomMenuItemContainer>
                    )}
                {internalToolbarProps?.showFile !== false &&
                    (internalToolbarProps?.fileOptions?.export === true ||
                        (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                            internalToolbarProps?.fileOptions?.export?.showXLSX !== false)) && (
                        <CustomMenuItemContainer clickable>
                            <MenuItem
                                onClick={() => {
                                    exportTable({
                                        data: getExportData(),
                                        columns: columnsOrder,
                                        fileName:
                                            (typeof internalToolbarProps?.fileOptions?.export !== 'boolean' &&
                                                internalToolbarProps?.fileOptions?.export?.fileName) ||
                                            `${t(locale.contents.xlsx)}_${t(locale.contents.file)}`,
                                        fileExtension: 'xlsx',
                                    });
                                }}>
                                {t(locale.contents.xlsx)}
                            </MenuItem>
                        </CustomMenuItemContainer>
                    )}
            </GridToolbarExportContainer>
        );
    };

    return (
        <GridToolbarContainer>
            {internalToolbarProps?.showColumns !== false && <GridToolbarColumnsButton />}
            {internalToolbarProps?.showFilter !== false && <GridToolbarFilterButton />}
            {internalToolbarProps?.showDensity !== false && <GridToolbarDensitySelector />}
            {internalToolbarProps?.showFile !== false &&
                (internalToolbarProps.fileOptions?.export === true ||
                    internalToolbarProps.fileOptions?.import === true ||
                    (typeof internalToolbarProps.fileOptions?.export !== 'boolean' &&
                        typeof internalToolbarProps.fileOptions?.export !== 'undefined' &&
                        (internalToolbarProps?.fileOptions?.export?.showCSV !== false ||
                            internalToolbarProps?.fileOptions?.export?.showXLS !== false ||
                            internalToolbarProps?.fileOptions?.export?.showXLSX !== false)) ||
                    (typeof internalToolbarProps.fileOptions?.import !== 'boolean' &&
                        typeof internalToolbarProps.fileOptions?.import !== 'undefined' &&
                        !isEmpty(internalToolbarProps.fileOptions?.import) &&
                        (internalToolbarProps?.fileOptions?.import?.showCSV !== false ||
                            internalToolbarProps?.fileOptions?.import?.showXLS !== false ||
                            internalToolbarProps?.fileOptions?.import?.showXLSX !== false))) && <CustomFileButton />}
            {internalToolbarProps.showQuickFilter && (
                <GridToolbarQuickFilter
                    sx={{ ml: { md: 'auto' } }}
                    debounceMs={
                        internalToolbarProps.quickFilterDebounce ? internalToolbarProps.quickFilterDebounce : 500
                    } // Pass debounceMs directly
                />
            )}
        </GridToolbarContainer>
    );
};

export default CustomToolbar;
