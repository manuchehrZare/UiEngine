import { TableBody as MuiTableBody } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { ITableBodyProps } from './type';

const TableBody: FC<ITableBodyProps> = forwardRef(({ children, ...rest }: ITableBodyProps, ref) => {
    return (
        <MuiTableBody ref={ref} {...rest}>
            {children}
        </MuiTableBody>
    );
});

export default TableBody;
