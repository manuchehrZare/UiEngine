import type { FC } from 'react';
import { memo } from 'react';
import { Box, CustomScrollbar, useTitle } from '../../lib';
import type { ILayout } from './type';
import Sidebar from './Sidebar';
import Header from './Header';
import { useLocation } from 'react-router-dom';
import { camelCase, drop, upperFirst } from 'lodash';

const Layout: FC<ILayout> = ({ children, showSidebar = true }: ILayout) => {
    const { pathname } = useLocation();
    const baseUrl = '/';
    const splittedPath = drop(pathname.split(baseUrl));
    const pageTitle: string =
        pathname !== baseUrl && splittedPath.length
            ? splittedPath.map((item) => upperFirst(camelCase(item))).join(' - ')
            : '';

    useTitle(`${import.meta.env.VITE_APP_TITLE}${pageTitle ? ` | ${pageTitle}` : ''}`);
    return (
        <>
            <Header />
            {showSidebar && <Sidebar />}
            <Box
                component="div"
                sx={{
                    position: 'relative',
                    height: 'calc(100vh - 48px)',
                    width: showSidebar ? 'calc(100% - 216px)' : '100%',
                    left: showSidebar ? 216 : 0,
                    top: 48,
                    // background: 'white',
                }}>
                <CustomScrollbar height="100%">
                    <Box
                        component="div"
                        id="contentRoot"
                        sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            minHeight: '100%',
                            height: '100%',
                            p: 2,
                        }}>
                        {children || null}
                    </Box>
                </CustomScrollbar>
            </Box>
        </>
    );
};

export { Header, Sidebar };
export default memo(Layout);
