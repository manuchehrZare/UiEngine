import { menuData } from './_menu';

let hierarchy: string[] = [];
const recursiveParentControl = (parentId: number) => {
    const menuItem = menuData.find((item) => item.id === parentId);
    if (menuItem) {
        hierarchy.push(menuItem.title);
        menuItem.parentId && recursiveParentControl(menuItem.parentId);
    }
};

export const generateSideHierarchy = (title: string, parentId?: number): string => {
    hierarchy = [];
    if (parentId) {
        recursiveParentControl(parentId);
        return hierarchy.length > 0 ? `${hierarchy.reverse().join('/')}/${title}` : title;
    }
    return title;
};
