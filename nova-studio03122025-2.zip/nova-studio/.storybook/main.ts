import type { StorybookConfig } from '@storybook/react-vite';

const config: StorybookConfig = {
    stories: ['../src/**/*.mdx', '../src/**/*.stories.@(js|jsx|ts|tsx)'],
    staticDirs: ['../public'],
    addons: ['@storybook/addon-docs', '@storybook/addon-links'],
    framework: {
        name: '@storybook/react-vite',
        options: {},
    },
    docs: {},
    async viteFinal(viteConfig: any) {
        viteConfig.define = {
            ...viteConfig.define,
            'import.meta.env.NODE_ENV': JSON.stringify('development'),
            'import.meta.env.VITE_APP_ABORT_TIME': JSON.stringify('10000'),
            'import.meta.env.VITE_APP_NAME': JSON.stringify('SekerUI Library'),
            'import.meta.env.VITE_APP_SHORT_NAME': JSON.stringify('SekerUI'),
        };

        return viteConfig;
    },
};

export default config;
