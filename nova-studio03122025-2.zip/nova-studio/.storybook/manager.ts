import { addons } from 'storybook/manager-api';
import { create } from 'storybook/theming';

const theme = create({
    base: 'light',
    appBorderRadius: 10,
    inputBorderRadius: 10,
    brandTitle: 'Şekerbank',
    brandImage: '/images/sekerbank.png',
    brandTarget: '_self',
});

addons.setConfig({
    theme,
    panelPosition: 'bottom',
    sidebar: { showRoots: true },
    toolbar: {
        title: { hidden: true },
        'storybook/background': { hidden: true },
        'storybook/outline': { hidden: true },
        'storybook/viewport': { hidden: true },
    },
});
