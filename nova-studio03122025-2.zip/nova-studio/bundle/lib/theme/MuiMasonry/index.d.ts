import type { Components } from '@mui/material';
export declare const MuiMasonryTheme: Components;
//# sourceMappingURL=index.d.ts.map