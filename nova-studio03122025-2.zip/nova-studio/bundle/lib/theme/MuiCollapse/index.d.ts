import type { Components } from '@mui/material';
export declare const MuiCollapseTheme: Components;
//# sourceMappingURL=index.d.ts.map