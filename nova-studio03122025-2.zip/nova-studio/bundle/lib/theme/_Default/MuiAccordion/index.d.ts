import type { Components } from '@mui/material';
export declare const MuiAccordionTheme: Components;
//# sourceMappingURL=index.d.ts.map