import type { Components } from '@mui/material';
export declare const MuiDividerTheme: Components;
//# sourceMappingURL=index.d.ts.map