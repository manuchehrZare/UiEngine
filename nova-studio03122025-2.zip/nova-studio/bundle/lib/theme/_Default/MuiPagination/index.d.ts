import type { Components } from '@mui/material';
export declare const MuiPaginationTheme: Components;
//# sourceMappingURL=index.d.ts.map