import type { Components } from '@mui/material';
export declare const MuiDataGridTheme: Components;
//# sourceMappingURL=index.d.ts.map