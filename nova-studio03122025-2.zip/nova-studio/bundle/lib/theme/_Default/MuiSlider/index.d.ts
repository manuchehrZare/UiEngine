import type { Components } from '@mui/material';
export declare const MuiSliderTheme: Components;
//# sourceMappingURL=index.d.ts.map