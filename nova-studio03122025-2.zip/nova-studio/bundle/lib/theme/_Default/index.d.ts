import type { Components } from '@mui/material';
declare const ComponentsTheme: Components;
export default ComponentsTheme;
//# sourceMappingURL=index.d.ts.map