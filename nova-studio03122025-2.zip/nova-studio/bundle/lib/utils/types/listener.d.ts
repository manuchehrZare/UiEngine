type SharedListenerEventMapFor<T> = T extends Window ? WindowEventMap : T extends Document ? DocumentEventMap : T extends HTMLElement ? HTMLElementEventMap : T extends MediaQueryList ? {
    change: MediaQueryListEvent;
} : Record<string, Event>;
type SharedListenerEventType<T> = Extract<keyof SharedListenerEventMapFor<T>, string>;
type SharedListenerTypedEventCallback<T, K extends SharedListenerEventType<T>> = (event: SharedListenerEventMapFor<T>[K]) => void;
interface SharedListenerOptions {
    capture?: boolean;
    once?: boolean;
    passive?: boolean;
}
declare class SharedEventListener {
    private listeners;
    add<T extends EventTarget, K extends SharedListenerEventType<T>>(source: T, event: K, callback: SharedListenerTypedEventCallback<T, K>, options?: SharedListenerOptions): void;
    remove<T extends EventTarget, K extends SharedListenerEventType<T>>(source: T, event: K, callback: SharedListenerTypedEventCallback<T, K>): void;
}
export declare const sharedEventListener: SharedEventListener;
export {};
//# sourceMappingURL=listener.d.ts.map