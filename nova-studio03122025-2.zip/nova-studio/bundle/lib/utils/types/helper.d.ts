import type { FieldValues, UseFormReturnType } from '../..';
export type HelperComponentProps = {
    link?: string;
    outerHeight?: number;
};
/**
 * - Requires a property definition named "**formProps**".
 * - **TFormFields** : Represents the form pattern that it can take as a generic.
 * - **RequiredFormPropsKeys** : Represents mandatory key definitions for "**formProps**" in case of getting a type error. If not defined, formProps keys will be treated as optional.
 *
 * @example Example For RequiredFormPropsKeys;
 * interface IProps extends HelperFormProps<IFormValues, 'control' | 'setValue'> {}
 */
export type HelperFormProps<TFormFields extends FieldValues, RequiredFormPropsKeys extends keyof UseFormReturnType<TFormFields> | undefined = undefined> = {
    formProps: Required<Pick<UseFormReturnType<TFormFields>, RequiredFormPropsKeys>> & Partial<Omit<UseFormReturnType<TFormFields>, RequiredFormPropsKeys>>;
};
/**
 * Makes the "optional" fields at each level of the object "required".
 */
export type DeepRequired<T> = {
    [K in keyof T]-?: T[K] extends object ? DeepRequired<T[K]> : T[K];
};
//# sourceMappingURL=helper.d.ts.map