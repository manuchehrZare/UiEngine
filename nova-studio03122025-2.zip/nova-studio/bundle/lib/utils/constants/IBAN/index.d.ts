export declare const IBANFormats: {
    TR: {
        length: number;
        regex: RegExp;
    };
    DE: {
        length: number;
        regex: RegExp;
    };
    GB: {
        length: number;
        regex: RegExp;
    };
    FR: {
        length: number;
        regex: RegExp;
    };
    IT: {
        length: number;
        regex: RegExp;
    };
    ES: {
        length: number;
        regex: RegExp;
    };
    NL: {
        length: number;
        regex: RegExp;
    };
    BE: {
        length: number;
        regex: RegExp;
    };
};
//# sourceMappingURL=index.d.ts.map