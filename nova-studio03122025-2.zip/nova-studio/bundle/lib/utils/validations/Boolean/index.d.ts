import * as yup from 'yup';
import type { IBooleanOptions } from '../type';
import type { FieldValues } from '../../../hooks/useForm';
export declare const booleanValidation: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: IBooleanOptions<T>) => yup.BooleanSchema<boolean | undefined, yup.AnyObject, undefined, "">;
//# sourceMappingURL=index.d.ts.map