/**
 * Returns the keys of an object as an array.
 * @param obj
 * @param intermediate
 * @returns string array
 */
export declare const deepKeysAsArray: <T>(obj: T, intermediate?: boolean) => string[];
/**
 * Returns the keys of an object as an object.
 * @param obj
 * @returns typeof object
 */
export declare const deepKeysAsObject: <T>(obj: T) => Required<T>;
//# sourceMappingURL=index.d.ts.map