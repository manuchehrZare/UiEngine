export declare const queryStringToJSON: (query: string) => object;
export declare const jsonToQueryString: <T extends object>(data: T) => string;
//# sourceMappingURL=index.d.ts.map