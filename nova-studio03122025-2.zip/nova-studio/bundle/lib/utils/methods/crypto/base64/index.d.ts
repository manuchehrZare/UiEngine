import type { FileExtentionsEnum } from '../../../..';
/**
 * Returns the result of whether the data is base64.
 * @param data base64 or not base64 string value.
 * @returns true or false
 */
export declare const isBase64: (data: string) => boolean;
export declare const base64ToDataUri: (base64String: string, sourceType: `${FileExtentionsEnum}`) => string;
export { base64Decryption } from './_decryption';
export { base64Encryption } from './_encryption';
//# sourceMappingURL=index.d.ts.map