import type { Theme, CSSSelectorObjectOrCssVariables } from '../../../../../lib';
import type { CustomPaletteColorOptions } from '../../../../theme/_palette';
export declare enum BgColorEnum {
    Error = "error",
    Info = "info",
    Primary = "primary",
    Secondary = "secondary",
    Success = "success",
    Warning = "warning"
}
export type GetFlashAnimationCSSOptions = {
    bgColor: `${BgColorEnum}`;
    className: string;
    colorTone?: keyof CustomPaletteColorOptions;
    flashing?: boolean;
};
/**
 * @param className specific class name that you can use this method css
 * @param bgColor background color by theme colors
 * @param flashing this makes blink to background
 * @default false
 * @param colorTone tone of background color
 * @returns
 * @description colorTone for error 100, others 200
 */
export declare const getBgColorByClassName: ({ className, bgColor, flashing, colorTone, }: GetFlashAnimationCSSOptions) => CSSSelectorObjectOrCssVariables<Theme>;
//# sourceMappingURL=index.d.ts.map