export { getBgColorByClassName } from './getBgColorByClassName';
export { getComputedStyles } from './getComputedStyles';
export declare const importantStyle: (styleValue: string) => string;
export declare const randomColor: () => string;
/**
 * TYPES
 */
export type { GetFlashAnimationCSSOptions } from './getBgColorByClassName';
export type { ComputedStyles } from './getComputedStyles';
/**
 * ENUMS
 */
export { BgColorEnum } from './getBgColorByClassName';
//# sourceMappingURL=index.d.ts.map