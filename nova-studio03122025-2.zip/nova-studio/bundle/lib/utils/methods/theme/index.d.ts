import type { Theme } from '@mui/material';
export declare const setProviderTheme: (theme: Partial<Theme>) => void;
export declare const getProviderTheme: (theme?: Partial<Theme> | null) => Partial<Theme> | null;
export declare const removeProviderTheme: () => void;
//# sourceMappingURL=index.d.ts.map