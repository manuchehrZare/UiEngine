export { currency } from './currency';
export { numberFormat } from './numberFormat';
export { randomNumber } from './randomNumber';
export declare const isNumeric: (value: string) => boolean;
/**
 * TYPES
 */
export type { INumberFormatOptions } from './numberFormat';
//# sourceMappingURL=index.d.ts.map