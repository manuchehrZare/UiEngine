type RandomNumberOptions = {
    precision?: number;
};
type RandomNumberType = (min: number, max: number, options?: RandomNumberOptions) => number;
/**
 * Generates a cryptographically secure random number.
 *
 * - Returns a number between `min` and `max` (inclusive).
 * - If `precision` is 0 or not provided, it returns an integer.
 * - If `precision` > 0, it returns a floating-point number with the specified number of decimal places.
 * - Uses `window.crypto.getRandomValues()` for secure randomness.
 *
 * @param min - Minimum value (inclusive)
 * @param max - Maximum value (inclusive)
 * @param options - Optional settings (e.g., `precision`)
 * @returns A secure random number between `min` and `max`
 */
export declare const randomNumber: RandomNumberType;
export {};
//# sourceMappingURL=index.d.ts.map