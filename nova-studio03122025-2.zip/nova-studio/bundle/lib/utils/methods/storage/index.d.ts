import type { StorageValueType } from '../../..';
export declare const getLocalStorageItem: <T>(key: string) => StorageValueType<T>;
export declare const setLocalStorageItem: <T>(key: string, value: T) => void;
export declare const removeLocalStorageItem: (key: string) => void;
export declare const getSessionStorageItem: <T>(key: string) => StorageValueType<T>;
export declare const setSessionStorageItem: <T>(key: string, value: T) => void;
export declare const removeSessionStorageItem: (key: string) => void;
//# sourceMappingURL=index.d.ts.map