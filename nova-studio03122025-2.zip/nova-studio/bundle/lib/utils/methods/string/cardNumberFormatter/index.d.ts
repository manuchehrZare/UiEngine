/**
 * It ensures that the card number appears regularly in groups of four characters.
 * @param cardNumberValue It is the card number value to be formatted.
 * @returns Returns the formatted version of the card number value.
 */
export declare const cardNumberFormatter: (cardNumberValue: string) => string;
//# sourceMappingURL=index.d.ts.map