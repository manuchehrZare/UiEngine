export declare enum FileExtentionsEnum {
    CSV = "csv",
    DOC = "doc",
    DOCX = "docx",
    GIF = "gif",
    HTM = "htm",
    HTML = "html",
    JPEG = "jpeg",
    JPG = "jpg",
    PDF = "pdf",
    PNG = "png",
    PPT = "ppt",
    PPTX = "pptx",
    SVG = "svg",
    TXT = "txt",
    WEBP = "webp",
    XLS = "xls",
    XLSX = "xlsx",
    XML = "xml"
}
export declare const mimeTypes: {
    csv: string;
    docx: string;
    doc: string;
    gif: string;
    html: string;
    jpeg: string;
    jpg: string;
    pdf: string;
    png: string;
    pptx: string;
    ppt: string;
    svg: string;
    txt: string;
    webp: string;
    xlsx: string;
    xls: string;
    xml: string;
};
interface IFileAcceptValues {
    CSV: `${Extract<FileExtentionsEnum, FileExtentionsEnum.CSV>}`[];
    EXCEL: `${Extract<FileExtentionsEnum, FileExtentionsEnum.XLS | FileExtentionsEnum.XLSX>}`[];
    HTML: `${Extract<FileExtentionsEnum, FileExtentionsEnum.HTML | FileExtentionsEnum.HTM>}`[];
    JPEG: `${Extract<FileExtentionsEnum, FileExtentionsEnum.JPEG | FileExtentionsEnum.JPG>}`[];
    PDF: `${Extract<FileExtentionsEnum, FileExtentionsEnum.PDF>}`[];
    PNG: `${Extract<FileExtentionsEnum, FileExtentionsEnum.PNG>}`[];
    SVG: `${Extract<FileExtentionsEnum, FileExtentionsEnum.SVG>}`[];
    TXT: `${Extract<FileExtentionsEnum, FileExtentionsEnum.TXT>}`[];
    WORD: `${Extract<FileExtentionsEnum, FileExtentionsEnum.DOC | FileExtentionsEnum.DOCX>}`[];
    XML: `${Extract<FileExtentionsEnum, FileExtentionsEnum.XML>}`[];
}
export declare const FileAcceptValues: IFileAcceptValues;
export declare const FileTypes: Record<keyof IFileAcceptValues, string[]>;
export {};
//# sourceMappingURL=type.d.ts.map