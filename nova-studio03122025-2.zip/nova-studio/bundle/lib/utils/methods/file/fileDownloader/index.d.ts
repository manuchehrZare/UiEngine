import { FileExtentionsEnum } from '../type';
interface IFileDownloaderProps {
    fileName: string;
    source: Blob | string;
    sourceType: `${FileExtentionsEnum}`;
}
export declare const fileDownloader: ({ source, sourceType, fileName }: IFileDownloaderProps) => Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map