/**
 * JavaScript dates can be constructed by passing milliseconds
 * since the Unix epoch (January 1, 1970) example: new Date(12312512312);
 * 1. Subtract number of days between:
 *    Jan 1, 1900 and Jan 1, 1970, plus 2 ("excel leap year bug")
 * 2. Convert to milliseconds.
 *
 * @method getDateFromExcelDate
 * @param  {Number} excelDate
 * @return {Date}
 */
export declare const getDateFromExcelDate: (excelDate: number) => Date;
export declare const getExcelDateFromDate: (date: Date) => number;
//# sourceMappingURL=_excelDate.d.ts.map