import { FileExtentionsEnum } from '../type';
import './_Font_SourceSansPro-Regular-normal.js';
import type { DataGridColDef } from '../../../..';
export interface IExportTableDateOptions {
    dataFormat: string;
    dataKeys: string[];
    expectedFormat: string;
}
export interface IExportTableColumns extends Pick<DataGridColDef, 'field' | 'headerName'> {
}
export interface IExportTableProps<T extends object> {
    columns: IExportTableColumns[];
    csvSeparator?: string;
    data: T[];
    dateOptions?: IExportTableDateOptions;
    fileExtension: `${Extract<FileExtentionsEnum, FileExtentionsEnum.CSV | FileExtentionsEnum.DOC | FileExtentionsEnum.DOCX | FileExtentionsEnum.PDF | FileExtentionsEnum.XLS | FileExtentionsEnum.XLSX>}`;
    fileName: string;
}
export declare const exportTable: <T extends object>({ data, columns, fileName, fileExtension, csvSeparator, dateOptions, }: IExportTableProps<T>) => void;
//# sourceMappingURL=exportTable.d.ts.map