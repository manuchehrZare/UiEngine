import './_Font_SourceSansPro-Regular-normal.js';
interface RGB {
    ch1: number;
    ch2: number;
    ch3: number;
}
interface IText {
    fontColor?: RGB;
    fontSize?: number;
    text: string;
    xPosition?: number;
    yPosition?: number;
}
interface IImage {
    format: string;
    height: number;
    source: any;
    width: number;
    xPosition: number;
    yPosition: number;
}
export interface IExportPDFProps {
    data: string;
    fileName: string;
    fontSize?: number;
    images?: IImage[];
    margin?: number;
    marginLeft?: number;
    marginTop?: number;
    pageCount?: boolean;
    texts?: IText[];
}
export declare const exportHtmlToPDF: ({ data, fileName, texts, images, pageCount, margin, fontSize, marginLeft, marginTop, }: IExportPDFProps) => void;
export {};
//# sourceMappingURL=exportHtmlToPDF.d.ts.map