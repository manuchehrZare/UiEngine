declare const _default: {
    common: {
        verb: {
            entry: string;
            choosing: string;
            mustBe: string;
        };
        required: string;
        matches: string;
        typeError: string;
        min: string;
        max: string;
        length: string;
    };
    length: {
        char: string;
        length: string;
        minLength: string;
        maxLength: string;
    };
    compare: {
        greaterThan: string;
        lessThan: string;
        equal: string;
        notEqual: string;
        greaterThanOrEqual: string;
        lessThanOrEqual: string;
    };
    range: {
        message: string;
    };
    iban: {
        iban: string;
    };
    file: {
        accept: string;
        max: string;
        min: string;
        maxFileSize: string;
    };
};
export default _default;
//# sourceMappingURL=_validations.d.ts.map