declare const _default: {
    home: string;
    notFound: string;
    auth: {
        login: string;
    };
};
export default _default;
//# sourceMappingURL=_pageTitles.d.ts.map