declare const _default: {
    actualSize: string;
    cancel: string;
    finish: string;
    fitPage: string;
    goToFirstPage: string;
    goToLastPage: string;
    menu: string;
    more: string;
    next: string;
    nextPage: string;
    no: string;
    ok: string;
    prev: string;
    preview: string;
    previousPage: string;
    print: string;
    rotate: string;
    save: string;
    suitableWidth: string;
    titles: string;
    yes: string;
    zoomIn: string;
    zoomOut: string;
};
export default _default;
//# sourceMappingURL=_buttons.d.ts.map