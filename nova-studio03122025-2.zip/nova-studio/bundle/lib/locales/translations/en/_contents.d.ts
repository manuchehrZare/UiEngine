declare const _default: {
    PDFFileWasNotTransmitted: string;
    areYouSureYouWantToContinueWithThisProcess: string;
    csv: string;
    errorDuringFileTransport: string;
    export: string;
    failedToLoadPDFFile: string;
    file: string;
    import: string;
    invalidFileType: string;
    loading: string;
    thereWereNoResults: string;
    warning: string;
    xls: string;
    xlsx: string;
};
export default _default;
//# sourceMappingURL=_contents.d.ts.map