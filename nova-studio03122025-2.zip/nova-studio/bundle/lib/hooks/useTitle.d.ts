declare const useTitle: (title: string) => void;
export default useTitle;
//# sourceMappingURL=useTitle.d.ts.map