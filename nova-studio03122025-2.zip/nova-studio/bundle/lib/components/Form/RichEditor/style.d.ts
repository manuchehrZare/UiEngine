import type { SxProps, Theme } from '@mui/material';
import type { IRichEditorProps } from './type';
interface IParams extends Pick<IRichEditorProps, 'design' | 'height' | 'readOnly' | 'disabled' | 'toolbar' | 'variant'> {
    froalaRef?: any;
    labelRef?: any;
}
declare const MuiRichEditorSxProps: ({ design, height, froalaRef, labelRef, disabled, readOnly, toolbar, variant, }: IParams) => SxProps<Theme>;
export default MuiRichEditorSxProps;
//# sourceMappingURL=style.d.ts.map