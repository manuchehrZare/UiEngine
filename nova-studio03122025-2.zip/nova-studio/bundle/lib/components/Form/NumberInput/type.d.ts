import type { TextFieldProps } from '@mui/material';
import type { NumberFormatProps } from 'react-number-format';
import type { ICommonFieldProps } from '../commonTypes';
import type { IInputProps } from '../Input/type';
export declare enum NumberInputReturnValueEnum {
    floatValue = "floatValue",
    formattedValue = "formattedValue",
    value = "value"
}
export type NumberInputReturnValueType = keyof typeof NumberInputReturnValueEnum;
export interface INumberFormatProps extends Pick<NumberFormatProps, 'allowEmptyFormatting' | 'allowLeadingZeros' | 'allowNegative' | 'decimalScale' | 'fixedDecimalScale' | 'format' | 'isAllowed' | 'mask' | 'maxLength' | 'minLength' | 'prefix' | 'removeFormatting' | 'renderText' | 'suffix' | 'type'> {
    decimalSeparator?: ',' | '.';
    returnValue?: NumberInputReturnValueType;
    thousandSeparator?: boolean | ',' | '.' | ' ';
}
export interface INumberInputProps extends Pick<TextFieldProps, 'autoComplete' | 'autoFocus' | 'className' | 'disabled' | 'focused' | 'id' | 'inputRef' | 'label' | 'onBlur' | 'onFocus' | 'onKeyPress' | 'placeholder' | 'ref' | 'required' | 'size' | 'sx' | 'variant'>, ICommonFieldProps, INumberFormatProps, Pick<IInputProps, 'passwordVisibility'> {
    textAlign?: 'left' | 'right' | 'center';
}
//# sourceMappingURL=type.d.ts.map