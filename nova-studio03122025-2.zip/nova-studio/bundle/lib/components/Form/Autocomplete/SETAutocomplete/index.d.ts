import type { JSX } from 'react';
import type { IAutocompleteProps } from '../type';
declare const Autocomplete: <T>({ helperText, name, autoComplete, disabled, readOnly, required, label, hidden, autoFocus, open, noOptionsDataText, loadingText, disableCloseOnSelect, options, multiple, control, fullWidth, labelPlacement, labelWidth, labelEllipsis, sx, onKeyPress, onBlur, onFocus, onChange, placeholder, popupIcon, openText, closeText, disablePopupIconRotate, componentsProps, className, deps, ChipProps, renderTags, showSelectedItemsSummary, variant, getOptionDisabled, }: IAutocompleteProps<T>) => JSX.Element;
export default Autocomplete;
//# sourceMappingURL=index.d.ts.map