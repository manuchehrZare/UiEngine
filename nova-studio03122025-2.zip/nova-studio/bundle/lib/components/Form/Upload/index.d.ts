import 'filepond-polyfill';
import 'filepond/dist/filepond.min.css';
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css';
import type { IUploadProps } from './type';
declare const _default: import("react").NamedExoticComponent<IUploadProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map