import type { FC } from 'react';
import type { IRadioProps } from '../type';
declare const Radio: FC<IRadioProps>;
export default Radio;
//# sourceMappingURL=index.d.ts.map