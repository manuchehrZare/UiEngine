import type { RadioProps } from '@mui/material';
import type { ICommonFieldProps } from '../commonTypes';
export interface IRadioProps extends Pick<RadioProps, 'checkedIcon' | 'className' | 'color' | 'disabled' | 'icon' | 'id' | 'onChange' | 'size' | 'sx' | 'required'>, Pick<ICommonFieldProps, 'helperText' | 'design'> {
    label?: string;
    value: any;
}
//# sourceMappingURL=type.d.ts.map