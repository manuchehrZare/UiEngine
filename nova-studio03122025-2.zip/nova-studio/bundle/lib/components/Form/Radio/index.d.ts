import type { IRadioProps } from './type';
declare const _default: import("react").NamedExoticComponent<IRadioProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map