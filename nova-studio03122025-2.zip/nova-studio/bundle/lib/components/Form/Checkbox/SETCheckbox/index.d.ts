import type { FC } from 'react';
import type { ICheckboxProps } from '../type';
declare const Checkbox: FC<ICheckboxProps>;
export default Checkbox;
//# sourceMappingURL=index.d.ts.map