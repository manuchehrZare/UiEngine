import type { FC } from 'react';
import type { ITableFooterProps } from './type';
declare const TableFooter: FC<ITableFooterProps>;
export default TableFooter;
//# sourceMappingURL=index.d.ts.map