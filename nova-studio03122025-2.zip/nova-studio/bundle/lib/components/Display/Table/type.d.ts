import type { TableContainerProps, TableProps } from '@mui/material';
import type { Ref } from 'react';
import type { ICommonProps } from '../../../utils/types/common';
export interface ITableProps extends Pick<TableProps, 'children' | 'className' | 'hidden' | 'id' | 'key' | 'onClick' | 'onClickCapture' | 'onDoubleClick' | 'onDoubleClickCapture' | 'onKeyDown' | 'onKeyDownCapture' | 'onKeyPress' | 'onKeyPressCapture' | 'onKeyUp' | 'onKeyUpCapture' | 'onLoad' | 'onLoadCapture' | 'onLoadStart' | 'onLoadStartCapture' | 'onMouseDown' | 'onMouseDownCapture' | 'onMouseEnter' | 'onMouseLeave' | 'onMouseMove' | 'onMouseMoveCapture' | 'onMouseOut' | 'onMouseOutCapture' | 'onMouseOver' | 'onMouseOverCapture' | 'onMouseUp' | 'onMouseUpCapture' | 'onScroll' | 'onScrollCapture' | 'onWheel' | 'onWheelCapture' | 'size' | 'sx'>, ICommonProps {
    containerProps?: Pick<TableContainerProps, 'className' | 'hidden' | 'id' | 'key' | 'onClick' | 'onClickCapture' | 'onDoubleClick' | 'onDoubleClickCapture' | 'onKeyDown' | 'onKeyDownCapture' | 'onKeyPress' | 'onKeyPressCapture' | 'onKeyUp' | 'onKeyUpCapture' | 'onLoad' | 'onLoadCapture' | 'onLoadStart' | 'onLoadStartCapture' | 'onMouseDown' | 'onMouseDownCapture' | 'onMouseEnter' | 'onMouseLeave' | 'onMouseMove' | 'onMouseMoveCapture' | 'onMouseOut' | 'onMouseOutCapture' | 'onMouseOver' | 'onMouseOverCapture' | 'onMouseUp' | 'onMouseUpCapture' | 'onScroll' | 'onScrollCapture' | 'onWheel' | 'onWheelCapture' | 'sx'>;
    noBorder?: boolean;
    ref?: Ref<any>;
}
//# sourceMappingURL=type.d.ts.map