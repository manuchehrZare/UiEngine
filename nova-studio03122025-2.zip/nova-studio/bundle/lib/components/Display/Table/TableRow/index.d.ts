import type { FC } from 'react';
import type { ITableRowProps } from './type';
declare const TableRow: FC<ITableRowProps>;
export default TableRow;
//# sourceMappingURL=index.d.ts.map