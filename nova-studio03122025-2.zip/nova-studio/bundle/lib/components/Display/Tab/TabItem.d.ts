import type { ITabItemProps } from './type';
declare const _default: import("react").NamedExoticComponent<ITabItemProps>;
export default _default;
//# sourceMappingURL=TabItem.d.ts.map