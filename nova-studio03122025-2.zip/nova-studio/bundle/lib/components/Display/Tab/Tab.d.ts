import type { FC } from 'react';
import type { ITabProps } from './type';
declare const Tab: FC<ITabProps>;
export default Tab;
//# sourceMappingURL=Tab.d.ts.map