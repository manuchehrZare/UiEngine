import type { KeyboardLayoutObject } from 'react-simple-keyboard';
export declare const numeric: KeyboardLayoutObject;
//# sourceMappingURL=numeric.d.ts.map