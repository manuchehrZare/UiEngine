import type { Grid2Props } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
export interface IGridProps extends Omit<Grid2Props, 'classes' | 'color' | 'fontFamily'>, ICommonProps {
    /**
     * @default undefined
     */
    spacingType?: 'common' | 'button' | 'form' | 'joinedForm';
}
export interface IGridItemProps extends Omit<Grid2Props, 'classes' | 'color' | 'fontFamily'>, ICommonProps {
    /**
     * @default undefined
     */
    sizeType?: 'common' | 'form';
}
//# sourceMappingURL=type.d.ts.map