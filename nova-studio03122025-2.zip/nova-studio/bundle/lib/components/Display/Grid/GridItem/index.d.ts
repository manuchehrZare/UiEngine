import type { FC } from 'react';
import type { IGridItemProps } from '../type';
declare const GridItem: FC<IGridItemProps>;
export default GridItem;
//# sourceMappingURL=index.d.ts.map