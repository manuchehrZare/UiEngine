import type { INavContainerProps } from '../type';
declare const _default: import("react").NamedExoticComponent<INavContainerProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map