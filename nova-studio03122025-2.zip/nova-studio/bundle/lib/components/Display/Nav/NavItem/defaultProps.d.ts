import type { INavItemProps } from '../../../..';
export declare const getDefaultProps: ({ design, sx, }: Pick<INavItemProps, "design" | "sx">) => Pick<INavItemProps, "py" | "pb" | "sx">;
//# sourceMappingURL=defaultProps.d.ts.map