import type { INavTitleProps } from '../type';
declare const _default: import("react").NamedExoticComponent<INavTitleProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map