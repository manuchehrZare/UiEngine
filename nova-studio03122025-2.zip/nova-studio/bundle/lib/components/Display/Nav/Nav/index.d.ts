import type { INavProps } from '../type';
declare const _default: import("react").NamedExoticComponent<INavProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map