import type { ChipProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
export interface IChipProps extends ICommonProps, Pick<ChipProps, 'avatar' | 'className' | 'disabled' | 'deleteIcon' | 'icon' | 'label' | 'onClick' | 'onDelete' | 'size' | 'sx' | 'variant' | 'leftCornered' | 'rightCornered' | 'cornered'> {
    color?: 'primary' | 'secondary' | 'info' | 'error' | 'success' | 'warning';
}
//# sourceMappingURL=type.d.ts.map