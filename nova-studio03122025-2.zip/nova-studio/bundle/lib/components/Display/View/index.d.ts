import type { IViewProps } from './type';
declare const _default: import("react").NamedExoticComponent<IViewProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map