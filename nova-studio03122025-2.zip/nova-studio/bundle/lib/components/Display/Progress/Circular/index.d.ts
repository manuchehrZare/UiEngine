import type { FC } from 'react';
import type { ICircularProgressProps } from './type';
declare const CustomCircularProgress: FC<ICircularProgressProps>;
export default CustomCircularProgress;
//# sourceMappingURL=index.d.ts.map