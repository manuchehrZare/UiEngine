import type { IProgressProps } from '../type';
export interface ILinearProgressProps extends Omit<IProgressProps, 'type'> {
}
//# sourceMappingURL=type.d.ts.map