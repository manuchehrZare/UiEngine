import type { ListProps } from '@mui/material';
import type { ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';
export interface IKeyValueListItem {
    text: ReactNode;
    value: ReactNode;
    wrap?: boolean;
}
export interface IKeyValueListProps extends ICommonProps, Pick<ListProps, 'className' | 'sx'> {
    data: IKeyValueListItem[];
    wrap?: boolean;
}
//# sourceMappingURL=type.d.ts.map