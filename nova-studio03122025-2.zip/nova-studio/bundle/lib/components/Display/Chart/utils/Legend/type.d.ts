export interface ILegend {
    color?: string;
    fontSize?: number;
    iconSize?: number;
    iconType?: 'circle' | 'cross' | 'diamond' | 'line' | 'plainline' | 'rect' | 'square' | 'star' | 'triangle' | 'wye';
    layout?: 'vertical' | 'horizontal';
    margin?: number;
    position?: 'top' | 'bottom';
}
//# sourceMappingURL=type.d.ts.map