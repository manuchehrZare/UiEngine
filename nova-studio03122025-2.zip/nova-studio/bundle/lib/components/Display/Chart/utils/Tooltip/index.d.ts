import type { ChartDataTypes, ChartTooltipTypes } from '../../commonTypes';
import type { ITooltip } from './type';
import type { JSX } from 'react';
declare const CustomTooltip: <T extends ChartDataTypes, Y extends ChartTooltipTypes>(chartType: "pie" | "bar" | "line", tooltip: boolean | ITooltip | Y, activeTooltipData?: any, data?: T, yUnit?: string | [string, string]) => JSX.Element;
export default CustomTooltip;
//# sourceMappingURL=index.d.ts.map