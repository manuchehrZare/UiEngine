import type { ILegend } from './type';
import type { JSX } from 'react';
declare const CustomLegend: (legend: boolean | ILegend) => JSX.Element;
export default CustomLegend;
//# sourceMappingURL=index.d.ts.map