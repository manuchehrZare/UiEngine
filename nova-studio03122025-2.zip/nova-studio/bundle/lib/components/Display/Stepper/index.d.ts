import type { IStepperProps, IStepStepperRef } from './type';
declare const Stepper: import("react").ForwardRefExoticComponent<IStepperProps & import("react").RefAttributes<IStepStepperRef>>;
export default Stepper;
//# sourceMappingURL=index.d.ts.map