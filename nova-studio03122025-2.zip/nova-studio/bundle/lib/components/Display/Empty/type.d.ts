import type { ICommonProps } from '../../../utils/types/common';
export interface IEmptyProps extends ICommonProps {
    className?: string;
    loading?: boolean;
    text: string;
}
//# sourceMappingURL=type.d.ts.map