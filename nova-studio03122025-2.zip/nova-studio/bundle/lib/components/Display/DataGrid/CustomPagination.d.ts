import type { GridApiPro } from '@mui/x-data-grid-pro';
import type { FC } from 'react';
import type { IPaginationProps } from '../Pagination/type';
interface ICustomPaginationProps extends IPaginationProps {
    apiRef: React.MutableRefObject<GridApiPro>;
}
declare const CustomPagination: FC<ICustomPaginationProps>;
export default CustomPagination;
//# sourceMappingURL=CustomPagination.d.ts.map