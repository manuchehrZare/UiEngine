import type { GridApiPro } from '@mui/x-data-grid-pro/models/gridApiPro';
import type { Dispatch, FC, MutableRefObject, SetStateAction } from 'react';
import type { DataGridColDef, ToolbarPropsType } from './type';
interface ICustomToolbarProps {
    apiRef: MutableRefObject<GridApiPro>;
    columns: DataGridColDef[];
    setRowsData: Dispatch<SetStateAction<readonly any[]>>;
    toolbarProps?: ToolbarPropsType;
}
declare const CustomToolbar: FC<ICustomToolbarProps>;
export default CustomToolbar;
//# sourceMappingURL=CustomToolbar.d.ts.map