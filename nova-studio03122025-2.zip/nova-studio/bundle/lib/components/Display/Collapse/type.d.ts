import type { CollapseProps } from '@mui/material';
export interface ICollapseProps extends Pick<CollapseProps, 'className' | 'orientation' | 'in' | 'timeout' | 'children'> {
}
//# sourceMappingURL=type.d.ts.map