import type { IModalProps } from './type';
declare const _default: import("react").NamedExoticComponent<IModalProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map