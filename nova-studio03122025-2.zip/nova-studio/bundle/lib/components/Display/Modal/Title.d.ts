import type { FC } from 'react';
import type { IModalTitleProps } from './type';
declare const ModalTitle: FC<IModalTitleProps>;
export default ModalTitle;
//# sourceMappingURL=Title.d.ts.map