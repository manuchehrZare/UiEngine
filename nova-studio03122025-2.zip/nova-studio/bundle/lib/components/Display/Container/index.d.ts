import type { FC } from 'react';
import type { IContainerProps } from './type';
declare const Container: FC<IContainerProps>;
export default Container;
//# sourceMappingURL=index.d.ts.map