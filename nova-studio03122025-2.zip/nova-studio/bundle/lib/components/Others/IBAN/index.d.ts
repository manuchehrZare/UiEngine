import type { FC } from 'react';
import type { IBANProps } from './type';
declare const IBAN: FC<IBANProps>;
export default IBAN;
//# sourceMappingURL=index.d.ts.map