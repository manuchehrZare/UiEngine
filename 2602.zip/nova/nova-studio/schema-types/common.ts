/* eslint-disable */
import type { PropertySchema, EventSchema } from './schema';

export const commonProps: PropertySchema[] = [
    { name: 'id', type: 'string', label: 'ID', group: 'Common' },
    { name: 'className', type: 'string', label: 'Class Name', group: 'Common' },
    { name: 'design', type: 'select', label: 'Design', group: 'Common', options: ['default', 'SET'] },
    { name: 'sx', type: 'json', label: 'SX Styles', group: 'Style' },
    { name: 'visible', type: 'boolean', label: 'Visible', group: 'State', defaultValue: true },
];

export const commonFormProps: PropertySchema[] = [
    ...commonProps,
    { name: 'label', type: 'string', label: 'Label', group: 'Form' },
    { name: 'helperText', type: 'string', label: 'Helper Text', group: 'Form' },
    { name: 'placeholder', type: 'string', label: 'Placeholder', group: 'Form' },
    { name: 'disabled', type: 'boolean', label: 'Disabled', group: 'State' },
    { name: 'required', type: 'boolean', label: 'Required', group: 'Validation' },
    { name: 'readOnly', type: 'boolean', label: 'Read Only', group: 'State' },
    { name: 'fullWidth', type: 'boolean', label: 'Full Width', group: 'Style', defaultValue: true },
    { name: 'size', type: 'select', label: 'Size', group: 'Style', options: ['small', 'medium'] },
    { name: 'variant', type: 'select', label: 'Variant', group: 'Style', options: ['outlined', 'filled', 'standard'] },
    { name: 'hidden', type: 'boolean', label: 'Hidden', group: 'State' },
    { name: 'labelPlacement', type: 'select', label: 'Label Placement', group: 'Style', options: ['top', 'start'] },
    { name: 'labelWidth', type: 'string', label: 'Label Width', group: 'Style' },
    { name: 'tabIndex', type: 'number', label: 'Tab Index', group: 'Common' },
];

/**
 * Common events for form components (inputs, selects, etc.)
 */
export const commonFormEvents: EventSchema[] = [
    { name: 'onChange', label: 'On Change', description: 'Fired when the value changes' },
    { name: 'onBlur', label: 'On Blur', description: 'Fired when the component loses focus' },
    { name: 'onFocus', label: 'On Focus', description: 'Fired when the component gains focus' },
];

/**
 * Common events for clickable components (buttons, etc.)
 */
export const commonClickEvents: EventSchema[] = [
    { name: 'onClick', label: 'On Click', description: 'Fired when the component is clicked' },
    { name: 'onDoubleClick', label: 'On Double Click', description: 'Fired when the component is double-clicked' },
];

/**
 * Page lifecycle events
 */
export const pageLifecycleEvents: EventSchema[] = [
    { name: 'onLoad', label: 'On Load', description: 'Fired when the page loads' },
    { name: 'onUnload', label: 'On Unload', description: 'Fired before the page unloads' },
];

/**
 * Table/Data Grid events
 */
export const tableEvents: EventSchema[] = [
    { name: 'onRowSelect', label: 'On Row Select', description: 'Fired when a row is selected' },
    { name: 'onCellClick', label: 'On Cell Click', description: 'Fired when a cell is clicked' },
    { name: 'onRowInsert', label: 'On Row Insert', description: 'Fired when a row is inserted' },
    { name: 'onRowDelete', label: 'On Row Delete', description: 'Fired when a row is deleted' },
    { name: 'onCellDataChanged', label: 'On Cell Data Changed', description: 'Fired when cell data changes' },
];

