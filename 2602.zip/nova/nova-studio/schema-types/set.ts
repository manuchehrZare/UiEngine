/* eslint-disable */
import { createSchema, type PropertySchema } from './schema';
import { commonProps } from './common';

/**
 * Button properties that can be reused across button-like components
 */
export const buttonProperties: PropertySchema[] = [
    { name: 'children', type: 'string', label: 'Label', group: 'Content' },
    { name: 'variant', type: 'select', label: 'Variant', group: 'Style', options: ['text', 'contained', 'outlined'] },
    { name: 'color', type: 'select', label: 'Color', group: 'Style', options: ['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning'] },
    { name: 'size', type: 'select', label: 'Size', group: 'Style', options: ['small', 'medium', 'large'] },
    { name: 'fullWidth', type: 'boolean', label: 'Full Width', group: 'Style' },
    { name: 'disabled', type: 'boolean', label: 'Disabled', group: 'State' },
    { name: 'type', type: 'select', label: 'Type', group: 'Behavior', options: ['button', 'submit', 'reset'] },
    { name: 'loading', type: 'boolean', label: 'Loading', group: 'State' },
    { name: 'text', type: 'string', label: 'Text', group: 'Content' },
    { name: 'href', type: 'string', label: 'Href', group: 'Behavior' },
    { name: 'icon', type: 'string', label: 'Icon Name', group: 'Content' },
    { name: 'rounded', type: 'boolean', label: 'Rounded', group: 'Style' },
];

/**
 * Set category component schemas
 */
export const SetSchemas = {
    SetButton: createSchema('SetButton', 'Set', [
        ...commonProps,
        ...buttonProperties,
    ], { children: 'Set Button', variant: 'contained', color: 'primary' }, [
        { name: 'actionPerformed', label: 'Action Performed', description: 'Triggered when the button is clicked' }
    ]),

    TableComponent: createSchema('TableComponent', 'Set', [
        ...commonProps,
        { name: 'adapterInfo', type: 'json', label: 'Adapter Info', group: 'Data' },
        { name: 'background', type: 'string', label: 'Background Color', group: 'Style' },
        { name: 'rows', type: 'array', label: 'Rows', group: 'Data' },
    ], {}, [
        { name: 'cellDataChanged', label: 'Cell Data Changed', description: 'Triggered when cell data is modified' },
        { name: 'mouseDoubleClicked', label: 'Mouse Double Clicked', description: 'Triggered on double click' },
        { name: 'mousePressed', label: 'Mouse Pressed', description: 'Triggered when mouse is pressed' },
        { name: 'rowDeleted', label: 'Row Deleted', description: 'Triggered when a row is deleted' },
        { name: 'rowInserted', label: 'Row Inserted', description: 'Triggered when a row is inserted' },
        { name: 'rowSelected', label: 'Row Selected', description: 'Triggered when a row is selected' }
    ]),

    Region: createSchema('Region', 'Set', [
        ...commonProps,
        { name: 'regionName', type: 'string', label: 'Region Name', group: 'General', description: 'The name/ID of the region page to load', required: true },
        { name: 'title', type: 'string', label: 'Title', group: 'General', description: 'Title displayed in the Nav header when set' },
        { name: 'popup', type: 'boolean', label: 'Popup', group: 'General', description: 'If true, renders as a modal dialog instead of inline content' },
        { name: 'label', type: 'string', label: 'Label', group: 'General' },
    ], {}, [
        { name: 'popupCanceled', label: 'Popup Canceled', description: 'Triggered when popup is canceled' }
    ]),

    HandleButton: createSchema('HandleButton', 'Set', [
        ...commonProps,
        { name: 'name', type: 'string', label: 'Name', group: 'General' },
        { name: 'label', type: 'string', label: 'Label', group: 'General' },
        { name: 'fieldLabel', type: 'string', label: 'Field Label', group: 'General' },
        { name: 'text', type: 'string', label: 'Text', group: 'General' },
        { name: 'popup', type: 'string', label: 'Popup Page ID', group: 'General', description: 'The page ID to open as a modal when button is clicked' },
        { name: 'readOnly', type: 'boolean', label: 'Read Only', group: 'State', defaultValue: true },
    ], {}, [
        { name: 'actionPerformed', label: 'Action Performed', description: 'Triggered when the button is clicked' },
        { name: 'focusGained', label: 'Focus Gained', description: 'Triggered when the field gains focus' },
        { name: 'focusLost', label: 'Focus Lost', description: 'Triggered when the field loses focus' },
        { name: 'onCancelPopup', label: 'On Cancel Popup', description: 'Triggered when popup is cancelled' },
        { name: 'onClosePopup', label: 'On Close Popup', description: 'Triggered when popup is closed' },
        { name: 'onShowPopup', label: 'On Show Popup', description: 'Triggered when popup is shown' }
    ]),

    Page: createSchema('Page', 'Set', [
        ...commonProps,
        { name: 'title', type: 'string', label: 'Title', group: 'General' },
        { name: 'popupMenuName', type: 'string', label: 'Popup Menu Name', group: 'General', description: 'ID of a JCSPopupMenu definition to attach as right-click context menu' },
    ], {}, [
        { name: 'pageClose', label: 'Page Close', description: 'Triggered when the page is closed' },
        { name: 'pageKeyEvent', label: 'Page Key Event', description: 'Triggered on keyboard events' },
        { name: 'pageLoad', label: 'Page Load', description: 'Triggered when the page loads' }
    ]),

    TabbedPane: createSchema('TabbedPane', 'Set', [
        ...commonProps,
        { name: 'defaultTab', type: 'string', label: 'Default Tab', group: 'General' },
    ], {}, [
        { name: 'stateChanged', label: 'State Changed', description: 'Triggered when the selected tab changes' }
    ]),

    TabPage: createSchema('TabPage', 'Set', [
        ...commonProps,
        { name: 'label', type: 'string', label: 'Label', group: 'General' },
        { name: 'text', type: 'string', label: 'Text', group: 'General' },
    ], {}, [
        { name: 'pageLoad', label: 'Page Load', description: 'Triggered when the tab page loads' }
    ]),

    ReportViewer: createSchema('ReportViewer', 'Set', [
        ...commonProps,
        { name: 'name', type: 'string', label: 'Name', group: 'General' },
        { name: 'value', type: 'string', label: 'PDF Data (Base64)', group: 'Data', description: 'Base64 encoded PDF data' },
    ]),
};
