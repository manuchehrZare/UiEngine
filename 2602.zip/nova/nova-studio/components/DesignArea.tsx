/* eslint-disable */
import React, { useMemo, useEffect, useRef } from 'react';
import { useDrop } from 'react-dnd';
import { FormProvider } from 'react-hook-form';
import useForm from '../../../seker-ui-lib/hooks/useForm';
import { ComponentRenderer } from './ComponentRenderer';
import { Box, Typography, Paper, IconButton, Tooltip } from '@mui/material';
import GridOnIcon from '@mui/icons-material/GridOn';
import GridOffIcon from '@mui/icons-material/GridOff';
import { buildFormDefaultValues } from '../../nova-core/utils/formUtils';
import { PreviewRenderer } from './PreviewRenderer';
import { useNova } from '../../nova-core';
import { useGridOptional } from '../context/GridContext';
import { CoordinateGridOverlay } from './CoordinateGridOverlay';

export const DesignArea: React.FC = () => {
    const { components, addComponent, selectComponent, moveComponent, mode } = useNova();
    const gridContext = useGridOptional();
    const containerRef = useRef<HTMLDivElement>(null);

    // Check if any component has bounds (bounds mode)
    const hasBoundsComponents = useMemo(() => {
        const checkBounds = (comps: any[]): boolean => {
            for (const comp of comps) {
                if (comp.bounds) return true;
                if (comp.children && checkBounds(comp.children)) return true;
            }
            return false;
        };
        return checkBounds(components);
    }, [components]);

    // Recalculate grid lines when components change
    // Use componentIds as dependency to avoid unnecessary recalculations
    const boundsKey = useMemo(() => {
        const extractBoundsKey = (comps: any[]): string => {
            return comps.map(c => {
                const boundsStr = c.bounds ? `${c.bounds.x},${c.bounds.y},${c.bounds.width},${c.bounds.height}` : '';
                const childStr = c.children ? extractBoundsKey(c.children) : '';
                return `${c.id}:${boundsStr}${childStr}`;
            }).join('|');
        };
        return extractBoundsKey(components);
    }, [components]);

    useEffect(() => {
        if (gridContext && hasBoundsComponents) {
            gridContext.recalculateGridLines(components);
        }
    }, [boundsKey, hasBoundsComponents]); // Only recalculate when bounds actually change

    // Build initial default values only once on mount or when component structure changes
    const componentIds = useMemo(() => {
        const extractIds = (comps: any[]): string => {
            return comps.map(c => `${c.id}:${c.type}${c.children ? ':' + extractIds(c.children) : ''}`).join(',');
        };
        return extractIds(components);
    }, [components]);

    const initialDefaultValues = useMemo(() => {
        return buildFormDefaultValues(components);
    }, [componentIds]);

    const pageForm = useForm({
        defaultValues: initialDefaultValues,
        mode: 'onChange',
    });

    const [{ isOver }, drop] = useDrop({
        accept: ['COMPONENT', 'COMPONENT_INSTANCE'],
        drop: (item: any, monitor) => {
            if (monitor.didDrop()) return;

            if (item.id) {
                moveComponent(item.id, null, 'inside');
            } else {
                addComponent(item.type, null);
            }
        },
        collect: (monitor) => ({
            isOver: monitor.isOver({ shallow: true }),
        }),
    });

    const handleBackgroundClick = () => {
        selectComponent(null);
    };

    // Combine refs
    const setRefs = (el: HTMLDivElement | null) => {
        drop(el);
        (containerRef as any).current = el;
    };

    // Preview/generator mode - render without D&D wrappers
    if (mode === 'preview' || mode === 'generator') {
        return (
            <Box sx={{ bgcolor: '#f0f2f5', height: '100%', overflow: 'auto' }}>
                <FormProvider {...pageForm}>
                    {components.map(comp => <PreviewRenderer key={comp.id} component={comp} />)}
                </FormProvider>
            </Box>
        );
    }

    // Determine if we should use bounds-based layout
    const useBoundsLayout = hasBoundsComponents && gridContext?.boundsMode;

    // Design mode - with D&D functionality
    return (
        <Box
            ref={setRefs}
            onClick={handleBackgroundClick}
            sx={{
                height: '100%',
                p: 4,
                backgroundColor: isOver ? '#e3f2fd' : '#f0f2f5',
                overflow: 'auto',
                transition: 'background-color 0.2s',
                position: 'relative',
            }}
        >
            {/* Grid overlay toggle button */}
            {gridContext && hasBoundsComponents && (
                <Box sx={{ position: 'absolute', top: 8, right: 8, zIndex: 1001 }}>
                    <Tooltip title={gridContext.showGridOverlay ? 'Hide Grid Lines' : 'Show Grid Lines'}>
                        <IconButton
                            size="small"
                            onClick={(e) => {
                                e.stopPropagation();
                                gridContext.setShowGridOverlay(!gridContext.showGridOverlay);
                            }}
                            sx={{
                                backgroundColor: gridContext.showGridOverlay ? '#eb7a34' : 'white',
                                color: gridContext.showGridOverlay ? 'white' : '#eb7a34',
                                border: '1px solid #eb7a34',
                                '&:hover': {
                                    backgroundColor: gridContext.showGridOverlay ? '#d96a24' : '#fff5ee',
                                }
                            }}
                        >
                            {gridContext.showGridOverlay ? <GridOnIcon fontSize="small" /> : <GridOffIcon fontSize="small" />}
                        </IconButton>
                    </Tooltip>
                </Box>
            )}

            <Paper
                elevation={0}
                sx={{
                    minHeight: useBoundsLayout ? 600 : '100%',
                    p: useBoundsLayout ? 0 : 2,
                    backgroundColor: 'white',
                    border: '1px solid #e0e0e0',
                    backgroundImage: isOver
                        ? 'radial-gradient(#2196f3 1px, transparent 1px)'
                        : 'radial-gradient(#e0e0e0 1px, transparent 1px)',
                    backgroundSize: '20px 20px',
                    position: 'relative',
                }}
            >
                {/* Coordinate Grid Overlay */}
                {gridContext && hasBoundsComponents && (
                    <CoordinateGridOverlay
                        gridLines={gridContext.gridLines}
                        visible={gridContext.showGridOverlay}
                        gridColor="#eb7a34"
                        containerWidth={gridContext.containerWidth}
                    />
                )}

                <FormProvider {...pageForm}>
                    {components.length === 0 ? (
                        <Box sx={{
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            height: '300px',
                            color: 'text.secondary'
                        }}>
                            <Typography>Drag components here to start designing</Typography>
                        </Box>
                    ) : useBoundsLayout ? (
                        // Bounds-based layout mode - absolute positioning
                        <Box sx={{ position: 'relative', minHeight: 600 }}>
                            {components.map(comp => (
                                <ComponentRenderer key={comp.id} component={comp} />
                            ))}
                        </Box>
                    ) : (
                        // Standard flow layout mode
                        components.map(comp => (
                            <ComponentRenderer key={comp.id} component={comp} />
                        ))
                    )}
                </FormProvider>
            </Paper>
        </Box>
    );
};
