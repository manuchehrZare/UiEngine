/* eslint-disable */
import React, { useRef, useState, useCallback } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { Box, Unstable_Grid2 as Grid2 } from '@mui/material';
import { COMPONENT_REGISTRY } from '../../nova-core/registry/component-registry';
import { useNova, type DesignComponent } from '../../nova-core';
import { useGridOptional } from '../context/GridContext';
import { ResizableWrapper } from './ResizableWrapper';
import type { ComponentBounds } from '../../nova-core/types';

interface ComponentRendererProps {
    component: DesignComponent;
}

export const ComponentRenderer: React.FC<ComponentRendererProps> = ({ component }) => {
    const { selectComponent, selectedComponentId, moveComponent, addComponent, updateComponentBounds } = useNova();
    const gridContext = useGridOptional();
    const ref = useRef<HTMLDivElement>(null);
    const [isHovered, setIsHovered] = useState(false);

    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';
    const isContainer = registryItem?.isContainer;

    // Check if this component has bounds for absolute positioning
    const hasBounds = !!component.bounds;

    const [{ isDragging }, drag] = useDrag({
        type: 'COMPONENT_INSTANCE',
        item: { id: component.id, type: component.type },
        collect: (monitor) => ({
            isDragging: monitor.isDragging(),
        }),
        // Disable default drag when using bounds mode (ResizableWrapper handles it)
        canDrag: !hasBounds,
    });

    const [{ isOver, canDrop }, drop] = useDrop({
        accept: ['COMPONENT', 'COMPONENT_INSTANCE'],
        canDrop: (item: any, monitor) => {
            if (!isContainer) return false;
            if (item.id === component.id) return false;
            return true;
        },
        drop: (item: any, monitor) => {
            if (monitor.didDrop()) {
                return;
            }

            if (item.id) {
                moveComponent(item.id, component.id, 'inside');
            } else {
                addComponent(item.type, component.id);
            }
        },
        collect: (monitor) => ({
            isOver: monitor.isOver({ shallow: true }),
            canDrop: monitor.canDrop(),
        }),
    });

    // Only apply drag/drop refs when not in bounds mode
    if (!hasBounds) {
        drag(drop(ref));
    }

    const isSelected = selectedComponentId === component.id;

    const handleClick = useCallback((e: React.MouseEvent) => {
        e.stopPropagation();
        selectComponent(component.id);
    }, [component.id, selectComponent]);

    const handleBoundsChange = useCallback((newBounds: ComponentBounds) => {
        updateComponentBounds(component.id, newBounds);
    }, [component.id, updateComponentBounds]);

    // Recursively render children
    const renderChildren = () => {
        return component.children.map((child, index) => (
            <ComponentRenderer key={`${component.id}-${index}-${child.id}`} component={child} />
        ));
    };

    const isGridItem = component.type === 'GridItem';

    const gridLayoutProps = isGridItem ? {
        xs: component.props.xs,
        sm: component.props.sm,
        md: component.props.md,
        lg: component.props.lg,
        xl: component.props.xl,
    } : {};

    const componentPropsToPass = isGridItem
        ? Object.fromEntries(
            Object.entries(component.props).filter(([key]) =>
                !['xs', 'sm', 'md', 'lg', 'xl'].includes(key)
            )
          )
        : component.props;

    // Common wrapper styles for non-bounds mode
    const wrapperStyles = {
        position: 'relative' as const,
        opacity: isDragging ? 0.5 : 1,
        border: isSelected ? '2px solid #2196f3' : isHovered ? '1px dashed #2196f3' : '1px solid transparent',
        m: isGridItem ? 0 : 0.5,
        backgroundColor: (isOver && canDrop) ? 'rgba(33, 150, 243, 0.1)' : undefined,
        transition: 'all 0.2s',
    };

    // Render the actual component content
    const renderComponentContent = () => (
        <ActualComponent {...componentPropsToPass} designComponent={component}>
            {isContainer ? (
                component.children.length > 0 ? (
                    renderChildren()
                ) : (
                    <Box
                        sx={{
                            minHeight: '50px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            border: '1px dashed #ccc',
                            borderRadius: 1,
                            m: 1,
                            backgroundColor: '#fafafa'
                        }}
                    >
                        <span style={{ fontSize: '0.8rem', color: '#999' }}>Drop components here</span>
                    </Box>
                )
            ) : (
                component.props.children
            )}
        </ActualComponent>
    );

    // Render content with label overlay
    const renderContent = () => (
        <>
            {/* Label for selected/hovered component */}
            {(isSelected || isHovered) && (
                <Box
                    sx={{
                        position: 'absolute',
                        top: hasBounds ? -20 : -20,
                        left: 0,
                        backgroundColor: isSelected ? (hasBounds ? '#eb7a34' : '#2196f3') : '#90caf9',
                        color: 'white',
                        fontSize: '0.75rem',
                        padding: '2px 6px',
                        borderRadius: '4px 4px 0 0',
                        zIndex: 10,
                        pointerEvents: 'none'
                    }}
                >
                    {component.type}
                    {hasBounds && component.bounds && (
                        <span style={{ marginLeft: 8, fontSize: '0.65rem', opacity: 0.9 }}>
                            ({component.bounds.x}, {component.bounds.y})
                        </span>
                    )}
                </Box>
            )}
            {renderComponentContent()}
        </>
    );

    // Bounds mode - use ResizableWrapper for absolute positioning
    if (hasBounds && component.bounds) {
        return (
            <ResizableWrapper
                bounds={component.bounds}
                onBoundsChange={handleBoundsChange}
                gridLines={gridContext?.gridLines}
                snapThreshold={gridContext?.snapThreshold}
                isSelected={isSelected}
                onClick={handleClick}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
            >
                {renderContent()}
            </ResizableWrapper>
        );
    }

    // GridItem - use Grid2 wrapper
    if (isGridItem) {
        return (
            <Grid2
                ref={ref}
                onClick={handleClick}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                {...gridLayoutProps}
                sx={{
                    ...wrapperStyles,
                    ...component.props.style,
                    display: 'flex',
                    flexDirection: 'column',
                    minWidth: 0,
                }}
            >
                {renderContent()}
            </Grid2>
        );
    }

    // Standard flow layout
    return (
        <Box
            ref={ref}
            onClick={handleClick}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            sx={wrapperStyles}
        >
            {renderContent()}
        </Box>
    );
};
