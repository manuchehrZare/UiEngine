/* eslint-disable */
import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Paper, Divider, useForm, Input, Select } from '../../../../seker-ui-lib';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    Stack, IconButton, TextField, MenuItem
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import { v4 as uuidv4 } from 'uuid';
import { useNova, type SubAction } from '../../../nova-core';

interface SubActionEditorProps {
    open: boolean;
    subAction: SubAction | null;
    onSave: (subAction: SubAction) => void;
    onClose: () => void;
}

interface SubActionFormValues {
    type: string;
    rule: string;
    beanValue: string;
    method: string;
    service: string;
    referencedAction: string;
    variableName: string;
    variableValue: string;
    variableValueType: string;
    variableValueMethod: string;
    pageName: string;
    pageTitle: string;
    returnAction: string;
}

export const SubActionEditor: React.FC<SubActionEditorProps> = ({ open, subAction, onSave, onClose }) => {
    const { rules = [], variables = [], actions = [] } = useNova();
    const [formData, setFormData] = useState<Partial<SubAction>>({
        type: 'BeanAction'
    });

    const { control, handleSubmit, reset, setValue } = useForm<SubActionFormValues>({
        defaultValues: {
            type: 'BeanAction',
            rule: '',
            beanValue: '',
            method: '',
            service: '',
            referencedAction: '',
            variableName: '',
            variableValue: '',
            variableValueType: 'Constant',
            variableValueMethod: '',
            pageName: '',
            pageTitle: '',
            returnAction: ''
        }
    });

    useEffect(() => {
        if (subAction) {
            setFormData(subAction);
            reset({
                type: subAction.type || 'BeanAction',
                rule: subAction.rule || '',
                beanValue: subAction.beanValue || '',
                method: subAction.method || '',
                service: subAction.service || '',
                referencedAction: subAction.referencedAction || '',
                variableName: subAction.variableName || '',
                variableValue: subAction.variableValue || '',
                variableValueType: subAction.variableValueType || 'Constant',
                variableValueMethod: subAction.variableValueMethod || '',
                pageName: subAction.pageName || '',
                pageTitle: subAction.pageTitle || '',
                returnAction: subAction.returnAction || ''
            });
        } else {
            setFormData({ type: 'BeanAction' });
            reset({
                type: 'BeanAction',
                rule: '',
                beanValue: '',
                method: '',
                service: '',
                referencedAction: '',
                variableName: '',
                variableValue: '',
                variableValueType: 'constant',
                variableValueMethod: '',
                pageName: '',
                pageTitle: '',
                returnAction: ''
            });
        }
    }, [subAction]);

    const handleSave = handleSubmit((data) => {
        onSave({
            id: formData.id || uuidv4(),
            ...data,
            // Keep the arrays from formData state
            parameters: formData.parameters,
            inputs: formData.inputs,
            outputs: formData.outputs,
            pageParameters: formData.pageParameters
        } as SubAction);
    });

    const addParameter = () => {
        setFormData({
            ...formData,
            parameters: [...(formData.parameters || []), { name: '', value: '', valueType: 'constant' }]
        });
    };

    const updateParameter = (index: number, field: string, value: any) => {
        const updated = [...(formData.parameters || [])];
        updated[index] = { ...updated[index], [field]: value };
        setFormData({ ...formData, parameters: updated });
    };

    const deleteParameter = (index: number) => {
        const updated = [...(formData.parameters || [])];
        updated.splice(index, 1);
        setFormData({ ...formData, parameters: updated });
    };

    const addInput = () => {
        setFormData({
            ...formData,
            inputs: [...(formData.inputs || []), { bagKey: '', value: '', valueType: 'constant', componentId: '' }]
        });
    };

    const updateInput = (index: number, field: string, value: any) => {
        const updated = [...(formData.inputs || [])];
        updated[index] = { ...updated[index], [field]: value };
        setFormData({ ...formData, inputs: updated });
    };

    const deleteInput = (index: number) => {
        const updated = [...(formData.inputs || [])];
        updated.splice(index, 1);
        setFormData({ ...formData, inputs: updated });
    };

    const addOutput = () => {
        setFormData({
            ...formData,
            outputs: [...(formData.outputs || []), { bagKey: '', targetVariable: '', targetId: '', targetType: 'variable' }]
        });
    };

    const updateOutput = (index: number, field: string, value: any) => {
        const updated = [...(formData.outputs || [])];
        updated[index] = { ...updated[index], [field]: value };
        setFormData({ ...formData, outputs: updated });
    };

    const deleteOutput = (index: number) => {
        const updated = [...(formData.outputs || [])];
        updated.splice(index, 1);
        setFormData({ ...formData, outputs: updated });
    };

    const addPageParameter = () => {
        setFormData({
            ...formData,
            pageParameters: [...(formData.pageParameters || []), { variableName: '', value: '', valueMethod: '' }]
        });
    };

    const updatePageParameter = (index: number, field: string, value: any) => {
        const updated = [...(formData.pageParameters || [])];
        updated[index] = { ...updated[index], [field]: value };
        setFormData({ ...formData, pageParameters: updated });
    };

    const deletePageParameter = (index: number) => {
        const updated = [...(formData.pageParameters || [])];
        updated.splice(index, 1);
        setFormData({ ...formData, pageParameters: updated });
    };

    const variableValueTypeData=[
                                        { value: 'constant', label: 'Constant' },
                                        { value: 'variable', label: 'Variable' },
                                        { value: 'component', label: 'Component' },
                                        { value: 'rule', label: 'Rule' }
                                    ];

const subActionTypeData=[
                                    { value: 'BeanAction', label: 'Bean Action - Call component methods' },
                                    { value: 'RemoteCall', label: 'Remote Call - Call server services' },
                                    { value: 'ReferenceCall', label: 'Reference Call - Call another action' },
                                    { value: 'VariableSetting', label: 'Variable Setting - Set variable values' },
                                    { value: 'PageCall', label: 'Page Call - Navigate to page' }
                                ];

    return (
        <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
            <DialogTitle>
                {subAction ? 'Edit Sub-Action' : 'New Sub-Action'}
            </DialogTitle>
            <DialogContent>
                <Paper sx={{ p: 3, bgcolor: 'background.default' }}>
                    <Stack spacing={2}>
                         <Select
                            label="Sub-Action Type *"
                            name="type"
                            control={control}
                            options={{
                                data: subActionTypeData,
                                displayField: 'label',
                                displayValue: 'value',
                            }}
                            setValue={setValue}
                            onChange={( selectedValue) => setFormData({ ...formData, type:  selectedValue })}
                        />

                        <Select
                            label="Rule"
                            name="rule"
                            control={control}
                            options={{
                                data: [{ id: '', name: 'No Rule' }, ...rules],
                                displayField: 'name',
                                displayValue: 'name',
                            }}
                            setValue={setValue}
                        />

                    {/* BeanAction Fields */}
                    {formData.type === 'BeanAction' && (
                        <>
                            <Input
                                label="Component/Bean Name *"
                                name="beanValue"
                                control={control}
                            />

                            <Input
                                label="Method *"
                                name="method"
                                control={control}
                            />

                            <Box>
                                <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                                    <Typography variant="subtitle2">Parameters</Typography>
                                    <Button size="small" iconLeft={<AddIcon />} onClick={addParameter} text="Add Parameter" />
                                </Stack>
                                {(formData.parameters || []).length > 0 && (
                                    <>
                                        {/* Header Row */}
                                        <Box sx={{
                                            display: 'grid',
                                            gridTemplateColumns: '1fr 1fr 130px 100px 40px',
                                            gap: 2,
                                            mb: 1,
                                            pb: 1,
                                            borderBottom: '2px solid #ddd',
                                            fontWeight: 'bold',
                                            fontSize: '0.875rem'
                                        }}>
                                            <div>Name</div>
                                            <div>Value</div>
                                            <div>Type</div>
                                            <div>Method</div>
                                            <div></div>
                                        </Box>
                                        {/* Data Rows */}
                                        {(formData.parameters || []).map((param, index) => (
                                            <Box key={index} sx={{
                                                display: 'grid',
                                                gridTemplateColumns: '1fr 1fr 130px 100px 40px',
                                                gap: 2,
                                                mb: 1,
                                                alignItems: 'center'
                                            }}>
                                                <TextField
                                                    size="small"
                                                    value={param.name}
                                                    onChange={(e) => updateParameter(index, 'name', e.target.value)}
                                                    fullWidth
                                                />
                                                <TextField
                                                    size="small"
                                                    value={param.value}
                                                    onChange={(e) => updateParameter(index, 'value', e.target.value)}
                                                    fullWidth
                                                />
                                                <TextField select
                                                    size="small"
                                                    value={param.valueType || 'constant'}
                                                    onChange={(e) => updateParameter(index, 'valueType', e.target.value)}
                                                    fullWidth
                                                >
                                                    <MenuItem value="constant">Constant</MenuItem>
                                                    <MenuItem value="variable">Variable</MenuItem>
                                                    <MenuItem value="component">Component</MenuItem>
                                                    <MenuItem value="rule">Rule</MenuItem>
                                                </TextField>
                                                <TextField
                                                    size="small"
                                                    value={param.valueMethod || ''}
                                                    onChange={(e) => updateParameter(index, 'valueMethod', e.target.value)}
                                                    fullWidth
                                                    disabled={param.valueType !== 'component'}
                                                />
                                                <IconButton size="small" onClick={() => deleteParameter(index)}>
                                                    <DeleteIcon fontSize="small" />
                                                </IconButton>
                                            </Box>
                                        ))}
                                    </>
                                )}
                            </Box>
                        </>
                    )}

                    {/* RemoteCall Fields */}
                    {formData.type === 'RemoteCall' && (
                        <>
                            <Input
                                label="Service Name *"
                                name="service"
                                control={control}
                            />
                            <Divider textAlign="left">Input Parameters</Divider>
                            <Box>
                                <Button size="small" iconLeft={<AddIcon />}  text="Add Input" onClick={addInput} sx={{ mb: 1 }} />
                                {(formData.inputs || []).length > 0 && (
                                    <>
                                        {/* Header Row */}
                                        <Box sx={{
                                            display: 'grid',
                                            gridTemplateColumns: '1fr 140px 1fr 40px',
                                            gap: 2,
                                            mb: 1,
                                            pb: 1,
                                            borderBottom: '2px solid #ddd',
                                            fontWeight: 'bold',
                                            fontSize: '0.875rem'
                                        }}>
                                            <div>Bag Key</div>
                                            <div>Type</div>
                                            <div>Value / Component ID</div>
                                            <div></div>
                                        </Box>
                                        {/* Data Rows */}
                                        {(formData.inputs || []).map((input, index) => (
                                            <Box key={index} sx={{
                                                display: 'grid',
                                                gridTemplateColumns: '1fr 140px 1fr 40px',
                                                gap: 2,
                                                mb: 1,
                                                alignItems: 'center'
                                            }}>
                                                <TextField
                                                    size="small"
                                                    value={input.bagKey}
                                                    onChange={(e) => updateInput(index, 'bagKey', e.target.value)}
                                                    fullWidth
                                                />
                                                <TextField select
                                                    size="small"
                                                    value={input.valueType || 'constant'}
                                                    onChange={(e) => updateInput(index, 'valueType', e.target.value)}
                                                    fullWidth
                                                >
                                                    <MenuItem value="constant">Constant</MenuItem>
                                                    <MenuItem value="variable">Variable</MenuItem>
                                                    <MenuItem value="component">Component</MenuItem>
                                                </TextField>
                                                {input.valueType === 'component' ? (
                                                    <TextField
                                                        size="small"
                                                        value={input.componentId || ''}
                                                        onChange={(e) => updateInput(index, 'componentId', e.target.value)}
                                                        fullWidth
                                                    />
                                                ) : (
                                                    <TextField
                                                        size="small"
                                                        value={input.value}
                                                        onChange={(e) => updateInput(index, 'value', e.target.value)}
                                                        fullWidth
                                                    />
                                                )}
                                                <IconButton size="small" onClick={() => deleteInput(index)}>
                                                    <DeleteIcon fontSize="small" />
                                                </IconButton>
                                            </Box>
                                        ))}
                                    </>
                                )}
                            </Box>

                            <Divider textAlign="left">Output Parameters</Divider>
                            <Box>
                                <Button size="small" iconLeft={<AddIcon />} text="Add Output" onClick={addOutput} sx={{ mb: 1 }} />
                                {(formData.outputs || []).length > 0 && (
                                    <>
                                        {/* Header Row */}
                                        <Box sx={{
                                            display: 'grid',
                                            gridTemplateColumns: '1fr 140px 1fr 40px',
                                            gap: 2,
                                            mb: 1,
                                            pb: 1,
                                            borderBottom: '2px solid #ddd',
                                            fontWeight: 'bold',
                                            fontSize: '0.875rem'
                                        }}>
                                            <div>Bag Key</div>
                                            <div>Target Type</div>
                                            <div>Variable / Component ID</div>
                                            <div></div>
                                        </Box>
                                        {/* Data Rows */}
                                        {(formData.outputs || []).map((output, index) => (
                                            <Box key={index} sx={{
                                                display: 'grid',
                                                gridTemplateColumns: '1fr 140px 1fr 40px',
                                                gap: 2,
                                                mb: 1,
                                                alignItems: 'center'
                                            }}>
                                                <TextField
                                                    size="small"
                                                    value={output.bagKey}
                                                    onChange={(e) => updateOutput(index, 'bagKey', e.target.value)}
                                                    fullWidth
                                                />
                                                <TextField select
                                                    size="small"
                                                    value={output.targetType || 'variable'}
                                                    onChange={(e) => updateOutput(index, 'targetType', e.target.value)}
                                                    fullWidth
                                                >
                                                    <MenuItem value="variable">Variable</MenuItem>
                                                    <MenuItem value="component">Component</MenuItem>
                                                </TextField>
                                                {output.targetType === 'variable' ? (
                                                    <TextField
                                                        size="small"
                                                        value={output.targetVariable}
                                                        onChange={(e) => updateOutput(index, 'targetVariable', e.target.value)}
                                                        fullWidth
                                                    />
                                                ) : (
                                                    <TextField
                                                        size="small"
                                                        value={output.targetId || ''}
                                                        onChange={(e) => updateOutput(index, 'targetId', e.target.value)}
                                                        fullWidth
                                                    />
                                                )}
                                                <IconButton size="small" onClick={() => deleteOutput(index)}>
                                                    <DeleteIcon fontSize="small" />
                                                </IconButton>
                                            </Box>
                                        ))}
                                    </>
                                )}
                            </Box>
                        </>
                    )}

                    {/* ReferenceCall Fields */}
                    {formData.type === 'ReferenceCall' && (
                        <Select
                            label="Referenced Action *"
                            name="referencedAction"
                            control={control}
                            options={{
                                data: [{ id: '', name: '' }, ...actions],
                                displayField: 'name',
                                displayValue: 'name',
                            }}
                            setValue={setValue}
                        />
                    )}

                    {/* VariableSetting Fields */}
                    {formData.type === 'VariableSetting' && (
                        <>
                            <Select
                                label="Variable Name *"
                                name="variableName"
                                control={control}
                                options={{
                                    data: [{ id: '', name: '(None)' }, ...(variables || []).filter(v => v && v.name)],
                                    displayField: 'name',
                                    displayValue: 'id',
                                }}
                                setValue={setValue}
                            />

                            <Input
                                label="Value *"
                                name="variableValue"
                                control={control}
                            />

                            <Select
                                label="Value Type"
                                name="variableValueType"
                                control={control}
                                options={{
                                    data: variableValueTypeData ,
                                    displayField: 'label',
                                    displayValue: 'value',
                                }}
                                setValue={setValue}
                                onChange={( selectedValue) => setFormData({ ...formData, variableValueType: selectedValue })}
                            />

                            {formData.variableValueType === 'component' && (
                                <Input
                                    label="Value Method"
                                    name="variableValueMethod"
                                    control={control}
                                />
                            )}
                        </>
                    )}

                    {/* PageCall Fields */}
                    {formData.type === 'PageCall' && (
                        <>
                            <Input
                                label="Page Name *"
                                name="pageName"
                                control={control}
                            />

                            <Input
                                label="Page Title"
                                name="pageTitle"
                                control={control}
                            />

                            <Select
                                label="Return Action"
                                name="returnAction"
                                control={control}
                                options={{
                                    data: [{ id: '', name: '' }, ...actions],
                                    displayField: 'name',
                                    displayValue: 'name',
                                }}
                                setValue={setValue}
                            />

                            <Box>
                                <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                                    <Typography variant="subtitle2">Page Parameters</Typography>
                                    <Button size="small" iconLeft={<AddIcon />} text="Add Parameter"  onClick={addPageParameter} />
                                </Stack>
                                {(formData.pageParameters || []).length > 0 && (
                                    <>
                                        {/* Header Row */}
                                        <Box sx={{
                                            display: 'grid',
                                            gridTemplateColumns: '1fr 1fr 1fr 40px',
                                            gap: 2,
                                            mb: 1,
                                            pb: 1,
                                            borderBottom: '2px solid #ddd',
                                            fontWeight: 'bold',
                                            fontSize: '0.875rem'
                                        }}>
                                            <div>Variable Name</div>
                                            <div>Value</div>
                                            <div>Method</div>
                                            <div></div>
                                        </Box>
                                        {/* Data Rows */}
                                        {(formData.pageParameters || []).map((param, index) => (
                                            <Box key={index} sx={{
                                                display: 'grid',
                                                gridTemplateColumns: '1fr 1fr 1fr 40px',
                                                gap: 2,
                                                mb: 1,
                                                alignItems: 'center'
                                            }}>
                                                <TextField
                                                    size="small"
                                                    value={param.variableName}
                                                    onChange={(e) => updatePageParameter(index, 'variableName', e.target.value)}
                                                    fullWidth
                                                />
                                                <TextField
                                                    size="small"
                                                    value={param.value}
                                                    onChange={(e) => updatePageParameter(index, 'value', e.target.value)}
                                                    fullWidth
                                                />
                                                <TextField
                                                    size="small"
                                                    value={param.valueMethod || ''}
                                                    onChange={(e) => updatePageParameter(index, 'valueMethod', e.target.value)}
                                                    fullWidth
                                                />
                                                <IconButton size="small" onClick={() => deletePageParameter(index)}>
                                                    <DeleteIcon fontSize="small" />
                                                </IconButton>
                                            </Box>
                                        ))}
                                    </>
                                )}
                            </Box>
                        </>
                    )}
                    </Stack>
                </Paper>
            </DialogContent>
            <DialogActions sx={{ justifyContent: 'flex-end' }}>
                <Button onClick={onClose} text="Cancel" />
                <Button onClick={handleSave} text="Save" variant="contained" />
            </DialogActions>
        </Dialog>
    );
};
