/* eslint-disable */
import React, { useMemo, useState, useEffect } from 'react';
import { ComponentSchemas, DefaultSchema } from '../schema-types';
import {
    Box, Typography, TextField, Switch, FormControlLabel,
    Divider, Select, MenuItem, FormControl, IconButton,
    Accordion, AccordionSummary, AccordionDetails, Button
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import EditIcon from '@mui/icons-material/Edit';
import AspectRatioIcon from '@mui/icons-material/AspectRatio';
import type { ComponentSchema, PropertySchema } from '../schema-types/schema';
import { useNova } from '../../nova-core';
import type { ComponentBounds } from '../../nova-core/types';
import { KeyValueGridInput } from './KeyValueGridInput';
import { DefinitionsEditorModal } from './Modals/DefinitionsEditorModal';
import { EventBindingsEditorModal } from './Modals/EventBindingsEditorModal';

const JsonInput: React.FC<{
    label: string;
    value: any;
    onChange: (val: any) => void;
}> = ({ label, value, onChange }) => {
    const [text, setText] = useState('');
    const [error, setError] = useState(false);

    useEffect(() => {
        setText(JSON.stringify(value, null, 2));
    }, [value]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newText = e.target.value;
        setText(newText);
        try {
            const parsed = JSON.parse(newText);
            setError(false);
            onChange(parsed);
        } catch (err) {
            setError(true);
        }
    };

    return (
        <TextField
            fullWidth
            multiline
            rows={4}
            label={label}
            value={text}
            onChange={handleChange}
            error={error}
            helperText={error ? "Invalid JSON" : ""}
            variant="outlined"
            size="small"
            sx={{ mb: 2, fontFamily: 'monospace' }}
            inputProps={{ style: { fontFamily: 'monospace', fontSize: 12 } }}
        />
    );
};

export const PropertiesPanel: React.FC = () => {
    const { selectedComponentId, getComponentById, updateComponentProps, updateComponentBounds, deleteComponent } = useNova();
    const [showDefinitionsModal, setShowDefinitionsModal] = useState(false);
    const [showEventBindingsModal, setShowEventBindingsModal] = useState(false);

    // Only calculate component when ID changes
    const component = useMemo(() =>
        selectedComponentId ? getComponentById(selectedComponentId) : null,
    [selectedComponentId, getComponentById]);

    // Derive schema directly from component type (memoized)
    const schema: ComponentSchema = useMemo(() => {
        if (!component) return DefaultSchema;
        // @ts-ignore
        return ComponentSchemas[component.type] || DefaultSchema;
    }, [component?.type]);

    const groupedProps = useMemo(() => {
        const groups: Record<string, PropertySchema[]> = {};
        schema.properties.forEach(prop => {
            const group = prop.group || 'General';
            if (!groups[group]) groups[group] = [];
            groups[group].push(prop);
        });
        
        // Ensure General is first if it exists
        const orderedGroups: Record<string, PropertySchema[]> = {};
        if (groups['General']) orderedGroups['General'] = groups['General'];
        Object.keys(groups).sort().forEach(key => {
            if (key !== 'General') orderedGroups[key] = groups[key];
        });
        
        return orderedGroups;
    }, [schema]);

    if (!selectedComponentId || !component) {
        return (
            <Box sx={{ p: 2 }}>
                <Typography color="text.secondary">Select a component to edit properties</Typography>
            </Box>
        );
    }

    const handleChange = (key: string, value: any) => {
        updateComponentProps(component.id, { [key]: value });
    };

    const handleBoundsChange = (field: keyof ComponentBounds, value: number) => {
        if (!component) return;
        const currentBounds = component.bounds || { x: 0, y: 0, width: 100, height: 30 };
        updateComponentBounds(component.id, { ...currentBounds, [field]: value });
    };

    const handleAddBounds = () => {
        if (!component) return;
        updateComponentBounds(component.id, { x: 0, y: 0, width: 200, height: 50 });
    };

    const handleRemoveBounds = () => {
        if (!component) return;
        // Remove bounds by setting to undefined (requires context support)
        updateComponentBounds(component.id, undefined as any);
    };

    const renderInput = (propSchema: PropertySchema) => {
        const key = propSchema.name;
        const value = component.props[key];
        const currentValue = value ?? propSchema.defaultValue;

        switch (propSchema.type) {
            case 'boolean':
                return (
                    <FormControlLabel
                        key={key}
                        control={
                            <Switch 
                                checked={Boolean(currentValue)} 
                                onChange={(e) => handleChange(key, e.target.checked)} 
                            />
                        }
                        label={propSchema.label || key}
                        sx={{ mb: 1, display: 'block' }}
                    />
                );
            
            case 'select':
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ mb: 0.5, fontWeight: 500 }}>
                            {propSchema.label || key}
                        </Typography>
                        <FormControl fullWidth size="small">
                            <Select
                                value={currentValue ?? ''}
                                onChange={(e) => handleChange(key, e.target.value)}
                                displayEmpty
                                sx={{ minWidth: '100%' }}
                            >
                                <MenuItem value="" disabled>
                                    <em>Select {propSchema.label || key}</em>
                                </MenuItem>
                                {propSchema.options?.map((opt: any) => {
                                    const isObject = typeof opt === 'object';
                                    const val = isObject ? opt.value : opt;
                                    const label = isObject ? opt.label : opt;
                                    return (
                                        <MenuItem key={String(val)} value={val}>{label}</MenuItem>
                                    );
                                })}
                            </Select>
                        </FormControl>
                    </Box>
                );

            case 'number':
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ mb: 0.5, fontWeight: 500 }}>
                            {propSchema.label || key}
                        </Typography>
                        <TextField
                            type="number"
                            fullWidth
                            size="small"
                            value={currentValue ?? ''}
                            onChange={(e) => handleChange(key, Number(e.target.value))}
                            variant="outlined"
                        />
                    </Box>
                );

            case 'json':
            case 'array':
            case 'object':
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ mb: 0.5, fontWeight: 500 }}>
                            {propSchema.label || key}
                        </Typography>
                        <JsonInput
                            label=""
                            value={currentValue}
                            onChange={(val) => handleChange(key, val)}
                        />
                    </Box>
                );

            case 'keyvalue':
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <KeyValueGridInput
                            label={propSchema.label || key}
                            value={currentValue || []}
                            onChange={(val) => handleChange(key, val)}
                            keyLabel={propSchema.keyLabel || 'Key'}
                            valueLabel={propSchema.valueLabel || 'Value'}
                        />
                    </Box>
                );

            case 'bounds':
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ mb: 1, fontWeight: 500 }}>
                            {propSchema.label || key}
                        </Typography>
                        <Box sx={{ 
                            display: 'grid', 
                            gridTemplateColumns: '1fr 1fr',
                            gap: 1
                        }}>
                            <TextField
                                label="X"
                                type="number"
                                size="small"
                                value={currentValue?.x ?? 0}
                                onChange={(e) => handleChange(key, { 
                                    ...currentValue, 
                                    x: Number(e.target.value) 
                                })}
                                variant="outlined"
                            />
                            <TextField
                                label="Y"
                                type="number"
                                size="small"
                                value={currentValue?.y ?? 0}
                                onChange={(e) => handleChange(key, { 
                                    ...currentValue, 
                                    y: Number(e.target.value) 
                                })}
                                variant="outlined"
                            />
                            <TextField
                                label="Width"
                                type="number"
                                size="small"
                                value={currentValue?.width ?? 0}
                                onChange={(e) => handleChange(key, { 
                                    ...currentValue, 
                                    width: Number(e.target.value) 
                                })}
                                variant="outlined"
                            />
                            <TextField
                                label="Height"
                                type="number"
                                size="small"
                                value={currentValue?.height ?? 0}
                                onChange={(e) => handleChange(key, { 
                                    ...currentValue, 
                                    height: Number(e.target.value) 
                                })}
                                variant="outlined"
                            />
                        </Box>
                    </Box>
                );

            case 'definitions':
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ mb: 0.5, fontWeight: 500 }}>
                            {propSchema.label || key}
                        </Typography>
                        <Button
                            variant="outlined"
                            fullWidth
                            startIcon={<EditIcon />}
                            onClick={() => setShowDefinitionsModal(true)}
                            sx={{ justifyContent: 'flex-start' }}
                        >
                            Edit Options
                        </Button>
                        {propSchema.description && (
                            <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                                {propSchema.description}
                            </Typography>
                        )}
                    </Box>
                );

            default: // string
                return (
                    <Box key={key} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ mb: 0.5, fontWeight: 500 }}>
                            {propSchema.label || key}
                        </Typography>
                        <TextField
                            fullWidth
                            size="small"
                            value={currentValue ?? ''}
                            onChange={(e) => handleChange(key, e.target.value)}
                            variant="outlined"
                        />
                    </Box>
                );
        }
    };

    const handleDelete = () => {
        if (component) {
            deleteComponent(component.id);
        }
    };

    return (
        <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderLeft: '1px solid #ddd' }}>
            <Box sx={{ p: 2, borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography variant="h6">{component.type}</Typography>
                <IconButton onClick={handleDelete} color="error" size="small" title="Delete Component">
                    <DeleteIcon />
                </IconButton>
            </Box>

            <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
                {Object.entries(groupedProps).map(([group, props]) => (
                    <Accordion key={group} defaultExpanded disableGutters elevation={0} sx={{ '&:before': { display: 'none' }, borderBottom: '1px solid #eee' }}>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 48, px: 1, backgroundColor: '#f5f5f5' }}>
                            <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>{group}</Typography>
                        </AccordionSummary>
                        <AccordionDetails sx={{ p: 2 }}>
                            {props.map(prop => renderInput(prop))}
                        </AccordionDetails>
                    </Accordion>
                ))}

                {/* Events Accordion */}
                {schema.events && schema.events.length > 0 && (
                    <Accordion disableGutters elevation={0} sx={{ '&:before': { display: 'none' }, borderBottom: '1px solid #eee' }}>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 48, px: 1, backgroundColor: '#f5f5f5' }}>
                            <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Events</Typography>
                        </AccordionSummary>
                        <AccordionDetails sx={{ p: 2 }}>
                            <Button
                                variant="outlined"
                                fullWidth
                                startIcon={<EditIcon />}
                                onClick={() => setShowEventBindingsModal(true)}
                                sx={{ justifyContent: 'flex-start' }}
                            >
                                Manage Event Bindings
                            </Button>
                            <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                                Configure which actions trigger on component events
                            </Typography>
                        </AccordionDetails>
                    </Accordion>
                )}

                {/* Position & Size (Bounds) Accordion */}
                <Accordion disableGutters elevation={0} sx={{ '&:before': { display: 'none' }, borderBottom: '1px solid #eee' }}>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 48, px: 1, backgroundColor: '#fff5ee' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <AspectRatioIcon sx={{ fontSize: 18, color: '#eb7a34' }} />
                            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', color: '#eb7a34' }}>Position & Size</Typography>
                        </Box>
                    </AccordionSummary>
                    <AccordionDetails sx={{ p: 2 }}>
                        {component.bounds ? (
                            <>
                                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1, mb: 2 }}>
                                    <TextField
                                        label="X"
                                        type="number"
                                        size="small"
                                        value={component.bounds.x}
                                        onChange={(e) => handleBoundsChange('x', Number(e.target.value))}
                                        InputProps={{ sx: { fontFamily: 'monospace' } }}
                                    />
                                    <TextField
                                        label="Y"
                                        type="number"
                                        size="small"
                                        value={component.bounds.y}
                                        onChange={(e) => handleBoundsChange('y', Number(e.target.value))}
                                        InputProps={{ sx: { fontFamily: 'monospace' } }}
                                    />
                                    <TextField
                                        label="Width"
                                        type="number"
                                        size="small"
                                        value={component.bounds.width}
                                        onChange={(e) => handleBoundsChange('width', Number(e.target.value))}
                                        InputProps={{ sx: { fontFamily: 'monospace' } }}
                                    />
                                    <TextField
                                        label="Height"
                                        type="number"
                                        size="small"
                                        value={component.bounds.height}
                                        onChange={(e) => handleBoundsChange('height', Number(e.target.value))}
                                        InputProps={{ sx: { fontFamily: 'monospace' } }}
                                    />
                                </Box>
                                <Button
                                    variant="outlined"
                                    color="warning"
                                    size="small"
                                    fullWidth
                                    onClick={handleRemoveBounds}
                                >
                                    Remove Position (Use Flow Layout)
                                </Button>
                            </>
                        ) : (
                            <>
                                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                    This component uses flow layout. Enable absolute positioning to set exact coordinates.
                                </Typography>
                                <Button
                                    variant="contained"
                                    size="small"
                                    fullWidth
                                    onClick={handleAddBounds}
                                    sx={{ backgroundColor: '#eb7a34', '&:hover': { backgroundColor: '#d96a24' } }}
                                >
                                    Enable Absolute Positioning
                                </Button>
                            </>
                        )}
                    </AccordionDetails>
                </Accordion>

                {/* Fallback for un-grouped props if using DefaultSchema or minimal schema */}
                {Object.keys(groupedProps).length === 0 && (
                    <Typography variant="body2" color="text.secondary">No properties defined in schema.</Typography>
                )}
            </Box>

            {/* Definitions Editor Modal */}
            {component && (
                <DefinitionsEditorModal
                    showModal={showDefinitionsModal}
                    onClose={() => setShowDefinitionsModal(false)}
                    componentId={component.id}
                />
            )}

            {/* Event Bindings Editor Modal */}
            {component && schema.events && schema.events.length > 0 && (
                <EventBindingsEditorModal
                    showModal={showEventBindingsModal}
                    onClose={() => setShowEventBindingsModal(false)}
                    componentId={component.props.id || component.id}
                    componentType={component.type}
                    availableEvents={schema.events.map(e => e.name)}
                />
            )}
        </Box>
    );
};
