/* eslint-disable */
import React from 'react';
import { COMPONENT_REGISTRY } from '../../nova-core/registry/component-registry';
import { NovaRuntimeWrapper } from '../../nova-core/components/NovaRuntimeWrapper';
import { useNova, type DesignComponent } from '../../nova-core';

/**
 * Helper to check if a component and all its children are invisible
 * Used to determine if a GridItem should be hidden
 */
function areAllChildrenInvisible(
    component: DesignComponent,
    getComponentState: (id: string) => { visible?: boolean } | undefined
): boolean {
    const children = component.children || [];

    // If no children, check the component's own visibility
    if (children.length === 0) {
        return false; // Empty GridItem should still show
    }

    // Check if ALL children are invisible
    return children.every(child => {
        const childState = getComponentState(child.id);
        const propsVisible = child.props?.visible;
        // A child is invisible if either state or props says visible=false
        const isChildInvisible = childState?.visible === false || propsVisible === false;

        if (isChildInvisible) {
            return true; // This child is invisible
        }

        // If child is a container, recursively check its children
        const childRegistry = COMPONENT_REGISTRY[child.type];
        if (childRegistry?.isContainer && child.children?.length > 0) {
            return areAllChildrenInvisible(child, getComponentState);
        }

        return false; // This child is visible
    });
}

export const PreviewRenderer: React.FC<{ component: DesignComponent }> = ({ component }) => {
    const { getComponentState } = useNova();
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';

    const renderChildren = () => {
         return component.children?.map((child, index) => (
            <PreviewRenderer key={`${component.id}-${index}-${child.id}`} component={child} />
        ));
    };

    // Extract key and designComponent from component.props to avoid React warnings
    // React keys must be passed directly, not spread
    // designComponent should not be passed to DOM elements
    const { key: _, designComponent: __, ...propsWithoutKey } = component.props || {};

    // Pass designComponent only if the component explicitly requires it (e.g. TabbedPane)
    // This prevents React warnings about passing unrecognized props to DOM elements
    const extraProps: Record<string, any> = {};
    if (registryItem?.needsDesignComponent) {
        extraProps.designComponent = component;
    }

    // For GridItem: if all children are invisible, hide the GridItem to avoid empty space
    if (component.type === 'GridItem') {
        const allChildrenInvisible = areAllChildrenInvisible(component, getComponentState);
        if (allChildrenInvisible) {
            return null; // Don't render the GridItem at all
        }

        // Dynamic grid sizing: If this GridItem has an adjustXs property,
        // calculate the adjusted xs value based on sibling visibility
        if (component.props?.adjustXsOnSiblingHidden && component.props?.siblingId) {
            const siblingComponent = findSiblingComponent(component);
            if (siblingComponent) {
                const siblingInvisible = areAllChildrenInvisible(siblingComponent, getComponentState);
                if (siblingInvisible) {
                    // Expand this GridItem to take the sibling's space
                    const currentXs = Number(component.props.xs) || 12;
                    const siblingXs = Number(siblingComponent.props?.xs) || 0;
                    extraProps.xs = currentXs + siblingXs;
                }
            }
        }
    }

    // Wrap with runtime features (method registration, event handlers)
    return (
        <NovaRuntimeWrapper component={component}>
            <ActualComponent {...propsWithoutKey} {...extraProps}>
                {registryItem?.isContainer ? renderChildren() : component.props?.children}
            </ActualComponent>
        </NovaRuntimeWrapper>
    );
};

/**
 * Helper to find sibling component by traversing parent
 * This is a simplified version - you may need to enhance based on your component tree structure
 */
function findSiblingComponent(component: DesignComponent): DesignComponent | null {
    // This would need access to the parent component
    // For now, return null - you'll need to pass parent context or use a different approach
    return null;
}


// Simple renderer for Preview mode without D&D/Selection wrappers
/* export const PreviewRenderer: React.FC<{ component: any }> = ({ component }) => {
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';

    const renderChildren = () => {
         return component.children?.map((child: any) => (
            <PreviewRenderer key={child.id} component={child} />
        ));
    };

    // Destructure to exclude 'key' from props spreading
    const { key, ...restProps } = component.props || {};

    return (
        <ActualComponent {...restProps} designComponent={component}>
            {registryItem?.isContainer ? renderChildren() : component.props.children}
        </ActualComponent>
    );
}**/

