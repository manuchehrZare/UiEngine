/* eslint-disable */
import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import type { DesignComponent } from '../../nova-core/types/nova-ui-schema.types';
import type { ComponentBounds } from '../../nova-core/types';

interface GridLines {
    columns: number[];
    rows: number[];
}

interface GridContextType {
    /** Whether bounds-based layout mode is enabled */
    boundsMode: boolean;
    setBoundsMode: (enabled: boolean) => void;

    /** Calculated grid lines from all component bounds */
    gridLines: GridLines;

    /** Recalculate grid lines from components */
    recalculateGridLines: (components: DesignComponent[]) => void;

    /** Container width for grid calculations */
    containerWidth: number;
    setContainerWidth: (width: number) => void;

    /** Show/hide grid overlay */
    showGridOverlay: boolean;
    setShowGridOverlay: (show: boolean) => void;

    /** Snap threshold in pixels */
    snapThreshold: number;
    setSnapThreshold: (threshold: number) => void;
}

const GridContext = createContext<GridContextType | undefined>(undefined);

export const useGrid = () => {
    const context = useContext(GridContext);
    if (!context) {
        throw new Error('useGrid must be used within a GridProvider');
    }
    return context;
};

/**
 * Optional version that returns null if provider is not available
 */
export const useGridOptional = () => {
    return useContext(GridContext);
};

interface GridProviderProps {
    children: React.ReactNode;
    defaultContainerWidth?: number;
}

/**
 * Extracts bounds from a DesignComponent
 */
const extractBounds = (component: DesignComponent): ComponentBounds | undefined => {
    // Check for bounds directly on component
    if (component.bounds) {
        return component.bounds;
    }
    // Check for bounds in props (legacy format)
    if (component.props?.bounds) {
        if (typeof component.props.bounds === 'string') {
            const parts = component.props.bounds.split(',').map((s: string) => parseInt(s.trim(), 10));
            if (parts.length >= 4) {
                return {
                    x: parts[0],
                    y: parts[1],
                    width: parts[2],
                    height: parts[3]
                };
            }
        }
        if (typeof component.props.bounds === 'object') {
            return component.props.bounds;
        }
    }
    return undefined;
};

/**
 * Recursively collects all bounds from component tree
 */
const collectAllBounds = (components: DesignComponent[]): ComponentBounds[] => {
    const bounds: ComponentBounds[] = [];

    const traverse = (comps: DesignComponent[]) => {
        for (const comp of comps) {
            const compBounds = extractBounds(comp);
            if (compBounds) {
                bounds.push(compBounds);
            }
            if (comp.children && comp.children.length > 0) {
                traverse(comp.children);
            }
        }
    };

    traverse(components);
    return bounds;
};

/**
 * Calculates grid lines from component bounds
 */
const calculateGridLines = (bounds: ComponentBounds[], containerWidth: number): GridLines => {
    const xPositions = new Set<number>([0]);
    const yPositions = new Set<number>([0]);

    bounds.forEach((b) => {
        xPositions.add(b.x);
        xPositions.add(b.x + b.width);
        yPositions.add(b.y);
        yPositions.add(b.y + b.height);
    });

    // Add container width
    const maxX = Math.max(...Array.from(xPositions));
    if (containerWidth > maxX) {
        xPositions.add(containerWidth);
    }

    return {
        columns: Array.from(xPositions).sort((a, b) => a - b),
        rows: Array.from(yPositions).sort((a, b) => a - b)
    };
};

export const GridProvider: React.FC<GridProviderProps> = ({
    children,
    defaultContainerWidth = 960
}) => {
    const [boundsMode, setBoundsMode] = useState(false);
    const [gridLines, setGridLines] = useState<GridLines>({ columns: [], rows: [] });
    const [containerWidth, setContainerWidth] = useState(defaultContainerWidth);
    const [showGridOverlay, setShowGridOverlay] = useState(true);
    const [snapThreshold, setSnapThreshold] = useState(10);

    const recalculateGridLines = useCallback((components: DesignComponent[]) => {
        const allBounds = collectAllBounds(components);
        if (allBounds.length > 0) {
            const newGridLines = calculateGridLines(allBounds, containerWidth);
            setGridLines(newGridLines);
            // Only enable bounds mode if not already enabled (avoid re-render loops)
            setBoundsMode(prev => prev ? prev : true);
        } else {
            setGridLines({ columns: [], rows: [] });
        }
    }, [containerWidth]);

    const value = useMemo(() => ({
        boundsMode,
        setBoundsMode,
        gridLines,
        recalculateGridLines,
        containerWidth,
        setContainerWidth,
        showGridOverlay,
        setShowGridOverlay,
        snapThreshold,
        setSnapThreshold,
    }), [
        boundsMode,
        gridLines,
        recalculateGridLines,
        containerWidth,
        showGridOverlay,
        snapThreshold,
    ]);

    return (
        <GridContext.Provider value={value}>
            {children}
        </GridContext.Provider>
    );
};

export default GridContext;
