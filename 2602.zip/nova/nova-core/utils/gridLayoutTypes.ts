/* eslint-disable */
/**
 * Grid Layout Types for EBML-to-Grid Conversion
 * These types support the row-based grid layout algorithm that converts
 * absolute positioning (bounds) to responsive MUI Grid layout.
 */

import type { ParsedComponent, ComponentBounds } from '../types';

/**
 * Calculated grid position for a component within a row
 */
export interface GridPosition {
    /** Grid column start (0-11, which column the component starts at) */
    column: number;
    /** Grid column span (1-12, how many columns the component occupies) */
    span: number;
    /** Offset before this component (0-11, empty columns before this component) */
    offset: number;
}

/**
 * A group of components that belong to the same visual row
 * (based on Y coordinate proximity)
 */
export interface RowGroup {
    /** Y coordinate range start for this row */
    yStart: number;
    /** Y coordinate range end for this row */
    yEnd: number;
    /** Components in this row, sorted by X position */
    components: LayoutComponent[];
    /** Total row height (max height of components in row) */
    rowHeight: number;
}

/**
 * Component category for tolerance calculation
 */
export type ComponentLayoutCategory = 'Form' | 'Layout' | 'Other';

/**
 * A component with its calculated grid layout position
 * Can also represent a spacer (empty GridItem) when isSpacer is true
 */
export interface LayoutComponent {
    /** Reference to the original ParsedComponent (null for spacers) */
    original: ParsedComponent | null;
    /** Calculated grid position (column, span, offset) */
    gridPosition: GridPosition;
    /** Original bounds for reference (null for spacers) */
    bounds: ComponentBounds | null;
    /** Whether this is a spacer (empty GridItem) for gap handling */
    isSpacer?: boolean;
    /** Component category for tolerance calculation */
    category?: ComponentLayoutCategory;
}

/**
 * Configuration options for the grid layout algorithm
 */
export interface GridLayoutConfig {
    /** Number of grid columns (default: 12) */
    columns: number;
    /** Tolerance in pixels for row grouping (default: 15) */
    rowTolerance: number;
    /** Minimum gap in pixels to create an offset (default: 20) */
    minGapForOffset: number;
    /** Container width in pixels */
    containerWidth: number;
    /** Tolerance in pixels for form components spacer calculation (default: 15) */
    formComponentTolerance: number;
    /** Tolerance in pixels for layout components spacer calculation (default: 30) */
    layoutComponentTolerance: number;
}

/**
 * Result of the grid layout calculation
 */
export interface GridLayoutResult {
    /** Grouped rows with calculated grid positions */
    rows: RowGroup[];
    /** Configuration used for calculation */
    config: GridLayoutConfig;
}

/**
 * Props for GridItem
 */
export interface GridItemLayoutProps {
    /** Grid column span (1-12) */
    xs: number;
    /** Component key for React */
    key?: string;
}
