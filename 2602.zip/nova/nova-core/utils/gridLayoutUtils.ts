/* eslint-disable */
/**
 * Grid Layout Utilities
 * Algorithms for converting absolute positioning (bounds) to responsive MUI Grid layout.
 *
 * The main algorithm:
 * 1. Groups components by Y coordinate (row detection with tolerance)
 * 2. Within each row, sorts components by X coordinate
 * 3. Calculates grid column positions based on X position and width
 * 4. Uses empty spacer GridItems to handle gaps between components
 */

import type { ParsedComponent, ComponentBounds } from '../types';
import type {
    GridPosition,
    RowGroup,
    LayoutComponent,
    GridLayoutConfig,
    GridLayoutResult,
    GridItemLayoutProps,
    ComponentLayoutCategory
} from './gridLayoutTypes';
import { COMPONENT_REGISTRY } from '../registry/component-registry';
import { resolveComponentType } from './mappings';

/**
 * Default configuration for grid layout calculation
 */
const DEFAULT_CONFIG: GridLayoutConfig = {
    columns: 12,
    rowTolerance: 20,
    minGapForOffset: 30,
    containerWidth: 960,
    formComponentTolerance: 20,
    layoutComponentTolerance: 50
};

/**
 * Get the component category (Form, Layout, or Other) for tolerance calculation
 */
function getComponentCategory(component: ParsedComponent): ComponentLayoutCategory {
    const designType = COMPONENT_REGISTRY[component.type]
        ? component.type
        : resolveComponentType(component.type) || component.type;

    const config = COMPONENT_REGISTRY[designType];
    if (config) {
        if (config.category === 'Form') return 'Form';
        if (config.category === 'Layout') return 'Layout';
    }
    return 'Other';
}

/**
 * Groups components into rows based on Y coordinate with tolerance.
 * Components with Y values within tolerance are considered same row.
 *
 * @param components - Array of parsed components to group
 * @param config - Configuration options (partial, merged with defaults)
 * @returns Array of RowGroup, each containing components for that row
 */
export function groupComponentsByRow(
    components: ParsedComponent[],
    config: Partial<GridLayoutConfig> = {}
): RowGroup[] {
    const fullConfig = { ...DEFAULT_CONFIG, ...config };
    const { rowTolerance } = fullConfig;

    if (!components || components.length === 0) {
        return [];
    }

    // Sort by Y first to process top to bottom
    const sortedByY = [...components].sort((a, b) => {
        const aY = a.bounds?.y ?? 0;
        const bY = b.bounds?.y ?? 0;
        return aY - bY;
    });

    const rows: RowGroup[] = [];
    let currentRowComponents: ParsedComponent[] = [];
    let currentRowY = sortedByY[0].bounds?.y ?? 0;

    for (const component of sortedByY) {
        const componentY = component.bounds?.y ?? 0;

        // Check if this component belongs to current row (within tolerance)
        if (Math.abs(componentY - currentRowY) <= rowTolerance) {
            currentRowComponents.push(component);
        } else {
            // Finalize current row and start new one
            if (currentRowComponents.length > 0) {
                rows.push(createRowGroup(currentRowComponents, fullConfig));
            }
            currentRowComponents = [component];
            currentRowY = componentY;
        }
    }

    // Don't forget the last row
    if (currentRowComponents.length > 0) {
        rows.push(createRowGroup(currentRowComponents, fullConfig));
    }

    return rows;
}

/**
 * Creates a RowGroup from a list of components in the same row.
 * Sorts by X and calculates grid positions for each component.
 */
function createRowGroup(
    components: ParsedComponent[],
    config: GridLayoutConfig
): RowGroup {
    // Sort by X position (left to right)
    const sortedByX = [...components].sort((a, b) => {
        const aX = a.bounds?.x ?? 0;
        const bX = b.bounds?.x ?? 0;
        return aX - bX;
    });

    // Calculate Y range and max height
    const yValues = sortedByX.map(c => c.bounds?.y ?? 0);
    const heights = sortedByX.map(c => c.bounds?.height ?? 20);
    const yStart = Math.min(...yValues);
    const yEnd = Math.max(...yValues.map((y, i) => y + heights[i]));
    const rowHeight = Math.max(...heights);

    // Calculate grid positions for each component
    const layoutComponents = calculateRowGridPositions(sortedByX, config);

    return {
        yStart,
        yEnd,
        components: layoutComponents,
        rowHeight
    };
}

/**
 * Calculates grid positions for components in a single row.
 *
 * Algorithm:
 * - Treat row as 12 columns
 * - Column width = containerWidth / 12 (e.g., 960/12 = 80px)
 * - For each component:
 *   - Calculate start column from X position: startCol = floor(x / columnWidth)
 *   - Calculate end column from (x + width): endCol = ceil((x + width) / columnWidth)
 *   - Component span = endCol - startCol (minimum 1)
 *   - If there's a gap from previous component, add empty spacer GridItem
 */
function calculateRowGridPositions(
    components: ParsedComponent[],
    config: GridLayoutConfig
): LayoutComponent[] {
    const { columns, containerWidth } = config;
    const result: LayoutComponent[] = [];

    // Column width in pixels (e.g., 960/12 = 80px per column)
    const columnWidth = containerWidth / columns;

    // Track the current column position (where we are in the 12-column grid)
    let currentColumn = 0;

    for (let i = 0; i < components.length; i++) {
        const component = components[i];
        const nextComponent = components[i + 1];

        const x = component.bounds?.x ?? 0;
        let width = component.bounds?.width ?? 100;

        // Calculate effective width: if declared width overlaps with next component,
        // use the distance to next component instead
        if (nextComponent) {
            const nextX = nextComponent.bounds?.x ?? 0;
            if (x + width > nextX) {
                width = nextX - x;
            }
        }

        // Get component category
        const category = getComponentCategory(component);

        // Calculate the starting column for this component based on its X position
        const startColumn = Math.floor(x / columnWidth);

        // Calculate the ending column based on X + width
        const endColumn = Math.ceil((x + width) / columnWidth);

        // Component span is the difference (minimum 1)
        let span = Math.max(1, endColumn - startColumn);

        // If there's a gap between current position and this component's start,
        // add a spacer GridItem to fill it
        if (startColumn > currentColumn) {
            const spacerSpan = startColumn - currentColumn;
            if (spacerSpan > 0) {
                result.push({
                    original: null,
                    bounds: null,
                    isSpacer: true,
                    category: category,
                    gridPosition: {
                        column: currentColumn,
                        span: spacerSpan,
                        offset: 0
                    }
                });
                currentColumn += spacerSpan;
            }
        }

        // Add the actual component
        result.push({
            original: component,
            bounds: component.bounds,
            isSpacer: false,
            category: category,
            gridPosition: {
                column: startColumn,
                span: span,
                offset: 0
            }
        });

        // Update current column position to end of this component
        currentColumn = startColumn + span;
    }

    // Normalize: ensure total spans don't exceed 12
    return normalizeRowPositions(result, columns);
}

/**
 * Normalizes grid positions to ensure they don't exceed column count (12).
 * If total columns used exceeds max, scales down using floor rounding.
 * Handles both spacers and regular components.
 */
function normalizeRowPositions(
    components: LayoutComponent[],
    columns: number
): LayoutComponent[] {
    // Calculate total columns used (sum of all spans)
    const totalUsed = components.reduce(
        (sum, c) => sum + c.gridPosition.span,
        0
    );

    if (totalUsed <= columns) {
        return components;
    }

    // Need to scale down - calculate scale factor
    const scaleFactor = columns / totalUsed;

    // First pass: use floor to ensure we don't exceed 12
    const scaled = components.map(component => {
        const { span, column } = component.gridPosition;

        // Scale using floor, ensuring minimum span of 1 for non-spacers
        const minSpan = component.isSpacer ? 0 : 1;
        const newSpan = Math.max(minSpan, Math.floor(span * scaleFactor));

        return {
            ...component,
            gridPosition: {
                column,
                offset: 0,
                span: newSpan
            }
        };
    }).filter(c => c.gridPosition.span > 0); // Remove zero-span spacers

    // Calculate remaining columns after floor scaling
    const usedAfterFloor = scaled.reduce((sum, c) => sum + c.gridPosition.span, 0);
    let remaining = columns - usedAfterFloor;

    // Distribute remaining columns to non-spacer components (largest first)
    if (remaining > 0) {
        // Sort by original span (descending) to give extra columns to larger components
        const sortedIndices = scaled
            .map((c, i) => ({ index: i, isSpacer: c.isSpacer, originalSpan: components[i]?.gridPosition.span || 0 }))
            .filter(item => !item.isSpacer)
            .sort((a, b) => b.originalSpan - a.originalSpan);

        for (const item of sortedIndices) {
            if (remaining <= 0) break;
            scaled[item.index].gridPosition.span += 1;
            remaining--;
        }
    }

    return scaled;
}

/**
 * Main entry point: converts components to grid layout.
 *
 * @param components - Array of parsed components
 * @param containerWidth - Width of the container in pixels
 * @param config - Optional configuration overrides
 * @returns GridLayoutResult with grouped rows and config
 */
export function calculateGridLayout(
    components: ParsedComponent[],
    containerWidth: number,
    config: Partial<GridLayoutConfig> = {}
): GridLayoutResult {
    const fullConfig: GridLayoutConfig = {
        ...DEFAULT_CONFIG,
        ...config,
        containerWidth
    };

    const rows = groupComponentsByRow(components, fullConfig);

    return {
        rows,
        config: fullConfig
    };
}

/**
 * Utility: Get grid props for a component (for use in nova-schema-mapper).
 * Returns props object suitable for GridItem component.
 *
 * @param layoutComponent - Component with calculated grid position
 * @returns Props object with xs
 */
export function getGridItemProps(
    layoutComponent: LayoutComponent
): GridItemLayoutProps {
    return {
        xs: layoutComponent.gridPosition.span
    };
}

/**
 * Utility: Check if two components are in the same visual row.
 *
 * @param bounds1 - First component bounds
 * @param bounds2 - Second component bounds
 * @param tolerance - Y tolerance in pixels (default: 15)
 * @returns True if components are in same row
 */
export function areInSameRow(
    bounds1: ComponentBounds,
    bounds2: ComponentBounds,
    tolerance: number = DEFAULT_CONFIG.rowTolerance
): boolean {
    const y1 = bounds1?.y ?? 0;
    const y2 = bounds2?.y ?? 0;
    return Math.abs(y1 - y2) <= tolerance;
}

/**
 * Utility: Get effective width of a component.
 * Checks bounds.width first, then pageSize property.
 *
 * @param component - Parsed component
 * @returns Width in pixels
 */
export function getEffectiveWidth(component: ParsedComponent): number {
    // First check if bounds has a valid width
    if (component.bounds && component.bounds.width > 0) {
        return component.bounds.width;
    }

    // If bounds is 0, check for pageSize property (format: "width,height")
    if (component.properties?.pageSize) {
        const pageSize = String(component.properties.pageSize);
        const [width] = pageSize.split(',').map(Number);
        if (width && width > 0) {
            return width;
        }
    }

    // Fallback to bounds width (even if 0)
    return component.bounds?.width || 0;
}
