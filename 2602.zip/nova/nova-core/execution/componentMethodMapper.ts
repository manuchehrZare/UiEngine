/* eslint-disable */
/**
 * Component Method Mapper
 * Maps legacy EBML method calls to React component implementations
 *
 * This module provides the execution bridge between the legacy method definitions
 * in COMPONENT_TO_METHOD_MAP and the actual React component state/behavior.
 */

import type { DesignComponent } from '../types/nova-ui-schema.types';

/**
 * Interface for component method implementation
 * Each method receives the component ID, component state getter/setter, and arguments
 */
export type ComponentMethodImplementation = (
    componentId: string,
    getComponentState: (id: string) => any,
    setComponentState: (id: string, state: any) => void,
    invokeComponentMethod: (id: string, method: string, ...args: any[]) => any,
    getVariable: (name: string) => any,
    setVariable: (name: string, value: any) => void,
    ...args: any[]
) => any;

/**
 * Registry of method implementations by component type
 * Structure: { [componentType]: { [methodName]: implementation } }
 */
export const COMPONENT_METHOD_IMPLEMENTATIONS: Record<string, Record<string, ComponentMethodImplementation>> = {
    // Input Component Methods
    'Input': {
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.value || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, text: string) => {
            setComponentState(componentId, { value: text });
        },
        'appendText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, text: string) => {
            const currentValue = getComponentState(componentId)?.value || '';
            setComponentState(componentId, { value: currentValue + text });
        },
        'setEditable': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, editable: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), readOnly: !editable });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setReadOnly': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, readOnly: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), readOnly });
        },
        'setBackground': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, color: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), backgroundColor: color });
        },
        'setForeground': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, color: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), color });
        },
        'grabFocus': (componentId, getComponentState, setComponentState) => {
            setComponentState(componentId, { ...getComponentState(componentId), focused: true });
        },
    },

    // NumberInput Component Methods (similar to Input)
    'NumberInput': {
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.value || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, text: string) => {
            setComponentState(componentId, { value: text });
        },
        'setEditable': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, editable: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), readOnly: !editable });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
    },

    // Button Component Methods
    'SetButton': {
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.text || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, text: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), text });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setBackground': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, color: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), backgroundColor: color });
        },
        'grabFocus': (componentId, getComponentState, setComponentState) => {
            setComponentState(componentId, { ...getComponentState(componentId), focused: true });
        },
    },

    // Label Component Methods
    'Label': {
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.text || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, text: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), text });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
        'setForeground': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, color: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), color });
        },
    },

    // Checkbox Component Methods
    'Checkbox': {
        'isSelected': (componentId, getComponentState) => {
            return getComponentState(componentId)?.checked || false;
        },
        'setSelected': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, selected: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), checked: selected });
        },
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.label || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, text: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), label: text });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
    },

    // Select Component Methods
    'Select': {
        'getSelectedValue': (componentId, getComponentState) => {
            return getComponentState(componentId)?.value;
        },
        'setSelectedValue': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, value: any) => {
            setComponentState(componentId, { ...getComponentState(componentId), value });
        },
        'getSelectedText': (componentId, getComponentState) => {
            const state = getComponentState(componentId);
            const options = state?.options || [];
            const value = state?.value;
            const option = options.find((opt: any) => opt.value === value);
            return option?.label || '';
        },
        'addItem': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, label: string, value: any) => {
            const state = getComponentState(componentId);
            const options = [...(state?.options || []), { label, value }];
            setComponentState(componentId, { ...state, options });
        },
        'clear': (componentId, getComponentState, setComponentState) => {
            setComponentState(componentId, { ...getComponentState(componentId), options: [], value: null });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
    },

    // TableComponent Methods
    'TableComponent': {
        'getValueAt': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, row: number, col: number) => {
            const rows = getComponentState(componentId)?.rows || [];
            return rows[row]?.[col];
        },
        'setValueAt': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, row: number, col: number, value: any) => {
            const state = getComponentState(componentId);
            const rows = [...(state?.rows || [])];
            if (rows[row]) {
                rows[row] = [...rows[row]];
                rows[row][col] = value;
                setComponentState(componentId, { ...state, rows });
            }
        },
        'addRow': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, ...rowData: any[]) => {
            const state = getComponentState(componentId);
            const rows = [...(state?.rows || []), rowData];
            setComponentState(componentId, { ...state, rows });
        },
        'deleteRow': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, rowIndex: number) => {
            const state = getComponentState(componentId);
            const rows = [...(state?.rows || [])];
            rows.splice(rowIndex, 1);
            setComponentState(componentId, { ...state, rows });
        },
        'clear': (componentId, getComponentState, setComponentState) => {
            setComponentState(componentId, { ...getComponentState(componentId), rows: [] });
        },
        'getSelectedRow': (componentId, getComponentState) => {
            return getComponentState(componentId)?.selectedRow || -1;
        },
        'setSelectedRow': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, rowIndex: number) => {
            setComponentState(componentId, { ...getComponentState(componentId), selectedRow: rowIndex });
        },
        'setContent': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, data: any[][]) => {
            setComponentState(componentId, { ...getComponentState(componentId), rows: data });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
    },

    // Page Component Methods
    'Page': {
        'setTitle': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, title: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), title });
        },
        'setDirty': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, dirty: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), dirty });
        },
        'isDirty': (componentId, getComponentState) => {
            return getComponentState(componentId)?.dirty || false;
        },
        'setEnableAll': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            // This would recursively enable/disable all child components
            setComponentState(componentId, { ...getComponentState(componentId), enableAll: enabled });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
    },

    // Container Component Methods
    'Container': {
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setEnableAll': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), enableAll: enabled });
        },
        'setTitle': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, title: string) => {
            setComponentState(componentId, { ...getComponentState(componentId), title });
        },
    },

    // DatePicker Component Methods
    'DatePicker': {
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.value || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, date: string) => {
            setComponentState(componentId, { value: date });
        },
        'setEditable': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, editable: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), readOnly: !editable });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
    },

    // Currency Component Methods
    'Currency': {
        'getText': (componentId, getComponentState) => {
            return getComponentState(componentId)?.value || '';
        },
        'setText': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, value: string) => {
            setComponentState(componentId, { value });
        },
        'setEditable': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, editable: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), readOnly: !editable });
        },
        'setVisible': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, visible: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), visible });
        },
        'setEnabled': (componentId, getComponentState, setComponentState, invokeComponentMethod, getVariable, setVariable, enabled: boolean) => {
            setComponentState(componentId, { ...getComponentState(componentId), disabled: !enabled });
        },
    },
};

/**
 * Creates a method executor function that can be registered with the component method registry
 */
export function createMethodExecutor(
    componentId: string,
    componentType: string,
    methodName: string,
    getComponentState: (id: string) => any,
    setComponentState: (id: string, state: any) => void,
    invokeComponentMethod: (id: string, method: string, ...args: any[]) => any,
    getVariable: (name: string) => any,
    setVariable: (name: string, value: any) => void
): Function {
    const implementation = COMPONENT_METHOD_IMPLEMENTATIONS[componentType]?.[methodName];

    if (!implementation) {
        // Return a no-op function for unimplemented methods
        return (...args: any[]) => {
            console.warn(`Method ${methodName} not implemented for component type ${componentType}`);
            return undefined;
        };
    }

    // Return a function that calls the implementation with all necessary context
    return (...args: any[]) => {
        return implementation(
            componentId,
            getComponentState,
            setComponentState,
            invokeComponentMethod,
            getVariable,
            setVariable,
            ...args
        );
    };
}

/**
 * Registers all methods for a component based on its type
 */
export function registerAllComponentMethods(
    componentId: string,
    componentType: string,
    registerComponentMethod: (id: string, method: string, fn: Function) => void,
    getComponentState: (id: string) => any,
    setComponentState: (id: string, state: any) => void,
    invokeComponentMethod: (id: string, method: string, ...args: any[]) => any,
    getVariable: (name: string) => any,
    setVariable: (name: string, value: any) => void
): void {
    const methodImplementations = COMPONENT_METHOD_IMPLEMENTATIONS[componentType];

    if (!methodImplementations) {
        // console.warn(`No method implementations found for component type: ${componentType}`);
        return;
    }

    // Register each method
    Object.keys(methodImplementations).forEach(methodName => {
        const executor = createMethodExecutor(
            componentId,
            componentType,
            methodName,
            getComponentState,
            setComponentState,
            invokeComponentMethod,
            getVariable,
            setVariable
        );
        registerComponentMethod(componentId, methodName, executor);
    });
}
