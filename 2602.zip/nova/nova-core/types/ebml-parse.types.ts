/* eslint-disable */
export interface ComponentBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface ParsedComponent {
    id: string;
    type: string;
    bounds: ComponentBounds;
    properties: Record<string, any>;
    children?: ParsedComponent[];
}
