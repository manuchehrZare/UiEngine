/* eslint-disable */
/**
 * TabPage Component
 * Renders EBML JCSTabPage components (individual tab page within TabbedPane)
 * Uses Grid container to properly layout children (panels side by side as columns)
 */

import React from 'react';
import { Grid } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const TabPageComponent: React.FC<NovaComponentProps> = ({
    children
}) => {
    // TabPage wraps children in a Grid container so GridItem children layout properly
    // This allows side-by-side panels to display as columns instead of rows
    return (
        <Grid container spacing={1} sx={{ height: '100%', width: '100%' }}>
            {children}
        </Grid>
    );
};
