/* eslint-disable */
/**
 * HandleButtonField Component
 * Renders EBML HandleButtonField - Text field with button
 * Supports both absolute positioning and responsive grid layout
 * Opens a dynamic modal when button is clicked based on popup property
 */

import React, { useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { GridItem, Input, Box, Tooltip, Button }   from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { boundsToGridSize } from '..';
import { MoreHoriz } from '@mui/icons-material';
import DynamicModal from './DynamicModal';

export const HandleButtonFieldComponent: React.FC<NovaComponentProps> = ({
    id,
    name,
    text,
    value,
    label,
    fieldLabel,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    popup,
    xs,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;
    const containerWidth = parentBounds?.width || 960;
    const fieldId = name || id?.split('.').pop() || 'handlefield';

    // State for managing modal visibility
    const [showModal, setShowModal] = useState(false);

    // Handler for opening the modal
    const handleOpenModal = () => {
        if (popup) {
            setShowModal(true);
        } else {
            console.warn('HandleButtonFieldComponent: No popup property defined');
        }
    };

    // Handler for closing the modal
    const handleCloseModal = () => {
        setShowModal(false);
    };

    // Filter out props that shouldn't be passed to Input component
    const { type, enabled, designComponent, component, componentKey, allPages, regionName, ...inputProps } = props;

    const handleButtonContent = (
        <>
            <Input
                name={fieldId}
                sx={{
                    input: {
                        textTransform: 'uppercase',
                    },
                }}
                control={control as any}
                readOnly
                label={label || fieldLabel}
                labelPlacement='start'
                endAdornment={
                    <Box sx={{ mr: '-5px' }}>
                        <Tooltip title={popup ? 'Open details' : 'No popup configured'}>
                            <Button
                                name='openModalBtn'
                                iconButton
                                icon={<MoreHoriz />}
                                onClick={handleOpenModal}
                                disabled={!popup}
                            />
                        </Tooltip>
                    </Box>
                }
                {...inputProps}
            />
            <DynamicModal
                showModal={showModal}
                onClose={handleCloseModal}
                pageId={popup}
                title={text || label || fieldLabel || 'Details'}
                maxWidth="md"
            />
        </>
    );

    if (useAbsolutePositioning) {
        return handleButtonContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {handleButtonContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
            xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {handleButtonContent}
        </GridItem>
    );
};
