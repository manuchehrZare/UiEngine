/* eslint-disable */
/**
 * FileSelector Component Wrapper
 * Wraps the lib FileSelector component to handle EBML property conversions
 * and ensure all required properties have safe defaults
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { FileSelector } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const FileSelectorComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;

    const safeProps = {
        ...props,
        label: label || '',
        name: name || id || '',
        control: control as any,
        component: 'Input' as const,
    };

    return <FileSelector {...(safeProps as any)} />;
};
