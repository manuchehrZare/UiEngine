/* eslint-disable */
/**
 * Engine Debug Panel
 * Reusable debug panel for inspecting and testing the page engine
 * Now with draggable functionality and log viewer
 */

import React, { useState, useRef, useEffect } from 'react';
import {  Tabs, Tab } from '@mui/material';
import { Box, Paper, Typography, Grid, GridItem, Button } from '../../../seker-ui-lib'
import { useNova } from '../context/NovaContext';
import { useLogCenter } from '../context/LogCenterContext';
import { PestControl, DragIndicator, Close } from '@mui/icons-material';
import { LogViewer } from './LogViewer';

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
}

const TabPanel: React.FC<TabPanelProps> = ({ children, value, index }) => {
    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            style={{ height: value === index ? 'calc(100% - 48px)' : 0, overflow: 'hidden' }}
        >
            {value === index && children}
        </div>
    );
};

export const EngineDebugPanel: React.FC = () => {
    const engine = useNova();
    const { logs } = useLogCenter();
    const [showDebug, setShowDebug] = useState(false);
    const [activeTab, setActiveTab] = useState(0);
    const [position, setPosition] = useState({ x: window.innerWidth - 420, y: 64 });
    const [dragging, setDragging] = useState(false);
    const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
    const panelRef = useRef<HTMLDivElement>(null);

    const variables = Array.from(engine.variables.entries());
    const componentStates = Array.from(engine.componentStates.entries());

    // Use designer actions/rules if available, otherwise fall back to schema
    const allActions = engine.actions?.length > 0
        ? engine.actions
        : (engine.schema?.events?.actions || []);

    // Filter to show only actions with type 'action' (not event bindings)
    const actions = allActions.filter(action => action.type === 'action');

    const rules = engine.rules?.length > 0
        ? engine.rules
        : (engine.schema?.ruleset?.rules || []);

    // Dragging logic
    const handleMouseDown = (e: React.MouseEvent) => {
        if ((e.target as HTMLElement).closest('.drag-handle')) {
            setDragging(true);
            setDragOffset({
                x: e.clientX - position.x,
                y: e.clientY - position.y
            });
        }
    };

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (dragging) {
                const newX = Math.max(0, Math.min(window.innerWidth - 400, e.clientX - dragOffset.x));
                const newY = Math.max(0, Math.min(window.innerHeight - 200, e.clientY - dragOffset.y));
                setPosition({ x: newX, y: newY });
            }
        };

        const handleMouseUp = () => {
            setDragging(false);
        };

        if (dragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }

        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [dragging, dragOffset]);

    return (
        <>
            <Button
                variant={showDebug ? "contained" : "outlined"}
                iconRight={<PestControl />}
                onClick={() => setShowDebug(!showDebug)}
                text="Engine Debug"
                sx={{ mr: 1, whiteSpace: 'nowrap' }}
            />

            {showDebug && (
                <Paper
                    ref={panelRef}
                    onMouseDown={handleMouseDown}
                    sx={{
                        position: 'fixed',
                        left: position.x,
                        top: position.y,
                        width: 500,
                        height: 'calc(100vh - 100px)',
                        maxHeight: '80vh',
                        zIndex: 1300,
                        display: 'flex',
                        flexDirection: 'column',
                        overflow: 'hidden',
                        boxShadow: 6,
                        cursor: dragging ? 'grabbing' : 'default'
                    }}
                >
                    {/* Header with drag handle */}
                    <Box
                        className="drag-handle"
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            p: 1.5,
                            borderBottom: '1px solid #e0e0e0',
                            bgcolor: '#f5f5f5',
                            cursor: 'grab',
                            '&:active': {
                                cursor: 'grabbing'
                            }
                        }}
                    >
                        <DragIndicator sx={{ color: '#999', mr: 1 }} />
                        <Typography variant="h6" sx={{ flexGrow: 1 }}>
                            Engine Debug
                        </Typography>
                        <Typography variant="caption" sx={{ color: 'text.secondary', mr: 2 }}>
                            {logs.length} logs
                        </Typography>
                        <Button size="small"    iconRight={<Close/>}   variant="outlined" onClick={() => setShowDebug(false)} text="Close" />
                           

                    </Box>

                    {/* Tabs */}
                    <Tabs
                        value={activeTab}
                        onChange={(_, newValue) => setActiveTab(newValue)}
                        sx={{ borderBottom: '1px solid #e0e0e0', minHeight: 40 }}
                    >
                        <Tab label="Actions & Rules" sx={{ minHeight: 40, py: 1 }} />
                        <Tab label={`Logs (${logs.length})`} sx={{ minHeight: 40, py: 1 }} />
                    </Tabs>

                    {/* Tab Panels */}
                    <TabPanel value={activeTab} index={0}>
                        <Box sx={{ height: '100%', overflow: 'auto', p: 2 }}>
                            <Typography variant="subtitle2" gutterBottom>
                                Lifecycle: <strong>{engine.lifecyclePhase}</strong>
                            </Typography>

                            <Typography variant="subtitle2" sx={{ mt: 2 }}>
                                Variables ({engine.schema?.data?.var?.length || 0})
                            </Typography>
                            <Box sx={{ maxHeight: 120, overflow: 'auto', bgcolor: '#f5f5f5', p: 1, fontSize: '0.75rem' }}>
                                {engine.schema?.data?.var?.map((item) => (
                                    <div key={item.name}>
                                        <strong>{item.name}</strong>: {item.type} = {JSON.stringify(item.initialValue)}
                                    </div>
                                ))}
                            </Box>

                            <Typography variant="subtitle2" sx={{ mt: 2 }}>
                                Actions ({actions.length})
                            </Typography>
                            <Box sx={{ maxHeight: 120, overflow: 'auto', bgcolor: '#f5f5f5', p: 1 }}>
                                {actions.map((action) => (
                                    <Box key={action.id} sx={{ mb: 1 }}>
                                        <Button
                                            size="small"
                                            variant="outlined"
                                            fullWidth
                                            onClick={() => {
                                                console.log(`[Debug] Executing action: ${action.name}`);
                                                engine.executeAction(action.id);
                                            }}
                                            text={action.name}
                                        />
                                    </Box>
                                ))}
                            </Box>

                            <Typography variant="subtitle2" sx={{ mt: 2 }}>
                                Rules ({rules.length})
                            </Typography>
                            <Box sx={{ maxHeight: 120, overflow: 'auto', bgcolor: '#f5f5f5', p: 1, fontSize: '0.75rem' }}>
                                {rules.map((rule) => (
                                    <Box key={rule.id} sx={{ mb: 0.5, display: 'flex', alignItems: 'center', gap: 1 }}>
                                        <Typography variant="caption" sx={{ flexGrow: 1 }}>
                                            {rule.name} ({rule.type})
                                        </Typography>
                                        <Button
                                            size="small"
                                            onClick={async () => {
                                                const result = await engine.evaluateRule(rule.id);
                                                console.log(`[Debug] Rule ${rule.name} evaluated to:`, result);
                                                alert(`Rule "${rule.name}" = ${result}`);
                                            }}
                                            text="Test"
                                        />
                                    </Box>
                                ))}
                            </Box>
                            <Typography variant="subtitle2" sx={{ mt: 2 }}>
                                Definitions ({engine.schema?.data?.definitions?.length || 0})
                            </Typography>
                            <Box sx={{ maxHeight: 150, overflow: 'auto', bgcolor: '#f5f5f5', p: 1, fontSize: '0.75rem' }}>
                                {engine.schema?.data?.definitions?.map((def) => (
                                    <Box key={def.id} sx={{ mb: 1, pb: 1, borderBottom: '1px solid #ddd' }}>
                                        <div><strong>ID:</strong> {def.id}</div>
                                        {def.options && def.options.length > 0 && (
                                            <div style={{ marginLeft: '8px', marginTop: '4px' }}>
                                                <em>Options:</em>
                                                <ul style={{ margin: '4px 0', paddingLeft: '20px' }}>
                                                    {def.options.map((opt, idx) => (
                                                        <li key={idx}>
                                                            {opt.value}: {opt.text}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                        {def.columnDefinitions && def.columnDefinitions.length > 0 && (
                                            <div style={{ marginLeft: '8px', marginTop: '4px' }}>
                                                <em>Column Definitions:</em>
                                                {def.columnDefinitions.map((col, colIdx) => (
                                                    <Box key={colIdx} sx={{ ml: 1, mt: 0.5 }}>
                                                        <strong>{col.columnId}:</strong>
                                                        <ul style={{ margin: '2px 0', paddingLeft: '20px' }}>
                                                            {col.options.map((opt, optIdx) => (
                                                                <li key={optIdx}>
                                                                    {opt.value}: {opt.text}
                                                                </li>
                                                            ))}
                                                        </ul>
                                                    </Box>
                                                ))}
                                            </div>
                                        )}
                                    </Box>
                                ))}
                                {(!engine.schema?.data?.definitions || engine.schema.data.definitions.length === 0) && (
                                    <div style={{ color: '#999', fontStyle: 'italic' }}>No definitions found</div>
                                )}
                            </Box>
                        </Box>
                    </TabPanel>

                    <TabPanel value={activeTab} index={1}>
                        <LogViewer />
                    </TabPanel>
                </Paper>
            )}
        </>
    );
};
