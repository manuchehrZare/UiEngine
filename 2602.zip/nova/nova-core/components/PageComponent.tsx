/* eslint-disable */
/**
 * Page Component
 * Renders EBML Page components (root container).
 * If popupMenuName is set, wraps content in ContextMenuWrapper to provide right-click menu.
 *
 * Phase 5: pageKeyEvent — keyboard events on the page are now routed through fireEvent
 */

import React, { useEffect } from 'react';
import { Box, Grid, Paper } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { ContextMenuWrapper } from './ContextMenuWrapper';
import { useNovaOptional } from '../context/NovaContext';


export const PageComponent: React.FC<NovaComponentProps> = ({
    id,
    bounds: _bounds,
    pageSize: _pageSize,
    pageWidth: _propPageWidth,
    pageHeight: propPageHeight,
    backgroundColor: _backgroundColor,
    children,
    designComponent: _designComponent,
    component: _component,
    allPages: _allPages,
    useAbsolutePositioning: _useAbsolutePositioning = false,
    popupMenuName,
}) => {
    // Phase 5: wire pageKeyEvent — listen for keyboard events and fire through Nova
    const nova = useNovaOptional();

    useEffect(() => {
        if (!nova?.fireEvent || !id) return;

        const handler = (e: KeyboardEvent) => {
            // Check schema for listeners before dispatching
            nova.fireEvent(id, 'pageKeyEvent', {
                key: e.key,
                keyCode: e.keyCode,
                ctrlKey: e.ctrlKey,
                shiftKey: e.shiftKey,
                altKey: e.altKey,
            });
        };

        window.addEventListener('keydown', handler);
        return () => window.removeEventListener('keydown', handler);
    }, [id, nova?.fireEvent]);

    const content = (
        <Paper sx={{ width: '100%', p: 2 }}>
            <Grid
                minHeight={propPageHeight}
                height="100%"
                display="flex"
                justifyContent="center"
                alignItems="flex-start"
            >
                <Box sx={{ width: '100%' }}>
                    {children}
                </Box>
            </Grid>
        </Paper>
    );

    if (popupMenuName) {
        return (
            <ContextMenuWrapper popupMenuName={popupMenuName}>
                {content}
            </ContextMenuWrapper>
        );
    }

    return content;
}
