/* eslint-disable */
/**
 * Dropdown Button Component
 * Renders EBML JCSDropdownButton components as Material UI ButtonGroup with dropdown
 * Maps to Material UI split button pattern
 */

import React, { useState, useRef } from 'react';
import { 
    Button, 
    ButtonGroup, 
    GridItem,
    MenuList,
    MenuItem
} from '../../../seker-ui-lib';
import { 
    Popper,
    Grow,
    Paper,
    ClickAwayListener
} from '@mui/material';
import { ArrowDropDown as ArrowDropDownIcon } from '@mui/icons-material';
import type { NovaComponentProps } from '..';
import { boundsToGridSize } from '..';
import { useNovaComponent } from '../hooks/useComponentRuntime';
import { useNovaOptional } from '../context/NovaContext';


export const DropdownButtonComponent: React.FC<NovaComponentProps> = ({
    id,
    text,
    label,
    enabled,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    popupMenuName,
    xs,
    ...props
}) => {
    // Use Nova runtime hook to get event handlers attached
    const runtimeProps = useNovaComponent(id, 'DropdownButton', props);
    const context = useNovaOptional();
    
    const [open, setOpen] = useState(false);
    const anchorRef = useRef<HTMLDivElement>(null);
    const [selectedIndex, setSelectedIndex] = useState(0);

    const containerWidth = parentBounds?.width || 960;
    const buttonText = text || label || '';

    // Resolve menu items from the popup menu registry via popupMenuName.
    // JCSDropdownButton stores its items as a JCSPopupMenu referenced by name,
    // which is collected into schema.popupMenus during EBML conversion.
    const menu = popupMenuName && context ? context.getPopupMenu(popupMenuName) : undefined;
    const menuItems: Array<{ id: string; text: string; enabled: boolean }> = menu?.items ?? props.menuItems ?? [];

    const handleMenuItemClick = (
        event: React.MouseEvent<HTMLLIElement, MouseEvent>,
        index: number,
    ) => {
        setSelectedIndex(index);
        setOpen(false);
        
        // Trigger the menu item's action if available
        const menuItem = menuItems[index];
        if (menuItem && context) {
            // Execute the action for this menu item
            context.fireEvent(menuItem.id, 'actionPerformed', event);
        }
    };

    const handleToggle = () => {
        setOpen((prevOpen) => !prevOpen);
    };

    const handleClose = (event: Event) => {
        if (
            anchorRef.current &&
            anchorRef.current.contains(event.target as HTMLElement)
        ) {
            return;
        }
        setOpen(false);
    };

    const handleClick = () => {
        // Execute the main button action (currently selected menu item)
        if (menuItems.length > 0 && context) {
            const menuItem = menuItems[selectedIndex];
            if (menuItem) {
                context.fireEvent(menuItem.id, 'actionPerformed', {});
            }
        }
        
        // Also trigger the button's own event if available
        if (runtimeProps.onClick) {
            runtimeProps.onClick({} as any);
        }
    };

    const buttonContent = (
        <React.Fragment>
            <ButtonGroup
                ref={anchorRef}
                disabled={enabled === 'false' || enabled === false}
                sx={{
                    minWidth: '120px',
                    width: '100%',
                    height: '100%',
                }}
            >
                <Button 
                    onClick={handleClick}
                    fullWidth
                    text={menuItems.length > 0 ? menuItems[selectedIndex].text : buttonText}
                    sx={{textWrap:'nowrap'}}
                />
                <Button
                    iconButton
                    aria-controls={open ? 'split-button-menu' : undefined}
                    aria-expanded={open ? 'true' : undefined}
                    aria-haspopup="menu"
                    onClick={handleToggle}
                    iconLeft={<ArrowDropDownIcon />}
                />
            </ButtonGroup>
            <Popper
                sx={{ 
                    zIndex: 9999 // Very high z-index to appear above all components
                }}
                open={open}
                anchorEl={anchorRef.current}
                role={undefined}
                transition
                placement="bottom-start"
            >
                {({ TransitionProps, placement }) => (
                    <Grow
                        {...TransitionProps}
                        style={{
                            transformOrigin:
                                placement === 'bottom' ? 'center top' : 'center bottom',
                        }}
                    >
                        <Paper>
                            <ClickAwayListener onClickAway={handleClose}>
                                <MenuList id="split-button-menu" autoFocusItem>
                                    {menuItems.map((option, index) => (
                                        <MenuItem
                                            key={option.id}
                                            disabled={!option.enabled}
                                            selected={index === selectedIndex}
                                            onClick={(event) => handleMenuItemClick(event, index)}
                                        >
                                            {option.text}
                                        </MenuItem>
                                    ))}
                                </MenuList>
                            </ClickAwayListener>
                        </Paper>
                    </Grow>
                )}
            </Popper>
        </React.Fragment>
    );

    if (useAbsolutePositioning) {
        return buttonContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {buttonContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    
    return (
        <GridItem
            xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {buttonContent}
        </GridItem>
    );
};

