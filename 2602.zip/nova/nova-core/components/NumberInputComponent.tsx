/* eslint-disable */
/**
 * NumberInput Component Wrapper
 * Wraps the lib NumberInput component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { NumberInput } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const NumberInputComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;

    // Ensure string properties are never undefined to prevent errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `numberinput_${Math.random().toString(36).substring(2, 11)}`;

    const resolvedThousandSeparator =
        typeof props.thousandSeparator === 'boolean'
            ? props.thousandSeparator
                ? ','
                : undefined
            : props.thousandSeparator;

    const resolvedDecimalSeparator =
        resolvedThousandSeparator === '.' && (props.decimalSeparator === '.' || props.decimalSeparator === undefined)
            ? ','
            : props.decimalSeparator;

    const safeProps = {
        ...props,
        label: label || '',
        name: safeName,
        value: value !== undefined ? value : null, // NumberInput expects null for empty, not undefined
        control: control as any,
        thousandSeparator: resolvedThousandSeparator,
        decimalSeparator: resolvedDecimalSeparator,
    };

    return <NumberInput {...(safeProps as any)} />;
};
