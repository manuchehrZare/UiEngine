/* eslint-disable */
/**
 * TabbedPane Component
 * Renders EBML TabbedPane components with custom Tab and TabItem components
 * Supports both absolute positioning and responsive grid layout
 *
 * Lifecycle events implemented:
 * - Phase 3: TabPage.pageLoad — fired when a tab first becomes active
 * - Phase 4: TabbedPane.stateChanged — fired via fireEvent on tab change
 */

import React, { useCallback, useEffect, useRef } from 'react';
import { Paper, Tab, TabItem, Box } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { useNovaOptional } from '../context/NovaContext';

export const TabbedPaneComponent: React.FC<NovaComponentProps> = ({
    id,
    bounds,
    useAbsolutePositioning = false,
    children,
    designComponent,
}) => {
    const [value, setValue] = React.useState(0);

    // Phase 3 & 4: access Nova context (optional — safe in both design/preview modes)
    const nova = useNovaOptional();

    // Track which TabPage ids have already received pageLoad (fire only once per tab)
    const firedPageLoads = useRef<Set<string>>(new Set());

    // Use designComponent to inspect children definitions for tab titles
    const tabDefinitions = designComponent?.children || [];
    const childArray = React.Children.toArray(children);

    /**
     * Fire pageLoad for the currently active TabPage (Phase 3).
     * Only fires the first time a tab becomes active (matches legacy Swing behaviour).
     */
    const fireTabPageLoad = useCallback((tabIndex: number) => {
        if (!nova?.fireEvent) return;
        const tabDef = tabDefinitions[tabIndex];
        if (!tabDef) return;
        // Only fire once per tab session (legacy JCS fires pageLoad once per open)
        if (!firedPageLoads.current.has(tabDef.id)) {
            firedPageLoads.current.add(tabDef.id);
            nova.fireEvent(tabDef.id, 'pageLoad');
        }
    }, [nova, tabDefinitions]);

    // Fire pageLoad for the initial (first) tab when it is first displayed
    useEffect(() => {
        if (tabDefinitions.length > 0) {
            fireTabPageLoad(0);
        }
    }, []); // Only on mount — intentionally empty deps

    const handleChange = (newValue: number) => {
        setValue(newValue);

        // Phase 4: fire TabbedPane stateChanged via Nova event system
        if (nova?.fireEvent && id) {
            nova.fireEvent(id, 'stateChanged', { tabIndex: newValue });
        }

        // Phase 3: fire pageLoad for the newly active TabPage
        fireTabPageLoad(newValue);
    };

    // Calculate tab content height (total height minus tabs header)
    const tabHeaderHeight = 48;
    const contentHeight = bounds ? bounds.height - tabHeaderHeight : 400;

    return (
        <Paper
            sx={{
                width: '100%',
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                boxSizing: 'border-box',
            }}
        >
            <Tab
                value={value}
                onChange={handleChange}
                variant="scrollable"
                sx={{ borderBottom: 1, borderColor: 'divider', minHeight: tabHeaderHeight }}
            >
                {tabDefinitions.map((childDef, index) => {
                    const childProps = childDef.props || {};
                    const tabLabel = childProps.title || childProps.tabTitle || childProps.label || childProps.text || childProps.name || `Tab ${index + 1}`;
                    return <TabItem key={childDef.id} text={tabLabel} value={index} />;
                })}
                 {/* Fallback if no designComponent but we have children (legacy mode unlikely here) */}
                {tabDefinitions.length === 0 && childArray.map((_, index) => (
                    <TabItem key={index} text={`Tab ${index + 1}`} value={index} />
                ))}
            </Tab>

            {childArray.map((child, index) => {
                // Each child in childArray corresponds to a TabPage (one tab content per child)
                // Only show the child that matches the active tab index
                return (
                    <Box
                        key={index}
                        hidden={value !== index}
                        sx={{
                            position: 'relative',
                            width: '100%',
                            height: useAbsolutePositioning ? `${contentHeight}px` : 'auto',
                            flex: useAbsolutePositioning ? undefined : 1,
                            overflow: 'auto',
                            p: 1
                        }}
                    >
                        {child}
                    </Box>
                );
            })}
        </Paper>
    );
};
