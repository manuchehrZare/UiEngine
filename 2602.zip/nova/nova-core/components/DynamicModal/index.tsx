/* eslint-disable */
/**
 * DynamicModal Component
 * Renders a modal with dynamic content loaded from a page schema
 * Similar to RegionComponent but designed for modal display
 */

import React, { useState, useEffect } from 'react';
import type { FC, JSX } from 'react';
import { Box, Modal, ModalBody, ModalTitle } from '../../../../seker-ui-lib';
import type { NovaUiSchema } from '../../types/nova-ui-schema.types';
import { PreviewRenderer } from '../../../nova-studio/components/PreviewRenderer';
import { getScreenEbmlSchema } from '../../nova-ebml/ebml-schema-provider';
import { convertNovaEbmlToNovaUiSchema } from '../../nova-ebml/nova-ebml-converter';

export interface IDynamicModalProps {
    showModal: boolean;
    onClose: () => void;
    pageId?: string;
    title?: string;
    maxWidth?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
}

const DynamicModal: FC<IDynamicModalProps> = ({
    showModal,
    onClose,
    pageId,
    title = 'Information',
    maxWidth = 'sm'
}): JSX.Element => {
    const [pageSchema, setPageSchema] = useState<NovaUiSchema | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadPageSchema = async () => {
            if (!pageId) {
                setPageSchema(null);
                setError('No page ID specified');
                return;
            }

            setIsLoading(true);
            setError(null);

            try {
                const pageEbml = await getScreenEbmlSchema(pageId);
                if (pageEbml) {
                    const convertedSchema = convertNovaEbmlToNovaUiSchema(pageEbml);
                    setPageSchema(convertedSchema);
                } else {
                    setPageSchema(null);
                    setError(`Page not found: ${pageId}`);
                }
            } catch (err) {
                console.error('Error loading page schema:', err);
                setPageSchema(null);
                setError(`Error loading page: ${pageId}`);
            } finally {
                setIsLoading(false);
            }
        };

        if (showModal && pageId) {
            loadPageSchema();
        }
    }, [showModal, pageId]);

    const renderModalContent = () => {
        // Loading state
        if (isLoading) {
            return (
                <Box sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    minHeight: 200,
                    p: 2
                }}>
                    <Box textAlign="center">Loading {pageId}...</Box>
                </Box>
            );
        }

        // Error state
        if (error || !pageSchema) {
            return (
                <Box sx={{
                    border: '2px dashed #f44336',
                    p: 2,
                    borderRadius: 1,
                    textAlign: 'center',
                    minHeight: 200,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
                    <Box>{error || 'No content available'}</Box>
                </Box>
            );
        }

        // Successfully loaded page schema - render it
        return (
            <Box sx={{
                width: '100%',
                display: 'flex',
                flexDirection: 'column'
            }}>
                {pageSchema.ui && pageSchema.ui.length > 0 && (
                    <PreviewRenderer component={pageSchema.ui[0]} />
                )}
            </Box>
        );
    };

    return (
        <Modal show={showModal} onClose={onClose} maxWidth={maxWidth}>
            <ModalTitle>{title}</ModalTitle>
            <ModalBody>
                {renderModalContent()}
            </ModalBody>
        </Modal>
    );
};

export default DynamicModal;
