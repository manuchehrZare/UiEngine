/* eslint-disable */
/**
 * Hidden Field Component
 * Renders utility/service beans that have no visual representation in runtime mode
 * but displays a placeholder in design mode for visibility and selection
 *
 * These components are typically utility classes like:
 * - PageOrganizer, FileTransfer, JCSMath, BPMEbmlUtility
 * - JCSStringUtility, JCSClientContext, DMSDocument, JCSDateUtility
 * - JCSShell, JCSTimer, DMSScanner, CSVExport, JCSFileSystem
 * - JNovaBrowserPanel, DMSSharedScanner, JCSFtp, BankingBrowser
 */

import React from 'react';
import { Box, Typography, Chip } from '../../../seker-ui-lib';
import { useNovaOptional } from '../context/NovaContext';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

export interface HiddenFieldComponentProps {
    id?: string;
    name?: string;
    /** The original Java class name for display purposes */
    originalType?: string;
    /** Display label for the hidden field */
    label?: string;
    [key: string]: any;
}

/**
 * Map of known hidden field types to friendly display names
 */
const HIDDEN_FIELD_DISPLAY_NAMES: Record<string, string> = {
    'tr.com.cs.aurora.extensions.client.banking.PageOrganizer': 'Page Organizer',
    'tr.com.cs.aurora.extensions.client.banking.FileTransfer': 'File Transfer',
    'tr.com.cs.aurora.ebml.bean.utility.JCSMath': 'Math Utility',
    'tr.com.cs.foja.bpm.aurora.client.BPMEbmlUtility': 'BPM Utility',
    'tr.com.cs.aurora.ebml.bean.utility.JCSStringUtility': 'String Utility',
    'tr.com.cs.aurora.ebml.bean.utility.JCSClientContext': 'Client Context',
    'tr.com.cs.foja.dms.aurora.client.DMSDocument': 'DMS Document',
    'tr.com.cs.aurora.ebml.bean.utility.JCSDateUtility': 'Date Utility',
    'tr.com.cs.aurora.ebml.bean.utility.JCSShell': 'Shell Utility',
    'tr.com.cs.aurora.ebml.bean.utility.JCSTimer': 'Timer',
    'tr.com.cs.foja.dms.aurora.client.DMSScanner': 'DMS Scanner',
    'tr.com.cs.aurora.extensions.client.banking.CSVExport': 'CSV Export',
    'tr.com.cs.aurora.ebml.bean.utility.JCSFileSystem': 'File System',
    'tr.com.sekerbank.nova.shell.JNovaBrowserPanel': 'Browser Panel',
    'tr.com.cs.foja.dms.aurora.client.DMSSharedScanner': 'Shared Scanner',
    'tr.com.cs.aurora.ebml.bean.utility.JCSFtp': 'FTP Utility',
    'tr.com.cs.aurora.extensions.client.banking.BankingBrowser': 'Banking Browser',
};

/**
 * Get friendly display name from original type
 */
const getDisplayName = (originalType?: string, name?: string, label?: string): string => {
    if (label) return label;
    if (originalType && HIDDEN_FIELD_DISPLAY_NAMES[originalType]) {
        return HIDDEN_FIELD_DISPLAY_NAMES[originalType];
    }
    if (originalType) {
        // Extract class name from full path
        const parts = originalType.split('.');
        return parts[parts.length - 1];
    }
    return name || 'Hidden Field';
};

/**
 * Get short type name for chip display
 */
const getShortTypeName = (originalType?: string): string => {
    if (!originalType) return 'Utility';
    const parts = originalType.split('.');
    return parts[parts.length - 1];
};

export const HiddenFieldComponent: React.FC<HiddenFieldComponentProps> = ({
    id,
    name,
    originalType,
    label,
    ...props
}) => {
    // Try to get Nova context to check mode, but don't fail if not available
    const novaContext = useNovaOptional();
    const isDesignMode = novaContext?.mode === 'design';

    // In runtime/preview mode, render nothing (hidden)
    if (!isDesignMode) {
        return null;
    }

    const displayName = getDisplayName(originalType, name, label);
    const shortType = getShortTypeName(originalType);

    // In design mode, render a visual placeholder
    return (
        <Box
            sx={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 1,
                padding: '4px 8px',
                backgroundColor: 'rgba(156, 39, 176, 0.08)',
                border: '1px dashed rgba(156, 39, 176, 0.4)',
                borderRadius: 1,
                minWidth: 120,
                maxWidth: 250,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                '&:hover': {
                    backgroundColor: 'rgba(156, 39, 176, 0.15)',
                    borderColor: 'rgba(156, 39, 176, 0.6)',
                },
            }}
            title={`${originalType || 'Hidden Field'}\nID: ${id || name || 'unknown'}`}
        >
            <VisibilityOffIcon
                sx={{
                    fontSize: 16,
                    color: 'rgba(156, 39, 176, 0.7)',
                    flexShrink: 0,
                }}
            />
            <Typography
                variant="caption"
                sx={{
                    color: 'rgba(0, 0, 0, 0.6)',
                    fontWeight: 500,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    flexGrow: 1,
                }}
            >
                {displayName}
            </Typography>
            <Chip
                label={shortType}
                size="small"
                sx={{
                    height: 18,
                    fontSize: '0.65rem',
                    backgroundColor: 'rgba(156, 39, 176, 0.2)',
                    color: 'rgba(156, 39, 176, 0.9)',
                    '& .MuiChip-label': {
                        padding: '0 6px',
                    },
                }}
            />
        </Box>
    );
};
