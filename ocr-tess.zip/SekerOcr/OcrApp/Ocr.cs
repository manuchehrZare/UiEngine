using Ocr.Core;
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace OcrApp
{
    public partial class Ocr : Form
    {
        private readonly OcrService _ocrService;
        private readonly ChequeProcessor _chequeProcessor;
        private string? _currentImagePath;

        public Ocr()
        {
            InitializeComponent();
            _ocrService = new OcrService();
            _chequeProcessor = new ChequeProcessor();
            InitializeEngines();
        }

        private void InitializeEngines()
        {
            var engines = _ocrService.GetEngines();
            foreach (var engine in engines)
            {
                cmbEngines.Items.Add(engine.Name);
            }

            if (cmbEngines.Items.Count > 0)
                cmbEngines.SelectedIndex = 0;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            using var openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.tiff";
            
            // Try to find the cheques directory relative to the executable for user convenience
            string potentialPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\OcrApp\cheques"));
            if (Directory.Exists(potentialPath))
            {
                openFileDialog.InitialDirectory = potentialPath;
            }
            else
            {
                 // Check if it's just cheques
                 string altPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "cheques");
                 if (Directory.Exists(altPath))
                    openFileDialog.InitialDirectory = altPath;
            }

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                _currentImagePath = openFileDialog.FileName;
                try
                {
                    // Use FileStream to avoid locking the file if possible (though Image.FromStream locks it until disposed)
                    using var stream = new FileStream(_currentImagePath, FileMode.Open, FileAccess.Read);
                    pbImage.Image = System.Drawing.Image.FromStream(stream);
                    lblStatus.Text = $"Loaded: {Path.GetFileName(_currentImagePath)}";
                    rtbResult.Text = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading image: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void btnProcess_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_currentImagePath))
            {
                MessageBox.Show("Please load an image first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbEngines.SelectedItem == null)
            {
                 MessageBox.Show("Please select an OCR engine.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 return;
            }

            string engineName = cmbEngines.SelectedItem.ToString()!;
            
            try
            {
                btnProcess.Enabled = false;
                lblStatus.Text = $"Processing with {engineName}...";
                
                var engine = _ocrService.GetEngine(engineName);
                var result = await engine.ProcessImageAsync(_currentImagePath);

                if (result.Success)
                {
                    rtbResult.Text = $"--- OCR Result ({engineName}) ---\n";
                    rtbResult.AppendText($"Execution Time: {result.ExecutionTime.TotalMilliseconds:F2}ms\n\n");
                    rtbResult.AppendText(result.Text);
                    lblStatus.Text = "Completed Success";
                }
                else
                {
                     rtbResult.Text = $"Error: {result.ErrorMessage}";
                     lblStatus.Text = "Error occurred";
                     MessageBox.Show($"OCR Failed:\n{result.ErrorMessage}", "OCR Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Critical Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Exceptional Error";
            }
            finally
            {
                btnProcess.Enabled = true;
            }
        }

        private void btnProcessCheque_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_currentImagePath))
            {
                MessageBox.Show("Please load an image first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                btnProcessCheque.Enabled = false;
                lblStatus.Text = "Processing Cheque (QR + MICR)...";
                rtbResult.Text = "";

                // Run in background to not freeze UI
                Task.Run(() => 
                {
                    var sw = System.Diagnostics.Stopwatch.StartNew();
                    var result = _chequeProcessor.ProcessCheque(_currentImagePath);
                    sw.Stop();

                    this.Invoke(() => 
                    {
                        if (result.Success)
                        {
                            var sb = new System.Text.StringBuilder();
                            sb.AppendLine("--- Cheque Processing Result ---");
                            sb.AppendLine($"Execution Time: {sw.ElapsedMilliseconds}ms");
                            sb.AppendLine();
                            
                            sb.AppendLine("=== QR Code Data ===");
                            if (result.QrData != null)
                            {
                                sb.AppendLine($"Raw: {result.QrData.RawQr}");
                                sb.AppendLine($"Serial: {result.QrData.SerialNumber}");
                                sb.AppendLine($"Bank: {result.QrData.BankCode}");
                                sb.AppendLine($"Branch: {result.QrData.BranchCode}");
                                sb.AppendLine($"Account: {result.QrData.AccountNumber}");
                                sb.AppendLine($"TC/Tax: {result.QrData.TcTaxNo}");
                                sb.AppendLine($"Mersis: {result.QrData.MersisNo}");
                            }
                            else
                            {
                                sb.AppendLine("No QR Code detected.");
                            }
                            
                            sb.AppendLine();
                            sb.AppendLine("=== MICR Data ===");
                            if (result.MicrData != null)
                            {
                                sb.AppendLine($"Raw: {result.MicrData.RawMicr}");
                                sb.AppendLine($"Serial: {result.MicrData.SerialNumber}");
                                sb.AppendLine($"Bank: {result.MicrData.BankCode}");
                                sb.AppendLine($"Branch: {result.MicrData.BranchCode}");
                                sb.AppendLine($"Account: {result.MicrData.AccountNumber}");
                            }
                            else
                            {
                                sb.AppendLine("No MICR detected or invalid.");
                            }

                            rtbResult.Text = sb.ToString();
                            lblStatus.Text = "Cheque Processed";
                        }
                        else
                        {
                             rtbResult.Text = $"Error: {result.ErrorMessage}";
                             lblStatus.Text = "Error";
                        }
                        btnProcessCheque.Enabled = true;
                    });
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnProcessCheque.Enabled = true;
                lblStatus.Text = "Error";
            }
        }
    }
}
