"""
Turkish Cheque Reader Application
Reads DataMatrix codes and MICR data from cheque images.
"""

import cv2
import numpy as np
import zxingcpp
import pytesseract
import json
import sys
from pathlib import Path
from typing import Dict, Optional, Any


class QRCodeReader:
    """Reads and parses DataMatrix codes from Turkish cheques."""

    @staticmethod
    def read_qr_codes(image: np.ndarray) -> Optional[Dict[str, Any]]:
        """
        Read DataMatrix code from an image using zxing-cpp.

        Args:
            image: OpenCV image (BGR format)

        Returns:
            Dictionary containing parsed code data or None
        """
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Try different scales for different image sizes
        height = gray.shape[0]
        if height < 200:
            scales = [3, 4, 2]
        elif height < 300:
            scales = [2, 3, 4]
        else:
            scales = [1, 2, 3]

        for scale in scales:
            if scale > 1:
                scaled = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            else:
                scaled = gray

            barcodes = zxingcpp.read_barcodes(scaled, formats=zxingcpp.BarcodeFormat.DataMatrix)
            for bc in barcodes:
                raw_data = bc.text
                if raw_data:
                    parsed = QRCodeReader.parse_qr_data(raw_data)
                    if parsed:
                        return parsed

        return None

    @staticmethod
    def parse_qr_data(raw_data: str) -> Optional[Dict[str, Any]]:
        """
        Parse Turkish cheque DataMatrix code data.

        Expected format: "KKB 00 SERIAL BANK BRANCH ACCOUNT TC_TAX MERSIS HASH"
        """
        if not raw_data:
            return None

        raw_data = raw_data.strip()
        parts = raw_data.split()

        if len(parts) < 8 or parts[0] != 'KKB':
            return None

        return {
            'raw_qr': raw_data,
            'serial_number': parts[2],
            'bank_code': parts[3],
            'branch_code': parts[4],
            'account_number': parts[5],
            'tc_tax_no': parts[6],
            'mersis_no': parts[7]
        }


class MICRReader:
    """Reads and parses MICR data from Turkish cheques using Tesseract with E13B traineddata."""

    @staticmethod
    def read_micr(image: np.ndarray) -> Optional[Dict[str, Any]]:
        """
        Read MICR data from cheque image.

        Args:
            image: OpenCV image (BGR format)

        Returns:
            Dictionary containing parsed MICR data or None
        """
        height, width = image.shape[:2]

        # MICR is at the bottom of the cheque
        micr_y_start = int(height * 0.80)
        micr_region = image[micr_y_start:height, :]

        if micr_region.shape[0] < 10:
            return None

        # Preprocess for OCR
        gray = cv2.cvtColor(micr_region, cv2.COLOR_BGR2GRAY)
        scaled = cv2.resize(gray, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(4, 4))
        enhanced = clahe.apply(scaled)
        _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # OCR with E13B traineddata
        text = pytesseract.image_to_string(binary, config=r'--oem 3 --psm 6 -l e13b')
        text = text.upper().replace(' ', '').replace('\n', '')

        # Parse E13B output
        micr_text = MICRReader._parse_e13b_micr(text)
        if micr_text:
            return MICRReader.parse_micr_data(micr_text)

        return None

    @staticmethod
    def _parse_e13b_micr(text: str) -> Optional[str]:
        """
        Parse E13B OCR output to extract MICR digits.

        E13B format: C<serial>C<bank>D<branch>A<account>C
        - C = On-Us symbol
        - D = Amount symbol
        - A = Transit symbol (separates routing from account)
        """
        if 'A' not in text:
            return None

        # Find all 'A' positions and try each one
        # The correct 'A' separates routing (14 digits) from account (16 digits)
        a_positions = [i for i, c in enumerate(text) if c == 'A']

        for idx in a_positions:
            before = text[:idx]
            after = text[idx + 1:]

            routing_digits = ''.join(c for c in before if c.isdigit())
            account_digits = ''.join(c for c in after if c.isdigit())

            # Take last 14 digits of routing (serial 7 + bank 3 + branch 4)
            if len(routing_digits) >= 14:
                routing = routing_digits[-14:]
            else:
                routing = routing_digits

            # Take first 16 digits of account
            if len(account_digits) >= 16:
                account = account_digits[:16]
            else:
                account = account_digits

            # Valid MICR: 14 routing digits + 16 account digits
            if len(routing) >= 13 and len(account) >= 15:
                return f"{routing}:{account}"

        return None

    @staticmethod
    def parse_micr_data(raw_micr: str) -> Optional[Dict[str, Any]]:
        """
        Parse Turkish cheque MICR data.

        Turkish MICR format (E13B):
        - Serial Number: 7 digits
        - Bank Code: 3 digits
        - Branch Code: 4 digits
        - Account Number: 16 digits
        """
        if not raw_micr or ':' not in raw_micr:
            return None

        parts = raw_micr.split(':')
        if len(parts) < 2:
            return None

        routing = parts[0]
        account = parts[1]

        # Pad routing to 14 digits if needed
        if len(routing) == 13:
            routing = '0' + routing
        elif len(routing) > 14:
            routing = routing[-14:]

        if len(routing) < 14 or len(account) < 16:
            return None

        return {
            'serial_number': routing[:7],
            'bank_code': routing[7:10],
            'branch_code': routing[10:14],
            'account_number': account[:16],
            'raw_micr': f"{routing}:{account[:16]}",
            'valid': True
        }


class ChequeProcessor:
    """Main class for processing cheque images."""

    def __init__(self):
        self.qr_reader = QRCodeReader()
        self.micr_reader = MICRReader()

    def process_image(self, image_path: str) -> Dict[str, Any]:
        """
        Process a cheque image and extract QR and MICR data.

        Args:
            image_path: Path to the image file

        Returns:
            Dictionary containing cheque data
        """
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not read image: {image_path}")

        qr_data = self.qr_reader.read_qr_codes(image)
        micr_data = self.micr_reader.read_micr(image)

        return {
            'file': image_path,
            'qr_code': qr_data,
            'micr': micr_data
        }

    def process_directory(self, directory_path: str, pattern: str = "*.jpg") -> Dict[str, Dict[str, Any]]:
        """Process all matching images in a directory."""
        results = {}
        path = Path(directory_path)

        for image_file in path.glob(pattern):
            try:
                results[image_file.name] = self.process_image(str(image_file))
            except Exception as e:
                results[image_file.name] = {'error': str(e)}

        return results


def main():
    """Main entry point."""
    import argparse

    parser = argparse.ArgumentParser(description='Turkish Cheque Reader')
    parser.add_argument('input', help='Image file or directory path')
    parser.add_argument('-o', '--output', help='Output JSON file (default: stdout)')
    parser.add_argument('-p', '--pattern', default='*.jpg', help='File pattern for directory processing')

    args = parser.parse_args()

    processor = ChequeProcessor()
    input_path = Path(args.input)

    if input_path.is_file():
        results = processor.process_image(str(input_path))
    elif input_path.is_dir():
        results = processor.process_directory(str(input_path), args.pattern)
    else:
        print(f"Error: {args.input} is not a valid file or directory")
        sys.exit(1)

    output = json.dumps(results, indent=2, ensure_ascii=False)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Results written to {args.output}")
    else:
        print(output)


if __name__ == '__main__':
    main()
