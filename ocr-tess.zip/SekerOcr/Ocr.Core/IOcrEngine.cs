namespace Ocr.Core;

public interface IOcrEngine
{
    string Name { get; }
    Task<OcrResult> ProcessImageAsync(string imagePath);
}
