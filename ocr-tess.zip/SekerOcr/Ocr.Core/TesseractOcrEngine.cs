using System.Diagnostics;
using Tesseract;

namespace Ocr.Core;

public class TesseractOcrEngine : IOcrEngine
{
    public string Name => "Tesseract OCR";
    private readonly string _tessDataPath;
    private readonly string _language;

    public TesseractOcrEngine(string? tessDataPath = null, string language = "tur")
    {
        _tessDataPath = tessDataPath ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tessdata");
        _language = language;
    }

    public Task<OcrResult> ProcessImageAsync(string imagePath)
    {
        return Task.Run(() =>
        {
            var sw = Stopwatch.StartNew();
            try
            {
                if (!Directory.Exists(_tessDataPath))
                {
                    return new OcrResult 
                    { 
                        EngineName = Name, 
                        Success = false, 
                        ErrorMessage = $"Tessdata directory not found at {_tessDataPath}.\nPlease create a 'tessdata' folder in the application directory and place 'eng.traineddata' inside it.\nYou can download it from https://github.com/tesseract-ocr/tessdata" 
                    };
                }

                using var engine = new TesseractEngine(_tessDataPath, _language, EngineMode.Default);
                using var img = Pix.LoadFromFile(imagePath);
                using var page = engine.Process(img);
                
                var text = page.GetText();
                sw.Stop();

                return new OcrResult
                {
                    EngineName = Name,
                    Text = text,
                    Success = true,
                    ExecutionTime = sw.Elapsed
                };
            }
            catch (Exception ex)
            {
                return new OcrResult
                {
                    EngineName = Name,
                    Success = false,
                    ErrorMessage = ex.Message,
                    ExecutionTime = sw.Elapsed
                };
            }
        });
    }
}
