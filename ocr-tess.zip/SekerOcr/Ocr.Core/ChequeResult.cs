
using System.Text.Json.Serialization;

namespace Ocr.Core;

public class ChequeResult
{
    public string FilePath { get; set; } = string.Empty;
    public bool Success { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;

    public ChequeQrResult? QrData { get; set; }
    public ChequeMicrResult? MicrData { get; set; }
    
    // Consolidated data could go here if needed
}

public class ChequeQrResult
{
    public string RawQr { get; set; } = string.Empty;
    public string SerialNumber { get; set; } = string.Empty;
    public string BankCode { get; set; } = string.Empty;
    public string BranchCode { get; set; } = string.Empty;
    public string AccountNumber { get; set; } = string.Empty;
    public string TcTaxNo { get; set; } = string.Empty;
    public string MersisNo { get; set; } = string.Empty;
}

public class ChequeMicrResult
{
    public string RawMicr { get; set; } = string.Empty;
    public string SerialNumber { get; set; } = string.Empty;
    public string BankCode { get; set; } = string.Empty;
    public string BranchCode { get; set; } = string.Empty;
    public string AccountNumber { get; set; } = string.Empty;
    public bool Valid { get; set; }
}
