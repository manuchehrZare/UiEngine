namespace Ocr.Core;

public class OcrResult
{
    public string Text { get; set; } = string.Empty;
    public string EngineName { get; set; } = string.Empty;
    public bool Success { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;
    public TimeSpan ExecutionTime { get; set; }
}
