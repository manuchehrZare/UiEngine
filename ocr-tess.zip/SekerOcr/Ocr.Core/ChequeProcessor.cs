
using OpenCvSharp;

namespace Ocr.Core;

public class ChequeProcessor
{
    private readonly MICRReader _micrReader;

    public ChequeProcessor(string? tessDataPath = null)
    {
        _micrReader = new MICRReader(tessDataPath);
    }

    public ChequeResult ProcessCheque(string imagePath)
    {
        var result = new ChequeResult 
        { 
            FilePath = imagePath,
            Success = false 
        };

        try
        {
            if (!File.Exists(imagePath))
            {
                result.ErrorMessage = "File not found.";
                return result;
            }

            // Load image using OpenCvSharp
            using var image = Cv2.ImRead(imagePath);
            if (image.Empty())
            {
                result.ErrorMessage = "Could not read image.";
                return result;
            }

            // QR Code
            result.QrData = QRCodeReader.ReadQrCodes(image);

            // MICR
            result.MicrData = _micrReader.ReadMicr(image);

            result.Success = true;
        }
        catch (Exception ex)
        {
            result.ErrorMessage = ex.Message;
            result.Success = false;
        }

        return result;
    }
}
