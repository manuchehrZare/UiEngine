<popupdata type="sql">
<sql dataSource="IBANK_NoTx">
	SELECT  to_char(MUSTERINO) AS MUSTERINO,KULLANICIADI,KULLANICISOYADI,OIDMUSTERI,OIDKULLANICI, DECODE(OIDKULLANICIGRUBU, 'BIREYSELKULLANICI', 1, 2) AS MUSTERITIPI
	 FROM  KULLANICIEBTABLE 
	 WHERE  to_char(MUSTERINO) = ? and AKTIF=0 
	 ORDER BY MUSTERINO
</sql>
    	<parameters>
	        <parameter prefix="" suffix="" type="string">Page.MUSTERINO</parameter>
	   	</parameters>
</popupdata>