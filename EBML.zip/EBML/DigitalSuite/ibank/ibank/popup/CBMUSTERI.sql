<popupdata type="sql">
<sql dataSource="CB_NoTx">
	SELECT HDR_CSTID as MUSTERINO, HDR_FIRSTNAME as AD, HDR_LASTNAME as SOYAD, HDR_FRGN_NAME as FOREIGN, HDR_INTRL_CLSF as CLASS
	FROM CST_HDR_HEADER
	WHERE to_char(HDR_CSTID) = ?
	and (HDR_LASTNAME like ?
	and (HDR_FIRSTNAME like ? or HDR_FIRSTNAME is null))
	ORDER BY HDR_CSTID
</sql>
    	<parameters>
	        <parameter prefix="" suffix="" type="string">Page.pnlKriter.txtMusteriNo</parameter>
	        <parameter prefix="" suffix="%" type="string">Page.pnlKriter.txtMusteriAd</parameter>
	        <parameter prefix="" suffix="%" type="string">Page.pnlKriter.txtMusteriSoyad</parameter>
	</parameters>
</popupdata>
