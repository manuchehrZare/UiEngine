<popupdata type="service">
    <service>SBIB_CCCAGRIDETAIL</service>
    <parameters>
        <parameter n="OIDISLEM">Page.txtOidIslem</parameter>
        <parameter n="AGENTKODU">Page.txtAgent</parameter>
    </parameters>
</popupdata>
