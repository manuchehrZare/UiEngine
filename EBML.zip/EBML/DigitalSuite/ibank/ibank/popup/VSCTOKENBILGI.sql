<popupdata type="sql">
<sql dataSource="IBANK_NoTx">
	SELECT a.serialnumber, a.birthdate, a.expiredate, decode (a.used,1, 'ATANDI','ATANMADI') AS USED
	FROM VASCODPINFO a
	WHERE
	    a.dpmode = 'RO' and
	    a.used = ? and 
        a.serialnumber like ? 
</sql>
    <parameters>
        <parameter type="integer">Page.txt_used</parameter>
		<parameter prefix="%" suffix="%" type="string">Page.txt_SeriNum</parameter>
	</parameters>
</popupdata>




	
	

