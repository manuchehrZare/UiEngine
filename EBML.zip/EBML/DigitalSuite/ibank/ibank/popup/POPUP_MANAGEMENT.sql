<popupdata type="service">
	<service>SBIB_LIST_POPUP</service>
    <parameters>
	        <parameter n="POPUP_NAME">Page.pnlQueryParameters.txtPopupName</parameter>
	</parameters>
</popupdata>
