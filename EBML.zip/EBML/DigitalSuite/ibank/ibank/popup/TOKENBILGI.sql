<popupdata type="sql">
<sql dataSource="IBANK_NoTx">
	SELECT a.serialnumber, a.birthdate, a.expiredate, decode (a.used,1, 'ATANDI','ATANMADI') AS USED
	FROM otptokenbilgileri a
	WHERE
        a.serialnumber like ? and used=0
</sql>
    <parameters>
		<parameter prefix="%" suffix="%" type="string">Page.txt_SeriNum</parameter>
	</parameters>
</popupdata>




	
	

