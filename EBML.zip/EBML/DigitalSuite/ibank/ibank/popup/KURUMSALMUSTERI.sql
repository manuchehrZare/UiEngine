<popupdata type="sql">
<sql dataSource="IBANK_NoTx">
	SELECT to_char(A.MUSTERINO) AS MUSTERINO, A.AD, A.SOYAD, A.DTARIHI, A.OIDMUSTERI, A.MUSTERITIPI, B.KULLANICIKODU, B.KULLANICIADI, B.KULLANICISOYADI, B.OIDKULLANICI, DECODE(B.OTPDURUMU, 1, 4, DECODE(C.SMSSTATU, 1, 1, DECODE(C.EIMZASTATU, 1, 2, DECODE(C.SOFTOTPSTATU, 1, 3, DECODE(C.VASCOOTPSTATU, 1, 5, 0))))) as EKGUVENLIK
	FROM MUSTERIBILGISIEBTABLE A, KULLANICIEBTABLE B, KULLANICIEKGUVENLIK C
	WHERE
        to_char(A.MUSTERINO) like decode(?, '', '%', ?)
	    AND (AD LIKE ? or AD is null)
	    AND SOYAD LIKE ? AND A.MUSTERINO = B.MUSTERINO AND A.OIDMUSTERI=B.OIDMUSTERI AND B.OIDKULLANICI = C.OIDKULLANICI (+)
	    AND AKTIF = 0
	 ORDER BY MUSTERINO
</sql>
    	<parameters>
	        <parameter prefix="" suffix="" type="string">Page.MUSTERINO</parameter>
            <parameter prefix="" suffix="" type="string">Page.MUSTERINO</parameter>
	        <parameter prefix="" suffix="%" type="string">Page.AD</parameter>
	        <parameter prefix="" suffix="%" type="string">Page.SOYAD</parameter>
	</parameters>
</popupdata>
