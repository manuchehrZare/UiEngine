<popupdata type="service">
    <service>SBIB_KK_MUSTERISORGULA</service>
    <parameters>
        <parameter n="ADI">Page.pnlKriter.txtMusteriAd</parameter>
        <parameter n="SOYADI">Page.pnlKriter.txtMusteriSoyad</parameter>
    </parameters>
</popupdata>
