<popupdata type="sql">
<sql dataSource="AuroraDS">
SELECT RTRIM(USERNAME) AS KULLANICIKODU,
    RTRIM(FIRST_NAME) KULLANICIADI,
    RTRIM(LAST_NAME) AS KULLANICISOYADI
FROM AURORA.DICT_ML_USER_GROUP_MEMBERSHIP T1, AURORA.DICT_ML_USER T2 ,AURORA.DICT_ML_USER_GROUP T3 
WHERE
 T1.USER_GROUP_OID = T3.OID AND
 T1.USER_GROUP_OID LIKE  ? AND
 T2.USERNAME = SUBSTR(T1.USER_ID, INSTR(T1.USER_ID, '$')+1) AND
 USERNAME LIKE    ? AND
 FIRST_NAME  LIKE ? AND
 LAST_NAME LIKE   ?
ORDER BY USERNAME
</sql>
<parameters>
        <parameter prefix="" suffix="%" type="string">Page.OIDKULLANICIGRUP</parameter>
        <parameter prefix="" suffix="" type="string">Page.KULLANICIKODU</parameter>
        <parameter prefix="" suffix="%" type="string">Page.KULLANICIADI</parameter>
        <parameter prefix="" suffix="%" type="string">Page.KULLANICISOYADI</parameter>
</parameters>
</popupdata>



 