<popupdata type="service">
    <service>SBIB_MUSTERISORGULA_INTERNET</service>
    <parameters>
        <parameter n="MUSTERINO">Page.MUSTERINO</parameter>
        <parameter n="AD">Page.AD</parameter>
        <parameter n="SOYAD">Page.SOYAD</parameter>
    </parameters>
</popupdata>
