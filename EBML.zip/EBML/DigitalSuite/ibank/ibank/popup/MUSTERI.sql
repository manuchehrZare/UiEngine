<popupdata type="service">
    <service>SBIB_MUSTERISORGULA</service>
    <parameters>
        <parameter n="MUSTERINO">Page.pnlKriter.txtMusteriNo</parameter>
        <parameter n="ADI">Page.pnlKriter.txtMusteriAd</parameter>
        <parameter n="IKINCIADI">Page.pnlKriter.txtMusteriIkinciAd</parameter>
        <parameter n="SOYADI">Page.pnlKriter.txtMusteriSoyad</parameter>
        <parameter n="UNVAN">Page.pnlKriter.txtUnvan</parameter>
        <parameter n="VERGINO">Page.pnlKriter.txtVergiNo</parameter>
        <parameter n="KIMLIKNO">Page.pnlKriter.txtKimlikNo</parameter>
        <parameter n="AKTIF">Page.pnlKriter.comboAktif</parameter>
    </parameters>
</popupdata>
