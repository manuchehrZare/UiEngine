<popupdata type="sql">
<sql dataSource="IBANK_NoTx">
	SELECT M.MUSTERINO,M.AD, M.SOYAD,D.SOLABONENO,TO_CHAR(TANIMTARIHI,'DD/MM/YYYY ') AS TANIMTARIHI
	FROM MUSTERIBILGISIEBTABLE M, SUPERONLINEMUSTERI D  
	WHERE M.MUSTERINO = D.MUSTERINO(+)
	AND  to_char(M.MUSTERINO) = ? 
  ORDER BY M.MUSTERINO
</sql>
    	<parameters>
	        <parameter prefix="" suffix="" type="string">PP_SUPERONLINE.MUSTERINO</parameter>
	   	</parameters>
</popupdata>




