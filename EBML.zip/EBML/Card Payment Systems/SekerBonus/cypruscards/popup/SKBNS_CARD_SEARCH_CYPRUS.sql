<popupdata type="service">
	<service>SKBNS_LIST_CYPRUS_CARDS</service>
    <parameters>
		<parameter n="CUST_NO">Page.pnlPopupParameter.hndCustNo</parameter>							
	    <parameter n="CARD_STATUS">Page.pnlPopupParameter.chkOpen</parameter>							
   </parameters>
</popupdata>