<popupdata type="service">
    <service>SKBNS_GET_MANUAL_CAMPAIGN_LIST</service>
    <parameters>
    	<parameter n="CAMPAIGN_CODE">Page.txtCampaignCode</parameter>
    	<parameter n="IS_MANUAL">Page.lblIsManuel</parameter>
    </parameters>
</popupdata>