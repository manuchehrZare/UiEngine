<popupdata type="service">
	<service>SKBNS_LIST_ACCOUNT_INFOS</service>
    <parameters>
		<parameter n="CUST_NO">Page.pnlPopupParameter.hndCustNo</parameter>							
	    <parameter n="CARD_STATUS">Page.pnlPopupParameter.chkOpen</parameter>							
   </parameters>
</popupdata>