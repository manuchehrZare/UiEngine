<popupdata type="service">
	<service>SKBNS_LIST_MERCHANT_TERMINAL_INFOS</service>
    <parameters>
		<parameter n="CUSTOMER_NO">Page.pnlPopupParameter.hndCustNo</parameter>							
	    <parameter n="MERCHANT_NO">Page.pnlPopupParameter.txtMerchantNo</parameter>
	    <parameter n="FIRM_CODE">Page.pnlPopupParameter.txtFirmCode</parameter>
	    <parameter n="MAIN_BRANCH_CODE">Page.pnlPopupParameter.cmbBranch</parameter>
	    <parameter n="LIST_FOR">Page.pnlPopupParameter.lblListFor</parameter>								
   </parameters>
</popupdata>