<popupdata type="service">
	<service>CCA_DIRECTSALE_LIST_FOR_POPUP</service>
	  <parameters>
	     <parameter n="PERSONNEL_NO">pgDirectSaleRepresentative.pnlRepresentative.txtPersonelSicilNo</parameter>
         <parameter n="DS_REPR_CODE">pgDirectSaleRepresentative.pnlRepresentative.txtDSReprCode</parameter>
         <parameter n="DS_CUSTOMER_NO">pgDirectSaleRepresentative.pnlRepresentative.hndCustomerNo</parameter>
         <parameter n="TYPE">pgDirectSaleRepresentative.pnlRepresentative.txtType</parameter>
      </parameters>
</popupdata>