<popupdata type="service">
	<service>CCA_ACTIVE_SALES_FOR_POPUP</service>
	  <parameters>
	  <parameter n="ACTIVE_SALES_PERSONNEL_NO">ppActiveSales.txtSicilNo</parameter>
	  <parameter n="ACTIVE_SALES_PERSONNEL_NAME">ppActiveSales.txtName</parameter>
      <parameter n="ACTIVE_SALES_PERSONNEL_SECOND_NAME">ppActiveSales.txtSecondName</parameter>
      <parameter n="ACTIVE_SALES_PERSONNEL_SURNAME">ppActiveSales.txtSurname</parameter>
      </parameters>
</popupdata>