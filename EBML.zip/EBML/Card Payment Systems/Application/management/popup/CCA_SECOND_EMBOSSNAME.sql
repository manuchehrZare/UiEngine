<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT * FROM CCRD.CCA_EMBOSS_NAME WHERE EMBOSS_NAME like ?
	</sql>
	
    <parameters>
      	<parameter prefix="" suffix="%">Page.txtSecondEmbossName</parameter>
    </parameters>
</popupdata>


