�<popupdata type="service">
	<service>CCA_GET_APP_DETAILS_4PP</service>
	    <parameters>
      <parameter n="APP_TYPE">pgApplicationSearch.pnlCust.cmbApplicationType</parameter>
      <parameter n="PRODUCT_TYPE">pgApplicationSearch.pnlCust.cmbProductType</parameter>
			<parameter n="BRANCH_CODE">pgApplicationSearch.pnlCust.cboBranch</parameter>
      <parameter n="CUSTOMER_CODE">pgApplicationSearch.pnlCust.hndCustomerNo</parameter>
			<parameter n="NAME">pgApplicationSearch.pnlCust.txtName</parameter>
			<parameter n="SECOND_NAME">pgApplicationSearch.pnlCust.txtMidName</parameter>
			<parameter n="SURNAME">pgApplicationSearch.pnlCust.txtSurname</parameter>
      <parameter n="FATHER_NAME">pgApplicationSearch.pnlCust.txtFatherName</parameter>
			<parameter n="BIRTH_DATE">pgApplicationSearch.pnlCust.dtBirthDate</parameter>
			<parameter n="TC_ID">pgApplicationSearch.pnlCust.txtTCNo</parameter>
      <parameter n="APP_NO">pgApplicationSearch.pnlCust.txtApplicationNo</parameter>
			<parameter n="APP_START_DATE">pgApplicationSearch.pnlCust.dtApplicationStart</parameter>
			<parameter n="APP_END_DATE">pgApplicationSearch.pnlCust.dtApplicationEnd</parameter>
			<parameter n="CREATE_START_DATE">pgApplicationSearch.pnlCust.dtCreateStart</parameter>
			<parameter n="CREATE_END_DATE">pgApplicationSearch.pnlCust.dtCreateEnd</parameter>
			<parameter n="APPLICATION_STATUS">pgApplicationSearch.pnlCust.cmbApplicationStatus</parameter>
			<parameter n="APPLICATION_PREV_STATUS">pgApplicationSearch.pnlCust.cmbApplicationPrevStatus</parameter>
			<parameter n="PRD_CARD_KIND">pgApplicationSearch.pnlCust.rgProductGroup.Page.pnlProductGroup.cmbProductGroupOID</parameter>
			<parameter n="PRODUCT_CODE">pgApplicationSearch.pnlCust.rgProductGroup.Page.pnlProductGroup.cmbProductOID</parameter>
			<parameter n="APP_SALE_TYPE">pgApplicationSearch.pnlCust.cmbDirekSatisTipi</parameter>
			<parameter n="APP_COMPAIGN_CODE">pgApplicationSearch.pnlCust.cmbKampanyaKod</parameter>
			<parameter n="CARD_NO">pgApplicationSearch.pnlCust.mskKKNo</parameter>
			<parameter n="APP_PRODUCT_GROUP">pgApplicationSearch.pnlCust.txtProductGroup</parameter>
			<parameter n="FROM_BRANCH_USER">pgApplicationSearch.txtSubeden</parameter>
	    </parameters>
</popupdata>