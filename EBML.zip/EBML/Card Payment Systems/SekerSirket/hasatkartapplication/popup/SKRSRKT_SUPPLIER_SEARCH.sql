<popupdata type="service">
	<service>SKRSRKT_GET_SUPPLIER_DETAILS_FOR_POPUP_NEW</service>
	    <parameters>
	        <parameter n="CUSTOMER_NO">pgCardSearch.pnlCust.hndCustomerNo</parameter>
	        <parameter n="FIRM_NO">pgCardSearch.pnlCust.txtFirmNo</parameter>
	    </parameters>
</popupdata>