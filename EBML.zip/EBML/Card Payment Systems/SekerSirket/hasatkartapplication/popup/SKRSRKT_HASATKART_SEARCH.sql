<popupdata type="service">
	<service>SKRSRKT_GET_HASATKART_DETAILS_FOR_POPUP_NEW</service>
	    <parameters>
	        <parameter n="CUSTOMER_NO">pgCardSearch.pnlCust.hndCustomerNo</parameter>
	        <parameter n="CARD_NO">pgCardSearch.pnlCust.txtCardNo</parameter>
	    </parameters>
</popupdata>