<popupdata type="service">
	<service>SKRSRKT_GET_APPLICATION_DETAILS_FOR_POPUP</service>
	    <parameters>
			<parameter n="BRANCH_CODE">pgApplicationSearch.pnlCust.cboBranch</parameter>
	        <parameter n="CUSTOMER_NO">pgApplicationSearch.pnlCust.hndCustomerNo</parameter>
			<parameter n="NAME">pgApplicationSearch.pnlCust.txtName</parameter>
			<parameter n="SECOND_NAME">pgApplicationSearch.pnlCust.txtMidName</parameter>
			<parameter n="SURNAME">pgApplicationSearch.pnlCust.txtSurname</parameter>
			<parameter n="BIRTH_DATE">pgApplicationSearch.pnlCust.dtBirthDate</parameter>
			<parameter n="TC_ID">pgApplicationSearch.pnlCust.txtTCNo</parameter>
	        <parameter n="APPLICATION_NO">pgApplicationSearch.pnlCust.txtApplicationNo</parameter>
			<parameter n="CREATE_START_DATE">pgApplicationSearch.pnlCust.dtCreateStart</parameter>
			<parameter n="CREATE_END_DATE">pgApplicationSearch.pnlCust.dtCreateEnd</parameter>
			<parameter n="APPLICATION_STATUS">pgApplicationSearch.pnlCust.cmbApplicationStatus</parameter>
			<parameter n="APPLICATION_PREV_STATUS">pgApplicationSearch.pnlCust.cmbApplicationPrevStatus</parameter>
	    </parameters>
</popupdata>