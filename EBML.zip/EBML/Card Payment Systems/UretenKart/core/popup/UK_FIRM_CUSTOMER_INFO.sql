<popupdata type="service">
	<service>UK_GET_FIRM_CUSTOMER_INFO_FOR_POPUP</service>
	    <parameters>
	        <parameter n="CARD_NO">pgCustomerInfo.pnlCust.txtUretenCardNo</parameter>
	        <parameter n="FIRM_CUSTOMER_NO">pgCustomerInfo.pnlCust.txtFirmCustomerNo</parameter>
	        <parameter n="CUSTOMER_NO">pgCustomerInfo.pnlCust.txtCardCustomerNo</parameter>
	    </parameters>
</popupdata>