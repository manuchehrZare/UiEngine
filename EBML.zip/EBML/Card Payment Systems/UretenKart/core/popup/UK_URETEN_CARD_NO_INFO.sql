<popupdata type="service">
	<service>UK_GET_FIRM_CUSTOMER_INFO_FOR_POPUP</service>
	    <parameters>
	        <parameter n="CARD_NO">Page.pnlCust.txtUretenCardNo</parameter>
	        <parameter n="FIRM_CUSTOMER_NO">Page.pnlCust.txtFirmCustomerNo</parameter>
	        <parameter n="CUSTOMER_NO">Page.pnlCust.txtCardCustomerNo</parameter>
	    </parameters>
</popupdata>