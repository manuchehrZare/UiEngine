<popupdata type="service">
	<service>FTR_WESTERN_UNION_SELECT_SEND_MONEY</service>
	    <parameters>
		   	<parameter n="MTCN">Page.pnlCriteria.txtMTCN</parameter>
		   	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranchCode</parameter>
		   	<parameter n="ORIGINATION_CURRENCY_ISO_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
		   	<parameter n="MIN_PRINCIPAL_AMOUNT">Page.pnlCriteria.minAmount</parameter>
		   	<parameter n="MAX_PRINCIPAL_AMOUNT">Page.pnlCriteria.maxAmount</parameter>		   	
		   	<parameter n="SENDER_FIRST_NAME">Page.pnlCriteria.txtSenderName</parameter>
		   	<parameter n="SENDER_LAST_NAME">Page.pnlCriteria.txtSenderSurname</parameter>
		   	<parameter n="RECEIVER_FIRST_NAME">Page.pnlCriteria.txtReceiverName</parameter>
			<parameter n="RECEIVER_LAST_NAME">Page.pnlCriteria.txtReceiverSurname</parameter>
			<parameter n="FIRST_CREATE_DATE">Page.pnlCriteria.firstDate</parameter>
			<parameter n="LAST_CREATE_DATE">Page.pnlCriteria.lastDate</parameter>
			<parameter n="OPERATION_TYPE">Page.lblOperationType</parameter>
     </parameters>
</popupdata>