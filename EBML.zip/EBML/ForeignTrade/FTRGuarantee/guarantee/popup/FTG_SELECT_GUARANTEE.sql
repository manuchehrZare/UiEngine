<popupdata type="service">
<service>FTG_GUARANTEE_LIST_GUARANTEE</service>
	    <parameters>
		   	<parameter n="GUARANTEE_OID">Page.pnlCriterias.lblGuaranteeOID</parameter>
		   	<parameter n="BUSINESS_REFERENCE_NO">Page.pnlCriterias.txtBusinessReferenceNo</parameter>		   	
		    <parameter n="BRANCH_CODE">Page.pnlCriterias.cmbBranch</parameter>
		    <parameter n="IN_OUT_TYPE">Page.pnlCriterias.cmbInOutType</parameter>		    
		    <parameter n="PRODUCT_TYPE">Page.pnlCriterias.cmbProductType</parameter>		    		    
		    <parameter n="CUSTOMER_CODE">Page.pnlCriterias.bhbCustomer</parameter>
		    <parameter n="CURRENCY_CODE">Page.pnlCriterias.cmbCurrencyCode</parameter>
		    <parameter n="LETTER_DATE_START">Page.pnlCriterias.dtLetterDateStart</parameter>
		    <parameter n="LETTER_DATE_END">Page.pnlCriterias.dtLetterDateEnd</parameter>		    
		    <parameter n="TERM_DATE_START">Page.pnlCriterias.dtTermDateStart</parameter>
		    <parameter n="TERM_DATE_END">Page.pnlCriterias.dtTermDateEnd</parameter>		    
		    <parameter n="COUNTER_TERM_DATE_START">Page.pnlCriterias.dtCounterTermDateStart</parameter>
		    <parameter n="COUNTER_TERM_DATE_END">Page.pnlCriterias.dtCounterTermDateEnd</parameter>		    
			<parameter n="OPERATION_TYPE">Page.pnlCriterias.lblOperationType</parameter>
			<parameter n="LIST_FTR">Page.pnlCriterias.lblListFTR</parameter>
			<parameter n="DRAWEE">Page.pnlCriterias.txtDrawee</parameter>
			<parameter n="CORR_CONFIRM_BANK">Page.pnlCriterias.bhbCorrBank</parameter>
			<parameter n="CUSTOMER_NAME">Page.pnlCriterias.txtCustomerTitle</parameter>
			<parameter n="TERM_CONSTRAINT">Page.pnlCriterias.cmbTermConstraint</parameter>			
	    </parameters>
</popupdata>