<popupdata type="service">
	<service>FTR_SWF_VOSTRO_LIST_OPERATIONS</service>
	    <parameters>
	    	<parameter n="BUSINESS_REFERENCE_NO">Page.txtBusinessRefNo</parameter>
	    	<parameter n="STATE">Page.cmbState</parameter>
     </parameters>
</popupdata>
