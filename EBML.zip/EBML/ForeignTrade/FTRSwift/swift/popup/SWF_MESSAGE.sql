<popupdata type="service">
	<service>SWF_SWIFT_LIST_MESSAGE</service>
	<parameters>
		<parameter n="BUSINESS_REFERENCE_NO">Page.hndBusinessRefNo</parameter>
		<parameter n="DATE_START">Page.dfStart</parameter>
		<parameter n="DATE_END">Page.dfEnd</parameter>
		
		<parameter n="BRANCH_CODE">Page.lblBranchCode</parameter>
		
	</parameters>
</popupdata>