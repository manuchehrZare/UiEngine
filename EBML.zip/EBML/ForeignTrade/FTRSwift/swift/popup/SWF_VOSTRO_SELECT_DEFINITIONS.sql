<popupdata type="service">
	<service>FTR_SWF_VOSTRO_LIST_CUST_ACC</service>
	    <parameters>
	    	<parameter n="BIC_CODE">Page.txtBIC</parameter>
	    	<parameter n="BANK_NAME">Page.txtBankName</parameter>
	    	<parameter n="CURRENCY_CODE">Page.cmbCurrCode</parameter>
     </parameters>
</popupdata>
