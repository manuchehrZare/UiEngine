<popupdata type="service">
	<service>SWF_QUERY_MESSAGE_TEMPLATE</service>
	    <parameters>
		   	<parameter n="MESSAGE_TYPE">Page.cmbMessageType</parameter>
		   	<parameter n="MESSAGE_FIELD">Page.cmbMessageField</parameter>
	    	<parameter n="TEMPLATE_NO">Page.txtTemplateNo</parameter>
     </parameters>
</popupdata>
