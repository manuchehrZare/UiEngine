<popupdata type="service">
	<service>SWF_SWIFT_CAMPAIGN_LIST_FOR_CUSTOMER_SEGMENT</service>
	    <parameters>
		   	<parameter n="CUSTOMER_CODE">Page.panelQuery.txtCustomerCode</parameter>
     </parameters>
</popupdata>