<popupdata type="service">
	<service>SWF_SWIFT_CAMPAIGN_LIST</service>
	    <parameters>
		   	<parameter n="CODE">Page.panelQuery.txtCode</parameter>
		   	<parameter n="NAME">Page.panelQuery.txtName</parameter>
		   	<parameter n="DATE_START">Page.panelQuery.dateStart</parameter>
		   	<parameter n="DATE_END">Page.panelQuery.dateEnd</parameter>
		   	<parameter n="TYPE">Page.panelQuery.comboType</parameter>
		   	<parameter n="CAMPAIGN_TYPE">Page.panelQuery.comboCampaignType</parameter>
		   	<parameter n="CUSTOMER_SEGMENT">Page.panelQuery.comboCustomerSegment</parameter>
		   	<parameter n="CHANNEL">Page.panelQuery.comboChannel</parameter>
		   	<parameter n="SWIFT_TYPE">Page.panelQuery.comboSwiftType</parameter>
     </parameters>
</popupdata>
