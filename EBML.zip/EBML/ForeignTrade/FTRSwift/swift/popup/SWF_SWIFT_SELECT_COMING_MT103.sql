<popupdata type="service">
	<service>SWF_SWIFT_LIST_MT103</service>
	    <parameters>
	    	<parameter n="ENTER_SYSTEM_DATE_START">Page.pnlCriteria.dtEnterSystemStartDate</parameter>
	    	<parameter n="ENTER_SYSTEM_DATE_END">Page.pnlCriteria.dtEnterSystemEndDate</parameter>
	    	<parameter n="VALUE_DATE_START">Page.pnlCriteria.dtValueStartDate</parameter>
	    	<parameter n="VALUE_DATE_END">Page.pnlCriteria.dtValueEndDate</parameter>
		   	<parameter n="BUSINESS_REFERENCE_NO">Page.pnlCriteria.txtBusinessReferenceNo</parameter>
	    	<parameter n="SENDER_REFERENCE">Page.pnlCriteria.txtSenderReferenceNo</parameter>
			<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbReceiverBranchCode</parameter>
		   	<parameter n="AMOUNT_START">Page.pnlCriteria.txtLowLimit</parameter>
	    	<parameter n="AMOUNT_END">Page.pnlCriteria.txtHighLimit</parameter>
	    	<parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
	    	<parameter n="APPROVEMENT_STATE">Page.pnlCriteria.cmbApprovementState</parameter>	    	
	    	<parameter n="SENT_FROM_SCREEN">Page.pnlCriteria.lblSentFromScreen</parameter>
	   	<parameter n="MESSAGE_OID">Page.pnlCriteria.txtMessageOid</parameter>
	   	<parameter n="RECEIVER_CUST_CODE">Page.pnlCriteria.txtReceiverCustCode</parameter>
     </parameters>
</popupdata>
