<popupdata type="service">
	<service>SWF_SWIFT_SELECT_FUND_RESERVATION</service>
	    <parameters>
		   	<parameter n="BUSINESS_REFERENCE_NO">Page.pnlCriteria.txtReferenceNo</parameter>
		   	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranchCode</parameter>
	    	<parameter n="CUST_CODE">Page.pnlCriteria.bhbCustCode</parameter>
	    	<parameter n="CURR_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
	    	<parameter n="VALUE_START_DATE">Page.pnlCriteria.dtValueStartDate</parameter>
	    	<parameter n="VALUE_END_DATE">Page.pnlCriteria.dtValueEndDate</parameter>
	    	<parameter n="FUND_RESERVATION_POPUP">Page.txtPopup</parameter>	    		    	
			<parameter n="FUND_RESERVATION_OID">Page.pnlCriteria.txtFundReservationOID</parameter>
			<parameter n="CHARGE_TYPE">Page.pnlCriteria.cmbChargeType</parameter>
     </parameters>
</popupdata>
