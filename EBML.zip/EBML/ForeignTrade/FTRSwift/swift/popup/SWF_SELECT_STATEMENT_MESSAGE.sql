<popupdata type="service">
	<service>SWF_SWIFT_LIST_STATEMENT_MESSAGE</service>
	    <parameters>
		   	<parameter n="BUSINESS_REFERENCE_NO">Page.pnlCriteria.txtBusinessReferenceNo</parameter>
			<parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomerCode</parameter>
			<parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrency</parameter>
			<parameter n="ACCOUNT_OID">Page.pnlCriteria.ppAccountCode</parameter>
			<parameter n="MESSAGING_STATEMENT_TYPE">Page.pnlCriteria.cmbMessagingStatementType</parameter>
			<parameter n="MESSAGING_INTERVAL">Page.pnlCriteria.cmbMessagingInterval</parameter>
			<parameter n="MESSAGING_TYPE">Page.pnlCriteria.cmbMessagingType</parameter>
			<parameter n="MESSAGING_UNIT">Page.pnlCriteria.cmbMessagingUnit</parameter>
			<parameter n="SEND_DECISION">Page.pnlCriteria.cmbSendDecision</parameter>
     </parameters>
</popupdata>