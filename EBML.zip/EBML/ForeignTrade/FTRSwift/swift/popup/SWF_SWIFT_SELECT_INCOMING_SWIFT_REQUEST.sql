<popupdata type="service">
	<service>SWF_SWIFT_SELECT_INCOMING_SWIFT_REQUEST</service>
	    <parameters>
		   	<parameter n="REFERENCE_CODE">Page.pnlCriteria.txtReferenceNo</parameter>
	    	<parameter n="VALUE_START_DATE">Page.pnlCriteria.dtValueStartDate</parameter>
	    	<parameter n="VALUE_END_DATE">Page.pnlCriteria.dtValueEndDate</parameter>
	    	<parameter n="SWIFT_START_DATE">Page.pnlCriteria.dtSwiftStartDate</parameter>
	    	<parameter n="SWIFT_END_DATE">Page.pnlCriteria.dtSwiftEndDate</parameter>
	    	<parameter n="CORR_REFERENCE_CODE">Page.pnlCriteria.txtCorrReferenceNo</parameter>
		   	<parameter n="LOW_AMOUNT">Page.pnlCriteria.txtLowLimit</parameter>
	    	<parameter n="HIGH_AMOUNT">Page.pnlCriteria.txtHighLimit</parameter>
	    	<parameter n="CURR_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
	    	<parameter n="SWIFT_APPROVEMENT_STATUS">Page.pnlCriteria.cmbStatus</parameter>	    	
     </parameters>
</popupdata>
