<popupdata type="service">
	<service>SWF_SWIFT_SELECT_BUSINESS_REF</service>
	    <parameters>
		   	<parameter n="BUSINESS_REFERENCE_NO">Page.panelQuery.txtReference</parameter>
		   	<parameter n="REQ_START_DATE">Page.panelQuery.dtReqStartDate</parameter>
		   	<parameter n="REQ_END_DATE">Page.panelQuery.dtReqEndDate</parameter>
		   	<parameter n="BRANCH_CODE">Page.panelQuery.cmbBranchCode</parameter>
		   	<parameter n="CUST_CODE">Page.panelQuery.bhbCustomerCode</parameter>
		   	<parameter n="SWIFT_TYPE">Page.panelQuery.cmbProductCode</parameter>
		   	<parameter n="CURR_CODE">Page.panelQuery.cmbCurrencyCode</parameter>
		   	<parameter n="REQ_STATE">Page.panelQuery.cmbApproval</parameter>
		   	<parameter n="MESSAGE_OID">Page.panelQuery.txtMessageOid</parameter>
     </parameters>
</popupdata>