<popupdata type="service">
	<service>SWF_WESTERN_UNION_SELECT_SEND_MONEY_MESSAGE</service>
	    <parameters>
		   	<parameter n="MTCN">Page.pnlCriteria.txtMTCN</parameter>
		   	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranchCode</parameter>
		   	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.bhbCustomerCode</parameter>
		   	<parameter n="SENDER_NAME">Page.pnlCriteria.txtSenderName</parameter>
		   	<parameter n="SENDER_SURNAME">Page.pnlCriteria.txtSenderSurname</parameter>
		   	<parameter n="SENDER_IDENTITY">Page.pnlCriteria.txtSenderIdentityNumber</parameter>
		   	<parameter n="SENDER_TAX_NO">Page.pnlCriteria.txtSenderTaxNumber</parameter>
		   	<parameter n="SENDER_PASSAPORT_COUNTRY">Page.pnlCriteria.cmbPasaprtCountry</parameter>
		   	<parameter n="SENDER_PASSAPORT_NUMBER">Page.pnlCriteria.txtPasaportNo</parameter>
		   	<parameter n="CURR_CODE">Page.pnlCriteria.cmbCurrency</parameter>
		   	<parameter n="LOW_AMOUNT">Page.pnlCriteria.amount1</parameter>
		   	<parameter n="HIGH_AMOUNT">Page.pnlCriteria.amount2</parameter>
		   	<parameter n="CREATE_DATE_FIRST">Page.pnlCriteria.date1</parameter>
		   	<parameter n="CREATE_DATE_END">Page.pnlCriteria.date2</parameter>
		   	<parameter n="OID">Page.txtOID</parameter>
     </parameters>
</popupdata>