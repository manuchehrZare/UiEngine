<popupdata type="service">
	<service>FTT_TRADE_GET_CAD_SIGHT</service>
	<parameters>
		   	<parameter n="FILE_OID">Page.pnlCriterias.txtFileOid</parameter>
		   	<parameter n="FILE_NO">Page.pnlCriterias.txtFileNo</parameter>
		   	<parameter n="PRODUCT_TYPE">Page.pnlCriterias.txtProductType</parameter>
		   	<parameter n="POP_UP">Page.pnlCriterias.txtProductType</parameter>
	 </parameters>
</popupdata>
