<popupdata type="service">
	<service>FTT_TRADE_FILE_AGAINST_DRAFT_LIST</service>
	    <parameters>
		   	<parameter n="FILE_NO">Page.pnlCriteria.txtFileNo</parameter>
	    	<parameter n="PRODUCT_TYPE">Page.pnlCriteria.cmbProductType</parameter>
	    	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranch</parameter>
	    	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomer</parameter>
	    	<parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrency</parameter>
	    	<parameter n="STATE">Page.pnlState.cmbState</parameter>    	    	    	    	
	    	<parameter n="CAD_OR_POLICY">Page.txtCadOrPolicy</parameter>    	    	    	    		    	
	    	<parameter n="CAD_OR_POLICY_OID">Page.txtCadOrPolicyOid</parameter>    	    	    	    		    	
	    	<parameter n="PARAM_DISCOUNT_CREATE">Page.pnlCriteria.PARAM_DISCOUNT_CREATE</parameter>
	    	<parameter n="IMPORT">Page.pnlCriteria.rdbIthalat</parameter>
	        <parameter n="TRADE">Page.pnlCriteria.rdbIhracat</parameter>
	    </parameters>
</popupdata> 