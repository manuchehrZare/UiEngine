<popupdata type="service">
	<service>FTT_TRADE_LIST_IBKB_SEQUENCE_NUMBERS</service>
	    <parameters>
	    	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.bhbCustomerCode</parameter>
			<parameter n="BRANCH_CODE">Page.pnlCriteria.txtBranchCode</parameter>
			<parameter n="IBKB_DATE">Page.pnlCriteria.txtDate</parameter>	
			<parameter n="SEQUENCE_NO">Page.pnlCriteria.txtIBKBSeqNo</parameter>		
	    </parameters>
</popupdata>


