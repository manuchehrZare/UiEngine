<popupdata v="3.0.6" type="sql">
    <sql dataSource="BankingDS">
  SELECT I.BANK, D.TITLE, I.BRANCH, B.BRANCH_NAME, I.ADDRESS,I.OID
	  FROM FTR.FTE_INTERMED_BANK I , INFRA.INSTITUTION_DEFINITION D, INFRA.INSTITUTION_BRANCH B
	 WHERE I.STATUS = '1' AND I.BANK = D.BANK_CODE AND D.CLOSED='0'
	   AND D.OID = B.INSTITUTION_OID AND I.BRANCH = B.BRANCH_CODE AND B.CLOSED='0'
	   AND I.BANK LIKE ?
   	   AND I.BRANCH LIKE ?
    </sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbBank</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbBankBranch</parameter>
     </parameters>
</popupdata>


