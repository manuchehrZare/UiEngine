<popupdata type="service">
	<service>FTT_TRADE_GET_FETDEC_LIST</service>
	    <parameters>
		   	<parameter n="DAB_NO">Page.pnlCriteria.txtDABNo</parameter>
		   	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranch</parameter>
	    	<parameter n="FILE_NO">Page.pnlCriteria.ppFileNo</parameter>
	    	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomerCode</parameter>
	    	<parameter n="PRODUCT_CODE">Page.pnlCriteria.cmbProductType</parameter>
	    	<parameter n="FIRST_DATE">Page.pnlCriteria.dtFirstDate</parameter>
	    	<parameter n="SECOND_DATE">Page.pnlCriteria.dtSecondDate</parameter>
	    	<parameter n="REFERENCE_ID">Page.pnlCriteria.txtReference</parameter>	    	
     </parameters>
</popupdata>
