<popupdata v="3.0.6" type="sql">
    <sql dataSource="BankingDS">
	  SELECT CUSTOMSDEC_NO, OID, CURRENCY_CODE, CUSTOMS_OF_DEPARTURE,
	       DESTINATION_COUNTRY, INCOTERMS, BRANCH_CODE, IS_SPSF, SPSF_AMOUNT,
	       FOB_AMOUNT, FREIGHT_AMOUNT,
	       INSURANCE_AMOUNT, CUSTOMSDEC_DATE as CUSTOMS_DATE,
	       TYPE as TYPE,INTERMEDIARY_BANK, ACTUAL_DEPARTURE_DATE, NOTIFICATION_START_DATE,
	       CUSTOMER_CODE,STATISTICAL_VALUE
	  FROM FTR.FTE_CUSTOMSDEC CD
	 WHERE STATUS = '1'
	   AND CUSTOMER_CODE LIKE ?
	   AND (CUSTOMS_OF_DEPARTURE is null OR CUSTOMS_OF_DEPARTURE LIKE ?)
	   AND CUSTOMSDEC_NO LIKE ?
	   AND (DESTINATION_COUNTRY LIKE ? OR DESTINATION_COUNTRY is null)
	   AND (INCOTERMS LIKE ? OR  INCOTERMS is null)
	   AND (BRANCH_CODE LIKE ? or  BRANCH_CODE is null)
	   AND OID LIKE ?
	   AND STATE LIKE ?    
       AND (? = '%' OR EXISTS ( SELECT 1 FROM FTR.FTE_CUSTOMSDEC_FILE_RL REL WHERE REL.CUSTOMSDEC_OID=CD.OID AND REL.FILE_OID LIKE ?))
	   AND (INVOICE_SERIAL_NO LIKE ? or (? = '%' and INVOICE_SERIAL_NO is null ))
    </sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.bhbCustomerCode</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbCustoms</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.txtDeclarationNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbCountry</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbIncoTerms</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbBranch</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.txtOID</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbCDClosingStatus</parameter>
    	<parameter prefix="" suffix="%">Page.pnlStaticCriteria.txtFileOID</parameter>
    	<parameter prefix="" suffix="%">Page.pnlStaticCriteria.txtFileOID</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.txtInvoiceSerialNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.txtInvoiceSerialNo</parameter>
     </parameters>
</popupdata>
