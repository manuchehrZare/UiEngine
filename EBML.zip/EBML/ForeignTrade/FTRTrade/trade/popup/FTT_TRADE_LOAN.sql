<popupdata type="service">
	<service>FTT_TRADE_GET_LOANS_FOR_POPUP</service>
	    <parameters>
		   	<parameter n="REFERENCE_ID">Page.pnlCriteria.txtReferenceNumber</parameter>
	    	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranchCode</parameter>
	    	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomerCode</parameter>
			<parameter n="DISPOSAL_START">Page.pnlCriteria.dtDisposalStart</parameter>
			<parameter n="DISPOSAL_END">Page.pnlCriteria.dtDisposalEnd</parameter>
			<parameter n="DECLERATION_START">Page.pnlCriteria.dtDeclerationStart</parameter>
			<parameter n="DECLERATION_END">Page.pnlCriteria.dtDeclerationEnd</parameter>
	    	<parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
			<parameter n="DECLERATION_STATUS">Page.pnlCriteria.cmbDeclerationStatus</parameter>
			<parameter n="DOCUMENT_STATUS">Page.pnlCriteria.cmbDocumentStatus</parameter>
	    </parameters>
</popupdata>
