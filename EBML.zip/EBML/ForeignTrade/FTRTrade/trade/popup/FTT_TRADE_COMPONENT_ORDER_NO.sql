<popupdata type="service">
	<service>FTT_TRADE_LIST_COMPONENT_ORDER_NO</service>
	    <parameters>
	    	<parameter n="KALEM_SIRA_NO">Page.pnlCriteria.txtComponentOrderNo</parameter>
		<parameter n="VKN">Page.pnlCriteria.txtVKN</parameter>
		<parameter n="GB_NO">Page.pnlCriteria.txtGBNo</parameter>   	
     	</parameters>
</popupdata>
