<popupdata v="3.0.6" type="sql">
    <sql dataSource="BankingDS">
   SELECT FED.OID AS OID,
		FED.RECORD_DATE,
		FED.RECORD_NO, 
		FED.CUSTOMS_OF_DEPARTURE, 
		FED.EFFECTIVE_EXCHANGE_RATE_FROM,
		FED.BANK_PRESENTATION_DATE, 
		FED.AMOUNT, 
		FED.CURRENCY_CODE
	FROM FTR.FTE_CURRENCY_DECLARATION FED
	WHERE 
		FED.STATUS = 1 AND
		FED.CURRENCY_CODE LIKE ? AND 
		FED.RECORD_NO LIKE ?
   </sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.cmbCurrency</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.txtRecordNo</parameter>
     </parameters>
</popupdata> 