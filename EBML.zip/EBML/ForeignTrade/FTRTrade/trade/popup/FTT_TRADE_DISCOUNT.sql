<popupdata type="service">
	<service>FTT_TRADE_DISCOUNT_OPERATION_LIST</service>
	    <parameters>
		   	<parameter n="FILE_NO">Page.pnlCriteria.hndFileNo</parameter>
	    	<parameter n="VALUE_DATE">Page.pnlCriteria.dtValueDate</parameter>
	    	<parameter n="STATE">Page.txtState</parameter>
	    	<parameter n="CAD_OR_POLICY">Page.txtCadOrPolicy</parameter>
	    	<parameter n="CAD_OR_POLICY_OID">Page.txtCadOrPolicyOid</parameter>
     </parameters>
</popupdata>
