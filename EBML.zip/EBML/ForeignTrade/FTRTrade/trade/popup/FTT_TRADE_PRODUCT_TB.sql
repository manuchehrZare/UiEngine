<popupdata type="service">
	<service>FTT_TRADE_LIST_CUSTOM_PRODUCT_FOR_TB</service>
	    <parameters>
	    	<parameter n="KALEM_NO">Page.pnlCriteria.txtProductNo</parameter>
		   	<parameter n="VKN">Page.pnlCriteria.txtVKN</parameter>
		   	<parameter n="GB_NO">Page.pnlCriteria.txtGBNo</parameter>   	
     	</parameters>
</popupdata>
