<popupdata type="service">
	<service>FTT_TRADE_GET_FILES_FOR_COLLATERAL_POPUP</service>
	    <parameters>
		   	<parameter n="FILE_NO">Page.pnlCriteria.txtFileNo</parameter>
	    	<parameter n="PRODUCT_TYPE">Page.pnlCriteria.cmbProductType</parameter>
	    	<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranch</parameter>
	    	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomer</parameter>
	    	<parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrency</parameter>
	    	<parameter n="STATE">Page.pnlCriteria.cmbState</parameter>    	    	    	    	
	    	<parameter n="CONFIRM_TYPE">Page.pnlCriteria.cmbConfirmType</parameter>    	    	    	    	
		   	<parameter n="FILE_OID">Page.pnlCriteria.txtFileOID</parameter>
	    </parameters>
</popupdata>
