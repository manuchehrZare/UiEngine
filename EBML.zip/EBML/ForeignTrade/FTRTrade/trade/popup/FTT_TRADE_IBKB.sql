<popupdata type="service">
	<service>FTT_TRADE_LIST_IBKB</service>
	    <parameters>
	    	<parameter n="CUSTOMER_CODE">Page.pnlCriteria.bhbCustomerCode</parameter>
	    </parameters>
</popupdata>