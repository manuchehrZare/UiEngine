<popupdata v="3.0.6" type="sql">
    <sql dataSource="BankingDS">
  SELECT F.OID,F.FILE_NO,M.OID,M.CUSTOMER_CODE, M.MANUF_TITLE
	  FROM FTR.FTE_FILE F , FTR.FTE_MANUFACTURER M
	 WHERE F.STATUS = '1' AND M.STATUS = '1' 
	   AND F.OID = M.FILE_OID
	   AND F.FILE_NO LIKE ?
   	   AND M.CUSTOMER_CODE LIKE ?
   	</sql>
    <parameters>
    	<parameter prefix="" suffix="">Page.pnlCriteria.txtFileNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlCriteria.hndCustomer</parameter>
     </parameters>
</popupdata>


