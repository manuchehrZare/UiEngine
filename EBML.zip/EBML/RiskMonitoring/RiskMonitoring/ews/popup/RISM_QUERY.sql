<popupdata type="service">
	<service>RISK_MONITORING_GET_ACTION_WITH_CRITERIA</service>
	 <parameters>
		<parameter n="CUSTOMER_CODE">Page.rgQuery.Page.hndCustomerCode</parameter>
		<parameter n="ORG_CODE">Page.rgQuery.Page.cmbBranchCode</parameter>
		<parameter n="REGION">Page.rgQuery.Page.cmbRegionCode</parameter>
		<parameter n="PROFIT_CENTER_CODE">Page.rgQuery.Page.cboProfitCenter</parameter>
		<parameter n="PROFIT_SEGMENT_CODE">Page.rgQuery.Page.cboProfitSegmentCode</parameter>
		<parameter n="COLOR">Page.rgQuery.Page.pnlHideElements.cmbActionColor</parameter>
		<parameter n="ACTION">Page.rgQuery.Page.pnlHideElements.cmbActionType</parameter>
		<parameter n="FIRM_AUTHORIZATION">Page.rgQuery.Page.pnlHideElements.cmbFirmAuthorization</parameter>
		<parameter n="GROUP_AUTHORIZATION">Page.rgQuery.Page.pnlHideElements.cmbGrupAuthorization</parameter>
		<parameter n="CREATE_DATE">Page.rgQuery.Page.pnlHideElements.dtStartDate</parameter>
		<parameter n="CREATE_END_DATE">Page.rgQuery.Page.pnlHideElements.dtFinishDate</parameter>
		<parameter n="IS_COLLECTION">Page.rgQuery.Page.chkIsCollection</parameter>
		<parameter n="IS_MONITORING">Page.rgQuery.Page.chkIsMonitoring</parameter>
		<parameter n="IS_OVERRIDE">Page.rgQuery.Page.isOverride</parameter>
		<parameter n="SCREEN_CODE">Page.rgQuery.Page.lblScreenCode</parameter>
     </parameters>
</popupdata>
