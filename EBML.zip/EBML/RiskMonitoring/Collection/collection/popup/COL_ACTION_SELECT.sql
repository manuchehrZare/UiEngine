<popupdata type="service">
	<service>CARD_COL_ACTION_LIST_POOL</service>
    <parameters>
        <parameter n="STATE">Page.var_State</parameter>
        <parameter n="MANUALLY_CREATED">Page.var_ManuallyCreated</parameter>
        <parameter n="ORDER_BY">Page.var_OrderBy</parameter>
        <parameter n="REFERENCE_ID">Page.Panel_Filter.Text_ReferenceNo</parameter>
        <parameter n="CLASS_CODE">Page.Panel_Filter.Combo_ClassCode</parameter>
        <parameter n="PRODUCT_MAIN_GROUP_CODE">Page.Panel_Filter.Combo_ProductCode</parameter>
        <parameter n="COLLECTOR_CODE">Page.Panel_Filter.Combo_CollectorCode</parameter>
        <parameter n="ACTION_CODE">Page.Panel_Filter.Combo_MainActionCode</parameter>
        <parameter n="REASON_CODE">Page.Panel_Filter.Combo_ReasonCode</parameter>
        <parameter n="DATE_BEGIN">Page.Panel_Filter.DF_DateBegin</parameter>
        <parameter n="DATE_END">Page.Panel_Filter.DF_DateEnd</parameter>
        <parameter n="TIME_BEGIN">Page.Panel_Filter.TF_TimeBegin</parameter>
        <parameter n="TIME_END">Page.Panel_Filter.TF_TimeEnd</parameter>
        <parameter n="CUSTOMER_CODE">Page.Panel_Filter.HND_CustomerCode</parameter>
        <parameter n="CUSTOMER_NAME">Page.Panel_Filter.Text_CustomerName</parameter>
        <parameter n="IBAN_NUMBER">Page.Panel_Filter.HND_AccountNo</parameter>        
   </parameters>
</popupdata>
