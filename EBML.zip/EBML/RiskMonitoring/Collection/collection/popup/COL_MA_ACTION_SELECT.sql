<popupdata type="service">
	<service>CARD_COL_ACTION_LIST_REALIZED</service>
    <parameters>
        <parameter n="STATE">Page.var_State</parameter>
        <parameter n="ACTION_CODE">Page.Panel_Filter.Combo_MainActionCode</parameter>
        <parameter n="DATE_BEGIN">Page.Panel_Filter.DF_DateBegin</parameter>
        <parameter n="DATE_END">Page.Panel_Filter.DF_DateEnd</parameter>
        <parameter n="CUSTOMER_CODE">Page.Panel_Filter.HND_CustomerCode</parameter>
		<parameter n="BY_REALIZED_DATE">Page.var_ByRealizedDate</parameter> 
		<parameter n="IS_SCREEN">Page.Panel_Filter.Screen</parameter>	
   </parameters>
</popupdata>
