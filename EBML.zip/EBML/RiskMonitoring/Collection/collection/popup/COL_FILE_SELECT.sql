<popupdata type="service">
	<service>CARD_COL_LIST_FILES</service>
    <parameters>
		<parameter n="CUSTOMER_CODE">Page.pnlFilter.hndCustomerCode</parameter>
		<parameter n="BRANCH_CODE">Page.pnlFilter.cmbBranchCode</parameter>
		<parameter n="IBAN_NUMBER">Page.pnlFilter.txtAccountCode</parameter>
		<parameter n="MIN_DEPT_AMOUNT">Page.pnlFilter.currMinDeptAmount</parameter>
		<parameter n="MAX_DEPT_AMOUNT">Page.pnlFilter.currMaxDeptAmount</parameter>
		<parameter n="CLASS_CODE">Page.pnlFilter.cmbClassCode</parameter>
		<parameter n="PRODUCT_MAIN_GROUP_CODE">Page.pnlFilter.cmbProductMainGroupCode</parameter>
		<parameter n="ENTER_DATE">Page.pnlFilter.dtEnterDate</parameter>
		<parameter n="STATE">Page.pnlFilter.cmbState</parameter>
		<parameter n="IS_SCREEN">Page.pnlFilter.Screen</parameter>
   </parameters>
</popupdata>