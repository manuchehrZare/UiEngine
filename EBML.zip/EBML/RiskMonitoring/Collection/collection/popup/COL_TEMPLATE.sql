<popupdata type="service">
	<service>CARD_COL_DEF_LIST_TEMPLATE</service>
    <parameters>
        <parameter n="TYPE">Page.pnlFilter.cmbType</parameter>
		<parameter n="CODE">Page.pnlFilter.txtCode</parameter>
   </parameters>
</popupdata>