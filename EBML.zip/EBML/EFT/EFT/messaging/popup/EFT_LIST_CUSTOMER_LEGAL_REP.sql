<popupdata type="service">
	<service>CUST_PERS_CREL_CUSTOMER_REPRESENTATIVE</service>
	    <parameters>
	        <parameter n="CUST_CUST_CUSTOMER_OID">Page.rgCustomer.Page.txtCustomerOid</parameter>
	    </parameters>
</popupdata>