<popupdata type="service">
	<service>ACCOUNTING_CORE_GL_LEAF_LIST</service>
	    <parameters>
	        <parameter n="GL_NAME" >Page.txtGLNAME</parameter>
	        <parameter n="GL_CODE">Page.txtGLCODE</parameter>
        </parameters>
</popupdata>

