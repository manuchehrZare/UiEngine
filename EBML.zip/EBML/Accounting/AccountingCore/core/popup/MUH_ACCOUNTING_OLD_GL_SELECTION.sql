<popupdata type="sql">
    <sql dataSource="BankingDS">
select distinct NEW_GL_CODE as GL_CODE 
		FROM ACCOUNTING.ACCOUNTING_PLAN_CHANGE_LOG 
		WHERE STATUS = '1' AND NEW_GL_CODE LIKE ? 
        AND ( ? is null or ? BETWEEN NEW_BEGIN_DATE AND NEW_END_DATE)
		order by GL_CODE  
 	 </sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.txtGLNumber</parameter>
    	<parameter>Page.dtToday</parameter>
    	<parameter>Page.dtToday</parameter>
	</parameters>
</popupdata>