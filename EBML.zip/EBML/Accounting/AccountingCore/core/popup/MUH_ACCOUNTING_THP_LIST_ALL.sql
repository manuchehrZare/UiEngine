<popupdata type="service">
	<service>ACCOUNTING_CORE_THP_LIST_ALL</service>
	    <parameters>
	        <parameter n="GL_NAME" >Page.txtGLNAME</parameter>
	        <parameter n="GL_CODE">Page.txtGLCODE</parameter>
        </parameters>
</popupdata>

