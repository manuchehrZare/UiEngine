<popupdata type="sql">
    <sql dataSource="BankingDS">
    	select distinct OID, GL_NAME, GL_CODE
        from ACCOUNTING.ACCOUNTING_PLAN
        where STATUS = '1' AND GL_NAME LIKE ? 
        AND ? IS NULL 
        AND GL_STATUS = '1' AND ? BETWEEN BEGIN_DATE AND END_DATE      
        UNION
        select OID, GL_NAME, GL_CODE
        from ACCOUNTING.ACCOUNTING_PLAN
        where STATUS = '1' AND (GL_NAME like ? AND
        GL_CODE like ?) 
        AND GL_STATUS = '1' 
        AND (? is null or ? BETWEEN BEGIN_DATE AND END_DATE)
        order by GL_CODE 
 	 </sql>
    <parameters>
    	<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
    	<parameter prefix="" suffix="" type="string">Page.txtGLNumber2</parameter>
    	<parameter>Page.dtToday</parameter>
    	<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
		<parameter prefix="" suffix="%">Page.txtGLNumber</parameter>	
		<parameter>Page.dtToday</parameter>
		<parameter>Page.dtToday</parameter>
	</parameters>
</popupdata>