<popupdata type="sql">
    <sql dataSource="BankingDS">
		select VOUCHER_NO, ACC_DATE, DESCRIPTION, OID 
		FROM ACCOUNTING.ACCOUNTING_VOUCHER
		WHERE ACCOUNTING_VOUCHER.STATUS = '1'
		AND (ACCOUNTING_VOUCHER.CANCELED <> '1'
		or ACCOUNTING_VOUCHER.CANCELED is null)
		AND ACCOUNTING_VOUCHER.VOUCHER_TYPE = ?
		AND VOUCHER_NO like ?
		AND ACC_DATE BETWEEN ? AND ?
		ORDER BY VOUCHER_NO
	</sql>
    <parameters>
		<parameter prefix="" suffix="">Page.txtVoucherType</parameter>
    	<parameter prefix="" suffix="%">Page.txtVoucherNo</parameter>
    	<parameter prefix="" suffix="">Page.dtStartDate</parameter>
		<parameter prefix="" suffix="">Page.dtEndDate</parameter>
	</parameters>
</popupdata>