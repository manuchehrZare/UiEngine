<popupdata type="service">
	<service>ACCOUNTING_CORE_ACCOUNTING_VOUCHER_DETAIL_DELETE</service>
	<parameters>
	     <parameter n="TODAY">Page.dtToday</parameter>
		 <parameter n="DESCRIPTION">Page.txtPaneDescription</parameter>
	     <parameter n="VALUE_DATE">Page.txtValueDate</parameter>
		 <parameter n="VOUCHER_OID">Page.txtVoucherOID</parameter>
    </parameters>
</popupdata>