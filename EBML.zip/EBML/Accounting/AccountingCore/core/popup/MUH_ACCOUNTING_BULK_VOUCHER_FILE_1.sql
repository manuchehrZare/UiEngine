<popupdata type="sql">

    <sql dataSource="BankingDS">
		SELECT oid, transaction_date, transaction_time, transaction_branch_code, user_no, state, src_type, ref_id_list, reference_id
		FROM accounting.accounting_bulk_v_file
		WHERE status = '1' and transaction_date = '19841214' 
		and oid like ? 
	</sql>
	
    <parameters>
    
    	<parameter prefix="" suffix="">Page.txtOpenFile</parameter>
    	
	</parameters>

</popupdata>


