<popupdata type="service">
	<service>ACCOUNTING_CORE_GL_LIST_FOR_MANUAL_VOUCHER</service>
	    <parameters>
	        <parameter n="GL_NAME" >Page.txtGLNAME</parameter>
	        <parameter n="GL_CODE">Page.txtGLCODE</parameter>
        </parameters>
</popupdata>

