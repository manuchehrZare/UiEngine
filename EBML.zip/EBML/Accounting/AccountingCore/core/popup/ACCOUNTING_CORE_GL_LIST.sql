<popupdata type="sql">
  <sql dataSource="BankingDS">
		SELECT distinct OID, GL_NAME, GL_CODE,GL_CURRENCY_TYPE,GL_CURRENCY_CODE,OPEN_TO_BRANCHES, DECODE(actual_and_verse_def,'A','AKTIF','P','PASIF','D','DIGER',actual_and_verse_def) AS ACTUAL_AND_VERSE_DEF
	FROM ACCOUNTING.ACCOUNTING_PLAN
	 WHERE NVL(?,'NULL') ='1'
	   AND oid in (
	    SELECT distinct PARENT_ACC_OID
	    FROM ACCOUNTING.ACCOUNTING_PLAN
	    WHERE STATUS = '1'
	      AND NVL(?,'NULL') IN('NULL',GL_STATUS)
	      AND NVL(?,'NULL') IN('NULL',FAST_ACCOUNTING)
	      AND NVL(?,'NULL') IN('NULL',IS_LEAF)
	      AND NVL(?,BEGIN_DATE) BETWEEN BEGIN_DATE AND END_DATE  
	      AND GL_NAME LIKE NVL2(?,'%'||?||'%','%')
	      AND GL_CODE like NVL2(?,?||'%','%')
	      AND GL_CURRENCY_TYPE = 'YP')
	UNION
	SELECT distinct OID, GL_NAME, GL_CODE,GL_CURRENCY_TYPE,GL_CURRENCY_CODE,OPEN_TO_BRANCHES, DECODE(actual_and_verse_def,'A','AKTIF','P','PASIF','D','DIGER',actual_and_verse_def) AS ACTUAL_AND_VERSE_DEF 
	FROM ACCOUNTING.ACCOUNTING_PLAN
	WHERE NVL(?,'NULL') !='1'
	      AND STATUS = '1'  
	      AND NVL(?,'NULL') IN('NULL',GL_STATUS)
	      AND NVL(?,'NULL') IN('NULL',FAST_ACCOUNTING)
	      AND NVL(?,'NULL') IN('NULL',IS_LEAF)
	      AND NVL(?,BEGIN_DATE) BETWEEN BEGIN_DATE AND END_DATE  
	      AND GL_NAME LIKE NVL2(?,'%'||?||'%','%')
	      AND GL_CODE like NVL2(?,?||'%','%')
	      AND GL_CURRENCY_TYPE IN('YP','XX')
	UNION
	SELECT distinct OID, GL_NAME, GL_CODE,GL_CURRENCY_TYPE,GL_CURRENCY_CODE,OPEN_TO_BRANCHES , DECODE(actual_and_verse_def,'A','AKTIF','P','PASIF','D','DIGER',actual_and_verse_def) AS ACTUAL_AND_VERSE_DEF 
	FROM ACCOUNTING.ACCOUNTING_PLAN
	WHERE STATUS = '1'  
	      AND NVL(?,'NULL') IN('NULL',GL_STATUS)
	      AND NVL(?,'NULL') IN('NULL',FAST_ACCOUNTING)
	      AND NVL(?,'NULL') IN('NULL',IS_LEAF)
	      AND NVL(?,BEGIN_DATE) BETWEEN BEGIN_DATE AND END_DATE  
	      AND GL_NAME LIKE NVL2(?,'%'||?||'%','%')
	      AND GL_CODE like NVL2(?,?||'%','%')
	      AND GL_CURRENCY_TYPE IN('TP','AD')
	ORDER BY GL_CODE
  </sql>
    <parameters>
    	<parameter>Page.pnlParams.txtParamOnlyParentForYP</parameter>
    	<parameter>Page.pnlParams.txtParamIsGLActive</parameter>
    	<parameter>Page.pnlParams.txtParamFastAccounting</parameter>
    	<parameter>Page.pnlParams.txtParamIsLeaf</parameter>
    	<parameter>Page.pnlParams.dtParamValidDate</parameter>
    	<parameter>Page.txtGLName</parameter>
    	<parameter>Page.txtGLName</parameter>
    	<parameter>Page.txtGLNumber</parameter>	
    	<parameter>Page.txtGLNumber</parameter>	
    	<parameter>Page.pnlParams.txtParamOnlyParentForYP</parameter>
    	<parameter>Page.pnlParams.txtParamIsGLActive</parameter>
    	<parameter>Page.pnlParams.txtParamFastAccounting</parameter>
    	<parameter>Page.pnlParams.txtParamIsLeaf</parameter>
    	<parameter>Page.pnlParams.dtParamValidDate</parameter>
    	<parameter>Page.txtGLName</parameter>
    	<parameter>Page.txtGLName</parameter>
    	<parameter>Page.txtGLNumber</parameter>	
    	<parameter>Page.txtGLNumber</parameter>	
    	<parameter>Page.pnlParams.txtParamIsGLActive</parameter>
    	<parameter>Page.pnlParams.txtParamFastAccounting</parameter>
        <parameter>Page.pnlParams.txtParamIsLeaf</parameter>
    	<parameter>Page.pnlParams.dtParamValidDate</parameter>
    	<parameter>Page.txtGLName</parameter>
    	<parameter>Page.txtGLName</parameter>
    	<parameter>Page.txtGLNumber</parameter>	
    	<parameter>Page.txtGLNumber</parameter>	
	</parameters>
</popupdata>