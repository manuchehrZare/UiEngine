<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT oid, transaction_date, transaction_time, transaction_branch_code, user_no, state, src_type, ref_id_list, reference_id
		FROM accounting.accounting_bulk_v_file
		WHERE status = '1' and transaction_date = ? 
		and user_no like ? and transaction_branch_code like ?
		and nvl(ref_id_list,0)like ?
		and state in ('Haz�r', 'Onayda', 'Tamamland�','�ptal Edildi')
	</sql>
    <parameters>
    	<parameter prefix="" suffix="">Page.dtDate</parameter>
		<parameter prefix="" suffix="%">Page.txtUser</parameter>
		<parameter prefix="" suffix="%">Page.cmbBranch</parameter>
		<parameter prefix="" suffix="%">Page.txtReferenceNo</parameter>
	</parameters>
</popupdata>
 