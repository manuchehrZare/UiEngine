<popupdata type="service">
	<service>ACCOUNTING_LIST_ACCOUNT</service>
	    <parameters>
    	    <parameter n="ACC_NAME">Page.txtAccName</parameter>
    	    <parameter n="ACCOUNTING_TYPE_OID">Page.cmbAccountingType</parameter>
    	    <parameter n="PP_EXECUTE">Page.txtExecute</parameter>
	    </parameters>
</popupdata>