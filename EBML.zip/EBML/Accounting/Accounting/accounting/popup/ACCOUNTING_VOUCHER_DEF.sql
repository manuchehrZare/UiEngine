<popupdata type="service">
	<service>ACCOUNTING_LIST_ACCOUNTING_VOUCHER_DEFS</service>
	    <parameters>
    	    <parameter n="PROCESS_GROUP_OID">Page.cmbProcessGroup</parameter>
	        <parameter n="PROCESS_ID">Page.cmbProcessDef</parameter>
	        <parameter n="ACCOUNTING_TYPE_OID">Page.cmbAccountingType</parameter>
	        <parameter n="PROCESS_TYPE">Page.cmbProcessType</parameter>
	        <parameter n="DONT_LIST">Page.txtDontList</parameter>
	    </parameters>
</popupdata>