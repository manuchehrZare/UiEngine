<popupdata type="service">
	<service>ACCOUNTING_LIST_META_ACC_DEF</service>
	    <parameters>
	        <parameter n="META_ACC_NAME">Page.txtMetaAccName</parameter>
	        <parameter n="DONT_LIST">Page.txtDontList</parameter>
	    </parameters>
</popupdata>