<popupdata type="sql">
    <sql dataSource="BankingDS">
        select distinct def.OID as META_ACC_OID,
                def.META_ACC_NAME
        from ACCOUNTING.ACCOUNTING_META_ACC_DEF def,
             ACCOUNTING.ACCOUNTING_META_ACC_NODES node
        where def.STATUS = '1' AND META_ACC_NAME like ? 
        and def.OID <> node.META_ACC_OID and ? is null       
        UNION
        select def.OID as META_ACC_OID,
                def.META_ACC_NAME
        from ACCOUNTING.ACCOUNTING_META_ACC_DEF def,
             ACCOUNTING.ACCOUNTING_META_ACC_NODES node
        where def.STATUS = '1' AND (def.META_ACC_NAME like ? AND
        node.GL_CODE like ?) AND
        def.OID = node.META_ACC_OID AND node.NODE_OR_LEAF = '1'
        order by META_ACC_NAME 
      </sql>
    <parameters>
        <parameter prefix="%" suffix="%">Page.txtMetaAccName</parameter>
        <parameter prefix="" suffix="" type="string">Page.txtGLNumber2</parameter>
        <parameter prefix="%" suffix="%">Page.txtMetaAccName</parameter>
        <parameter prefix="" suffix="%">Page.txtGLNumber</parameter>
    </parameters>
</popupdata>
