<popupdata type="sql">
    <sql dataSource="BankingDS">
       select distinct NEW_META_NAME as META_NAME
        from ACCOUNTING.ACCOUNTING_SC_CHANGE_LOG
        where STATUS = '1' AND NEW_META_NAME like ?
        and ? is null       
        UNION
        select NEW_META_NAME
        from ACCOUNTING.ACCOUNTING_SC_CHANGE_LOG
        where STATUS = '1' AND (NEW_META_NAME like ? AND
        NEW_STATISTICAL_CODE like ?)     
        order by META_NAME 
      </sql>
    <parameters>
        <parameter prefix="%" suffix="%">Page.txtMetaAccName</parameter>
        <parameter prefix="" suffix="" type="string">Page.txtSCNumber2</parameter>
        <parameter prefix="%" suffix="%">Page.txtMetaAccName</parameter>
        <parameter prefix="" suffix="%">Page.txtSCNumber</parameter>
    </parameters>
</popupdata>
