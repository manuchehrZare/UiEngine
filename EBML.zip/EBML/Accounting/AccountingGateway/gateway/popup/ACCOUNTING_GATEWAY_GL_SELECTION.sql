<popupdata type="sql">
    <sql dataSource="BankingDS">
    	  select distinct OID, GL_NAME, GL_CODE
		  from ACCOUNTING.ACCOUNTING_PLAN where oid in (	
		  select distinct PARENT_ACC_OID
		  from ACCOUNTING.ACCOUNTING_PLAN
		  where STATUS = '1' AND GL_NAME LIKE ? 
          AND ? IS NULL AND IS_LEAF = '1'
		  AND GL_STATUS = '1' AND ? BETWEEN BEGIN_DATE AND END_DATE   
 	      AND GL_CURRENCY_TYPE = 'YP'   )
	UNION
		  select OID, GL_NAME, GL_CODE
		  from ACCOUNTING.ACCOUNTING_PLAN where oid in (
 		  select distinct PARENT_ACC_OID
 		  from ACCOUNTING.ACCOUNTING_PLAN
		  where STATUS = '1' AND (GL_NAME like ? AND
		  GL_CODE like ?) AND IS_LEAF = '1'
		  AND GL_STATUS = '1' AND ? BETWEEN BEGIN_DATE AND END_DATE
		  AND GL_CURRENCY_TYPE = 'YP')
	UNION
		  select distinct OID, GL_NAME, GL_CODE
          from ACCOUNTING.ACCOUNTING_PLAN
          where STATUS = '1' AND GL_NAME LIKE ? 
          AND ? IS NULL AND IS_LEAF = '1'
          AND GL_STATUS = '1' AND ? BETWEEN BEGIN_DATE AND END_DATE
          AND GL_CURRENCY_TYPE = 'TP'      
    UNION
          select OID, GL_NAME, GL_CODE
          from ACCOUNTING.ACCOUNTING_PLAN
          where STATUS = '1' AND (GL_NAME like ? AND
          GL_CODE like ?) AND IS_LEAF = '1'
          AND GL_STATUS = '1' AND ? BETWEEN BEGIN_DATE AND END_DATE
          AND GL_CURRENCY_TYPE = 'TP'
    UNION
          select OID, GL_NAME, GL_CODE
          from ACCOUNTING.ACCOUNTING_PLAN
          where STATUS = '1' AND (GL_NAME like ? AND
          GL_CODE like ?) AND IS_LEAF = '1'
          AND GL_STATUS = '1' AND ? BETWEEN BEGIN_DATE AND END_DATE
          AND GL_CURRENCY_TYPE = 'AD'
	order by GL_CODE 
 	 </sql>
    <parameters>
    	<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
    	<parameter prefix="" suffix="" type="string">Page.txtGLNumber2</parameter>
    	<parameter>Page.dtToday</parameter>
    	<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
		<parameter prefix="" suffix="%">Page.txtGLNumber</parameter>	
		<parameter>Page.dtToday</parameter>
		<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
		<parameter prefix="" suffix="%">Page.txtGLNumber</parameter>	
		<parameter>Page.dtToday</parameter>
		<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
		<parameter prefix="" suffix="%">Page.txtGLNumber</parameter>	
		<parameter>Page.dtToday</parameter>
		<parameter prefix="%" suffix="%">Page.txtGLName</parameter>
		<parameter prefix="" suffix="%">Page.txtGLNumber</parameter>	
		<parameter>Page.dtToday</parameter>
	</parameters>
</popupdata>

