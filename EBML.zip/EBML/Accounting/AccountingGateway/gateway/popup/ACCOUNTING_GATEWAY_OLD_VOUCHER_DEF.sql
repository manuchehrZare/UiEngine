<popupdata type="sql">
    <sql dataSource="BankingDS">
		select  distinct eproc.PROCESS_ID || '-' || PROCESS_NAME AS PROCESS_ID   
FROM 	ACCOUNTING.ACCOUNTING_VOUC_DEF_CHNG_LOG def , 
        ACCOUNTING.ACCOUNTING_VOUCHER_CHANGE_LOG par,
        ACCOUNTING.ACCOUNTING_TYPES type,
        INFRA.EPROC_PROCESS_DEFINITION eproc
WHERE def.STATUS = '1' 
AND (def.PROCESS_ID =  ? or ? is null)
AND (def.PROCESS_TYPE = ? or ? is null)
AND (def.ACCOUNTING_TYPE_OID =   ? or ? is null) 
and def.oid = par.VOUCHER_OID
and def.PROCESS_ID = eproc.PROCESS_ID
and type.OID = def.ACCOUNTING_TYPE_OID
 	 </sql>
    <parameters>
    	<parameter prefix="" suffix="">Page.cmbProcessDef</parameter>
    	<parameter prefix="" suffix="">Page.cmbProcessDef</parameter>
		<parameter prefix="" suffix="">Page.cmbProcessType</parameter>
		<parameter prefix="" suffix="">Page.cmbProcessType</parameter>
		<parameter prefix="" suffix="">Page.cmbAccountingType</parameter>
		<parameter prefix="" suffix="">Page.cmbAccountingType</parameter>
	</parameters>
</popupdata>