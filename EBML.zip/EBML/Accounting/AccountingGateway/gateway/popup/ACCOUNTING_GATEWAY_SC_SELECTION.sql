<popupdata type="sql">
    <sql dataSource="BankingDS">
        select distinct def.OID as META_OID,
                def.META_NAME
        from ACCOUNTING.ACCOUNTING_SC_META_DEF def,
             ACCOUNTING.ACCOUNTING_SC_NODES node
        where def.STATUS = '1' AND META_NAME like ? 
        and def.OID <> node.META_OID(+) and ? is null        
        UNION
        select def.OID as META_OID,
                def.META_NAME
        from ACCOUNTING.ACCOUNTING_SC_META_DEF def,
             ACCOUNTING.ACCOUNTING_SC_NODES node
        where def.STATUS = '1' AND (def.META_NAME like ? AND
        node.STATISTICAL_CODE like ?) AND
        def.OID = node.META_OID(+) AND node.NODE_OR_LEAF = '1'
        order by META_NAME 
      </sql>
    <parameters>
        <parameter prefix="%" suffix="%">Page.txtMetaName</parameter>
        <parameter prefix="" suffix="" type="string">Page.txtStatisticalCode2</parameter>
        <parameter prefix="%" suffix="%">Page.txtMetaName</parameter>
        <parameter prefix="" suffix="%">Page.txtStatisticalCode</parameter>
    </parameters>
</popupdata>
