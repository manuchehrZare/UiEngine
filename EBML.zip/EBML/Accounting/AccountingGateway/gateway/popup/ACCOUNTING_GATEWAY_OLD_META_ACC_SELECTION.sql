<popupdata type="sql">
    <sql dataSource="BankingDS">
       select distinct NEW_META_ACC_NAME as META_ACC_NAME
        from ACCOUNTING.ACCOUNTING_META_ACC_CHANGE_LOG
        where STATUS = '1' AND NEW_META_ACC_NAME like ?
        and ? is null       
        UNION
        select NEW_META_ACC_NAME
        from ACCOUNTING.ACCOUNTING_META_ACC_CHANGE_LOG
        where STATUS = '1' AND (NEW_META_ACC_NAME like ? AND
        NEW_GL_CODE like ?)     
        order by META_ACC_NAME 
      </sql>
    <parameters>
        <parameter prefix="%" suffix="%">Page.txtMetaAccName</parameter>
        <parameter prefix="" suffix="" type="string">Page.txtGLNumber2</parameter>
        <parameter prefix="%" suffix="%">Page.txtMetaAccName</parameter>
        <parameter prefix="" suffix="%">Page.txtGLNumber</parameter>
    </parameters>
</popupdata>
