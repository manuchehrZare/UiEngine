<popupdata type="sql">
    <sql dataSource="BankingDS">
      select rr.oid ,rr.USER_FILE_NO, 
          rr.name || ' ' ||rr.last_name as NAME, 
          rr.PROFIT_CENTER_CODE
      from infra.cust_cust_rep rr 
      where rr.status='1' 
        and rr.branch_code=?  
	</sql>
    <parameters>
		<parameter prefix="" suffix="">Page.cmbBranch</parameter>
	</parameters>
</popupdata>
 