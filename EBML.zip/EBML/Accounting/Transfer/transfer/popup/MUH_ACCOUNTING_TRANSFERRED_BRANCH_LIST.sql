<popupdata type="service">
	<service>ACCOUNTING_BRANCH_ASSIGNMENT_GET_BRANCHES</service>
	<parameters>
    </parameters>
</popupdata>