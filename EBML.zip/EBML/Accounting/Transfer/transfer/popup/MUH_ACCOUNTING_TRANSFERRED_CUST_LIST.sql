<popupdata type="service">
	<service>ACCOUNTING_BRANCH_ASSIGNMENT_GET_CUST</service>
	<parameters>
    </parameters>
</popupdata>