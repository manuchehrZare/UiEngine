<popupdata type="service">
	<service>POS_BILL_PAYMENT_QUERY_INSTITUTIONS</service>
	    <parameters>
	        <parameter n="CITY_CODE">ppInstitutionSearch.pnlFilter.cmbCity</parameter>
	        <parameter n="SECTOR_CODE">ppInstitutionSearch.pnlFilter.cmbSector</parameter> 
	        <parameter n="INSTITUTION_NAME">ppInstitutionSearch.pnlFilter.tfInstitutionName</parameter> 
	    </parameters>
</popupdata>