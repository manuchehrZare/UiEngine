<popupdata type="service">
	<service>POS_BILL_PAYMENT_QUERY_TERMINALS</service>
	    <parameters>
	        <parameter n="CUSTOMER_CODE">ppTerminalSearch.pnlFilter.hndCustomerCode</parameter>
	        <parameter n="TERMINAL_NO">ppTerminalSearch.pnlFilter.tbTerminalNo</parameter>
	        <parameter n="MERCHANT_NO">ppTerminalSearch.pnlFilter.tbMerchantNo</parameter>    
	    </parameters>
</popupdata>