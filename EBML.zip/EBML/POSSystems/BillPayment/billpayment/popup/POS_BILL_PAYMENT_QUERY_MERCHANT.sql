<popupdata type="service">
	<service>POS_BILL_PAYMENT_QUERY_MERCHANTS</service>
	    <parameters>
	        <parameter n="CUSTOMER_CODE">ppMerchantSearch.pnlFilter.hndCustomerCode</parameter>
	        <parameter n="TERMINAL_NO">ppMerchantSearch.pnlFilter.tbTerminalNo</parameter>
	        <parameter n="MERCHANT_NO">ppMerchantSearch.pnlFilter.tbMerchantNo</parameter>    
	    </parameters>
</popupdata>