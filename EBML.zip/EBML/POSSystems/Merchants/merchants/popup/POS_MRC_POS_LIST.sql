<popupdata type="service">
	<service>POS_MRC_MASTER_LIST_BY_ORGID</service>
	    <parameters>
	        <parameter n="POS_NO">Page.pnlPosFilter.txtPosNo</parameter>
	        <parameter n="POS_NAME">Page.pnlPosFilter.txtPosAdi</parameter>	       
	        <parameter n="POS_STATE">Page.pnlPosFilter.cmbPosState</parameter>	 
			<parameter n="ORG_CODE">Page.pnlPosFilter.lblOrgCode</parameter>			
			<parameter n="POS_ISYERINO">Page.pnlPosFilter.ppMrcNo</parameter>			
         </parameters>
</popupdata>