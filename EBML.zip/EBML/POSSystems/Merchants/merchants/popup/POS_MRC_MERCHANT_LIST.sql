<popupdata type="service">
	<service>POS_MRC_MERCHANT_MERCHANT_LIST_FOR_POPUP</service>
	    <parameters>
	        <parameter n="MERCHANT_CODE">Page.pnlFilter.txtMerchantCode</parameter>
	        <parameter n="CUST_CODE">Page.pnlFilter.txtCustomerCode</parameter>
	        <parameter n="TABLE_NAME">Page.pnlFilter.txtTableName</parameter>
	        <parameter n="TRADE_NAME">Page.pnlFilter.txtTradeName</parameter>
	        <parameter n="CONTRACT_BRANCH">Page.pnlFilter.cmbContractBranch</parameter>
	        <parameter n="ORG_CODE">Page.lblPosOrganizationCode</parameter>
	        <parameter n="CRUD_MODE">Page.lblMode</parameter>                             
         </parameters>
</popupdata>