<popupdata type="service">
	<service>HMRS_PRM_LIST_FORMULA_CONTENTS</service>
    <parameters>
		<parameter n="SCENARIO_OID">Page.cmbScenario</parameter>							
	    <parameter n="IS_CRITERIA_SELECTED">Page.rdGroup.rdCriteria</parameter>							
   </parameters>
</popupdata>