<popupdata type="service">
    <service>IKS_CORE_OPERATIONAL_REPORT_INFO</service>
        <parameters>            
            <parameter n="REPORT_NO">Page.pnlQueryRestrict.txtReportNo</parameter>
            <parameter n="OPEN_BY_USER">Page.pnlQueryRestrict.hndOpenByUser</parameter>
            <parameter n="FILE_NO">Page.pnlQueryRestrict.hndUserNo</parameter>
            <parameter n="BRANCH_CODE">Page.pnlQueryRestrict.cmbBranchCode</parameter>
            <parameter n="REPORT_TYPE">Page.pnlQueryRestrict.cmbReportType</parameter>
            <parameter n="STATE">Page.pnlQueryRestrict.cmbState</parameter>            
            <parameter n="BEGIN_DATE">Page.pnlQueryRestrict.pnlReportDates.dfReportOpenDate</parameter>
            <parameter n="END_DATE">Page.pnlQueryRestrict.pnlReportDates.dfReportEndDate</parameter>
            <parameter n="USER_ORG_CODE">Page.pnlQueryRestrict.cmbOrgUserCode</parameter>
        </parameters>
</popupdata>