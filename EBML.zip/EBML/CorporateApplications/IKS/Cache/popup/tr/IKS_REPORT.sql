<popupdata type="service">
    <service>IKS_CORE_REPORT_INFO</service>
        <parameters>            
            <parameter n="REPORT_NO">Page.pnlQueryRestrict.txtReportNo</parameter>
            <parameter n="OPEN_BY_USER">Page.pnlQueryRestrict.hndOpenByUser</parameter>
            <parameter n="CUSTOMER_CODE">Page.pnlQueryRestrict.hndCustomerCode</parameter>
            <parameter n="BRANCH_CODE">Page.pnlQueryRestrict.cmbBranchCode</parameter>
            <parameter n="SEGMENT">Page.pnlQueryRestrict.cmbSegment</parameter>
            <parameter n="RISK_CODE">Page.pnlQueryRestrict.cmbRiskCode</parameter>
            <parameter n="STATE">Page.pnlQueryRestrict.cmbState</parameter>
            <parameter n="BEGIN_DATE">Page.pnlQueryRestrict.pnlReportDates.dfReportOpenDate</parameter>
            <parameter n="END_DATE">Page.pnlQueryRestrict.pnlReportDates.dfReportEndDate</parameter>
        </parameters>
</popupdata>