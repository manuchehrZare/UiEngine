<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT 
	VAR.* 		
FROM 
BPM.PROCESS_DOC_RELATION_VARIABLE VAR 
WHERE 
VAR.NAME LIKE ? 
ORDER BY VAR.NAME	
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">Page.txtAttrName</parameter>
    </parameters>
</popupdata>
