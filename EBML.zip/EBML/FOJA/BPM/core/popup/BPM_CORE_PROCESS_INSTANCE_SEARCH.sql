<popupdata type="service">
	<service>BPM_CORE_PROCESS_INSTANCE_SEARCH</service>
	    <parameters>
	        <parameter n="CUSTOMER_NO">ProcessInstanceSearch.pnlCriteria.hndCustomer</parameter>
	        <parameter n="REFERENCE_ID">ProcessInstanceSearch.pnlCriteria.txtReferenceID</parameter>
	        <parameter n="PROCESS_DEFINITION_NAME">ProcessInstanceSearch.pnlCriteria.hndProcess</parameter>
	        <parameter n="START_DATE1">ProcessInstanceSearch.pnlCriteria.txtStartTime1</parameter>
	        <parameter n="START_DATE2">ProcessInstanceSearch.pnlCriteria.txtStartTime2</parameter>
	        <parameter n="END_DATE1">ProcessInstanceSearch.pnlCriteria.txtFinishTime1</parameter>
	        <parameter n="END_DATE2">ProcessInstanceSearch.pnlCriteria.txtFinishTime2</parameter>
			<parameter n="PROCESS_STATUS">ProcessInstanceSearch.pnlCriteria.cmbStatus</parameter>
	      </parameters>
</popupdata>