<popupdata type="service">
	<service>BPM_CORE_PROCESS_DEFINITION_NAME_SEARCH</service>
	    <parameters>
	        <parameter n="PROCESS_DEFINITION_NAME">Page.pnlCriteria.txtProcessID</parameter>
	        <parameter n="PROCESS_DEFINITION_LABEL">Page.pnlCriteria.txtProcessName</parameter>
	        <parameter n="PROCESS_GROUP_OID">Page.pnlCriteria.cmbProcessGroup</parameter>
	    </parameters>
</popupdata>