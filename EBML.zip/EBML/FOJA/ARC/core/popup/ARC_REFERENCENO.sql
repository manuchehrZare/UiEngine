<popupdata type="service">
    <service>ARC_CORE_GET_MULTIPLE_DOC_EDITING_LIST</service>
    <parameters>    	
    	<parameter n="REFERENCE_NO">Page.pnlDocumentInfo.txtReferenceNo</parameter> 
        <parameter n="ROOM_NO">Page.pnlDocumentInfo.txtRoomNo</parameter>
        <parameter n="BOX_NO">Page.pnlDocumentInfo.txtBoxNo</parameter>
        <parameter n="ORGANIZATION_ID">Page.pnlDocumentInfo.cmbFakeOrganization</parameter>
        <parameter n="UNIT_ID">Page.pnlDocumentInfo.cmbUserUnit</parameter>
		<parameter n="ARCHIVE_GROUP">Page.pnlDocumentInfo.cmbArcGroup</parameter>
        <parameter n="ENTRY_USER">Page.pnlDocumentInfo.hndOwner</parameter>
		<parameter n="FILE_NO">Page.pnlDocumentInfo.txtFileNo</parameter>
		<parameter n="ARC_DOC_TYPE">Page.pnlDocumentInfo.cmbDocTypes</parameter>
		<parameter n="START_DATE_1">Page.pnlDocumentInfo.dtStart1</parameter>
		<parameter n="START_DATE_2">Page.pnlDocumentInfo.dtStart2</parameter>
		<parameter n="END_DATE_1">Page.pnlDocumentInfo.dtEnd1</parameter>
		<parameter n="END_DATE_2">Page.pnlDocumentInfo.dtEnd2</parameter>
		<parameter n="DESTROY_DATE_1">Page.pnlDocumentInfo.dtDestroy1</parameter>
		<parameter n="DESTROY_DATE_2">Page.pnlDocumentInfo.dtDestroy2</parameter>
		<parameter n="YEAR">Page.pnlDocumentInfo.txtYear</parameter>
		<parameter n="DESCRIPTION">Page.pnlDocumentInfo.txtDescription</parameter>
		<parameter n="ARC_DOC_NAME">Page.pnlDocumentInfo.txtFileName</parameter>
		<parameter n="IS_EXISTS">Page.pnlDocumentInfo.cmbIsExists</parameter>
    </parameters>
</popupdata>
