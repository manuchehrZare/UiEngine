<popupdata type="service">
	<service>DMS_STRUCT_LIST_TYPES</service>
	    <parameters>
	        <parameter n="ITEM_TYPE">Page.txtItemType</parameter>
	    </parameters>
</popupdata>