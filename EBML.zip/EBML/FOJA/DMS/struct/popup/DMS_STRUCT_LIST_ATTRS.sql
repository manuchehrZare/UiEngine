<popupdata type="service">
	<service>DMS_STRUCT_LIST_ALL_ATTRIBUTES</service>
	    <parameters>
	        <parameter n="ATTR_NAME">Page.txtAttrName</parameter>
	    </parameters>
</popupdata>