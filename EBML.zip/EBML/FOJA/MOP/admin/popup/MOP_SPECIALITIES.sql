<popupdata type="sql">
	<sql dataSource="BankingDS">select ID,NAME,CHECKER_PROFILE_CODE, MAKER_PROFILE_CODE from MOP.ADMIN_SPECIALITY
	WHERE ID LIKE ? and NAME LIKE  ?
	</sql>
	<parameters>    	
    	<parameter prefix="" suffix="%">Page.txtSpecialityNo</parameter> 
        <parameter prefix="" suffix="%">Page.txtSpecialityName</parameter>       
    </parameters>
</popupdata>