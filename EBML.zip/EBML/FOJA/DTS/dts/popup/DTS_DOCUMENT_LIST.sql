<popupdata type="service">
	<service>DTS_DTS_LIST_DOCUMENTS</service>
    <parameters>
        <parameter n="DOC_ID">Page.pnlFilter.txtDocumentNo</parameter>
        <parameter n="BEGIN_CREATE_DATE">Page.pnlFilter.dtBeginReceiveDate</parameter>
        <parameter n="END_CREATE_DATE">Page.pnlFilter.dtEndReceiveDate</parameter>                
        <parameter n="DOC_TYPE">Page.pnlFilter.cmbDocType</parameter>
        <parameter n="DOC_SUB_TYPE">Page.pnlFilter.cmbDocSubType</parameter>
        <parameter n="SUBJECT">Page.pnlFilter.txtSubject</parameter>
        <parameter n="LIST_ONLY_MY_DOCUMENTS">Page.pnlFilter.lblListOnlyMyDocuments</parameter>
        <parameter n="CHARGED_ORG_CODE">Page.pnlFilter.lblChargedOrgCode</parameter>
        <parameter n="CREATE_UNIT">Page.pnlFilter.cmbSenderUnit</parameter> 
        <parameter n="PRIVATE_PERSON">Page.pnlFilter.txtReceiverPerson1</parameter>        
        <parameter n="RELATED_DOC_ID">Page.pnlFilter.hndReplyPaidDocNo1</parameter>
   </parameters>
</popupdata>