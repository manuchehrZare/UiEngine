<popupdata type="service">
	<service>DTS_DTS_LIST_POSTS</service>
    <parameters>
        <parameter n="POST_ID">Page.pnlFilter.txtPostNo</parameter>
        <parameter n="SENDER_UNIT_CODE">Page.pnlFilter.cmbOrganizations</parameter>        
        <parameter n="RECEIVER_CODE">Page.pnlFilter.rgnReceiverUnit.Page.txtReceiverCode</parameter>        
        <parameter n="RECEIVER_TYPE">Page.pnlFilter.rgnReceiverUnit.Page.txtReceiverType</parameter>                
        <parameter n="BEGIN_POST_DATE">Page.pnlFilter.dtBeginPostDate</parameter>
        <parameter n="END_POST_DATE">Page.pnlFilter.dtEndPostDate</parameter>                
        <parameter n="POST_TYPE">Page.pnlFilter.cmbPostType</parameter>
        <parameter n="SENDED_RECEIVED">Page.pnlFilter.lblSendedOrReceived</parameter>                
   </parameters>
</popupdata>