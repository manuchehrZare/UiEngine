<popupdata type="service">
	<service>DTS_TRANSFER_LIST_TRANSFERS</service>
    <parameters>    
    	<parameter n="TRANSFER_MAIN_ID">Page.pnlFilter.txtTransferMainID</parameter>
        <parameter n="DOC_ID">Page.pnlFilter.hndDocNo</parameter>
        <parameter n="RECEIVER_CODE">Page.pnlFilter.rgnReceiverUnit.Page.txtReceiverCode</parameter>
        <parameter n="RECEIVER_VALUE">Page.pnlFilter.rgnReceiverUnit.Page.txtReceiverValue</parameter>          
        <parameter n="RECEIVER_TYPE">Page.pnlFilter.rgnReceiverUnit.Page.txtReceiverType</parameter>                
 	    <parameter n="TRANSFER_START_DATE">Page.pnlFilter.dtTransferStartDate</parameter>
		<parameter n="TRANSFER_END_DATE">Page.pnlFilter.dtTransferEndDate</parameter>
 	    <parameter n="SEND_UNIT">Page.pnlFilter.lblSendUnit</parameter>         	    
 	    <parameter n="SEND_STATUS">Page.pnlFilter.txtSendStatus</parameter>         	    
   	    <parameter n="EXECUTE_QUERY">Page.pnlFilter.txtExecuteQuery</parameter>         	    
	    <parameter n="POST_ID_IS_NULL">Page.pnlFilter.txtPostIdIsNull</parameter>         	       	    
   </parameters>
</popupdata>