<popupdata type="service">
	<service>DTS_DTS_LIST_DOCUMENTS</service>
    <parameters>
        <parameter n="DOC_ID">Page.pnFilter.txtDocumentNo</parameter>
        <parameter n="BEGIN_CREATE_DATE">Page.pnFilter.dtBeginReceiveDate</parameter>
        <parameter n="END_CREATE_DATE">Page.pnFilter.dtEndReceiveDate</parameter>                
        <parameter n="DOC_TYPE">Page.pnFilter.cmbDocType</parameter>
        <parameter n="DOC_SUB_TYPE">Page.pnFilter.cmbDocSubType</parameter>
        <parameter n="LIST_ONLY_MY_DOCUMENTS">Page.pnFilter.lblListOnlyMyDocuments</parameter>
        <parameter n="CHARGED_ORG_CODE">Page.pnFilter.lblChargedOrgCode</parameter>
        <parameter n="CREATE_UNIT">Page.pnFilter.cmbSenderUnit</parameter> 
        <parameter n="PRIVATE_PERSON">Page.pnFilter.txtReceiverPerson1</parameter>                
   </parameters>
</popupdata>