<popupdata type="service">
	<service>UBS_DEFINITION_LIST_ACTIVITY</service>
	    <parameters>
	        <parameter n="ACTIVITY_CODE">Page.pnlAktivityInfo.txtActivityCode</parameter>
	        <parameter n="ACTIVITY_NAME">Page.pnlAktivityInfo.txtActivityName</parameter>
	        <parameter n="ACTIVITY_ACTIVITY_GROUP_CODE">Page.pnlAktivityInfo.handleBtnActivityGrub</parameter>
   	        <parameter n="ACTIVITY_STATUS">Page.pnlAktivityInfo.cmbBoxStatus</parameter>
	    </parameters>
</popupdata>