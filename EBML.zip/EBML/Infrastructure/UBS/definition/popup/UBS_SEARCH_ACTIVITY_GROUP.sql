<popupdata type="service">
	<service>UBS_DEFINITION_LIST_ACTIVITY_GROUP</service>
	    <parameters>
	  		<parameter n="ACTIVITY_GROUP_CODE">Page.PanelAktiviteGrubuBilgileri.txtActivityGroupCode</parameter>
	        <parameter n="ACTIVITY_GROUP_NAME">Page.PanelAktiviteGrubuBilgileri.txtActivityGroupName</parameter>    
	    </parameters>
</popupdata>