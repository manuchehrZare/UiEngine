<popupdata type="service">
	<service>UBS_DEFINITION_LIST_NOTIFICATIONS</service>
	    <parameters>
	        <parameter n="DESCRIPTION">Page.txtNotificationName</parameter>
	        <parameter n="CODE">Page.txtNotificationCode</parameter>
	        <parameter n="CHANNEL">Page.cbNotificationChannel</parameter>
   	        <parameter n="PRIORITY">Page.cbNotificationPriority</parameter>
   	        <parameter n="COMMON_CONTENT">Page.txtCommonContent</parameter>
   	        <parameter n="ADD_DELETED">Page.chkAddDeleted</parameter>
   	        <parameter n="EMAIL_SUBJECT">Page.pnlEmail.txtEmailSubject</parameter>
			<parameter n="EMAIL_PRIORITY">Page.pnlEmail.cbEmailPriority</parameter>
   	        <parameter n="EMAIL_SENDER">Page.pnlEmail.txtEmailSender</parameter>
   	        <parameter n="ALERT_SENDER">Page.pnlAlert.txtAlertSender</parameter>
   	        <parameter n="ALERT_IS_POPUP">Page.pnlAlert.cmbIsPopUp</parameter>
   	        <parameter n="ALERT_DEFINED_MSG_ID">Page.pnlAlert.cmbAlertID</parameter>
   	        <parameter n="SMS_SERVICE">Page.pnlSMS.cbSMSService</parameter>
   	        <parameter n="FAX_SENDER">Page.pnlFax.cbFaxSender</parameter>
   	        <parameter n="PROCESS_PROCESS_ID">Page.pnlProcess.hbProcessNumber</parameter>
   	        <parameter n="MEMO_UPPER_CODE">Page.pnlMemo.cbMemoUpperCode</parameter>
   	        <parameter n="MEMO_LOWER_CODE">Page.pnlMemo.cbMemoLowerCode</parameter>
   	        <parameter n="MEMO_ACTION">Page.pnlMemo.cbMemoAction</parameter>
	    </parameters>
</popupdata>