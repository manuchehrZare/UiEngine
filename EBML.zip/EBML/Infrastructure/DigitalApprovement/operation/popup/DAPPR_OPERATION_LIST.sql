<popupdata type="service">
	<service>DAPPR_GET_OPERATION_DEFINITION_LIST</service>
	    <parameters>
	    	<parameter n="OPERATION_CODE">page.pnlOperationSearch.txtOperationCode</parameter>
			<parameter n="IGNORE_CHANNEL_FILTER">page.pnlOperationSearch.txtIgnoreChannelFilter</parameter>
	    </parameters>
</popupdata>