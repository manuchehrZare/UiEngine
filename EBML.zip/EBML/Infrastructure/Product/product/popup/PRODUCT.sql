<popupdata type="sql">
    <sql dataSource="BankingDS">
	SELECT T3.OID AS PRODUCT_OID, 
		T3.PRODUCT_CODE, 
		T3.PRODUCT_NAME, 
		T3.MAIN_GROUP_CODE, 
		T1.OID AS MAIN_GROUP_OID, 
		T3.GROUP_CODE, 
		T2.OID AS GROUP_OID, 
		T3.PRODUCT_DESCRIPTION, 
		T3.PRODUCT_PROFIT_CENTER, 
		T3.ORGANIZATION_CODE, 
		T3.PORTFOLIO_PRODUCT, 
		T3.PORTFOLIO_SCREEN_CODE, 
		T3.DETAIL_SCREEN_CODE, 
		T3.EXTERNAL_REFERENCE_CODE 
	FROM INFRA.PROD_PRODUCT_MAIN_GROUP T1, 
		INFRA.PROD_PRODUCT_GROUP T2, 
		INFRA.PROD_PRODUCT_NEW T3 
	WHERE T1.STATUS = '1' 
		AND T2.STATUS = '1' 
		AND T3.STATUS = '1' 
		AND T2.PRODUCT_MAIN_GROUP_CODE = T1.PRODUCT_MAIN_GROUP_CODE 
		AND T3.MAIN_GROUP_CODE = T2.PRODUCT_MAIN_GROUP_CODE 
		AND T3.GROUP_CODE = T2.PRODUCT_GROUP_CODE 
		AND T1.OID LIKE ? 
		AND T1.OID LIKE ? 
		AND T2.OID LIKE ? 
		AND T2.OID LIKE ? 
		AND T3.OID LIKE ? 
		AND T3.OID LIKE ? 
		AND T1.PRODUCT_MAIN_GROUP_CODE LIKE ? 
		AND T2.PRODUCT_GROUP_CODE LIKE ? 
		AND T3.PRODUCT_CODE LIKE ? 
        AND T3.IS_INDIVIDUAL LIKE ?
        AND T3.IS_FARMER LIKE ?
        AND T3.IS_GKTI LIKE ?
        AND T3.IS_CORPORATE LIKE ?
	ORDER BY T3.MAIN_GROUP_CODE, T3.GROUP_CODE, T3.PRODUCT_CODE	
    </sql>
    <parameters>
        <parameter prefix="" suffix="%">Product.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.txtProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.txtProductGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.cmbProductOID</parameter>
        <parameter prefix="" suffix="%">Product.txtProductOID</parameter>
        <parameter prefix="" suffix="%">Product.txtProductMainGroupCode</parameter>
        <parameter prefix="" suffix="%">Product.txtProductGroupCode</parameter>
        <parameter prefix="" suffix="%">Product.txtProductCode</parameter>
        <parameter prefix="" suffix="%">Product.txtIsIndividual</parameter>
        <parameter prefix="" suffix="%">Product.txtIsFarmer</parameter>
        <parameter prefix="" suffix="%">Product.txtIsGKTI</parameter>
        <parameter prefix="" suffix="%">Product.txtIsCorporate</parameter>
    </parameters>
</popupdata>
