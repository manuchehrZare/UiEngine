<popupdata type="sql">
    <sql dataSource="BankingDS">
	SELECT T1.PRODUCT_MAIN_GROUP_CODE AS MAIN_GROUP_CODE, 
		T1.OID AS MAIN_GROUP_OID, 
		T1.PRODUCT_MAIN_GROUP_NAME AS MAIN_GROUP_NAME, 
		T2.PRODUCT_GROUP_CODE AS GROUP_CODE, 
		T2.OID AS GROUP_OID, 
		T2.PRODUCT_GROUP_NAME AS GROUP_NAME 
	FROM INFRA.PROD_PRODUCT_MAIN_GROUP T1, 
		INFRA.PROD_PRODUCT_GROUP T2 
	WHERE T1.STATUS = '1' 
		AND T2.STATUS = '1' 
		AND T2.PRODUCT_MAIN_GROUP_CODE = T1.PRODUCT_MAIN_GROUP_CODE 
		AND T1.OID LIKE ? 
		AND T1.OID LIKE ? 
		AND T2.OID LIKE ? 
		AND T2.OID LIKE ? 
		AND T1.PRODUCT_MAIN_GROUP_CODE LIKE ? 
		AND T2.PRODUCT_GROUP_CODE LIKE ? 
	ORDER BY T1.PRODUCT_MAIN_GROUP_CODE, T2.PRODUCT_GROUP_CODE	
    </sql>
    <parameters>
        <parameter prefix="" suffix="%">ProductGroup.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">ProductGroup.txtProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">ProductGroup.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="%">ProductGroup.txtProductGroupOID</parameter>
        <parameter prefix="" suffix="%">ProductGroup.txtProductMainGroupCode</parameter>
        <parameter prefix="" suffix="%">ProductGroup.txtProductGroupCode</parameter>
    </parameters>
</popupdata>
