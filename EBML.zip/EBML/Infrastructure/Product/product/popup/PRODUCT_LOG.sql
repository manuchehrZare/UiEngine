<popupdata type="service">
	<service>PROD_PRODUCT_LOG_LIST_FOR_TABLE</service>
	    <parameters>
	        <parameter n="PRODUCT_REFERENCE_NO">productSearchPP.pnlSearchCriterias.txtProductReferenceNo</parameter>
	        <parameter n="BUSINESS_REFERENCE_NO">productSearchPP.pnlSearchCriterias.txtExternalReferenceNo</parameter>
	        <parameter n="BUSINESS_REFERENCE_DESC">productSearchPP.pnlSearchCriterias.txtBusinessRefDesc</parameter>
	        <parameter n="PRODUCT_STATUS">productSearchPP.pnlSearchCriterias.cmbProductStatus</parameter>
			<parameter n="PRODUCT_CUST_CODE">productSearchPP.pnlSearchCriterias.hndlBtnCust</parameter>
			<parameter n="PRODUCT_OUT_OF_SYSTEM">productSearchPP.chkListOutOfSystemProducts</parameter>
			<parameter n="PRODUCT_MAIN_GROUP_CODE">productSearchPP.pnlSearchCriterias.lblProductMainGroupCode</parameter>
			<parameter n="PRODUCT_GROUP_CODE">productSearchPP.pnlSearchCriterias.lblProductGroupCode</parameter>
			<parameter n="PRODUCT_CODE">productSearchPP.pnlSearchCriterias.hndlBtnProductCode</parameter>
			<parameter n="LIST_FOR_POPUP">productSearchPP.pnlSearchCriterias.lblListForPP</parameter>
	    </parameters>
</popupdata>