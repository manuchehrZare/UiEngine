<popupdata type="service">
	<service>BATCH_ORDER_LIST_ORDER_POPUP</service>
	    <parameters>
	        <parameter n="BATCH_ORDER_CUSTOMER_CODE">Page.pnlOrder.hndCustomerCode</parameter>
	        <parameter n="BATCH_ORDER_ACCOUNT_OID">Page.lblAccountOID</parameter>
	        <parameter n="BATCH_ORDER_TYPE_OID">Page.pnlOrder.cmbOrderType</parameter>
		<parameter n="BATCH_ORDER_START_DATE">Page.pnlOrder.dtStartDate</parameter>			
		<parameter n="BATCH_ORDER_END_DATE">Page.pnlOrder.dtEndDate</parameter>		
	    </parameters>
</popupdata>