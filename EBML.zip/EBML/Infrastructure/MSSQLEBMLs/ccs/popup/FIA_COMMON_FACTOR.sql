<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 
		  	F.OID, 
		  	F.FACTOR_CODE,
		  	F.FACTOR_NAME,
		  	F.FACTOR_DESCR,
		  	F.FACTOR_GROUP_CODE
	  	FROM CCS.FIA_CMMN_FACTOR_DEF F
		WHERE 
	          F.STATUS='1' AND 
	          (LEN(?) <1 OR F.FACTOR_CODE LIKE (? + '%')) AND
	          (LEN(?) <1 OR F.FACTOR_NAME LIKE (? + '%')) AND
	          (LEN(?) <1 OR F.FACTOR_GROUP_CODE = ?)
	    ORDER BY FACTOR_GROUP_CODE, FACTOR_CODE
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbGroupCode</parameter> 	
     </parameters>
</popupdata>