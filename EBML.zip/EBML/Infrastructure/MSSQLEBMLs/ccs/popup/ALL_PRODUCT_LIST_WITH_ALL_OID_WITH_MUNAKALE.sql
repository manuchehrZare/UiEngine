<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT   OID, MAIN_GROUP_CODE, MAIN_GROUP_CODE AS MAIN_GRP_CODE, GROUP_CODE,
         GROUP_CODE AS GRP_CODE, PRODUCT_CODE, CASH_NON_CASH, PRODUCT_NAME,
         (MAIN_GROUP_CODE + GROUP_CODE + PRODUCT_CODE) AS CODE,
         (MAIN_GROUP_CODE + GROUP_CODE) AS MAIN_GROUP, ALOID,
         IPRODUCT_OID,IPRODUCT_GROUP_OID,IPRODUCT_MAIN_GROUP_OID
    FROM (SELECT P.OID, IP.OID AS IPRODUCT_OID, IPG.OID AS IPRODUCT_GROUP_OID,
                 IPMG.OID AS IPRODUCT_MAIN_GROUP_OID, P.MAIN_GROUP_CODE,
                 P.GROUP_CODE, P.PRODUCT_CODE, P.CASH_NON_CASH,
                 IP.PRODUCT_NAME, APL.ALLOTMENT_OID AS ALOID
            FROM CCS.PRODUCT_LIMIT P,
                 INFRA.PROD_PRODUCT_NEW IP,
                 INFRA.PROD_PRODUCT_MAIN_GROUP IPMG,
                 INFRA.PROD_PRODUCT_GROUP IPG,
                 CCS.ALLOTMENT_PRODUCT_LIMIT APL
           WHERE P.STATUS = '1'
             AND P.OID = APL.PRODUCT_OID
             AND IP.STATUS = '1'
             AND IP.PRODUCT_CODE = P.PRODUCT_CODE
             AND IP.MAIN_GROUP_CODE = IPMG.PRODUCT_MAIN_GROUP_CODE
             AND IP.GROUP_CODE = IPG.PRODUCT_GROUP_CODE
             AND IPG.PRODUCT_MAIN_GROUP_CODE = IPMG.PRODUCT_MAIN_GROUP_CODE
             AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
             AND IP.GROUP_CODE = P.GROUP_CODE
             AND IP.PRODUCT_ACTIVE = '1'
             AND APL.APPROVED_LMT > 0
               AND (? IS NULL OR P.MAIN_GROUP_CODE = ? OR IPMG.OID = ?)
               AND (? IS NULL OR P.GROUP_CODE = ? OR IPG.OID = ?)
                AND (? IS NULL OR APL.ALLOTMENT_OID = ?)
                UNION
               SELECT P.OID, IP.OID AS IPRODUCT_OID, IPG.OID AS IPRODUCT_GROUP_OID,
                 IPMG.OID AS IPRODUCT_MAIN_GROUP_OID, P.MAIN_GROUP_CODE,
                 P.GROUP_CODE, P.PRODUCT_CODE, P.CASH_NON_CASH,
                 IP.PRODUCT_NAME, T.ALLOTMENT_OID AS ALOID
            FROM CCS.PRODUCT_LIMIT P,
                 INFRA.PROD_PRODUCT_NEW IP,
                 INFRA.PROD_PRODUCT_MAIN_GROUP IPMG,
                 INFRA.PROD_PRODUCT_GROUP IPG,
                 CCS.ALLOTMENT_TRANSPORT T
           WHERE P.STATUS = '1'
             AND P.OID = T.NEW_PRODUCT_OID
             AND IP.STATUS = '1'
             AND IP.PRODUCT_CODE = P.PRODUCT_CODE
             AND IP.MAIN_GROUP_CODE = IPMG.PRODUCT_MAIN_GROUP_CODE
             AND IP.GROUP_CODE = IPG.PRODUCT_GROUP_CODE
             AND IPG.PRODUCT_MAIN_GROUP_CODE = IPMG.PRODUCT_MAIN_GROUP_CODE
             AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
             AND IP.GROUP_CODE = P.GROUP_CODE
             AND IP.PRODUCT_ACTIVE = '1'
             AND T.TRANSPORT_STATE = '1'
             AND T.STATUS = '1' 
               AND (? IS NULL OR P.MAIN_GROUP_CODE = ? OR IPMG.OID = ?)
               AND (? IS NULL OR P.GROUP_CODE = ? OR IPG.OID = ?)
                AND (? IS NULL OR T.ALLOTMENT_OID = ?)
                ) K


</sql>
    <parameters>
    	<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
    	<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
    	<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="">Product.txtAllotmentOid</parameter>
        <parameter prefix="" suffix="">Product.txtAllotmentOid</parameter>
        <parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
    	<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
    	<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
        <parameter prefix="" suffix="">Product.txtAllotmentOid</parameter>
        <parameter prefix="" suffix="">Product.txtAllotmentOid</parameter>
    </parameters>
</popupdata>
