<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 	  	
		  	FA.FACTOR_CODE,
		  	FA.FACTOR_NAME,
		  	FA.FACTOR_VALUE,
		  	FA.ANSWER_VALUE,
		  	FA.CALC_FACTOR_VALUE,
		  	FA.CALC_ANSWER_VALUE,
		  	FA.RESULT_VALUE
	  	FROM CCS.FIA_CMMN_FACTOR_ANSWER FA
		WHERE 
	          FA.STATUS='1' AND 
	          (FA.REPORT_OID = ?) AND
	          (LEN(?) <1 or FA.IS_REPORT_OWNER = ?)
	    ORDER BY FACTOR_CODE
    </sql>
    <parameters>
    	<parameter prefix="" >Page.pnlFilter.txtReportOID</parameter>	
    	<parameter prefix="" >Page.pnlFilter.txtReportOwner</parameter>	
    	<parameter prefix="" >Page.pnlFilter.txtReportOwner</parameter>	
     </parameters>
</popupdata>