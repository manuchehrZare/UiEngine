<popupdata type="service">
	<service>FIA_COMMON_LIST_TABLE_ROW_DEF_FOR_POPUP</service>
	    <parameters>
	        <parameter n="ORDER_NO">Page.pnlFilter.txtOrderNo</parameter>
	        <parameter n="ROW_LEVEL">Page.pnlFilter.txtLevel</parameter>
	        <parameter n="TABLE_CODE">Page.pnlFilter.cmbTableCode</parameter>
	        <parameter n="ROW_CODE">Page.pnlFilter.txtRowCode</parameter>
	        <parameter n="ROW_NAME">Page.pnlFilter.txtRowName</parameter>
	        <parameter n="TREND_TYPE">Page.pnlFilter.cmbTrendType</parameter>
	        <parameter n="ENTRY_TYPE">Page.pnlFilter.chbIsScoringReport</parameter>			
	      </parameters>
</popupdata>