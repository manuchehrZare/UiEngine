<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT   LIM.OID AS OID, LIM.MAIN_GROUP_CODE,
         LIM.MAIN_GROUP_CODE AS MAIN_GRP_CODE, LIM.GROUP_CODE,
         LIM.GROUP_CODE AS GRP_CODE, LIM.PRODUCT_CODE, IP.PRODUCT_NAME,
         (LIM.MAIN_GROUP_CODE + LIM.GROUP_CODE + LIM.PRODUCT_CODE) AS CODE, 
		 (LIM.MAIN_GROUP_CODE + LIM.GROUP_CODE) AS MAIN_GROUP,
         LIM.PRODUCT_PROPERTIES AS PROP_CODE
    FROM CCS.PRODUCT_LIMIT LIM,
         INFRA.PROD_PRODUCT_NEW IP
   WHERE LIM.STATUS = '1'
     AND IP.STATUS = '1'
     AND IP.PRODUCT_ACTIVE = '1'
     AND IP.PRODUCT_CODE = LIM.PRODUCT_CODE
     AND IP.MAIN_GROUP_CODE = LIM.MAIN_GROUP_CODE
     AND IP.GROUP_CODE = LIM.GROUP_CODE
     AND (? IS NULL OR LIM.OID = ?)
     AND (? IS NULL OR LIM.PRODUCT_PROPERTIES = ?)
     AND (? IS NULL OR LIM.MAIN_GROUP_CODE = ?)
     AND (? IS NULL OR LIM.GROUP_CODE = ?)
    ORDER BY LIM.OID

</sql>
    <parameters>
    		<parameter prefix="" suffix="">Product.lblProductOid</parameter>
    		<parameter prefix="" suffix="">Product.lblProductOid</parameter>
			<parameter prefix="" suffix="">Product.cmbUsageProperties</parameter>
		    <parameter prefix="" suffix="">Product.cmbUsageProperties</parameter>
        	<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
			<parameter prefix="" suffix="">Product.cmbProductMainGroupOID</parameter>
        	<parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
			<parameter prefix="" suffix="">Product.cmbProductGroupOID</parameter>
    </parameters>
</popupdata>