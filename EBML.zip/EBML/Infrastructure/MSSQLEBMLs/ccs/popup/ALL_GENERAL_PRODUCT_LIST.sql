<popupdata type="sql">
<sql dataSource="BankingDS">


SELECT OID,MAIN_GROUP_CODE,MAIN_GROUP_CODE AS MAIN_GRP_CODE,GROUP_CODE,GROUP_CODE AS GRP_CODE,PRODUCT_CODE,CASH_NON_CASH ,PRODUCT_NAME ,
( MAIN_GROUP_CODE + GROUP_CODE + PRODUCT_CODE) AS CODE, 
(MAIN_GROUP_CODE + GROUP_CODE) as MAIN_GROUP_CMB
FROM ( 
       SELECT P.OID,P.MAIN_GROUP_CODE,P.GROUP_CODE,P.PRODUCT_CODE, P.CASH_NON_CASH,IP.PRODUCT_NAME
       FROM CCS.PRODUCT_LIMIT P, INFRA.PROD_PRODUCT_NEW IP
       WHERE P.STATUS = '1' 
       
       and IP.STATUS = '1'
       AND IP.PRODUCT_CODE = P.PRODUCT_CODE
       AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
       AND IP.GROUP_CODE = P.GROUP_CODE
       AND IP.PRODUCT_ACTIVE = '1'
         
		  AND P.MAIN_GROUP_CODE LIKE ?
		  AND P.GROUP_CODE LIKE ?
		  AND P.OID LIKE ?
		
     )  K order by MAIN_GROUP_CODE + GROUP_CODE + PRODUCT_CODE

</sql>
    <parameters>
        	<parameter prefix="" suffix="%">Product.cmbProductMainGroupOID</parameter>
        	<parameter prefix="" suffix="%">Product.cmbProductGroupOID</parameter>	
        	<parameter prefix="" suffix="%">Product.cmbProductOID</parameter>
        

    </parameters>
</popupdata>