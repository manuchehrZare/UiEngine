<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 
		  	FA.OID, 
		  	FA.ANSWER_NAME,
		  	FA.ANSWER_VALUE
	  	FROM CCS.FIA_CMMN_FACTOR_ANSWER_DEF FA
		WHERE 
	          FA.STATUS='1' AND 
	          (LEN(?) <1 OR FA.FACTOR_CODE = ?)
	          ORDER BY ANSWER_NAME
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtFactorCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtFactorCode</parameter>
    </parameters>
</popupdata>