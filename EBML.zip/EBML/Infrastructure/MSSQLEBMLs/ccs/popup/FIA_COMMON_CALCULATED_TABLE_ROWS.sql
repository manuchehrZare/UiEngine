<popupdata type="sql">
	<sql dataSource="BankingDS">
SELECT   OID, ROW_CODE, ROW_NAME, ORIGINAL_1, CORRECTED_1, ORIGINAL_2,
         CORRECTED_2, ORIGINAL_3, CORRECTED_3
    FROM CCS.FIA_CMMN_TABLE_ROW_VALUES RW
   WHERE STATUS = '1'
     AND CALC_TYPE = '0'
     AND RW.TABLE_CODE IN (
                      SELECT TD.TABLE_CODE
                        FROM CCS.FIA_CMMN_TABLE_DEF TD
                       WHERE TD.STATUS = '1'
                             AND TD.IS_USABLE_IN_COMMENTS = '1')
     AND REPORT_OID = ?
     AND (LEN(?) <1 OR ROW_CODE = ?)
     AND (LEN(?) <1 OR TABLE_CODE = ?)
ORDER BY ROW_CODE
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtReportOid</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtRowCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtRowCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbTablo</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbTablo</parameter>
    </parameters>
</popupdata>