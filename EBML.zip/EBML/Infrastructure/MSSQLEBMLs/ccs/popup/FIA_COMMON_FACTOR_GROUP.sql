<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 
		  	OID, 
		  	REPORT_TYPE,
		  	REPORT_SUB_TYPE,
		  	FACTOR_GROUP_CODE,
		  	FACTOR_GROUP_NAME
	  	FROM CCS.FIA_CMMN_FACTOR_GROUP_DEF
		WHERE 
	          STATUS='1' AND 
	          (LEN(?) <1 OR REPORT_TYPE = ?) AND
	          (LEN(?) <1 OR REPORT_SUB_TYPE = ?) AND
	          (LEN(?) <1 OR FACTOR_GROUP_CODE LIKE (? + '%')) AND
	          (LEN(?) <1 OR FACTOR_GROUP_NAME LIKE (? + '%'))
	    ORDER BY FACTOR_GROUP_NAME
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.cmbRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbSubRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbSubRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupName</parameter>	
     </parameters>
</popupdata>