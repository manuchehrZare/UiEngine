<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
    SELECT DISTINCT VARIABLE_CODE, min(VARIABLE_DESCR) as VARIABLE_DESCR
		FROM CCS.FIA_CMMN_VARIABLE_DEF
		WHERE STATUS='1'
		AND (LEN(?) <1 OR VARIABLE_CODE LIKE (? + '%'))
		GROUP BY VARIABLE_CODE
	    ORDER BY VARIABLE_CODE
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtFilterVarCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtFilterVarCode</parameter> 	
    </parameters>
</popupdata>
 
 