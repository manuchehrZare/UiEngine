<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 
		  	R.OID, 
		  	R.REPORT_NO,
		  	R.REPORT_TYPE,
		  	R.REPORT_STATUS,
		  	R.CUSTOMER_CODE,
		  	R.APP_DATE,
		  	R.REPORT_SECTOR,
		  	R.REFERENCE_ID,
		  	U.USER_FILE_NO AS CREATOR_USER,
		  	R.CREATOR_USER_OID
	  	FROM CCS.FIA_COMMON_REPORT R, INFRA.ADMIN_USR_USER U
		WHERE 
	          R.STATUS='1' AND 
	          (LEN(?) <1  OR R.REPORT_NO = ?) AND
	          (LEN(?) <1  OR R.OID = ?) AND
	          (LEN(?) <1  OR R.CUSTOMER_CODE = ?) AND
	          (LEN(?) <1  OR R.CREATOR_USER_OID = ?) AND
	          (LEN(?) <1  OR R.REPORT_TYPE = ?) AND
	          (LEN(?) <1  OR R.REPORT_STATUS = ?) AND
	          (LEN(?) <1  OR R.REFERENCE_ID = ?) AND 
	          (LEN(?) <1  OR R.REPORT_SECTOR = ?) AND
	          (LEN(?) <1  OR R.AUTHORIZATION_TYPE = ?) AND
	          (LEN(?) <1  OR R.MAIN_BRANCH_CODE = ?) AND
	          R.CREATOR_USER_OID = U.OID
	    ORDER BY REPORT_NO      
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtReportNo</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtReportNo</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtReportOID</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtReportOID</parameter>
	   	<parameter prefix="" >Page.pnlFilter.hndCustomerCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.hndCustomerCode</parameter>
	    <parameter prefix="" >Page.pnlFilter.txtCreatorUserOID</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCreatorUserOID</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbReportType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbReportType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbReportStatus</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbReportStatus</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtReferenceId</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtReferenceId</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbSector</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbSector</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbAuthorizationType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbAuthorizationType</parameter>	  
	    <parameter prefix="" >Page.pnlFilter.txtBranchCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtBranchCode</parameter>	   	
     </parameters>
</popupdata>