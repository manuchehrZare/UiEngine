<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 
		  	F.OID, 
		  	F.FACTOR_CODE,
		  	F.FACTOR_NAME,
		  	F.FACTOR_DESCR
	  	FROM CCS.FIA_CMMN_FACTOR_DEF F, 
	  	     CCS.FIA_CMMN_FACTOR_GROUP_DEF FG
		WHERE (LEN(?) <1 OR FG.REPORT_TYPE = ?)
		  AND FG.STATUS = '1'
  		  AND F.FACTOR_GROUP_CODE = FG.FACTOR_GROUP_CODE
	      AND (LEN(?) <1 OR F.FACTOR_CODE LIKE (? + '%'))
	      AND F.REPORT_FACTOR = '1'
	      AND F.STATUS = '1'
	    ORDER BY FACTOR_CODE
    </sql>
    <parameters>
    	<parameter prefix="" >Page.pnlFilter.txtReportType</parameter> 	
    	<parameter prefix="" >Page.pnlFilter.txtReportType</parameter> 	
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
     </parameters>
</popupdata>