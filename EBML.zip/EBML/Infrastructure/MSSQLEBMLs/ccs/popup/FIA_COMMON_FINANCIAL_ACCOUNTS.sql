<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
SELECT OID , FA_CODE , FA_NAME , FA_DESCR
  FROM CCS.FIA_COMMON_FIN_ACCOUNT_DEF AD
  WHERE AD.STATUS = '1'
    AND (AD.FA_CODE = ? OR ? IS NULL)
    AND (AD.FA_NAME = ? OR ? IS NULL)
    AND (AD.FA_DESCR LIKE ?)
  ORDER BY AD.MASTER_FA_CODE , AD.ORDER_NO 
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlSorguKriterleri.txtFACode</parameter>
	   	<parameter prefix="" >Page.pnlSorguKriterleri.txtFACode</parameter>
	   	<parameter prefix="" >Page.pnlSorguKriterleri.txtFAName</parameter>
	   	<parameter prefix="" >Page.pnlSorguKriterleri.txtFAName</parameter>
	   	<parameter prefix="%" postfix="%" >Page.pnlSorguKriterleri.txtFADescr</parameter>
     </parameters>
</popupdata>