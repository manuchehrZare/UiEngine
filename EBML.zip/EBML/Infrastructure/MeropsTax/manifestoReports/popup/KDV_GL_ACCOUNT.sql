<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT acc_code as gl_account_no,
				acc_name as gl_account_name,
				free_from_tax,
        		open_date,
				close_date,
				is_open
		FROM infra.utl_manifesto_gl_account_plan
		WHERE acc_code LIKE ?
   			  	AND acc_name LIKE ?
   	  			AND free_from_tax = ?
   	  			AND is_open = ?
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">GlAccount.tfGlAccountNo</parameter>
        <parameter prefix="%" suffix="%">GlAccount.tfGlAccountName</parameter>
        <parameter prefix="" suffix="">GlAccount.chbFreeTax</parameter>
        <parameter prefix="" suffix="">GlAccount.chbIsOpen</parameter>
    </parameters>
</popupdata>
