<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT acc_code as gl_account_no,
				acc_name as gl_account_name,
				kkdf_type,
				credit_type,
				free_from_tax,
        		open_date,
				close_date,
				is_open
		FROM infra.utl_manifesto_gl_account_plan
		WHERE acc_code LIKE ?
   			  	AND acc_name LIKE ?
   	 			AND (kkdf_type LIKE ? or kkdf_type is null)
   	 			AND (credit_type LIKE ? or credit_type is null)
   	  			AND free_from_tax = ?
   	  			AND is_open = ?
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">KkdfGlAccount.tfGlAccountNo</parameter>
        <parameter prefix="%" suffix="%">KkdfGlAccount.tfGlAccountName</parameter>
        <parameter prefix="%" suffix="%">KkdfGlAccount.cbKkdfType</parameter>
        <parameter prefix="%" suffix="%">KkdfGlAccount.cbCreditType</parameter>
        <parameter prefix="" suffix="">KkdfGlAccount.chbFreeTax</parameter>
        <parameter prefix="" suffix="">KkdfGlAccount.chbIsOpen</parameter>
    </parameters>
</popupdata>