<popupdata type="service">
	<service>EPROC_PROCESS_DEFINITION_SEARCH_RESTRICTED</service>
	    <parameters>
	        <parameter n="EPROC_PROCESS_ID">Page.pnlCriteria.txtProcessID</parameter>
	        <parameter n="EPROC_PROCESS_NAME">Page.pnlCriteria.txtProcessName</parameter>
	        <parameter n="EPROC_GROUP_OID">Page.pnlCriteria.cmbProcessGroup</parameter>
      	        <parameter n="SCREEN_CODE">Page.pnlCriteria.SCREEN_CODE</parameter>
	    </parameters>
</popupdata>