<popupdata type="service">
	<service>EPROC_PROCESS_INSTANCE_SEARCH</service>
	    <parameters>
	        <parameter n="EPROC_CUSTOMER_NO">ProcessInstanceChooser.pnlCriteria.hndCustomer</parameter>
	        <parameter n="EPROC_REFERENCE_ID">ProcessInstanceChooser.pnlCriteria.txtReferenceID</parameter>
	        <parameter n="EPROC_PROCESS_ID">ProcessInstanceChooser.pnlCriteria.hndProcess</parameter>
	        <parameter n="EPROC_START1">ProcessInstanceChooser.pnlCriteria.txtStartTime1</parameter>
	        <parameter n="EPROC_START2">ProcessInstanceChooser.pnlCriteria.txtStartTime2</parameter>
	        <parameter n="EPROC_END1">ProcessInstanceChooser.pnlCriteria.txtFinishTime1</parameter>
	        <parameter n="EPROC_END2">ProcessInstanceChooser.pnlCriteria.txtFinishTime2</parameter>
			<parameter n="EPROC_STATUS">ProcessInstanceChooser.pnlCriteria.cmbStatus</parameter>
	        <parameter n="EPROC_END2">ProcessInstanceChooser.pnlCriteria.txtFinishTime2</parameter>
			<parameter n="EPROC_STATUS">ProcessInstanceChooser.pnlCriteria.cmbStatus</parameter>
			<parameter n="EPROC_PROCESS_ORGANIZATION">ProcessInstanceChooser.pnlCriteria.cmbOrganization</parameter>
			<parameter n="REQUEST_SOURCE">ProcessInstanceChooser.pnlCriteria.lblRequestSource</parameter>
			<parameter n="REQUEST_TYPE">ProcessInstanceChooser.pnlCriteria.lblRequestType</parameter>
	    </parameters>
</popupdata>