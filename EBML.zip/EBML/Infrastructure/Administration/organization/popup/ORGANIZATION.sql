<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT T1.OID AS ORGANIZATION_OID, 
			T1.CODE AS ORGANIZATION_CODE, 
			T1.NAME AS ORGANIZATION_NAME, 
			T1.PARENT_OID, 
			T1.ORG_TYPE, 
			T1.CAN_OPERATE_FOR_OTHER, 
			T1.IS_BEING_ESTABLISHED, 
			T1.IS_CLOSED, 
			T1.EFT_CODE, 
			T1.RISK_CENTRALIZATION_CODE, 
			T1.TAX_NUMBER, 
			T1.TAX_OFFICE_CODE 
		FROM INFRA.ADMIN_ORG_ORGANIZATION T1 
		WHERE T1.STATUS = '1' 
			AND T1.CODE LIKE ? 
			AND T1.NAME LIKE ? 
			AND T1.ORG_TYPE LIKE ? 
		ORDER BY T1.CODE 
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">Organization.txtOrgCode</parameter>
        <parameter prefix="%" suffix="%">Organization.txtOrgName</parameter>
        <parameter prefix="" suffix="%">Organization.cmbOrgType</parameter>
    </parameters>
</popupdata>
