<popupdata type="sql">
    <sql dataSource="BankingDS">
	SELECT T1.OID AS SCREEN_OID, 
		   T1.SCREEN_CODE, 
		   T1.SCREEN_NAME, 
		   T1.SCREEN_DESCRIPTION,
		   T2.PARENT_MENU_OID
	FROM INFRA.ADMIN_MENU_SCREEN T1,INFRA.ADMIN_MENU_MENU_DEFINITION T2
	WHERE T1.STATUS = '1' 
		  AND T2.STATUS = '1'
		  AND T1.SCREEN_CODE = T2.SCREEN_CODE
		  AND T1.COMPONENT_OID LIKE ? 
		  AND T1.SCREEN_CODE LIKE ? 
		  AND T1.SCREEN_NAME LIKE ? 
	ORDER BY T1.SCREEN_CODE 	</sql>
    <parameters>
        <parameter prefix="%" suffix="%">Screen.txtScreenComponentOID</parameter>
        <parameter prefix="%" suffix="%">Screen.txtScreenCode</parameter>
        <parameter prefix="%" suffix="%">Screen.txtScreenName</parameter>
    </parameters>
</popupdata>
