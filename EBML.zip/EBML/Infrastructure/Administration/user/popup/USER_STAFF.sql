<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT T1.OID AS USER_OID, 
			T1.USER_FILE_NO AS USER_FILE_NO, 
			T1.USER_FIRST_NAME AS USER_FIRST_NAME, 
			T1.USER_LAST_NAME AS USER_LAST_NAME, 
			T1.USER_ORGANIZATION_OID AS USER_ORGANIZATION_OID, 
			T1.USER_UNIT_OID AS USER_UNIT_OID, 
			T1.USER_TITLE_OID AS USER_TITLE_OID, 
			T1.USER_USER_NAME AS USER_NAME, 
			T1.USER_ACTIVE AS USER_ACTIVE, 
			T1.USER_EXPIRATION_DATE AS USER_EXPIRATION_DATE, 
			T1.USER_STATUS AS USER_STATUS, 
			T1.USER_NOTE AS USER_NOTE, 
			T2.NAME AS USER_ORGANIZATION, 
			T3.UNIT_NAME AS USER_UNIT, 
			T4.TITLE_NAME AS USER_TITLE, 
			T1.USER_CHARGED_ORG_OID AS USER_CHARGED_ORGANIZATION_OID, 
			T5.NAME AS USER_CHARGED_ORGANIZATION, 
			T1.USER_CHARGED_UNIT_OID AS USER_CHARGED_UNIT_OID, 
			T6.UNIT_NAME AS USER_CHARGED_UNIT 
		FROM INFRA.ADMIN_USR_USER T1, 
			INFRA.ADMIN_ORG_ORGANIZATION T2, 
			INFRA.ADMIN_ORG_ORGANIZATION_UNIT T3, 
			INFRA.ADMIN_USR_TITLE T4, 
			INFRA.ADMIN_ORG_ORGANIZATION T5, 
			INFRA.ADMIN_ORG_ORGANIZATION_UNIT T6 
		WHERE T1.STATUS = '1' 
			AND T1.USER_FILE_NO LIKE ? 
			AND T1.USER_FIRST_NAME LIKE ? 
			AND T1.USER_LAST_NAME LIKE ? 
			AND T1.USER_ORGANIZATION_OID LIKE ? 
			AND T1.USER_UNIT_OID LIKE ? 
			AND T1.USER_TITLE_OID LIKE ? 
			AND T1.USER_USER_NAME LIKE ? 
			AND T2.STATUS = '1' 
			AND T2.OID =  T1.USER_ORGANIZATION_OID 
			AND T3.STATUS = '1' 
			AND T3.OID = T1.USER_UNIT_OID 
			AND T4.STATUS = '1' 
			AND T4.OID = T1.USER_TITLE_OID 
			AND T5.STATUS = '1' 
			AND T5.OID =  T1.USER_CHARGED_ORG_OID 
			AND T6.STATUS = '1' 
			AND T6.OID = T1.USER_CHARGED_UNIT_OID 
			AND T1.OID LIKE ? 
			AND T1.USER_ACTIVE LIKE ? 
			AND T1.USER_CHARGED_ORG_OID LIKE ? 
			AND T1.USER_CHARGED_UNIT_OID LIKE ? 
			AND (? = '%' OR T1.USER_STATUS LIKE ?) 
			AND (? = '%' OR (EXISTS (SELECT T7.OID 
					  	 			FROM INFRA.ADMIN_USR_USER_PROFILE T7 
									WHERE T7.STATUS = '1' 
										  AND T7.USER_NAME = T1.USER_USER_NAME 
										  AND T7.PROFILE_EXPIRED = '0' 
										  AND T7.PROFILE_CODE LIKE ?)))
		ORDER BY T1.USER_USER_NAME 
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">User.txtUserFileNo</parameter>
        <parameter prefix="" suffix="%">User.txtUserFirstName</parameter>
        <parameter prefix="" suffix="%">User.txtUserLastName</parameter>
        <parameter prefix="" suffix="%">User.cmbUserOrganization</parameter>
        <parameter prefix="" suffix="%">User.cmbUserUnit</parameter>
        <parameter prefix="" suffix="%">User.cmbUserTitle</parameter>
        <parameter prefix="" suffix="%">User.txtUserName</parameter>
        <parameter prefix="" suffix="%">User.txtUserOID</parameter>
	<parameter prefix="" suffix="%">User.cmbUserActive</parameter>
        <parameter prefix="" suffix="%">User.cmbUserChargedOrganization</parameter>
        <parameter prefix="" suffix="%">User.cmbUserChargedUnit</parameter>
        <parameter prefix="" suffix="%">User.cmbUserStatus</parameter>
        <parameter prefix="" suffix="%">User.cmbUserStatus</parameter>
        <parameter prefix="" suffix="%">User.cmbUserProfile</parameter>
        <parameter prefix="" suffix="%">User.cmbUserProfile</parameter>
    </parameters>
</popupdata>
