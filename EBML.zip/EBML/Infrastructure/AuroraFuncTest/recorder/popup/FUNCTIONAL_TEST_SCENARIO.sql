<popupdata type="sql">
    <sql dataSource="FuncTestDS">
	SELECT SCENARIO2.*, (SELECT COUNT(*) FROM FUNC_TEST.SCENARIO_STEP STEP WHERE STEP.SCENARIO_OID = SCENARIO2.OID AND STEP.STATUS = '1') AS STEP_COUNT
    	FROM
    		FUNC_TEST.SCENARIO SCENARIO2
        WHERE 
        	SCENARIO2.STATUS = '1'
        	AND (? is null or GROUP_NAME LIKE ?)
			AND (? is null or CODE LIKE ?)
			AND (? is null or SCENARIO2.RECORD_DATE LIKE ?)
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlCriterias.cmbScenarioGroup</parameter>
		<parameter prefix="" suffix="">Page.pnlCriterias.cmbScenarioGroup</parameter>
		<parameter prefix="" suffix="">Page.pnlCriterias.txtScenarioCode</parameter>
		<parameter prefix="" suffix="%">Page.pnlCriterias.txtScenarioCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriterias.dtRecordDate</parameter>
		<parameter prefix="" suffix="">Page.pnlCriterias.dtRecordDate</parameter>
	</parameters>
</popupdata>