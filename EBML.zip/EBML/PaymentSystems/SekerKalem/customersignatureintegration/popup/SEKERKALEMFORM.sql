<popupdata type="service">
    <service>SKL_SEKERKALEM_GET_INSTANCE_HEADS</service>
         <parameters>        
               <parameter n="RESERVATIONKEY">Page.txtNumara</parameter> 
               <parameter n="BRANCH_CODE">Page.cmbBranchCode</parameter> 
         </parameters>
</popupdata>
