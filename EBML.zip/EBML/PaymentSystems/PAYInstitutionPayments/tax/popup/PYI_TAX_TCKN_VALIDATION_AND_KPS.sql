<popupdata type="service">
<service>PYI_TAX_TCKN_VALIDATION_AND_KPS_QUERY</service>
	<parameters>    	
    	<parameter n="TC_ID">Page.pnlQueryCriteria.txtTCKN</parameter>
    	<parameter n="BIRTHDAY">Page.pnlQueryCriteria.dtBirthDate</parameter>
	</parameters>
</popupdata>
