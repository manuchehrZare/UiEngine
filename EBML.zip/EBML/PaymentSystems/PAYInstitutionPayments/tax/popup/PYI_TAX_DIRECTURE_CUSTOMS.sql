<popupdata type="service">
<service>PYI_TAX_REVENUE_QUERY</service>
	<parameters>    	
    <parameter n="REVENU_OFFICE_CODE">Page.pnlCriterias.txtDirectoreCustomCode</parameter> 
	<parameter n="REVENUE_OFFICE_NAME">Page.pnlCriterias.txtDirectoreCustomName</parameter>
</parameters>
</popupdata>
