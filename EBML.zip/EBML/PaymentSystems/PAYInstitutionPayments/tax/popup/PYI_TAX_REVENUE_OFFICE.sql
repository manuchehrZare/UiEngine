<popupdata type="service">
<service>PYI_TAX_LIST_REVENUE_OFFICE</service>
	<parameters>    	
    <parameter n="REVENUE_OFFICE_CODE">Page.pnlDirectoreCustomsInfo.txtDirectoreCustomCode</parameter> 
	<parameter n="REVENUE_OFFICE_NAME">Page.pnlDirectoreCustomsInfo.txtDirectoreCustomName</parameter>
    <parameter n="INSTITUTION_CODE">Page.pnlDirectoreCustomsInfo.hndAccountancyCode</parameter>
</parameters>
</popupdata>
