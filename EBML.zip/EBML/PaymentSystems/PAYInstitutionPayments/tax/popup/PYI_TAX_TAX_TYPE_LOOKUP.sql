<popupdata type="service">
<service>PYI_TAX_TYPE_QUERY</service>
	<parameters>    	
    <parameter n="TAX_TYPE_CODE">Page.pnlCriterias.txtTaxCode</parameter>
    <parameter n="TAX_TYPE_CODE">Page.pnlCriterias.txtTaxCode</parameter> 
	<parameter n="SUPPORT_AUTO_DEBIT">Page.pnlCriterias.txtSupportAutoDebit</parameter>
</parameters>
</popupdata>
