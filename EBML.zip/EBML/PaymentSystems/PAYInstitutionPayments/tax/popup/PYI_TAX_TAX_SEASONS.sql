<popupdata type="service">
<service>PYI_TAX_TYPE_TERM_QUERY</service>
	<parameters>    	
    <parameter n="TAX_TYPE_CODE">Page.pnlQuery.cmbTaxType</parameter> 
	<parameter n="SHOW_ONLY_TERM">Page.pnlQuery.lblShowOnlyTerm</parameter>
	<parameter n="SHOW_FINAL_PAY_AFTER">Page.pnlQuery.lblShowFinalPayAfter</parameter>
	<parameter n="SHOW_ONLY_ONE_YEAR">Page.pnlQuery.lblShowOnlyOneYear</parameter>
	<parameter n="TERM_YEAR">Page.pnlQuery.mskTermYear</parameter>
</parameters>
</popupdata>
