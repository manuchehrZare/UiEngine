<popupdata type="service">
<service>PYI_OTHERBANK_QUERY_CUSTOMER</service>
	<parameters>    	
	    <parameter n="CUSTOMER_CODE">Page.pnlCustomerInfo.txtCustomerNo</parameter>
		<parameter n="CUSTOMER_FULL_NAME">Page.pnlCustomerInfo.txtCustomerNameSurname</parameter>
		<parameter n="CUSTOMER_TCK_ID">Page.pnlCustomerInfo.rgnTCTaxNumberTwoColumns.Page.txtTCIdentityNumber</parameter>
		<parameter n="CUSTOMER_TAX_ID">Page.pnlCustomerInfo.rgnTCTaxNumberTwoColumns.Page.txtTaxNumber</parameter>
		<parameter n="FOREIGN_IDENTITY_NO">Page.pnlCustomerInfo.txtForeignIdentityNo</parameter>
		<parameter n="PASSPORT_NO">Page.pnlCustomerInfo.txtPassportId</parameter>
		<parameter n="CUSTOMER_ACCOUNT_NO">Page.pnlCustomerInfo.txtAccountNo</parameter>
		<parameter n="CUSTOMER_IBAN">Page.pnlCustomerInfo.txtIban</parameter>
		<parameter n="CUSTOMER_CREDIT_CARD_NO">Page.pnlCustomerInfo.txtCreditCardNo</parameter>
		<parameter n="INSTITUTION_OID">Page.txtInstitutionOid</parameter>
		<parameter n="BANK_NAME">Page.pnlCustomerInfo.txtBankName</parameter>
	</parameters>
</popupdata>