<popupdata type="service">
<service>PYF_EDUCATION_LOAD_PAYMENT_PLAN_MANAGEMENT</service>
  <parameters>    	
	<parameter n="INSTITUTION_CODE">Page.pnlQuery.hndInstitutionCode</parameter> 
	<parameter n="INSTITUTION_SHORT_NAME">Page.pnlQuery.txtInstitutionShortName</parameter> 	
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerCode</parameter>
	<parameter n="CUSTOMER_NAME">Page.pnlQuery.txtCustomerName</parameter>
	<parameter n="PAYMENT_TYPE">Page.pnlQuery.cmbPaymentType</parameter>
	<parameter n="EDUCATION_TERM_MONTH">Page.pnlQuery.cmbEducationTermMonth</parameter>
	<parameter n="EDUCATION_TERM_YEAR">Page.pnlQuery.cmbEducationTermYear</parameter>
	
  </parameters>
</popupdata>
