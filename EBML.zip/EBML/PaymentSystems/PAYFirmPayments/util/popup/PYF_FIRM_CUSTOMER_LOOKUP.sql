<popupdata type="service">
<service>PYF_LOOKUP_CUSTOMER</service>
  <parameters>    	
	<parameter n="IS_FIRM">Page.pnlQuery.lblIsFirm</parameter> 
	<parameter n="ORDER_NO">Page.pnlQuery.txtOrderNo</parameter>
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerNo</parameter>
	<parameter n="ORDER_TYPE">Page.pnlQuery.lblOrderType</parameter>
	<parameter n="TRANSACTION_BRANCH">Page.pnlQuery.cmbBranchCode</parameter>
  </parameters>
</popupdata>
