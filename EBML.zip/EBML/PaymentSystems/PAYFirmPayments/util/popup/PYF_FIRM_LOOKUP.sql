<popupdata type="service">
<service>PYF_LOOKUP_FIRM</service>
  <parameters>    	
	<parameter n="INSTITUTION_SHORT_NAME">Page.pnlQuery.txtInstitutionName</parameter> 
	<parameter n="INSTITUTION_CODE">Page.pnlQuery.txtInstitutionCode</parameter>
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerNo</parameter>
	<parameter n="ORDER_TYPE">Page.pnlQuery.lblOrderType</parameter>
	<parameter n="BRANCH_CODE">Page.pnlQuery.cmbBranch</parameter>
    <parameter n="IS_APPROVED">Page.pnlQuery.lblIsApproved</parameter>
	<parameter n="IS_HISTORY">Page.pnlQuery.lblIsHistory</parameter>
	<parameter n="IS_ACTIVE">Page.pnlQuery.lblIsActive</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_CODE">Page.pnlQuery.lblWageCustomerNo</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_REGISTER_NO">Page.pnlQuery.lblWageCustomerRegisterNo</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_TC_NO">Page.pnlQuery.lblWageCustomerTcNo</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_NAME">Page.pnlQuery.lblWageCustomerName</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_SURNAME">Page.pnlQuery.lblWageCustomerSurname</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_ACCOUNT_NO">Page.pnlQuery.lblWageCustomerAccountNo</parameter>
	<parameter n="WAGE_PERSONNEL_CUSTOMER_ACCOUNT_BRANCH_CODE">Page.pnlQuery.lblWageCustomerAccountBranchCode</parameter>
	<parameter n="SOURCE">Page.txtSourceDBS</parameter>
  </parameters>
</popupdata>
