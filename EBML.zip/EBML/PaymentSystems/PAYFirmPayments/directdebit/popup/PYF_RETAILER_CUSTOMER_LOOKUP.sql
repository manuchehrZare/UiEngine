<popupdata type="service">
<service>PYF_DIRECTDEBIT_GET_RETAILER</service>
  <parameters>    	
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerNo</parameter>
	<parameter n="INSTITUTION_OID">Page.pnlQuery.lblInstitutionOid</parameter>
	<parameter n="ORDER_TYPE">Page.pnlQuery.lblOrderType</parameter>
	<parameter n="RETAILER_CODE">Page.pnlQuery.txtRetailerCode</parameter>
  </parameters>
</popupdata>
