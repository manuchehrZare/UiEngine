<popupdata type="service">
<service>PYF_DBS_UPLOAD_FILE_LIST</service>
  <parameters>    	
	<parameter n="INSTITUTION_OID">Page.pnlFilter.txtInstitutionOid</parameter>
	<parameter n="INSTITUTION_SHORT_NAME">Page.pnlFilter.txtInstitutionName</parameter>
	<parameter n="LOAD_DATE_START">Page.pnlFilter.dfDateStart</parameter>
	<parameter n="LOAD_DATE_END">Page.pnlFilter.dfDateEnd</parameter>
	<parameter n="FILE_TYPE">Page.pnlFilter.cmbFileType</parameter>
	<parameter n="INSTITUTION_TYPE">Page.pnlFilter.cmbFirmInstType</parameter>
  </parameters>
</popupdata>
