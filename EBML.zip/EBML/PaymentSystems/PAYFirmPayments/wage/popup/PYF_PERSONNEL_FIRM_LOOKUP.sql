<popupdata type="service">
<service>PYF_WAGE_LIST_WAGE_PERSONNEL_FIRMS</service>
  <parameters>    	
	<parameter n="CUSTOMER_NO">Page.pnlQuery.txtCustomerCode</parameter> 
	<parameter n="REGISTER_NO">Page.pnlQuery.txtRegisterNo</parameter>
	<parameter n="TC_ID">Page.pnlQuery.txtTCIdentityNumber</parameter>
	<parameter n="PERSONNEL_FIRST_NAME">Page.pnlQuery.txtName</parameter>
	<parameter n="PERSONNEL_LAST_NAME">Page.pnlQuery.txtSurname</parameter>
	<parameter n="ACCOUNT_CODE">Page.pnlQuery.txtAccountCode</parameter>
	<parameter n="PERSONNEL_STATUS">Page.pnlQuery.cmbSituation</parameter>
	<parameter n="BRANCH_CODE">Page.pnlQuery.cmbBranch</parameter> 
  </parameters>
</popupdata>
