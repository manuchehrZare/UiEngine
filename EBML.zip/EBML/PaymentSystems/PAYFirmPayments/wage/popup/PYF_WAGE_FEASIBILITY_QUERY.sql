<popupdata type="service">
<service>PYF_WAGE_QUERY_FEASIBILTY_REPORT</service>
  <parameters>    	
	<parameter n="INSTITUTION_OID">Page.pnlCriteria.lblInstitutionOid</parameter> 
	<parameter n="START_DATE">Page.pnlCriteria.dtfStart</parameter>
	<parameter n="END_DATE">Page.pnlCriteria.dtfEnd</parameter>
  </parameters>
</popupdata>
