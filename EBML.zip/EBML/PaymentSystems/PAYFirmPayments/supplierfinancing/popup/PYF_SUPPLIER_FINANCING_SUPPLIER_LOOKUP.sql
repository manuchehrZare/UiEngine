<popupdata type="service">
	<service>PYF_SF_LOOKUP_SUPPLIER</service>
	<parameters>    	
	    <parameter n="NAME">Page.pnlQuery.tfName</parameter> 
		<parameter n="TAX_NO">Page.pnlQuery.tfTaxNo</parameter>
		<parameter n="SUPPLIER_CODE">Page.pnlQuery.tfCode</parameter>
		<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustCode</parameter>
	</parameters>
</popupdata>
