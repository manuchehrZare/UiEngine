<popupdata type="service">
	<service>PYF_SF_LOOKUP_INSTITUTION</service>
	<parameters>    	
	    <parameter n="NAME">Page.pnlQuery.tfInstName</parameter> 
		<parameter n="TAX_NO">Page.pnlQuery.tfInstTaxNo</parameter>
		<parameter n="INSTITUTION_CODE">Page.pnlQuery.tfInstCode</parameter>
		<parameter n="SUPPLIER_CUST_CODE">Page.pnlQuery.hndSupplierCustCode</parameter>
	</parameters>
</popupdata>
