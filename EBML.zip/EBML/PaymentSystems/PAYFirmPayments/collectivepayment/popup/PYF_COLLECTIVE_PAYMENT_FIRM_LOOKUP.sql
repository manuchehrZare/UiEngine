<popupdata type="service">
	<service>PYF_CP_LOOK_UP_FIRMS</service>
	<parameters>    	
	    <parameter n="FIRM_NAME">Page.pnlQuery.txtFirmName</parameter> 
		<parameter n="FIRM_CODE">Page.pnlQuery.txtFirmCode</parameter>
		<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerNo</parameter>
		<parameter n="BRANCH_CODE">Page.pnlQuery.txtBranchCode</parameter>
		<parameter n="IS_HISTORY">Page.txtIsHistory</parameter>
		<parameter n="IS_ACTIVE">Page.pnlQuery.txtIsEffective</parameter>
		<parameter n="SOURCE">Page.txtSourceTOS</parameter>
	</parameters>
</popupdata>
