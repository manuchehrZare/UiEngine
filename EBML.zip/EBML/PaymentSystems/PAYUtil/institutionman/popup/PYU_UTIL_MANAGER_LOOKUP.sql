<popupdata type="service">
<service>PYU_UTIL_LOOK_UP_MANAGERS</service>
	<parameters>    	
    <parameter n="MANAGER_NAME">Page.pnlQuery.txtManagerName</parameter> 
	<parameter n="MANAGER_CODE">Page.pnlQuery.txtManagerCode</parameter>
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerNo</parameter>
	<parameter n="IS_EFFECTIVE">Page.pnlQuery.txtIsEffective</parameter>
</parameters>
</popupdata>
