<popupdata type="service">
<service>PYU_UTIL_LOOK_UP_INSTITUTIONS</service>
	<parameters>    	
    <parameter n="INSTITUTION_SHORT_NAME">Page.pnlQuery.txtInstitutionName</parameter> 
	<parameter n="INSTITUTION_CODE">Page.pnlQuery.txtInstitutionCode</parameter>
	<parameter n="INSTITUTION_BUSINESS_CODE">Page.pnlQuery.txtInstitutionBusinessCode</parameter>
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerNo</parameter>
	<parameter n="SECTOR_OID">Page.pnlQuery.cmbSector</parameter>
	<parameter n="CITY_OID">Page.pnlQuery.cmbCity</parameter> 
	<parameter n="BRANCH_CODE">Page.pnlQuery.txtBranchCode</parameter>
	<parameter n="IS_HISTORY">Page.txtIsHistory</parameter>
	<parameter n="IS_EFFECTIVE">Page.pnlQuery.txtIsEffective</parameter>
	<parameter n="PAYMENT_TYPE_CODE">Page.txtPaymentTypeCode</parameter>
	<parameter n="IS_APARTMENT_CONTROL">Page.pnlQuery.txtIsApartmentControl</parameter>
</parameters>
</popupdata>
