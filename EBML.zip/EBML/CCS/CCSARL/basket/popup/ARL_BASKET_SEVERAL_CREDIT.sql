<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT CUST.CUSTOMER_CODE,
       CUST.DECLERATION_NAME_TITLE AS CUSTOMER_TITLE,
       PROD.PRODUCT_NAME,
       MYSIS.ALM_ACCOUNTNO         AS CREDIT_NO,
       CUST.PROFIT_CENTER_CODE     AS CENTER_CODE,
       CUST.PROFIT_SEGMENT_CODE    AS SEGMENT_CODE
  FROM INFRA.PROD_PRODUCT_NEW       PROD,
       INFRA.CUST_CUST_CUST         CUST,
       CCS.ARL_BASKET_SEVERAL_MYSIS MYSIS
 WHERE MYSIS.STATUS = '1'
   AND PROD.STATUS = '1'
   AND MYSIS.ALM_INDASSESSMENTPOOL = '1'
   AND PROD.MAIN_GROUP_CODE || PROD.GROUP_CODE || PROD.PRODUCT_CODE =
       MYSIS.ALM_PRODUCT_TYPE
   AND CUST.CUSTOMER_CODE = MYSIS.ALM_CUSTOMERID
   AND (? IS NOT NULL AND MYSIS.ALM_CUSTOMERID LIKE ? OR (? IS NULL))
   AND (? IS NOT NULL AND MYSIS.ALM_ACCOUNTNO LIKE ? OR (? IS NULL))
   AND ( (? IS NULL AND ? IS NULL AND PROD.MAIN_GROUP_CODE = 'MUSTERI_NO_VEYA_KREDI_NO_ZORUNLUDUR' ) OR NOT (? IS NULL AND ? IS NULL) )
  
</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
		
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
		
		
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>

    </parameters>
</popupdata>
