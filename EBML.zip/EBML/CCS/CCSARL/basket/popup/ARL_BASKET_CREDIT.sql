<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT CUST.CUSTOMER_CODE,
       CUST.DECLERATION_NAME_TITLE AS CUSTOMER_TITLE,
       PROD.PRODUCT_NAME,
       DEF.CREDIT_NO,
       CUST.PROFIT_CENTER_CODE     AS CENTER_CODE,
       CUST.PROFIT_SEGMENT_CODE    AS SEGMENT_CODE
  FROM INFRA.PROD_PRODUCT_NEW       PROD,
       INFRA.CUST_CUST_CUST         CUST,
       CCS.ARL_BASKET_EXCEPTION_DEF DEF
 WHERE DEF.STATUS = '1'
   AND PROD.STATUS = '1'
   AND PROD.MAIN_GROUP_CODE = DEF.PRODUCT_MAIN_GROUP_CODE
   AND PROD.GROUP_CODE = DEF.PRODUCT_GROUP_CODE
   AND PROD.PRODUCT_CODE = DEF.PRODUCT_CODE
   AND CUST.CUSTOMER_CODE = DEF.CUSTOMER_CODE
   AND (? IS NOT NULL AND DEF.CUSTOMER_CODE LIKE ? OR (? IS NULL))
   AND (? IS NOT NULL AND DEF.CREDIT_NO LIKE ? OR (? IS NULL))
   AND ( (? IS NULL AND ? IS NULL AND PROD.MAIN_GROUP_CODE = 'MUSTERI_NO_VEYA_KREDI_NO_ZORUNLUDUR' ) OR NOT (? IS NULL AND ? IS NULL) )
  
  
</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
		
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
		
		
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCreditNo</parameter>

    </parameters>
</popupdata>
