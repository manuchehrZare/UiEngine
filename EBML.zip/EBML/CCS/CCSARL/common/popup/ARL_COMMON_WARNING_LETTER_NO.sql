<popupdata type="service">
	<service>ARL_COMMON_LIST_LETTER_INFO_FOR_POPUP</service>
	    <parameters>
			<parameter n="WARNING_LETTER_NO">Page.pnlWarningLetterCriteria.txtWarningLetterNo</parameter>
			<parameter n="LETTER_STATE">Page.pnlWarningLetterCriteria.cmbLetterState</parameter>
			<parameter n="LETTER_TYPE">Page.pnlWarningLetterCriteria.cmbLetterType</parameter>
			<parameter n="CUSTOMER_CODE">Page.pnlWarningLetterCriteria.hndCustomerCode</parameter>
			<parameter n="CUSTOMER_ORG_CODE">Page.pnlWarningLetterCriteria.cmbBranchCode</parameter>
		</parameters>
</popupdata>