<popupdata type="sql">
	<sql dataSource="BankingDS">
	SELECT   OID, EXCEPTION_GROUP_CODE , EXCEPTION_CODE , EXCEPTION_NAME , EXCEPTION_DESCR , IS_ACTIVE
	    FROM CCS.ARL_CMMN_EXCP_DEF ED
	   WHERE STATUS = '1'
	   AND IS_ACTIVE = '1'
	     AND (? IS NULL OR EXCEPTION_GROUP_CODE = ?)
	     AND (? IS NULL OR EXCEPTION_CODE = ?)
	     AND (? IS NULL OR EXCEPTION_NAME = ?)
	ORDER BY EXCEPTION_GROUP_CODE
    </sql>
    <parameters>
		<parameter prefix="" >Page.pnlFilter.cmbGroupCode</parameter>
		<parameter prefix="" >Page.pnlFilter.cmbGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtName</parameter>
    </parameters>
</popupdata>