<popupdata type="sql">
	<sql dataSource="BankingDS">
	SELECT   OID , LETTER_CODE , LETTER_NAME , TEXT
	    FROM CCS.ARL_CMMN_WARNING_LETTER_DEF WL
	   WHERE STATUS = '1'
	     AND (? IS NULL OR LETTER_CODE LIKE ('%' || ? || '%'))
	     AND (? IS NULL OR LETTER_NAME LIKE ('%' || ? || '%'))
	ORDER BY LASTUPDATED
    </sql>
    <parameters>
		<parameter prefix="" >Page.txtWarningLetterCode</parameter>
		<parameter prefix="" >Page.txtWarningLetterCode</parameter>
		<parameter prefix="" >Page.txtWarningLetterName</parameter>
		<parameter prefix="" >Page.txtWarningLetterName</parameter>
    </parameters>
</popupdata>