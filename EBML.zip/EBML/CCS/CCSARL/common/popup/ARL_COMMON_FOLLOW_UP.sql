<popupdata type="sql">
    <sql dataSource="BankingDS">       

         SELECT  fu.OID, fu.follow_up_no, fu.state, fu.customer_code, fu.LETTER_DATE, 
                 fu.YTS_TRANSFERED, fu.REFERENCE_ID, fu.CUSTOMER_ORG_CODE MAIN_BRANCH_CODE, fu.SUB_STATE, fu.YTS_DESTINATION,
                 TRIM (   cust.NAME
                       || ' '
                       || cust.second_name
                       || ' '
                       || cust.surname
                       || ' '
                       || cust.title
                      ) AS customer_title, fu.CUSTOMER_RISK_CODE, APP_DATE, YTS_TRANSFER_DATE,(u.user_file_no||'-'||u.user_first_name||' '||u.user_last_name) AS CLOSED_USER
            FROM ccs.arl_cmmn_follow_up fu, infra.cust_cust_cust cust,infra.admin_usr_user u
           WHERE fu.status = '1'
             AND cust.customer_code = fu.customer_code
             and u.oid(+) = CLOSED_USER_OID
             AND ((? IS NOT NULL AND fu.follow_up_no = ?) OR (? IS NULL))
             AND ((? IS NOT NULL AND fu.OID = ?) OR (? IS NULL))
             AND ((? IS NOT NULL AND fu.customer_code = ?) OR (? IS NULL))
             AND ((? IS NOT NULL AND fu.state = ?) OR (? IS NULL))
             AND ((? IS NOT NULL AND fu.sub_state = ?) OR (? IS NULL))
             AND ((? IS NOT NULL AND '1'=? AND fu.yts_transfered = '1' AND (fu.YTS_DESTINATION='YTS' or fu.YTS_DESTINATION IS NULL))
				  OR (? IS NOT NULL AND '0'=? AND fu.yts_transfered = '0')	
				  OR (? IS NOT NULL AND '2'=? AND fu.yts_transfered = '1' AND fu.YTS_DESTINATION='KTS')	OR (? IS NULL))
             AND ((? IS NOT NULL AND fu.CUSTOMER_ORG_CODE = ?) OR (? IS NULL))
			 AND ((? IS NOT NULL AND fu.yts_transfered = ?) OR (? IS NULL))
        ORDER BY fu.follow_up_no

    </sql>
    <parameters>
			<parameter prefix="" suffix="">Page.pnlTop.txtFileNo</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFileNo</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFileNo</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.txtFollowUpOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFollowUpOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFollowUpOid</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.hndCust</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.hndCust</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.hndCust</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.cmbFileState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbFileState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbFileState</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.cmbProcessState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbProcessState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbProcessState</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbTransferedToYTS</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.cmbBranch</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbBranch</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbBranch</parameter>
			
			<parameter prefix="" suffix="">Page.pnlTop.cmbYTS_KTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbYTS_KTS</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbYTS_KTS</parameter>
			
    </parameters>
</popupdata>