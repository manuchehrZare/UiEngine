<popupdata type="service">
	<service>ARL_COMMON_LIST_AUDIT_FILES_FOR_POPUP</service>
	    <parameters>
	        <parameter n="AUDIT_FILE_NO">Page.pnlDetail.txtAuditFileNo</parameter>
	        <parameter n="CUSTOMER_ORG_CODE">Page.pnlDetail.cmbBranch</parameter>
	        <parameter n="CUSTOMER_CODE">Page.pnlDetail.hndCustomer</parameter>
	        <parameter n="PRIORITY">Page.pnlDetail.cmbPriority</parameter>
	        <parameter n="SOURCE">Page.pnlDetail.cmbSource</parameter>
	        <parameter n="CREATOR_USER_OID">Page.pnlDetail.txtCreatorUserOid</parameter>
	        <parameter n="STATE">Page.pnlDetail.cmbExeptionFileStatus</parameter>
	        <parameter n="PROCESS_TYPE">Page.pnlDetail.cmbUnit</parameter>
	        <parameter n="RISK_CODE">Page.pnlDetail.cmbRiskCode</parameter>
	        <parameter n="CREATOR_ORG_CODE">Page.pnlDetail.cmbCreatorOrgCode</parameter>
	        <parameter n="IS_COMMENT_DEMAND_ACTION">Page.txtIsCommentDemandAction</parameter>
	        <parameter n="USER_ORG_CODE">Page.txtUserOrgCode</parameter>
	      </parameters>
</popupdata>