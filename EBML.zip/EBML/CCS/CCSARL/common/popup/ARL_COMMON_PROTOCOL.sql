<popupdata type="sql">
	<sql dataSource="BankingDS">
	SELECT   *
	    FROM CCS.ARL_CMMN_PROTOCOL PR
	   WHERE STATUS = '1'
	     AND (? IS NULL OR PROTOCOL_NO = ?)
	     AND (? IS NULL OR PROTOCOL_STATE = ?)
	     AND (? IS NULL OR CUSTOMER_CODE = ?)
	     AND (? IS NULL OR BRANCH_CODE = ?)
	     AND (? IS NULL OR RISK_CODE = ?)
	     AND (? IS NULL OR USER_OID = ?)
	     AND (? IS NULL OR CLOSE_USER_OID = ?)
	     AND (? IS NULL OR CLOSE_REASON = ?)
	     AND (? IS NULL OR APPROVER_COMMITTEE = ?)
	     AND (? IS NULL OR IS_MIGRATION = ?)
	     AND (? IS NULL OR FOLLOW_UP_OID = ?)
	ORDER BY cast(PROTOCOL_NO AS NUMBER)
    </sql>
    <parameters>
		<parameter prefix="" >Page.pnlDetail.txtProtocolNo</parameter>
		<parameter prefix="" >Page.pnlDetail.txtProtocolNo</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbProtocolStatus</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbProtocolStatus</parameter>
		<parameter prefix="" >Page.pnlDetail.hndCustomerCode</parameter>
		<parameter prefix="" >Page.pnlDetail.hndCustomerCode</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbBranch</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbBranch</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbRiskCode</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbRiskCode</parameter>
		<parameter prefix="" >Page.pnlDetail.hndCreatorUser</parameter>
		<parameter prefix="" >Page.pnlDetail.hndCreatorUser</parameter>
		<parameter prefix="" >Page.pnlDetail.hndCloserUser</parameter>
		<parameter prefix="" >Page.pnlDetail.hndCloserUser</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbCloseReason</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbCloseReason</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbApproverCommitee</parameter>
		<parameter prefix="" >Page.pnlDetail.cmbApproverCommitee</parameter>
		<parameter prefix="" >Page.txtIsMGR</parameter>
		<parameter prefix="" >Page.txtIsMGR</parameter>
		<parameter prefix="" >Page.txtFollowUpOID</parameter>
		<parameter prefix="" >Page.txtFollowUpOID</parameter>
    </parameters>
</popupdata>