<popupdata type="service">
	<service>ARL_COMMON_LIST_CUST_RISK_FOR_POPUP</service>
	    <parameters>
	        <parameter n="SOURCE">Page.pnlDetail.cmbSource</parameter>
	        <parameter n="CUSTOMER_CODE">Page.txtCustomerCode</parameter>
	        <parameter n="BUSINESS_REFERENCE_ID">Page.pnlDetail.txtBusinessRefId</parameter>
	        <parameter n="TEMPLATE_NAME">Page.pnlDetail.hndTemplate</parameter>
	      </parameters>
</popupdata>