<popupdata type="sql">
    <sql dataSource="BankingDS">       

    (
        select distinct detail.*,rm.customer_code,PG.PRODUCT_GROUP_NAME AS GROUP_NAME,P.PRODUCT_NAME
        from ccs.ARL_RBD_REBUILD_DETAIL detail,INFRA.PROD_PRODUCT_NEW P,
        INFRA.PROD_PRODUCT_GROUP PG,ccs.arl_rbd_main RM
        where  (((? is not null and detail.INSTALMENT_OID =(?)))
            or (? is not null and detail.BUSINESS_REFERENCE_ID =(?)||(?))
         or ((? is not null) and (detail.RBD_MAIN_OID in
         (select oid  from ccs.arl_rbd_main m 
            where m.customer_code =? 
            and m.status='1'
            and m.rebuild_state='1'))))
        and detail.MAIN_GROUP_CODE = PG.PRODUCT_MAIN_GROUP_CODE
        and  detail.GROUP_CODE= PG.PRODUCT_GROUP_CODE
        and detail.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
        and  detail.GROUP_CODE  = P.GROUP_CODE
        and  detail.PRODUCT_CODE = P.PRODUCT_CODE
        and rm.oid = detail.RBD_MAIN_OID
		and pg.STATUS='1'
        and p.STATUS ='1'
    )
    </sql>
    <parameters>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtInstalmentOid</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtInstalmentOid</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtSimNo</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtSimName</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtSimNo</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.hndCustomer</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.hndCustomer</parameter>
    </parameters>
</popupdata>