<popupdata type="sql">
<sql dataSource="BankingDS">
SELECT PROPOSAL_NO,
  CUSTOMER_CODE,
  BRANCH_CODE,
  STATE
FROM
  (SELECT PROPOSAL_NO,
    CUSTOMER_CODE,
    BRANCH_CODE,
    STATE
  FROM CCS.PROPOSAL
  WHERE CUSTOMER_CODE=?
  AND STATUS         ='1'
  AND STATE NOT     IN('8')
  UNION ALL
  SELECT PROPOSAL_NO,
    CUSTOMER_CODE,
    BRANCH_CODE,
    STATE
  FROM CCS.PROPOSAL
  WHERE PROPOSAL_NO=?
  AND STATUS       ='1'
  AND STATE NOT   IN('8')
  ) T1 GROUP BY T1.PROPOSAL_NO,T1.CUSTOMER_CODE, T1.BRANCH_CODE,T1.STATE
</sql>
    <parameters>
	    	<parameter prefix="" suffix="">Page.pnlFilter.ppCustomer</parameter>
	    	<parameter prefix="" suffix="">Page.pnlFilter.txtProposalNo</parameter>
    </parameters>
</popupdata>