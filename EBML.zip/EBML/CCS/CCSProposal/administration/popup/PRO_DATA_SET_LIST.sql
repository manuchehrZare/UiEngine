<popupdata type="service">
	<service>CCS_PRO_FILL_POP_UP_DATA_SET_DEF</service>
	    <parameters>
	        <parameter n="DATA_KEY">Page.pnlQuery.txtDataKey</parameter>
	        <parameter n="DESCRIPTION">Page.pnlQuery.txtDescription</parameter>
	        <parameter n="DATA_SET_TYPE">Page.pnlQuery.cbDataSetType</parameter>
	        <parameter n="OID">Page.pnlQuery.txtDataSetOid</parameter>
	    </parameters>
</popupdata>