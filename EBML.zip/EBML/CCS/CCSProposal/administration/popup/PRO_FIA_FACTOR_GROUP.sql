<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  SELECT 
	        OID, 
	        FIA_TYPE,
	        FIA_SUB_TYPE,
	        FIA_FACTOR_GROUP_CODE,
	        FIA_FACTOR_GROUP_NAME
	      FROM CCS.PRO_FIA_FACTOR_GROUP_DEF
	    WHERE 
	            STATUS='1' AND 
	            (? is null OR FIA_TYPE = ?) AND
	            (? is null OR FIA_SUB_TYPE = ?) AND
	            (? is null OR FIA_FACTOR_GROUP_CODE LIKE (? || '%')) AND
	            (? is null OR FIA_FACTOR_GROUP_NAME LIKE (? || '%'))
	      ORDER BY FIA_FACTOR_GROUP_NAME
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.cmbRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbSubRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbSubRprtType</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtGroupName</parameter>	
     </parameters>
</popupdata>