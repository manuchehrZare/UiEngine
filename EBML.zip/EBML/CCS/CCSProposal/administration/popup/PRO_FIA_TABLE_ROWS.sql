<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
    select 		
		row1.ORDER_NO , 
		row1.ROW_LEVEL , 
		row1.TABLE_CODE , 
		row1.ROW_CODE , 
		row1.ROW_NAME ,
		row1.TREND_TYPE
	from 
		ccs.pro_fia_table_row_def row1, ccs.pro_fia_table_def tbl
	where
		row1.status = '1'
		and tbl.status = '1'
		and(? is null OR row1.table_code = ?)
		and(? is null OR row1.row_code LIKE ('%'||?||'%'))
		and(? is null OR row1.row_name LIKE ('%'||?||'%'))
		and((? is null OR ? <= 0) OR row1.row_level = ?)
		and((? is null OR ? <= 0) OR row1.order_no = ?)
		and(? is null OR row1.trend_type = ?)
		and(? is null OR row1.entry_type = ?)
		and exists ( select 1 
		               from  ccs.pro_adm_def_criteria_rel crt
		              where crt.status = '1'
							and(? is null OR crt.definition_type_code = ?)
							and(? is null OR (crt.criteria_type = ? and (crt.criteria_value = ? or crt.criteria_value is null)))
							and(? is null OR (crt.criteria_type = ? and (crt.criteria_sub_value = ? or crt.criteria_sub_value is null)))
							and tbl.table_code = crt.definition_code)	
		and(? is null OR tbl.is_usable_in_comments = ? )
		and tbl.table_code = row1.table_code
		
    </sql>
    <parameters>
		<parameter prefix="" >Page.pnlFilter.cmbTableCode</parameter>
		<parameter prefix="" >Page.pnlFilter.cmbTableCode</parameter>
		<parameter prefix="" >Page.pnlFilter.txtRowCode</parameter>
		<parameter prefix="" >Page.pnlFilter.txtRowCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtRowName</parameter>
		<parameter prefix="" >Page.pnlFilter.txtRowName</parameter>
		<parameter prefix="" >Page.pnlFilter.txtLevel</parameter>
		<parameter prefix="" >Page.pnlFilter.txtLevel</parameter>
		<parameter prefix="" >Page.pnlFilter.txtLevel</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtOrderNo</parameter>
		<parameter prefix="" >Page.pnlFilter.txtOrderNo</parameter>
		<parameter prefix="" >Page.pnlFilter.txtOrderNo</parameter>
		<parameter prefix="" >Page.pnlFilter.cmbTrendType</parameter>
		<parameter prefix="" >Page.pnlFilter.cmbTrendType</parameter>
		<parameter prefix="" >Page.pnlFilter.chbIsScoringReport</parameter>
		<parameter prefix="" >Page.pnlFilter.chbIsScoringReport</parameter>
		<parameter prefix="" >Page.pnlFilter.txtDefinitionTypeCode</parameter>
		<parameter prefix="" >Page.pnlFilter.txtDefinitionTypeCode</parameter>
		<parameter prefix="" >Page.pnlFilter.rgnFiaType.Page.cmbFiaType</parameter>
		<parameter prefix="" >Page.pnlFilter.txtCriteriaType</parameter>
		<parameter prefix="" >Page.pnlFilter.rgnFiaType.Page.cmbFiaType</parameter>
		<parameter prefix="" >Page.pnlFilter.rgnFiaType.Page.cmbFiaSubType</parameter>
		<parameter prefix="" >Page.pnlFilter.txtCriteriaType</parameter>
		<parameter prefix="" >Page.pnlFilter.rgnFiaType.Page.cmbFiaSubType</parameter>
		<parameter prefix="" >Page.pnlFilter.txtUsableInComments</parameter>
		<parameter prefix="" >Page.pnlFilter.txtUsableInComments</parameter>
    </parameters>
</popupdata>
 
 