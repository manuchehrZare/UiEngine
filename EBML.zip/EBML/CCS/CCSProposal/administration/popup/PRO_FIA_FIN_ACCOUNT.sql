<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	
		SELECT D.OID, D.FA_CODE, D.FA_NAME
          FROM CCS.PRO_FIA_FIN_ACCOUNT_DEF D
         WHERE D.STATUS = '1'
           AND UPPER(D.LEDGER_CODE) LIKE UPPER('%'||?||'%')
		   AND UPPER(D.FA_NAME) LIKE UPPER('%'||?||'%') 
           AND UPPER(D.FA_CODE) LIKE UPPER('%'||?||'%') 
         ORDER BY D.FA_CODE

    </sql>
      <parameters>
		<parameter prefix="" >Page.pnlFilter.cbLedger</parameter>
		<parameter prefix="" >Page.pnlFilter.txtFinAccName</parameter>
    	<parameter prefix="" >Page.pnlFilter.txtFinAccCode</parameter>
	  </parameters>
</popupdata>
