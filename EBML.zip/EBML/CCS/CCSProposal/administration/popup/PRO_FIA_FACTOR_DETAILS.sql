<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 	  	
		  	FA.FACTOR_CODE,
		  	FA.FACTOR_NAME,
		  	FA.FACTOR_VALUE,
		  	FA.ANSWER_VALUE,
		  	FA.CALC_FACTOR_VALUE,
		  	FA.CALC_ANSWER_VALUE,
		  	FA.RESULT_VALUE
	  	FROM CCS.PRO_FIA_FACTOR_ANSWER FA
		WHERE 
	          FA.STATUS='1' AND 
	          (FA.PROPOSAL_OID = ?) AND
	          (? is null or FA.REPORT_OWNER = ?)
	    ORDER BY FACTOR_CODE
    </sql>
    <parameters>
    	<parameter prefix="" >Page.pnlFilter.txtReportOID</parameter>	
    	<parameter prefix="" >Page.pnlFilter.txtReportOwner</parameter>	
    	<parameter prefix="" >Page.pnlFilter.txtReportOwner</parameter>	
     </parameters>
</popupdata>