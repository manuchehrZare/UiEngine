<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
    SELECT DISTINCT VARIABLE_CODE, min(VARIABLE_DESC) as VARIABLE_DESCR
		FROM CCS.PRO_FIA_VARIABLE_DEF
		WHERE STATUS='1'
		AND (? IS NULL OR VARIABLE_CODE LIKE (? || '%'))
		AND (? IS NULL OR VARIABLE_DESC LIKE (? || '%'))
		GROUP BY VARIABLE_CODE
	    ORDER BY VARIABLE_CODE
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtFilterVarCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtFilterVarCode</parameter> 	
	   	<parameter prefix="" >Page.pnlFilter.txtFilterVarName</parameter> 	
	   	<parameter prefix="" >Page.pnlFilter.txtFilterVarName</parameter> 	
    </parameters>
</popupdata>
 
 