<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
	  	SELECT 
		  	F.OID, 
		  	F.FIA_FACTOR_CODE,
		  	F.FIA_FACTOR_NAME,
		  	F.FIA_FACTOR_DESC,
		  	F.FIA_FACTOR_GROUP_CODE
	  	FROM CCS.PRO_FIA_FACTOR_DEF F
		WHERE 
	          F.STATUS='1' AND 
	          (? is null OR F.FIA_FACTOR_CODE LIKE (? || '%')) AND
	          (? is null OR F.FIA_FACTOR_NAME LIKE (? || '%')) AND
	          (? is null OR F.FIA_FACTOR_GROUP_CODE = ?)
	    ORDER BY FIA_FACTOR_GROUP_CODE, FIA_FACTOR_CODE
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtName</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbGroupCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbGroupCode</parameter> 	
     </parameters>
</popupdata>