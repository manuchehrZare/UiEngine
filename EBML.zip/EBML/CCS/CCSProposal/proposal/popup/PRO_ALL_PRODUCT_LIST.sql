<popupdata type="sql">
<sql dataSource="BankingDS">
SELECT OID,
  MAIN_GROUP_CODE,
  GROUP_CODE,
  PRODUCT_CODE,
  CASH_NON_CASH ,
  ( MAIN_GROUP_CODE
  || GROUP_CODE
  || PRODUCT_CODE) AS CODE,
  STANDART_PROPOSAL,
  SHORT_PROPOSAL,
  MID_PROPOSAL,
  CACHE_RESERVE_PROPOSAL,
  MICRO_FINANCING_PROPOSAL
FROM
  (SELECT OID,
    MAIN_GROUP_CODE,
    GROUP_CODE,
    PRODUCT_CODE,
    CASH_NON_CASH ,
    ( MAIN_GROUP_CODE
    || GROUP_CODE
    || PRODUCT_CODE) AS CODE,
    STANDART_PROPOSAL,
    SHORT_PROPOSAL,
    MID_PROPOSAL,
    CACHE_RESERVE_PROPOSAL,
    MICRO_FINANCING_PROPOSAL
  FROM
    (SELECT P.OID,
      P.MAIN_GROUP_CODE,
      P.GROUP_CODE,
      P.PRODUCT_CODE,
      P.CASH_NON_CASH,
      STANDART_PROPOSAL,
      SHORT_PROPOSAL,
      MID_PROPOSAL,
      CACHE_RESERVE_PROPOSAL,
      MICRO_FINANCING_PROPOSAL
    FROM CCS.PRODUCT_LIMIT P,
      INFRA.PROD_PRODUCT_NEW IP
    WHERE P.STATUS  = '1'
    AND IP.oid NOT IN (
      CASE
        WHEN ? = 1
        THEN
          (SELECT oid
          FROM INFRA.PROD_PRODUCT_NEW PN
          WHERE PN.MAIN_GROUP_CODE = '09'
          AND PN.GROUP_CODE        ='03'
          AND PN.PRODUCT_CODE      ='028'
          )
      END )
    AND IP.STATUS          = '1'
    AND IP.PRODUCT_CODE    = P.PRODUCT_CODE
    AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
    AND IP.GROUP_CODE      = P.GROUP_CODE
    AND IP.PRODUCT_ACTIVE  = '1'
    AND P.CASH_NON_CASH LIKE ?
    AND P.PRODUCT_CODE LIKE ?
    AND P.OID IN
      (SELECT R.PRODUCT_OID
      FROM CCS.PRODUCT_CUSTOMER_CREDIT_TYPE R,
        CCS.CUSTOMER_TYPE T
      WHERE T.STATUS = '1'
      AND R.STATUS   = '1'
      AND T.OID      = R.CUSTOMER_TYPE_OID
      AND T.CODE     = ?
      )
    )
  UNION
  SELECT OID,
    MAIN_GROUP_CODE,
    GROUP_CODE,
    PRODUCT_CODE ,
    CASH_NON_CASH ,
    ( MAIN_GROUP_CODE
    || GROUP_CODE
    || PRODUCT_CODE) AS CODE,
    P.STANDART_PROPOSAL,
    P.SHORT_PROPOSAL,
    P.MID_PROPOSAL,
    P.CACHE_RESERVE_PROPOSAL,
    P.MICRO_FINANCING_PROPOSAL
  FROM CCS.PRODUCT_LIMIT P
  WHERE P.STATUS = '1'
  AND P.OID     IN
    (SELECT PRODUCT_OID
    FROM CCS.PRODUCT_CUSTOMER
    WHERE STATUS      = '1'
    AND CUSTOMER_CODE = ?
    )
  AND P.oid NOT IN (
    CASE
      WHEN ? = 1
      THEN
        (SELECT oid
        FROM CCS.PRODUCT_LIMIT PN
        WHERE PN.MAIN_GROUP_CODE = '09'
        AND PN.GROUP_CODE        ='03'
        AND PN.PRODUCT_CODE      ='028'
        )
    END )
  ) T1
WHERE DECODE(?,1,CACHE_RESERVE_PROPOSAL,2,T1.SHORT_PROPOSAL,3,T1.STANDART_PROPOSAL,4,MICRO_FINANCING_PROPOSAL,5,T1.MID_PROPOSAL,0)=1
</sql>
    <parameters>
    		<parameter prefix="" suffix="">Page.txtSwap</parameter>
        	<parameter prefix="" suffix="%">Page.cmbCashNonCash</parameter>
        	<parameter prefix="" suffix="%">Page.txtProductCode</parameter>
     	    <parameter prefix="" suffix="">Page.cmbCustomerType</parameter>
	    	<parameter prefix="" suffix="">Page.ppCustomer</parameter>
	    	<parameter prefix="" suffix="">Page.txtSwap</parameter>
	    	<parameter prefix="" suffix="">Page.cmbProposalType</parameter>
    </parameters>
</popupdata>