<popupdata type="sql">
<sql dataSource="BankingDS">
	select distinct  OID, PROPOSAL_NO, 
	CUSTOMER_CODE, 
	STATE, 
	BRANCH_CODE
  from(
	SELECT OID, 
  PROPOSAL_NO, 
	CUSTOMER_CODE, 
	STATE, 
	BRANCH_CODE
	FROM CCS.PROPOSAL
	WHERE STATUS = '1'
	AND OID LIKE ?
	AND (PROPOSAL_NO IS NULL OR PROPOSAL_NO LIKE ?)
	AND CUSTOMER_CODE LIKE ?
	AND BRANCH_CODE LIKE  ?
   and decode(?,NULL,1,?)=state  
  union all  
  SELECT OID, 
  PROPOSAL_NO, 
	CUSTOMER_CODE, 
	STATE, 
	BRANCH_CODE
	FROM CCS.PROPOSAL
	WHERE STATUS = '1'
	AND OID LIKE ?
	AND (PROPOSAL_NO IS NULL OR PROPOSAL_NO LIKE ?)
	AND CUSTOMER_CODE LIKE ?
	AND BRANCH_CODE LIKE  ?
  and decode(?,NULL,1,2)=1
  )
</sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtOID</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtProposalNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.ppCustomer</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbBranch</parameter>
    	<parameter prefix="" suffix="">Page.pnlFilter.cmbProposalState</parameter>
    	<parameter prefix="" suffix="">Page.pnlFilter.cmbProposalState</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtOID</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtProposalNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.ppCustomer</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbBranch</parameter>
    	<parameter prefix="" suffix="">Page.pnlFilter.cmbProposalState</parameter>
    </parameters>
</popupdata>
