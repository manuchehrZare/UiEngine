<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
		SELECT CR.OID,
			   CUST.CUSTOMER_CODE,
			   CUST.NAME_TITLE,
			   CR.CREATE_DATE,
			   CUST.MAIN_BRANCH_CODE,
			   CR.CREDIT_REPORT_NO,
			   CR.CREATE_USER,
			   ''  AS STATE
		  FROM CCS.PRO_CR_MAIN CR, CCS.PRO_CR_CUSTOMER_STATE_INFO CUST
		 WHERE CR.STATUS = '1'
		   AND CUST.STATUS = '1'
		   AND CR.OID = CUST.MAIN_OID
		   AND (CR.OID = ? OR ? IS NULL)
		   AND (CR.CREDIT_REPORT_NO = ? OR ? IS NULL)
		   AND (CR.CUSTOMER_CODE = ? OR ? IS NULL)
		   AND (CUST.MAIN_BRANCH_CODE = ? OR ? IS NULL)
		   AND (? IS NULL OR CR.CREATE_DATE >= ?)
		   AND (? IS NULL OR CR.CREATE_DATE <= ?)
		ORDER BY LENGTH(CR.CREDIT_REPORT_NO), CR.CREDIT_REPORT_NO
    </sql>
    <parameters>
	   	<parameter prefix="" >Page.pnlFilter.txtCreditReportOid</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCreditReportOid</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCreditReportNo</parameter>
	   	<parameter prefix="" >Page.pnlFilter.txtCreditReportNo</parameter>
	   	<parameter prefix="" >Page.pnlFilter.hndCustomerCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.hndCustomerCode</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbBranch</parameter>
	   	<parameter prefix="" >Page.pnlFilter.cmbBranch</parameter>
	   	<parameter prefix="" >Page.pnlFilter.dtStartDate</parameter>
	   	<parameter prefix="" >Page.pnlFilter.dtStartDate</parameter>
	   	<parameter prefix="" >Page.pnlFilter.dtEndDate</parameter>
	   	<parameter prefix="" >Page.pnlFilter.dtEndDate</parameter>	   	
     </parameters>
</popupdata>