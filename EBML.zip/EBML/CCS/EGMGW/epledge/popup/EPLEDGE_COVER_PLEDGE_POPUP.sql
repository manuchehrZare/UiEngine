<popupdata type="service">
	<service>EGMGW_EPLEDGE_FIND_CAR_PLEDGE_FOR_POPUP</service>
	    <parameters>	       
	        <parameter n="PLATE">Page.txtPlate</parameter>
   	        <parameter n="REGISTER_NO">Page.txtRegisterNo</parameter>	        
	        <parameter n="ORG_CODE">Page.cmbBranchCode</parameter>
   	        <parameter n="TC_ID">Page.txtTcID</parameter>	
 			<parameter n="COVER_PLEDGE_STATUS">Page.cmbPledgeStatus</parameter>	
			<parameter n="EGM_REF_NO">Page.txtEGMRefNo</parameter>	
			<parameter n="SUSPENSE_REG_NO">Page.txtYevmiye</parameter>
			<parameter n="CHASSIS_NO">Page.txtChassisNo</parameter>
			<parameter n="ENGINE_NO">Page.txtEngineNo</parameter>
			<parameter n="EGM_CATEGORY">Page.cmbEGMCategory</parameter>
			<parameter n="COVER_NO">Page.txtCoverNo</parameter> 
			<parameter n="COVER_PLEDGE_STATUS_K">Page.txtPledgeStatusList</parameter> 
			<parameter n="INDIVIDUAL_CORPORATE">Page.cmbCorporateBane</parameter> 			
</parameters>
</popupdata>