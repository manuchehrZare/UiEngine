<popupdata type="sql">
<sql dataSource="BankingDS">
	SELECT OID, ALL_NO, 
	CUSTOMER_CODE, 
	ALL_STATE, 
	BRANCH_CODE,
	AUTHORITY_TYPE
	FROM CCS.ALLOTMENT
	WHERE STATUS = '1'
	AND OID LIKE ?
	AND ALL_NO LIKE ?
	AND CUSTOMER_CODE LIKE ?
	AND BRANCH_CODE LIKE  ?
	AND ALL_STATE LIKE  ?
	ORDER BY ALL_NO
</sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtOID</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtAllotmentNO</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.ppCustomer</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbBranch</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbAllotmentState</parameter>
    </parameters>
</popupdata>
