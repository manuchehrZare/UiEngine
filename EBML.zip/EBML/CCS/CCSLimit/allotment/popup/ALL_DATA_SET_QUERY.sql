<popupdata type="sql">
<sql dataSource="BankingDS">
	SELECT D.OID,
	D.DATA_SET_NAME,
	D.DATA_SET_CODE, 
	D.DATA_SET_TYPE,
	D.DATASET_STATE
	FROM CCS.ALL_DATA_SET_DEFINITION D
	WHERE D.STATUS = '1'
	AND  (D.DATA_SET_CODE =? OR ? IS NULL)
	AND (D.DATA_SET_NAME =? OR ? IS NULL)
	AND (D.DATA_SET_TYPE =? OR  ? IS NULL )
	AND (D.DATASET_STATE =? OR  ? IS NULL )
	AND (D.USAGE_PURPOSE =? OR  ? IS NULL )
</sql>
    <parameters>
    	<parameter prefix="" suffix="">Page.pnlQuery.txtDataKey</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.txtDataKey</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.txtDataName</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.txtDataName</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.cbDataSetType</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.cbDataSetType</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.cmbDataSetState</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.cmbDataSetState</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.lblDataSetUsagePurpose</parameter>
    	<parameter prefix="" suffix="">Page.pnlQuery.lblDataSetUsagePurpose</parameter>
    </parameters>
</popupdata>
