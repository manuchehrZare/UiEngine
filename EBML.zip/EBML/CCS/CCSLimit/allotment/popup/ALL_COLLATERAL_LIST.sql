<popupdata type="service">
	<service>CCS_ALL_BINDING_COLLATERAL_FILL_POPUP</service>
	    <parameters>
	        <parameter n="CUSTOMER_CODE">Page.pnlFilter.hndCustomerCode</parameter>
	        <parameter n="COLLATERAL_TYPE">Page.pnlFilter.cmbCollateralType</parameter>
	        <parameter n="COLLATERAL_CREDIT_TYPE">Page.pnlFilter.cmbCreditType</parameter>     
			<parameter n="BAIL_CUST_CODE">Page.pnlFilter.txtBailCustCode</parameter>
			<parameter n="COLLATERAL_NO">Page.pnlFilter.hndColCollateralNo</parameter>     
	    </parameters>
</popupdata>