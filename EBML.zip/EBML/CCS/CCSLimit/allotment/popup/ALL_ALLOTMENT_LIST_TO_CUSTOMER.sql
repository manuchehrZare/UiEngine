<popupdata type="sql">
<sql dataSource="BankingDS">
							  
	SELECT A.ALL_NO,A.BRANCH_CODE,
		   A.CUSTOMER_CODE, 
		   AL.EXISTING_LMT,
		   AL.LIMIT_TYPE 
	FROM CCS.ALLOTMENT_LIMIT AL,
		   CCS.ALLOTMENT A
	WHERE AL.STATUS='1'
		  AND AL.FIRM_OR_GROUP='F'
		  AND AL.ALLOTMENT_OID = A.OID
		  AND A.STATUS='1' 
		  AND A.CUSTOMER_CODE LIKE ? 
		  AND A.ALL_NO LIKE ? 
		  AND (A.BRANCH_CODE LIKE ? OR  ? IS NULL)
		  AND AL.FIRM_OR_GROUP='F' 
		  AND A.ALL_STATE='1'
</sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlFilter.ppCustomer</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtAllotmentNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbBranch</parameter>
	   	<parameter prefix="" suffix="">Page.pnlFilter.cmbBranch</parameter>
    </parameters>
</popupdata>
