<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT OID,REGULATION_NO,REGULATION_STATE, REGULATION_DATE, REGULATION_UPDATE_REASON
	    FROM   CCS.REGULATION_REGION_DEFINITION
		WHERE STATUS='1' AND REGULATION_NO LIKE ?
		AND REGULATION_STATE LIKE ? 
	    ORDER BY REGULATION_NO
</sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtProposalNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbProposalState</parameter>
   </parameters>
</popupdata>