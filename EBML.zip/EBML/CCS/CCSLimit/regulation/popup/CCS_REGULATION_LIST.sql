<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT OID,REGULATION_NO,STATE,VALIDITY_DATE
	    FROM   CCS.REGULATION_CONDITION_MASTER  
		WHERE STATUS='1' AND REGULATION_NO LIKE ?
		AND STATE like ? AND BRANCH_CODE is null
	    ORDER BY REGULATION_NO
</sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtProposalNo</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbProposalState</parameter>
   </parameters>
</popupdata>