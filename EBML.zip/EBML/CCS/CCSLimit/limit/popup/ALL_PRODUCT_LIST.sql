<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT OID,MAIN_GROUP_CODE,GROUP_CODE,PRODUCT_CODE,CASH_NON_CASH ,
( MAIN_GROUP_CODE || GROUP_CODE || PRODUCT_CODE) AS CODE
FROM ( 
       
       SELECT P.OID,P.MAIN_GROUP_CODE,P.GROUP_CODE,P.PRODUCT_CODE, P.CASH_NON_CASH 
       FROM CCS.PRODUCT_LIMIT P, INFRA.PROD_PRODUCT_NEW IP
       WHERE P.STATUS = '1' 
       AND IP.oid not in (case when ? = 1
            then  (select oid from INFRA.PROD_PRODUCT_NEW PN
                                  where PN.MAIN_GROUP_CODE = '09' AND PN.GROUP_CODE ='03' AND PN.PRODUCT_CODE ='028')
            end
       )
       and IP.STATUS = '1'
       AND IP.PRODUCT_CODE = P.PRODUCT_CODE
       AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
       AND IP.GROUP_CODE = P.GROUP_CODE
       AND IP.PRODUCT_ACTIVE = '1'
       
          AND P.CASH_NON_CASH LIKE ?
		  AND P.PRODUCT_CODE LIKE ?
		  
             AND P.OID IN ( SELECT R.PRODUCT_OID 
                            FROM CCS.PRODUCT_CUSTOMER_CREDIT_TYPE R,CCS.CUSTOMER_TYPE T 
                            WHERE T.STATUS = '1' AND R.STATUS = '1' 
                                 AND T.OID = R.CUSTOMER_TYPE_OID 
                                 AND T.CODE = ?
                           )
     ) K 
WHERE K.OID NOT IN  (  

				SELECT PRODUCT_OID 
                       FROM CCS.PRODUCT_SECTOR 
                       WHERE STATUS = '1' 
                             AND (( 
                             		SECTOR_CODE = ?
					        		AND ACTIVITY_CODE = ?
      	 						)
      	 						OR
      	 						(
	      	 						SECTOR_CODE = ?
	      	 						AND ACTIVITY_CODE IS NULL
      	 						)
							)

      	 				
      	 					
      	 			)         
UNION

SELECT OID,MAIN_GROUP_CODE,GROUP_CODE,PRODUCT_CODE ,CASH_NON_CASH , ( MAIN_GROUP_CODE || GROUP_CODE || PRODUCT_CODE) AS CODE
        FROM CCS.PRODUCT_LIMIT P
        WHERE P.STATUS = '1' AND  P.OID IN 
                                        (SELECT PRODUCT_OID 
                                         FROM CCS.PRODUCT_CUSTOMER 
                                         WHERE STATUS = '1' AND CUSTOMER_CODE = ?)
       AND P.oid not in (case when ? = 1
                then  (select oid from CCS.PRODUCT_LIMIT PN
                                      where PN.MAIN_GROUP_CODE = '09' AND PN.GROUP_CODE ='03' AND PN.PRODUCT_CODE ='028')
                end )                                          
</sql>
    <parameters>
    		<parameter prefix="" suffix="">Page.txtSwap</parameter>
        	<parameter prefix="" suffix="%">Page.cmbCashNonCash</parameter>
        	<parameter prefix="" suffix="%">Page.txtProductCode</parameter>
     	    <parameter prefix="" suffix="">Page.cmbCustomerType</parameter>
		   	<parameter prefix="" suffix="">Page.txtSectorCode</parameter>
			<parameter prefix="" suffix="">Page.txtActivityCode</parameter>
			<parameter prefix="" suffix="">Page.txtSectorCode</parameter>
	    	<parameter prefix="" suffix="">Page.ppCustomer</parameter>
	    	<parameter prefix="" suffix="">Page.txtSwap</parameter>		
    </parameters>
</popupdata>