<popupdata type="sql">
	<sql dataSource="BankingDS">
		SELECT tem.*, 
	        pro.main_group_code, 
	        pro.group_code, 
	        pro.product_code,
	       pro.cash_non_cash, 
	       pro.product_properties
	  FROM ccs.product_usage_info_templet tem,
	       ccs.product_limit pro,
	       infra.prod_product_new ip,
	       infra.prod_product_group pgrp,
	       infra.prod_product_main_group pmgrp
	 WHERE tem.status = '1'
	   AND pro.status = '1'
	   AND tem.state in ('1',?)
	   and ip.status = '1'
       and pgrp.status = '1'
       and pmgrp.status = '1'
	   AND pro.OID = tem.product_oid
	   AND pro.product_code = ip.product_code
	   AND pro.main_group_code = ip.main_group_code
	   AND pro.group_code = ip.group_code
	   AND pgrp.product_group_code = ip.group_code
	   AND pgrp.product_main_group_code = ip.main_group_code
	   AND pmgrp.product_main_group_code = ip.main_group_code
	   AND (? IS NULL OR pmgrp.OID = ?)
	   AND (? IS NULL OR pgrp.OID = ?)
	   AND (? IS NULL OR ip.OID = ?)
	   AND (? IS NULL OR ip.OID = ?)
	   AND (? IS NULL OR tem.OID = ?)
	   AND (? IS NULL OR tem.detail_name like ?)
	   AND (? IS NULL OR tem.usage_type = ?)
	   AND (? IS NULL OR pro.product_properties = ?)
	   AND ( pro.OID IN (
	          SELECT apl.product_oid AS pro_oid
	            FROM ccs.allotment_product_limit apl, ccs.allotment allo
	           WHERE apl.allotment_oid = allo.OID
	             AND allo.OID = ?
	             AND apl.approved_lmt > 0
	             AND apl.status = '1'
	          UNION
	          SELECT alt.new_product_oid AS pro_oid
	            FROM ccs.allotment_transport alt
	           WHERE alt.allotment_oid = ?
	             AND alt.transport_state = '1'
	             AND alt.status = '1') 
	             or ? is null
	             )
	</sql>
    <parameters>
    		<parameter prefix="" suffix="">Page.lblProductState</parameter>
    		<parameter prefix="" suffix="">Page.cmbProductMainGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductMainGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductOID</parameter>
		    <parameter prefix="" suffix="">Page.lblProductOid</parameter>
        	<parameter prefix="" suffix="">Page.lblProductOid</parameter>
        	<parameter prefix="" suffix="">Page.lblUsageTempletOid</parameter>
        	<parameter prefix="" suffix="">Page.lblUsageTempletOid</parameter>
        	<parameter prefix="" suffix="">Page.lblTempleteName</parameter>
        	<parameter prefix="%" suffix="%">Page.lblTempleteName</parameter>
        	<parameter prefix="" suffix="">Page.cmbUsageType</parameter>
        	<parameter prefix="" suffix="">Page.cmbUsageType</parameter>
        	<parameter prefix="" suffix="">Page.pnlQuery.cmbProductProperties</parameter>
        	<parameter prefix="" suffix="">Page.pnlQuery.cmbProductProperties</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
    		<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>

    </parameters>
</popupdata>
