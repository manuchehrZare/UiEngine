<popupdata type="sql">
	<sql dataSource="BankingDS">
         SELECT P.*,PRO.PRODUCT_PROPERTIES AS PRODUCT_PROPERTY
          FROM CCS.PRODUCT_USAGE_INFO_TEMPLET P,
               CCS.PRODUCT_LIMIT PRO
         WHERE P.STATUS = '1' 
         AND P.STATE  = '1'
         AND PRO.OID = P.PRODUCT_OID
         AND P.PRODUCT_OID = ?
         AND (? is null or P.OID = ?)
	</sql>
    <parameters>
        	<parameter prefix="" suffix="">Page.cmbProduct</parameter>
        	<parameter prefix="" suffix="">Page.lblUsageTempletOid</parameter>
        	<parameter prefix="" suffix="">Page.lblUsageTempletOid</parameter>
    </parameters>
</popupdata>