<popupdata type="service">
	<service>CCS_DT_FILL_POP_UP_DATA_SET_QUERY_DEF</service>
	    <parameters>
	        <parameter n="KEY">Page.pnlQuery.txtDataKey</parameter>
	        <parameter n="DESCRIPTION">Page.pnlQuery.txtDataName</parameter>
	    </parameters>
</popupdata>