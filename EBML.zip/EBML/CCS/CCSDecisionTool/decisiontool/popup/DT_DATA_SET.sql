<popupdata type="service">
	<service>CCS_DT_FILL_POP_UP_DATA_SET_DEF</service>
	    <parameters>
	        <parameter n="DATA_KEY">Page.pnlQuery.txtDataKey</parameter>
	        <parameter n="DATA_NAME">Page.pnlQuery.txtDataName</parameter>
	        <parameter n="DATA_SET_TYPE">Page.pnlQuery.cbDataSetType</parameter>     
	        <parameter n="DEFAULT_VALUE">Page.pnlQuery.tfDefaultValue</parameter>     
	        <parameter n="EDIT_TYPE">Page.pnlQuery.cbEditTYpe</parameter>     
	        <parameter n="STATE">Page.pnlQuery.btnGrpState</parameter>
            <parameter n="DATA_GROUP_NAME">Page.pnlQuery.cbDataGroupName</parameter>
	    </parameters>
</popupdata>