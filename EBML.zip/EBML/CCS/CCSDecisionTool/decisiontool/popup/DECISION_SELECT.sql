<popupdata type="sql">
<sql dataSource="BankingDS">
  SELECT OID, DT_NO, 
  CUSTOMER_CODE, 
  STATE, 
  BRANCH_CODE,
  CUSTOMER_SEGMENT_CODE,
  APPROVE_CHAIR
  FROM CCS.DT_MAIN
  WHERE STATUS = '1'
  AND OID LIKE ?
  AND (? IS NULL OR DT_NO LIKE ?)
  AND CUSTOMER_CODE LIKE ?
  AND BRANCH_CODE LIKE  ?
  AND STATE LIKE  ?
  ORDER BY DT_NO
</sql>
    <parameters>
    	<parameter prefix="" suffix="%">Page.pnlFilter.txtOID</parameter>
    	<parameter prefix="" suffix="">Page.pnlFilter.txtDtNO</parameter>
    	<parameter prefix="" suffix="">Page.pnlFilter.txtDtNO</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.ppCustomer</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbBranch</parameter>
    	<parameter prefix="" suffix="%">Page.pnlFilter.cmbDtState</parameter>
    </parameters>
</popupdata>