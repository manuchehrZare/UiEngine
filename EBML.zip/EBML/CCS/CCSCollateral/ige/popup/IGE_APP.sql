<popupdata type="service">
    <service>CCS_COL_IGE_GET_APP_ENTRY</service>
         <parameters>  
              <parameter n="CUSTOMER_CODE">PgIgeSearch.JCSPanel20709.lblCustomerCode</parameter>
         </parameters>
</popupdata>