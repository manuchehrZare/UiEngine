<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT        
        REA.OID AS REAL_ESTATE_OID,
        REA.REAL_ESTATE_NO,
        REA.REAL_ESTATE_TYPE,
        REA.PAGE_NO,
        REA.CITY_CODE,
        REA.COUNTY_CODE,
		REA.BLOCK,
        REA.SHEET,
        REA.BLOCK_NO,
        REA.PARCEL,
        REA.FLOOR_NO,
        REA.FLAT_NO,
        REA.RESIDENCE,
		REA.CUST_CODE,
		REA.STATUS
FROM CCS.COLLATERAL_REALESTATE REA
WHERE  REA.OID LIKE ? AND
       (? = '%' OR REA.OID IN (SELECT REALESTATE_OID FROM  CCS.COLLATERAL_REALESTATE_OWNERS WHERE STATUS='1' AND OWNER_CUST_CODE LIKE ? ) ) AND
       (? is NULL OR REA.REAL_ESTATE_NO = ?) AND
	   (? is NULL OR REA.CUST_CODE = ?) AND
       REA.REAL_ESTATE_TYPE LIKE ? AND
       REA.CITY_CODE LIKE ? AND
       REA.COUNTY_CODE LIKE ? AND
       (? IS NULL OR REA.PAGE_NO = ?) AND
       (? is NULL OR REA.REALESTATE_CREDIT_TYPE = ?) AND
       (? IS NULL OR REA.STATUS = ?)
    ORDER BY    
      REA.REAL_ESTATE_NO
 	 </sql>
	<parameters>
		<parameter prefix="%" suffix="">Page.txtOid</parameter>	
		<parameter prefix="%" suffix="">Page.txtCustCode</parameter>
		<parameter prefix="%" suffix="">Page.txtCustCode</parameter>
		<parameter prefix="" suffix="">Page.txtRealEstateNo</parameter>
		<parameter prefix="" suffix="">Page.txtRealEstateNo</parameter>
		<parameter prefix="" suffix="">Page.hndRealCustCode</parameter>
		<parameter prefix="" suffix="">Page.hndRealCustCode</parameter>
		<parameter prefix="%" suffix="">Page.cmbRealEstateType</parameter>
		<parameter prefix="%" suffix="">Page.cmbCity</parameter>
		<parameter prefix="%" suffix="">Page.cmbTown</parameter>
		<parameter prefix=""  suffix="">Page.txtCoverNo</parameter>
		<parameter prefix=""  suffix="">Page.txtCoverNo</parameter>
		<parameter prefix=""  suffix="">Page.cmbCreditType</parameter>
		<parameter prefix=""  suffix="">Page.cmbCreditType</parameter>
		<parameter prefix=""  suffix="">Page.cmbRealEstateStatus</parameter>
		<parameter prefix=""  suffix="">Page.cmbRealEstateStatus</parameter>
			</parameters>
</popupdata>