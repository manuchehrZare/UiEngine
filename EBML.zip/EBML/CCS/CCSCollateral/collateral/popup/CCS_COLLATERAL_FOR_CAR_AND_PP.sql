<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT CC.COLLATERAL_NO,
		       CC.COLLATERAL_TYPE,
		       CC.ORG_CODE,
		       CC.AMOUNT AS COLLATERAL_AMOUNT,
		       CC.CURR_CODE,
		       CC.STATE,
		       CC.COLLATERAL_CREDIT_TYPE,
		       CC.VERIFICATION,
		       CC.OID AS COLLATERAL_OID,
		       CC.ENTRY_DATE,
		       CC.CUST_CODE,
		       P.PLATE,
		       NVL(DECODE(P.STATUS_CODE,'A','Aktif','P','Pasif','L','Log'),'Di�er') STATUS_CODE,
		       P.EGM_REF_NO,
		       P.COVER_PLEDGE_STATUS,
		       P.REGISTER_NO,
		       P.ENGINE_NO,
		       P.CHASSIS_NO,
		       P.EGM_CATEGORY,
		       P.SUSPENSE_REG_NO,
	           CASE P.COVER_PLEDGE_STATUS WHEN '1' THEN '1' 
	             WHEN '6' THEN '1'
	               ELSE '0'
	                 END ZERO
		  FROM CCS.COLLATERAL_COMMON CC,
		       EGMGW.EPLEDGE_COVER_PLEDGE P
		 WHERE CC.STATUS = '1'
		   AND P.STATUS = 1
		   AND CC.COLLATERAL_NO = P.COVER_NO
		   AND ((? is not null and CC.COLLATERAL_TYPE = ?) or (? is null))
		   AND ((? is not null and CC.COLLATERAL_CREDIT_TYPE = ?) or (? is null))
		   AND ((? is not null and CC.COLLATERAL_NO = ?) or (? is null))
		   AND ((? is not null and CC.ORG_CODE = ?) or (? is null))
		   AND ((? is not null and CC.STATE = ?) or (? is null))
		   AND ((? is not null and CC.VERIFICATION = ?) or (? is null))
		   AND ((? is not null and CC.CUST_CODE = ?) or (? is null))
		   AND ((? is not null and P.STATUS_CODE = ?) or (? is null))
		   AND ((? is not null and P.COVER_PLEDGE_STATUS = ?) or (? is null))
		   AND ((? is not null and P.PLATE = ?) or (? is null))
		   AND ((? is not null and P.ENGINE_NO = ?) or (? is null))
		 ORDER BY  CC.COLLATERAL_NO
      </sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.cmbStatusCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.cmbStatusCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.cmbStatusCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.cmbCoverPledgeStatus</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.cmbCoverPledgeStatus</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.cmbCoverPledgeStatus</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.txtPlate</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.txtPlate</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.txtPlate</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.txtEngineNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.txtEngineNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilterEGM.txtEngineNo</parameter>
    </parameters>
</popupdata>
