<popupdata type="sql">
    <sql dataSource="BankingDS">
    SELECT DISTINCT CCR.CUSTOMER_CODE,
           CCR.ORG_CODE,
           CCR.REGISTRY_NO
    FROM CCS.COLLATERAL_CATTLE_REGISTRY CCR
    WHERE CCR.STATUS = '1'
       AND ((? is not null and CCR.REGISTRY_NO= ?) or (? is null))
       AND ((? is not null and CCR.ORG_CODE= ?) or (? is null))
       AND ((? is not null and CCR.CUSTOMER_CODE  = ?) or (? is null))
		 ORDER BY  CCR.REGISTRY_NO
      </sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCattleRegisrtyId</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCattleRegisrtyId</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCattleRegisrtyId</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
    </parameters>
</popupdata>
