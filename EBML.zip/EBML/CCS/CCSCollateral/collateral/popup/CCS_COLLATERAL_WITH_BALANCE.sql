<popupdata type="sql">
    <sql dataSource="BankingDS">
    SELECT distinct COM.COLLATERAL_NO,
                  COM.COLLATERAL_TYPE,
                  COM.ORG_CODE,
                  COM.CURR_CODE,
                  COM.AMOUNT AS COLLATERAL_AMOUNT,
                  COM.CURR_CODE,
                  COM.STATE,
                  COM.COLLATERAL_CREDIT_TYPE,
                  COM.VERIFICATION,
                  COM.OID AS COLLATERAL_OID,
                  COM.ENTRY_DATE,
                  (SELECT DECODE(GG.VERSION, 2, 'YENI_GKS', 1, 'ESKI_GKS')
                     FROM CCS.COLLATERAL_GKS GG
                    WHERE COM.OID = GG.COLLATERAL_OID
                      AND GG.STATUS = '1') AS GKS_VERSION,
                  (SELECT DECODE(CH.VERSION, 2, 'YENI_TTKS', 1, 'ESKI_TTKS')
                     FROM CCS.COLLATERAL_CAR_AND_HOUSE CH
                    WHERE COM.OID = CH.COLLATERAL_OID
                      AND CH.STATUS = '1') AS TTKS_VERSION,
                  CASE COM.COLLATERAL_TYPE
                  	WHEN 'KGF' THEN COM.AMOUNT - NVL(COM.BLOCK_AMOUNT,0)
                  	WHEN 'TKGF' THEN COM.AMOUNT - NVL(COM.BLOCK_AMOUNT,0)
                  	ELSE COM.AMOUNT - (SELECT NVL(SUM (REL.REL_AMOUNT),0) FROM CCS.ALLOTMENT_CB_CRD_COLL_REL REL   WHERE REL.STATUS='1' AND REL.COLLATERAL_OID = COM.OID) 
                  END AS BALANCE
    FROM CCS.COLLATERAL_COMMON COM, ccs.collateral_cust_relation rel
   WHERE COM.STATUS = '1'
     AND ((? IS NOT NULL AND COM.COLLATERAL_TYPE = ?) or (? IS NULL)) 
     AND ((? IS NOT NULL AND COM.COLLATERAL_NO = ?) or (? IS NULL))
     AND ((? IS NOT NULL AND COM.ORG_CODE = ? ) OR (? IS NULL)) 
     AND ((? IS NOT NULL AND COM.STATE = ?) OR (? IS NULL))
     AND ((? IS NOT NULL AND COM.VERIFICATION = ?) OR (? IS NULL))
     AND ((? IS NOT NULL AND rel.CUSTOMER_CODE = ? )  OR (? IS NULL))
     AND ((? IS NOT NULL AND EXISTS(SELECT 1 FROM CCS.COLLATERAL_BAILMENT B WHERE B.STATUS = '1' AND COM.OID = B.COLLATERAL_OID AND B.CUST_CODE = ?)) or (? IS NULL))
     AND ((? IS NOT NULL AND COM.Curr_Code = ?) or (? IS NULL))
     AND ((? IS NOT NULL AND COM.COLLATERAL_CREDIT_TYPE = ?) or (? IS NULL))
     AND rel.status = '1'
     AND REL.COLLATERAL_OID = COM.OID
   ORDER BY COM.COLLATERAL_NO

      </sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtBailCustCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtBailCustCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtBailCustCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCurrCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCurrCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCurrCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
    </parameters>
</popupdata>
