<popupdata type="sql">
    <sql dataSource="BankingDS">
		select  com.COLLATERAL_NO,
				com.AMOUNT,
				com.CURR_CODE,
				com.COLLATERAL_CREDIT_TYPE,
				com.VERIFICATION,
				rel.REAL_ESTATE_LEVEL
		from CCS.COLLATERAL_COMMON com,CCS.COLLATERAL_MORT_R_REL rel
		where rel.REAL_ESTATE_OID = ? AND
		com.state = '1' AND
		rel.status = '1' AND
		com.status = '1' AND
		rel.COLLATERAL_OID = com.OID
		order by com.COLLATERAL_NO 
 	 </sql>
    <parameters>
		<parameter prefix="" suffix="">Page.lblRealEstateOid</parameter>
	</parameters>
</popupdata>