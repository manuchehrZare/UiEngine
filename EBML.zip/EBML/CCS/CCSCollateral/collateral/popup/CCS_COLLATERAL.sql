<popupdata type="sql">
    <sql dataSource="BankingDS">
 SELECT COLLATERAL_NO,
 		COLLATERAL_TYPE, 
 		ORG_CODE, 
 		COLLATERAL_AMOUNT, 
 		CURR_CODE, 
 		STATE, 
 		COLLATERAL_CREDIT_TYPE, 
 		VERIFICATION, 
 		COLLATERAL_OID, 
 		ENTRY_DATE, 
 		CUST_CODE, 
 		GKS_VERSION, 
 		TTKS_VERSION, 
 		SUBSTR(COLLATERAL_EXPLANATION, 0, LENGTH(COLLATERAL_EXPLANATION) - 2) COLLATERAL_EXPLANATION
 FROM
 (SELECT distinct
           COM.COLLATERAL_NO,
           COM.COLLATERAL_TYPE,
           COM.ORG_CODE,
           COM.AMOUNT AS COLLATERAL_AMOUNT,
           COM.CURR_CODE,
           COM.STATE,
           COM.COLLATERAL_CREDIT_TYPE,
           COM.VERIFICATION,
           COM.OID AS COLLATERAL_OID,
           COM.ENTRY_DATE,
           COM.CUST_CODE,
           (SELECT DECODE(GG.VERSION, 2,'YENI_GKS',1,'ESKI_GKS')
              FROM CCS.COLLATERAL_GKS GG
             WHERE COM.OID = GG.COLLATERAL_OID AND GG.STATUS = '1') AS GKS_VERSION,
           (SELECT DECODE(CH.VERSION, 2,'YENI_TTKS',1,'ESKI_TTKS')
              FROM CCS.COLLATERAL_CAR_AND_HOUSE CH
             WHERE COM.OID = CH.COLLATERAL_OID AND CH.STATUS = '1') AS TTKS_VERSION,
           ((case when COM.IS_TEMLIK = '1' then 'Temlik, ' else '' end) ||
           (case when COM.APPROVE = '1' then 'Onayl�, ' else '' end) ||
	   (case when COM.IS_GARAME = '1' then 'Garame, ' else '' end) ||
           (case when COM.SUPPLEMENT = '1' then 'Munzam, ' else '' end) ||
           (case when COM.FOLLOW_UP = '1' then 'Takip, ' else '' end) ||
           (case when COM.IS_KRDY = '1' then 'Krediler y�netimi talebi ile girilmi�  ' else '' end)) as COLLATERAL_EXPLANATION  
       FROM  CCS.COLLATERAL_COMMON COM
       WHERE COM.STATUS='1'
         AND ((? is not null and COM.COLLATERAL_TYPE = ?) or (? is null))
         AND ((? is not null and COM.COLLATERAL_CREDIT_TYPE = ?) or (? is null))
         AND ((? is not null and COM.COLLATERAL_NO = ? )or (? is null)) 
         AND ((? is not null and COM.ORG_CODE = ? )or (? is null)) 
         AND ((? is not null and COM.STATE = ? )or (? is null))
         AND ((? is not null and COM.VERIFICATION = ? )or (? is null))
         AND ((? is not null and COM.CUST_CODE = ? )or (? is null))
   	ORDER BY  COM.COLLATERAL_NO)
      </sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCollateralType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbCreditType</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.txtCollateralNo</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.cmbVerification</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlFilter.hndCustomerCode</parameter>
    </parameters>
</popupdata>
