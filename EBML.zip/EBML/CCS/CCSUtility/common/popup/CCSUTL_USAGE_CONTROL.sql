<popupdata type="service">
<service>CCS_UTL_GET_USG_CNTRL_DEF_AUTHORIZATION</service>
      <parameters>
      <parameter n="PAGE_NAME">Page.pnlQuery.txtPageName</parameter>
      <parameter n="CONTROL_ID">Page.pnlQuery.txtControlID</parameter>
      <parameter n="CONTROL_NAME">Page.pnlQuery.txtControlName</parameter>
      <parameter n="CONTROL_DESCRIPTION">Page.pnlQuery.txtDescription</parameter>
      <parameter n="CONTROL_STATE">Page.pnlQuery.cmbState</parameter>         
      </parameters>
	  
</popupdata>
