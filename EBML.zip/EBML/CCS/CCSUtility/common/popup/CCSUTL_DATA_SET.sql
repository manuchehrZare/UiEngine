<popupdata type="sql">
<sql dataSource="BankingDS">
SELECT D.*
  FROM CCS.UTL_DATA_SET_DEF            D
 WHERE D.STATUS = '1'
   AND (? IS NOT NULL AND D.DATA_SET_ID LIKE ? OR (? IS NULL))
   AND (? IS NOT NULL AND D.DATA_SET_NAME LIKE ? OR (? IS NULL))
   AND (? IS NOT NULL AND D.DATA_SET_TYPE = ? OR (? IS NULL))
   AND (? IS NOT NULL AND D.STATE = ? OR (? IS NULL))
   AND (? IS NOT NULL AND D.STATEMENT LIKE ? OR (? IS NULL))
   AND (? IS NOT NULL AND D.STATEMENT_TYPE = ? OR (? IS NULL))
   AND (? IS NOT NULL AND D.PARAMETER_KEY LIKE ? OR (? IS NULL))
</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.txtDataSetID</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtDataSetID</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtDataSetID</parameter>

    <parameter prefix="" suffix="">Page.pnlQuery.txtDataSetName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtDataSetName</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtDataSetName</parameter>

    <parameter prefix="" suffix="">Page.pnlQuery.cmbDataSetType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbDataSetType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbDataSetType</parameter>

    <parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>

    <parameter prefix="" suffix="">Page.pnlQuery.txtStatement</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtStatement</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtStatement</parameter>

    <parameter prefix="" suffix="">Page.pnlQuery.cmbStatementType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbStatementType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbStatementType</parameter>

    <parameter prefix="" suffix="">Page.pnlQuery.txtStatementKey</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtStatementKey</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtStatementKey</parameter>
    </parameters>
</popupdata>
