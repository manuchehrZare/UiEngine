<popupdata type="sql">
	<sql dataSource="BankingDS">
		SELECT tem.*,nvl(tem.is_kkdf_farm_def,0) as is_kkdf_farm_def ,
	        pro.main_group_code,
	        pro.group_code,
	        pro.product_code,
	       pro.cash_non_cash,
	       pro.product_properties,
		   pro.product_properties_detail,
		   tem.bpm_priority
	  FROM ccs.product_usage_info_templet tem,
	       ccs.product_limit pro,
	       infra.prod_product_new ip,
	       infra.prod_product_group pgrp,
	       infra.prod_product_main_group pmgrp
	 WHERE tem.status = '1'
	   AND ( tem.CHANNEL_BRANCH= '1' OR (tem.CHANNEL_BRANCH is null AND tem.CHANNEL_TABLET is null AND tem.CHANNEL_MOBILE_IBANK is null))
	   AND pro.status = '1'
	   AND tem.state = '1'
	   and ip.status = '1'
       and pgrp.status = '1'
       and pmgrp.status = '1'
	   AND pro.OID = tem.product_oid
	   AND pro.product_code = ip.product_code
	   AND pro.main_group_code = ip.main_group_code
	   AND pro.group_code = ip.group_code
	   AND pgrp.product_group_code = ip.group_code
	   AND pgrp.product_main_group_code = ip.main_group_code
	   AND pmgrp.product_main_group_code = ip.main_group_code
	   AND (? IS NULL OR pmgrp.OID = ?)
	   AND (? IS NULL OR pgrp.OID = ?)
	   AND (? IS NULL OR ip.OID = ?)
	   AND (? IS NULL OR ip.OID = ?)
	   AND (? IS NULL OR tem.OID = ?)
	   AND (? IS NULL OR tem.detail_name like ?)
	   AND (? IS NULL OR tem.usage_type = ?)
	   AND (? IS NULL OR pro.product_properties like ?)
	   AND ( 
	           (? = '1' 
	           		AND tem.OID IN (select t.oid as tem_oid
		                        from CCS.DT_MAIN m,
		                             CCS.DT_MAIN_PRODUCT_LIMIT lim,
		                             ccs.product_usage_info_templet t
		                        where m.OID = lim.DT_MAIN_OID
		                        and lim.status = '1'
		                        and lim.USAGE_TEMPLET_OID is null
		                        and m.OID = ?
		                        and t.product_oid = lim.product_oid
		                        and t.status = '1'
		                        and t.state = '1'

		                        UNION

		                        select lim.usage_templet_oid as tem_oid
		                        from CCS.DT_MAIN m,
		                             CCS.DT_MAIN_PRODUCT_LIMIT lim
		                        where m.OID = lim.DT_MAIN_OID
		                        and lim.status = '1'
		                        and lim.USAGE_TEMPLET_OID is not null
								and m.OID = ?

								UNION

								select t.oid as tem_oid
									from ccs.dt_product_transport alt,
									ccs.product_usage_info_templet t
								where t.product_oid = alt.new_product_oid
								and alt.dt_main_oid = ?
								and alt.transport_state = '1'
								and alt.status = '1')

	           )
	           OR
			  (? = '0'
	            AND pro.OID IN (
		          SELECT apl.product_oid AS pro_oid
		            FROM ccs.allotment_product_limit apl, ccs.allotment allo
		           WHERE apl.allotment_oid = allo.OID
		             AND allo.OID = ?
		             AND apl.approved_lmt > 0
		             AND apl.status = '1'
		          UNION
		          SELECT alt.new_product_oid AS pro_oid
		            FROM ccs.allotment_transport alt
		           WHERE alt.allotment_oid = ?
		             AND alt.transport_state = '1'
		             AND alt.status = '1')
		      )
		      OR
              (? = '0'
               AND pro.OID IN (
                SELECT papl.product_oid AS pro_oid
                FROM   CCS.PRO_ALL_PRODUCT_LIMIT papl, CCS.PROPOSAL prop
                WHERE  papl.proposal_oid = prop.oid
                AND    prop.oid = ?
                AND    papl.approved_limit > 0
                AND    papl.status = '1'
                UNION
                SELECT pat.transport_product_oid as pro_oid
                FROM   CCS.PRO_ALL_TRANSPORT pat
                WHERE  pat.proposal_oid = ?
                AND    pat.transport_state = '1'
                AND    pat.status = '1')
             )
	          or ? is null
      		)
      		AND (? IS NULL or tem.usage_templet_code not like ?)
			AND (? IS NULL or tem.usage_templet_code not like ?)
	</sql>
    <parameters>
    		<parameter prefix="" suffix="">Page.cmbProductMainGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductMainGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductGroupOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductOID</parameter>
        	<parameter prefix="" suffix="">Page.cmbProductOID</parameter>
		    <parameter prefix="" suffix="">Page.lblProductOid</parameter>
        	<parameter prefix="" suffix="">Page.lblProductOid</parameter>
        	<parameter prefix="" suffix="">Page.lblUsageTempletOid</parameter>
        	<parameter prefix="" suffix="">Page.lblUsageTempletOid</parameter>
        	<parameter prefix="" suffix="">Page.lblTempleteName</parameter>
        	<parameter prefix="%" suffix="%">Page.lblTempleteName</parameter>
        	<parameter prefix="" suffix="">Page.cmbUsageType</parameter>
        	<parameter prefix="" suffix="">Page.cmbUsageType</parameter>
        	<parameter prefix="" suffix="">Page.pnlQuery.cmbProductProperties</parameter>
        	<parameter prefix="" suffix="%">Page.pnlQuery.cmbProductProperties</parameter>
			<parameter prefix="" suffix="">Page.txtIsDT</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.txtIsDT</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.txtIsDT</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblAllotmentOid</parameter>
			<parameter prefix="" suffix="">Page.lblHasatKart</parameter>
			<parameter prefix="" suffix="%">Page.lblHasatKart</parameter>
			<parameter prefix="" suffix="">Page.lblSwap</parameter>
			<parameter prefix="" suffix="%">Page.lblSwap</parameter>
    </parameters>
</popupdata>
