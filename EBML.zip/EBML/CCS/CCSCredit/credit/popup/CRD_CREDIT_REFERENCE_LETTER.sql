<popupdata type="sql">
    <sql dataSource="BankingDS">
        SELECT RL.*, DR.DRAWEE_NAME,
		TRIM(CC.name || ' ' || CC.second_name || ' ' || CC.surname || ' ' || CC.title) as CUSTOMER_NAME
        FROM CCS.CRD_CREDIT_REFERENCE_LETTER RL,
		CCS.CRD_UTL_DRAWEE_DEF DR,
		INFRA.CUST_CUST_CUST CC
        WHERE RL.STATUS='1'
        AND DR.STATUS='1'
        AND CC.STATUS='1'
		AND RL.DRAWEE_OID = DR.OID
        AND RL.CUSTOMER_CODE = CC.customer_code (+)
        AND (? IS NOT NULL AND RL.REF_LETTER_NO = ? OR (? IS NULL))
        AND (? IS NOT NULL AND RL.CUSTOMER_CODE = ? OR (? IS NULL))
		AND (? IS NOT NULL AND RL.ORG_CODE = ? OR (? IS NULL))
		AND (? IS NOT NULL AND RL.USER_ORG_CODE = ? OR (? IS NULL))
		AND (? IS NOT NULL AND RL.PRINTING_BRANCH = ? OR (? IS NULL))
		AND (? IS NOT NULL AND RL.CREATE_DATE = ? OR (? IS NULL))
		AND (? IS NOT NULL AND RL.DRAWEE_OID = ? OR (? IS NULL))
		AND (? IS NOT NULL AND RL.IS_FOREIGN_LETTER = ? OR (? IS NULL))
        AND (? IS NOT NULL AND RL.STATE = ? OR (? IS NULL))
        AND (? IS NOT NULL AND RL.IS_E_TENDER = ? OR (? IS NULL))
        AND ((? is not null and RL.STATE IN('1','4') ) OR (? IS NULL))
        AND ((? is not null and RL.EKAP_LETTER_OID IS NOT NULL ) OR (? IS NULL))	
        ORDER BY RL.REF_LETTER_NO
    </sql>
      
    <parameters>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtRefLetterNo</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtRefLetterNo</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtRefLetterNo</parameter>
		
		<parameter prefix="" suffix="">Page.pnlRefLetterSearch.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.hndCustomer</parameter>
           
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbCustBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbCustBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbCustBranch</parameter>
        
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbUserBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbUserBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbUserBranch</parameter>
		
		<parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbPrintBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbPrintBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbPrintBranch</parameter>
		
		<parameter prefix="" suffix="">Page.pnlRefLetterSearch.dtCreate</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.dtCreate</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.dtCreate</parameter>
		
		<parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtDraweeOid</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtDraweeOid</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtDraweeOid</parameter>
		
		<parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbLetterType</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbLetterType</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cmbLetterType</parameter>
        
		<parameter prefix="" suffix="">Page.pnlRefLetterSearch.cbmState</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cbmState</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.cbmState</parameter>	
        
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETender</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETender</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETender</parameter>
        
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETenderState</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETenderState</parameter>    
        
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETenderState</parameter>
        <parameter prefix="" suffix="">Page.pnlRefLetterSearch.txtIsETenderState</parameter>      
  </parameters>
</popupdata>
