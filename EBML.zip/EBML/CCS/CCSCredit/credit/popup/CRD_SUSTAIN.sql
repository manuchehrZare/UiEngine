<popupdata type="sql">
<sql dataSource="BankingDS">
		SELECT  OID,
		CRITERIA_NAME,
		CRITERIA_DESC,
		0 AS CRITERIA_CHECK
FROM CCS.CRD_SUSTAINABLE_CRITERIA csc WHERE STATUS = 1
 ORDER BY TO_NUMBER(csc.CRITERIA_CODE) ASC 
</sql>
    <parameters>
    </parameters>
</popupdata>
