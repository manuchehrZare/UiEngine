<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT PPDEF.NAME, PPDEF.PAYMENT_PLAN_TYPE AS INST_TYPE, PPDEF.CREATE_DATE, US.USER_FIRST_NAME || ' ' || US.USER_LAST_NAME AS CREATOR_NAME, PPDEF.OID
FROM CCS.CRD_CREDIT_PAYMENT_PLAN_DEF PPDEF ,
INFRA.ADMIN_USR_USER US
WHERE PPDEF.STATUS = '1'
AND US.STATUS = '1'
AND US.OID = PPDEF.CREATOR_OID
AND ( ? IS NOT NULL AND PPDEF.OID = ? OR ( ? IS NULL))
AND ( ? IS NOT NULL AND PPDEF.CREDIT_REF_TYPE = ? OR ( ? IS NULL)) 
AND ( ? IS NOT NULL AND PPDEF.NAME LIKE ? OR ( ? IS NULL)) 
AND ( ? IS NOT NULL AND PPDEF.PAYMENT_PLAN_TYPE = ? OR ( ? IS NULL)) 
AND ( ? IS NOT NULL AND PPDEF.CREATE_DATE >= ? OR (? IS NULL)) 
AND ( ? IS NOT NULL AND PPDEF.CREATE_DATE <= ? OR (? IS NULL)) 
 
ORDER BY PPDEF.NAME
  
</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.txtOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtOid</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.cmbSimType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbSimType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbSimType</parameter>
        
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtSimName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtSimName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtSimName</parameter>
        
        <parameter prefix="" suffix="">Page.pnlQuery.cmbInstType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbInstType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbInstType</parameter>
        
        <parameter prefix="" suffix="">Page.pnlQuery.dtCreateDate1</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtCreateDate1</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtCreateDate1</parameter>
        
        <parameter prefix="" suffix="">Page.pnlQuery.dtCreateDate2</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtCreateDate2</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtCreateDate2</parameter>       
  
    </parameters>
</popupdata>
