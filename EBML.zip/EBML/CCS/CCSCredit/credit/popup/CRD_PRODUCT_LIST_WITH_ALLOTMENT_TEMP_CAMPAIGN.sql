<popupdata type="sql">
<sql dataSource="BankingDS">

			
	  select distinct P.OID, 
      IP.PRODUCT_NAME, IP.MAIN_GROUP_CODE,IP.MAIN_GROUP_CODE AS MAIN_GRP_CODE,IP.GROUP_CODE,P.CASH_NON_CASH,P.PRODUCT_CODE
      from ccs.product_limit P,
      ccs.allotment_product_limit AP,
      infra.prod_product_new IP,
      ccs.crd_utl_credit_temp_product TP
      
      where p.status = '1'
      and AP.status  = '1'
      and IP.Status = '1'
      
      and  P.OID = AP.Product_Oid
      and IP.Main_Group_Code = P.Main_Group_Code
      and IP.Group_Code = P.Group_Code 
      and IP.Product_Code = P.Product_Code
      and IP.PRODUCT_ACTIVE = '1'
      
      AND TP.Status = '1'
      
      and AP.ALLOTMENT_OID = ?
      AND P.MAIN_GROUP_CODE LIKE ?
      AND P.GROUP_CODE LIKE ?
      and ap.approved_lmt > 0
      
      and 
      (
      
      (TP.CREDIT_TEMP_OID = ? and P.OID = TP.Product_Oid) --'3by5u7fng0j2z000'
      or ? is null
      )
      and 
      (
      P.OID = ? or ? is null
      )
      
      union
      
      select distinct P.OID, 
      IP.PRODUCT_NAME, IP.MAIN_GROUP_CODE,IP.MAIN_GROUP_CODE AS MAIN_GRP_CODE,IP.GROUP_CODE,P.CASH_NON_CASH,P.PRODUCT_CODE
      from ccs.product_limit P,
      CCS.PRO_ALL_PRODUCT_LIMIT PL,
      infra.prod_product_new IP,
      ccs.crd_utl_credit_temp_product TP
      
      where p.status = '1'
      and PL.status  = '1'
      and IP.Status = '1'
      
      and  P.OID = PL.Product_Oid
      and IP.Main_Group_Code = P.Main_Group_Code
      and IP.Group_Code = P.Group_Code 
      and IP.Product_Code = P.Product_Code
      and IP.PRODUCT_ACTIVE = '1'
      
      AND TP.Status = '1'
      
      and PL.PROPOSAL_OID = ?
      AND P.MAIN_GROUP_CODE LIKE ?
      AND P.GROUP_CODE LIKE ?
      and PL.approved_lmt > 0
      
      and 
      (
      
      (TP.CREDIT_TEMP_OID = ? and P.OID = TP.Product_Oid) --'3by5u7fng0j2z000'
      or ? is null
      )
      and 
      (
      P.OID = ? or ? is null
      )
      
      union
      
      select distinct P.OID, 
      IP.PRODUCT_NAME, IP.MAIN_GROUP_CODE,IP.MAIN_GROUP_CODE AS MAIN_GRP_CODE,IP.GROUP_CODE,P.CASH_NON_CASH,P.PRODUCT_CODE
      from ccs.product_limit P,
      ccs.allotment_transport AT,
      infra.prod_product_new IP,
      ccs.crd_utl_credit_temp_product TP
      
      where p.status = '1'
      and IP.Status = '1'
      
      and IP.Main_Group_Code = P.Main_Group_Code
      and IP.Group_Code = P.Group_Code 
      and IP.Product_Code = P.Product_Code
      and IP.PRODUCT_ACTIVE = '1'
      
      AND TP.Status = '1'
      
      AND AT.STATUS = '1'
      and AT.ALLOTMENT_OID = ?
      and AT.New_Product_Oid = P.OID
      AND AT.TRANSPORT_STATE = '1'
			AND P.MAIN_GROUP_CODE LIKE ?
			AND P.GROUP_CODE LIKE ?
			
			and 
			(
			
			(TP.CREDIT_TEMP_OID = ? and P.OID = TP.Product_Oid) --'3by5u7fng0j2z000'
			or ? is null
			
			)
			and 
			(
			P.OID = ? or ? is null
			)
      
      union
      
      select distinct P.OID, 
      IP.PRODUCT_NAME, IP.MAIN_GROUP_CODE,IP.MAIN_GROUP_CODE AS MAIN_GRP_CODE,IP.GROUP_CODE,P.CASH_NON_CASH,P.PRODUCT_CODE
      from ccs.product_limit P,
      CCS.PRO_ALL_TRANSPORT PT,
      infra.prod_product_new IP,
      ccs.crd_utl_credit_temp_product TP
      
      where p.status = '1'
      and IP.Status = '1'
      
      and IP.Main_Group_Code = P.Main_Group_Code
      and IP.Group_Code = P.Group_Code 
      and IP.Product_Code = P.Product_Code
      and IP.PRODUCT_ACTIVE = '1'
      
      AND TP.Status = '1'
      
      AND PT.STATUS = '1'
      and PT.PROPOSAL_OID = ?
      and PT.Transport_Product_Oid = P.OID
      AND PT.TRANSPORT_STATE = '1'
			AND P.MAIN_GROUP_CODE LIKE ?
			AND P.GROUP_CODE LIKE ?
			
			and 
			(
			
			(TP.CREDIT_TEMP_OID = ? and P.OID = TP.Product_Oid) --'3by5u7fng0j2z000'
			or ? is null
			
			)
			and 
			(
			P.OID = ? or ? is null
			)

</sql>
    <parameters>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtAllotmentOid</parameter>    	
		<parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductGroupOID</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>

		<parameter prefix="" suffix="">Product.pnlCriteria.txtAllotmentOid</parameter>    	
		<parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductGroupOID</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
		
		<parameter prefix="" suffix="">Product.pnlCriteria.txtAllotmentOid</parameter>    	
		<parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductGroupOID</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
		
		<parameter prefix="" suffix="">Product.pnlCriteria.txtAllotmentOid</parameter>    	
		<parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductMainGroupOID</parameter>
        <parameter prefix="" suffix="%">Product.pnlCriteria.cmbProductGroupOID</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtCreditTempOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
		<parameter prefix="" suffix="">Product.pnlCriteria.txtProductOid</parameter>
    </parameters>
</popupdata>
