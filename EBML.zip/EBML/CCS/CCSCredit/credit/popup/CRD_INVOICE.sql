<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT I.OID, I.CUSTOMER_CODE, I.AMOUNT, I.CURRENCY_CODE, I.INVOICE_DATE, I.INVOICE_TYPE,
       I.INVOICE_REF_NO, I.INVOICE_DOC_NO, I.INVOICE_SUBJECT, I.FIRM_TITLE, I.DESCRIPTION,
       U.CREDIT_NO
  FROM CCS.CRD_INVOICE            I,
       CCS.CRD_INVOICE_CREDIT_REL R,
       CCS.CRD_CREDIT_USAGE       U
 WHERE I.STATUS = '1'
   AND I.STATE = '2'
   AND U.STATUS(+) = '1'
   AND U.RECORD_TYPE(+) = 'U'
   AND U.STATE(+) IN ('2','5')
   AND R.STATUS(+) = '1' 
   AND R.STATE(+) = '2'
   AND R.INVOICE_OID(+) = I.OID
   AND U.OID(+) = R.USAGE_OID
   AND (? IS NOT NULL AND I.CUSTOMER_CODE = ? OR (? IS NULL))
   AND (? IS NOT NULL AND U.CREDIT_NO = ? OR (? IS NULL))
   AND (? IS NOT NULL AND I.INVOICE_REF_NO = ? OR (? IS NULL))
   AND (? IS NOT NULL AND I.INVOICE_DOC_NO = ? OR (? IS NULL))
   AND (I.AMOUNT = to_number(?,'9999999999999999999999.99') OR (to_number(?,'9999999999999999999999.99') = 0))
   AND (? IS NOT NULL AND I.CURRENCY_CODE = ? OR (? IS NULL))
   AND (? IS NOT NULL AND I.INVOICE_DATE >= ? OR (? IS NULL))
   AND (? IS NOT NULL AND I.INVOICE_DATE <= ? OR (? IS NULL))
   AND (? IS NOT NULL AND I.INVOICE_TYPE = ? OR (? IS NULL))
   AND (? IS NOT NULL AND I.FIRM_TITLE LIKE ? OR (? IS NULL))
 ORDER BY I.INVOICE_DATE DESC
  
</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndCustomer</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.hndKTF</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndKTF</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.hndKTF</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.txtInvoiceRefNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtInvoiceRefNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtInvoiceRefNo</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.txtInvoiceDocNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtInvoiceDocNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtInvoiceDocNo</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.currAmount</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.currAmount</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.cmbCurrCode</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbCurrCode</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbCurrCode</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.dtInvoiceDateStart</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtInvoiceDateStart</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtInvoiceDateStart</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.dtInvoiceDateEnd</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtInvoiceDateEnd</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.dtInvoiceDateEnd</parameter>

		<parameter prefix="" suffix="">Page.pnlQuery.cmbInvoiceType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbInvoiceType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbInvoiceType</parameter>

		<parameter prefix="%" suffix="%">Page.pnlQuery.txtFirmTitle</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtFirmTitle</parameter>
        <parameter prefix="%" suffix="%">Page.pnlQuery.txtFirmTitle</parameter>

    </parameters>
</popupdata>
