<popupdata type="service">
<service>CCS_CRD_CREDIT_USAGE_LIST_FOR_POPUP</service>
	    <parameters>
			<parameter n="PROCESS_ID">Page.pnlFilter.txtProcessId</parameter>
	        <parameter n="RECORD_TYPE">Page.pnlFilter.txtRecordType</parameter>
	        <parameter n="RECORD_TYPE_2">Page.pnlFilter.txtRecordType2</parameter>
	        <parameter n="IS_PRINCIPLE">Page.pnlFilter.txtIsPrincible</parameter>
			<parameter n="CREDIT_OID">Page.pnlFilter.txtCreditOid</parameter>
	        <parameter n="CREDIT_NO">Page.pnlFilter.txtCreditNo</parameter>
	        <parameter n="CUSTOMER_CODE">Page.pnlFilter.hndCustomerCode</parameter>
			<parameter n="IS_REPRINT">Page.pnlFilter.txtTeminatMektubuYenidenBasim</parameter>
	        <parameter n="CREATOR_ORG_CODE">Page.pnlFilter.cbBranchCode</parameter>
	        <parameter n="PRODUCT_OID">Page.pnlFilter.txtProductOid</parameter>
			<parameter n="PRODUCT_TYPE">Page.pnlFilter.cbProductType</parameter>
	        <parameter n="MIN_AMOUNT">Page.pnlFilter.txtMinAmount</parameter>
	        <parameter n="MAX_AMOUNT">Page.pnlFilter.txtMaxAmount</parameter>
			<parameter n="USAGE_ACCOUNT_OID">Page.pnlFilter.txtAccountOid</parameter>
	        <parameter n="STATE">Page.pnlFilter.cbCreditState</parameter>
	        <parameter n="PRODUCT_PROPERTIES">Page.pnlFilter.txtProductProperties</parameter>
			<parameter n="PRODUCT_PROPERTIES_2">Page.pnlFilter.txtProductProperties2</parameter>
	        <parameter n="PRODUCT_PROPERTIES_3">Page.pnlFilter.txtProductProperties3</parameter>
	        <parameter n="PRODUCT_PROPERTIES_4">Page.pnlFilter.txtProductProperties4</parameter>
	        <parameter n="PRODUCT_PROPERTIES_5">Page.pnlFilter.txtProductProperties5</parameter>
	        <parameter n="PRODUCT_PROPERTIES_6">Page.pnlFilter.txtProductProperties6</parameter>
			<parameter n="YENIDEN_YAPILANDIRMA">Page.pnlFilter.txtYenidenYapilandirma</parameter>
	        <parameter n="CUSTOMER_ORG_CODE">Page.pnlFilter.cbCustomerBranchCode</parameter>
	        <parameter n="IS_INJUNCTION">Page.pnlFilter.txtInjunction</parameter>
			<parameter n="DRAWEE_OID">Page.pnlFilter.txtDrawee</parameter>
	        <parameter n="USAGE_TYPE">Page.pnlFilter.cmbUsageType</parameter>
	        <parameter n="USAGE_PATTERN_OID">Page.pnlFilter.txtTemplateName</parameter>
	        <parameter n="IS_KKDF_FARM_DEF">Page.pnlFilter.txtIsKKDFFarmDef</parameter>
	        <parameter n="SCOPE_CODE_NOT_NULL">Page.pnlFilter.txtScopeCodeNotNull</parameter>
	        <parameter n="IS_REBUILD">Page.pnlFilter.txtIsRebuild</parameter>
	        <parameter n="PRICING_MODEL">Page.pnlFilter.txtPricingModel</parameter>
	        <parameter n="IS_E_TENDER">Page.pnlFilter.txtIsETender</parameter>
	    </parameters>
</popupdata>
