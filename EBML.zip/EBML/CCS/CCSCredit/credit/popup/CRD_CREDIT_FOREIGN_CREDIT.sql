<popupdata type="sql">
<sql dataSource="BankingDS">
 SELECT 
  CRD.OID,
  CRD.STATUS,
  CRD.LASTUPDATED,
  CRD.CREDIT_NO,
  CRD.DESCRIPTION,
  CRD.FTI_LC_OID,
  CRD.AMOUNT,
  CRD.CURRENCY_CODE,
  CRD.STATE,
  
  EXT.STATUS,
  EXT.CREDIT_TYPE,
  EXT.CREDIT_SUB_TYPE,
  EXT.END_DATE,
  EXT.AGGREMENT_DATE,
  EXT.PRICING_MATURITY_DATE,
  EXT.CREDIT_REASON,
  EXT.CREDITOR_BANK_CODE,
  EXT.ACC_BANK_CODE,
  EXT.INTEREST_SPREAD,
  EXT.INDEX_OID,
  EXT.ACC_NO,
  EXT.PRE_CUST_CODE,
  EXT.INDEX_DAY,
  EXT.USAGE_OID,
  EXT.MATURITY_DATE,
  EXT.INTEREST_TYPE,
  EXT.INTEREST_RATE,
  EXT.BIC_CODE,
  EXT.DEBIT_AUTHORIZATION,
  EXT.ACC_BANK_ACC_NO,
  EXT.CASH_PAID_INTEREST,
  EXT.CASH_CREDIT_AMOUNT,
  EXT.PAYBACK_DETAIL,
  EXT.INDEX_DETAIL
  
  FROM CCS.CRD_CREDIT_USAGE CRD,
  CCS.CRD_CREDIT_USAGE_EXT_DETAIL EXT
  
  WHERE CRD.STATUS = '1'
  AND EXT.STATUS = '1'
  
  AND CRD.OID = EXT.USAGE_OID
  AND CRD.RECORD_TYPE = 'E' 
  
	AND ((? is not null and CRD.CREDIT_NO LIKE ?) or (? IS NULL) )
	AND ((? is not null and EXT.CREDIT_TYPE LIKE ?) or (? IS NULL) )
	AND ((? is not null and EXT.CREDIT_SUB_TYPE LIKE ?) or (? IS NULL) )
	AND ((? is not null and CRD.STATE LIKE ?) or (? IS NULL))
	AND ((? is not null and CRD.STATE IN('0','2') ) or (? is not null and CRD.STATE = '1') or (? IS NULL))
	
</sql>
    <parameters>
    	<parameter prefix="" suffix="">Page.txtCreditNo</parameter>
    	<parameter prefix="" suffix="">Page.txtCreditNo</parameter>
    	<parameter prefix="" suffix="">Page.txtCreditNo</parameter>
    	
    	<parameter prefix="" suffix="">Page.cmbCreditType</parameter>
    	<parameter prefix="" suffix="">Page.cmbCreditType</parameter>
    	<parameter prefix="" suffix="">Page.cmbCreditType</parameter>
    	
    	<parameter prefix="" suffix="">Page.cmbCreditSubType</parameter>
    	<parameter prefix="" suffix="">Page.cmbCreditSubType</parameter>
    	<parameter prefix="" suffix="">Page.cmbCreditSubType</parameter>
    	
    	<parameter prefix="" suffix="">Page.cmbCreditState</parameter>
    	<parameter prefix="" suffix="">Page.cmbCreditState</parameter>
    	<parameter prefix="" suffix="">Page.cmbCreditState</parameter>
    	
    	<parameter prefix="" suffix="">Page.txtForeignCreditSreen</parameter>
    	<parameter prefix="" suffix="">Page.txtChangeScreen</parameter>
    	<parameter prefix="" suffix="">Page.txtForeignCreditSreen</parameter>
    	
    </parameters>
</popupdata>
