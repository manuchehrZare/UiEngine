<popupdata type="service">
<service>CCS_CRD_KGF_GET_DOCUMENTS</service>
	    <parameters>
			<parameter n="INVOICE_CURRENCY_TYPE">Page.pnlQuery.cmbDefaultCurrencyType</parameter>
	        <parameter n="DYS_DOCUMENT_TYPE">Page.pnlQuery.txtDys</parameter>
			<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomer</parameter>
	        <parameter n="CUSTOMER_TITLE">Page.pnlQuery.txtCustomer</parameter>
			<parameter n="MIN_DOCUMENT_AMOUNT">Page.pnlQuery.txtAmountMin</parameter>
	        <parameter n="MAX_DOCUMENT_AMOUNT">Page.pnlQuery.txtAmountMax</parameter>
	        <parameter n="USAGE_OID">Page.pnlQuery.lblUsageOid</parameter>
	    </parameters>
</popupdata>