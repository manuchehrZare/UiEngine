<popupdata type="sql">
  <sql dataSource="BankingDS">
    
    SELECT TP.BRANCH_CODE, TP.SERIES, TP.INITIAL_NO, TP.FINAL_NO,TP.DIST_DATE, TP.PRINTED_FORM_SERIES_OID, TP.OID
    FROM CCS.CRD_UTL_PRINTED_FORM_DISTRIBUT TP
    WHERE TP.STATUS = '1'
    AND ( (? is not null and TP.BRANCH_CODE = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.SERIES = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.INITIAL_NO = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.FINAL_NO = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.DIST_DATE = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.PRINTED_FORM_SERIES_OID = ?  and TP.STATUS = '1') or (? IS NULL) )

  
  </sql>
  
    <parameters>
      <parameter prefix="" suffix="">Page.cmbOrgCode</parameter>
      <parameter prefix="" suffix="">Page.cmbOrgCode</parameter>
      <parameter prefix="" suffix="">Page.cmbOrgCode</parameter>
      
      <parameter prefix="" suffix="">Page.hndPrintedFormRecord</parameter>
      <parameter prefix="" suffix="">Page.hndPrintedFormRecord</parameter>
      <parameter prefix="" suffix="">Page.hndPrintedFormRecord</parameter>
      
      <parameter prefix="" suffix="">Page.txtSeriesInitial</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesInitial</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesInitial</parameter>
      
      <parameter prefix="" suffix="">Page.txtSeriesFinal</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesFinal</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesFinal</parameter>
      
      <parameter prefix="" suffix="">Page.dtRecordDate</parameter>
      <parameter prefix="" suffix="">Page.dtRecordDate</parameter>
      <parameter prefix="" suffix="">Page.dtRecordDate</parameter>					
      
      <parameter prefix="" suffix="">Page.cmbFormState</parameter>
      <parameter prefix="" suffix="">Page.cmbFormState</parameter>
      <parameter prefix="" suffix="">Page.cmbFormState</parameter>
    </parameters>
</popupdata>