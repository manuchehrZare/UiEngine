<popupdata type="sql">
    <sql dataSource="BankingDS">       

    select f.oid, f.form_code, f.form_name, f.state, f.form_version, f.form_explanation
    from ccs.crd_utl_form f
    where f.status = '1' 
    and ( (? is not null and f.form_code = ?) or (? is null) )
    and ( (? is not null and f.state = ?) or (? is null) )
    and ( ? is null or lower(upper(f.form_version)) like (lower(upper(?))) )
    and ( ? is null or lower(upper(f.form_name)) like (lower(upper(?))) )
    and ( ? is null or lower(upper(f.form_explanation)) like (lower(upper(?))) )  
    order by f.form_code

    </sql>
    <parameters>

      <parameter prefix="" suffix="">Page.pnlQuery.txtFormTemplateCode</parameter>
      <parameter prefix="" suffix="">Page.pnlQuery.txtFormTemplateCode</parameter>
      <parameter prefix="" suffix="">Page.pnlQuery.txtFormTemplateCode</parameter>
      
      <parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
      <parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
      <parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
      
      <parameter prefix="%" suffix="%">Page.pnlQuery.txtVersion</parameter>
      <parameter prefix="%" suffix="%">Page.pnlQuery.txtVersion</parameter> 
               
      <parameter prefix="%" suffix="%">Page.pnlQuery.txtFormTemplateName</parameter>
      <parameter prefix="%" suffix="%">Page.pnlQuery.txtFormTemplateName</parameter>       
            
      <parameter prefix="%" suffix="%">Page.pnlQuery.txpExplanation</parameter>
      <parameter prefix="%" suffix="%">Page.pnlQuery.txpExplanation</parameter> 
       
    </parameters>
</popupdata>
