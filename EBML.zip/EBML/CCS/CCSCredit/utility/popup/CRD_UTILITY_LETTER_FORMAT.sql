<popupdata type="sql">
    <sql dataSource="BankingDS">       

		select DISTINCT LF.OID,LF.FORMAT_NAME,LF.APPROVE_TYPE,
				LF.IS_ALL_BRANCH,
				--LF.DETAIL,
				--LF.SIGN,
				LF.STATE,
				LF.LETTER_TYPE,LF.ORGANIZATION_CODE,LF.LETTER_NO
		from CCS.CRD_UTL_LTR_FORMAT_DEF LF,
		CCS.CRD_UTL_LTR_FORMAT_PROD_DEF P,
		CCS.CRD_UTL_LTR_FORMAT_CUST_DEF C,
		CCS.CRD_UTL_LTR_FORMAT_BRAN_DEF B
		where LF.STATUS = '1' 
		and LF.OID = P.LETTER_FORMAT_OID (+) 
		and LF.OID = C.LETTER_FORMAT_OID (+) 
		and LF.OID = B.LETTER_FORMAT_OID (+)
		and ( ( (? is not null and B.BRANCH_CODE = ? and B.STATUS = '1') or (? IS NULL) ) or (LF.IS_ALL_BRANCH = '1') )
		and ( (? is not null and C.CUST_CODE = ? and C.STATUS = '1') or (? IS NULL)or (LF.IS_ALL_CUST = '1') )        
		and ( (? is not null and P.PRODUCT_OID = ?  and P.STATUS = '1') or (? IS NULL) )
		and ( (? is not null and LF.STATE = ?) or (? IS NULL) )
		and ( ? IS NULL OR LOWER(UPPER(LF.FORMAT_NAME)) LIKE ( LOWER(UPPER(?)) || '%')) 
		and ( (? is not null and LF.OID = ?) or (? IS NULL) )
		and ( (? is not null and LF.LETTER_TYPE = ? ) or (? IS NULL) )
		and ( (? is not null and LF.LETTER_NO = ? ) or (? IS NULL) )
		and ( ((? IS NULL or ? = '0') AND (LF.ETM IS NULL OR LF.ETM <> 1)) or (? is not null and LF.ETM = ?) )
		order by LF.FORMAT_NAME

    </sql>
    <parameters>

			<parameter prefix="" suffix="">Page.pnlTop.cmbBranch</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbBranch</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbBranch</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.hndCust</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.hndCust</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.hndCust</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.txtProductOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtProductOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtProductOid</parameter>

			<parameter prefix="" suffix="">Page.pnlTop.cmbLetterState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbLetterState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbLetterState</parameter>

			<parameter prefix="%" suffix="%">Page.pnlTop.txtFormatName</parameter>
			<parameter prefix="%" suffix="%">Page.pnlTop.txtFormatName</parameter>	

			<parameter prefix="" suffix="">Page.pnlTop.txtLetterOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtLetterOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtLetterOid</parameter>
			
			<parameter prefix="" suffix="">Page.pnlTop.cmbLetterType</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbLetterType</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbLetterType</parameter>
			
			<parameter prefix="" suffix="">Page.pnlTop.txtLetterNo</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtLetterNo</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtLetterNo</parameter>
			
			<parameter prefix="" suffix="">Page.pnlTop.txtEtm</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtEtm</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtEtm</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtEtm</parameter>
    </parameters>
</popupdata>