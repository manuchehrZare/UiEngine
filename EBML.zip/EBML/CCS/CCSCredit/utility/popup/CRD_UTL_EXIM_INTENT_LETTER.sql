<popupdata type="sql">
  <sql dataSource="BankingDS">
    
    SELECT *
    FROM CCS.CRD_UTL_EXIM_INTENT_LETTER LT
    WHERE LT.STATUS='1'
      AND (? IS NULL OR LT.LETTER_NO = ?)
      AND (? IS NULL OR LT.CUSTOMER_CODE = ?)
      AND (? IS NULL OR LT.PRODUCT_OID = ?)
      AND (? IS NULL OR LT.LETTER_STATE = ?)
      AND (? IS NULL OR LT.ORG_CODE = ?)
      AND (? IS NULL OR LT.OID = ?)

	  
  </sql>
  
    <parameters>
      <parameter prefix="" suffix="">Page.txtLetterNo</parameter>					
      <parameter prefix="" suffix="">Page.txtLetterNo</parameter>
      <parameter prefix="" suffix="">Page.hndCustomer</parameter>					
      <parameter prefix="" suffix="">Page.hndCustomer</parameter>
      <parameter prefix="" suffix="">Page.cmbProduct</parameter>
      <parameter prefix="" suffix="">Page.cmbProduct</parameter>
      <parameter prefix="" suffix="">Page.cmbLetterState</parameter>
      <parameter prefix="" suffix="">Page.cmbLetterState</parameter>
      <parameter prefix="" suffix="">Page.cmbBranch</parameter>
      <parameter prefix="" suffix="">Page.cmbBranch</parameter>
      <parameter prefix="" suffix="">Page.txtOid</parameter>
      <parameter prefix="" suffix="">Page.txtOid</parameter>
    </parameters>
</popupdata>
