<popupdata type="sql">
    <sql dataSource="BankingDS">
        SELECT MG.GROUP_NAME AS MAIN_GROUP, SG.GROUP_NAME AS SUB_GROUP, DR.DRAWEE_NAME AS NAME, DR.OID AS OID, MG.OID AS MAIN_OID, SG.OID AS SUB_OID, DR.APPROVE_TYPE AS APPROVE_TYPE, DR.DRAWEE_ADDRESS AS DRAWEE_ADDRESS,DR.DRAWEE_TAX_NO AS TAX_NO , DR.DRAWEE_TC_ID AS TC_ID
        FROM CCS.CRD_UTL_DRAWEE_DEF DR,
        CCS.CRD_UTL_DRAWEE_GROUP_DEF SG,
        CCS.CRD_UTL_DRAWEE_GROUP_DEF MG
        WHERE SG.OID=DR.GROUP_OID
        AND MG.OID=SG.PARENT_OID
        AND DR.STATUS='1'
        AND SG.STATUS='1'
        AND MG.STATUS='1'
        AND (? IS NOT NULL AND MG.OID = ? OR (? IS NULL))
        AND (? IS NOT NULL AND SG.OID = ? OR (? IS NULL))
        AND (? IS NOT NULL AND DR.DRAWEE_NAME LIKE ? OR (? IS NULL)) 
		AND (? IS NOT NULL AND DR.OID = ? OR (? IS NULL))
		AND (? IS NOT NULL AND DR.DRAWEE_TAX_NO = ? OR (? IS NULL))
		AND (? IS NOT NULL AND DR.DRAWEE_TC_ID = ? OR (? IS NULL))
        ORDER BY MG.GROUP_NAME, SG.GROUP_NAME, DR.DRAWEE_NAME
    </sql>
      
    <parameters>
        <parameter prefix="" suffix="">Page.pnlGroup.txtMainGroupOid</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtMainGroupOid</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtMainGroupOid</parameter>
           
        <parameter prefix="" suffix="">Page.pnlGroup.txtSubGroupOid</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtSubGroupOid</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtSubGroupOid</parameter>
        
        <parameter prefix="%" suffix="%">Page.pnlGroup.txtDraweeName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlGroup.txtDraweeName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlGroup.txtDraweeName</parameter>
        
        <parameter prefix="" suffix="">Page.pnlGroup.txtDraweeOid</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtDraweeOid</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtDraweeOid</parameter>
        
		<parameter prefix="" suffix="">Page.pnlGroup.txtVKN</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtVKN</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtVKN</parameter>
        
        <parameter prefix="" suffix="">Page.pnlGroup.txtTC</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtTC</parameter>
        <parameter prefix="" suffix="">Page.pnlGroup.txtTC</parameter> 
  </parameters>
</popupdata>
