<popupdata type="service">
	<service>EBID_FIND_BID_BY_RECORD_YEAR_AND_NUMBER</service>
	    <parameters>
	        <parameter n="BID_RECORD_YEAR">Page.txtTenderYear</parameter>
	        <parameter n="BID_RECORD_NO">Page.txtTenderNo</parameter>
	    </parameters>
</popupdata>