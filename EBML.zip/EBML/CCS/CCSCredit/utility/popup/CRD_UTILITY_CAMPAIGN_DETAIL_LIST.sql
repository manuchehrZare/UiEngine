<popupdata type="sql">

    <sql dataSource="BankingDS">       
    
        SELECT         
            CP.USAGE_TYPE AS DETAIL_USAGE_TYPE,
            PUIT.DETAIL_NAME AS DETAIL_TEMP_NAME, -- PRODUCT_TEMPLATE_NAME
            CP.PRODUCT_TEMPLATE_OID AS DETAIL_TEMP_OID, --PRODUCT_TEMPLATE_OID  
            IP.PRODUCT_NAME AS DETAIL_PROD_NAME, -- PRODUCT_NAME
            CP.PRODUCT_OID AS DETAIL_PROD_OID,  -- PRODUCT_OID
            CP.CMP_DETAIL_NAME AS DETAIL_NAME, -- CAMPAIGN_DETAIL_NAME
            CP.OID AS DETAIL_OID, -- CAMPAIGN_DETAIL_OID
            CP.REF_OID AS CAMPAIGN_OID, --CAMPAIGN_OID
            C.CAMPAIGN_STATE AS CMP_STATE, 
            C.CAMPAIGN_END_DATE AS CMP_END,
            C.CAMPAIGN_START_DATE AS CMP_START,
            C.CAMPAIGN_NAME AS CMP_NAME, 
            C.CAMPAIGN_NO AS CMP_NO, 
            C.OID AS CMP_OID,
			C.FORM_CODE AS FORM_CODE,
			(select f.oid
                from CCS.CRD_UTL_FORM F
                where F.FORM_CODE = C.FORM_CODE
                     AND F.STATUS = '1'
                     AND F.STATE = '2'
            ) as FORM_OID,
			P.MAIN_GROUP_CODE,
            P.GROUP_CODE
        FROM CCS.CRD_UTL_CAMPAIGN C, 
        CCS.CRD_UTL_CAMPAIGN_PROD CP, 
        INFRA.PROD_PRODUCT_NEW IP,
        CCS.PRODUCT_LIMIT P,
        CCS.PRODUCT_USAGE_INFO_TEMPLET PUIT
		
                
        WHERE CP.REF_TYPE = '0'
        AND  C.STATUS = '1'
        AND  CP.STATUS = '1'        
        
        AND P.STATUS = '1'
        AND IP.STATUS = '1' 
        AND IP.PRODUCT_CODE = P.PRODUCT_CODE
        AND IP.PRODUCT_ACTIVE = '1'
        AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
        AND IP.GROUP_CODE = P.GROUP_CODE
                
        AND C.OID (+)= CP.REF_OID
        AND P.OID (+)= CP.PRODUCT_OID
        AND PUIT.OID (+)= CP.PRODUCT_TEMPLATE_OID
		
		AND ( PUIT.CHANNEL_BRANCH= '1' OR (PUIT.CHANNEL_BRANCH is null AND PUIT.CHANNEL_TABLET is null AND PUIT.CHANNEL_MOBILE_IBANK is null))
                   
        AND ( ? IS NOT NULL AND C.CAMPAIGN_NO = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.CAMPAIGN_NAME LIKE ? OR ( ? IS NULL))        
        AND ( ? IS NOT NULL AND C.CAMPAIGN_STATE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND CP.CMP_DETAIL_NAME LIKE ? OR ( ? IS NULL))        
        AND ( ? IS NOT NULL AND CP.PRODUCT_TEMPLATE_OID = ? OR ( ? IS NULL))        
        AND ( ? IS NOT NULL AND CP.USAGE_TYPE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND CP.DETAIL_STATE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND CP.OID = ? OR ( ? IS NULL))
        AND (( ? IS NOT NULL AND C.CAMPAIGN_START_DATE <= ? AND C.CAMPAIGN_END_DATE >= ?) OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND P.MAIN_GROUP_CODE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND P.GROUP_CODE = ? OR ( ? IS NULL))
        
    
    </sql>
    
    <parameters>    
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.txtCampaignNo</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.txtCampaignNo</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.txtCampaignNo</parameter>
        
        <parameter prefix="%" suffix="%">Page.pnlCriteria.pnlTop.txtCampaignName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlCriteria.pnlTop.txtCampaignName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlCriteria.pnlTop.txtCampaignName</parameter>
                
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.cmbCampaignState</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.cmbCampaignState</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.cmbCampaignState</parameter>
        
        <parameter prefix="%" suffix="%">Page.pnlCriteria.pnlDetail.txtDetailName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlCriteria.pnlDetail.txtDetailName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlCriteria.pnlDetail.txtDetailName</parameter>
                        
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.txtProdTempOid</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.txtProdTempOid</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.txtProdTempOid</parameter>
        
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.cmbUsageType</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.cmbUsageType</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.cmbUsageType</parameter>
        
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.cmbDetailState</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.cmbDetailState</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlDetail.cmbDetailState</parameter>
        
        <parameter prefix="" suffix="">Page.txtCampaignDetailOid</parameter>
        <parameter prefix="" suffix="">Page.txtCampaignDetailOid</parameter>
        <parameter prefix="" suffix="">Page.txtCampaignDetailOid</parameter>
        
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.dtCampaignValidDate</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.dtCampaignValidDate</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.dtCampaignValidDate</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.pnlTop.dtCampaignValidDate</parameter>   
        
        <parameter prefix="" suffix="">Page.lblProductMainGroupCode</parameter>
        <parameter prefix="" suffix="">Page.lblProductMainGroupCode</parameter>
        <parameter prefix="" suffix="">Page.lblProductMainGroupCode</parameter>

        <parameter prefix="" suffix="">Page.lblProductGroupCode</parameter>
        <parameter prefix="" suffix="">Page.lblProductGroupCode</parameter>
        <parameter prefix="" suffix="">Page.lblProductGroupCode</parameter>
        	
    </parameters>
    
</popupdata>







