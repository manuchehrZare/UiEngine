<popupdata type="sql">

    <sql dataSource="BankingDS">       
    
        SELECT         
            C.OID, 
            C.CAMPAIGN_NO, 
            C.CAMPAIGN_NAME, 
            C.RESOURCE_TYPE, 
            C.USAGE_OID, 
            C.CAMPAIGN_START_DATE, 
            C.CAMPAIGN_END_DATE, 
            C.CAMPAIGN_STATE, 
            C.IS_MAIN_CUSTOMER, 
            C.MAIN_CUSTOMER_CODE, 
            U.CREDIT_NO AS USAGE_NO,
            U.DESCRIPTION AS USAGE_DESCRIPTION, 
            CUST.DECLERATION_NAME_TITLE AS MAIN_CUSTOMER_NAME            
        FROM CCS.CRD_UTL_CAMPAIGN C, 
        CCS.CRD_CREDIT_USAGE U, 
        INFRA.CUST_CUST_CUST CUST
        WHERE C.STATUS = '1'        
        AND U.OID (+)= C.USAGE_OID 
        AND CUST.CUSTOMER_CODE (+)= C.MAIN_CUSTOMER_CODE 
        AND ( ? IS NOT NULL AND C.CAMPAIGN_NO = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.CAMPAIGN_NAME LIKE ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.RESOURCE_TYPE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.USAGE_OID = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.CAMPAIGN_STATE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.IS_MAIN_CUSTOMER = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.MAIN_CUSTOMER_CODE = ? OR ( ? IS NULL))
        AND ( ? IS NOT NULL AND C.CAMPAIGN_START_DATE >= ? OR ( ? IS NULL) OR (C.CAMPAIGN_START_DATE IS NULL))
        AND ( ? IS NOT NULL AND C.CAMPAIGN_END_DATE <= ? OR ( ? IS NULL) OR (C.CAMPAIGN_END_DATE IS NULL))
    
    </sql>
    
    <parameters>    
        <parameter prefix="" suffix="">Page.pnlTop.txtCampaignNo</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.txtCampaignNo</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.txtCampaignNo</parameter>
        
        <parameter prefix="%" suffix="%">Page.pnlTop.txtCampaignName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlTop.txtCampaignName</parameter>
        <parameter prefix="%" suffix="%">Page.pnlTop.txtCampaignName</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.cmbSourceType</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.cmbSourceType</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.cmbSourceType</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.txtUsageOid</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.txtUsageOid</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.txtUsageOid</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.cmbCampaignState</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.cmbCampaignState</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.cmbCampaignState</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.cmbMainBusiness</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.cmbMainBusiness</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.cmbMainBusiness</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.hndCustCode</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.hndCustCode</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.hndCustCode</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.dtCampaignStartDate</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.dtCampaignStartDate</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.dtCampaignStartDate</parameter>
        
        <parameter prefix="" suffix="">Page.pnlTop.dtCampaignEndDate</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.dtCampaignEndDate</parameter>
        <parameter prefix="" suffix="">Page.pnlTop.dtCampaignEndDate</parameter>
        
        
        
        
        	
    </parameters>
    
</popupdata>







