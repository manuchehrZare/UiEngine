<popupdata type="sql">
  <sql dataSource="BankingDS">
    
    SELECT TD.*, DD.DRAWEE_NAME,
	decode (IS_CUSTOMER,'1',TRIM(CC.name || ' ' || CC.second_name || ' ' || CC.surname || ' ' || CC.title)),
	decode (IS_CUSTOMER,'1',TRIM(CC.name || ' ' || CC.second_name || ' ' || CC.surname || ' ' || CC.title),
                        '0','') as CUSTOMER_NAME 
    FROM CCS.CRD_UTL_TENDER_DEF TD,
	CCS.CRD_UTL_DRAWEE_DEF DD,
	INFRA.CUST_CUST_CUST CC
    WHERE TD.STATUS='1' 
	AND DD.STATUS = '1'
	AND TD.DRAWEE_OID = DD.OID
	and TD.CUSTOMER_CODE = CC.customer_code (+)
    AND (? IS NOT NULL AND TD.TENDER_NO = ? OR (? IS NULL))
    AND (? IS NOT NULL AND TD.STATE = ? OR (? IS NULL))
    AND (? IS NOT NULL AND TD.DRAWEE_OID = ? OR (? IS NULL))
	AND (? IS NOT NULL AND TD.TENDER_DATE >= ? OR (? IS NULL))
	AND (? IS NOT NULL AND TD.TENDER_DATE <= ? OR (? IS NULL))
	
  </sql>
  
    <parameters>
	
		<parameter prefix="" suffix="">Page.pnlQuery.txtTenderNo</parameter>	
		<parameter prefix="" suffix="">Page.pnlQuery.txtTenderNo</parameter>	
		<parameter prefix="" suffix="">Page.pnlQuery.txtTenderNo</parameter>	
		
		<parameter prefix="" suffix="">Page.pnlQuery.cmbTenderState</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbTenderState</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbTenderState</parameter>	

		<parameter prefix="" suffix="">Page.pnlQuery.txtDraweeOid</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtDraweeOid</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtDraweeOid</parameter>
		
		<parameter prefix="" suffix="">Page.pnlQuery.dtStart</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.dtStart</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.dtStart</parameter>
		
		<parameter prefix="" suffix="">Page.pnlQuery.dtEnd</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.dtEnd</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.dtEnd</parameter>
		
    </parameters>
</popupdata>