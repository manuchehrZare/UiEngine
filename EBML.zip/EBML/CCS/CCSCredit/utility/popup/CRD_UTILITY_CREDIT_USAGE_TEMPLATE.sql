<popupdata type="sql">
  <sql dataSource="BankingDS">
    SELECT CTD.OID, CTD.TEMPLATE_NAME, CTD.PRODUCT_TYPE  
    FROM CCS.CRD_UTL_CREDIT_TEMPLATE_DEF CTD
	  WHERE ((CTD.STATUS='1'
      AND ( ? IS NOT NULL AND CTD.PRODUCT_TYPE = ? OR ( ? IS NULL))
      AND ( ? IS NULL OR CTD.TEMPLATE_NAME LIKE ( ? || '%'))
      AND (CTD.OID IN 
        (
          SELECT P.CREDIT_TEMP_OID
          FROM CCS.CRD_UTL_CREDIT_TEMP_PRODUCT P
          WHERE ( ? IS NOT NULL AND P.PRODUCT_OID = ? OR ( ? IS NULL))
        )
        
      )) AND ? is null) OR (? is not null and ? = CTD.OID)
    ORDER BY CTD.TEMPLATE_NAME
  	  	
  </sql>
  
    <parameters>    
        <parameter prefix="" suffix="">Page.pnlQuery.cmbProductType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbProductType</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.cmbProductType</parameter>
        
        <parameter prefix="" suffix="">Page.pnlQuery.txtTemplateName</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtTemplateName</parameter>
        
        <parameter prefix="" suffix="">Page.pnlQuery.prmProductOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.prmProductOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.prmProductOid</parameter>
        
        <parameter prefix="" suffix="">Page.pnlQuery.prmTemplateOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.prmTemplateOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.prmTemplateOid</parameter>    
    </parameters>
    
    
</popupdata>
