<popupdata type="sql">
  <sql dataSource="BankingDS">
    
    SELECT TP.ORG_CODE, TP.SERIES, TP.INITIAL_NO, TP.FINAL_NO,TP.RECORD_DATE, TP.OID
    FROM CCS.CRD_UTL_PRINTED_FORM TP
    WHERE TP.STATUS = '1'
    AND ( (? is not null and TP.ORG_CODE = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.SERIES = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.INITIAL_NO = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.FINAL_NO = ?  and TP.STATUS = '1') or (? IS NULL) )
    and ( (? is not null and TP.RECORD_DATE = ?  and TP.STATUS = '1') or (? IS NULL) )

  
  </sql>
  
    <parameters>
      <parameter prefix="" suffix="">Page.cmbOrgCode</parameter>
      <parameter prefix="" suffix="">Page.cmbOrgCode</parameter>
      <parameter prefix="" suffix="">Page.cmbOrgCode</parameter>
      
      <parameter prefix="" suffix="">Page.txtSeries</parameter>
      <parameter prefix="" suffix="">Page.txtSeries</parameter>
      <parameter prefix="" suffix="">Page.txtSeries</parameter>
      
      <parameter prefix="" suffix="">Page.txtSeriesInitial</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesInitial</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesInitial</parameter>
      
      <parameter prefix="" suffix="">Page.txtSeriesFinal</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesFinal</parameter>
      <parameter prefix="" suffix="">Page.txtSeriesFinal</parameter>
      
      <parameter prefix="" suffix="">Page.dtRecordDate</parameter>
      <parameter prefix="" suffix="">Page.dtRecordDate</parameter>
      <parameter prefix="" suffix="">Page.dtRecordDate</parameter>					
    </parameters>
</popupdata>