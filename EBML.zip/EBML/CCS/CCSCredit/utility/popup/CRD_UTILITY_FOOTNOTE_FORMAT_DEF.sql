<popupdata type="sql">
    <sql dataSource="BankingDS">       

		select  FN.OID,FN.FOOTNOTE_NAME,
				FN.DETAIL,FN.IS_AUTO_EXIT,
				FN.DAY,FN.IS_LETTER_EXIT,
				FN.STATE, FN.IS_LIMIT,
				FN.APPROVE_TYPE
		from CCS.CRD_UTL_FOOTNOTE_FORMAT_DEF FN
		where FN.STATUS = '1'        
		and ( ? IS NULL OR LOWER(UPPER(FN.FOOTNOTE_NAME)) LIKE ( LOWER(UPPER(?)) || '%')) 
		and ( (? is not null and FN.OID = ?) or (? IS NULL) )
		and ( (? is not null and FN.STATE = ?) or (? IS NULL) )
		order by FN.FOOTNOTE_NAME

    </sql>
    <parameters>
	
			<parameter prefix="" suffix="">Page.pnlTop.txtFootNoteName</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFootNoteName</parameter>
			
			<parameter prefix="" suffix="">Page.pnlTop.txtFootNoteOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFootNoteOid</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.txtFootNoteOid</parameter>
			
			<parameter prefix="" suffix="">Page.pnlTop.cmbState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbState</parameter>
			<parameter prefix="" suffix="">Page.pnlTop.cmbState</parameter>

    </parameters>
</popupdata>