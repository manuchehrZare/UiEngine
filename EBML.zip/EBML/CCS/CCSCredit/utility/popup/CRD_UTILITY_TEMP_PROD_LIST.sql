<popupdata type="sql">
  <sql dataSource="BankingDS">
    
    SELECT P.OID AS PRODUCT_OID, P.CASH_NON_CASH AS CASH_NON_CASH,IP.PRODUCT_NAME AS PRODUCT_NAME
    FROM CCS.CRD_UTL_CREDIT_TEMP_PRODUCT TP,
    CCS.PRODUCT_LIMIT P,
    INFRA.PROD_PRODUCT_NEW IP
    WHERE TP.STATUS='1'
    AND P.STATUS = '1'
    AND IP.STATUS = '1' 
    AND IP.PRODUCT_CODE = P.PRODUCT_CODE
    AND IP.PRODUCT_ACTIVE = '1'
    AND IP.MAIN_GROUP_CODE = P.MAIN_GROUP_CODE
    AND IP.GROUP_CODE = P.GROUP_CODE
    AND P.OID = TP.PRODUCT_OID
    AND TP.CREDIT_TEMP_OID = ?

	  
  </sql>
  
    <parameters>
      <parameter prefix="" suffix="">Page.txtTemplateOid</parameter>					
    </parameters>
</popupdata>
