<popupdata type="service">
<service>CCS_CRD_UTL_EXIM_INTENT_LETTER_LIST</service>
	    <parameters>
	        <parameter n="ORG_CODE">Page.pnlCriteria.cbBranchCode</parameter>
	        <parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomer</parameter>
	  		<parameter n="KKB_LETTER_NO">Page.pnlCriteria.txtKkbLetterNo</parameter>	
	  		<parameter n="IS_ETM">Page.pnlCriteria.txtETM</parameter>	   
	  		<parameter n="EXIM_LETTER_NO">Page.pnlCriteria.txtEximIntentLetterNo</parameter>
			<parameter n="IS_KKB_LETTER_FULL">Page.pnlCriteria.txtKKBLetterFull</parameter>  
	    </parameters>
</popupdata>
