<popupdata type="service">
<service>CCS_CRD_CORP_CODE_VALIDATE</service>
	    <parameters>
	    </parameters>
</popupdata>
