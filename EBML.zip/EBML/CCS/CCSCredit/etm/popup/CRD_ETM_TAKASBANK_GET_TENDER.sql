<popupdata type="service">
<service>CCS_CRD_ETM_TAKASBANK_GET_TENDER</service>
	    <parameters>
	    	<parameter n="TENDER_REGISTRATION_NO_YEAR">Page.txtTenderRegistrationNoYear</parameter>
		<parameter n="TENDER_REGISTRATION_NO_NUMBER">Page.txtTenderRegistrationNo</parameter>
		<parameter n="TENDER_EXECUTIVE_REF_NO">Page.txtTenderExecutiveRefNo</parameter>
	    </parameters>
</popupdata>
