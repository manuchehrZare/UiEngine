<popupdata type="service">
<service>CCS_CRD_MANAGEMENT_CODE_VALIDATE</service>
	    <parameters>
	    	<parameter n="CORP_CODE">Page.hndCorporateCode</parameter>
		<parameter n="MANAGEMENT_CODE">Page.txtManagementCode</parameter>
	    </parameters>
</popupdata>
