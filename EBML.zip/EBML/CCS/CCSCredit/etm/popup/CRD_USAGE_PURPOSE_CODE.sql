<popupdata type="service">
<service>CCS_CRD_INTENDED_USE_VALIDATE</service>
	    <parameters>
		<parameter n="CORP_CODE">Page.hndCorporateCode</parameter>
		<parameter n="INTENDED_USE_CODE">Page.txtPurposeCode</parameter>
	    </parameters>
</popupdata>
