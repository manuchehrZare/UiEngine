<popupdata type="sql">
    <sql dataSource="BankingDS">
        SELECT TRL.*,
		TRIM(CC.name || ' ' || CC.second_name || ' ' || CC.surname || ' ' || CC.title) as CUSTOMER_NAME
        FROM CCS.CRD_CREDIT_TKS_REF_LETTER TRL,
		INFRA.CUST_CUST_CUST CC
        WHERE TRL.STATUS='1'
        AND CC.STATUS='1'
        AND TRL.CUSTOMER_CODE = CC.customer_code (+)
        AND (? IS NOT NULL AND TRL.REF_LETTER_NO = ? OR (? IS NULL))
        AND (? IS NOT NULL AND TRL.CUSTOMER_CODE = ? OR (? IS NULL))
	AND (? IS NOT NULL AND TRL.CUSTOMER_ORG_CODE = ? OR (? IS NULL))
        AND (? IS NOT NULL AND TRL.CREATE_DATE = ? OR (? IS NULL))
	AND (? IS NOT NULL AND TRL.STATE = ? OR (? IS NULL))
	AND (? IS NOT NULL AND TRL.TKS_LETTER_NO = ? OR (? IS NULL))
        ORDER BY TRL.REF_LETTER_NO
    </sql>
      
    <parameters>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.txtRefLetterNo</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.txtRefLetterNo</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.txtRefLetterNo</parameter>
		
	<parameter prefix="" suffix="">Page.pnlInquiryCriterias.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.hndCustomer</parameter>
           
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.cmbCustBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.cmbCustBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.cmbCustBranch</parameter>
        
	<parameter prefix="" suffix="">Page.pnlInquiryCriterias.dtCreate</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.dtCreate</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.dtCreate</parameter>
        
	<parameter prefix="" suffix="">Page.pnlInquiryCriterias.cbmState</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.cbmState</parameter>    
	<parameter prefix="" suffix="">Page.pnlInquiryCriterias.cbmState</parameter>
	
	<parameter prefix="" suffix="">Page.pnlInquiryCriterias.txtTksRefNo</parameter>
        <parameter prefix="" suffix="">Page.pnlInquiryCriterias.txtTksRefNo</parameter>    
	<parameter prefix="" suffix="">Page.pnlInquiryCriterias.txtTksRefNo</parameter>  
  </parameters>
</popupdata>
