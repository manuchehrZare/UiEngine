<popupdata type="service">
<service>CCS_CRD_ETM_LETTER_LIST_FOR_POPUP</service>
	    <parameters>
			<parameter n="OID">Page.pnlCriteria.txtOid</parameter>
	        <parameter n="ORG_CODE">Page.pnlCriteria.cbBranchCode</parameter>
	        <parameter n="CUSTOMER_CODE">Page.pnlCriteria.hndCustomer</parameter>
	        <parameter n="DRAWEE_OID">Page.pnlCriteria.txtDraweeOid</parameter>
			<parameter n="PRIVATE_PUBLIC">Page.pnlCriteria.cmbLetterType</parameter>
	        <parameter n="STATE">Page.pnlCriteria.cbState</parameter>
	        <parameter n="KTF_NO">Page.pnlCriteria.hndKTFNo</parameter>
	        <parameter n="USAGE_NO">Page.pnlCriteria.hndUsageNo</parameter>
			<parameter n="LETTER_NO">Page.pnlCriteria.txtLetterNo</parameter>
			<parameter n="KKB_LETTER_NO">Page.pnlCriteria.txtKkbLetterNo</parameter>
	        <parameter n="USAGE_TEMPLATE_OID">Page.pnlCriteria.txtUsageTemplateOid</parameter>
	    </parameters>
</popupdata>
