<popupdata type="service">
<service>CCS_CRD_ETM_FORMAT_LIST</service>
	    <parameters>
			<parameter n="KKB_FORMAT_ID">Page.pnlCriteria.txtFormatNo</parameter>
	        <parameter n="DRAWEE_OID">Page.pnlCriteria.txtDraweeOid</parameter>
	        <parameter n="FIRST_DATE">Page.pnlCriteria.dtStartDate</parameter>
			<parameter n="LAST_DATE">Page.pnlCriteria.dtEndDate</parameter>
	        <parameter n="KKB_FORMAT_TYPE">Page.pnlCriteria.cmbFormatType</parameter>
	        <parameter n="MATURITY_TYPE">Page.pnlCriteria.cmbMaturityType</parameter>
			<parameter n="CURRENCY_TYPE">Page.pnlCriteria.cmbCurrencyType</parameter>
			<parameter n="START_DATE">Page.pnlCriteria.dtStartDate</parameter>
			<parameter n="END_DATE">Page.pnlCriteria.dtEndDate</parameter>
			<parameter n="FROM_DB">Page.pnlCriteria.chkFromDBOnly</parameter>
			<parameter n="USER_FILE_NO">Page.pnlCriteria.lblUserName</parameter>
			<parameter n="DRAWEE_TC">Page.pnlCriteria.lblDraweeTc</parameter>
			<parameter n="DRAWEE_VKN">Page.pnlCriteria.lblDraweeVKN</parameter>
			<parameter n="LETTER_FORMAT_OID">Page.pnlCriteria.lblBankFormatOid</parameter>
			<parameter n="KKB_STATE">Page.pnlCriteria.KKB_STATE</parameter>
			<parameter n="DRAWEE_NAME">Page.pnlCriteria.hndDrawee</parameter>
			<parameter n="LETTER_FORMAT_TYPE">Page.pnlCriteria.txtLetterFormatType</parameter>
			<parameter n="STATE">Page.pnlCriteria.cmbBankState</parameter>
	    </parameters>
</popupdata>
