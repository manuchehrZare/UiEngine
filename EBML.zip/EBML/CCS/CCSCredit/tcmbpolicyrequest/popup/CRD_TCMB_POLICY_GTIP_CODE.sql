<popupdata type="sql">
<sql dataSource="BankingDS">


SELECT G.*,
       SUBSTR(G.GTIP_NAME, 0, 30) AS GTIP_NAME_30_CHAR
  FROM CCS.CRD_TCMB_GTIP_CODE_LIST G
 WHERE G.STATUS = 1
   AND G.GTIP_TYPE IN ('M', 'Y')
   AND G.RECORD_DATE = (SELECT MAX(RECORD_DATE)
                               FROM CCS.CRD_TCMB_GTIP_CODE_LIST G2
                              WHERE G2.STATUS = 1
                                AND G.GTIP_TYPE = G2.GTIP_TYPE)
   AND ((? IS NULL) OR G.GTIP_TYPE = ?)
   AND ((? IS NULL) OR G.GTIP_CODE = ?)
   AND ((? IS NULL) OR G.GTIP_NAME LIKE '%' || ? || '%')


</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.cmbGoodType</parameter>
        <parameter prefix="" suffix="">Page.cmbGoodType</parameter>

        <parameter prefix="" suffix="">Page.txtGtipCode</parameter>
        <parameter prefix="" suffix="">Page.txtGtipCode</parameter>

        <parameter prefix="" suffix="">Page.txtOtherGtipName</parameter>
        <parameter prefix="" suffix="">Page.txtOtherGtipName</parameter>

    </parameters>
</popupdata>
