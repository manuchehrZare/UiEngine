<popupdata type="sql">
<sql dataSource="BankingDS">


SELECT *
  FROM CCS.CRD_TCMB_POLICY P
 WHERE P.STATUS = 1
   AND ((? IS NULL) OR P.CUSTOMER_CODE = ?)
   AND ((? IS NULL) OR P.START_DATE = ?)
   AND ((? IS NULL) OR P.POLICY_STATUS = ?)
   AND ((? IS NULL) OR P.POLICY_TYPE = ?)
   AND ((? IS NULL) OR P.REQUEST_NO = ?)


</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.hndCustomer</parameter>

        <parameter prefix="" suffix="">Page.dtStartDate</parameter>
        <parameter prefix="" suffix="">Page.dtStartDate</parameter>

        <parameter prefix="" suffix="">Page.cmbPolicyStatus</parameter>
        <parameter prefix="" suffix="">Page.cmbPolicyStatus</parameter>

        <parameter prefix="" suffix="">Page.cmbPolicyType</parameter>
        <parameter prefix="" suffix="">Page.cmbPolicyType</parameter>

        <parameter prefix="" suffix="">Page.txtRequestNo</parameter>
        <parameter prefix="" suffix="">Page.txtRequestNo</parameter>

    </parameters>
</popupdata>
