<popupdata type="sql">
<sql dataSource="BankingDS">


SELECT C.*, P.POLICY_TYPE
  FROM CCS.CRD_TCMB_CONTRACT C, 
       CCS.CRD_TCMB_POLICY P
 WHERE P.STATUS = 1
   AND C.STATUS = 1
   AND C.POLICY_OID = P.OID
   AND ((? IS NULL) OR C.ORG_CODE = ?)
   AND ((? IS NULL) OR C.CUSTOMER_CODE = ?)
   AND ((? IS NULL) OR C.STATE = ?)
   AND ((? IS NULL) OR P.POLICY_TYPE = ?)
   AND ((? IS NULL) OR C.CONTRACT_REFERENCE_NO = ?)
   AND ((? IS NULL) OR C.OID = ?)


</sql>
    <parameters>
    	<parameter prefix="" suffix="">Page.pnlCriteria.cmbTcmbBranch</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbTcmbBranch</parameter>
    
        <parameter prefix="" suffix="">Page.pnlCriteria.hndCustomer</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.hndCustomer</parameter>

        <parameter prefix="" suffix="">Page.pnlCriteria.cmbContractState</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbContractState</parameter>

        <parameter prefix="" suffix="">Page.pnlCriteria.cmbPolicyType</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbPolicyType</parameter>

        <parameter prefix="" suffix="">Page.pnlCriteria.txtContractReferenceNo</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.txtContractReferenceNo</parameter>
        
        <parameter prefix="" suffix="">Page.pnlCriteria.txtOid</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.txtOid</parameter>

    </parameters>
</popupdata>
