<popupdata type="sql">
<sql dataSource="BankingDS">

SELECT  P.PARAMETER_KEY AS SCOPE_CODE,
        P.PAR_VALUE AS SCOPE_DESC
  FROM CCS.UTILITY_COMMON_PARAM_DEF P
 WHERE P.STATUS = 1
   AND P.PARAMETER_TYPE = 'CRD_RISK_DECLARATION_SCOPE_CODE'
   AND (? IS NULL OR P.DESCRIPTION LIKE '%' || ? || '%')
   AND (? IS NULL OR P.PARAMETER_KEY = ?)

 ORDER BY SCOPE_CODE

</sql>

 <parameters>
 	<parameter prefix="" suffix="">Page.lblPageCode</parameter>
 	<parameter prefix="" suffix="">Page.lblPageCode</parameter>
	<parameter prefix="" suffix="">Page.txtScopeCode</parameter>
	<parameter prefix="" suffix="">Page.txtScopeCode</parameter>
 </parameters>

</popupdata>