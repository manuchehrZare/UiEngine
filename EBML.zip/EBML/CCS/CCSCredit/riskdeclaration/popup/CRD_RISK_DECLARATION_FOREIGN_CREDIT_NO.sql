<popupdata type="sql">
<sql dataSource="BankingDS">


SELECT FC.CUSTOMER_CODE,
       FC.CREDIT_NO,
       FC.SCOPE_CODE,
       FC.CURRENCY_CODE,
       FC.CREDIT_AMOUNT
  FROM CCS.CRD_RISK_DECLARTN_FOREIGN_CRDT FC
 WHERE FC.STATUS = 1
   AND FC.STATE = 1
   AND (? IS NULL OR FC.CUSTOMER_CODE = ?)
   AND (? IS NULL OR FC.CREDIT_NO = ?)


</sql>

 <parameters>
 	<parameter prefix="" suffix="">Page.hndCustomer</parameter>
 	<parameter prefix="" suffix="">Page.hndCustomer</parameter>
	<parameter prefix="" suffix="">Page.txtCreditNo</parameter>
	<parameter prefix="" suffix="">Page.txtCreditNo</parameter>
 </parameters>

</popupdata>