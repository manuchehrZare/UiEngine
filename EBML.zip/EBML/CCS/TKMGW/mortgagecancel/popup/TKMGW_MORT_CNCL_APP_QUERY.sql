<popupdata type="service">
	<service>TKM_LIST_MORT_APPLICATION_FOR_POPUP</service>
	    <parameters>
	        <parameter n="CUSTOMER_CODE">pgApplicationSearch.hndCustomerNo</parameter>
	        <parameter n="APPLICATION_NO">pgApplicationSearch.txtApplicationNo</parameter>
        </parameters>
</popupdata>