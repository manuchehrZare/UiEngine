<popupdata type="service">
	<service>FINMAN_NETTING_PROCESS_LIST</service>
    	<parameters>			
	        <parameter n="DEAL_REF_ID">Page.pnlFilter.txtDealRef</parameter>
		<parameter n="COUNTER_PARTY_OID">Page.pnlFilter.cmbCounterParty</parameter>
   	        <parameter n="NETTING_DATE">Page.pnlFilter.dtValueDate</parameter>
	 </parameters>
</popupdata>