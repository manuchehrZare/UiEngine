<popupdata type="service">
	<service>FINMAN_OPTION_PROCESS_LIST</service>
    	<parameters>			
	        <parameter n="TRANSACTION_DECONT_NUMBER">Page.pnlFilter.txtDecont</parameter>
	        <parameter n="DEAL_REF_ID">Page.pnlFilter.txtDealRef</parameter>
	        <parameter n="PORTFOLIO_OID">Page.pnlFilter.cmbPortfolio</parameter>
   	        <parameter n="COUNTER_PARTY_OID">Page.pnlFilter.cmbCounterParty</parameter>
   	        <parameter n="BUY_CURRENCY_OID">Page.pnlFilter.cmbBuy</parameter>
   	        <parameter n="SELL_CURRENCY_OID">Page.pnlFilter.cmbSell</parameter>
			<parameter n="OPERATION_DATE">Page.pnlFilter.dtDate</parameter>
   	        <parameter n="VALUE_DATE">Page.pnlFilter.dtValueDate</parameter>	        	                	        	        	        	        
	    </parameters>
</popupdata>