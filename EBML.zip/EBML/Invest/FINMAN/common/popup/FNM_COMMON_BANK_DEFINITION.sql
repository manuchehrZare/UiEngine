<popupdata type="service">
	<service>FINMAN_COMMON_LIST_BANK_DEFINITION</service>
    	<parameters>			
	        <parameter n="BIC_CODE">Page.pnlCriteria.txtBicCode</parameter>
	        <parameter n="BANK">Page.pnlCriteria.txtBankName</parameter>
	        <parameter n="COUNTER">Page.pnlCriteria.counter</parameter>
	        <parameter n="CORRES">Page.pnlCriteria.corres</parameter>
	        <parameter n="CURRENCY_OID">Page.pnlCriteria.cmbCurr</parameter>
	        <parameter n="TYPE">Page.pnlCriteria.lblProcessType</parameter>
	        <parameter n="CORRES_TYPE">Page.pnlCriteria.lblCorresType</parameter>
			<parameter n="TREASURE_CORRES">Page.pnlCriteria.cbTreasureCorres</parameter>
         	  </parameters>
</popupdata>