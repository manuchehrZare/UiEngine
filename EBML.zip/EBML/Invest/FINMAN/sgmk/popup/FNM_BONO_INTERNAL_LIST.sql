<popupdata type="service">
	<service>FINMAN_BOND_INTERNAL_PROCESS_LIST</service>
    	<parameters>			
			<parameter n="OPERATION_DATE">Page.pnlFilter.dtDate</parameter>
   	        <parameter n="VALUE_DATE">Page.pnlFilter.dtValueDate</parameter>
	    </parameters>
</popupdata>