<popupdata type="service">
	<service>FINMAN_BONO_LIST_BANK_DEFINITION</service>
    	<parameters>			
	        <parameter n="BIC_CODE">Page.pnlCriteria.txtBicCode</parameter>
	        <parameter n="BANK">Page.pnlCriteria.txtBankName</parameter>
         </parameters>
</popupdata>