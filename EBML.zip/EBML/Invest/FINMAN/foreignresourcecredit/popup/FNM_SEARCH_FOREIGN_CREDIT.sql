<popupdata type="service">
	<service>FINMAN_FOREIGN_CREDIT_LIST</service>
    	<parameters>			
	        <parameter n="CREDIT_REFERENCE_ID">Page.pnlFilter.txtCreditReferenceID</parameter>
	        <parameter n="CREDIT_GIVER_COUNTRY_CODE">Page.pnlFilter.cmbCreditGiverCountry</parameter>
	        <parameter n="INSTITUTION_TYPE">Page.pnlFilter.cmbInstitutionType</parameter>
	        <parameter n="CURRENCY_CODE">Page.pnlFilter.cmbCurrencyCode</parameter>
	        <parameter n="CREDIT_DEF_DATE">Page.pnlFilter.dtOperationDate</parameter>
	        <parameter n="CREDIT_VALUE_DATE">Page.pnlFilter.dtCreditValueDate</parameter>
	        <parameter n="MATURITY_DATE">Page.pnlFilter.dtMaturityDate</parameter>
	    </parameters>
</popupdata>