<popupdata type="service">
	<service>FINMAN_LIST_SWAPTION_OPERATIONS</service>
    	<parameters>			
	        <parameter n=DEAL_REFERENCE_ID>Page.pnlFilter.txtDealRef</parameter>
	        <parameter n="PORTFOLIO_OID">Page.pnlFilter.cmbPortfolio</parameter>
   	        <parameter n="DEAL_TYPE">Page.pnlFilter.cmbDealType</parameter>
   	        <parameter n="COUNTER_PARTY_OID">Page.pnlFilter.cmbCounterParty</parameter>
   	        <parameter n="FIRST_CURRENCY_OID">Page.pnlFilter.cmbBuy</parameter>
   	        <parameter n="SECOND_CURRENCY_OID">Page.pnlFilter.cmbSell</parameter>
			<parameter n="OPERATION_DATE">Page.pnlFilter.dtDate</parameter>
   	        <parameter n="PREMIUM_VALUE_DATE">Page.pnlFilter.dtValueDate</parameter>	        	                	        	        	        	        
			<parameter n="OPTION_DUE_DATE">Page.pnlFilter.dtDueDate</parameter>	
	    </parameters>
</popupdata>