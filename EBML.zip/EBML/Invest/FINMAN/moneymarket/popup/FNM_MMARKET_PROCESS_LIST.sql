<popupdata type="service">
	<service>FINMAN_MMARKET_PROCESS_LIST</service>
    	<parameters>			
			<parameter n="MMARKET_TYPE">Page.pnlFilter.cmbMMarketType</parameter>	        	                	        	        	        	        
	        <parameter n="TRANSACTION_DECONT_NUMBER">Page.pnlFilter.txtDecont</parameter>
	        <parameter n="DEAL_REF_ID">Page.pnlFilter.txtDealRef</parameter>
	        <parameter n="PORTFOLIO_OID">Page.pnlFilter.cmbPortfolio</parameter>
   	        <parameter n="COUNTER_PARTY_BIC_CODE">Page.pnlFilter.txtBICCode</parameter>
   	        <parameter n="CURRENCY_OID">Page.pnlFilter.cmbCurrency</parameter>
			<parameter n="OPERATION_DATE">Page.pnlFilter.dtDate</parameter>
   	        <parameter n="VALUE_DATE">Page.pnlFilter.dtValueDate</parameter>
			<parameter n="DUE_DATE">Page.pnlFilter.dtDueDate</parameter>	        	                	        	        	        	        
			<parameter n="OPERATION_STATUS">Page.pnlFilter.lblOperationStatus</parameter>	        	                	        	        	        	        
	    </parameters>
</popupdata>