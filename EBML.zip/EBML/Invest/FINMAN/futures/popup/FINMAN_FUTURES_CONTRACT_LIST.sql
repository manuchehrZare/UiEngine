<popupdata type="service">
	<service>FINMAN_LIST_FUTURES_CONTRACT_DEF</service>
	    <parameters>
	        <parameter n="CONTRACT_NAME">Page.pnlGeneralInfo.txtContractName</parameter>
		<parameter n="CONTRACT_CLASS">Page.pnlGeneralInfo.txtContractClass</parameter>
	        <parameter n="CONTRACT_CODE">Page.pnlGeneralInfo.txtContractCode</parameter>
	        <parameter n="MATURITY_DATE">Page.pnlGeneralInfo.dtMaturityDate</parameter>
	        <parameter n="MATURITY_DATE_OPERATOR">Page.pnlGeneralInfo.cmbMaturityDateOperator</parameter>
	        <parameter n="CURRENCY_CODE">Page.pnlGeneralInfo.cmbCurrCode</parameter>
	        <parameter n="EXECUTE_QUERY">Page.txtExecuteQuery</parameter>
	        <parameter n="CHECK_PDATE">Page.txtCheckPDate</parameter>
	    </parameters>
</popupdata>