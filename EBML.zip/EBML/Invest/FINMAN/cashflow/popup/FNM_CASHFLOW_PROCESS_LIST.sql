<popupdata type="service">
	<service>FINMAN_CASHFLOW_PROCESS_LIST</service>
    	<parameters>			
	        <parameter n="DEAL_REF_ID">Page.pnlFilter.txtDealRef</parameter>
   	        <parameter n="COUNTER_PARTY_BIC_CODE">Page.pnlFilter.hndCounterParty</parameter>
   	        <parameter n="CURRENCY_OID">Page.pnlFilter.cmbCurrency</parameter>
			<parameter n="OPERATION_DATE">Page.pnlFilter.dtDate</parameter>
   	        <parameter n="VALUE_DATE">Page.pnlFilter.dtValueDate</parameter>
			<parameter n="OPERATION_STATUS">Page.pnlFilter.lblOperationStatus</parameter>	        	                	        	        	        	        
			<parameter n="CASHFLOW_TYPE_STR">Page.pnlFilter.lblCashFlowTypes</parameter>	        	                	        	        	        	        
	    </parameters>
</popupdata>