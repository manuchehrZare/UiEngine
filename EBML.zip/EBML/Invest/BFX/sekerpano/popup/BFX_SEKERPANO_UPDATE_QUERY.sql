<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT *
    	FROM
    		BFX.SEKER_PANO_MESSAGE_DEF MESSAGE
		WHERE
			MESSAGE.STATUS=1
			and (to_date(message.end_date||' '||message.end_time,'yyyymmdd hh24miss')- sysdate) >= 0  					    
    </sql>
	<parameters>
	</parameters>
</popupdata>