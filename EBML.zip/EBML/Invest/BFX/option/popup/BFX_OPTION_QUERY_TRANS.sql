<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT 
  OP.OID as OID,
  OP.STATUS as STATUS,
  OP.LASTUPDATED as LASTUPDATED,
  OP.REFERENCE_ID as REFERENCE_ID,
  OP.TRANSACTION_OID as TRANSACTION_OID ,
  OP.TRANSACTION_DATE as TRANSACTION_DATE,
  OP.RESERVATION_NO as RESERVATION_NO,
  OP.STATE as STATE,
  OP.PROCESS_ID as PROCESS_ID,
  OP.TRANSACTION_TYPE as TRANSACTION_TYPE,
  OP.CUSTOMER_NO as CUSTOMER_NO,
  OP.CUST_BRANCH_CODE as CUST_BRANCH_CODE,
  OP.OP_BRANCH_CODE as OP_BRANCH_CODE,
  OP.BRANCH_USER as BRANCH_USER,
  OP.USAGE_PURPOSE as USAGE_PURPOSE,
  OP.EXTERNAL_TICKET_ID as EXTERNAL_TICKET_ID,
  OP.MAIN_OPTION_TYPE as MAIN_OPTION_TYPE,
  OP.OPTION_TYPE as OPTION_TYPE ,
  OP.TL_ACC_NO as TL_ACC_NO,
  OP.DTH_ACC_NO as DTH_ACC_NO,
  OP.PREMIUM_ACC_NO as PREMIUM_ACC_NO ,
  OP.TL_ACC_OID as TL_ACC_OID,
  OP.DTH_ACC_OID as DTH_ACC_OID,
  OP.PREMIUM_ACC_OID as PREMIUM_ACC_OID,
  OP.BUY_CURRENCY_CODE as BUY_CURRENCY_CODE,
  OP.BUY_CURRENCY_TYPE as BUY_CURRENCY_TYPE,
  OP.SELL_CURRENCY_CODE as SELL_CURRENCY_CODE,
  OP.SELL_CURRENCY_TYPE as SELL_CURRENCY_TYPE,
  OP.OPTION_CURRENCY_CODE as OPTION_CURRENCY_CODE,
  OP.OPTION_AMOUNT as OPTION_AMOUNT,
  OP.OPTION_NETTING_AMOUNT as OPTION_NETTING_AMOUNT,
  OP.PRACTICE_RATE as PRACTICE_RATE,
  OP.SPOT_RATE as SPOT_RATE,
  OP.TREASURY_PREMIUM_AMOUNT as TREASURY_PREMIUM_AMOUNT,
  OP.CUSTOMER_PREMIUM_AMOUNT as CUSTOMER_PREMIUM_AMOUNT,
  OP.PREMIUM_AMOUNT as PREMIUM_AMOUNT,
  OP.PREMIUM_CURRENCY_CODE as PREMIUM_CURRENCY_CODE,
  OP.DUE_DATE as DUE_DATE,
  OP.PREMIUM_VALUE_DATE as PREMIUM_VALUE_DATE,
  OP.DAY_COUNT as DAY_COUNT,
  OP.HEAD_OFFICE_TO_CUST as HEAD_OFFICE_TO_CUST,
  OP.NON_TAXPAYER_CORP as NON_TAXPAYER_CORP,
  OP.DESCRIPTON as DESCRIPTON,
  OP.PROFIT_LOSS AS PROFIT_LOSS,
  OP.SWAP_DATE AS SWAP_DATE,
  OP.BARRIER_TYPE AS BARRIER_TYPE,
  OP.BARRIER_KIND AS BARRIER_KIND,
  OP.BARRIER_LEVEL AS BARRIER_LEVEL,
  OP.CREDIT_LIMIT AS CREDIT_LIMIT,
  OP.USABLE_CREDIT_LIMIT AS USABLE_CREDIT_LIMIT,
  OP.USAGE_PURPOSE AS USAGE_PURPOSE,
  OP.OPTION_ONS_NETTING_AMOUNT AS OPTION_ONS_NETTING_AMOUNT,
  OP.OPTION_ONS_PRACTICE_RATE AS OPTION_ONS_PRACTICE_RATE,
  OP.COUNTER_INSTITUTION_PURPOSE AS COUNTER_INSTITUTION_PURPOSE
FROM BFX.OPTION_OP_TRANSACTION OP WHERE
OP.STATUS = '1'

AND ((? is null AND (? is null or OP.TRANSACTION_DATE>=?) AND (? is null or OP.TRANSACTION_DATE<=?) ) or OP.REFERENCE_ID = ? )  
AND (? is null or OP.STATE in ('RG','TBO') )  
AND (? is null or OP.BUY_CURRENCY_CODE = ? )  
AND (? is null or OP.SELL_CURRENCY_CODE = ? )  
AND (? is null or OP.CUSTOMER_NO = ? )  
AND (? is null or OP.OP_BRANCH_CODE = ? )  
AND (? is null or OP.TRANSACTION_TYPE = ? )  
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     		<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
	     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState1</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbSellCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbSellCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>		
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>		
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>		
	</parameters>
</popupdata>