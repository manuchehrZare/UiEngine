<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT OP.OID,
       OP.REFERENCE_ID,
       OP.CUSTOMER_NO,
       OP.CUST_BRANCH_CODE,
       OP.OPTION_CURRENCY_CODE,
       OP.CREDIT_LIMIT AS CREDIT_LIMIT,
       OP.USABLE_CREDIT_LIMIT AS USABLE_CREDIT_LIMIT,
       OP.OPTION_AMOUNT AS BALANCE,
       '09' AS MAIN_GROUP_CODE,
       '03' AS GROUP_CODE,
       case
         when (OP.DAY_COUNT <= 30) then
          '016'
         when (OP.DAY_COUNT <= 90) then
          '07'
         when (OP.DAY_COUNT <= 180) then
          '018'
         when (OP.DAY_COUNT <= 365) then
          '019'
         when (OP.DAY_COUNT <= 730) then
          '020'
         else
          '021'
       end as PRODUCT_CODE,
       (select oid
          from ccs.product_limit
         where main_group_code = '09'
           and group_code = '03'
           and product_code = case
                 when (OP.DAY_COUNT <= 30) then
                  '016'
                 when (OP.DAY_COUNT <= 90) then
                  '017'
                 when (OP.DAY_COUNT <= 180) then
                  '018'
                 when (OP.DAY_COUNT <= 365) then
                  '019'
                 when (OP.DAY_COUNT <= 730) then
                  '020'
                 else
                  '021'
               end) as PRODUCT_OID
  FROM BFX.OPTION_OP_TRANSACTION OP
 WHERE OP.STATUS = '1'
   AND OP.STATE <> 'IPT'
  
AND (? is null or OP.REFERENCE_ID  = ? )  
AND (? is null or OP.CUSTOMER_NO = ? )
AND (? is null or OP.CUST_BRANCH_CODE = ? )
AND (? is null or OP.OPTION_CURRENCY_CODE = ? )
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQuery.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.hndCustNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQuery.hndCustNo</parameter>
	    <parameter prefix="" suffix="">Page.pnlQuery.cmbBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCurrencyCode</parameter>
	</parameters>
</popupdata>