<popupdata type="sql">
    <sql dataSource="BankingDS">
    	select
 HEROS.OID as OID, 
 HEROS.REFERENCE_ID as REFERENCE_ID,
 HEROS.TRANSACTION_OID as TRANSACTION_OID, 
 HEROS.RESERVATION_NO as RESERVATION_NO,
 HEROS.STATE as STATE,
 HEROS.CUSTOMER_NO as CUSTOMER_NO,
 HEROS.BRANCH_CODE as BRANCH_CODE,
 HEROS.BRANCH_USER as BRANCH_USER,
 HEROS.TRANSACTION_TYPE as TRANSACTION_TYPE,
 HEROS.USAGE_PURPOSE as USAGE_PURPOSE,
 HEROS.TRANSACTION_DATE as TRANSACTION_DATE,
 HEROS.EXTERNAL_TICKET_ID as EXTERNAL_TICKET_ID,
 HEROS.MAIN_OPTION_TYPE as MAIN_OPTION_TYPE,
 HEROS.OPTION_TYPE as OPTION_TYPE,
 HEROS.BUY_CURRENCY_CODE as BUY_CURRENCY_CODE,
 HEROS.SELL_CURRENCY_CODE as SELL_CURRENCY_CODE,
 HEROS.BUY_CURRENCY_TYPE as BUY_CURRENCY_TYPE,
 HEROS.SELL_CURRENCY_TYPE as SELL_CURRENCY_TYPE,
 HEROS.OPTION_CURRENCY_CODE as OPTION_CURRENCY_CORE,
 HEROS.OPTION_AMOUNT as OPTION_AMOUNT,
 HEROS.OPTION_NETTING_AMOUNT as OPTION_NETTING_AMOUNT,
 HEROS.PRACTICE_RATE as PRACTICE_RATE,
 HEROS.SPOT_RATE as SPOT_RATE,
 HEROS.TREASURY_PREMIUM_AMOUNT as TREASURY_PREMIUM_AMOUNT,
 HEROS.CUSTOMER_PREMIUM_AMOUNT as CUSTOMER_PREMIUM_AMOUNT,
 HEROS.PREMIUM_AMOUNT as PREMIUM_AMOUNT,
 HEROS.PREMIUM_CURRENCY_CODE as PREMIUM_CURRENCY_CODE,
 HEROS.DUE_DATE as DUE_DATE,
 HEROS.PREMIUM_VALUE_DATE as PREMIUM_VALUE_DATE,
 HEROS.DAY_COUNT as DAY_COUNT,
 HEROS.HEAD_OFFICE_TO_CUST as HEAD_OFFICE_TO_CUST,
 HEROS.NON_TAXPAYER_CORP as NON_TAXPAYER_CORP,
 HEROS.DESCRIPTON as DESCRIPTON,
 HEROS.SWAP_DATE as SWAP_DATE,
 HEROS.PROFIT_LOSS as PROFIT_LOSS,
 HEROS.COUNTER_INSTITUTION_PURPOSE as COUNTER_INSTITUTION_PURPOSE,
 HEROS.BARRIER_TYPE as BARRIER_TYPE,
 HEROS.BARRIER_KIND as BARRIER_KIND,
 HEROS.BARRIER_LEVEL as BARRIER_LEVEL,
 HEROS.KKM_CONTROL as KKM_CONTROL,
 HEROS.OPTION_ONS_NETTING_AMOUNT as OPTION_ONS_NETTING_AMOUNT,
 HEROS.OPTION_ONS_PRACTICE_RATE as OPTION_ONS_PRACTICE_RATE
from BFX.OPTION_EXC_GIVE_RATEOFEX HEROS , BFX.OPTION_EXC_TRANSACTION TRANS 
where 
    TRANS.STATUS ='1' 
AND HEROS.STATUS = '1' 
AND TRANS.OID = HEROS.TRANSACTION_OID 
AND (? is null or HEROS.RESERVATION_NO = ? )  
AND (? is null or HEROS.STATE = ? )  
AND (? is null or HEROS.TRANSACTION_DATE = ? )  
AND (? is null or HEROS.BUY_CURRENCY_CODE = ? )  
AND (? is null or HEROS.SELL_CURRENCY_CODE = ? )  
AND (? is null or HEROS.BRANCH_CODE = ? )  
AND (? is null or HEROS.BRANCH_USER = ? )  

    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBuyCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBuyCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbSellCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbSellCurrencyCode</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>	
		
	</parameters>
</popupdata>