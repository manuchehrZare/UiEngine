<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		GEX.*,EXC.TRANSACTION_TYPE,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.ORG_USER AS TRANS_ORG_USER,TRANS.CUSTOMER_CODE AS TRANS_CUSTOMER_CODE,
        TRANS.CUSTOMER_NAME AS TRANS_CUSTOMER_NAME, TRANS.CUSTOMER_ORG_CODE AS TRANS_CUSTOMER_ORG_CODE, TRANS.TL_ACC_OID AS TRANS_TL_ACC_OID, 
        TRANS.REFERENCE_ID AS TRANS_REFERENCE_ID,TRANS.Oid as TRANS_OID,(select ACC_CODE FROM DEPOSIT.DEPOSIT_ACCOUNT WHERE OID = TRANS.DTH_OID) AS TRANS_DTH_NO,
        (select ACC_CODE FROM DEPOSIT.DEPOSIT_ACCOUNT WHERE OID = TRANS.TL_ACC_OID) AS TRANS_TL_ACC_NO,TRANS.CREDIT_LIMIT,TRANS.USABLE_CREDIT_LIMIT,EXC2.TRANSACTION_TIME 
    	FROM
    		BFX.SWAP_OP_TRANSACTION TRANS,
		  	BFX.SWAP_EXC_GIVE_RATEOFEX GEX,
			BFX.SWAP_EXC_TRANSACTION EXC,
			BFX.SWAP_EXC_TRANSACTION EXC2
		WHERE
			TRANS.STATUS=1
			AND GEX.STATUS=1
			AND GEX.OID=TRANS.RESERVATION_OID
			AND EXC.OID=GEX.TRANSACTION_OID
			AND EXC2.OID=TRANS.TRANSACTION_OID
			AND (? is null or TRANS.REFERENCE_ID=?)
			AND (? is null or TRANS.STATE=?)
			AND (? is null or TRANS.TRANSACTION_DATE=?)
			AND (? is null or (GEX.CURRENCY_CODE=? OR GEX.SPOT_DEPOSIT_CURRENCY_CODE=?))
			AND (? is null or TRANS.ORG_USER=?)
			AND (? is null or TRANS.ORG_CODE=?)
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtRefId</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtRefId</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>		
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>		
	</parameters>
</popupdata>