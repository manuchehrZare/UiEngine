<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		GEX.*,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.TRANSACTION_USER
    	FROM
    		BFX.SWAP_EXC_TRANSACTION TRANS,
		  	BFX.SWAP_EXC_GIVE_RATEOFEX GEX
		WHERE
			TRANS.STATUS=1
			AND GEX.STATUS=1
			AND GEX.TRANSACTION_OID=TRANS.OID
			AND (? is null or GEX.RESERVATION_NO=?)
			AND (? is null or GEX.STATE=?)
			AND (? is null or TRANS.TRANSACTION_DATE=?)
			AND (? is null or (GEX.CURRENCY_CODE=? OR GEX.SPOT_DEPOSIT_CURRENCY_CODE=?))
			AND (? is null or GEX.ORG_USER=?)
			AND (? is null or GEX.ORG_CODE=?)
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>		
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>		
	</parameters>
</popupdata>