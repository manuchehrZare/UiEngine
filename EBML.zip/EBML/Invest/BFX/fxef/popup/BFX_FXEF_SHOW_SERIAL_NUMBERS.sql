<popupdata type="service">
	<service>BFX_FXEF_LIST_SERIAL_NUMBERS_FOR_POPUP</service>
	    <parameters>
	        <parameter n="REFERENCE_ID">Page.txtRefId</parameter>
      </parameters>
</popupdata>
