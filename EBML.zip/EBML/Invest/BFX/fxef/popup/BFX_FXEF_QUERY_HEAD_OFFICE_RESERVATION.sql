<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		GEX.*,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.USER_NO
    	FROM
    		BFX.FXEF_EXC_TRANSACTIONS TRANS,
		  	BFX.FXEF_EXC_GIVE_RATEOFEX GEX
		WHERE
			TRANS.STATUS=1
			AND GEX.STATUS=1
			AND GEX.TRANSACTION_OID=TRANS.OID
			AND (? is null or GEX.RESERVATION_NO=?)
			AND (? is null or GEX.STATE=?)
			AND (? is null or TRANS.TRANSACTION_DATE=?)
			AND (? is null or GEX.TRANSACTION_TO_USE=?)
			AND (? is null or GEX.TRANSACTION_TYPE=?)
			AND (? is null or GEX.CURRENCY_CODE=?)
			AND (? is null or GEX.ARB_CURRENCY_CODE=?)
			AND (? is null or GEX.BRANCH_USER=?)
			AND (? is null or GEX.BRANCH_CODE=?)
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransactionToUse</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransactionToUse</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransactionType</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransactionType</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>		
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>		
	</parameters>
</popupdata>