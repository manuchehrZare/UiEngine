<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		GEX.*,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.ORG_USER AS TRANS_ORG_USER,TRANS.CUSTOMER_CODE AS TRANS_CUSTOMER_CODE,
        TRANS.CUSTOMER_NAME AS TRANS_CUSTOMER_NAME, TRANS.CUSTOMER_ORG_CODE AS TRANS_CUSTOMER_ORG_CODE, TRANS.TL_ACC_OID AS TRANS_TL_ACC_OID, 
        TRANS.REFERENCE_ID AS TRANS_REFERENCE_ID,TRANS.Oid as TRANS_OID,(select ACC_CODE FROM DEPOSIT.DEPOSIT_ACCOUNT WHERE OID = TRANS.DTH_OID) AS TRANS_DTH_NO,
        (select ACC_CODE FROM DEPOSIT.DEPOSIT_ACCOUNT WHERE OID = TRANS.TL_ACC_OID) AS TRANS_TL_ACC_NO,ACCDEF.ACC_CODE AS TIMEDEP_ACCCODE, GEX.SWAP_TYPE,TRANS.STATE AS TRANS_STATE  
    	FROM
    		BFX.SWAP_OP_TRANSACTION TRANS,
		  	BFX.SWAP_EXC_GIVE_RATEOFEX GEX,
		  	DEPOSIT.TIMEDEP_ACCOUNT_DEF ACCDEF
		WHERE
			TRANS.STATUS=1
			AND GEX.STATUS=1
			AND GEX.OID=TRANS.RESERVATION_OID
			AND ACCDEF.OID(+) = TRANS.TIME_DEPOSIT_OID
			AND TRANS.STATE IN ('TB','RG')
			AND (? is null or TRANS.REFERENCE_ID=?)
			AND (? is null or TRANS.TRANSACTION_DATE=?)
			AND (? is null or (GEX.CURRENCY_CODE=? OR GEX.SPOT_DEPOSIT_CURRENCY_CODE=?))
			AND (? is null or TRANS.ORG_USER=?)
			AND (? is null or TRANS.ORG_CODE=?)
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtRefId</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtRefId</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>		
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>		
	</parameters>
</popupdata>