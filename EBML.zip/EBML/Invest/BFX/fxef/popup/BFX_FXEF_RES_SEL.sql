<popupdata type="sql">
    <sql dataSource="BankingDS">
		  SELECT 
      RES.*,
      TRANS.TRANSACTION_DATE,
      TRANS.TRANSACTION_TIME,
      TRANS.USER_NO,
      TRANS.BRANCH_CODE,
      TRANS.STATEMENT_NO,
      TRANS.DESCRIPTION,
      DEF.UNITS,
      GEX.RESERVATION_NO AS HEAD_OFFICE_RESERVATION_NO,
      GEX_TRANS.TRANSACTION_DATE AS HEAD_OFFICE_TRANSACTION_DATE,
      GEX.DUE_DATE,
      GEX.FUTURE_DATE_OPERATION,
      GEX.SPOT_RATE,
      
      CASE WHEN (RES.TRANSACTION_TYPE IN ('E','D','AR'))
            THEN RES.TL_AMOUNT
            ELSE 0 END X_SECOND_FX_AMOUNT,
            CASE WHEN (RES.TRANSACTION_TYPE NOT IN ('E','D','AR'))
            THEN RES.TL_AMOUNT
            ELSE 0 END X_TL_AMOUNT,
            CASE WHEN (RES.TRANSACTION_TYPE IN ('E','D','AR'))
            THEN RES.TL_ACC_NO
            ELSE '' END X_DTH2_NO,
            CASE WHEN (RES.TRANSACTION_TYPE NOT IN ('E','D','AR'))
            THEN RES.TL_ACC_NO
            ELSE '' END X_TL_ACC_NO
    FROM 
      BFX.FXEF_EXC_RESERVATION RES,
      BFX.FXEF_EXC_TRANSACTIONS TRANS,
      BFX.FXEF_EXC_TRANSACTIONS GEX_TRANS,
      BFX.FXEF_EXC_GIVE_RATEOFEX GEX,
      BFX.FXEF_PAR_CURRENCY_DEF DEF
    WHERE
      RES.STATUS=1
      AND TRANS.STATUS=1
      AND RES.TRANSACTION_OID=TRANS.OID
      AND RES.HEAD_OFFICE_RESERVATION_ID=GEX.OID(+)
      AND GEX.TRANSACTION_OID=GEX_TRANS.OID(+)
      AND RES.CURRENCY_CODE=DEF.CURRENCY_CODE
		  AND (? is null or RES.REFERENCE_ID=?)
		  AND (? is null or TRANS.BRANCH_CODE=?)
		  AND (? is null or RES.CUST_NO=?)
		  AND (? is null or RES.TRANSACTION_TO_USE=?)
		  AND (? is null or RES.TRANSACTION_TYPE=?)
		  AND (? is null or (RES.CURRENCY_CODE=? or RES.ARB_CURRENCY_CODE=?))
		  AND (? is not null or (RES.CURRENCY_CODE NOT IN 'XAU' AND (RES.ARB_CURRENCY_CODE NOT in 'XAU' OR RES.ARB_CURRENCY_CODE IS null)))
		  AND (? is null or RES.TIMEDEP_ACC_NO_CONVERT_FROM=?)
  		  AND (? is null or RES.TIMEDEP_ACC_NO_CONVERT_TO=?)
		  AND (? is null or TRANS.USER_NO=?)
		  AND (to_number(?,'9999999999999999999999.99') = 0 or RES.TL_AMOUNT>=to_number(?,'9999999999999999999999.99'))
		  AND (to_number(?,'9999999999999999999999.99') = 0 or RES.TL_AMOUNT<=to_number(?,'9999999999999999999999.99'))
		  AND (to_number(?,'9999999999999999999999.99') = 0 or RES.FX_AMOUNT>=to_number(?,'9999999999999999999999.99'))
		  AND (to_number(?,'9999999999999999999999.99') = 0 or RES.FX_AMOUNT<=to_number(?,'9999999999999999999999.99'))
		  AND (? is null or TRANS.TRANSACTION_DATE>=?)
		  AND (? is null or TRANS.TRANSACTION_DATE<=?)
		  AND (? is null or RES.STATE=?)
		  AND (? is null)
		  AND (? is null or RES.DUE_DATE>=?)
		  AND (? is null or RES.DUE_DATE<=?)
		  AND (? is null or RES.FUTURE_DATE_OPERATION=?)
    </sql>
     <parameters>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtResRefNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtResRefNo</parameter>

     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>

     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>

     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransToUse</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransToUse</parameter>

     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>

     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode2</parameter>
	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode1</parameter>

		<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlTimeDeposit.hndTimeDepConvertFrom</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlTimeDeposit.hndTimeDepConvertFrom</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlTimeDeposit.hndTimeDepConvertTo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlTimeDeposit.hndTimeDepConvertTo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtErrorText</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlDueDate.dtDueDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlDueDate.dtDueDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlDueDate.dtDueDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.pnlDueDate.dtDueDate2</parameter>      
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtFutureDateOperation</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtFutureDateOperation</parameter>
     </parameters>
</popupdata>
     