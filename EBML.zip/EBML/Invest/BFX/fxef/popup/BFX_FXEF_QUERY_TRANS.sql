<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT 
			TE.*,
			TRANS.TRANSACTION_DATE,
			TRANS.TRANSACTION_TIME,
			TRANS.USER_NO,
			TRANS.BRANCH_CODE,
			TRANS.STATEMENT_NO,
			TRANS.DESCRIPTION,
			CASE WHEN (TE.TRANSACTION_TYPE IN ('E','D','AR'))
            THEN TE.TL_AMOUNT
            ELSE 0 END X_SECOND_FX_AMOUNT,
            CASE WHEN (TE.TRANSACTION_TYPE NOT IN ('E','D','AR'))
            THEN TE.TL_AMOUNT
            ELSE 0 END X_TL_AMOUNT,
            CASE WHEN (TE.TRANSACTION_TYPE IN ('E','D','AR'))
            THEN TE.TL_ACC_NO
            ELSE '' END X_DTH2_NO,
            CASE WHEN (TE.TRANSACTION_TYPE NOT IN ('E','D','AR'))
            THEN TE.TL_ACC_NO
            ELSE '' END X_TL_ACC_NO
		FROM 
		  BFX.FXEF_EXC_TRANSACTION_ENTRY TE,
		  BFX.FXEF_EXC_TRANSACTIONS TRANS
		WHERE
		  TE.STATUS=1
		  AND TRANS.STATUS=1
		  AND TE.TRANSACTION_OID=TRANS.OID
		  AND (? is null or TE.REFERENCE_ID=?)
		  AND (? is null or TRANS.BRANCH_CODE=?)
		  AND (? is null or TE.CUST_NO=?)
		  AND (? is null or TE.TRANSACTION_TO_USE=?)
		  AND (? is null or TE.TRANSACTION_TYPE=?)
		  AND (? is null or TE.CURRENCY_CODE=?)
		  AND (? is null or TE.ARB_CURRENCY_CODE=?)
		  AND (? is null or TRANS.USER_NO=?)
		  AND (to_number(?,'9999999999999999999999.99') = 0 or TE.TL_AMOUNT>=to_number(?,'9999999999999999999999.99'))
		  AND (to_number(?,'9999999999999999999999.99') = 0 or TE.TL_AMOUNT<=to_number(?,'9999999999999999999999.99'))
		  AND (to_number(?,'9999999999999999999999.99') = 0 or TE.FX_AMOUNT>=to_number(?,'9999999999999999999999.99'))
		  AND (to_number(?,'9999999999999999999999.99') = 0 or TE.FX_AMOUNT<=to_number(?,'9999999999999999999999.99'))
		  AND (? is null or TRANS.TRANSACTION_DATE>=?)
		  AND (? is null or TRANS.TRANSACTION_DATE<=?)
		  AND (? is null or TE.STATE=?)
		  AND (? is null)
		  AND TE.OID not in (SELECT TRANSACTION_ENTRY_OID FROM BFX.FXFWD_OP_TRANSACTION WHERE TRANSACTION_ENTRY_OID is not null)
    </sql>
     <parameters>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransToUse</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransToUse</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrCode2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfTLAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cfFXAmount2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtErrorText</parameter>        	
     </parameters>
</popupdata>
     