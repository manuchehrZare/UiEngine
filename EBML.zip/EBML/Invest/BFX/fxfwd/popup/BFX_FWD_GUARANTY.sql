<popupdata type="sql">
    <sql dataSource="BankingDS">
    	select
			   OID,
			   REFERENCE_ID,
			   CUST_NO,
			   BRANCH_CODE,
			   CURRENCY_CODE,
			   ARB_CURRENCY_CODE,
			   CREDIT_LIMIT,
			   USABLE_CREDIT_LIMIT,
			   BALANCE,
			   '09' as MAIN_GROUP_CODE,
			   '03' as GROUP_CODE, 
	  		    case when (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=30 ) then '007'
                     		 when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=90 ) then '022'
                     		 when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=180 ) then '023'
                     		 when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=365 ) then '024'
                     		 when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=730 ) then '025'                                            
                      		else '026'                      
              		    end   as PRODUCT_CODE,                
              		   (select oid from ccs.product_limit 
              		    where main_group_code = '09' 
                	    and group_code = '03' 
                	    and product_code =     case when (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=30 ) then '007'
              	       					when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=90 ) then '022'
                    					when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=180 ) then '023'
                  					when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=365 ) then '024'
                      					when  (( to_date(return_date,'yyyymmdd')-to_date(transaction_date,'yyyymmdd'))<=730 ) then '025'                                            
                   				   else '026'                      
            					   end ) as PRODUCT_OID
		from  BFX.FXFWD_OP_TRANSACTION
		where  status = '1'
		and    state <> 'IPT'
		AND (? is null or OID=?)
		AND (? is null or REFERENCE_ID=?)
		AND (? is null or CUST_NO=?)
		AND (? is null or BRANCH_CODE=?)
		AND (? is null or CURRENCY_CODE=?)
		AND (? is null or ARB_CURRENCY_CODE=?)	
	union
	SELECT 		C.OID,
       			C.REFERENCE_ID,
       			F.INV_ACC_CUST_CODE AS CUST_NO,
      			C.BRANCH AS BRANCH_CODE,
       			AD.ISIN_CODE AS CURRENCY_CODE,
       			AD.ISIN_CODE AS ARB_CURRENCY_CODE,
       			C.CREDIT_LIMIT,
      			C.USABLE_CREDIT_LIMIT,
       			C.BALANCE,
      			'09' AS MAIN_GROUP_CODE,
       			'03' AS GROUP_CODE,
       			 case when (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=30 ) then '007'
                              when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=90 ) then '022'
                              when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=180 ) then '023'
                              when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=365 ) then '024'
                              when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=730 ) then '025'                                            
                              else '026'                      
                         end   as PRODUCT_CODE,                
                         (select oid from ccs.product_limit 
                          where main_group_code = '09' 
                          and group_code = '03' 
                          and product_code =     case when (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=30 ) then '007'
                                            	      when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=90 ) then '022'
		                                      when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=180 ) then '023'
                		                      when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=365 ) then '024'
                                	              when  (( to_date(c.value_date,'yyyymmdd')-to_date(c.transaction_date,'yyyymmdd'))<=730 ) then '025'                                            
		                                      else '026'                      
                	                       end ) as PRODUCT_OID
  	FROM FIS.CUSTOMER_FORWARD C,
      	     FIS.FISTRADE_OPERATION F,
       	     INVESTCORE.ASSET_DEF AD
	 WHERE     C.STATUS = '1'
      	 AND F.STATUS(+) = '1'
         AND AD.STATUS = '1'
         AND C.STATE <> 'IPT'
         AND C.TRADE_OPERATION_OID = F.OID(+)
         AND C.CURRENCY_OID = AD.OID
         AND (? IS NULL OR C.OID = ?)
         AND (? IS NULL OR C.REFERENCE_ID = ?)
         AND (? IS NULL OR C.BRANCH = ?)
         AND (? IS NULL OR AD.ISIN_CODE = ?)
         AND (? IS NULL OR AD.ISIN_CODE = ?)
	union
  	select
			   T.OID,
			   T.REFERENCE_ID,
			   T.CUSTOMER_CODE,
			   T.ORG_CODE,
			   G.CURRENCY_CODE,
			   G.SPOT_DEPOSIT_CURRENCY_CODE ,
			   CREDIT_LIMIT,
			   USABLE_CREDIT_LIMIT,
			   0,
			   '09' as MAIN_GROUP_CODE,
			   '03' as GROUP_CODE, 
	  		    case when (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=30 ) then '007'
                     		 when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=90 ) then '022'
                     		 when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=180 ) then '023'
                     		 when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=365 ) then '024'
                     		 when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=730 ) then '025'                                            
                      		else '026'                      
              		    end   as PRODUCT_CODE,                
              		   (select oid from ccs.product_limit 
              		    where main_group_code = '09' 
                	    and group_code = '03' 
                	    and product_code =     case when (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=30 ) then '007'
              	       					when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=90 ) then '022'
                    					when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=180 ) then '023'
                  					when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=365 ) then '024'
                      					when  (( to_date(G.return_date,'yyyymmdd')-to_date(T.transaction_date,'yyyymmdd'))<=730 ) then '025'                                            
                   				   else '026'                      
            					   end ) as PRODUCT_OID
		from  BFX.SWAP_OP_TRANSACTION T, BFX.SWAP_EXC_GIVE_RATEOFEX G
		where  T.status = '1'
		AND    G.STATUS = '1'
		and    T.state <> 'IPT'
		AND    G.OID = T.RESERVATION_OID 
		AND (? is null or T.OID=?)
		AND (? is null or T.REFERENCE_ID=?)
		AND (? is null or T.CUSTOMER_CODE=?)
		AND (? is null or T.ORG_CODE=?)
		AND (? is null or G.CURRENCY_CODE=?)
		AND (? is null or G.SPOT_DEPOSIT_CURRENCY_CODE =?)
    </sql>
	<parameters>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.lblOid</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.lblOid</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>	
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>	
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.lblOid</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.lblOid</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>	
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.lblOid</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.lblOid</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>	
     	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
	    <parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
	</parameters>
</popupdata>