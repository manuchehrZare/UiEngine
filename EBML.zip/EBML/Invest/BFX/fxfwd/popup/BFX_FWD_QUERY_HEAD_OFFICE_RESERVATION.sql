<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		HEORES.*,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.USER_NO, TRANS.DESCRIPTION
    	FROM
    		BFX.FXFWD_EXC_TRANSACTIONS TRANS,
		  	BFX.FXFWD_EXC_GIVE_RATEOFEX HEORES
		WHERE
			TRANS.STATUS=1
			AND HEORES.STATUS=1
			AND HEORES.TRANSACTION_OID=TRANS.OID
			AND (? is null or HEORES.RESERVATION_NO=?)
			AND (? is null or HEORES.STATE=?)
			AND (? is null or TRANS.TRANSACTION_DATE=?)
			AND (? is null or HEORES.TRANSACTION_TYPE=?)
			AND (? is null or HEORES.CURRENCY_CODE=?)
			AND (? is null or HEORES.ARB_CURRENCY_CODE=?)
			AND (? is null or HEORES.BRANCH_USER=?)
			AND (? is null or HEORES.BRANCH_CODE=?)
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtHeadOffResNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.lblQueryDate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransactionType</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransactionType</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndUserNo</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbOrgCode</parameter>	
	</parameters>
</popupdata>