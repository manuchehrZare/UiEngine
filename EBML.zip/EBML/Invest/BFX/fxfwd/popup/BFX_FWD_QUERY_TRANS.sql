<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		FXFWD.*,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.USER_NO, TRANS.DESCRIPTION,TRANS.BRANCH_CODE,TRANS.STATEMENT_NO,FEGR.PURPOSE
    	FROM
    		BFX.FXFWD_OP_TRANSACTION FXFWD,
		   	BFX.FXFWD_EXC_TRANSACTIONS TRANS,
		   	BFX.FXFWD_EXC_GIVE_RATEOFEX FEGR
		WHERE
			TRANS.STATUS=1
			AND FXFWD.STATUS=1
			AND FXFWD.TRANSACTION_OID=TRANS.OID
			AND FXFWD.HEAD_OFFICE_RESERVATION_ID = FEGR.OID
			AND ((? is null AND (? is null or TRANS.TRANSACTION_DATE>=?) AND (? is null or TRANS.TRANSACTION_DATE<=?) ) or FXFWD.REFERENCE_ID=?)
			AND (? is null or FXFWD.STATE=?)
		    AND ((? is null AND ((? is null or FXFWD.STATE=?) OR (? is null or FXFWD.STATE=?))) or ((FXFWD.STATE=? and TRANS.TRANSACTION_DATE=?) or (FXFWD.STATE=? and TRANS.TRANSACTION_DATE<=? and FXFWD.RETURN_DATE>? ))) 
			AND (? is null or TRANS.BRANCH_CODE=?)
			AND (? is null or FXFWD.CUST_NO=?)	
			AND (? is null or FXFWD.TRANSACTION_TYPE=?)
			AND (? is null or FXFWD.CURRENCY_CODE=?)
			AND (? is null or FXFWD.ARB_CURRENCY_CODE=?)		
			AND (to_number(?,'9999999999999999999999.99') = 0 or FXFWD.FX_AMOUNT>=to_number(?,'9999999999999999999999.99'))
		    AND (to_number(?,'9999999999999999999999.99') = 0 or FXFWD.FX_AMOUNT<=to_number(?,'9999999999999999999999.99'))		    
		    
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtCheckForCooperate</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState1</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState1</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState2</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState2</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtToday</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtToday</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtToday</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMinAmount</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMinAmount</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMaxAmount</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMaxAmount</parameter>	        		
	</parameters>
</popupdata>