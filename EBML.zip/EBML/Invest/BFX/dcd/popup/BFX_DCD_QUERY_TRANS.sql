<popupdata type="sql">
    <sql dataSource="BankingDS">
    	SELECT 
    		DCD.*,TRANS.TRANSACTION_DATE AS TRANS_TRANSACTION_DATE,TRANS.USER_NO, TRANS.DESCRIPTION,TRANS.BRANCH_CODE,TRANS.STATEMENT_NO
    	FROM
    		BFX.DCD_OP_TRANSACTION DCD,
		   	BFX.DCD_EXC_TRANSACTIONS TRANS
		WHERE
			TRANS.STATUS=1
			AND DCD.STATUS=1
			AND DCD.TRANSACTION_OID=TRANS.OID
			AND (? is null or DCD.REFERENCE_ID=?)
			AND (? is null or DCD.STATE=?)
			AND (? is null or DCD.STATE=?)
			AND (? is null or TRANS.BRANCH_CODE=?)
			AND (? is null or DCD.CUST_NO=?)	
			AND (? is null or DCD.TRANSACTION_TYPE=?)
			AND (? is null or DCD.CURRENCY_CODE=?)
			AND (? is null or DCD.ARB_CURRENCY_CODE=?)
			AND (? is null or TRANS.TRANSACTION_DATE>=?)
		    AND (? is null or TRANS.TRANSACTION_DATE<=?)	
			AND (to_number(?,'9999999999999999999999.99') = 0 or DCD.FX_AMOUNT>=to_number(?,'9999999999999999999999.99'))
		    AND (to_number(?,'9999999999999999999999.99') = 0 or DCD.FX_AMOUNT<=to_number(?,'9999999999999999999999.99'))
    </sql>
	<parameters>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtTransRefNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState1</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.txtState1</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbBranchCode</parameter>	
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.hndCustNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbTransType</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.cmbArbCurrencyCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate1</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.dtDate2</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMinAmount</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMinAmount</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMaxAmount</parameter>
     	<parameter prefix="" suffix="">Page.pnlQueryCriterias.currMaxAmount</parameter>		
	</parameters>
</popupdata>