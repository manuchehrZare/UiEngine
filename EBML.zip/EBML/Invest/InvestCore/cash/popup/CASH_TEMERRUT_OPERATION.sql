<popupdata type="service">
	<service>INVESTCORE_CASH_LIST_TEMERRUT_OPERATIONS</service>
    <parameters>
        <parameter n="DECONT_NUMBER">Page.pnlFilter.txtDecontNumber</parameter>
        <parameter n="ACCOUNT_CODE">Page.pnlFilter.hndAccount</parameter>
        <parameter n="CUSTOMER_CODE">Page.pnlFilter.txtCustNo</parameter>        
        <parameter n="ORG_OID">Page.pnlFilter.cmbOrganization</parameter>
        <parameter n="TEMERRUT_PROCESS_TYPE">Page.pnlFilter.cmbProcessType</parameter>                       
        <parameter n="BEGIN_DATE">Page.pnlFilter.dtBeginDate</parameter>
        <parameter n="END_DATE">Page.pnlFilter.dtEndDate</parameter>               
        <parameter n="ONLY_DECONT_QUERY">Page.pnlFilter.txtOnlyDecontQuery</parameter>                       
        </parameters>
</popupdata>