<popupdata type="service">
	<service>INVESTCORE_TRN_LIST_ASSET_DEPOT_STOCK</service>
    	<parameters>
	        <parameter n="ACCOUNT_CODE">Page.pnlAccountInfo.txtAccountCode</parameter>
	        <parameter n="ASSET_DEFINITION_OID">Page.pnlAsset.txtAssetDefinitionOID</parameter>
	        <parameter n="CLEARING_INST_OID">Page.pnlAsset.cmbClearingInst</parameter>
	        <parameter n="ASSET_MAIN_GROUP_DEF_OID">Page.txtAssetMainGroupDefOID</parameter>
	        <parameter n="LIST_TYPE">Page.txtListType</parameter>
	    </parameters>
</popupdata>
