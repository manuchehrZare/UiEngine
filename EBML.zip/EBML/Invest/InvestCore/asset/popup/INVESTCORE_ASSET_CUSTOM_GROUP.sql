<popupdata type="service">
	<service>INVESTCORE_ASSET_LIST_ASSET_CUSTOM_GROUP</service>
    	<parameters>
	        <parameter n="GROUP_NAME">Page.pnlCriteria.txtGroupCode</parameter>
	        <parameter n="GROUP_CODE">Page.pnlCriteria.txtGroupName</parameter>
	        <parameter n="ASSET_MAIN_GROUP_DEF_OID">Page.pnlCriteria.cmbAssetMainGroup</parameter>
	        <parameter n="ASSET_GROUP_DEF_OID">Page.pnlCriteria.cmbAssetGroup</parameter>
	    </parameters>
</popupdata>