<popupdata type="service">
	<service>INVESTCORE_INVCMN_LIST_BRANCH_AIM</service>
	    <parameters>
	    	<parameter n="YEAR">Page.pnlCriterias.cmbYear</parameter>
	    	<parameter n="OPERATION_TYPE">Page.pnlCriterias.cmbOperationType</parameter>
	    	<parameter n="DETAIL_TYPE">Page.pnlCriterias.cmbDetailType</parameter>    
	    	<parameter n="EXECUTE_QUERY">Page.pnlCriterias.txtExecuteQuery</parameter>
	    	<parameter n="ORG_OID">Page.pnlCriterias.cmbOrgCode</parameter>	    		
	    </parameters>
</popupdata>