<popupdata type="service">
	<service>INVESTCORE_INVCMN_LIST_CURRENCY_OP_TYPE</service>
	    <parameters>
	    	<parameter n="CURR_OP_TYPE_CODE">Page.txtCurrOpTypeCode</parameter>
	    	<parameter n="CURR_OP_TYPE_NAME">Page.txtCurrOpTypeName</parameter>
	    </parameters>
</popupdata>