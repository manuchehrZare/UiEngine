<popupdata type="service">
	<service>INVESTCORE_TRANSFER_LIST_TRANSFER</service>
    	<parameters>
    		<parameter n="PROCESS_ID">Page.txtProcessID</parameter>
    		<parameter n="TRANSACTION_DECONT_NUMBER">Page.pnlTransferInfo.txtDecontNumber</parameter>
    		<parameter n="TRANSACTION_DATE">Page.pnlTransferInfo.dtTransactionDate</parameter>
    		<parameter n="ASSET_DEF_OID">Page.pnlTransferInfo.txtAssetDefOID</parameter>    		 		
    		<parameter n="ASSET_REC_CLEARING_INST_OID">Page.pnlTransferInfo.cmbNewClearingInst</parameter>    		
	        <parameter n="ASSET_REC_DEPOT_OID">Page.pnlTransferInfo.cmbNewDepot</parameter>
   	        <parameter n="EXECUTE_QUERY">Page.txtExecuteQuery</parameter>
   	        <parameter n="CURRENCY_OID">Page.pnlTransferInfo.cmbCurrency_OID</parameter>
	    </parameters>
</popupdata>
