<popupdata type="service">
	<service>INVESTCORE_TRANSFER_LIST_ASSET_DEPOT_STOCK</service>
    	<parameters>
	        <parameter n="INV_ACC_OID">Page.pnlAccInfo.txtInvAccOID</parameter>
	         <parameter n="ACC_CODE">Page.pnlAccInfo.txtAccCode</parameter>
	        <parameter n="ASSET_DEF_OID">Page.pnlAsset.txtAssetDefOID</parameter>
	        <parameter n="CLEARING_INST_OID">Page.pnlAsset.cmbClearingInst</parameter>
	        <parameter n="ASSET_MAIN_GROUP_DEF_OID">Page.txtAssetMainGroupDefOID</parameter>
	        <parameter n="LIST_TYPE">Page.txtListType</parameter>
   	        <parameter n="EXECUTE_QUERY">Page.txtExecuteQuery</parameter>
   	        <parameter n="USABLE_PROCESS_CODE">Page.txtUsableProcessCode</parameter>	
   	        <parameter n="CURRENCY_OID">Page.pnlAsset.cmbCurrencyType</parameter>  
   	        <parameter n="LIST_SOURCE">Page.txtListSource</parameter>
   	        <parameter n="TRANSFER_TYPE">Page.txtTransferType</parameter>       
	    </parameters>
</popupdata>
