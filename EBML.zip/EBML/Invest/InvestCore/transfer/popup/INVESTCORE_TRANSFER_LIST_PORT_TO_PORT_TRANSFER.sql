<popupdata type="service">
	<service>INVESTCORE_TRANSFER_LIST_TRANSFER</service>
    	<parameters>
    		<parameter n="PROCESS_ID">Page.txtProcessID</parameter>
    		<parameter n="TRANSACTION_DECONT_NUMBER">Page.pnlTransferInfo.txtDecontNumber</parameter>
    		<parameter n="TRANSACTION_DATE">Page.pnlTransferInfo.dtTransactionDate</parameter>
    		<parameter n="ASSET_DEF_OID">Page.pnlTransferInfo.txtAssetDefOID</parameter>    		
    		<parameter n="EXECUTE_QUERY">Page.txtExecuteQuery</parameter>    		    		
    		<parameter n="CURRENCY_OID">Page.pnlTransferInfo.cmbCurrencyType</parameter> 
	    </parameters>
</popupdata> 