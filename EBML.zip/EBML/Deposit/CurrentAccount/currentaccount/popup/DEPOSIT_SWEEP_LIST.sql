<popupdata type="service">
	<service>DEPOSIT_ACC_LIST_SWEEP_INS</service>
	    <parameters>
	    	<parameter n="ORG_CODE">Page.pnlCriteria.cmbOrgCode</parameter>
	        <parameter n="SWEEP_CODE">Page.pnlCriteria.txtSweepNo</parameter>
	        <parameter n="CUST_CODE">Page.pnlCriteria.hndCustCode</parameter>
	        <parameter n="ACC_OID">Page.pnlCriteria.txtAccOid</parameter>
			<parameter n="RECEIVER_ACC_OID">Page.pnlCriteria.txtReceiverAccOid</parameter>
			<parameter n="RECEIVER_IBAN_NO">Page.pnlCriteria.txtIBAN</parameter>	
			<parameter n="SWEEP_ACCOUNT_TYPE">Page.pnlCriteria.cmbSweepAccType</parameter>					
	    </parameters>
</popupdata>