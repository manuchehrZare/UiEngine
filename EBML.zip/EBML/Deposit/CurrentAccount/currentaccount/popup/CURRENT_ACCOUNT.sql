<popupdata type="service">
	<service>DEPOSIT_CURRENT_ACC_LIST</service>
	    <parameters>
	    	<parameter n="ACC_CUST_CODE">Page.pnlCriteria.pnlCustomerInfo.hndCustCode</parameter>
	        <parameter n="ACC_ORG_CODE">Page.pnlCriteria.cmbOrganization</parameter>
	        <parameter n="ACC_CODE">Page.pnlCriteria.txtAccCode</parameter>
	        <parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
			<parameter n="CUST_REPRESENTATIVE">Page.pnlCriteria.hndCustRepresantative</parameter>
			<parameter n="OPERATION_TYPE">Page.lblRestrictionOperationType</parameter>        
			<parameter n="REPORT_OR_OPERATION">Page.lblReportOrOperation</parameter>
			<parameter n="ACC_OID">Page.lblAccOID</parameter>
			<parameter n="ACC_TYPE">Page.lblAccountGroup</parameter>	
			<parameter n="ACC_IBAN">Page.pnlCriteria.txtAccountIBAN</parameter>  
			<parameter n="ACC_CHANNEL">Page.pnlCriteria.txtChannelCode</parameter>		
			<parameter n="ACC_KRM_GROUP">Page.lblAccKRMGroup</parameter>
			<parameter n="ACC_KRM_REMOVED_PRODUCT_LIST">Page.lblKrmRemovedProductList</parameter>
			<parameter n="ACC_KRM_PRODUCT_GROUP_LIST">Page.lblKrmProductGroupList</parameter>
			<parameter n="ACC_KRM_ADD_PRODUCT_LIST">Page.lblKrmAddProductList</parameter>
			<parameter n="LIST_BUDGET">Page.pnlCriteria.txtListBudget</parameter>
	    </parameters>
</popupdata>