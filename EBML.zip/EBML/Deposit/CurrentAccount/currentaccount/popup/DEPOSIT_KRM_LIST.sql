<popupdata type="sql">
	<sql dataSource="BankingDS">
	SELECT acc.OID AS acc_oid, 
    acc.acc_code,
    acc.cust_code,  
    acc.balance,  
    acc.limit_balance,
    acc.org_code,
    acc.currency_code,
    krm.krm_product_code,
    krm.krm_product_group_code,
    '08' as MAIN_PRODUCT_GROUP_CODE,
    lim.oid as KRM_CCS_PRODUCT_OID,
    krm.krm_product_ccs_oid as KRM_CCS_PRODUCT_TEMPLET_OID,
    (CASE
        WHEN c.individual = 1 AND c.corporate = 1
           THEN    c.title
                || ' '
                || c.NAME
                || ' '
                || c.second_name
                || ' '
                || c.surname
        WHEN c.corporate = 1
           THEN '' || c.title
        WHEN c.individual = 1
           THEN c.NAME || ' ' || c.second_name || ' ' || c.surname
        ELSE ''
     END
    ) AS cust_title
	FROM deposit.deposit_account acc,
	    deposit.deposit_krm_limit krm,
	    infra.cust_cust_cust c,
	    ccs.PRODUCT_USAGE_INFO_TEMPLET usg,
	    ccs.product_limit lim
	WHERE acc.OID = krm.acc_oid (+)
	AND (krm.individual_corporate = '2' OR krm.individual_corporate is null) 
	AND c.customer_code = acc.cust_code
	and krm.krm_product_ccs_oid = usg.oid(+)
	and usg.product_oid = lim.oid(+)
	and acc.status = '1' 
	   and (? is null or acc.OID = ?)
	   and (? is null or acc.cust_code = ?)
	   and (? is null or acc.org_code = ?)
	   and (? is null or acc.acc_code = ?)
	</sql>
    <parameters>
	    <parameter prefix="" suffix="">Page.lblKRMOid</parameter>
        <parameter prefix="" suffix="">Page.lblKRMOid</parameter>
		<parameter prefix="" suffix="">Page.hndCustCode</parameter>
        <parameter prefix="" suffix="">Page.hndCustCode</parameter>
        <parameter prefix="" suffix="">Page.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.cmbOrganization</parameter>
        <parameter prefix="" suffix="">Page.hndAccCode</parameter>
        <parameter prefix="" suffix="">Page.hndAccCode</parameter>
    </parameters>
</popupdata>