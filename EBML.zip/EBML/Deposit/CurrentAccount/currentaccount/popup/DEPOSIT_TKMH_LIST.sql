<popupdata type="service">
	<service>DEPOSIT_TKMH_LIST</service>
	    <parameters>
	    	<parameter n="CUST_CODE">Page.pnlCriteria.hndCustCode</parameter>
	        <parameter n="ORG_CODE">Page.pnlCriteria.cmbOrganization</parameter>
	        <parameter n="STATUS">Page.pnlCriteria.cmbStatus</parameter>
	        <parameter n="ACC_CODE">Page.pnlCriteria.txtAccCode</parameter>
			<parameter n="IBAN_NO">Page.pnlCriteria.txtAccountIBAN</parameter>  
	    </parameters>
</popupdata>