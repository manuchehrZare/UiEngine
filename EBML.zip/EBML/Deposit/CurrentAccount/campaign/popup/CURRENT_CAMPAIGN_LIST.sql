<popupdata type="service">
	<service>DEPOSIT_LIST_CAMPAIGN</service>
	    <parameters>
	        <parameter n="CAMPAIGN_NO">Page.pnlCriteria.txtCampaignNo</parameter>
	        <parameter n="CAMPAIGN_GROUP">Page.pnlCriteria.cmbCampaignGroup</parameter>
	        <parameter n="START_DATE">Page.pnlCriteria.dtStartDate</parameter>
	        <parameter n="END_DATE">Page.pnlCriteria.dtEndDate</parameter>
			<parameter n="MAIN_PRODUCT_GROUP_CODE">Page.pnlCriteria.cmbMainProductGroupCode</parameter>
			<parameter n="PRODUCT_GROUP_CODE">Page.pnlCriteria.cmbProductGroupCode</parameter>
			<parameter n="PRODUCT_CODE">Page.pnlCriteria.cmbProductCode</parameter>
	    </parameters>
</popupdata>