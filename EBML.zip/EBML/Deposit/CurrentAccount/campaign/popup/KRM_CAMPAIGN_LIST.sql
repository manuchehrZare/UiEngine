<popupdata type="service">
	<service>DEPOSIT_KRM_LIST_CAMPAIGN</service>
	    <parameters>
	        <parameter n="CAMPAIGN_NO">Page.pnlCriteria.txtCampaignNo</parameter>
	        <parameter n="CAMPAIGN_OID">Page.pnlCriteria.cmbCampaign</parameter>
	        <parameter n="START_DATE">Page.pnlCriteria.dtStartDate</parameter>
	        <parameter n="END_DATE">Page.pnlCriteria.dtEndDate</parameter>
			<parameter n="MAIN_PRODUCT_GROUP_CODE">Page.pnlCriteria.cmbMainProductCode</parameter>
			<parameter n="PRODUCT_GROUP_CODE">Page.pnlCriteria.cmbProductGroupCode</parameter>
			<parameter n="PRODUCT_CODE">Page.pnlCriteria.cmbProductCode</parameter>
			<parameter n="IS_ACTIVE">Page.pnlCriteria.cmbIsActive</parameter>	
	    </parameters>
</popupdata>