<popupdata type="service">
	<service>COP_TRANSFER_LIST</service>
	    <parameters>
	        <parameter n="SENDER_ORG_CODE">Page.pnlCriteria.cmbSenderBranch</parameter>
	         <parameter n="RECEIVER_ORG_CODE">Page.pnlCriteria.cmbReceiverBranch</parameter>
	        <parameter n="TRANSFER_STATUS">Page.pnlCriteria.cmbTransferStatus</parameter>
	        <parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
      	    <parameter n="TRANSFER_DATE">Page.pnlCriteria.currAmount1</parameter>
      
	    </parameters>
</popupdata>