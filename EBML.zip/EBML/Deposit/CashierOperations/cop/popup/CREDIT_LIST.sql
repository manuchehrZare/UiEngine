<popupdata type="service">

	<service>COP_GET_CASHIER_CUSTOMER_CREDIT_LIST</service>
	
           <parameters>
	      
              <parameter n="CUSTOMER_CODE">Page.txtCust</parameter>
	 
           </parameters>

</popupdata>