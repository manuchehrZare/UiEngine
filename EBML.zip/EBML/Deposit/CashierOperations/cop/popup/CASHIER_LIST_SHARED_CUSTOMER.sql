<popupdata type="service">
	<service>COP_GET_CASHIER_ACTING_DETAILS_SHARED_CUSTOMER</service>
	    <parameters>
	        <parameter n="CUST_CUST_CUSTOMER_OID">Page.rgCustomer.Page.txtCustomerOid</parameter>
	    </parameters>
</popupdata>