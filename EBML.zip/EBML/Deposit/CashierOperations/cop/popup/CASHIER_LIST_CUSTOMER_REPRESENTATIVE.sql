<popupdata type="service">
	<service>COP_GET_CASHIER_ACTING_DETAILS_CUSTOMER_REPRESENTATIVE</service>
	    <parameters>
	        <parameter n="CUST_CUST_CUSTOMER_OID">Page.rgCustomer.Page.txtCustomerOid</parameter>
            <parameter n="CUST_CUST_CUSTOMER_CODE">Page.rgCustomer.Page.hndCustomerCode</parameter>
	    </parameters> 
</popupdata>