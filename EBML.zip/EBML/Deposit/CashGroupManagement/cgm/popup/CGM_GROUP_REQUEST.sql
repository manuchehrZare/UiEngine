<popupdata type="service">
	<service>CGM_CASH_GROUP_SEND_REQUEST_LIST</service>
	    <parameters>
	        <parameter n="USER_ORG_CODE">Page.pnlCriteria.cmbOrgCode</parameter>
	       	<parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
	      	<parameter n="DATE_MIN">Page.pnlCriteria.dtFirstDate</parameter>    
	        <parameter n="DATE_MAX">Page.pnlCriteria.dtLastDate</parameter>
	        <parameter n="REQUEST_TYPE">Page.pnlCriteria.txtRequestType</parameter>
	        <parameter n="SELECTED_TAB">Page.txtSelectedTabKey</parameter>  
	    </parameters>
</popupdata>