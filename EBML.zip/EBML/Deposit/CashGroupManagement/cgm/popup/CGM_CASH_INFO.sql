<popupdata type="service">
	<service>CGM_CASH_SHIFT_INFO_BY_QUERY</service>
	    <parameters>
	        <parameter n="ORG_CODE">Page.rgnCashInfo.Page.cmbBranch</parameter>
	       	<parameter n="CASH_TYPE">Page.rgnCashInfo.Page.cmbCaseType</parameter>
	      	<parameter n="OPEN_DATE_MIN">Page.rgnCashInfo.Page.dtMinOpenDate</parameter>    
	        <parameter n="OPEN_DATE_MAX">Page.rgnCashInfo.Page.dtMaxOpenDate</parameter>
	        <parameter n="CASH_NO">Page.rgnCashInfo.Page.cmbCashNo</parameter>
	        <parameter n="USER_ID">Page.rgnCashInfo.Page.txtCaseUser</parameter>  
	    </parameters>
</popupdata>