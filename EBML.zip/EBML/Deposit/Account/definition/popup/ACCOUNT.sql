<popupdata type="service">
	<service>ACCOUNT_LIST_CURRENT_ACCOUNTS_ORDINARY</service>
	    <parameters>
	        <parameter n="ACC_CUST_CODE">Page.pnlCriteria.pnlCustomerInfo.hndCustCode</parameter>
	        <parameter n="ACC_ORG_CODE">Page.pnlCriteria.cmbOrganization</parameter>
	        <parameter n="ACC_CODE">Page.pnlCriteria.txtAccCode</parameter>
	        <parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
			<parameter n="CUST_REPRESENTATIVE">Page.pnlCriteria.hndCustRepresantative</parameter>
			<parameter n="OPERATION_TYPE">Page.lblRestrictionOperationType</parameter>        
			<parameter n="REPORT_OR_OPERATION">Page.lblReportOrOperation</parameter>
			<parameter n="ACC_OID">Page.lblAccOID</parameter>
			<parameter n="ACC_TYPE">Page.lblAccountGroup</parameter>	
			<parameter n="ACC_IBAN">Page.pnlCriteria.txtAccountIBAN</parameter>  
			<parameter n="ACC_CHANNEL">Page.pnlCriteria.txtChannelCode</parameter>	
			<parameter n="CUST_REQUIRED">Page.lblCustRequired</parameter>
			<parameter n="CHECK_CUST_AP_STATUS">Page.lblCustCodeRequired</parameter>
			<parameter n="ACC_KRM_GROUP">Page.txtAccKrmGroup</parameter>	
			<parameter n="LIST_CLOSED_ACCOUNTS">Page.lblListClosedAccounts</parameter>
			<parameter n="ACC_PRODUCT_CODE">Page.lblAccProductCode</parameter>
			<parameter n="PURPOSE">Page.pnlCriteria.cmbPurpose</parameter>
			<parameter n="LIST_BUDGET">Page.pnlCriteria.txtListBudget</parameter>
			<parameter n="GET_PERSONNEL_ACC">Page.pnlCriteria.txtGetPersonnelAcc</parameter>
	    </parameters>
</popupdata>