<popupdata type="service">
	<service>ACCOUNT_LIST_CURRENT_ACCOUNTS</service>
	    <parameters>
	        <parameter n="ACC_CUST_CODE">Page.pnlCriteria.hndCustCode</parameter>
	        <parameter n="ACC_ORG_CODE">Page.pnlCriteria.cmbOrganization</parameter>
	        <parameter n="ACC_CODE">Page.pnlCriteria.txtAccCode</parameter>
	        <parameter n="CURRENCY_CODE">Page.pnlCriteria.cmbCurrencyCode</parameter>
			<parameter n="CUST_REPRESENTATIVE">Page.pnlCriteria.hndCustRepresantative</parameter>			
			<parameter n="OPERATION_TYPE">Page.lblRestrictionOperationType</parameter>        
			<parameter n="REPORT_OR_OPERATION">Page.lblReportOrOperation</parameter>
			<parameter n="ACC_TYPE">Page.lblAccountGroup</parameter>
			<parameter n="ACC_IBAN">Page.pnlCriteria.txtAccountIBAN</parameter>
			<parameter n="BY_PASS_ORG_RESTRICTION">Page.pnlCriteria.txtByPassOrgRestriction</parameter>
			<parameter n="ACCOUNT_OID">Page.lblAccountOID</parameter>
			<parameter n="SHOW_OPEN_ACCOUNTS_ONLY">Page.lblShowOpenAccountsOnly</parameter>
			<parameter n="PURPOSE">Page.pnlCriteria.cmbPurpose</parameter>
	    </parameters>
</popupdata>