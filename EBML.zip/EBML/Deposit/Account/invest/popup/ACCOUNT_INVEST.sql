<popupdata type="service">
	<service>ACCOUNT_LIST_INVEST_ACCOUNTS</service>
	    <parameters>
	        <parameter n="ACC_CUST_CODE">Page.pnlAccountInfo.hndCustomerCode</parameter>
	        <parameter n="ACC_ORG_CODE">Page.pnlAccountInfo.cmbAccountBranch</parameter>
	        <parameter n="ACC_CODE">Page.pnlAccountInfo.txtAccountCode</parameter>
			<parameter n="CUST_REPRESENTATIVE">Page.pnlAccountInfo.hndCustRepresantative</parameter>			
			<parameter n="ACC_LIST_TYPE">Page.lblListType</parameter>		
			<parameter n="REPORT_OR_OPERATION">Page.lblReportOrOperation</parameter>        
			<parameter n="OPERATION_TYPE">Page.lblOperation</parameter>
			<parameter n="ACC_IBAN">Page.pnlAccountInfo.txtAccountIBAN</parameter>        
	    </parameters>
</popupdata>