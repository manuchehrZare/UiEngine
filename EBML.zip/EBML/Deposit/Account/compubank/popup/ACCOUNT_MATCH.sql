<popupdata type="service">
	<service>ACCOUNT_LIST_ACCOUNTS_FOR_MATCH</service>
	    <parameters>
	        <parameter n="ACC_CUST_CODE">Page.txtCustomerNo</parameter>
	        <parameter n="ACC_ORG_CODE">Page.cmbBranch</parameter>
	        <parameter n="ACC_CODE">Page.txtAccountNo</parameter>
			<parameter n="OPERATION_TYPE">Page.lblSource</parameter>        
			<parameter n="REPORT_OR_OPERATION">Page.lblReportOrOperation</parameter>
	    </parameters>
</popupdata>