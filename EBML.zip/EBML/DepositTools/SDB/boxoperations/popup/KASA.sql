<popupdata type="service">
    <service>SDB_BOX_NO</service>
         <parameters>        
               <parameter n="CUSTOMER_CODE">Page.pnlKriter.btnMusteri</parameter> 
			   <parameter n="BRANCH_CODE">Page.pnlKriter.cmbBranch</parameter> 
			   <parameter n="BOX_NO">Page.pnlKriter.txtKasa</parameter> 
         </parameters>
</popupdata>
