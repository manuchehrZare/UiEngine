<popupdata type="service">
	<service>SA_SEARCH_CUSTOMER_DEFINITION</service>
	    <parameters>
	        <parameter n="CUSTOMER_CODE">Page.txtCustNo</parameter>
	        <parameter n="NAME">Page.txtFirstName</parameter>
	        <parameter n="SECONDNAME">Page.txtSecondName</parameter>
	        <parameter n="SURNAME">Page.txtSurname</parameter>
	        <parameter n="TRACE_DIVISION">Page.cmbTraceDivision</parameter>
	    </parameters>
</popupdata>