<popupdata type="sql">
   <sql dataSource="BankingDS">
SELECT DISTINCT T1.BUTCE_KODU ACC_BUTCEKODU,
        T1.MUSTERI_NO AS ACC_CUST_NO,
        T2.BUTCE_ACIKLAMASI_TR ACC_BUTCEADI,
		T1.HESAPNO AS ACC_NUM,
		T1.SUBE_KODU AS ACC_BRANCH,
		'806' AS ACC_TYPE,
		T1.PARA_BIRIMI AS ACC_CCY,
		T1.ADI AS ACC_NAME
    	FROM BUDGET.BUTCE_KALEM_HESAP T1,BUDGET.BUTCE_KALEMLER T2
		WHERE   ((T1.BUTCE_KODU = ?) OR (? IS NULL))
		AND      ((T1.MUSTERI_NO = ? ) OR (? IS NULL))
		AND      ((T1.HESAPNO = ? ) OR (? IS NULL))
		AND      ((T1.SUBE_KODU = ? ) OR (? IS NULL))
		AND  T2.BUTCE_YILI = ? and T1.BUTCE_KODU = T2.BUTCE_KODU
		and T1.BUTCE_YILI = T2.BUTCE_YILI
		ORDER BY 	T1.SUBE_KODU,T1.MUSTERI_NO,T1.HESAPNO
	</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.txtButceKodu</parameter>
        <parameter prefix="" suffix="">Page.txtButceKodu</parameter>
        <parameter prefix="" suffix="">Page.txtMusteriNo</parameter>
        <parameter prefix="" suffix="">Page.txtMusteriNo</parameter>
        <parameter prefix="" suffix="">Page.txtHesapNo</parameter>
        <parameter prefix="" suffix="">Page.txtHesapNo</parameter>
        <parameter prefix="" suffix="">Page.txtSubeNo</parameter>
        <parameter prefix="" suffix="">Page.txtSubeNo</parameter>
        <parameter prefix="" suffix="">Page.txtYil</parameter>
    </parameters>
</popupdata>
