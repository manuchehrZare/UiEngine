              <popupdata type="sql">
   <sql dataSource="BankingDS">
SELECT DISTINCT T1.SUBE_KODU AS SUBE_KODU,
		T1.GMENKUL_REFNO AS GMENKUL_REFNO,
		T1.TAKIP_MUSTERI_ADI AS TAKIP_MUSTERI_ADI,
		T1.ADRES AS ADRES,
		T1.OID AS OID
    	FROM BUDGET.BUTCE_GMENKULLER T1
		WHERE   ((T1.GMENKUL_REFNO = ?) OR (? IS NULL))
		    AND (((T1.CIKIS_TARIHI IS  NULL) AND (? = 0))  or 
		          (T1.CIKIS_TARIHI IS  NOT NULL) AND (? = 1))
		ORDER BY GMENKUL_REFNO
	</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.txtrefno</parameter>
        <parameter prefix="" suffix="">Page.txtrefno</parameter>
        <parameter prefix="" suffix="">Page.cmbCikis</parameter>
        <parameter prefix="" suffix="">Page.cmbCikis</parameter>
    </parameters>
</popupdata>