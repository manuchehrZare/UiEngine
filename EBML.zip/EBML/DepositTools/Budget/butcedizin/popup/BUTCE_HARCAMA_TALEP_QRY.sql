<popupdata type="service">
    <service>BUTCE_HARCAMA_TALEP_QRY</service>
    <parameters>
    	<parameter n="HARCAMA_KODU">Page.txtHarcamaKodu</parameter>
    	<parameter n="SUBE_KODU">Page.txtSubeKodu</parameter>
    	<parameter n="ISTEK_TUR">Page.cmbTur</parameter>
    	<parameter n="ISTEK_TARIHI1">Page.dateIstek1</parameter>
    	<parameter n="ISTEK_TARIHI2">Page.dateIstek2</parameter>
    	<parameter n="ODEME_DURUMU">Page.cmbOnay</parameter>
    	<parameter n="KARAR_NO">Page.txtKararNo</parameter>
    </parameters>
</popupdata>