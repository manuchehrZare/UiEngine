<popupdata type="service">
    <service>BUTCE_HARCAMA_KARAR_QRY</service>
    <parameters>
    	<parameter n="HARCAMA_KODU">Page.hndButceKodu</parameter>
    	<parameter n="SUBE_KODU">Page.hndOrg</parameter>
    	<parameter n="KARAR_NO">Page.txtKararNo</parameter>
    	<parameter n="KARAR_TARIHI1">Page.dateKarar1</parameter>
    	<parameter n="KARAR_TARIHI2">Page.dateKarar2</parameter>
    	<parameter n="ISTEK_TARIHI1">Page.dateGiris1</parameter>
    	<parameter n="ISTEK_TARIHI2">Page.dateGiris2</parameter>
    	<parameter n="ONAY_DURUMU">Page.cmbOnay</parameter>
    	<parameter n="ACIK_KAPALI">Page.cmbAcikKapali</parameter>
    </parameters>
</popupdata>