<popupdata type="service">
    <service>BUTCE_HARCAMA_FIRMALAR</service>
    <parameters>
    	<parameter n="TUR">Page.cmbKisiFirma</parameter>
    	<parameter n="MUSTERI_NO">Page.txtMusteriNo</parameter>
    	<parameter n="HESAP_NO">Page.txtHesapNo</parameter>
    	<parameter n="AD_UNVAN">Page.txtAd</parameter>
    </parameters>
</popupdata>