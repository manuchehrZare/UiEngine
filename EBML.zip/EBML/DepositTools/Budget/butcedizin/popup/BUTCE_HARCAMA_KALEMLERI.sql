<popupdata type="service">
    <service>BUTCE_HARCAMA_KALEMLERI</service>
    <parameters>
    	<parameter n="BUTCE_YILI">Page.cmbYil</parameter>
    	<parameter n="BIRIM">Page.txtBirim</parameter>
    	<parameter n="KODU">Page.txtKodu</parameter>
    	<parameter n="BUTCE_TIPI">Page.cmbTuru</parameter>
    </parameters>
</popupdata>