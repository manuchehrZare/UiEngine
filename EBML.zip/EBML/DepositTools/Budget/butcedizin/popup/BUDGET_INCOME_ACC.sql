<popupdata type="sql">
   <sql dataSource="BankingDS">
  SELECT GELIR_KODU,
       MUSTERI_NO ACC_CUST_NO,
       HESAPNO ACC_NUM,
       SUBE_KODU ACC_BRANCH,
       PARA_BIRIMI ACC_CCY,
       TUR ACC_TYPE,
       ADI ACC_NAME
  FROM BUDGET.BUTCE_GELIR_HESAP T1
		WHERE   ((T1.GELIR_KODU = ?) OR (? IS NULL))
		AND      ((T1.MUSTERI_NO = ? ) OR (? IS NULL))
		AND      ((T1.HESAPNO = ? ) OR (? IS NULL))
		AND      ((T1.SUBE_KODU = ? ) OR (? IS NULL))
		AND      ((T1.PARA_BIRIMI = ? ) OR (? IS NULL))
		AND  T1.BUTCE_YILI = ?
  ORDER BY T1.GELIR_KODU,T1.MUSTERI_NO,T1.HESAPNO
	</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.cmbGelirKodu</parameter>
        <parameter prefix="" suffix="">Page.cmbGelirKodu</parameter>
        <parameter prefix="" suffix="">Page.txtMusteriNo</parameter>
        <parameter prefix="" suffix="">Page.txtMusteriNo</parameter>
        <parameter prefix="" suffix="">Page.txtHesapNo</parameter>
        <parameter prefix="" suffix="">Page.txtHesapNo</parameter>
        <parameter prefix="" suffix="">Page.txtSubeNo</parameter>
        <parameter prefix="" suffix="">Page.txtSubeNo</parameter>
        <parameter prefix="" suffix="">Page.cmbParaBirimi</parameter>
        <parameter prefix="" suffix="">Page.cmbParaBirimi</parameter>
        <parameter prefix="" suffix="">Page.txtYil</parameter>
    </parameters>
</popupdata>
