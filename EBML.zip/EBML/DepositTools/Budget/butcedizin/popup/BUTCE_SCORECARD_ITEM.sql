<popupdata type="sql">
   <sql dataSource="BankingDS">
SELECT DISTINCT T1.KARNE_KODU,T1.KARNE_ADI
    	FROM BUDGET.BUTCE_KARNE_KALEMLERI T1
		WHERE   ((T1.KARNE_KODU = ?) OR (? IS NULL))
		AND (T1.KARNE_YILI = ?)
		ORDER BY KARNE_KODU
	</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.txtKodu</parameter>
        <parameter prefix="" suffix="">Page.txtKodu</parameter>
        <parameter prefix="" suffix="">Page.cmbYil</parameter>
    </parameters>
</popupdata>
