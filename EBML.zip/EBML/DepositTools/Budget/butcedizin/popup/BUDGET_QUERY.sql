<popupdata type="service">
    <service>BUTCE_BUTCE_KALEMLERI_LISTELE</service>
    <parameters>
    	<parameter n="BUTCE_YILI">Page.cmbYil</parameter>
    	<parameter n="KODU">Page.txtKodu</parameter>
    	<parameter n="UST_BUTCE_KODU">Page.txtUstButceKodu</parameter>
    	<parameter n="BUTCE_TIPI">Page.cmbTuru</parameter>
    </parameters>
</popupdata>