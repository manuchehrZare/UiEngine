<popupdata type="service">
    <service>BUTCE_HARCAMA_KALEM_HESAPLARI_SORGULA</service>
    <parameters>
    	<parameter n="BUTCE_YILI">Page.cmbYil</parameter>
    	<parameter n="BIRIM">Page.txtBirim</parameter>
    	<parameter n="BUTCE_KODU">Page.txtKodu</parameter>
    </parameters>
</popupdata>