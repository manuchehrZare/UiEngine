<popupdata type="service">
    <service>STOK_CORE_INFO_EXIT</service>
        <parameters>            
            <parameter n="STOKKODU">Page.pnlCriteria.txtStokKodu</parameter>
        </parameters>
</popupdata>