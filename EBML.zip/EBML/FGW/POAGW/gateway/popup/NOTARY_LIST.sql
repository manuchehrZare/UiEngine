<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT T1.OID AS NOTARY_OID, 
		   T1.CODE AS CODE, 
		   T1.NAME AS NAME
	FROM POAGW.NOTARY_CONSULAR T1 
	WHERE T1.STATUS = '1' 
	      AND T1.NOTARY_CONSULAR_TYPE='NOTARY_QUERY'
		  AND T1.CODE LIKE ? 
		  AND T1.NAME LIKE ? 
	ORDER BY T1.CODE 		</sql>
    <parameters>
        <parameter prefix="%" suffix="%">Screen.txtScreenCode</parameter>
        <parameter prefix="%" suffix="%">Screen.txtScreenName</parameter>
    </parameters>
</popupdata>
