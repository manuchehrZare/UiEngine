<popupdata type="sql">
    <sql dataSource="OlapDS">

 SELECT EKS.ekstre_id,
        EKS.ekstrenindonembastarihi, 
        EKS.ekstrenindonembittarihi, 
		EKS.ekstrenindokumtarihi, 
        EKS.musterino

 FROM aml.MSK_EKS_EKSTREBILGILERI EKS
 WHERE 
         EKS.STATUS='1' AND
     ((to_number(?) is not null and  EKS.EKSTRE_ID = to_number(?)) or (to_number(?) is null))
     
    
       
 ORDER BY    
     EKS.EKSTRE_ID
    

      </sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlFilter.txtExtreId</parameter>
		<parameter prefix="" suffix="">Page.pnlFilter.txtExtreId</parameter>
		<parameter prefix="" suffix="">Page.pnlFilter.txtExtreId</parameter>
     
    </parameters>

</popupdata>
