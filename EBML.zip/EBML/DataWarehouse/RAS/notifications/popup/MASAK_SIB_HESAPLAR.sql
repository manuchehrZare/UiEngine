<popupdata type="service">
	<service>RAS_MASAK_SIB_SEARCH_ACCOUNT</service>
	    <parameters>
	        <parameter n="MUS_NO">pgMasakSibHesaplar.txtMusNo</parameter>
	        <parameter n="MODUL">pgMasakSibHesaplar.cmbHesapTuru</parameter>
	        <parameter n="SUBE">pgMasakSibHesaplar.cmbSube</parameter>
			<parameter n="HESAP_NO">pgMasakSibHesaplar.txtHesapNo</parameter>
	        <parameter n="IBAN">pgMasakSibHesaplar.txtIban</parameter>
	    </parameters>
</popupdata>