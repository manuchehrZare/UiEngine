<popupdata type="service">
	<service>RAS_MASAK_SIB_SEARCH_TRANSACTION</service>
	    <parameters>
	        <parameter n="TC_NO">pgMasakSibIslemler.txtTcNo</parameter>
	        <parameter n="VKN">pgMasakSibIslemler.txtVergiNo</parameter>
	        <parameter n="BASLANGIC">pgMasakSibIslemler.dtBaslangic</parameter>
			<parameter n="BITIS">pgMasakSibIslemler.dtBitis</parameter>
	        <parameter n="AD_SOYAD">pgMasakSibIslemler.txtAd</parameter>
	    </parameters>
</popupdata>