<popupdata type="sql">
    <sql dataSource="OlapDS">
select CUSTOMER_CODE,DECLARATION_TITLE,case
   when individual_corporate = '1' and nationality = 'TC' then
    tc_id
   else
   tax_no
end TCKNVKN  from olap.fc_customer  where  CUSTOMER_CODE LIKE ? 
and nvl(DECLARATION_TITLE,' ') LIKE ?
and nvl(case when individual_corporate = '1' and nationality = 'TC' then tc_id else tax_no end,' ' ) LIKE ?
AND AS_OF_DATE = to_date(to_char(sysdate-3,'ddmmyyyy'), 'ddmmyyyy') order by CUSTOMER_CODE asc
	</sql>
    <parameters>
        <parameter suffix="%" >Page.txtCustomerCode</parameter>
        <parameter suffix="%">Page.txtCustomerName</parameter>
        <parameter suffix="%">Page.txtTCKNVKN</parameter>
    </parameters>
</popupdata>
