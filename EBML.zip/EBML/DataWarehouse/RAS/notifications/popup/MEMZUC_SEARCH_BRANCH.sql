<popupdata type="sql">
    <sql dataSource="OlapDS">
select ORG_CODE,COUNTY_ORDER,CITY_CODE,COUNTY_CODE,ORG_NAME,DEFAULT_BRANCH,'059'||CITY_CODE||COUNTY_CODE||COUNTY_ORDER as ORG_FULL_CODE from notification_data.pr_memzuc_org_county

where ORG_CODE LIKE ? 
AND COUNTY_ORDER LIKE ?
AND CITY_CODE LIKE ? 
AND COUNTY_CODE LIKE ? 
AND ORG_NAME LIKE ? 

	</sql>
    <parameters>
        <parameter prefix="%" suffix="%">Page.txtOrgCode</parameter>
        <parameter prefix="%" suffix="%">Page.txtCountyOrder</parameter>
        <parameter prefix="%" suffix="%">Page.txtCityCode</parameter>
	<parameter prefix="%" suffix="%">Page.txtCountyCode</parameter>
	<parameter prefix="%" suffix="%">Page.txtBranchName</parameter>
       
    </parameters>
</popupdata>
