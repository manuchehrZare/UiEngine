<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT CC.CONTRACT_NO,CC.OID AS CONTRACT_DEFINITION_OID,CC.CONTRACT_ASSET_TYPE,  CC.CONTRACT_CURRENCY_CODE,
		 CC.IS_IN_SCOPE_OF_IFRS16,CC.CONTRACT_START_DATE,CC.CONTRACT_END_DATE, CC.CONTRACT_ESTIMATED_END_DATE,
		 	(SELECT TO_CHAR(listagg(LES.LESSOR_NAME,','))
		 	FROM RENTCON.CONTRACT_DEF_LESSOR_EXTENSION LES WHERE LES.STATUS = 1 AND LES.CONTRACT_DEFINITION_OID = CC.OID) AS LESSOR_NAME_CSV ,
		 	(SELECT to_char(listagg(DISTINCT(sub_contract_no),',')) 
		 	FROM RENTCON.CONTRACT_DEF_ASSET_EXTENSION LES WHERE LES.STATUS = 1 AND LES.CONTRACT_DEFINITION_OID = CC.OID) as SUB_CONTRACT_NO_CSV ,
		 	(SELECT to_char(listagg(DISTINCT(ASSET_IDENTITY_REF_NO),',')) 
		 	FROM RENTCON.CONTRACT_DEF_ASSET_EXTENSION LES WHERE LES.STATUS = 1 AND LES.CONTRACT_DEFINITION_OID = CC.OID) as ASSET_IDENTITY_REF_NO_CSV ,
		 	(SELECT to_char(listagg(DISTINCT(ORG_CODE||'-'||ORG_NAME),',')) 
		 	FROM RENTCON.CONTRACT_DEF_ASSET_EXTENSION LES WHERE LES.STATUS = 1 AND LES.CONTRACT_DEFINITION_OID = CC.OID) as ORG_CODE_NAME_CSV 
		FROM RENTCON.CONTRACT_DEFINITION CC 
		WHERE CC.STATUS='1'
		    AND NVL(?,'NULL') IN  ('NULL',CC.CONTRACT_ASSET_TYPE) 
		    AND NVL(?,'NULL') IN  ('NULL',CC.IS_IN_SCOPE_OF_IFRS16)
			AND NVL(?,'NULL') IN  ('NULL',CC.CONTRACT_IDENTITY_REF_NO)
			AND NVL(?,'NULL') IN  ('NULL',CC.CONTRACT_NO)
		    AND EXISTS(SELECT 1 FROM RENTCON.CONTRACT_DEF_LESSOR_EXTENSION LS WHERE LS.CONTRACT_DEFINITION_OID=CC.OID AND NVL(?,'NULL') IN  ('NULL',LS.RENT_INCREASE_TYPE) )
		    AND EXISTS(SELECT 1 FROM RENTCON.CONTRACT_DEF_LESSOR_EXTENSION LS WHERE LS.CONTRACT_DEFINITION_OID=CC.OID AND NVL(?,'NULL') IN  ('NULL',LS.PAYMENT_PERIOD) )
		    AND EXISTS(SELECT 1 FROM RENTCON.CONTRACT_DEF_LESSOR_EXTENSION LS WHERE LS.CONTRACT_DEFINITION_OID=CC.OID AND NVL(?,'NULL') IN  ('NULL',LS.PAYMENT_CURRENCY_CODE) )
			AND EXISTS(SELECT 1 FROM RENTCON.CONTRACT_DEF_ASSET_EXTENSION ass where ass.CONTRACT_DEFINITION_OID=CC.OID AND NVL(?,'NULL') IN  ('NULL',ass.org_code) )
	</sql>
    <parameters>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbCONTRACT_ASSET_TYPE</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbIsInIFRS</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.txtContractIdentityRefNo</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.txtContractNo</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbRENT_INCREASE_TYPE</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbPaymentPeriod</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbPaymentCurrencyCode</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.hndBranchCode</parameter>
    </parameters>
</popupdata>