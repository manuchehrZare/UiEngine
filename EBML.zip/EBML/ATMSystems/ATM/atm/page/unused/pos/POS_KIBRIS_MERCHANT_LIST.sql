<popupdata type="sql">
    <sql dataSource="POSDS">
    	SELECT TOP 100 MRC_CODE,MRC_CUSTOMER_CODE,MRC_VERGI_KIMLIK_NO,MRC_TICARI_ADI,
    		MRC_MEVDUAT_BANKA_KOD ,MRC_MEVDUAT_SUBE_KOD ,MRC_MEVDUAT_HESAP,MRC_MEVDUAT_HESAP_DVZ,
			MRC_BLOKE_MEVDUAT_HESABI,MRC_BLOKE_BANKA_KOD,MRC_BLOKE_SUBE_KOD,MRC_BLOKE_HESAP,MRC_BLOKE_HESAP_DVZ
		FROM tblMrcMaster
		WHERE MRC_CUSTOMER_CODE LIKE ?    
		AND (MRC_CODE like ?)
	</sql>
	<parameters>
		<parameter prefix="%" suffix="%">Page.txtCustomerCode</parameter>
		<parameter prefix="%" suffix="%">Page.txtMrcCode</parameter>
	</parameters>
</popupdata>