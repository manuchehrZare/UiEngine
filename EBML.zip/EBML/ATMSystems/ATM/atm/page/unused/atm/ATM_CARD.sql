<popupdata type="service">
	<service>ATM_LIST_CARD_VIA_POPUP</service>
	    <parameters>
	        <parameter n="CUST_CODE">Page.pnlCriteria.hndCustCode</parameter>
	        <parameter n="ORG_CODE">Page.pnlCriteria.cmbOrgCode</parameter>
	        <parameter n="CARD_NO">Page.pnlCriteria.txtCardNo</parameter>
	        <parameter n="CUST_NAME">Page.pnlCriteria.txtFirstName</parameter>
	        <parameter n="CUST_SURNAME">Page.pnlCriteria.txtSurname</parameter>
	        <parameter n="APPROVE_STATUS">Page.pnlCriteria.cmbApproveStatus</parameter>
	        <parameter n="CARD_TYPE">Page.pnlCriteria.cmbCardProductType</parameter>
	        <parameter n="CARD_GROUP">Page.pnlCriteria.cmbCardGroup</parameter>	        
	        <parameter n="CARD_AUTHORIZED">Page.pnlCriteria.grpAuthorized.rbAuthorized</parameter>
	       	<parameter n="CARD_UNAUTHORIZED">Page.pnlCriteria.grpAuthorized.rbUnauthorized</parameter>	        
	        <parameter n="CARD_MAIN">Page.pnlCriteria.grpMainCard.rbMainCard</parameter>
	        <parameter n="CARD_ADDITIONAL">Page.pnlCriteria.grpMainCard.rbAdditionalCard</parameter>
	      </parameters>
</popupdata>