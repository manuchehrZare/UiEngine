<popupdata type="sql">
    <sql dataSource="ATMDS">
		SELECT convert(varchar(16),CUSTOMER_CODE) as CUSTOMER_CODE,
			KBRS_CUST_NO,
			NAME_TITLE, 
			NAME, 
			SECOND_NAME, 
			SURNAME, 
			MAIN_BRANCH_CODE 
		from dbo.tblKbrsCustDef 
		WHERE (convert(varchar(16),CUSTOMER_CODE) like ?)
			AND (KBRS_CUST_NO like ?)
			AND (NAME LIKE ?)
			AND (SURNAME LIKE ?)
			AND (MAIN_BRANCH_CODE like ?)
		ORDER BY CREATE_DATE
	</sql>
	<parameters>
		<parameter prefix="%" suffix="%">Page.pnlCriteria.hndCustCode</parameter>
	    <parameter prefix="%" suffix="%">Page.pnlCriteria.txtKbrsCustCode</parameter>
	    <parameter prefix="%" suffix="%">Page.pnlCriteria.txtFirstName</parameter>
		<parameter prefix="%" suffix="%">Page.pnlCriteria.txtSurname</parameter>
		<parameter prefix="%" suffix="%">Page.pnlCriteria.cmbOrganization</parameter>
	</parameters>
</popupdata>