<popupdata type="service">
	<service>ATM_LIST_SCREEN_DATA_FOR_POPUP</service>
	    <parameters>
	        <parameter n="VERSION">Page.pnlCriteria.cmbVersion</parameter>
	        <parameter n="SCREEN_NUMBER">Page.pnlCriteria.txtScreenNo</parameter>
	        <parameter n="SCREEN_NAME">Page.pnlCriteria.txtScreenName</parameter>      
	    </parameters>
</popupdata>