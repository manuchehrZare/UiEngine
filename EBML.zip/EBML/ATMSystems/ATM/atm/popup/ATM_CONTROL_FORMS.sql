<popupdata type="service">
	<service>ATM_LIST_CONTROL_FORMS</service>
	    <parameters>
	        <parameter n="BRANCH_NO">Page.cmbOrg</parameter>
	        <parameter n="ATM_NO">Page.txtATMNo</parameter>
	        <parameter n="FIRST_DATE">Page.dtDate1</parameter>
	        <parameter n="LAST_DATE">Page.dtDate2</parameter>		      
	    </parameters>
</popupdata>