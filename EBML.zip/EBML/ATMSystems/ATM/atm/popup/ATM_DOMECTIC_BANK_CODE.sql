<popupdata type="sql">
	<sql dataSource="BankingDS">
		SELECT BANK_CODE,BANK_NAME 
		FROM ATMSYSTEM.ATM_DOMESTIC_BANK_CODE
		WHERE (? IS NULL OR BANK_CODE = (?))
			AND (BANK_NAME like ?)
		ORDER BY BANK_CODE
	</sql>
	<parameters>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtBankCode</parameter>
			<parameter prefix="" suffix="">Page.pnlCriteria.txtBankCode</parameter>			
			<parameter prefix="%" suffix="%">Page.pnlCriteria.txtBankName</parameter>	              
	    </parameters>
	</popupdata>