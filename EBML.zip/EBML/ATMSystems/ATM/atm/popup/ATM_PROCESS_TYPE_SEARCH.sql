<popupdata type="sql">
    <sql dataSource="BankingDS">
		SELECT TYPE,DESCRIPTION
  		FROM ATMSYSTEM.ATM_PROCESS_TYPE_DEFINITION
		WHERE (TYPE like ?)
			AND (DESCRIPTION like ?)
		ORDER BY TYPE 
	</sql>
	<parameters>
		<parameter prefix="%" suffix="%">Page.pnlCriteria.txtCode</parameter>
	    <parameter prefix="%" suffix="%">Page.pnlCriteria.txtOperationName</parameter>
	</parameters>
</popupdata>