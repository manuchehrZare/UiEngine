<popupdata type="service">
	<service>ATM_VOICE_KEYBOARD_DETAILS</service>
	    <parameters>
	        <parameter n="KEYBOARD_NO">Page.pnlCriteria.txtKeyboardNo</parameter>
	        <parameter n="VERSION">Page.pnlCriteria.cmbVersion</parameter>   
	    </parameters>
</popupdata>