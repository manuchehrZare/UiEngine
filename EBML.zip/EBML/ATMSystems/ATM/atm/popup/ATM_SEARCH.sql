<popupdata type="service">
	<service>ATM_LIST</service>
	    <parameters>
	        <parameter n="ATM_NO">Page.pnlCriteria.txtATMNo</parameter>
	        <parameter n="ATM_NAME">Page.pnlCriteria.txtATMName</parameter>
	        <parameter n="BRANCH_NO">Page.pnlCriteria.cmbOrgCode</parameter>
	        <parameter n="ATM_CITY">Page.pnlCriteria.cmbCity</parameter>		      
	    </parameters>
</popupdata>