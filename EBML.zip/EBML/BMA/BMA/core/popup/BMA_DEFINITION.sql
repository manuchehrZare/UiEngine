<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
SELECT D.OID ,D.BMA_DEFINITION_NO , D.DEPT_TYPE , D.COLLECTION_ACCOUNT_TYPE , D.COLLECTION_TYPE , D.PARTITION_ALLOWED , D.CREDITOR_TYPE , D.IS_ACTIVE
     , D.DEPTOR_CURRENCY_TYPE , nvl(D.INSTALLMENT_TYPE,'0') INSTALLMENT_TYPE , nvl(D.IS_MANUALLY_GENERATEBLE,0) IS_MANUALLY_GENERATEBLE
     , NVL(DA.INTEREST_RATE_BMA_BASED,D.INTEREST_RATE_BMA_BASED) INTEREST_RATE_BMA_BASED, D.IS_EFT
  FROM INFRA.BMA_DEFINITION D
     , (SELECT * FROM INFRA.BMA_DEFINITION DA WHERE DA.IS_ACTIVE = 'A') DA
  WHERE (D.DEPT_TYPE LIKE ? OR ? IS NULL)
    AND (D.COLLECTION_ACCOUNT_TYPE = ? OR ? IS NULL)
    AND (D.COLLECTION_TYPE = ? OR ? IS NULL)
    AND (D.OID = ? OR (? IS NULL AND (D.IS_ACTIVE = ? OR ? IS NULL)))
    AND (D.CREDITOR_TYPE = ? OR ? IS NULL)
    AND (D.PARTITION_ALLOWED = ? OR ? IS NULL)
    AND (D.BMA_DEFINITION_NO = ? OR ? = 0)
    AND (D.DEPTOR_CURRENCY_TYPE = ? OR ? IS NULL)
    AND (NVL(D.IS_MANUALLY_GENERATEBLE,'0')=? or ? IS NULL)
    AND D.DEPT_TYPE = DA.DEPT_TYPE(+)
    AND ( d.interest_rate_bma_based = ? OR ? IS NULL)
  ORDER BY D.BMA_DEFINITION_NO  
    </sql>
    <parameters>
        <parameter>Page.pnlCriteria.txtDeptType</parameter>
        <parameter>Page.pnlCriteria.txtDeptType</parameter>

        <parameter>Page.pnlCriteria.cmbCollectionAccountTypes</parameter>
        <parameter>Page.pnlCriteria.cmbCollectionAccountTypes</parameter>

        <parameter>Page.pnlCriteria.cmbCollectionType</parameter>
        <parameter>Page.pnlCriteria.cmbCollectionType</parameter>

        <parameter>Page.pnlCriteria.txtOid</parameter>
        <parameter>Page.pnlCriteria.txtOid</parameter>        

        <parameter>Page.pnlCriteria.cmbActivationState</parameter>
        <parameter>Page.pnlCriteria.cmbActivationState</parameter>        

        <parameter>Page.pnlCriteria.cmbCreditorAccountType</parameter>        
        <parameter>Page.pnlCriteria.cmbCreditorAccountType</parameter>

        <parameter>Page.pnlCriteria.cmbPartialCollectionTypes</parameter>
        <parameter>Page.pnlCriteria.cmbPartialCollectionTypes</parameter>  

        <parameter>Page.pnlCriteria.cfBmaDefinitionNo</parameter>
        <parameter>Page.pnlCriteria.cfBmaDefinitionNo</parameter>  

        <parameter>Page.pnlCriteria.cmbCurrencyCode</parameter>
        <parameter>Page.pnlCriteria.cmbCurrencyCode</parameter>  

        <parameter>Page.pnlCriteria.chkIsManuallyGenerateble</parameter>
        <parameter>Page.pnlCriteria.chkIsManuallyGenerateble</parameter>  

        <parameter>Page.pnlCriteria.txtInterestRateBMABased</parameter>
        <parameter>Page.pnlCriteria.txtInterestRateBMABased</parameter>  

    </parameters>
</popupdata>