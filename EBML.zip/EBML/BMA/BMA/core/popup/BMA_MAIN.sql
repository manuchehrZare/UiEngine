<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
SELECT BM.OID , BD.DEPT_TYPE , BM.BMA_REFERENCE_NO , BM.BUSINESS_REFERENCE_NO , BM.REFERENCE_ID
     , BM.CUSTOMER_CODE , BM.BRANCH_CODE , BM.STATE , BM.COLLECTION_STATE , BM.AMOUNT , BM.CURRENCY_CODE
     , BT.TRANSACTION_DATE , BM.BMA_DEFINITION_OID , BT.PROCESS_ID CREATOR_PROCESS_ID
  FROM INFRA.BMA_MAIN BM 
     , INFRA.BMA_DEFINITION BD
     , INFRA.BMA_TRANSACTIONS BT
  WHERE BM.STATUS = '1'
    AND BD.STATUS = '1'
    AND BT.STATUS = '1'
    AND BM.BMA_DEFINITION_OID = BD.OID
    AND BT.BMA_MAIN_OID = BM.OID
    AND (BT.PROCESS_ID = '28955' OR BT.PROCESS_ID = '28956')
    AND (BM.BMA_REFERENCE_NO = ? OR ? IS NULL)
    AND (BD.DEPT_TYPE = ? OR ? IS NULL)
    AND (BM.BUSINESS_REFERENCE_NO = ? OR ? IS NULL)
    AND (BM.REFERENCE_ID = ? OR ? IS NULL)
    AND (BM.BRANCH_CODE = ? OR ? IS NULL)
    AND (BM.CUSTOMER_CODE = ? OR ? IS NULL)
    AND (BM.STATE = ? OR ? IS NULL)
    AND (BM.COLLECTION_STATE = ? OR ? IS NULL)
    AND (BM.AMOUNT >= ? OR ? = 0)
    AND (BM.AMOUNT <= ? OR ? = 0)
    AND (BM.CURRENCY_CODE = ? OR ? IS NULL)
    AND (BT.TRANSACTION_DATE >= ? OR ? IS NULL)
    AND (BT.TRANSACTION_DATE <= ? OR ? IS NULL)
  ORDER BY BM.BMA_REFERENCE_NO
    </sql>
    <parameters>
        <parameter>Page.pnlCriteria.txtBMANo</parameter>
        <parameter>Page.pnlCriteria.txtBMANo</parameter>

        <parameter>Page.pnlCriteria.hbBMADeptType</parameter>
        <parameter>Page.pnlCriteria.hbBMADeptType</parameter>

        <parameter>Page.pnlCriteria.txtBusinessReferenceNo</parameter>
        <parameter>Page.pnlCriteria.txtBusinessReferenceNo</parameter>
        
        <parameter>Page.pnlCriteria.txtReferenceNo</parameter>
        <parameter>Page.pnlCriteria.txtReferenceNo</parameter>

        <parameter>Page.pnlCriteria.cmbBranch</parameter>
        <parameter>Page.pnlCriteria.cmbBranch</parameter>

        <parameter>Page.pnlCriteria.hbCustomerCode</parameter>
        <parameter>Page.pnlCriteria.hbCustomerCode</parameter>
        
        <parameter>Page.pnlCriteria.cmbState</parameter>
        <parameter>Page.pnlCriteria.cmbState</parameter>

        <parameter>Page.pnlCriteria.cmbCollectionState</parameter>
        <parameter>Page.pnlCriteria.cmbCollectionState</parameter>

        <parameter>Page.pnlCriteria.cfAmountMin</parameter>
        <parameter>Page.pnlCriteria.cfAmountMin</parameter>

        <parameter>Page.pnlCriteria.cfAmountMax</parameter>
        <parameter>Page.pnlCriteria.cfAmountMax</parameter>

        <parameter>Page.pnlCriteria.cmbCurrencyCode</parameter>
        <parameter>Page.pnlCriteria.cmbCurrencyCode</parameter>

        <parameter>Page.pnlCriteria.dfValidationDateBegin</parameter>
        <parameter>Page.pnlCriteria.dfValidationDateBegin</parameter>

        <parameter>Page.pnlCriteria.dfValidationDateEnd</parameter>
        <parameter>Page.pnlCriteria.dfValidationDateEnd</parameter>
    </parameters>
</popupdata>