<popupdata type="service">
	<service>CONS_LIST_POLICY_RULE</service>
<parameters>
    <parameter n="CONTROL_CODE">Page.PnlCriteria.cmbControlPlace</parameter>
    <parameter n="EXPLANATION">Page.PnlCriteria.txtExplanation</parameter>
	<parameter n="ACTION">Page.PnlCriteria.cmbActionResult</parameter>
</parameters>
</popupdata>
