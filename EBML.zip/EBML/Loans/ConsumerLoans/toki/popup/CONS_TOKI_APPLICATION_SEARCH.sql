<popupdata type="service">
	<service>CONS_TOKI_LIST_APPLICATION</service>
	    <parameters>
			<parameter n="CUST_CODE">Page.pnlCriteria.hndCustcode</parameter>
			<parameter n="APPLICATION_NO">Page.pnlCriteria.txtApplicationNo</parameter>
			<parameter n="BRANCH_CODE">Page.pnlCriteria.cmbBranchCode</parameter>
			<parameter n="STATUS_CODE">Page.lblApplicationStatusCode</parameter>
		</parameters>
</popupdata>