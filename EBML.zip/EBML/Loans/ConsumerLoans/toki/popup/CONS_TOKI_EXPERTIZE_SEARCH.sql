<popupdata type="service">
	<service>CONS_TOKI_EXPERTIZE_REQUEST_QUERY</service>
	    <parameters>
			<parameter n="PROJECT_CODE">Page.pnlExp.hndProjectCode</parameter>
			<parameter n="REQUESTING_BRANCH_CODE">Page.pnlExp.cmbRequestingBranchCode</parameter>
			<parameter n="EXP_REF_NO">Page.pnlExp.txtExpRefNo</parameter>
			<parameter n="DT_BEGIN">Page.pnlExp.dtBegin</parameter>
			<parameter n="STATE">Page.pnlExp.cmbState</parameter>
			<parameter n="STATE_LABEL">Page.pnlExp.lblExpState</parameter>
			<parameter n="COOP_QUERY_MODE">Page.pnlExp.lblCoopQueryMode</parameter>
		</parameters>
</popupdata>
