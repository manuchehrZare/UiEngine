<popupdata type="service">
	<service>CONS_TOKI_LIST_LOANS</service>
	    <parameters>

			<parameter n="PROJECT_CODE">Page.pnlLoans.txtProjectCode</parameter>
			<parameter n="CUST_CODE">Page.pnlLoans.hndCustCode</parameter>
			<parameter n="PRODUCT_CODE">Page.pnlLoans.cmbProductCode</parameter>
			<parameter n="LOANS_REF_NO">Page.pnlLoans.txtLoansRefNo</parameter>
			<parameter n="LOANS_STATE">Page.pnlLoans.cmbLoansStatus</parameter>
			<parameter n="MEMBER_NO_1">Page.pnlLoans.txtMemberNo1</parameter>
			<parameter n="MEMBER_NO_2">Page.pnlLoans.txtMemberNo2</parameter>
            <parameter n="LOANS_TYPE">Page.pnlLoans.cmbLoansType</parameter>
            <parameter n="LOANS_BRANCH_CODE">Page.pnlLoans.cmbBranchCode</parameter>
            <parameter n="LOANS_ACC_OID">Page.pnlLoans.txtPayAccOid</parameter>
            <parameter n="MEMBER_NAME">Page.pnlLoans.txtMemberName</parameter>
		</parameters>
</popupdata>



