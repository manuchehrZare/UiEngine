<popupdata type="service">
	<service>CONS_TOKI_USAGE_REQUEST_QUERY</service>
	    <parameters>
			<parameter n="EXP_REF_NO">Page.pnlUsage.hndExpReq</parameter>
			<parameter n="USAGE_REF_NO">Page.pnlUsage.txtUsageRefNo</parameter>
			<parameter n="TOKI_REQUEST_DATE">Page.pnlUsage.dtTOKIRequest</parameter>
			<parameter n="USAGE_STATUS">Page.pnlUsage.lblUsageMode</parameter>
		</parameters>
</popupdata>