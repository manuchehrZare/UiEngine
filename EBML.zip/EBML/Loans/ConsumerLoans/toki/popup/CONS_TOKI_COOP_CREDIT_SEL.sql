<popupdata type="service">
	<service>CONS_TOKI_COOP_LOANS_QUERY</service>
	    <parameters>
			<parameter n="PROJECT_CODE">Page.pnlCoopLoansRef.hndProjectCode</parameter>
			<parameter n="CUST_CODE">Page.pnlCoopLoansRef.hndCustCode</parameter>
			<parameter n="PRODUCT_CODE">Page.pnlCoopLoansRef.cmbProductCode</parameter>
			<parameter n="COOP_LOANS_REF_NO">Page.pnlCoopLoansRef.txtLoansRefNo</parameter>
			<parameter n="COOP_QUERY_MODE">Page.pnlCoopLoansRef.lblCoopQueryMode</parameter>
		</parameters>
</popupdata>
