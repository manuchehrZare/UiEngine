<popupdata type="service">
	<service>CONS_TOKI_LIST_COOP</service>
	    <parameters>

			<parameter n="PROJECT_CODE">Page.pnlCoop.txtProjectCode</parameter>
			<parameter n="CUST_CODE">Page.pnlCoop.hndCustcode</parameter>
			<parameter n="CITY_CODE">Page.pnlCoop.cmbCityCode</parameter>
			<parameter n="MAIN_BRANCH_CODE">Page.pnlCoop.cmbBranchCode</parameter>
			<parameter n="COOP_QUERY_MODE">Page.pnlCoop.lblCoopQueryMode</parameter>
		</parameters>
</popupdata>