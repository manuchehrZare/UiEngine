<popupdata type="service">
	<service>CONS_CAMPAIGN_LIST_GROUP_FOR_POPUP</service>
    	<parameters>
	        <parameter n="GROUP_CODE">Page.txtGroupCode</parameter>
	        <parameter n="GROUP_NAME">Page.txtGroupName</parameter>
	    </parameters>
</popupdata>
