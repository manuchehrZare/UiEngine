<popupdata type="service">
	<service>CONS_CAMPAIGN_LIST_CAMPAIGNS_OF_CUSTOMER_FOR_POPUP</service>
    	<parameters>
	        <parameter n="CAMPAIGN_CODE">Page.txtCampaignCode</parameter>
	        <parameter n="CAMPAIGN_NAME">Page.txtCampaignName</parameter>
	        <parameter n="CAMPAIGN_TYPE">Page.cmbCampaignType</parameter>
            <parameter n="CAMPAIGN_STRATEGY">Page.cmbCampaignStrategy</parameter>
	        <parameter n="CURRENCY_CODE">Page.cmbCurrencyType</parameter>
	        <parameter n="PRODUCT_TYPE">Page.cmbProductType</parameter>
	        <parameter n="PRODUCT_CODE">Page.cmbProduct</parameter>
	        <parameter n="CUST_CODE">Page.txtCustomerCode</parameter>
	        <parameter n="CAMPAIGN_OID">Page.lblCampaignOID</parameter>
	        <parameter n="ORG_CODE">Page.lblOrgCode</parameter>
	        <parameter n="RESTRICTION_CUSTOMER_TYPE">Page.lblRestrictionCustomerType</parameter>
	        <parameter n="GET_ALL">Page.lblGetAll</parameter>
	        <parameter n="GROUP_OID">Page.lblGroupOid</parameter>
 			<parameter n="ADK_STATUS">Page.txtAdkStatus</parameter>
	    </parameters>
</popupdata>