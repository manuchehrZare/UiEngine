<popupdata type="service">
	<service>CONS_CAMPAIGN_LIST_SELLER_FOR_POPUP</service>
    	<parameters>
	        <parameter n="CAMPAIGN_CODE">Page.txtCampaignCode</parameter>
			<parameter n="SELLER_CUST_CODE">Page.txtCustCode</parameter>
			<parameter n="CUST_CODE">Page.hndCustCode</parameter>
			<parameter n="BUSINESS_AREA">Page.cmbBusinessArea</parameter>
			<parameter n="SELLER_TYPE">Page.cmbSellerType</parameter>
			<parameter n="ADK_STATUS">Page.adkLabel</parameter>
	    </parameters>
</popupdata>