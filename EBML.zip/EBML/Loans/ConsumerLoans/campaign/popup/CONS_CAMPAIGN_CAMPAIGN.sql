<popupdata type="service">
	<service>CONS_CAMPAIGN_LIST_FOR_POPUP</service>
    	<parameters>
	        <parameter n="CAMPAIGN_CODE">Page.txtCampaignCode</parameter>
	        <parameter n="CAMPAIGN_NAME">Page.txtCampaignName</parameter>
	        <parameter n="START_DATE">Page.dtStart</parameter>
	        <parameter n="END_DATE">Page.dtEnd</parameter>
	        <parameter n="CAMPAIGN_TYPE">Page.cmbCampaignType</parameter>
	        <parameter n="CURRENCY_CODE">Page.cmbCurrencyType</parameter>
	        <parameter n="PRODUCT_TYPE">Page.cmbProductType</parameter>
	        <parameter n="PRODUCT_CODE">Page.cmbProduct</parameter>
	        <parameter n="CAMPAIGN_VALID_TODAY">Page.chkCampaignValidToday</parameter>
	        <parameter n="CAMPAIGN_STRATEGY">Page.cmbCampaignStrategy</parameter>
	        <parameter n="ORG_CODE">Page.lblOrgCode</parameter>
	        <parameter n="ORG_TYPE">Page.lblOrgType</parameter>
	        <parameter n="GROUP_OID">Page.lblGroupOid</parameter>
	        <parameter n="CAMPAIGN_STATUS">Page.lblCampaignStatus</parameter>
	        
	    </parameters>
</popupdata>