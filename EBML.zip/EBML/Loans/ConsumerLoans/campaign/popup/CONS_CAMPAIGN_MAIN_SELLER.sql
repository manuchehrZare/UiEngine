<popupdata type="service">
	<service>CONS_CAMPAIGN_GET_SELLER</service>
    	<parameters>
	        <parameter n="SELLER_OID">Page.lblSellerOID</parameter>	        
	    </parameters>
</popupdata>