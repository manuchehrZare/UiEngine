<popupdata type="sql">
<sql dataSource="BankingDS">
	select
	T1.OID AS OID,
T1.CUST_CODE AS CUST_CODE,
T1.OWNER_ORGANIZATION AS OWNER_ORGANIZATION,
T1.TYPE AS TYPE,
T1.BUSINESS_AREA AS BUSINESS_AREA,
T1.NAME_SURNAME AS CONTACT_NAME,
T1.CONTACT_MAIL AS CONTACT_MAIL,
T1.CONTACT_TEL AS CONTACT_TEL,
T1.CONTACT_FAX AS CONTACT_FAX,
T1.EXTENTION AS EXTENSION,
(CASE 
           WHEN INDIVIDUAL = 1 AND CORPORATE = 1 THEN CONCAT(TITLE,CONCAT(' ',CONCAT(CONCAT(' ',CONCAT(NAME,CONCAT(' ',SECOND_NAME))),SURNAME)))
           WHEN CORPORATE = 1 THEN CONCAT('',TITLE)
           WHEN INDIVIDUAL = 1 THEN CONCAT(CONCAT(NAME,CONCAT(' ',SECOND_NAME)),CONCAT(' ',SURNAME))
           ELSE ''
           END) AS CUST_TITLE
           
	from 	CONS.CAMPAIGN_SELLER T1,
	INFRA.CUST_CUST_CUST		T2
	where 	T1.STATUS = '1'
AND T1.CUST_CODE LIKE ?
AND T1.TYPE LIKE ? 
AND T1.BUSINESS_AREA LIKE ? 
AND T1.OID LIKE ?
AND T1.OWNER_ORGANIZATION LIKE ?
AND	T1.CUST_CODE = T2.CUSTOMER_CODE
</sql>
    <parameters>
  	   <parameter prefix="" suffix="%">Page.hndCustomerCode</parameter>
        <parameter prefix="" suffix="%">Page.cmbSellerType</parameter>
        <parameter prefix="" suffix="%">Page.cmbBusinessArea</parameter>
        <parameter prefix="" suffix="%">Page.lblSellerOID</parameter>
        <parameter prefix="" suffix="%">Page.rgBranchCode.Page.cmbBranchCode</parameter>
   </parameters>
</popupdata>
