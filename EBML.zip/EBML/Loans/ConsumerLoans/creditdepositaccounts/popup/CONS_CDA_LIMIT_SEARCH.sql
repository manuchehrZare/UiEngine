<popupdata type="service">
	<service>CONS_CDA_SEARCH_POPUP</service>
<parameters>
    <parameter n="CUSTOMER_CODE">Page.txtCustomerCode</parameter>
    <parameter n="APPLICATION_NO">Page.txtApplicationNo</parameter>
</parameters>
</popupdata>
