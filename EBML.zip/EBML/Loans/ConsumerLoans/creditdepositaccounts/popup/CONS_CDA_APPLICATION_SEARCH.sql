<popupdata type="service">
	<service>CONS_CDA_FILL_APP_POPUP</service>
<parameters>
    <parameter n="CUSTOMER_CODE">Page.hndCustomerNo</parameter>
    <parameter n="APPLICATION_NO">Page.txtApplicationNo</parameter>
	<parameter n="STATUS_CODE">Page.cmbStatusCode</parameter>
	<parameter n="BRANCH_CODE">Page.cmbBranchCode</parameter>
</parameters>
</popupdata>
