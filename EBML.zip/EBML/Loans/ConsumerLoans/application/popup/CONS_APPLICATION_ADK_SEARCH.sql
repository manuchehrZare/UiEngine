<popupdata type="service">
	<service>CONS_APPLICATION_ADK_LIST_FOR_POPUP</service>
	<parameters>
	    <parameter n="APPLICATION_NO">Page.txtAppNo</parameter>
	    <parameter n="CUST_CODE">Page.hndCustCode</parameter>
		<parameter n="CHANNEL_CODE">Page.cmbChannelCode</parameter>
		<parameter n="STATUS_CODE">Page.cmbStatusCode</parameter>
		<parameter n="CREDIT_CODE">Page.hndCreditCode</parameter>
		<parameter n="BEGIN_DATE">Page.startDate</parameter>
		<parameter n="END_DATE">Page.endDate</parameter>
		<parameter n="APP_TYPE">Page.cmbAppType</parameter>
	</parameters>
</popupdata>