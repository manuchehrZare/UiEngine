<popupdata type="service">
	<service>CONS_APPLICATION_POPUP_LIST</service>
<parameters>
    <parameter n="CUSTOMER_CODE">Page.hndCustomerNo</parameter>
    <parameter n="APPLICATION_NO">Page.txtApplicationNo</parameter>
	<parameter n="STATUS_CODE">Page.cmbStatusCode</parameter>
	<parameter n="CURRENCY_CODE">Page.cmbCurrencyCode</parameter>
	<parameter n="BRANCH_CODE">Page.cmbBranchCode</parameter>
	<parameter n="CHANNEL_CODE">Page.cmbChannelCode</parameter>
	<parameter n="PRODUCT_MAIN_GROUP_CODE">Page.cmbProductType</parameter>
	<parameter n="PRODUCT_GROUP_CODE">Page.cmbProductGroup</parameter>
	<parameter n="PRODUCT_CODE">Page.cmbProduct</parameter>
	<parameter n="MALIK_CUST_CODE">Page.hndMalikCustomerNo</parameter>
	<parameter n="IGNORED_STATUS_CODE">Page.txtIgnoredStatus</parameter>
	<parameter n="STATUS_CODE_LIST">Page.txtStatusCodeList</parameter>  
	<parameter n="IS_KDS_EXCEPTION">Page.lbIsKDSException</parameter>
</parameters>
</popupdata>
