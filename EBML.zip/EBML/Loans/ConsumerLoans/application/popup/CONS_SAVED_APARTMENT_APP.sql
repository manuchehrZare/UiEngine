<popupdata type="service">
	<service>CONS_APPLICATION_LIST_SAVED_APARTMENT_APPLICATIONS</service>
<parameters>
    <parameter n="CUSTOMER_CODE">Page.hndCustomerCode</parameter>
    <parameter n="BRANCH_CODE">Page.cmbBranchCode</parameter>
	<parameter n="VALID_STATUS">Page.cmbValidStatus</parameter>
	<parameter n="FIRST_DATE">Page.dtDateFirst</parameter>
	<parameter n="LAST_DATE">Page.dtDateLast</parameter>
</parameters>
</popupdata>
