<popupdata type="sql">
<sql dataSource="BankingDS">
	(select cust.CUSTOMER_CODE "CUSTOMER_NO",
	       TRIM(custInd.NAME||' '||custInd.SECOND_NAME||' '||custInd.SURNAME) "CUSTOMER_TITLE",
		   app.APPLICATION_NO "APPLICATION_NO",
		   app.STATUS_CODE "STATUS_CODE",
		   app.BRANCH_CODE "BRANCH_CODE",
		   app.OID "APPLICATION_OID",
		   cust.CUSTOMER_TYPE "CUSTOMER_TYPE",
		   cust.CUSTOMER_OID "CUSTOMER_OID",
		   app.PRODUCT_TYPE_CODE "PRODUCT_TYPE_CODE",
		   app.PRODUCT_GROUP_CODE "PRODUCT_GROUP_CODE",
		   prd_grp.PRODUCT_GROUP_NAME "PRODUCT_GROUP_NAME",
		   app.PRODUCT_CODE "PRODUCT_CODE",
		   prd_prd.PRODUCT_NAME "PRODUCT_NAME"		   
	from CONS.CDA_APPLICATION_MAIN app,
		CONS.APPLICATION_CUST_CUST cust,
		CONS.APPLICATION_CUST_IND custInd,
 		INFRA.PROD_PRODUCT_NEW prd_prd,
		INFRA.PROD_PRODUCT_GROUP prd_grp
	where cust.CUSTOMER_CODE=app.CUST_CODE
	and cust.APPLICATION_OID=app.OID
	and cust.CUSTOMER_OID=custInd.CUSTOMER_OID
	and custInd.APPLICATION_OID=app.OID
	and app.PRODUCT_TYPE_CODE = prd_grp.PRODUCT_MAIN_GROUP_CODE
	and app.PRODUCT_GROUP_CODE= prd_grp.PRODUCT_GROUP_CODE
	and app.PRODUCT_TYPE_CODE = prd_prd.MAIN_GROUP_CODE
	and prd_prd.MAIN_GROUP_CODE = app.PRODUCT_TYPE_CODE
	and prd_prd.GROUP_CODE = app.PRODUCT_GROUP_CODE
	and prd_prd.PRODUCT_CODE = app.PRODUCT_CODE
	and cust.CUSTOMER_CODE like ?
	and app.APPLICATION_NO like ?
	and app.STATUS_CODE like ?
	and app.BRANCH_CODE like ?
	and app.PRODUCT_TYPE_CODE like ?
	and app.PRODUCT_GROUP_CODE like ?
	and app.PRODUCT_CODE like ?
	and cust.STATUS ='1'
	and app.STATUS = '1'
	and prd_prd.STATUS = '1'
	and prd_grp.STATUS = '1'
	and custInd.STATUS = '1'
	--order by to_number(app.APPLICATION_NO)
	UNION
	select cust.CUSTOMER_CODE "CUSTOMER_NO",
	       TRIM(custCorp.COMMERCE_TITLE) "CUSTOMER_TITLE",
		   app.APPLICATION_NO "APPLICATION_NO",
		   app.STATUS_CODE "STATUS_CODE",
		   app.BRANCH_CODE "BRANCH_CODE",
		   app.OID "APPLICATION_OID",
		   cust.CUSTOMER_TYPE "CUSTOMER_TYPE",
		   cust.CUSTOMER_OID "CUSTOMER_OID",
		   app.PRODUCT_TYPE_CODE "PRODUCT_TYPE_CODE",
		   app.PRODUCT_GROUP_CODE "PRODUCT_GROUP_CODE",
		   prd_grp.PRODUCT_GROUP_NAME "PRODUCT_GROUP_NAME",
		   app.PRODUCT_CODE "PRODUCT_CODE",
		   prd_prd.PRODUCT_NAME "PRODUCT_NAME"		   
	from CONS.CDA_APPLICATION_MAIN app,
		CONS.APPLICATION_CUST_CUST cust,
		CONS.APPLICATION_CUST_CORP custCorp,
 		INFRA.PROD_PRODUCT_NEW prd_prd,
		INFRA.PROD_PRODUCT_GROUP prd_grp
	where cust.CUSTOMER_CODE=app.CUST_CODE
	and cust.APPLICATION_OID=app.OID
	and custCorp.CUSTOMER_OID=cust.CUSTOMER_OID
	and custCorp.APPLICATION_OID=app.OID
	and app.PRODUCT_TYPE_CODE = prd_grp.PRODUCT_MAIN_GROUP_CODE
	and app.PRODUCT_GROUP_CODE= prd_grp.PRODUCT_GROUP_CODE
	and app.PRODUCT_TYPE_CODE = prd_prd.MAIN_GROUP_CODE
	and prd_prd.MAIN_GROUP_CODE = app.PRODUCT_TYPE_CODE
	and prd_prd.GROUP_CODE = app.PRODUCT_GROUP_CODE
	and prd_prd.PRODUCT_CODE = app.PRODUCT_CODE
	and cust.CUSTOMER_CODE like ?
	and app.APPLICATION_NO like ?
	and app.STATUS_CODE like ?
	and app.BRANCH_CODE like ?
	and app.PRODUCT_TYPE_CODE like ?
	and app.PRODUCT_GROUP_CODE like ?
	and app.PRODUCT_CODE like ?
	and cust.STATUS ='1'
	and app.STATUS = '1'
	and prd_prd.STATUS = '1'
	and prd_grp.STATUS = '1'
	and custCorp.STATUS = '1'
	--order by to_number(app.APPLICATION_NO)
	)
	order by APPLICATION_NO
</sql>
    <parameters>
    <parameter prefix="" suffix="%">Page.hndCustomerNo</parameter>
    <parameter prefix="" suffix="%">Page.txtApplicationNo</parameter>
	<parameter prefix="" suffix="%">Page.cmbStatusCode</parameter>
	<parameter prefix="" suffix="%">Page.cmbBranchCode</parameter>
	<parameter prefix="" suffix="%">Page.cmbProductType</parameter>
	<parameter prefix="" suffix="%">Page.cmbProductGroup</parameter>
	<parameter prefix="" suffix="%">Page.cmbProduct</parameter>
    <parameter prefix="" suffix="%">Page.hndCustomerNo</parameter>
    <parameter prefix="" suffix="%">Page.txtApplicationNo</parameter>
	<parameter prefix="" suffix="%">Page.cmbStatusCode</parameter>
	<parameter prefix="" suffix="%">Page.cmbBranchCode</parameter>
	<parameter prefix="" suffix="%">Page.cmbProductType</parameter>
	<parameter prefix="" suffix="%">Page.cmbProductGroup</parameter>
	<parameter prefix="" suffix="%">Page.cmbProduct</parameter>
	
    </parameters>
</popupdata>
