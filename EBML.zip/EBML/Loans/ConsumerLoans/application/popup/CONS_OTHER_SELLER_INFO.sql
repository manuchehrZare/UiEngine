<popupdata type="service">
	<service>CONS_OTHER_APP_INFO_LIST_BY_TC_TAX</service>
	<parameters>
            <parameter n="TC_ID">Page.txtTCNo</parameter>
	</parameters>
</popupdata>