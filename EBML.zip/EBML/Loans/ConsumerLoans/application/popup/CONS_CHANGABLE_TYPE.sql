<popupdata type="service">
	<service>CONS_ADMIN_ADD_CHANGEABLE_INSURANCE</service>
<parameters>
			<parameter n="PRODUCT_GROUP_CODE">Page.txtProductGroupCode</parameter>
			<parameter n="PRODUCT_CODE">Page.txtProductCode</parameter>	        
			<parameter n="CAMPAIGN_CODE">Page.txtCampaignCode</parameter>	        						
			<parameter n="PRODUCT_MAIN_GROUP_CODE">Page.txtProductMainGroupCode</parameter>			
			<parameter n="CUSTOMER_CODE">Page.txtCustomerCode</parameter>
			<parameter n="CUST_CUST_CUSTOMER_CODE">Page.txtCustomerCode</parameter>
			<parameter n="RECURSIVE">Page.txtRecursive</parameter>
			<parameter n="INSURANCE_TYPE">Page.txtInsuranceType</parameter>
			<parameter n="IS_MANDATORY">Page.txtMand</parameter>
			<parameter n="FILL_POPUP_FROM_CONS202">Page.txtFrom</parameter>
			</parameters>
</popupdata>
