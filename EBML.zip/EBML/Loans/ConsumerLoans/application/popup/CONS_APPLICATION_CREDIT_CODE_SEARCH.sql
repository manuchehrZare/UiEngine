<popupdata type="sql">

<sql dataSource="BankingDS">

/* Formatted on 2009/05/14 16:12 (Formatter Plus v4.8.8) */
SELECT   t1.product_main_group_code AS product_main_group_code,
         t1.product_group_code AS product_group_code,
         t2.product_group_name AS product_group_name,
         t1.product_code AS product_code, 
         t3.product_name AS product_name,
         t1.credit_code AS credit_code, 
         t1.OID AS credit_oid,
         t1.credit_code_def AS credit_desc,
         t1.default_credit_code AS default_credit_code,
         t1.VALID_STATUS,
         t1.REFERENCE_ID,
		 t1.ACTIVE
    FROM cons.app_adk_def t1,
         infra.prod_product_group t2,
         infra.prod_product_new t3
   WHERE t1.credit_code LIKE ?
     AND t1.product_code LIKE ?
     AND t1.product_group_code LIKE ?
     AND t1.product_main_group_code LIKE ?
     AND t1.status = '1'
     AND t1.valid_status = '1'
     AND t2.status = '1'
     AND t3.status = '1'
     AND t1.product_group_code = t2.product_group_code
     AND t1.product_group_code = t3.group_code
     AND t1.product_code = t3.product_code
     AND t2.product_group_code = t1.product_group_code
     AND t2.product_main_group_code = t1.product_main_group_code
     AND t3.main_group_code = t1.product_main_group_code
     AND t3.group_code = t1.product_group_code
GROUP BY t1.product_main_group_code,
         t1.product_group_code,
         t2.product_group_name,
         t1.product_code,
         t3.product_name,
         t1.credit_code,
         t1.OID,
         t1.credit_code_def,
         t1.default_credit_code,
         t1.VALID_STATUS,
         t1.REFERENCE_ID,
		 t1.ACTIVE

</sql>
    <parameters>
  	    <parameter prefix="" suffix="%">Page.txtCreditCode</parameter>
        <parameter prefix="" suffix="%">Page.cmbProduct</parameter>
        <parameter prefix="" suffix="%">Page.cmbProductGroupCode</parameter>
        <parameter prefix="" suffix="%">Page.cmbMainProductGroupCode</parameter>
   </parameters>
</popupdata>
