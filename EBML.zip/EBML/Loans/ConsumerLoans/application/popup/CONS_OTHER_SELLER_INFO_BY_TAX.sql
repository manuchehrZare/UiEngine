<popupdata type="service">
	<service>CONS_OTHER_APP_INFO_LIST_BY_TC_TAX</service>
	<parameters>
	    <parameter n="TAX_NO">Page.txtTaxNo</parameter>
	</parameters>
</popupdata>