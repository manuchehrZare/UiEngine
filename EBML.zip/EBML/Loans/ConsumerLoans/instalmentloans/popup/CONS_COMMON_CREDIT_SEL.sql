<popupdata type="service">
	<service>CONS_INSTALMENTLOANS_LIST_LOANS</service>
    <parameters>
			<parameter n="PRODUCT_GROUP">Page.cmbProductType</parameter>
	    	<parameter n="PRODUCT">Page.cmbProduct</parameter>
	    	<parameter n="LOANS_STATUS">Page.cmbLoanStatus</parameter>
	    	<parameter n="CURRENCY_CODE">Page.cmbCurrencyCode</parameter>
	    	<parameter n="LOAN_ORG_CODE">Page.rgnCommonBranchCode.Page.cmbBranchCode</parameter>
	    	<parameter n="REFERENCE_NO">Page.txtReferenceNo</parameter>
	    	<parameter n="APPLICATION_NO">Page.txtApplicationNo</parameter>
	    	<parameter n="LOANS_OID">Page.txtLoanOid</parameter>
	    	<parameter n="CUST_CODE">Page.hndCustomer</parameter>
	    	<parameter n="LOAN_STATUS_LIST">Page.txtLoanStatusContent</parameter>
	    	<parameter n="CAMPAIGN_CODE">Page.hndCampaignSelection</parameter>
	    	<parameter n="MALIK_CUST_CODE">Page.hndMalikCustomer</parameter>
   	</parameters>
</popupdata>
