<popupdata type="sql">
<sql dataSource="BankingDS">
		 SELECT T1.OID,
		 		T1.FEDERATION ,
		 	 	T1.LABEL ,
		 	 	T1.TYPE,
		 	 	T1.BAG_NAME,
		 	 	T1.DEFAULT_VALUE 
		 FROM   CONS.ADMIN_PARAM_DEFINITION T1
		 WHERE T1.STATUS = '1' 
		 and T1.VALID_STATUS = '1' 
		 AND T1.FEDERATION  LIKE  ?  
		 AND T1.LABEL  LIKE  ? 
		 AND T1.BAG_NAME  LIKE  ?  	 
		 ORDER BY T1.FEDERATION
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">Page.cmbFederation</parameter>
        <parameter prefix="" suffix="%">Page.txtLabel</parameter>
        <parameter prefix="" suffix="%">Page.txtBagName</parameter>
    </parameters>
</popupdata>