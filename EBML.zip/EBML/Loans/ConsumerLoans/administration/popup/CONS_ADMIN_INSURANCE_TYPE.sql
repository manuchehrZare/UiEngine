<popupdata type="sql">
<sql dataSource="BankingDS">
		 SELECT  T1.OID,
		 		 T1.INSURANCE_TYPE  ,
				 T1.INSURANCE_CODE  ,
		 	 	 T1.EXPLANATION
		 FROM   CONS.ADMIN_INSURANCE_DEF T1
		 WHERE T1.STATUS = '1' 
		 AND T1.VALID_STATUS = '1'
		 AND T1.INSURANCE_TYPE  LIKE  ?  
		 AND T1.INSURANCE_CODE LIKE  ?
		 ORDER BY T1.INSURANCE_TYPE 
	</sql>                        
    <parameters>
        <parameter prefix="%" suffix="%">Page.txtInsuranceType</parameter>
        <parameter prefix="%" suffix="%">Page.txtInsuranceCode</parameter>

    </parameters>
</popupdata>