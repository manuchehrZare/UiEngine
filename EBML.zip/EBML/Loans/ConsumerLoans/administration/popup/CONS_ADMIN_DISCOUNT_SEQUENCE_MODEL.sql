<popupdata type="service">
	<service>CONS_ADMIN_LIST_DISCOUNT_SEQ_MODEL</service>
    	<parameters>
	        <parameter n="MODEL_ID">Page.txtID</parameter>
	        <parameter n="LOANS_TYPE">Page.txtLoansType</parameter>
	    </parameters>
</popupdata>