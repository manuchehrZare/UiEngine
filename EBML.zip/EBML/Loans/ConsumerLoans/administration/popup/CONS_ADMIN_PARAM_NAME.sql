<popupdata type="service">
	<service>CONS_ADMIN_LIST_PARAM_NAME</service>
    	<parameters>
	        <parameter n="PARAM_NAME">Page.txtParamName</parameter>
	    </parameters>
</popupdata>