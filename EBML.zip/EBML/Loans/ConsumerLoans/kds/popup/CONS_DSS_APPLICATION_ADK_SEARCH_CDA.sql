<popupdata type="service">
	<service>CONS_DSS_ADK_APPLICATION_POPUP_REPORT_CDA</service>
	<parameters>
	    <parameter n="APPLICATION_NO">Page.txtAppNo</parameter>
	    <parameter n="CUST_CODE">Page.hndCustCode</parameter>
		<parameter n="CHANNEL_CODE">Page.cmbChannelCode</parameter>
		<parameter n="STATE">Page.cmbState</parameter>
		<parameter n="RESULT">Page.cmbResult</parameter>
		<parameter n="RESULT_DETAIL">Page.cmbResultDetail</parameter>
		<parameter n="CREDIT_CODE">Page.hndCreditCode</parameter>
		<parameter n="BEGIN_DATE">Page.startDate</parameter>
		<parameter n="END_DATE">Page.endDate</parameter>
	</parameters>
</popupdata>