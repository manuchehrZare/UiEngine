<popupdata type="service">
	<service>CONS_DSS_CDA_APPLICATION_SEARCH_POPUP_LIST</service>
<parameters>
    <parameter n="CUSTOMER_CODE">Page.hndCustomerNo</parameter>
    <parameter n="APPLICATION_NO">Page.txtApplicationNo</parameter>
	<parameter n="STATUS_CODE">Page.cmbStatusCode</parameter>
	<parameter n="BRANCH_CODE">Page.cmbBranchCode</parameter>
    <parameter n="STATE">Page.cmbState</parameter>
	<parameter n="RESULT">Page.cmbResult</parameter>
	<parameter n="RESULT_DETAIL">Page.cmbResultDetail</parameter>
	<parameter n="EXCEPTION_TYPE">Page.txtExceptionType</parameter>
	<parameter n="IGNORED_STATUS_CODE">Page.txtIgnoredStatus</parameter>
</parameters>
</popupdata>
