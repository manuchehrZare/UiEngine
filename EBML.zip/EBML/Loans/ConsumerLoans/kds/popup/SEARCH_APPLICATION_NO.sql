<popupdata type="service">
    <service>CONS_DSS_APPLICATION_POPUP_LIST</service>
         <parameters>  
              <parameter n="APPLICATION_NO">Page.txtAppNo</parameter>
			  <parameter n="TC_ID">Page.txtTcId</parameter>
			  <parameter n="CHANNEL_CODE">Page.cmbChannel</parameter>
			  <parameter n="ORG_CODE">Page.cmbOrg</parameter>
			  <parameter n="DATE_START">Page.dtStart</parameter>
			  <parameter n="DATE_END">Page.dtEnd</parameter>
         </parameters>
</popupdata>