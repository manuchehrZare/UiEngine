<popupdata type="service">
	<service>CONS_COVER_REPORT_COVERS_FORPOPUP_DEMO</service>
	    <parameters>
	        <parameter n="CUST_CODE">Page.hndCustCode</parameter>
	        <parameter n="COVER_TYPE">Page.cmbCoverType</parameter>
	        <parameter n="COVER_NO">Page.txtCoverNo</parameter>
	        <parameter n="LOANS_OID">Page.txtLoansOID</parameter>
   	        <parameter n="LOANS_REFERENCE_NO">Page.hndLoansNo</parameter>
	        <parameter n="CURRENCY_CODE">Page.cmbCurrencyCode</parameter>
	        <parameter n="BAIL_CUST_CODE">Page.hndBailCustCode</parameter>
	        <parameter n="COVER_ORG_CODE">Page.rgnOrgCode.Page.cmbBranchCode</parameter>
	        <parameter n="COVER_TYPE_LIST">Page.lblCoverTypes</parameter>
	        <parameter n="CUST_TYPE">Page.cmbCustType</parameter>
   	        <parameter n="REAL_ESTATE_OID">Page.txtRealEstateOID</parameter>	
   	        <parameter n="COVER_STATUS">Page.cmbCoverStatus</parameter> 
			<parameter n="COVER_PLEDGE_STATUS">Page.cmbPledgeStatus</parameter> 
			<parameter n="EGM_REF_NO">Page.txtEGMRefNo</parameter> 
			<parameter n="ACC_CODE">Page.txtAccCode</parameter> 
			<parameter n="COVER_PLEDGE_STATUS_K">Page.txtCoverPledgeStatusK</parameter> 
			<parameter n="EGM_LEFT_OUTER_JOIN">Page.txtEGMLeftOuterJoin</parameter> 
			
</parameters>
</popupdata>