<popupdata type="service">
	<service>CONS_COVER_LIST_REAL_ESTATE_POPUP</service>
	<parameters>
		<parameter n="REAL_ESTATE_NO">Page.txtRealEstateNo</parameter>
		<parameter n="REAL_ESTATE_TYPE">Page.cmbRealEstateType</parameter>
		<parameter n="CITY_CODE">Page.cmbCity</parameter>
		<parameter n="COUNTY_CODE">Page.cmbTown</parameter>
		<parameter n="COVER_NO">Page.txtCoverNo</parameter>
		<parameter n="CUST_CODE">Page.txtCustCode</parameter>
		<parameter n="OWNER" prefix="%" suffix="%">Page.txtOwner</parameter>
	</parameters>
</popupdata>