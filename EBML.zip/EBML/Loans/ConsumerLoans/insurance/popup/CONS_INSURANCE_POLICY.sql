<popupdata type="service">
	<service>CONS_ADMIN_LIST_INSURANCE_POLICY</service>
    <parameters>
			<parameter n="INSURANCE_POLICY_INITIAL_DATE">Page.dtPolicyInitialDate</parameter>
	    	<parameter n="INSURANCE_POLICY_FINISH_DATE">Page.dtPolicyFinishDate</parameter>
	    	<parameter n="INSURANCE_POLICY_NO">Page.txtPolicyNo</parameter>
	    	<parameter n="INSURANCE_POLICY_STATE">Page.cmbPolicyState</parameter>
	    	<parameter n="INSURANCE_POLICY_BENEFICIARY">Page.hndCustomerNo</parameter>
	    	<parameter n="INSURANCE_TYPE">Page.hndInsuranceType</parameter>			
			<parameter n="BRANCH_CODE">Page.cmbBranch</parameter>	
			<parameter n="INSURANCE_POLICY_COMPANY_CODE">Page.cmbCompany</parameter>	
			<parameter n="VALID_POLICIES">Page.lbOpenPolicy</parameter>	
   	</parameters>
</popupdata>   
