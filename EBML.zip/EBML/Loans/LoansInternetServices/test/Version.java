/*
 * Created on 17.Oca.2005
 *
 */
package tr.com.cs.banking.loans.loansinternetservices.test.ebml;

/**
 * @author Uysal KARA
 *
 */
public class Version {
	public final static String component = "Test";
	public final static String version = "1.2.3.0";
	public final static String componentOwner = "Uysal KARA";
	public final static String date = "01.03.2006";
	public final static String componentGroup = "LoansInternetServices";
	public final static String project = "Banking";
}
