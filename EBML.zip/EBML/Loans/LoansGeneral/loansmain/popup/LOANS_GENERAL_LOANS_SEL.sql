<popupdata type="service">
	<service>LOANS_GENERAL_LIST_GENERAL_LOANS</service>
	    <parameters>
	    <!--TK-->
	    	<parameter n="LOANS_GEN_TYPE">Page.cmbLoansGenType</parameter>
	    	<parameter n="CUST_CODE">Page.pnlTK.hndCustCode</parameter>        	    	
	    	<parameter n="PRODUCT_GROUP">Page.pnlTK.cmbProductType</parameter>
        	<parameter n="PRODUCT">Page.pnlTK.cmbProduct</parameter>
        	<parameter n="LOANS_STATUS">Page.pnlTK.cmbLoanStatus</parameter>
        	<parameter n="CURRENCY_CODE">Page.pnlTK.cmbCurrencyCode</parameter>
        	<parameter n="LOAN_ORG_CODE">Page.pnlTK.rgnCommonBranchCode.Page.cmbBranchCode</parameter>
        	<parameter n="REFERENCE_NO">Page.pnlTK.txtReferenceNo</parameter>
        	<parameter n="LOAN_STATUS_LIST">Page.pnlTK.lblStatus</parameter>
        	<parameter n="LOANS_OID">Page.pnlTK.txtLoansOID</parameter>
        	<parameter n="APPLICATION_NO">Page.pnlTK.txtApplicationNo</parameter>
        <!--TOKI-->        	
        	<parameter n="MAIN_BRANCH_CODE">Page.pnlToki.cmbOrgCode</parameter>
        	<parameter n="PRODUCT_GROUP_CODE">Page.pnlToki.cmbProductGroupCode</parameter>       	        	
        	<parameter n="PRODUCT_CODE">Page.pnlToki.cmbProductCode</parameter>  
        	<parameter n="PROJECT_CODE">Page.pnlToki.txtProjectCode</parameter>        	        	
        	<parameter n="TOKI_CUST_CODE">Page.pnlToki.hndCustCode</parameter>          	
        	<parameter n="TOKI_LOANS_REF_NO">Page.pnlToki.txtLoansRefNoToki</parameter>      	
        	<parameter n="TOKI_COOP_LOANS_REF_NO">Page.pnlToki.txtLoansRefNoTokiCoop</parameter>
		</parameters>
</popupdata>



