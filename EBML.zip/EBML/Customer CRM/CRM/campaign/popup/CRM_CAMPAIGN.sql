<popupdata type="service">
<service>CRM_CAMPAIGN_POPUP_LIST</service>
<parameters>
    <parameter n="REQUEST_ID">Page.txtRequestID</parameter>
    <parameter n="ACTION_NAME">Page.txtActionName</parameter>
    <parameter n="ACTION_TYPE_OID">Page.cmbActionType</parameter>
    <parameter n="ACTION_FORM_DATE">Page.dtActionFormDate</parameter>
    <parameter n="CAMP_CHANNEL_OID">Page.cmbCampaignChannel</parameter>
</parameters>
</popupdata>