<popupdata type="sql">
<sql dataSource="BankingDS">
	select
T1.OID AS OID,
T1.TYPE AS TYPE,
T1.TYPE_EXPLANATION AS EXPLAIN,
T1.CUMULATIVE AS CUMULATIVE

	from 	INFRA.BLACK_LIST_DEFINITION T1
	where 	T1.STATUS = '1'

AND T1.TYPE LIKE ?
AND T1.TYPE_EXPLANATION LIKE ? 
AND T1.TYPE_STATUS = 'GR'
AND T1.TYPE != 'GERORT'
AND T1.TYPE != 'TUZORT'
</sql>
    <parameters>
  	   <parameter prefix="" suffix="%">Page.txtType</parameter>
        <parameter prefix="" suffix="%">Page.txtName</parameter>
   </parameters>
</popupdata>