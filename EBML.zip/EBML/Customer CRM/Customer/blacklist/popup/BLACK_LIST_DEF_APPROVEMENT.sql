<popupdata type="sql">
<sql dataSource="BankingDS">
	select
T1.OID AS OID,
T1.TYPE AS TYPE,
T1.TYPE_EXPLANATION AS EXPLAIN,
T1.CUMULATIVE AS CUMULATIVE,
T1.POT_MATCH_CRITER_UPDATE

	from 	INFRA.BLACK_LIST_DEFINITION T1
	where 	T1.STATUS = '1'

AND T1.TYPE = ?
AND T1.TYPE_STATUS = 'GR'
</sql>
    <parameters>
  	   <parameter>Page.txtType</parameter>
   </parameters>
</popupdata>