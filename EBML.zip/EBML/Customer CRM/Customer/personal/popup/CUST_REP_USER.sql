<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT 
	c.OID AS USER_OID, 
	c.USER_FILE_NO AS USER_FILE_NO, 
	c.USER_FIRST_NAME AS USER_FIRST_NAME, 
	c.USER_LAST_NAME AS USER_LAST_NAME, 
	c.USER_ORGANIZATION_OID AS USER_ORGANIZATION_OID, 
	c.USER_UNIT_OID AS USER_UNIT_OID, 
	c.USER_TITLE_OID AS USER_TITLE_OID, 
	c.USER_USER_NAME AS USER_NAME, 
	c.USER_ACTIVE AS USER_ACTIVE, 
	c.USER_EXPIRATION_DATE AS USER_EXPIRATION_DATE, 
	c.USER_STATUS AS USER_STATUS, 
	c.USER_NOTE AS USER_NOTE, 
	c.USER_CHANNEL_CODE AS USER_CHANNEL_CODE,
	d.NAME AS USER_ORGANIZATION,
	a.TITLE_NAME AS USER_TITLE, 
	NULL AS PROFILE_NAME		
FROM
infra.ADMIN_USR_TITLE a,
infra.ADMIN_USR_USER c,
infra.ADMIN_ORG_ORGANIZATION d
where
A.status=1 and 
c.status=1 and 
d.status=1 and 
c.user_organization_oid = d.oid 
AND c.user_title_oid=a.oid
AND c.USER_USER_NAME LIKE ? 
AND c.USER_FILE_NO LIKE ?
AND c.USER_FIRST_NAME like ? 
AND	c.USER_LAST_NAME like ?
AND d.CODE like ?
ORDER BY c.USER_USER_NAME	
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">User.txtUserName</parameter>
        <parameter prefix="" suffix="%">User.txtUserFileNo</parameter>
        <parameter prefix="" suffix="%">User.txtUserFirstName</parameter>
        <parameter prefix="" suffix="%">User.txtUserLastName</parameter>
        <parameter prefix="" suffix="%">User.cmbUserOrganization</parameter>
    </parameters>
</popupdata>
