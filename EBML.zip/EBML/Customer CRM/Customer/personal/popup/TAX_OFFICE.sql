<popupdata type="sql">
    <sql dataSource="AuroraDS">
		SELECT T2.CODE AS CODE,
		TO_CHAR(T3.TEXT) AS NAME
		FROM AURORA.DICT_ML_REFERENCE_DATA T1,
		AURORA.DICT_ML_REFERENCE_DATA_ITEM T2,
		AURORA.DICT_ML_LANGUAGE_TEXT T3
		WHERE   	T1.OID 	= T2.REFERENCE_DATA_OID
		AND     	T2.OID 	= T3.OWNER_OID
		AND     	T1.CODE	=  '4315'
		AND     	T3.LANGUAGE_CODE = 'tr'
		AND			(T2.CODE LIKE ?) 
		AND			T2.NAME LIKE ?
		AND			SUBSTR(T2.CODE,1,3) LIKE ?		
		ORDER BY 	T2.CODE	
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">Page.txtCode</parameter>
        <parameter prefix="" suffix="%">Page.txtName</parameter>
        <parameter prefix="" suffix="%">Page.cmbCity</parameter>
    </parameters>
</popupdata>