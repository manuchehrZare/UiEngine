<popupdata type="service">
	<service>CUST_PERS_EX_LIST_ALL</service>
	    <parameters>
	        <parameter n="CUST_CUST_TAX_NO">pgExcludedTaxNo.pnlCriterias.txtTaxNo</parameter>
	    </parameters>
</popupdata>