<popupdata type="service">
	<service>CUST_DOCUMENT_LIST_PARAM_NAME</service>
    	<parameters>
	        <parameter n="PARAM_NAME">Page.txtParamName</parameter>
	    </parameters>
</popupdata>