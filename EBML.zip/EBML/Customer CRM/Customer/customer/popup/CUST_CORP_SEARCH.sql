<popupdata type="service">
	<service>CUST_PERS_CUST_LIST_ALL</service>
	    <parameters>
	        <parameter n="CUST_CUST_CUSTOMER_CODE">pgCustomerSearch.pnlCust.txtCustomerCode</parameter>
	        <parameter n="CUST_CUST_CUSTOMER_TYPE">pgCustomerSearch.pnlCust.cboCustomerType</parameter>
	        <parameter n="CUST_CUST_CUSTOMER_CODE">pgCustomerSearch.pnlCust.txtCustomerCode</parameter>
	        <parameter n="CUST_CUST_NAME">pgCustomerSearch.pnlIndv.txtName</parameter>
			<parameter n="CUST_CUST_SURNAME">pgCustomerSearch.pnlIndv.txtSurname</parameter>
			<parameter n="CUST_CUST_SECOND_NAME">pgCustomerSearch.pnlIndv.txtSecondName</parameter>
			<parameter n="CUST_CUST_BIRTHDAY_START">pgCustomerSearch.pnlIndv.dtBirthDay1</parameter>
			<parameter n="CUST_CUST_BIRTHDAY_END">pgCustomerSearch.pnlIndv.dtBirthDay2</parameter>
			<parameter n="CUST_CUST_TITLE">pgCustomerSearch.pnlCorp.txtTitle</parameter>
			<parameter n="CUST_CUST_MAIN_BRANCH_CODE">pgCustomerSearch.pnlCust.cboBranch</parameter>
			<parameter n="CUST_CUST_ACTIVE">pgCustomerSearch.pnlCust.cboActive</parameter>	        			
			<parameter n="CUST_CUST_ACTIVE_STATUS">pgCustomerSearch.pnlCust.cboActiveStatus</parameter>	 
			<parameter n="CUST_CUST_POTENTIAL">pgCustomerSearch.pnlCust.cboPotential</parameter>
			<parameter n="CUST_CUST_TAX_NO">pgCustomerSearch.pnlCust.txtTaxNo</parameter>
			<parameter n="CUST_CORP_COMMERCIAL_RECORD_NO">pgCustomerSearch.pnlCorp.txtCommerceRecordNo</parameter>			
			<parameter n="CUST_CORP_SIGNBOARD">pgCustomerSearch.pnlCorp.txtSignboard</parameter>
			<parameter n="CUST_INDV_TC_ID">pgCustomerSearch.pnlIndv.txtTCID</parameter>
			<parameter n="CUST_INDV_FATHER_NAME">pgCustomerSearch.pnlIndv.txtFatherName</parameter>	        
			<parameter n="ACC_CODE">pgCustomerSearch.pnlCust.txtAccCode</parameter>	        						
			<parameter n="CUST_SHOW_NO_RECORD_MESSAGE">pgCustomerSearch.txtShowNoRecordMessage</parameter>			
			<parameter n="CUST_CUST_SHARED_CUSTOMER">pgCustomerSearch.pnlIndv.chkSharedCustomer</parameter>
			<parameter n="CUST_CUST_AREA_CODE">pgCustomerSearch.pnlTelephone.cmbAreaCode</parameter>
			<parameter n="CUST_CUST_TEL_NO">pgCustomerSearch.pnlTelephone.txtTelNo</parameter>
			<parameter n="CUST_CUST_AREA_CODE">pgCustomerSearch.pnlTelephone.txtAreaCode</parameter>
			<parameter n="CUST_CUST_COUNTRY_CODE">pgCustomerSearch.pnlTelephone.txtCountryCode</parameter>
	    </parameters>
</popupdata>