<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT   
	CINF.CHECK_NO AS CHECK_NO, 
	CB.CHECKBOOK_TYPE AS CHECK_TYPE,
	CINF.STATE_CODE AS STATE_CODE,
	CINF.OID AS CHECK_OID,
	CBO.BRANCH_CODE AS CUSTOMER_BRANCH_CODE,
	CB.BRANCH_CODE AS CHECK_BRANCH_CODE,
	CBO.CUSTOMER_CODE AS CUSTOMER_CODE, 
	CB.ACCOUNT_NO AS CHECK_ACCOUNT_NO, 
	CBO.ACCOUNT_OID AS CUSTOMER_ACCOUNT_OID,
	CDI.DRAWING_DATE AS DRAWING_DATE,
	CDI.VALUE_DATE AS VALUE_DATE, 
	CDI.DRAWING_PLACE AS DRAWING_PLACE,
	CDI.AMOUNT AS AMOUNT,  
	CB.CURRENCY_CODE AS CURRENCY_CODE,
	BNF.NAME_TITLE  AS BENEFICIARY_NAME_TITLE,
	CB.IS_TRADER AS IS_TRADER,
	CB.BENEFICIARY_TYPE AS BENEFICIARY_TYPE,
	CBT.TRANSACTION_DATE AS DELIVERY_DATE,
	DECODE(CB.IS_TRADER,NULL,'E','Y') AS NEW_OR_OLD_CHECK 
FROM  
	CHECKSBILLS.CHECK_INFO CINF,
	CHECKSBILLS.CHECK_CHECKBOOK CB,
	CHECKSBILLS.CHECK_BENEFICIARY BNF,
	CHECKSBILLS.CHECK_CHECKBOOK_OWNER CBO,
	CHECKSBILLS.CHECK_DRAWING_INFO CDI,
	CHECKSBILLS.CHECK_CHECKBOOK_TRANSACTIONS CBT
WHERE 
	CINF.STATUS='1'
AND CB.STATUS='1'
AND CBO.STATUS='1'
AND CBT.STATUS='1'
AND CBT.CANCEL_REFERENCE_ID IS NULL
AND CINF.CHECKBOOK_OID=CB.OID
AND CINF.BENEFICIARY_OID=BNF.OID(+)
AND CINF.OID=CDI.CHECK_OID(+)
AND CBO.OID=CB.OWNER_OID
AND (CDI.LASTUPDATED = (SELECT MAX(CDI2.LASTUPDATED) FROM CHECKSBILLS.CHECK_DRAWING_INFO CDI2 WHERE CDI2.CHECK_OID=CDI.CHECK_OID )  OR CDI.LASTUPDATED IS NULL)
AND CBT.CHECKBOOK_OID=CB.OID
AND CBT.PROCESS_ID='131030'
AND (? is null or CBO.BRANCH_CODE=?)
AND (? is null or CB.BRANCH_CODE=?)
AND (? is null or CBO.CUSTOMER_CODE=?)
AND (? is null or CB.ACCOUNT_NO=?)
AND (? is null or CBO.ACCOUNT_OID=?)
AND (? is null or CINF.CHECK_NO=?)
AND (? is null or CINF.STATE_CODE=?)
AND (? is null or CB.CURRENCY_CODE=?)
AND (? is null or CB.CURRENCY_CODE='TL')
AND (? is null or CB.CURRENCY_CODE!='TL')
ORDER BY CBO.BRANCH_CODE,
		 CBO.CUSTOMER_CODE,
         CINF.STATE_CODE,
         CINF.CHECK_NO
	</sql>
     <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.rgnCustAccSelection.Page.pnlAcc.cboBranch</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.rgnCustAccSelection.Page.pnlAcc.cboBranch</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCheckBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCheckBranchCode</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCustomerCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtCustomerCode</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCheckAccNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtCheckAccNo</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCustAccountOid</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtCustAccountOid</parameter>
        <parameter prefix="" suffix="">Page.pnlQuery.txtCheckNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtCheckNo</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbState</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCurrCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCurrCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtQueryForForeignChecks</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.txtQueryForTLChecks</parameter>
</parameters>
</popupdata>
