<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT DISTINCT CB.OID,
CBO.LIMIT_CUSTOMER_CODE AS LIMIT_CUSTOMER_CODE,
CBO.CUSTOMER_CODE AS CUSTOMER_CODE,
CB.CHECKBOOK_NO AS CHECKBOOK_NO,
CB.MIN_CHECK_NO AS MIN_CHECK_NO,
CB.MAX_CHECK_NO AS MAX_CHECK_NO,
CB.ACCOUNT_NO AS ACCOUNT_NO,
CB.CURRENCY_CODE AS CURRENCY_CODE,
CONCAT(DECODE(CB.IS_TRADER,NULL,'Eski ','1','Tacir ','0','Tacir Olmayan ') ,DECODE(CB.BENEFICIARY_TYPE,NULL,'�ek','E','','H','Hamiline')) AS CHECK_LEAF_TYPE,
CBO.VALUE_DATE AS VALUE_DATE,
DECODE (CB.LEGAL_DUTY_AMOUNT,NULL,'545',CB.LEGAL_DUTY_AMOUNT) AS LEGAL_DUTY_AMOUNT,
CB.CHECK_COUNT AS CHECK_COUNT,
CB.STATE AS CHECKBOOK_STATE,
DECODE(CB.STATE,'12',(SELECT COUNT(*) FROM CHECKSBILLS.CHECK_INFO CII  WHERE CII.STATE_CODE IN (SELECT CS.CODE 
                      FROM CHECKSBILLS.CHECK_STATE CS 
                      WHERE CS.STATUS='1' 
                      AND CS.IS_ACTIVE='1'
                      AND CS.IS_PAYABLE='1'
                      )
                      AND CB.OID=CII.CHECKBOOK_OID
                      ),'0') AS PAYABLE_COUNT,
(DECODE (CB.LEGAL_DUTY_AMOUNT,NULL,'545',CB.LEGAL_DUTY_AMOUNT))*
                      (DECODE(CB.STATE,'12',(SELECT COUNT(*) 
                      FROM CHECKSBILLS.CHECK_INFO CII  WHERE CII.STATE_CODE IN (SELECT CS.CODE 
                      FROM CHECKSBILLS.CHECK_STATE CS 
                      WHERE CS.STATUS='1' 
                      AND CS.IS_ACTIVE='1'
                      AND CS.IS_PAYABLE='1'
                      )
                      AND CB.OID=CII.CHECKBOOK_OID
                      ),CB.CHECK_COUNT)) AS TOTAL_LEGAL_DUTY_AMOUNT
FROM CHECKSBILLS.CHECK_CHECKBOOK_OWNER CBO,
CHECKSBILLS.CHECK_CHECKBOOK CB,
CHECKSBILLS.CHECK_INFO CI
WHERE CBO.STATUS='1' 
AND CB.STATUS='1'
AND (? is null  or CBO.LIMIT_CUSTOMER_CODE=?)
AND (? is null or CB.STATE=?)
AND ((('N'=? and CB.IS_TRADER is not null) or CB.IS_TRADER=?) OR ('O'=? and CB.IS_TRADER is null ) OR (? is null)) 
AND ((('N'=? and CB.IS_TRADER is not null) or  CB.BENEFICIARY_TYPE=?) OR ('O'=? and CB.IS_TRADER is null ) OR (? is null))
AND CBO.OID= CB.OWNER_OID
AND CBO.LIMIT_CUSTOMER_CODE IS NOT NULL
AND CB.STATE NOT IN ('05','11','13')
AND ((CB.STATE!='12' AND (? is null  or '1'!=?)) OR (CB.STATE='12' AND CI.CHECKBOOK_OID=CB.OID
AND CI.STATUS='1'
AND CI.STATE_CODE IN (SELECT CS.CODE 
                      FROM CHECKSBILLS.CHECK_STATE CS 
                      WHERE CS.STATUS='1' 
                      AND CS.IS_ACTIVE='1'
                      AND (? is null  or CS.IS_PAYABLE=?)
                      )
                      )
                      )
                      ORDER BY CB.OID
	</sql>
     <parameters>
        <parameter prefix="" suffix="">Page.pnlQuery.hndLimitCustomerCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.hndLimitCustomerCode</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCheckBookType</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.cmbCheckBookType</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblIsTrader</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblIsTrader</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblIsTrader</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblIsTrader</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblBeneficiaryType</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblBeneficiaryType</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblBeneficiaryType</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblBeneficiaryType</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblTemp</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblTemp</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblTemp</parameter>
		<parameter prefix="" suffix="">Page.pnlQuery.lblTemp</parameter>
		--<parameter prefix="" suffix="">Page.pnlQuery.pnlOldCheckOrNewCheck.rbOldCheck</parameter>
		
</parameters>
</popupdata>
