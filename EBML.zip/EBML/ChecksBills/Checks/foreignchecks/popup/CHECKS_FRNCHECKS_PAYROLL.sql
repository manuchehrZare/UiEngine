<popupdata type="service">
	<service>CHECK_FRNCHECKS_ROLL_LIST</service>
	<parameters>
		<parameter n="ROLL_NO">Page.pnlRollSelection.txtBordroNo</parameter>
		<parameter n="FRNCHECK_TYPE">Page.pnlRollSelection.cmbCekTuru</parameter>
		<parameter n="BRANCH_CODE">Page.pnlRollSelection.rgnAccount.Page.pnlAcc.cboBranch</parameter>
		<parameter n="CUSTOMER_CODE">Page.pnlRollSelection.rgnAccount.Page.pnlAcc.CustomerCode</parameter>
		<parameter n="ACCOUNT_NO">Page.pnlRollSelection.rgnAccount.Page.pnlAcc.hndAccCode</parameter>
		<parameter n="CURRENCY_CODE">Page.pnlRollSelection.cmbDovizCinsi</parameter>
		<parameter n="FIRST_AMOUNT">Page.pnlRollSelection.currTutarAraligi</parameter>
		<parameter n="LAST_AMOUNT">Page.pnlRollSelection.currTutarAraligi2</parameter>
		<parameter n="FIRST_CHECK_COUNT">Page.pnlRollSelection.currCekAdedi</parameter>
		<parameter n="LAST_CHECK_COUNT">Page.pnlRollSelection.currCekAdedi2</parameter>
		<parameter n="ACCOUNT_OID">Page.pnlRollSelection.txtAccOid</parameter>
	</parameters>
</popupdata>