<popupdata type="sql">
    <sql dataSource="BankingDS">
SELECT D.OID PD_CHECK_OID , CP.CUSTOMER_CODE , CP.ACCOUNT_OID , CP.PORTFOLIO_TYPE , CP.STATE  
     , D.CHECK_NO , D.CHECK_TYPE , D.DRAWER_ACCOUNT_NO , D.DRAWING_DATE,D.DRAWING_PLACE,D.DRAWER_CUSTOMER_CODE
     , D.DRAWER_NAME_TITLE , D.DRAWER_INDV_OR_CORP , D.DRAWER_TC_ID_NO , D.DRAWER_TAX_NO , D.DESCRIPTION
     , D.AMOUNT , D.CURRENCY_CODE , D.FULL_MICR_CODE , D.CHECK_BANK_CODE , D.CHECK_VALUE_DATE , D.CHECK_BRANCH_CODE
     , D.CHECK_BANK_TYPE , CP.ACCOUNT_OID , CP.TR_DATE , D.ORDER_CHECK_BEARER_USE,D.SHAPE_CONDITION_DISSONANT,CP.CLEARING_STATE_CODE
  FROM CHECKSBILLS.CHECK_PDCHECK_DEFINITION D 
     , CHECKSBILLS.CHECK_PDCHECK_CREDITOR_PORTFOL CP 
  WHERE D.OID = CP.PD_CHECK_OID(+)
    AND D.STATUS = '1'
	AND CP.STATUS = '1'
	AND CP.IS_ACTIVE = '1'
    AND (D.CHECK_NO = ? OR ? IS NULL)
    AND (D.CHECK_BANK_TYPE = ? OR ? IS NULL)    
    AND (CP.PORTFOLIO_TYPE = ? OR ? IS NULL)
    AND (D.CHECK_TYPE = ? OR ? IS NULL)
    AND (CP.STATE = ? OR ? IS NULL)
    AND (D.CHECK_BANK_CODE = ? OR ? IS NULL)    
    AND (D.CHECK_BRANCH_CODE = ? OR ? IS NULL)
    AND (D.CHECK_VALUE_DATE >= ? OR ? IS NULL)
    AND (D.CHECK_VALUE_DATE <= ? OR ? IS NULL)
    AND (D.DRAWING_DATE >= ? OR ? IS NULL)
    AND (D.DRAWING_DATE <= ? OR ? IS NULL)
    AND (CP.CUSTOMER_CODE = ? OR ? IS NULL)
    AND (CP.ACCOUNT_OID = ? OR ? IS NULL)
    AND (D.DRAWER_CUSTOMER_CODE = ? OR ? IS NULL)
    AND (D.DRAWER_NAME_TITLE LIKE ?)
    AND (D.DRAWER_TC_ID_NO = ? OR D.DRAWER_TAX_NO = ? OR ? IS NULL)
	AND (? IS NULL OR CP.PORTFOLIO_BRANCH_CODE = ?)
	AND (? IS NULL OR ? = D.CURRENCY_CODE)
  ORDER BY D.CHECK_BANK_CODE , D.CHECK_BRANCH_CODE , D.CHECK_NO	, CP.TR_DATE DESC</sql>    
    <parameters>
        <parameter prefix="" suffix="">Page.pnlCriteria.txtCheckNo</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.txtCheckNo</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbSekerOrOtherBank</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbSekerOrOtherBank</parameter>
        <parameter prefix="" suffix="">Page.pnlCriteria.cmbPortfolioType</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbPortfolioType</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbCheckType</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbCheckType</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbCheckState</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbCheckState</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbBankCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbBankCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmdBankBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmdBankBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfValueDateStart</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfValueDateStart</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfValueDateEnd</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfValueDateEnd</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfDrawDateStart</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfDrawDateStart</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfDrawDateEnd</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.dfDrawDateEnd</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.hndCustomerCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.hndCustomerCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.txtAccountOid</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.txtAccountOid</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.hndDrawerCustomerCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.hndDrawerCustomerCode</parameter>
		<parameter prefix="%" suffix="%">Page.pnlCriteria.txtDrawerNameTitle</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.txtDrawerTCNo</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.txtDrawerTCNo</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.txtDrawerTCNo</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbPortfolioBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbPortfolioBranchCode</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbCurrency</parameter>
		<parameter prefix="" suffix="">Page.pnlCriteria.cmbCurrency</parameter>
    </parameters>    
</popupdata>