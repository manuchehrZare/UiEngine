<popupdata type="service">
<service>CHECKS_BOOKMNG_GET_CHECKBOOK_WITH_LIMIT_RISK_CUSTOMER</service>


<parameters>
	<parameter n="BRANCH_CODE">Page.pnlQuery.txtBranchCode</parameter>
	<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomerCode</parameter>
	<parameter n="CHECK_NO">Page.pnlQuery.txtCheckNo</parameter>
	<parameter n="CHECKBOOK_TYPE">Page.pnlQuery.cmbBookType</parameter>
	<parameter n="CURRENCY_CODE">Page.pnlQuery.cmbCurrCode</parameter>
	<parameter n="STATE">Page.pnlQuery.cmbState</parameter>
	<parameter n="LIMIT_CUSTOMER_CODE">Page.pnlQuery.txtLimitCustomerCode</parameter>
	<parameter n="CHECKBOOK_NO">Page.pnlQuery.txtChecbookkNo</parameter>
	<parameter n="NOT_RISK_CHECKBOOK">Page.pnlQuery.chkNotRiskCheckbook</parameter>
	<parameter n="MAIN_BRANCH_CODE">Page.pnlQuery.txtMainBranchCode</parameter>
</parameters>
</popupdata>