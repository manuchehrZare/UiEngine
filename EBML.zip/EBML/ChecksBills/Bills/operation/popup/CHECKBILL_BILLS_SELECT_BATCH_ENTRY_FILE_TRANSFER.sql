<popupdata type="service">
	<service>BILL_BATCH_ENTRY_LIST_ENTRIES</service>
	<parameters>
		<parameter n="REFERENCE_ID">Page.pnlQeryCriterias.txtReferenceId</parameter>
		<parameter n="START_DATE">Page.pnlQeryCriterias.dtDateBegin</parameter>
		<parameter n="END_DATE">Page.pnlQeryCriterias.dtDateEnd</parameter>
		<parameter n="TRANSFER_BRANCH">Page.pnlQeryCriterias.cmbBranch</parameter>
		<parameter n="USER_NO">Page.pnlQeryCriterias.hndUser</parameter>
		<parameter n="BILL_TYPE">Page.pnlQeryCriterias.cmbBillType</parameter>
		<parameter n="PAYMENT_PLACE_TYPE">Page.pnlQeryCriterias.cmbPaymentPlaceType</parameter>
		<parameter n="DEBT_CURRENCY_CODE">Page.pnlQeryCriterias.cmbDebtCurrencyType</parameter>
		<parameter n="STATE">Page.pnlQeryCriterias.cmbState</parameter>
	</parameters>
</popupdata>