<popupdata type="service">
	<service>BILLS_BILL_LIST_BY_PARAMETERS</service>
	<parameters>
		<parameter n="BILL_NUMBER">Page.pnlQueryCriterias.mskBillNumber</parameter>
		<parameter n="BILL_TYPE">Page.pnlQueryCriterias.cmbBillType</parameter>
		<parameter n="DEBTOR_OID">Page.pnlQueryCriterias.txtDebtorOid</parameter>
		<parameter n="PHYSICAL_PLACE">Page.pnlQueryCriterias.cmbPhysicalPlace</parameter>
		<parameter n="PHYSICAL_BRANCH">Page.pnlQueryCriterias.cmbPhysicalBranch</parameter>
		<parameter n="STATE">Page.pnlQueryCriterias.cmbState</parameter>
		<parameter n="CUSTOMER_CODE">Page.pnlQueryCriterias.hndCustomerCode</parameter>
		<parameter n="VALOR_START_DATE">Page.pnlQueryCriterias.dtValorDateMin</parameter>
		<parameter n="VALOR_END_DATE">Page.pnlQueryCriterias.dtValorDateMax</parameter>
		<parameter n="DEBT_AMOUNT_MIN">Page.pnlQueryCriterias.currDebtAmountMin</parameter>
		<parameter n="DEBT_AMOUNT_MAX">Page.pnlQueryCriterias.currDebtAmountMax</parameter>
		<parameter n="DEBTOR_TC_ID">Page.txtDebtorTcId</parameter>
		<parameter n="DEBTOR_TAX_ID">Page.txtDebtorTaxId</parameter>
		<parameter n="LIST_DELETED">Page.txtListDeleted</parameter>	
		<parameter n="PAYMENT_PLACE_TYPE">Page.pnlQueryCriterias.cmbPaymentPlace</parameter>
		<parameter n="ORG_CODE">Page.pnlQueryCriterias.txtOrgCode</parameter>
		<parameter n="CLEARING_CENTER_CODE">Page.pnlQueryCriterias.txtClearingCenterCode</parameter>
	</parameters>
</popupdata>