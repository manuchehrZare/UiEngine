<popupdata type="service">
	<service>BILLS_DEBTOR_LIST_FOR_PP</service>
	<parameters>
		<parameter n="INST_OR_CUST">Page.JCSPanel55812.cmbDebtorType</parameter>
		<parameter n="FIRST_NAME">Page.JCSPanel55812.pnlRealPerson.txtName</parameter>
		<parameter n="SECOND_NAME">Page.JCSPanel55812.pnlRealPerson.txtSecondName</parameter>
		<parameter n="LAST_NAME">Page.JCSPanel55812.pnlRealPerson.txtLastName</parameter>
		<parameter n="TC_ID_NO">Page.JCSPanel55812.pnlRealPerson.txtTcNo</parameter>
		<parameter n="TCMB_TITLE">Page.JCSPanel55812.pnlJudicial.txtTitle</parameter>
		<parameter n="INST_TYPE">Page.JCSPanel55812.pnlJudicial.cmbType</parameter>
		<parameter n="TAX_NO">Page.JCSPanel55812.pnlJudicial.txtTaxNo</parameter>
		<parameter n="COMMERCIAL_ID_NO">Page.JCSPanel55812.pnlJudicial.txtCommNo</parameter>
		<parameter n="CITY_CODE">Page.JCSPanel55812.JCSPanel36546.cmbCity</parameter>
		<parameter n="COUNTY_CODE">Page.JCSPanel55812.JCSPanel36546.cmbCounty</parameter>
	</parameters>
</popupdata>