<popupdata type="service">
	<service>BILLS_LIST_BILL_ROLL</service>
	<parameters>
			<parameter n="BILL_ROLL_NO">Page.txtBillRollNo</parameter>
			<parameter n="CUSTOMER_CODE">Page.txtCustomerCode</parameter>
			<parameter n="ORG_CODE">Page.cmbBranch</parameter>
			<parameter n="CLEARING_CENTER_CODE">Page.cmbClearingCenter</parameter>
			<parameter n="BILL_ROLL_TYPE">Page.cmbBillRollType</parameter>
			<parameter n="CURR_CODE">Page.cmbBillRollCurrencyCode</parameter>
			<parameter n="STATE">Page.txtState</parameter>
			<parameter n="BILL_ROLL_CANCELLED">Page.txtBillRollCancelled</parameter>			
	</parameters>
</popupdata>