<popupdata type="service">
	<service>BILLS_SELECT_BATCH_ENTRY_TRANSACTIONS</service>
	<parameters>
		<parameter n="REFERENCE">Page.pnlQuery.txtReferenceId</parameter>
		<parameter n="BRANCH">Page.pnlQuery.cmbBranch</parameter>
		<parameter n="DATE_MIN">Page.pnlQuery.dtDateMin</parameter>
		<parameter n="DATE_MAX">Page.pnlQuery.dtDateMax</parameter>
		<parameter n="CUSTOMER_CODE">Page.pnlQuery.hndCustomer</parameter>
	</parameters>
</popupdata>