<popupdata type="service">
	<service>BILLS_PAYMENT_LIST_EFT_LOG</service>
	<parameters>
		<parameter n="BILL_NUMBER">Page.pnlQueryCriterias.mskBillNumber</parameter>
		<parameter n="REFERENCE_ID">Page.pnlQueryCriterias.txtReferenceID</parameter>
		<parameter n="TRANSDATE_1">Page.pnlQueryCriterias.dtTrans1</parameter>
		<parameter n="TRANSDATE_2">Page.pnlQueryCriterias.dtTrans2</parameter>
		<parameter n="AMOUNT1">Page.pnlQueryCriterias.currAmount1</parameter>
		<parameter n="AMOUNT2">Page.pnlQueryCriterias.currAmount2</parameter>
		<parameter n="DEST_BRANCH">Page.pnlQueryCriterias.cmbDestBranch</parameter>
		<parameter n="OID">Page.pnlQueryCriterias.txtOid</parameter>
	</parameters>
</popupdata>