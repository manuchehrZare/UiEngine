<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
SELECT D.OID , D.STATUS , D.LASTUPDATED , L.BORDRO_NO , D.CHECK_TYPE 
     , D.CHECK_NO , D.BANK_CODE , D.BRANCH_CODE , D.ACCOUNT_NO , NVL(D.CURRENCY_CODE,L.CURRENCY_CODE) CURRENCY_CODE
     , D.BENEFICIARY_NAME_TITLE , D.FULL_MICR_CODE , D.ENTERENCE_REFERENCE_ID 
     , D.DRAWING_DATE , D.DRAWING_PLACE , D.DRAWER_NAME_TITLE , D.AMOUNT CHECK_AMOUNT
     , D.DRAWER_IDENTITY_NO , D.USER_NO , D.USER_ORG_CODE , D.BANK_NAME , D.ENDORSER
  FROM CHECKSBILLS.CORE_CRM_CHECK_DETAILS D 
     , CHECKSBILLS.CORE_CRM_CHECK_LIST L
  WHERE D.LIST_OID = L.OID
    AND D.STATUS = '1'
    AND L.STATUS = '1'
    AND (L.BORDRO_NO = ? OR ? IS NULL)
    AND (D.CHECK_NO = ? OR ? IS NULL)
    AND (L.TRANSACTION_DATE = ? OR ? IS NULL)
    AND (L.TRANSACTION_TIME <= ? OR ? IS NULL)
    AND (L.TRANSACTION_TIME >= ? OR ? IS NULL)
    AND (D.CHECK_TYPE = ? OR ? IS NULL)
    AND (D.BANK_CODE = ? OR ? IS NULL)
    AND (D.BRANCH_CODE = ? OR ? IS NULL)
    AND (D.ACCOUNT_NO = ? OR ? IS NULL)
    AND (D.DRAWER_IDENTITY_NO = ? OR ? IS NULL)
    AND (D.DRAWER_NAME_TITLE LIKE ? OR ? = '%%')
    AND (D.DRAWING_PLACE = ? OR ? IS NULL)
    AND (D.DRAWING_DATE = ? OR ? IS NULL)
    AND (D.AMOUNT = TO_NUMBER(?,'9999999999999999D99') OR TO_NUMBER(?,'9999999999999999D99') = 0)
    AND (D.CURRENCY_CODE = ? OR ? IS NULL)
    AND (D.USER_ORG_CODE = ? OR ? IS NULL)
    AND (D.STATE = ? OR ? IS NULL)
    AND (D.BANK_NAME = ? OR ? IS NULL)
    AND (D.ENDORSER LIKE ? OR ? = '%')
    AND (L.BORDRO_TYPE = ? OR ? IS NULL)
    AND (D.USER_NO = ? OR ? IS NULL)
   ORDER BY L.BORDRO_NO , D.OID
    </sql>
    <parameters>
        <parameter>Page.pnlCriteria.hndBordroNo</parameter>
        <parameter>Page.pnlCriteria.hndBordroNo</parameter>

        <parameter>Page.pnlCriteria.txtCheckNo</parameter>
        <parameter>Page.pnlCriteria.txtCheckNo</parameter>

        <parameter>Page.pnlCriteria.dfScanDate</parameter>
        <parameter>Page.pnlCriteria.dfScanDate</parameter>

        <parameter>Page.pnlCriteria.tfTimeEnd</parameter>
        <parameter>Page.pnlCriteria.tfTimeEnd</parameter>        

        <parameter>Page.pnlCriteria.tfTimeBegin</parameter>        
        <parameter>Page.pnlCriteria.tfTimeBegin</parameter>

        <parameter>Page.pnlCriteria.cmbCheckType</parameter>
        <parameter>Page.pnlCriteria.cmbCheckType</parameter>  

        <parameter>Page.pnlCriteria.txtBankCode</parameter>   
        <parameter>Page.pnlCriteria.txtBankCode</parameter>

        <parameter>Page.pnlCriteria.txtBranchCode</parameter>  
        <parameter>Page.pnlCriteria.txtBranchCode</parameter>  

        <parameter>Page.pnlCriteria.txtAccountNo</parameter>
        <parameter>Page.pnlCriteria.txtAccountNo</parameter>  


        <parameter>Page.pnlCriteria.txtTCId</parameter>
        <parameter>Page.pnlCriteria.txtTCId</parameter>  


        <parameter prefix="%" suffix="%">Page.pnlCriteria.txtDrawerNameTitle</parameter>
		<parameter prefix="%" suffix="%">Page.pnlCriteria.txtDrawerNameTitle</parameter>

  
        <parameter>Page.pnlCriteria.txtDrawingPlace</parameter>
        <parameter>Page.pnlCriteria.txtDrawingPlace</parameter>  

        <parameter>Page.pnlCriteria.dfDrawingDate</parameter>
        <parameter>Page.pnlCriteria.dfDrawingDate</parameter>  

        <parameter>Page.pnlCriteria.cfAmount</parameter>
        <parameter>Page.pnlCriteria.cfAmount</parameter>  


        <parameter>Page.pnlCriteria.cmbCurrCode</parameter>
        <parameter>Page.pnlCriteria.cmbCurrCode</parameter>  


        <parameter>Page.pnlCriteria.cmbUserBranchNo</parameter>
        <parameter>Page.pnlCriteria.cmbUserBranchNo</parameter>  


        <parameter>Page.pnlCriteria.txtDetailState</parameter>
        <parameter>Page.pnlCriteria.txtDetailState</parameter>  

        <parameter>Page.pnlCriteria.hndBankName</parameter>
        <parameter>Page.pnlCriteria.hndBankName</parameter>  

        <parameter  prefix="" suffix="%">Page.pnlCriteria.txtEndorser</parameter>
        <parameter  prefix="" suffix="%">Page.pnlCriteria.txtEndorser</parameter>
        
        <parameter>Page.pnlCriteria.cmbBordroType</parameter>
        <parameter>Page.pnlCriteria.cmbBordroType</parameter>
        
        <parameter>Page.pnlCriteria.hndUserNo</parameter>
        <parameter>Page.pnlCriteria.hndUserNo</parameter>
    </parameters>
</popupdata>