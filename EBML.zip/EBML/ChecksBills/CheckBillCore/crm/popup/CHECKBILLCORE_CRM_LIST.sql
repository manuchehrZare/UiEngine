<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
   SELECT CCL.OID, CCL.BORDRO_NO , CCL.CUSTOMER_NO , C.TITLE CUSTOMER_TITLE , CCL.BRANCH_CODE 
      ,O.NAME BRANCH_NAME , CCL.USER_NO , U.USER_FIRST_NAME||' '||U.USER_LAST_NAME USER_NAME 
      ,CCL.CHECK_TYPE , CCL.CURRENCY_CODE , CCL.TOTAL_COUNT , CCL.TOTAL_AMOUNT 
      ,CCL.TRANSACTION_DATE , CCL.TRANSACTION_TIME , CCL.STATE , CCL.BORDRO_TYPE,CCL.INTELLIGENCE_STATE
   FROM CHECKSBILLS.CORE_CRM_CHECK_LIST CCL, 
        INFRA.CUST_CUST_CUST C ,
        INFRA.ADMIN_USR_USER  U ,
        INFRA.ADMIN_ORG_ORGANIZATION O
   WHERE CCL.STATUS = 1
     AND CCL.CUSTOMER_NO = C.CUSTOMER_CODE(+)
     AND CCL.USER_NO = U.USER_USER_NAME(+)
     AND CCL.BRANCH_CODE = O.CODE(+)
     AND (? IS NULL OR CCL.CHECK_TYPE = ? )
     AND (? IS NULL OR CCL.BORDRO_NO = ?)
     AND (? IS NULL OR CCL.CURRENCY_CODE = ?)
     AND (? IS NULL OR CCL.CUSTOMER_NO = ?)
     AND (? IS NULL OR CCL.USER_ORG_CODE = to_number(?))
     AND (? IS NULL OR CCL.USER_NO = ?)
     AND (? IS NULL OR CCL.TRANSACTION_DATE >= ?)
     AND (? IS NULL OR CCL.TRANSACTION_DATE <= ?)
     AND (? IS NULL OR CCL.STATE = ?)
     AND (? IS NULL OR CCL.BORDRO_TYPE = ?)
     AND (? IS NULL OR CCL.INTELLIGENCE_STATE = ?)
     AND (? IS NULL OR CCL.BRANCH_CODE = to_number(?))
    </sql>
    <parameters>
        <parameter>Page.pnlCriteria.cmbCheckType</parameter>
        <parameter>Page.pnlCriteria.cmbCheckType</parameter>
        <parameter>Page.pnlCriteria.txtBordroNo</parameter>
        <parameter>Page.pnlCriteria.txtBordroNo</parameter>
        <parameter>Page.pnlCriteria.cmbCurrency</parameter>
        <parameter>Page.pnlCriteria.cmbCurrency</parameter>
        <parameter>Page.pnlCriteria.hndCustomerNo</parameter>
        <parameter>Page.pnlCriteria.hndCustomerNo</parameter>        
        <parameter>Page.pnlCriteria.cmbBranchNo</parameter>        
        <parameter>Page.pnlCriteria.cmbBranchNo</parameter>
        <parameter>Page.pnlCriteria.hndUserNo</parameter>
        <parameter>Page.pnlCriteria.hndUserNo</parameter>  
        <parameter>Page.pnlCriteria.dfTransDateBegin</parameter>   
        <parameter>Page.pnlCriteria.dfTransDateBegin</parameter>
        <parameter>Page.pnlCriteria.dfTransDateEnd</parameter>  
        <parameter>Page.pnlCriteria.dfTransDateEnd</parameter>  
        <parameter>Page.pnlCriteria.cmbState</parameter>
        <parameter>Page.pnlCriteria.cmbState</parameter>    
	<parameter>Page.pnlCriteria.cmbBordroType</parameter>    
	<parameter>Page.pnlCriteria.cmbBordroType</parameter> 
	<parameter>Page.pnlCriteria.cmbIntlgState</parameter>
	<parameter>Page.pnlCriteria.cmbIntlgState</parameter>
	<parameter>Page.pnlCriteria.lblBranchCode</parameter>
	<parameter>Page.pnlCriteria.lblBranchCode</parameter>
    </parameters>
</popupdata>