<popupdata v="0.0.1" type="sql">
    <sql dataSource="BankingDS">
SELECT I.BIC_FOUR , I.INSTITUTION_NAME
  FROM CHECKSBILLS.CORE_CRM_INSTITUTION I
  WHERE I.STATUS = '1'
    AND (I.BIC_FOUR LIKE ? OR ? IS NULL)
    AND (I.INSTITUTION_NAME LIKE ? OR ? IS NULL)
    </sql>
    <parameters>
        <parameter prefix="%" suffix="%">Page.pnlCriteria.txtBICFour</parameter>
        <parameter >Page.pnlCriteria.txtBICFour</parameter>
        <parameter prefix="%" suffix="%">Page.pnlCriteria.txtInstitutionName</parameter>
        <parameter>Page.pnlCriteria.txtInstitutionName</parameter>
    </parameters>
</popupdata>