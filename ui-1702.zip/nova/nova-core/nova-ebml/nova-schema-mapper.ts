/* eslint-disable */
import type { ParsedComponent } from '../types';
import { COMPONENT_REGISTRY } from '../registry/component-registry';
import { resolveComponentType } from '../utils/mappings';
import type { DesignComponent } from '../types';
import { calculateCoordinateGrid } from '../utils/coordinateGridUtils';

// Default page width for grid calculations
const DEFAULT_PAGE_WIDTH = 960;

/**
 * Get the effective width of a component, considering both bounds and pageSize
 * @param component - The parsed component
 * @returns The width in pixels
 */
const getEffectiveWidth = (component: ParsedComponent): number => {
    // First check if bounds has a valid width
    if (component.bounds && component.bounds.width > 0) {
        return component.bounds.width;
    }

    // If bounds is 0, check for pageSize property (format: "width,height")
    if (component.properties?.pageSize) {
        const pageSize = String(component.properties.pageSize);
        const [width] = pageSize.split(',').map(Number);
        if (width && width > 0) {
            return width;
        }
    }

    // Fallback to bounds width (even if 0)
    return component.bounds?.width || 0;
};

// Unused helper removed: shouldBeFullWidth

/**
 * Check if a component is a hidden field (utility bean with no visual representation)
 * These components should not be wrapped in their own GridItem
 */
const isHiddenField = (designType: string): boolean => {
    return designType === 'HiddenField';
};

// Unused functions removed: createGridItemWithLayout, createSpacerGridItem, createRowContainer, wrapRowInGridItem

/**
 * Process children using coordinate-based grid layout algorithm
 * Groups children by unique coordinates and creates a CSS Grid container
 * Hidden fields are separated and appended to the nearest GridItem
 */
const processChildrenWithGridLayout = (
    children: ParsedComponent[],
    parentComponent: ParsedComponent,
    parentId: string
): DesignComponent[] => {
    if (!children || children.length === 0) {
        return [];
    }

    const parentWidth = getEffectiveWidth(parentComponent) || DEFAULT_PAGE_WIDTH;

    // Separate hidden fields from regular children
    const hiddenFields: ParsedComponent[] = [];
    const regularChildren: ParsedComponent[] = [];

    children.forEach(child => {
        const childType = COMPONENT_REGISTRY[child.type] ? child.type : resolveComponentType(child.type) || child.type;
        if (isHiddenField(childType)) {
            hiddenFields.push(child);
        } else {
            regularChildren.push(child);
        }
    });

    // Process regular children with grid layout
    let result: DesignComponent[] = [];

    if (regularChildren.length > 0) {
        // Use the new Coordinate-Based Grid algorithm
        // This generates a custom grid for the container based on exact component bounds
        const coordinateGrid = calculateCoordinateGrid(regularChildren, parentWidth);

        // Map components to DesignComponents with CSS Grid styles
        const gridChildren = regularChildren.map((child, index) => {
            const mappedChild = mapParsedComponentToDesign(child, parentId);
            const placement = coordinateGrid.placements.get(child.id);

            // Apply grid positioning style
            // We wrap each child in a generic 'Box' or 'GridItem' that acts as the grid cell
            // Use parentId + index to ensure unique IDs even when same component ID appears multiple times
            return {
                id: `grid-cell-${parentId}-${index}-${child.id}`,
                type: 'GridItem', // Using GridItem but overriding with CSS Grid styles
                props: {
                    key: `${parentId}-${index}-${child.id}`,
                    // We must override the default flex-based GridItem behavior
                    style: placement ? {
                        gridColumnStart: placement.gridColumnStart,
                        gridColumnEnd: placement.gridColumnEnd,
                        gridRowStart: placement.gridRowStart,
                        gridRowEnd: placement.gridRowEnd,
                        width: '100%',
                        height: '100%',
                        // Ensure no margins interfere
                        margin: 0,
                        padding: 0
                    } : {},
                    // Disable default Grid behavior if possible or ensure style overrides it
                    xs: undefined // Clear xs prop appropriately if possible, or ignore
                },
                children: [mappedChild],
                parentId
            };
        });

        // Create the Container Grid
        // Use Grid component so it's recognizable and modifiable in the designer
        const gridContainer: DesignComponent = {
            id: `css-grid-${parentId}`,
            type: 'Grid',
            props: {
                container: true,
                sx: {
                    display: 'grid',
                    gridTemplateColumns: coordinateGrid.columns,
                    gridTemplateRows: coordinateGrid.rows,
                    width: '100%',
                    position: 'relative'
                    // gap: '0px' - Coordinate grid handles gaps naturally via tracks
                },
                className: 'nova-coordinate-grid'
            },
            children: gridChildren,
            parentId: parentId
        };
        
        result.push(gridContainer);
    }

    // Process hidden fields - append them to the result (outside the visual grid)
    if (hiddenFields.length > 0) {
        const mappedHiddenFields = hiddenFields.map(hf => {
            const childType = COMPONENT_REGISTRY[hf.type] ? hf.type : resolveComponentType(hf.type) || hf.type;
            return {
                id: hf.id,
                type: childType,
                props: {
                    ...hf.properties,
                    id: hf.properties.id || hf.id,
                    name: hf.properties.id || hf.id,
                    originalType: hf.type, // Pass original Java class name for display
                },
                children: [],
                parentId: parentId,
            };
        });

        if (result.length > 0) {
            // Find the first GridItem and append hidden fields to it
            const firstGridItem = result[0];
            if (firstGridItem.type === 'GridItem') {
                firstGridItem.children = [...mappedHiddenFields, ...firstGridItem.children];
            } else {
                // If first result is not a GridItem, create a wrapper for hidden fields
                const hiddenFieldsContainer: DesignComponent = {
                    id: `hidden-fields-${parentId}`,
                    type: 'GridItem',
                    props: { xs: 12, key: 'hidden-fields' },
                    children: mappedHiddenFields,
                    parentId,
                };
                result = [hiddenFieldsContainer, ...result];
            }
        } else {
            // No regular children, create a GridItem just for hidden fields
            const hiddenFieldsContainer: DesignComponent = {
                id: `hidden-fields-${parentId}`,
                type: 'GridItem',
                props: { xs: 12, key: 'hidden-fields' },
                children: mappedHiddenFields,
                parentId,
            };
            result = [hiddenFieldsContainer];
        }
    }

    return result;
};

// Unused function removed: calculateSimpleGridSize

/**
 * Map ParsedComponent (nested structure) to DesignComponent (Grid structure)
 * Uses row-based layout algorithm for proper positioning
 */
export const mapParsedComponentToDesign = (
    component: ParsedComponent,
    parentId: string | null
): DesignComponent => {
    // component.type is already resolved by ebml-parser, but we double check/fallback
    const designType = COMPONENT_REGISTRY[component.type] ? component.type : resolveComponentType(component.type) || component.type;

    const defaultProps = COMPONENT_REGISTRY[designType]?.defaultProps || {};
    const props: Record<string, any> = {
        ...defaultProps,
        ...component.properties,
        // Map component Id to both id prop and name prop for backward compatibility
        id: component.properties.id || component.id,
        name: component.properties.id || component.id,
        bounds: component.bounds, // Pass bounds to all components
        // Fix: Check for resolved type 'TableComponent' instead of Java class name
        xs: designType === 'TableComponent' ? 12 : undefined,
        // Fix: HandleButton renders its own GridItem if useAbsolutePositioning is false, so we force it to true to avoid double wrapping
        useAbsolutePositioning: designType === 'HandleButton' ? true : undefined,
        // Pass original type for HiddenField components to display in design mode
        originalType: isHiddenField(designType) ? component.type : undefined,
    };

    let children: DesignComponent[] = [];

    // Special handling for Page (JCSPage)
    if (designType === 'Page') {
        // Process children using row-based grid layout
        if (component.children && component.children.length > 0) {
            children = processChildrenWithGridLayout(
                component.children,
                component,
                `page-content-${component.id}`
            );
        }

        // Create the GridItem that holds the Page properties
        const pageContentGridItem: DesignComponent = {
            id: `page-content-${component.id}`,
            type: 'GridItem',
            props: {
                ...props, // Bean properties go here
                xs: 12,   // Full width
                container: true,
                spacing: 2,
            },
            children: children,
            parentId: component.id
        };

        // Create Root Grid
        return {
            id: component.id,
            type: 'Grid',
            props: {
                container: true,
                direction: 'column',
                spacing: 2,
                style: { height: '100%', width: '100%' },
                p: 2,
            },
            children: [pageContentGridItem],
            parentId,
        };
    }

    // Special handling for Container (JCSPanel)
    if (designType === 'Container') {
        // Process children using row-based grid layout
        if (component.children && component.children.length > 0) {
            children = processChildrenWithGridLayout(
                component.children,
                component,
                `grid-${component.id}`
            );
        }

        // If panel has a title, add Nav component as first child
        const panelTitle = component.properties?.title || component.properties?.label;
        if (panelTitle) {
            // Create Nav component with title
            const navComponent: DesignComponent = {
                id: `nav-${component.id}`,
                type: 'Nav',
                props: {
                    navTitleProps: { title: panelTitle }
                },
                children: [],
                parentId: `grid-${component.id}`
            };

            // Wrap Nav in GridItem
            const navGridItem: DesignComponent = {
                id: `grid-item-nav-${component.id}`,
                type: 'GridItem',
                props: { xs: 12, key: `nav-${component.id}` },
                children: [navComponent],
                parentId: `grid-${component.id}`
            };

            // Add Nav as first child
            children = [navGridItem, ...children];
        }

        // Create Inner Grid (receives bean properties)
        const innerGrid: DesignComponent = {
            id: `grid-${component.id}`,
            type: 'Grid',
            props: {
                ...props, // Set property of bean to Grid
                container: true,
                spacing: 1,
                style: {}
            },
            children: children,
            parentId: `paper-${component.id}` // Parent is Paper
        };

        // Create Paper Wrapper
        return {
            id: component.id,
            type: 'Paper',
            props: {
                elevation: 1,
                style: {  padding: '16px', overflow: 'hidden' }
            },
            children: [innerGrid],
            parentId
        };
    }

    // Handle children (Default logic for non-Page/non-Container)
    // Region Handling
    if (designType === 'Region') {
        // Region components - pass title from properties if available
        // Title can come from 'title' or 'label' property
        const regionTitle = component.properties?.title || component.properties?.label;
        if (regionTitle) {
            props.title = regionTitle;
        }
        // Pass popup property if set (converts string 'true'/'false' to boolean)
        if (component.properties?.popup !== undefined) {
            props.popup = component.properties.popup === true || component.properties.popup === 'true';
        }
        // Leave children empty, will be loaded dynamically
    }
    else if (designType === 'Paper' && component.properties?.regionName) {
        // Legacy Paper with regionName - leave children empty, will be loaded dynamically
    }
    // Standard Children Handling
    else if (component.children && component.children.length > 0) {
        const isGridContainer = ['Grid', 'Container', 'Paper'].includes(designType) || COMPONENT_REGISTRY[designType]?.isContainer;

        // Special handling: TabbedPane should NOT wrap its TabPage children in GridItem
        // But TabPage SHOULD use grid layout so panels inside can be side by side
        if (designType === 'TabbedPane') {
            // TabbedPane: map TabPage children directly without GridItem wrapping
            children = component.children.map(child =>
                mapParsedComponentToDesign(child, component.id)
            );
        } else if (designType === 'TabPage') {
            // TabPage: use grid layout so side-by-side panels display as columns
            children = processChildrenWithGridLayout(
                component.children,
                component,
                component.id
            );
        } else if (isGridContainer) {
            // Use row-based grid layout for grid containers
            children = processChildrenWithGridLayout(
                component.children,
                component,
                component.id
            );
        } else {
            // Non-grid containers: map children directly without GridItem wrapping
            children = component.children.map(child =>
                mapParsedComponentToDesign(child, component.id)
            );
        }
    }

    // If component is a container, ensure it has container props
    if (designType === 'Grid') {
        props.container = true;
        props.spacing = 2;
    }

    return {
        id: component.id,
        type: designType,
        props,
        children,
        parentId,
    };
};
