/* eslint-disable */
import type { NovaEbml, NovaEbmlBean, NovaEbmlRuleset, NovaEbmlData, NovaEbmlEvent, NovaEbmlActionStep } from './types';
import type { NovaUiSchema, NovaRuleset, NovaData, NovaEvent, NovaEventActionStep } from '../types/nova-ui-schema.types';
import type { ParsedComponent, ComponentBounds } from '../types';
import type { DesignComponent, Rule, Variable } from '../types';
import { resolveComponentType } from '../utils/mappings';
import { mapParsedComponentToDesign } from './nova-schema-mapper';

/**
 * Converts a NovaEbml object (parsed from XML) into a NovaUiSchema (unified format).
 */
export const convertNovaEbmlToNovaUiSchema = (novaEbml: NovaEbml): NovaUiSchema => {
    console.log('=== Starting EBML to NovaUiSchema Conversion ===');

    // 1. Convert Data
    const data = convertData(novaEbml.data);

    // 2. Convert Ruleset
    const ruleset = convertRuleset(novaEbml.ruleset);

    // 3. Convert Events - Map NovaEbmlEvent to NovaEvent
    const events = convertEvents(novaEbml.interface.events || []);

    // 4. Convert Structure (UI)
    // We first convert NovaEbmlBean -> ParsedComponent (to get bounds etc)
    // Then ParsedComponent -> DesignComponent (using existing mapper)
    let ui: DesignComponent[] = [];
    if (novaEbml.interface.structure.rootBean) {
        // Collect all beans for lookup (needed for DropdownButton -> JCSPopupMenu linking)
        const allBeans = [novaEbml.interface.structure.rootBean];
        
        // Pass the root size attribute, data section, and all beans to the converter
        const parsedRoot = convertNovaBeanToParsedComponent(
            novaEbml.interface.structure.rootBean,
            novaEbml.size,
            novaEbml.data,
            allBeans
        );
        // Map to Design Component (Grid System)
        const designRoot = mapParsedComponentToDesign(parsedRoot, null);
        ui = [designRoot];
    }

    // 5. Build Final Schema
    return {
        ui,
        events, // Direct array of NovaEvent
        ruleset,
        data,
        metadata: {
            version: "1.0.0",
            name: novaEbml.pid || "Unknown",
            description: `Converted from EBML ${novaEbml.type || ''}`,
            createdAt: new Date().toISOString()
        }
    };
};

/**
 * Converts NovaEbmlBean to ParsedComponent
 * Extracts properties, resolving class to type, and parsing bounds.
 * @param bean - The NovaEbmlBean to convert
 * @param rootSize - Optional root size attribute from EBML (e.g., "360x50" for regions)
 * @param dataSection - Optional data section containing definitions for components
 * @param allBeans - Optional array of all beans for lookup (used for DropdownButton)
 */
const convertNovaBeanToParsedComponent = (
    bean: NovaEbmlBean, 
    rootSize?: string, 
    dataSection?: NovaEbmlData,
    allBeans?: NovaEbmlBean[]
): ParsedComponent => {
    const properties: Record<string, any> = {};
    const type = resolveComponentType(bean.class) || 'Unknown';
    if(type==='Unknown') 
       properties['originalClassName']=bean.class

    // Extract properties from Style
    if (bean.style && bean.style.properties) {
        bean.style.properties.forEach(p => {
            // Use Name as key, Text as value.
            // If Text is empty, check other fields or default empty.
            if (p.name) {
                properties[p.name] = p.text;
            }
            if(p.name==='adapterInfo')
                properties[p.name] = p.columns;
        });
    }

    // Also include top-level text if present
    if (bean.text) {
        properties['text'] = bean.text;
    }

    // Special handling for DropdownButton: extract menu items from linked JCSPopupMenu
    if (type === 'DropdownButton' && properties['popupMenuName'] && allBeans) {
        const popupMenuName = properties['popupMenuName'];
        
        // Find the JCSPopupMenu bean with matching id
        const findPopupMenuBean = (beans: NovaEbmlBean[]): NovaEbmlBean | null => {
            for (const b of beans) {
                if (b.id === popupMenuName) {
                    return b;
                }
                // Recursively search children
                if (b.children && b.children.length > 0) {
                    const found = findPopupMenuBean(b.children);
                    if (found) return found;
                }
            }
            return null;
        };

        const popupMenuBean = findPopupMenuBean(allBeans);
        
        if (popupMenuBean && popupMenuBean.children) {
            // Extract menu items from JCSPopupItem children
            const menuItems: Array<{ id: string; text: string; enabled: boolean }> = [];
            
            popupMenuBean.children.forEach(child => {
                const childType = resolveComponentType(child.class);
                if (childType === 'JCSPopupItem') {
                    const itemProps: Record<string, any> = {};
                    
                    // Extract properties from child
                    if (child.style && child.style.properties) {
                        child.style.properties.forEach(p => {
                            if (p.name) {
                                itemProps[p.name] = p.text;
                            }
                        });
                    }
                    
                    menuItems.push({
                        id: child.id,
                        text: itemProps['text'] || itemProps['label'] || child.id,
                        enabled: itemProps['enabled'] !== 'false' && itemProps['enabled'] !== false
                    });
                }
            });
            
            // Add menuItems as a property
            properties['menuItems'] = menuItems;
            
            console.log(`DropdownButton ${bean.id} found ${menuItems.length} menu items from ${popupMenuName}`);
        }
    }

    // For root components (Page/Region), convert the root size attribute to pageSize
    // Legacy EBML format: size="360x50" -> convert to pageSize="360,50"
    if (rootSize && (type === 'Page' || type === 'Region')) {
        const pageSizeConverted = rootSize.replace('x', ',');
        properties['pageSize'] = pageSizeConverted;
    }

    // Parse bounds from properties
    // Expecting logic: properties usually contain x, y, width, height or bounds string
    const bounds = parseBounds(properties);

    // Note: Components with definitions in schema.data.definitions will lookup by their own ID
    // No need to store definitionId - the component uses its own id to find the definition
    if (dataSection?.definitions) {
        const componentDataDef = dataSection.definitions.find(def => def.id === bean.id);
        if (componentDataDef) {
            console.log(`Component ${bean.id} has definition with ${componentDataDef.options?.length || 0} options`);
        }
    }

    // Recursively map children (pass dataSection and allBeans to children)
    const children: ParsedComponent[] = (bean.children || []).map(child =>
        convertNovaBeanToParsedComponent(child, undefined, dataSection, allBeans)
    );

    return {
        id: bean.id,
        type,
        bounds,
        properties,
        children
    };
};

/**
 * Parses bounds from component properties.
 * Defaults to 0,0,0,0 if not found.
 */
const parseBounds = (props: Record<string, any>): ComponentBounds => {
    // Check if 'bounds' property exists (e.g. "10,10,100,20")
    if (props['bounds']) {
        const parts = props['bounds'].split(',').map((s: string) => parseInt(s.trim(), 10));
        if (parts.length >= 4) {
            return { x: parts[0], y: parts[1], width: parts[2], height: parts[3] };
        }
    }

    // Check individual properties
    const x = parseInt(props['x'] || '0', 10);
    const y = parseInt(props['y'] || '0', 10);
    const width = parseInt(props['width'] || '0', 10);
    const height = parseInt(props['height'] || '0', 10);

    return { x, y, width, height };
};

/**
 * Convert Data Section to NovaData
 */
const convertData = (ebmlData?: NovaEbmlData): NovaData => {
    // Return empty if no data at all
    if (!ebmlData) return { var: [] };

    // Convert variables to Data format (can be empty array)
    const dataItems: Variable[] = (ebmlData.variables || []).map(v => ({
        name: v.n || v.id,
        type: 'string', // Default to string as EBML doesn't strictly type vars usually
        initialValue: v.text || undefined
    }));

    // Convert definitions if present (supports both simple and nested/table definitions)
    const definitions = ebmlData.definitions?.map(def => {
        const converted: any = {
            id: def.id,
            options: def.options.map(opt => ({
                value: opt.value,
                text: opt.text
            }))
        };

        // If this has column definitions (for table components), include them
        if (def.columnDefinitions && def.columnDefinitions.length > 0) {
            converted.columnDefinitions = def.columnDefinitions.map(colDef => ({
                columnId: colDef.columnId,
                options: colDef.options.map(opt => ({
                    value: opt.value,
                    text: opt.text
                }))
            }));
        }

        return converted;
    });

    return {
        var: dataItems,
        definitions: definitions && definitions.length > 0 ? definitions : undefined
    };
};

/**
 * Convert Ruleset Section to NovaRuleset
 */
const convertRuleset = (ruleset?: NovaEbmlRuleset): NovaRuleset => {
    if (!ruleset) return { rules: [] };

    const rules: Rule[] = [];

    // Simple Rules
    if (ruleset.rules) {
        ruleset.rules.forEach(r => {
            rules.push({
                id: r.id,
                name: r.id,
                type: 'Simple',
                operator: mapOperator(r.op), // Need to map operator string
                source: r.source,
                target: r.target,
                targetType: r.targetType as any // Assumes compatibility or lenient type
            });
        });
    }

    // Message Rules
    if (ruleset.messages) {
        ruleset.messages.forEach(m => {
            rules.push({
                id: m.id,
                name: m.id,
                type: 'Message',
                messageTitle: m.title,
                messageType: mapMessageType(m.messageType),
                messageContent: m.text,
                messageAppearance: mapMessageTypeToAppearance(m.type)
            });
        });
    }

    // Combination Rules
    if (ruleset.combinations) {
        ruleset.combinations.forEach(c => {
            rules.push({
                id: c.id,
                name: c.id,
                type: 'Combination',
                combinationExpression: c.expression
            });
        });
    }

    return { rules };
};

/**
 * Convert NovaEbmlActionStep to NovaEventActionStep
 */
const convertActionStep = (step: NovaEbmlActionStep): NovaEventActionStep => {
    switch (step.type) {
        case 'BeanAction':
            return {
                type: 'BeanAction',
                action: {
                    targetId: step.action.targetId,
                    method: step.action.method,
                    value: step.action.value,
                    property: step.action.property,
                    sourceVar: step.action.sourceVar,
                    description: step.action.description
                }
            };

        case 'RemoteCall':
            return {
                type: 'RemoteCall',
                call: {
                    serviceName: step.call.serviceName,
                    status: step.call.status,
                    // Pass through the flat array with type field
                    inputs: step.call.inputs,
                    outputs: step.call.outputs,
                    description: step.call.description
                }
            };

        case 'ReferenceCall':
            return {
                type: 'ReferenceCall',
                reference: step.reference
            };

        case 'VariableSetting':
            return {
                type: 'VariableSetting',
                setting: {
                    variableId: step.setting.variableId,
                    value: step.setting.value,
                    rule: step.setting.rule,
                    sourceComp: step.setting.sourceComp,
                    description: step.setting.description
                }
            };

        case 'PageCall':
            return {
                type: 'PageCall',
                call: {
                    pageName: step.call.pageName,
                    method: step.call.method,
                    params: step.call.params,
                    description: step.call.description
                }
            };

        default:
            // This should never happen with proper typing
            throw new Error(`Unknown action step type: ${(step as any).type}`);
    }
};

/**
 * Convert NovaEbmlEvent to NovaEvent
 */
const convertEvents = (ebmlEvents: NovaEbmlEvent[]): NovaEvent[] => {
    return ebmlEvents.map(ebmlEvent => ({
        id: ebmlEvent.id,
        name: ebmlEvent.name,
        type: ebmlEvent.type,
        refId: ebmlEvent.refId,
        actions: ebmlEvent.actions.map(step => convertActionStep(step))
    }));
};


// --- Helpers ---

const mapOperator = (op: string): any => {
    // Map EBML ops like 'EQ', 'GT' etc. usually they match or need slight casing changes
    return op; 
};

const mapMessageType = (type: string): any => {
    if (type === 'OK') return 'OK';
    if (type === 'OK_CANCEL') return 'OK_CANCEL';
    if (type === 'YES_NO') return 'YES_NO';
    return 'OK';
};

const mapMessageTypeToAppearance = (type: string): any => {
    // EBML might use 'ERROR', 'WARNING', 'INFO' or numbers/codes
    if (type === 'ERROR') return 'ERROR';
    if (type === 'WARNING') return 'WARNING';
    if (type === 'INFO') return 'INFO';
    return 'INFO';
};
