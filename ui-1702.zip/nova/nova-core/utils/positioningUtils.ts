/* eslint-disable */
/**
 * Positioning Utilities
 * Handles conversion of Windows Forms bounds to web CSS positioning
 */

import type { ComponentBounds } from '../types';

const GRID_COLUMNS = 12;
const DEFAULT_PAGE_WIDTH = 960;
 
/**
 * Convert bounds width to responsive grid columns
 * Used when useAbsolutePositioning = false (responsive mode)
 */
export const boundsToGridSize = (
    bounds: ComponentBounds,
    containerWidth: number = DEFAULT_PAGE_WIDTH,
    shouldFillRow: boolean = false,
): { xs: number; minHeight: number } => {
    const effectiveContainerWidth = Math.max(1, containerWidth);
    const ratio = bounds.width / effectiveContainerWidth;
    let columns = Math.round(ratio * GRID_COLUMNS);

    if (shouldFillRow) {
        columns = GRID_COLUMNS;
    }

    return {
        xs: Math.max(1, Math.min(GRID_COLUMNS, columns)),
        minHeight: bounds.height,
    };
};
export default {
   boundsToGridSize,
};