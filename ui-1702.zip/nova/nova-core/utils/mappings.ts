/* eslint-disable */
/**
 * Component Mappings
 * Maps Java Swing classes to Designer Component types and their available events
 *
 * This module provides mappings between Java Swing component classes from the legacy
 * EBML system and their corresponding React/Designer component types, as well as
 * the events that each component type can handle.
 */

export const CLASS_TO_COMPONENT_MAP: Record<string, string> = {
    'tr.com.cs.aurora.ebml.bean.swing.JCSPage': 'Page',
    'tr.com.cs.aurora.ebml.bean.swing.JCSPanel': 'Container',
    'tr.com.cs.aurora.ebml.bean.swing.JCSRegion': 'Region',

    'tr.com.cs.aurora.ebml.bean.swing.JCSTabbedPane': 'TabbedPane',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTabPage': 'TabPage',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTab': 'TabPage',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTextField': 'Input',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTextArea': 'Input',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTextPane': 'Input',
    'tr.com.cs.aurora.ebml.bean.swing.JCSNumberField': 'NumberInput',
    'tr.com.cs.aurora.ebml.bean.swing.JCSDateField': 'DatePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTimeField': 'TimePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSDateTimeField': 'DateTimePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSCheckBox': 'Checkbox',
    'tr.com.cs.aurora.ebml.bean.swing.JCSButtonGroup': 'RadioGroup',
    'tr.com.cs.aurora.ebml.bean.swing.JCSRadioButton': 'Radio',
    'tr.com.cs.aurora.ebml.bean.swing.JCSComboBox': 'Select',
    'tr.com.cs.aurora.ebml.bean.swing.JCSCurrencyField': 'Currency',
    'tr.com.cs.aurora.ebml.bean.swing.JCSLabel': 'Label',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTable': 'TableComponent',
    'tr.com.cs.aurora.ebml.bean.swing.JCSButton': 'SetButton',
    'tr.com.cs.aurora.ebml.bean.swing.JCSHandleButtonField': 'HandleButton',
    'tr.com.cs.aurora.ebml.bean.swing.JSeparator': 'Divider',
    'tr.com.cs.aurora.ebml.bean.swing.JCSJasperReport': 'ReportViewer',

    // Additional mappings for components with events
    'tr.com.cs.aurora.ebml.bean.swing.JCSDropdownButton': 'DropdownButton',
    'tr.com.cs.aurora.ebml.bean.swing.JCSEnhancedTable': 'JCSEnhancedTable',
    'tr.com.cs.aurora.ebml.bean.swing.JCSFilePicker': 'JCSFilePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSList': 'JCSList',
    'tr.com.cs.aurora.ebml.bean.swing.JCSMaskField': 'JCSMaskField',
    'tr.com.cs.aurora.ebml.bean.swing.JCSPasswordField': 'JCSPasswordField',
    'tr.com.cs.aurora.ebml.bean.swing.JCSPopupItem': 'JCSPopupItem',
    'tr.com.cs.aurora.ebml.bean.swing.JCSPopupMenu': 'JCSPopupMenu',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTree': 'JCSTree',
    'tr.com.cs.aurora.ebml.bean.utility.JCSTimer': 'HiddenField',

    // Banking extensions
    'tr.com.cs.aurora.extensions.client.banking.BankingTable': 'TableComponent',
    'tr.com.cs.aurora.extensions.client.banking.BankingHandleButton': 'HandleButton',
    'tr.com.cs.aurora.extensions.client.banking.BankingMaskField': 'BankingMaskField',
    'tr.com.cs.aurora.extensions.client.treeTable.TreeList': 'TreeList',

    // BPM and DMS
    'tr.com.cs.foja.bpm.aurora.client.BPMTable': 'BPMTable',
    'tr.com.cs.foja.dms.aurora.client.DMSFilePicker': 'DMSFilePicker',

    // Hidden Fields - Utility/Service beans with no visual representation
    'tr.com.cs.aurora.extensions.client.banking.PageOrganizer': 'HiddenField',
    'tr.com.cs.aurora.extensions.client.banking.FileTransfer': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSMath': 'HiddenField',
    'tr.com.cs.foja.bpm.aurora.client.BPMEbmlUtility': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSStringUtility': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSClientContext': 'HiddenField',
    'tr.com.cs.foja.dms.aurora.client.DMSDocument': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSDateUtility': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSShell': 'HiddenField',
    'tr.com.cs.foja.dms.aurora.client.DMSScanner': 'HiddenField',
    'tr.com.cs.aurora.extensions.client.banking.CSVExport': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSFileSystem': 'HiddenField',
    'tr.com.sekerbank.nova.shell.JNovaBrowserPanel': 'HiddenField',
    'tr.com.cs.foja.dms.aurora.client.DMSSharedScanner': 'HiddenField',
    'tr.com.cs.aurora.ebml.bean.utility.JCSFtp': 'HiddenField',
    'tr.com.cs.aurora.extensions.client.banking.BankingBrowser': 'HiddenField',
};

/**
 * Component Events Mapping
 * Maps component types to their available events
 */
export const COMPONENT_TO_EVENTS_MAP: Record<string, string[]> = {
    'SetButton': ['actionPerformed'],
    'Checkbox': ['actionPerformed', 'allItemsUnSelected', 'itemStateSelected', 'itemStateUnSelected'],
    'Select': ['actionPerformed', 'focusGained', 'focusLost', 'itemStateChanged'],
    'Currency': ['actionPerformed', 'focusGained', 'focusLost'],
    'DatePicker': ['actionPerformed', 'focusGained', 'focusLost', 'insertUpdate'],
    'DateTimePicker': ['focusLost'],
    'DropdownButton': ['actionPerformed'],
    'JCSEnhancedTable': ['cellDataChanged', 'mouseDoubleClicked', 'mousePressed', 'rowDeleted', 'rowInserted', 'rowSelected'],
    'JCSFilePicker': ['fileSelected'],
    'HandleButton': ['actionPerformed', 'focusGained', 'focusLost', 'onCancelPopup', 'onClosePopup', 'onShowPopup'],
    'Label': ['actionPerformed', 'itemStateSelected', 'itemStateUnSelected'],
    'JCSList': ['mouseDoubleClicked', 'valueChanged'],
    'JCSMaskField': ['actionPerformed', 'focusGained', 'focusLost'],
    'Page': ['pageClose', 'pageKeyEvent', 'pageLoad'],
    'JCSPasswordField': ['actionPerformed', 'focusGained', 'focusLost'],
    'JCSPopupItem': ['actionPerformed'],
    'JCSPopupMenu': ['popupMenuWillBecomeVisible'],
    'Radio': ['actionPerformed', 'itemStateSelected', 'itemStateUnSelected'],
    'Region': ['popupCanceled'],
    'TabbedPane': ['stateChanged'],
    'TableComponent': ['cellDataChanged', 'mouseDoubleClicked', 'mousePressed', 'rowDeleted', 'rowInserted', 'rowSelected'],
    'TabPage': ['pageLoad'],
    'Input': ['actionPerformed', 'focusGained', 'focusLost', 'insertUpdate', 'onCancelPopup', 'onClosePopup', 'removeUpdate'],
    'TimePicker': ['actionPerformed', 'focusLost'],
    'JCSTree': ['mouseClicked', 'mouseDoubleClicked', 'valueChanged'],
    'JCSTimer': ['actionPerformed'],
    'BankingHandleButton': ['actionPerformed', 'focusGained', 'focusLost', 'onCancelPopup', 'onClosePopup', 'onShowPopup'],
    'BankingMaskField': ['focusLost'],
    'TreeList': ['mouseDoubleClicked'],
    'BPMTable': ['mouseDoubleClicked', 'rowSelected'],
    'DMSFilePicker': ['fileSelected'],
};

/**
 * Component Methods Mapping
 * Maps component types to their available methods
 */
export const COMPONENT_TO_METHOD_MAP: Record<string, string[]> = {
    'Page': ['backToPage', 'cleanup', 'exit', 'getActiveComponent', 'getKey', 'getModifier', 'getPageName', 'giveup', 'isDirty', 'returnMenu', 'setBackground', 'setDirty', 'setEnableAll', 'setFocusable', 'setModal', 'setName', 'setPageSize', 'setPopup', 'setTitle'],
    'Container': ['cleanup', 'getTitle', 'grabFocus', 'setBackground', 'setBorderVisible', 'setBounds', 'setDirty', 'setEnableAll', 'setFocusable', 'setForeground', 'setHeight', 'setLocation', 'setTabOrder', 'setTitle', 'setVisible', 'setWidth'],
    'Region': ['cleanup', 'closePopup', 'renderRegion', 'setBorderVisible', 'setBounds', 'setDirty', 'setEnableAll', 'setHeight', 'setLocation', 'setName', 'setPageLoadOnce', 'setPopup', 'setRegionName', 'setTitle', 'setVisible', 'setWidth', 'showPopup'],
    'TabbedPane': ['cleanup', 'setDirty', 'setDisabledTabs', 'setEnableAll', 'setEnabledTabs', 'setHeight', 'setLocation', 'setSelectedTab', 'setTabTitleWithIndex', 'setVisible'],
    'TabPage': ['cleanup', 'getName', 'setDirty', 'setEnableAll', 'setFocusable', 'setPopupMenuName', 'setTabTitle', 'setTitle'],
    'Input': ['appendText', 'cleanup', 'deleteLast', 'getName', 'getReportData', 'getSelectedText', 'getText', 'getTextLength', 'grabFocus', 'isDirty', 'setAutoSkip', 'setBackground', 'setClearWith', 'setComment', 'setContentType', 'setDirty', 'setEditable', 'setEnabled', 'setExceptions', 'setFocusable', 'setFont', 'setForeground', 'setHeight', 'setLetterCase', 'setLimit', 'setLocation', 'setMinCharCount', 'setMustEnter', 'setMustFill', 'setReadOnly', 'setTabOrder', 'setText', 'setToolTipText', 'setVisible', 'setWidth'],
    'NumberInput': ['appendText', 'cleanup', 'deleteLast', 'getName', 'getSelectedText', 'getText', 'getTextLength', 'grabFocus', 'isDirty', 'setAutoSkip', 'setBackground', 'setClearWith', 'setComment', 'setContentType', 'setDirty', 'setEditable', 'setEnabled', 'setExceptions', 'setFocusable', 'setForeground', 'setHeight', 'setLetterCase', 'setLimit', 'setLocation', 'setMinCharCount', 'setMustEnter', 'setMustFill', 'setReadOnly', 'setTabOrder', 'setText', 'setToolTipText', 'setVisible', 'setWidth'],
    'DatePicker': ['cleanup', 'getName', 'getSelectedText', 'getText', 'grabFocus', 'setBackground', 'setBounds', 'setButtonVisible', 'setClearWith', 'setComment', 'setDirty', 'setEditable', 'setEnabled', 'setFocusable', 'setFont', 'setForeground', 'setLocation', 'setMaxDate', 'setMinDate', 'setMustEnter', 'setReadOnly', 'setText', 'setVisible', 'setWidth'],
    'TimePicker': ['getSelectedText', 'getText', 'setDirty', 'setEditable', 'setMustEnter', 'setReadOnly', 'setText', 'setVisible'],
    'DateTimePicker': ['getText', 'setEditable', 'setText', 'setVisible'],
    'Checkbox': ['cleanup', 'getName', 'getSelectionValue', 'getText', 'grabFocus', 'isSelected', 'setBackground', 'setBounds', 'setDirty', 'setEnabled', 'setFont', 'setForeground', 'setLocation', 'setReadOnly', 'setSelected', 'setText', 'setToolTipText', 'setVisible', 'setWidth'],
    'RadioGroup': ['cleanup', 'getName', 'getSelected', 'setEnableAll', 'setEnabled', 'setFocusable', 'setLocation', 'setSelected', 'setVisible'],
    'Radio': ['getSelected', 'getSelectionValue', 'getText', 'setBackground', 'setEnabled', 'setForeground', 'setLocation', 'setReadOnly', 'setSelected', 'setText', 'setVisible'],
    'Select': ['addItem', 'cleanup', 'clear', 'filter', 'getName', 'getSelectedIndex', 'getSelectedText', 'getSelectedValue', 'getSelectionValue', 'getText', 'grabFocus', 'isDirty', 'refreshReferenceData', 'removeItem', 'setBackground', 'setBounds', 'setComment', 'setDirty', 'setEditable', 'setEnabled', 'setFiltered', 'setFocusable', 'setFont', 'setForeground', 'setHeight', 'setLocation', 'setMustEnter', 'setReadOnly', 'setReferenceDataName', 'setSelectOnly', 'setSelectedIndex', 'setSelectedText', 'setSelectedValue', 'setShowText', 'setSorted', 'setToggleWith', 'setToolTipText', 'setUseCommonSeparator', 'setVisible', 'setWidth'],
    'Currency': ['cleanup', 'getName', 'getSelectedText', 'getText', 'getTitle', 'grabFocus', 'setBackground', 'setCanBeNegative', 'setClearWith', 'setComment', 'setDirty', 'setEditable', 'setEnabled', 'setFocusable', 'setLocation', 'setMustEnter', 'setPattern', 'setReadOnly', 'setText', 'setVisible'],
    'Label': ['cleanup', 'getName', 'getText', 'isDirty', 'setBounds', 'setDirty', 'setEnabled', 'setFont', 'setForeground', 'setHeight', 'setLocation', 'setText', 'setVisible', 'setWidth'],
    'TableComponent': ['addColumn', 'addRow', 'cleanup', 'clear', 'countOccurences', 'deleteRow', 'export', 'exportToExcel', 'getActualRowCount', 'getName', 'getSelectedRow', 'getSelectedText', 'getText', 'getTitle', 'getValueAt', 'grabFocus', 'insertRow', 'readFromCSV', 'readFromExcel', 'removeLastColumn', 'selectFirst', 'setAllCellBackgroundWithControl', 'setAllRowBackgroundWithControl', 'setAllRowForgroundWithControl', 'setAppendable', 'setBackground', 'setBounds', 'setCellBackground', 'setCellForeground', 'setColumnEditable', 'setColumnHidden', 'setColumnName', 'setColumnScript', 'setColumnTitle', 'setColumnWidth', 'setContent', 'setContextMenuEnable', 'setCsvExportSeparator', 'setDeletable', 'setDirty', 'setEditable', 'setEnabled', 'setExcelImportable', 'setExportable', 'setExtendable', 'setFocusable', 'setHeight', 'setHighlightSelectedRow', 'setInsertable', 'setItems', 'setLocation', 'setMinimumRowCount', 'setMultiSelectionEnabled', 'setMustEnter', 'setName', 'setPreferences', 'setRowBGColor', 'setRowBackground', 'setRowFGColor', 'setRowForeground', 'setRowHeaderVisible', 'setRowSelectionAllowed', 'setSelectedColumn', 'setSelectedRow', 'setSortable', 'setTitleLineCount', 'setValueAt', 'setVisible', 'setWidth', 'sortColumnAsc', 'sortColumnAscIgnoreCase', 'sortColumnDesc', 'sortColumnDescIgnoreCase', 'sumColumn', 'updateRow'],
    'SetButton': ['getText', 'grabFocus', 'setBackground', 'setBounds', 'setDirty', 'setEnabled', 'setFocusable', 'setForeground', 'setHotKey', 'setIcon', 'setLocation', 'setText', 'setToolTipText', 'setVisible', 'setWidth'],
    'HandleButton': ['closePopup', 'executeQuery', 'getName', 'getSelectedText', 'getText', 'grabFocus', 'isDirty', 'setBackground', 'setBounds', 'setButtonVisible', 'setComment', 'setDirty', 'setEditable', 'setEnabled', 'setFocusable', 'setForeground', 'setLocation', 'setMustEnter', 'setMustFill', 'setPopup', 'setReadOnly', 'setText', 'setToolTipText', 'setVisible', 'showPopup'],
    'Divider': [],
    'ReportViewer': ['cleanup', 'firstPage', 'getReportData', 'lastPage', 'nextPage', 'previousPage', 'print', 'printWithOptionalDialog', 'save', 'setBounds', 'setDefaultZoomRatio', 'setHeight', 'setLocation', 'setPrintButtonEnabled', 'setReportName', 'setSaveButtonEnabled', 'setToolbarVisible', 'setVisible', 'setWidth', 'showReport'],
    'DropdownButton': ['setEnabled', 'setVisible'],
    'JCSEnhancedTable': ['addRow', 'cleanup', 'clear', 'deleteRow', 'export', 'exportToExcel', 'getName', 'grabFocus', 'setColumnEditable', 'setColumnHidden', 'setColumnScript', 'setColumnTitle', 'setContent', 'setDeletable', 'setDirty', 'setEditable', 'setHeight', 'setInsertable', 'setItems', 'setMinimumRowCount', 'setMustEnter', 'setRowBackground', 'setSelectedRow', 'setValueAt', 'setVisible', 'sortColumnAsc', 'updateRow'],
    'JCSFilePicker': ['cleanup', 'close', 'deleteOnExit', 'getContent', 'getSelected', 'read', 'save', 'setBinary', 'setContent', 'setCreateFolders', 'setFocusable', 'setInitialDirectory', 'setName', 'setSaveOverride', 'setSelected', 'setVisible'],
    'JCSList': ['addItem', 'cleanup', 'clear', 'getSelectedText', 'removeItem', 'setReferenceDataName', 'setUnique', 'setVisible', 'sortAsc', 'sortAscIgnoreCase'],
    'JCSMaskField': ['getName', 'getText', 'grabFocus', 'setClearWith', 'setComment', 'setEditable', 'setEnabled', 'setFillAll', 'setFocusable', 'setLocation', 'setMask', 'setMustEnter', 'setPattern', 'setReadOnly', 'setText', 'setVisible'],
    'JCSPasswordField': ['getText', 'grabFocus', 'setBackground', 'setEditable', 'setLimit', 'setMustEnter', 'setReadOnly', 'setText', 'setVisible'],
    'JCSPopupItem': ['setEnabled', 'setText', 'setVisible'],
    'JCSPopupMenu': ['setEnabled'],
    'JCSTree': ['addNode', 'cleanup', 'collapseAllNode', 'expandAllNode', 'expandNode', 'getContent', 'getData', 'getSelectedNode', 'removeNode', 'search', 'selectParentNode', 'setContent', 'setData', 'setEnabled', 'setNodeData', 'setSelectedNode', 'setVisible', 'sortAsc', 'sortAscAll', 'sortDescAll'],
    'JCSTimer': ['setDelay', 'setRepeats', 'start', 'stop'],
    'BankingHandleButton': ['closePopup', 'executeQuery', 'executeQueryAndActionPerformed', 'getName', 'getSelectedText', 'getText', 'grabFocus', 'renderPopup', 'setAutoExecute', 'setButtonVisible', 'setComment', 'setDirty', 'setEditable', 'setEnabled', 'setFocusable', 'setLocation', 'setMustEnter', 'setMustFill', 'setReadOnly', 'setText', 'setVisible', 'setZeroPad', 'showPopup'],
    'BankingMaskField': ['completeMask', 'getText', 'grabFocus', 'setComment', 'setCompleteChar', 'setIsPrefix', 'setMask', 'setMustEnter', 'setPattern', 'setReadOnly', 'setText', 'setVisible'],
    'TreeList': ['cleanup'],
    'BPMTable': ['addColumn', 'addRow', 'cleanup', 'clear', 'deleteRow', 'exportToExcel', 'insertRow', 'removeLastColumn', 'setColumnEditable', 'setColumnHidden', 'setColumnName', 'setEditable', 'setMinimumRowCount', 'setRowBackground', 'setSelectedRow', 'setValueAt', 'setVisible', 'sortColumnDesc', 'updateRow'],
    'DMSFilePicker': ['cleanup', 'read', 'save', 'setBinary', 'setContent', 'setSaveOverride', 'setSelected', 'setVisible'],
};

/**
 * Resolves a component type to its available events
 */
export const resolveComponentEvents = (componentType: string): string[] => {
    return COMPONENT_TO_EVENTS_MAP[componentType] || [];
};

/**
 * Resolves a component type to its available methods
 */
export const resolveComponentMethods = (componentType: string): string[] => {
    return COMPONENT_TO_METHOD_MAP[componentType] || [];
};

/**
 * Resolves a Java class name to a Designer Component type
 */
export const resolveComponentType = (className: string): string => {
    if (CLASS_TO_COMPONENT_MAP[className]) {
        return CLASS_TO_COMPONENT_MAP[className];
    }
    console.log('Class Mapper not Found', className);
    return 'Unknown';
};

