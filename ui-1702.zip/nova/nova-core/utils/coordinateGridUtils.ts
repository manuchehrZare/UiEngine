/* eslint-disable */
/**
 * Coordinate-Based Grid Utilities
 * Generates a CSS Grid layout based on exact component bounds coordinates.
 */

import type { ParsedComponent } from '../types';

export interface GridTrack {
    start: number;
    end: number;
    size: number;
    index: number;
}

export interface CoordinateGridResult {
    rows: string;    // grid-template-rows value
    columns: string; // grid-template-columns value
    placements: Map<string, GridPlacement>; // Map of componentId -> placement style
    width: number;
    height: number;
}

export interface GridPlacement {
    gridColumnStart: number;
    gridColumnEnd: number;
    gridRowStart: number;
    gridRowEnd: number;
}

/**
 * Calculates a CSS Grid layout based on unique X and Y coordinates of all components.
 * Uses 'fr' units for columns to ensure the layout scales responsively to the container width.
 */
export function calculateCoordinateGrid(
    components: ParsedComponent[],
    containerWidth: number = 960
): CoordinateGridResult {
    // 1. Collect all unique X and Y coordinates (cuts)
    const xCuts = new Set<number>([0]); // Always start at 0
    const yCuts = new Set<number>([0]);

    // Also track max boundaries
    let maxY = 0;

    components.forEach(comp => {
        if (!comp.bounds) return;
        const { x, y, width, height } = comp.bounds;
        
        xCuts.add(x);
        xCuts.add(x + width);
        
        yCuts.add(y);
        yCuts.add(y + height);

        if (y + height > maxY) maxY = y + height;
    });

    // Ensure we account for the full container width to maintain proportions
    // Only add if it's larger than the last component
    const maxX = Math.max(...Array.from(xCuts));
    if (containerWidth > maxX) {
        xCuts.add(containerWidth);
    }

    // 2. Sort coordinates to create tracks
    const sortedX = Array.from(xCuts).sort((a, b) => a - b);
    const sortedY = Array.from(yCuts).sort((a, b) => a - b);

    // 3. Generate Track Definitions (intervals between cuts)
    const colTracks: GridTrack[] = [];
    const rowTracks: GridTrack[] = [];

    // Columns: Use 'fr' units proportional to the pixel width to makes it responsive
    let gridTemplateColumns = '';
    for (let i = 0; i < sortedX.length - 1; i++) {
        const size = sortedX[i+1] - sortedX[i];
        colTracks.push({ start: sortedX[i], end: sortedX[i+1], size, index: i + 1 });
        // Use fractional units (fr) so the grid scales to fit the container
        // We use the pixel value as the fraction (e.g. 50px -> 50fr)
        gridTemplateColumns += `${size}fr `;
    }

    // Rows: Use minmax(size, auto) to ensure rows define a minimum height based on legacy bounds
    // but can expand if content (text wrapping etc) requires more space, preventing overlap.
    let gridTemplateRows = '';
    for (let i = 0; i < sortedY.length - 1; i++) {
        const size = sortedY[i+1] - sortedY[i];
        rowTracks.push({ start: sortedY[i], end: sortedY[i+1], size, index: i + 1 });
        gridTemplateRows += `minmax(${size}px, auto) `;
    }

    // 4. Map components to grid areas
    const placements = new Map<string, GridPlacement>();

    components.forEach(comp => {
        if (!comp.bounds) return;
        const { x, y, width, height } = comp.bounds;

        // Find start and end column indices
        const startColIndex = sortedX.indexOf(x);
        const endColIndex = sortedX.indexOf(x + width);
        
        // Find start and end row indices
        const startRowIndex = sortedY.indexOf(y);
        const endRowIndex = sortedY.indexOf(y + height);

        // Grid lines are 1-based. 
        // If startColIndex is 0 (first cut), the grid line is 1.
        // If endColIndex is 2 (3rd cut), the grid line is 3.
        
        if (startColIndex !== -1 && endColIndex !== -1 && startRowIndex !== -1 && endRowIndex !== -1) {
             placements.set(comp.id, {
                gridColumnStart: startColIndex + 1,
                gridColumnEnd: endColIndex + 1,
                gridRowStart: startRowIndex + 1,
                gridRowEnd: endRowIndex + 1
             });
        }
    });

    return {
        rows: gridTemplateRows.trim(),
        columns: gridTemplateColumns.trim(),
        placements,
        width: sortedX[sortedX.length - 1],
        height: sortedY[sortedY.length - 1]
    };
}
