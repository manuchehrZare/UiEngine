/* eslint-disable */
/**
 * Region Component
 * Renders EBML Region components (references to reusable sub-pages)
 * Supports both absolute positioning and responsive grid layout
 */

import React, { useState, useEffect } from 'react';
import { Box, Label, Paper, Nav } from '../../../seker-ui-lib';
import { GridItem } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import type { NovaUiSchema } from '../types/nova-ui-schema.types';
import { PreviewRenderer } from '../../nova-studio/components/PreviewRenderer';
import { getScreenEbmlSchema } from '../nova-ebml/ebml-schema-provider';
import { convertNovaEbmlToNovaUiSchema } from '../nova-ebml/nova-ebml-converter';
import DynamicModal from './DynamicModal';

export const RegionComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    regionName,
    title,
    popup,
    xs,
    component,
    componentKey,
    allPages,
    designComponent,
    name,
    type,
    text,
    value,
    placeholder,
    enabled,
    children,
    ...gridProps
}) => {
    const gridSize = { xs: 12, minHeight: 0 };
    const [regionSchema, setRegionSchema] = useState<NovaUiSchema | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [showPopup, setShowPopup] = useState(false);

    // If popup is true, render as DynamicModal
    if (popup) {
        return (
            <DynamicModal
                showModal={showPopup}
                onClose={() => setShowPopup(false)}
                pageId={regionName}
                title={title || label || regionName}
            />
        );
    }

    useEffect(() => {
        const loadRegionSchema = async () => {
            setIsLoading(true);
            try {
                const regionEbml = await getScreenEbmlSchema(regionName);
                if (regionEbml) {
                    // If the Region component has bounds that differ from the region EBML size,
                    // override the region EBML size with the Region component's bounds
                    if (bounds && bounds.width > 0 && bounds.height > 0) {
                        const regionEbmlSize = regionEbml.size; // e.g., "910x220"
                        const [ebmlWidth, ebmlHeight] = regionEbmlSize ? regionEbmlSize.split('x').map(Number) : [0, 0];

                        // Check if sizes differ - if so, use the Region component's bounds
                        if (ebmlWidth !== bounds.width || ebmlHeight !== bounds.height) {
                            console.log(`[RegionComponent] Overriding region EBML size: ${regionEbmlSize} -> ${bounds.width}x${bounds.height}`);
                            regionEbml.size = `${bounds.width}x${bounds.height}`;
                        }
                    }

                    const convertedSchema = convertNovaEbmlToNovaUiSchema(regionEbml);
                    setRegionSchema(convertedSchema);
                } else {
                    setRegionSchema(null);
                }
            } catch (error) {
                setRegionSchema(null);
            } finally {
                setIsLoading(false);
            }
        };

        if (regionName) {
            loadRegionSchema();
        } else {
            setRegionSchema(null);
            setIsLoading(false);
        }
    }, [regionName, bounds?.width, bounds?.height]);

    // Helper function to wrap content based on positioning mode
    const wrapContent = (content: React.ReactNode) => {
        if (useAbsolutePositioning) {
            return content;
        }

        const resolvedXs = xs ?? gridSize.xs;
        return (
            <GridItem xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} {...gridProps}>
                {content}
            </GridItem>
        );
    };

    // No region name specified
    if (!regionName) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #ff9800',
                p: 0,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text="[Region: No name specified]" />
            </Box>
        );
    }

    // Loading state
    if (isLoading) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #2196f3',
                p: 0,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <Label text={`[Loading region: ${regionName}...]`} />
            </Box>
        );
    }

    // Region not found or error loading
    if (!regionSchema) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #f44336',
                p: 0,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text={`[Region not found: ${regionName}]`} />
            </Box>
        );
    }

    // Check if the Region has a title prop or if the root component (JCSPage) has a title
    // If so, render like a Container with Nav and Paper
    const rootComponent = regionSchema.ui[0];
    // Priority: title prop > root component title > root component label
    const regionTitle = title || rootComponent?.props?.title || rootComponent?.props?.label;
    // If region has a title, wrap in Paper with Nav (Container-like behavior)
    if (regionTitle) {
        const content = (
            <Paper
                sx={{
                    height: '100%',
                    width: '100%',
                    padding: '16px',
                    overflow: 'hidden'
                }}
            >
                <Box sx={{
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column'
                }}>
                    <Nav navTitleProps={{ title: regionTitle }} />
                    <PreviewRenderer component={rootComponent} />
                </Box>
            </Paper>
        );

        return wrapContent(content);
    }

    // Default: render region without additional container wrapper
    const content = (
        <Box sx={{
            width: '100%',
            height: '100%',
            position: useAbsolutePositioning ? 'relative' : undefined,
            display: 'flex',
            flexDirection: 'column'
        }}>
            <PreviewRenderer component={rootComponent} />
        </Box>
    );

    return wrapContent(content);
};
