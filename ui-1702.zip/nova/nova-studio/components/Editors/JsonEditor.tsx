/* eslint-disable */
import React from 'react';
import Editor from '@monaco-editor/react';
import { useNova } from '../../../nova-core';

export const JsonEditor: React.FC = () => {
    const { exportDesign, importDesign } = useNova();
    const json = exportDesign();

    const handleChange = (value: string | undefined) => {
        if (value) {
            importDesign(value);
        }
    };

    return (
        <Editor
            height="100%"
            defaultLanguage="json"
            value={json}
            onChange={handleChange}
            options={{
                minimap: { enabled: false },
                formatOnPaste: true,
                formatOnType: true
            }}
        />
    );
};

