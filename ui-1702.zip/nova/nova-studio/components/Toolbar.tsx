/* eslint-disable */
import React, { useState, useMemo } from 'react';
import { useDrag } from 'react-dnd';
import { COMPONENT_REGISTRY } from '../../nova-core/registry/component-registry';
import { Box, Typography, Paper, Grid, GridItem } from '../../../seker-ui-lib';
import SearchIcon from '@mui/icons-material/Search';
import { TextField, InputAdornment } from '@mui/material';

const DraggableItem = ({ type, name }: { type: string; name: string }) => {
    const [{ isDragging }, drag] = useDrag(() => ({
        type: 'COMPONENT', // Global type for dnd
        item: { type }, // What we are dragging
        collect: (monitor) => ({
            isDragging: !!monitor.isDragging(),
        }),
    }));

    return (
        <Paper
            ref={drag}
            sx={{
                p: 1,
                mb: 1,
                cursor: 'grab',
                opacity: isDragging ? 0.5 : 1,
                border: '1px solid #ccc',
                '&:hover': {
                    backgroundColor: '#f5f5f5'
                }
            }}
        >
            <Typography variant="body2">{name}</Typography>
        </Paper>
    );
};

export const Toolbar: React.FC = () => {
    const categories = ['Layout', 'Form','Set', 'Display', 'Others'];
    const [searchQuery, setSearchQuery] = useState('');

    // Filter components based on search query
    const filteredComponents = useMemo(() => {
        const query = searchQuery.toLowerCase().trim();

        if (!query) {
            // No search - return all components grouped by category
            return categories.map(category => ({
                category,
                components: Object.entries(COMPONENT_REGISTRY)
                    .filter(([_, config]) => config.category === category && config.showInDesignerToolbar)
            })).filter(group => group.components.length > 0);
        }

        // Search - return matching components across all categories
        const allComponents = Object.entries(COMPONENT_REGISTRY)
            .filter(([_, config]) =>
                config.showInDesignerToolbar &&
                (config.name.toLowerCase().includes(query) ||
                 config.category.toLowerCase().includes(query))
            );

        // Group filtered results by category
        return categories.map(category => ({
            category,
            components: allComponents.filter(([_, config]) => config.category === category)
        })).filter(group => group.components.length > 0);
    }, [searchQuery]);

    return (
        <Box sx={{ p: 2, height: '100%', display: 'flex', flexDirection: 'column', borderRight: '1px solid #ddd' }}>
            <Typography variant="h6" gutterBottom>Components</Typography>

            {/* Search Input */}
            <Box sx={{ mb: 2 }}>
                <TextField
                    fullWidth
                    placeholder="Search components..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <SearchIcon fontSize="small" />
                            </InputAdornment>
                        ),
                    }}
                    size="small"
                    variant="outlined"
                />
            </Box>

            {/* Scrollable Component List */}
            <Box sx={{ flex: 1, overflowY: 'auto' }}>
                {filteredComponents.length === 0 ? (
                    <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', mt: 4 }}>
                        No components found
                    </Typography>
                ) : (
                    filteredComponents.map(({ category, components }) => (
                        <Box key={category} sx={{ mb: 2 }}>
                            <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary', fontWeight: 'bold' }}>
                                {category}
                            </Typography>
                            <Grid container spacing={1}>
                                {components.map(([key, config]) => (
                                    <GridItem xs={6} key={key}>
                                        <DraggableItem type={key} name={config.name} />
                                    </GridItem>
                                ))}
                            </Grid>
                        </Box>
                    ))
                )}
            </Box>
        </Box>
    );
};

