/* eslint-disable */
import React from 'react';
import { Box } from '@mui/material';

interface GridLines {
    columns: number[];
    rows: number[];
}

interface CoordinateGridOverlayProps {
    gridLines: GridLines;
    visible?: boolean;
    gridColor?: string;
    containerWidth?: number;
    containerHeight?: number;
}

/**
 * CoordinateGridOverlay
 *
 * Renders a visual overlay showing the grid columns and rows.
 * Displays dotted lines at each grid track boundary to help
 * visualize component positioning in design mode.
 */
export const CoordinateGridOverlay: React.FC<CoordinateGridOverlayProps> = ({
    gridLines,
    visible = true,
    gridColor = '#eb7a34',
    containerWidth = 960,
    containerHeight = 600,
}) => {
    if (!visible || (gridLines.columns.length === 0 && gridLines.rows.length === 0)) {
        return null;
    }

    // Calculate dimensions from grid lines
    const maxX = gridLines.columns.length > 0 ? Math.max(...gridLines.columns) : containerWidth;
    const maxY = gridLines.rows.length > 0 ? Math.max(...gridLines.rows) : containerHeight;

    return (
        <Box
            sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: Math.max(maxX, containerWidth),
                height: Math.max(maxY, containerHeight),
                pointerEvents: 'none',
                zIndex: 999,
            }}
        >
            {/* Vertical lines (column boundaries) */}
            {gridLines.columns.map((x, index) => (
                <Box
                    key={`col-${index}`}
                    sx={{
                        position: 'absolute',
                        left: x,
                        top: 0,
                        width: 0,
                        height: '100%',
                        borderLeft: `1px dotted ${gridColor}`,
                    }}
                >
                    {/* Column marker dot */}
                    <Box
                        sx={{
                            position: 'absolute',
                            top: 0,
                            left: -3,
                            width: 6,
                            height: 6,
                            backgroundColor: gridColor,
                            borderRadius: '50%',
                            opacity: 0.8,
                        }}
                    />
                    {/* Column line number */}
                    <Box
                        sx={{
                            position: 'absolute',
                            left: 4,
                            top: 8,
                            fontSize: '9px',
                            color: gridColor,
                            fontWeight: 'bold',
                            opacity: 0.9,
                            backgroundColor: 'rgba(255, 255, 255, 0.8)',
                            padding: '0 2px',
                            borderRadius: '2px',
                        }}
                    >
                        {index + 1}
                    </Box>
                </Box>
            ))}

            {/* Horizontal lines (row boundaries) */}
            {gridLines.rows.map((y, index) => (
                <Box
                    key={`row-${index}`}
                    sx={{
                        position: 'absolute',
                        left: 0,
                        top: y,
                        width: '100%',
                        height: 0,
                        borderTop: `1px dotted ${gridColor}`,
                    }}
                >
                    {/* Row marker dot */}
                    <Box
                        sx={{
                            position: 'absolute',
                            left: 0,
                            top: -3,
                            width: 6,
                            height: 6,
                            backgroundColor: gridColor,
                            borderRadius: '50%',
                            opacity: 0.8,
                        }}
                    />
                    {/* Row line number */}
                    <Box
                        sx={{
                            position: 'absolute',
                            left: 8,
                            top: 4,
                            fontSize: '9px',
                            color: gridColor,
                            fontWeight: 'bold',
                            opacity: 0.9,
                            backgroundColor: 'rgba(255, 255, 255, 0.8)',
                            padding: '0 2px',
                            borderRadius: '2px',
                        }}
                    >
                        {index + 1}
                    </Box>
                </Box>
            ))}

            {/* Grid info label */}
            <Box
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    fontSize: '10px',
                    color: gridColor,
                    fontWeight: 'bold',
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    padding: '2px 6px',
                    borderRadius: '4px',
                    border: `1px solid ${gridColor}`,
                }}
            >
                {gridLines.columns.length} cols × {gridLines.rows.length} rows
            </Box>
        </Box>
    );
};

export default CoordinateGridOverlay;
