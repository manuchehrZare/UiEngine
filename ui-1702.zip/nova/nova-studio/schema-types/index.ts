/* eslint-disable */
import { FormSchemas } from './form';
import { DisplaySchemas } from './display';
import { LayoutSchemas } from './layout';
import { SetSchemas } from './set';
import { createSchema, type PropertySchema } from './schema';
import { commonFormProps } from './common';

// Define schemas for 'Others' category (Currency, IBAN from previous interactions)
const OthersSchemas = {
    Currency: createSchema('Currency', 'Others', [
        ...commonFormProps,
        { name: 'currency', type: 'string', label: 'Currency Symbol' },
        // Currency specific props
    ]),
    IBAN: createSchema('IBAN', 'Others', [
        ...commonFormProps,
        { name: 'input', type: 'boolean', label: 'Input Mode', defaultValue: true },
        // IBAN specific props
    ])
};

export const ComponentSchemas = {
    ...FormSchemas,
    ...DisplaySchemas,
    ...LayoutSchemas,
    ...SetSchemas,
    ...OthersSchemas,
};

export const DefaultSchema = createSchema('Default', 'Common', [
    { name: 'id', type: 'string', label: 'ID' },
    { name: 'className', type: 'string', label: 'Class Name' }
]);

export type { PropertySchema };
export { createSchema };
export { buttonProperties } from './set';
