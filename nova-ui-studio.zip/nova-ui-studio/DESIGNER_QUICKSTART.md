# UI Designer - Quick Start Guide

## Overview

The UI Designer is a comprehensive drag & drop visual design tool for creating pages and forms with real-time code editing capabilities.

## Features

- ✅ Drag & drop component palette
- ✅ Visual designer with component selection
- ✅ Multi-mode editing (Visual, Code, JSON, CSS)
- ✅ Dynamic properties panel
- ✅ Multi-level nested layouts
- ✅ JSON import/export
- ✅ Extensible component provider system

## Access

Navigate to `/designer` in your browser to open the UI Designer.

## Interface Layout

```
┌─────────────────────────────────────────────────────────────┐
│  [Import] [Export] [Clear All]                             │  ← Actions Bar
├──────────┬────────────────────────────────────┬─────────────┤
│          │                                    │             │
│          │  [👁️ Visual] [💻 Code]             │             │  ← Mode Tabs
│          │  [📋 JSON]   [🎨 CSS]               │             │
│          │                                    │             │
│  Tool-   │                                    │ Properties  │
│  bar     │        Design Canvas               │   Panel     │
│          │                                    │             │
│  📦 Box  │   Drop components here...          │ Component   │
│  🔲 Grid │                                    │ Settings    │
│  📝 Input│                                    │             │
│  🔘 Button                                    │             │
│          │                                    │             │
└──────────┴────────────────────────────────────┴─────────────┘
```

## Quick Tutorial

### 1. Create Your First Layout

1. **Drag a Grid** from the toolbar to the canvas
2. **Drag a GridItem** and drop it on the Grid
3. **Drag a Label** and drop it on the GridItem
4. Click on any component to see its properties

### 2. Edit Properties

1. Click on the Label you just created
2. In the Properties Panel (right side), change the "Text" property
3. See the change reflected immediately in the visual designer

### 3. Build a Form

```
Grid (container, spacing=2)
  └─ GridItem (xs=12)
       └─ Paper
            ├─ Label (text="User Form")
            ├─ Input (label="Name")
            ├─ Input (label="Email")
            └─ Button (text="Submit")
```

Steps:
1. Drag **Grid** to canvas
2. Drag **GridItem** onto Grid
3. Drag **Paper** onto GridItem
4. Drag **Label**, **Input** (twice), and **Button** onto Paper
5. Select each and configure properties

### 4. Export Your Design

1. Click **Export** button (top bar)
2. A JSON file will download
3. Save it for later use

### 5. Import a Design

1. Click **Import** button
2. Select a previously exported JSON file
3. Your design loads into the canvas

## Component Categories

### Layout Components

- **Box**: General purpose container
- **Grid**: Responsive grid container (use with GridItem)
- **GridItem**: Grid column (xs=12 is full width)
- **Paper**: Material design elevated container
- **Tab/TabItem**: Tabbed interface
- **Divider**: Horizontal line

### Input Components

- **Button**: Clickable button
- **Input**: Text input field

### Display Components

- **Label**: Text display
- **DataGrid**: Table with columns and rows

## Common Patterns

### Responsive Two-Column Layout

```
Grid (container, spacing=2)
  ├─ GridItem (xs=12, md=6)
  │   └─ [Left content]
  └─ GridItem (xs=12, md=6)
      └─ [Right content]
```

### Card Layout

```
Paper
  └─ Box (p=2)
       ├─ Label (text="Title")
       ├─ Divider
       └─ Label (text="Content")
```

### Form Layout

```
Grid (container, spacing=2)
  ├─ GridItem (xs=12)
  │   └─ Label (text="Form Title")
  ├─ GridItem (xs=12, md=6)
  │   └─ Input (label="First Name")
  ├─ GridItem (xs=12, md=6)
  │   └─ Input (label="Last Name")
  └─ GridItem (xs=12)
      └─ Button (text="Submit")
```

## Keyboard Shortcuts

- **Delete**: Remove selected component (when properties panel is active)

## Tips & Tricks

### 1. Grid Sizes

- `xs=12`: Full width on extra small screens
- `xs=6`: Half width on extra small screens
- `md=4`: One third width on medium+ screens
- Use combinations for responsive layouts

### 2. Component Selection

- Click on any component in visual mode to select it
- Selected component shows blue border
- Properties panel updates to show selected component's settings

### 3. Nested Containers

- You can drop containers into containers
- Example: Grid → GridItem → Paper → Box → Label
- Maximum recommended nesting: 5 levels

### 4. Visual Indicators

- **Blue solid border**: Selected component
- **Blue dashed border**: Component being dragged over (drop target)
- **Hover effect**: Available drop zone

### 5. Mode Switching

- **Visual Mode**: Drag & drop designing
- **JSON Mode**: View/edit raw JSON structure
- **CSS Mode**: View generated CSS styles
- **Code Mode**: Add custom JavaScript code

## Troubleshooting

### Component Won't Drop

- Make sure you're dropping on a valid container (Grid, Box, Paper, GridItem)
- Some components only accept specific children (Grid accepts GridItem)

### Properties Not Showing

- Click on the component to select it first
- Properties panel shows "No component selected" when nothing is clicked

### Layout Looks Different on Mobile

- This is normal for responsive designs
- Use Grid with xs/sm/md/lg props for responsive behavior
- Test with browser dev tools responsive mode

### Export Button Not Working

- Check browser's download settings
- Look in your Downloads folder for `ui-design.json`

### Import Fails

- Ensure JSON file is valid
- File must be from this designer (same format)
- Check console for error messages

## Advanced Usage

### Creating Custom Components

See `src/designer/README.md` for detailed instructions on:
- Registering custom component providers
- Defining property schemas
- Adding components to the renderer

### Extending Property Types

Current supported types:
- `string`: Text input
- `number`: Number input
- `boolean`: Toggle button
- `select`: Option buttons

### JSON Structure

Components are stored as:
```json
{
  "id": "unique-id",
  "type": "ComponentType",
  "name": "Display Name",
  "category": "Layout",
  "properties": { "prop1": "value1" },
  "children": [],
  "styles": {}
}
```

## Next Steps

1. ✅ Create your first layout
2. ✅ Experiment with different components
3. ✅ Build a complete form
4. ✅ Export and import your design
5. ✅ Try all four editing modes
6. 📚 Read the full documentation in `src/designer/README.md`
7. 🎨 Create custom components for your needs

## Support

For issues or questions:
- Check `src/designer/README.md` for detailed documentation
- Review component definitions in `src/designer/ComponentProvider.tsx`
- Inspect example designs in the designer

## Summary

The UI Designer provides a powerful visual way to create UIs with:
- Drag & drop simplicity
- Real-time editing
- Multi-level layouts
- Import/export capability
- Extensible architecture

Start designing and build beautiful UIs visually!
