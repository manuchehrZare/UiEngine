import type { FC } from 'react';
import { Children, useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, Button, ButtonGroup, Nav, Label } from '../../../../lib';

const ButtonGroupPage: FC = () => {
    const [activeButton, setActiveButton] = useState(0);
    return (
        <Layout>
            <Grid spacingType="common" p={1}>
                <GridItem lg>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Group' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Label text="Large" />
                                    <ButtonGroup>
                                        <Button size="large" text="One" />
                                        <Button size="large" text="Two" variant="outlined" />
                                        <Button size="large" text="Three" />
                                    </ButtonGroup>
                                </GridItem>
                                <GridItem>
                                    <Label text="Medium" />
                                    <ButtonGroup>
                                        <Button text="One" />
                                        <Button text="Two" variant="outlined" />
                                        <Button text="Three" />
                                    </ButtonGroup>
                                </GridItem>
                                <GridItem>
                                    <Label text="Small" />
                                    <ButtonGroup>
                                        <Button size="small" text="One" />
                                        <Button size="small" text="Two" variant="outlined" />
                                        <Button size="small" text="Three" />
                                    </ButtonGroup>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Group - Example' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Label text="Active Control" />
                                    <ButtonGroup>
                                        {Children.map([0, 1, 2], (index) => (
                                            <Button
                                                text={String(index)}
                                                variant={activeButton === index ? 'contained' : 'outlined'}
                                                onClick={() => setActiveButton(index)}
                                            />
                                        ))}
                                    </ButtonGroup>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ButtonGroupPage;
