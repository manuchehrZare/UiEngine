import type { FC } from 'react';
import { useState } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    Checkbox,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Nav,
    Paper,
    Radio,
    RadioGroup,
    useForm,
} from '../../../../../lib';
import type { IExampleData } from '../data';
import { rowsExampleNoId } from '../data';

const DataGridExamplePage: FC = () => {
    const [data] = useState<IExampleData[]>(rowsExampleNoId);

    const { control } = useForm({
        defaultValues: {
            mainAcc: null,
            crossTransactionAccs: data.map(() => false),
        } as any,
    });

    const cols: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            width: 90,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'age',
            headerName: 'Yaş',
            width: 90,
        },
        {
            field: 'fullName',
            headerName: 'İsim',
            width: 90,
            renderCell: (params) => params.value,
        },
        {
            field: 'isMainAcc',
            headerName: 'Ana Hesap',
            headerAlign: 'center',
            minWidth: 50,
            flex: 1,
            align: 'center',
            renderCell: (params) => {
                return (
                    <RadioGroup name="mainAcc" control={control}>
                        <Radio value={Number(params.id)} />
                    </RadioGroup>
                );
            },
        },
        {
            field: 'crossTransactionAcc',
            headerName: 'Çapraz İşlemler Hesabı',
            headerAlign: 'center',
            minWidth: 50,
            flex: 1,
            align: 'center',
            renderCell: (params) => {
                return <Checkbox name={`crossTransactionAccs[${params.id}]`} control={control} />;
            },
        },
        {
            field: 'bool',
            headerName: 'Bool',
            headerAlign: 'center',
            minWidth: 50,
            flex: 1,
            align: 'center',
            type: DataGridColumnTypeEnum.boolean,
        },
    ];

    return (
        <Grid spacingType="common">
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Example - Custom Cell (Radio & Checkbox)' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    // density="comfortable"
                                    // headerHeight={35}
                                    rowHeight={50}
                                    toolbar={false}
                                    // checkboxSelection
                                    sx={{
                                        height: 50 * data.length,
                                        // border: 1,
                                    }}
                                    columns={cols}
                                    rows={data}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridExamplePage;
