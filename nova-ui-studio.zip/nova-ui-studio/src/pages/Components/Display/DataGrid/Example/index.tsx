import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Box, DataGrid, DataGridColumnTypeEnum, Grid, GridItem, Nav, Paper } from '../../../../../lib';
import type { IExampleData } from '../data';
import { rowsExample, rowsExampleNoId } from '../data';

const DataGridExamplePage: FC = () => {
    const [data, setData] = useState<IExampleData[]>(rowsExampleNoId);

    useEffect(() => {
        const timeOut = setTimeout(() => {
            setData(data.filter((_, index) => index !== 0));
        }, 2000);
        return () => {
            clearTimeout(timeOut);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Grid spacingType="common">
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Example' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    // density="comfortable"
                                    // headerHeight={35}
                                    rowHeight={25}
                                    autoPageSize
                                    pageSize={5}
                                    pagination
                                    toolbar={false}
                                    // checkboxSelection
                                    sx={{
                                        height: 225,
                                        // border: 1,
                                    }}
                                    // toolbar
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'id',
                                            headerName: 'Id',
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                        },
                                    ]}
                                    rows={rowsExample}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: "Data Grid - 'counter' Column Type" }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    // density="comfortable"
                                    // headerHeight={35}
                                    // rowHeight={25}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                        },
                                    ]}
                                    rows={data}
                                    selectionOnClickable
                                    disableMultipleRowSelection
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridExamplePage;
