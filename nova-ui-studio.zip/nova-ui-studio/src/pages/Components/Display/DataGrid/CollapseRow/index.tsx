import type { FC } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Nav,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
} from '../../../../../lib';
import { employeesData } from '../data';

const DataGridCollapseRowPage: FC = () => {
    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
            headerAlign: 'center',
            align: 'center',
        },
        {
            field: 'firstName',
            headerName: 'Ad',
            headerAlign: 'center',
            align: 'center',
            flex: 1,
        },
        {
            field: 'lastName',
            headerName: 'Soyad',
            headerAlign: 'center',
            align: 'center',
            flex: 1,
        },
    ];

    return (
        <Grid spacing={1}>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Collapse Row' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 200 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            getDetailPanelHeight={() => 'auto'}
                                            getDetailPanelContent={(row) => {
                                                return (
                                                    <Grid>
                                                        <GridItem p={1}>
                                                            <Paper>
                                                                <Table>
                                                                    <TableHead>
                                                                        <TableRow>
                                                                            <TableCell>Kullanıcı Adı</TableCell>
                                                                            <TableCell>Meslek</TableCell>
                                                                            <TableCell>Tam Ad</TableCell>
                                                                            <TableCell>Yaş</TableCell>
                                                                            <TableCell>Çalışan Kodu</TableCell>
                                                                            <TableCell>Bölge</TableCell>
                                                                            <TableCell>Telefon Numarası</TableCell>
                                                                            <TableCell>Email</TableCell>
                                                                        </TableRow>
                                                                    </TableHead>
                                                                    <TableBody>
                                                                        <TableRow>
                                                                            <TableCell>{row.row?.userId}</TableCell>
                                                                            <TableCell>
                                                                                {row.row?.jobTitleName}
                                                                            </TableCell>
                                                                            <TableCell>
                                                                                {row.row?.preferredFullName}
                                                                            </TableCell>
                                                                            <TableCell>{row.row?.age}</TableCell>
                                                                            <TableCell>
                                                                                {row.row?.employeeCode}
                                                                            </TableCell>
                                                                            <TableCell>{row.row?.region}</TableCell>
                                                                            <TableCell>
                                                                                {row.row?.phoneNumber}
                                                                            </TableCell>
                                                                            <TableCell>
                                                                                {row.row?.emailAddress}
                                                                            </TableCell>
                                                                        </TableRow>
                                                                    </TableBody>
                                                                </Table>
                                                            </Paper>
                                                        </GridItem>
                                                    </Grid>
                                                );
                                            }}
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridCollapseRowPage;
