import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Label,
    Nav,
    Paper,
    useDataGridApiRef,
} from '../../../../../lib';

interface IData {
    abbreviation?: string;
    age: number | null;
    budget?: string;
    checkbox?: boolean;
    date?: Date;
    firstName: string | null;
    id: number;
    lastName: string;
}

const DataGridCheckboxPage: FC = () => {
    const apiRef = useDataGridApiRef();
    const [dataGridData, setDataGridData] = useState<any[]>([]);

    // * rows = data
    const rowsData1: IData[] = [
        {
            id: 1,
            lastName: 'Snow',
            firstName: 'Jon',
            abbreviation: 'JS',
            age: 35,
            budget: '10000',
            checkbox: true,
            date: new Date(),
        },
        {
            id: 2,
            lastName: 'Lannister',
            firstName: 'Cersei',
            abbreviation: 'CL',
            age: 42,
            budget: '20000',
            checkbox: true,
        },
        {
            id: 3,
            lastName: 'Lannister',
            firstName: 'Cersei',
            abbreviation: 'CL',
            age: 42,
            budget: '77777',
        },
        {
            id: 4,
            lastName: 'Lannister',
            firstName: 'Cersei',
            abbreviation: 'CL',
            age: 42,
            budget: '7777',
            checkbox: false,
        },
        {
            id: 5,
            lastName: 'Lannister',
            firstName: 'Jaime',
            abbreviation: 'JL',
            age: 45,
            budget: '30000',
            checkbox: true,
        },
        {
            id: 6,
            lastName: 'Stark',
            firstName: 'Arya',
            age: 16,
            abbreviation: 'AS',
            budget: '15000',
            checkbox: true,
            date: new Date(),
        },
        {
            id: 7,
            lastName: 'Targaryen',
            firstName: 'Daenerys',
            abbreviation: 'DT',
            age: null,
            budget: '10000.75',
            checkbox: false,
        },
        {
            id: 8,
            lastName: 'Melisandre',
            firstName: null,
            abbreviation: 'M',
            age: 150,
            budget: '123123.123',
            checkbox: true,
        },
        {
            id: 9,
            lastName: 'Clifford',
            firstName: 'Ferrara',
            abbreviation: 'FC',
            age: 44,
            budget: '500000',
            checkbox: true,
        },
        {
            id: 10,
            lastName: 'Frances',
            firstName: 'Rossini',
            abbreviation: 'RF',
            age: 36,
            budget: '200000',
            checkbox: true,
        },
        {
            id: 11,
            lastName: 'Frances',
            firstName: 'Rossini',
            abbreviation: 'RF',
            age: 36,
            budget: '0',
            checkbox: true,
        },
        {
            id: 12,
            lastName: 'Frances',
            firstName: 'Rossini',
            abbreviation: 'RF',
            age: 36,
            budget: '',
            checkbox: true,
        },
        {
            id: 13,
            lastName: 'Roxie',
            firstName: 'Harvey',
            abbreviation: 'HR',
            age: 65,
            checkbox: true,
        },
    ];

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            width: 90,
            editable: true,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'checkbox',
            headerAlign: 'center',
            align: 'center',
            headerName: 'Checkbox',
            flex: 1,
            minWidth: 120,
            editable: true,
            type: 'boolean',
        },
        {
            field: 'firstName',
            headerName: 'First name',
            width: 150,
            minWidth: 150,
            maxWidth: 200,
            description: 'The identification used by the person with access to the online service.',
            flex: 1,
            type: '',
            // resizable: false,
            // hideable: false,
            align: 'right',
            headerAlign: 'right',
            disableColumnMenu: true,
            // disableExport: true,
            editable: true,
            sortable: true,
            sortingOrder: ['desc', 'asc', null],
            filterable: false,
        },
        {
            field: 'lastName',
            headerName: 'Last nameeeeee',
            width: 150,
            editable: true,
            renderCell: (params) => {
                return (
                    <Box
                        component="div"
                        sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            width: '100%',
                        }}>
                        <Label
                            text={params.value}
                            className="MuiDataGrid-cellContent"
                            color="common.black"
                            fontWeight={400}
                        />
                    </Box>
                );
            },
        },
        {
            field: 'abbreviation',
            headerName: 'Abbreviation',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.abbreviation,
        },
        {
            field: 'age',
            headerName: 'Age',
            headerAlign: 'center',
            type: 'number',
            width: 110,
            editable: true,
            sortable: false,
        },
        {
            field: 'date',
            headerName: 'Date',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.date,
            editable: true,
            flex: 1,
        },
        {
            field: 'budget',
            headerName: 'Budget',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.currency,
            editable: true,
            flex: 1,
        },
    ];

    useEffect(() => {
        // eslint-disable-next-line
        setDataGridData(rowsData1);
        // eslint-disable-next-line
    }, []);

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Checkbox' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRef}
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    selectionOnClickable
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridCheckboxPage;
