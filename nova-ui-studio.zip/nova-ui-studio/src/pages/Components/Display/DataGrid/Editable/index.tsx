import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Nav,
    Paper,
    message,
    randomNumber,
} from '../../../../../lib';
import type { IExampleData } from '../data';
import { rowsExample } from '../data';

const DataGridEditablePage: FC = () => {
    const [data, setData] = useState<IExampleData[]>([]);

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'id',
            headerName: 'Id',
            editable: false,
        },
        {
            field: 'fullName',
            headerName: 'Full Name',
        },
        {
            field: 'age',
            headerName: 'Age',
        },
    ];

    useEffect(() => {
        const timeOut = setTimeout(() => {
            setData(rowsExample);
        }, 500);
        message({ variant: 'info', message: 'Check console after edit datagrid to see onEditChange function params' });
        return () => {
            clearTimeout(timeOut);
        };
    }, []);

    const generateRandomDate = (from: any, to: any) => {
        const fromTime = from.getTime();
        const toTime = to.getTime();
        // Generate a secure floating-point number between 0 and 1
        const randomFraction = randomNumber(0, 1, { precision: 10 });
        // Scale to timestamp range and return Date
        return new Date(fromTime + randomFraction * (toTime - fromTime));
    };

    const countryList = [
        { code: 'TR', name: 'Türkiye' },
        { code: 'BG', name: 'Bulgaria' },
        { code: 'NL', name: 'Netherlands' },
        { code: 'FR', name: 'France' },
        { code: 'UK', name: 'United Kingdom' },
        { code: 'ES', name: 'Spain' },
        { code: 'BR', name: 'Brazil' },
    ];

    return (
        <Grid spacing={1} p={1}>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'editMode="cell" (default)' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data}
                                    columns={columns}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'editMode="row"' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editMode="row"
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data}
                                    columns={columns}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Age type number' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'id',
                                            headerName: 'Id',
                                            editable: false,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                            type: 'number',
                                        },
                                    ]}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'type boolean' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'bool',
                                            headerName: 'Bool',
                                            type: 'boolean',
                                        },
                                        {
                                            field: 'id',
                                            headerName: 'Id',
                                            editable: false,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                            type: 'number',
                                        },
                                    ]}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Date type date' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data.map((item) => {
                                        return {
                                            ...item,
                                            date: generateRandomDate(
                                                new Date(2023 - Number(item.age), 0, 1),
                                                new Date(),
                                            ),
                                        };
                                    })}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                        },
                                        {
                                            field: 'date',
                                            headerName: 'Date',
                                            type: 'date',
                                        },
                                    ]}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Date type datetime' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data.map((item) => {
                                        return {
                                            ...item,
                                            date: generateRandomDate(
                                                new Date(2023 - Number(item.age), 0, 1),
                                                new Date(),
                                            ),
                                        };
                                    })}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                        },
                                        {
                                            field: 'date',
                                            headerName: 'Date',
                                            type: 'dateTime',
                                            flex: 1,
                                        },
                                    ]}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'single select edit' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data.map((item) => {
                                        return {
                                            ...item,
                                            country: countryList[randomNumber(0, countryList.length - 1)].code,
                                        };
                                    })}
                                    toolbarProps={{
                                        fileOptions: {
                                            import: {
                                                onImport: (importData) =>
                                                    importData.map((item) => {
                                                        return {
                                                            ...item,
                                                            country: countryList
                                                                .map((countryItem) => countryItem.name)
                                                                .includes(item.country)
                                                                ? countryList.find(
                                                                      (countryItem) =>
                                                                          countryItem.name === item.country,
                                                                  )?.code
                                                                : item?.country,
                                                        };
                                                    }),
                                            },
                                        },
                                    }}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                        },
                                        {
                                            field: 'country',
                                            headerName: 'Country',
                                            type: 'singleSelect',
                                            valueOptions: countryList,
                                            getOptionValue: (value: any) => value.code,
                                            getOptionLabel: (value: any) => value.name,
                                            flex: 1,
                                        },
                                    ]}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'type currency' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    editable
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={data}
                                    columns={[
                                        {
                                            field: 'no',
                                            headerName: 'No',
                                            type: DataGridColumnTypeEnum.counter,
                                        },
                                        {
                                            field: 'fullName',
                                            headerName: 'Full Name',
                                        },
                                        {
                                            field: 'age',
                                            headerName: 'Age',
                                        },
                                        {
                                            field: 'currency',
                                            headerName: 'Currency',
                                            headerAlign: 'center',
                                            minWidth: 100,
                                            type: DataGridColumnTypeEnum.currency,
                                            flex: 1,
                                        },
                                    ]}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridEditablePage;
