import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    Grid,
    GridItem,
    Paper,
    DataGrid,
    Button,
    Nav,
    Label,
    DataGridColumnTypeEnum,
    useDataGridApiRef,
} from '../../../../../lib';

interface IData {
    abbreviation?: string;
    age: number | null;
    bool?: boolean;
    budget?: string;
    date?: Date;
    firstName: string | null;
    id: number;
    lastName: string;
}

const DataGridBasicPage: FC = () => {
    const apiRef = useDataGridApiRef();
    const [hiddenColumns, setHiddenColumns] = useState<string[]>(['date']);
    const [dataGridData, setDataGridData] = useState<IData[]>([]);

    // * rows = data
    const rowsData1: IData[] = [
        {
            id: 1,
            lastName: 'Snow',
            firstName: 'Jon',
            abbreviation: 'JS',
            age: 35,
            budget: '10000',
            date: new Date(),
            bool: true,
        },
        {
            id: 2,
            lastName: 'Lannister',
            firstName: 'Cersei',
            abbreviation: 'CL',
            age: 42,
            budget: '20000',
        },
        {
            id: 2,
            lastName: 'Lannister',
            firstName: 'Cersei',
            abbreviation: 'CL',
            age: 42,
            budget: '77777',
        },
        {
            id: 2,
            lastName: 'Lannister',
            firstName: 'Cersei',
            abbreviation: 'CL',
            age: 42,
            budget: '7777',
        },
        {
            id: 3,
            lastName: 'Lannister',
            firstName: 'Jaime',
            abbreviation: 'JL',
            age: 45,
            budget: '30000',
        },
        {
            id: 4,
            lastName: 'Stark',
            firstName: 'Arya',
            age: 16,
            abbreviation: 'AS',
            budget: '15000',
            date: new Date(),
        },
        {
            id: 5,
            lastName: 'Targaryen',
            firstName: 'Daenerys',
            abbreviation: 'DT',
            age: null,
            budget: '10000.75',
        },
        {
            id: 6,
            lastName: 'Melisandre',
            firstName: null,
            abbreviation: 'M',
            age: 150,
            budget: '123123.123',
        },
        {
            id: 7,
            lastName: 'Clifford',
            firstName: 'Ferrara',
            abbreviation: 'FC',
            age: 44,
            budget: '500000',
        },
        {
            id: 8,
            lastName: 'Frances',
            firstName: 'Rossini',
            abbreviation: 'RF',
            age: 36,
            budget: '200000',
        },
        {
            id: 8,
            lastName: 'Frances',
            firstName: 'Rossini',
            abbreviation: 'RF',
            age: 36,
            budget: '0',
        },
        {
            id: 8,
            lastName: 'Frances',
            firstName: 'Rossini',
            abbreviation: 'RF',
            age: 36,
            budget: '',
        },
        {
            id: 9,
            lastName: 'Roxie',
            firstName: 'Harvey',
            abbreviation: 'HR',
            age: 65,
        },
    ];

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            width: 90,
            editable: true,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'bool',
            headerName: 'Bool',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.boolean,
        },
        {
            field: 'firstName',
            headerName: 'First name',
            width: 150,
            minWidth: 150,
            maxWidth: 200,
            description: 'The identification used by the person with access to the online service.',
            flex: 1,
            type: '',
            // resizable: false,
            // hideable: false,
            align: 'right',
            headerAlign: 'right',
            disableColumnMenu: true,
            // disableExport: true,
            editable: true,
            sortable: true,
            sortingOrder: ['desc', 'asc', null],
            filterable: false,
        },
        {
            field: 'lastName',
            headerName: 'Last nameeeeee',
            width: 150,
            editable: true,
            renderCell: (params) => {
                return (
                    <Box
                        component="div"
                        sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            width: '100%',
                        }}>
                        <Label
                            text={params.value}
                            className="MuiDataGrid-cellContent"
                            color="common.black"
                            fontWeight={400}
                        />
                    </Box>
                );
            },
        },
        {
            field: 'abbreviation',
            headerName: 'Abbreviation',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.abbreviation,
        },
        {
            field: 'age',
            headerName: 'Age',
            headerAlign: 'center',
            type: 'number',
            width: 110,
            editable: true,
            sortable: false,
        },
        {
            field: 'date',
            headerName: 'Date',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.date,
            editable: true,
            flex: 1,
        },
        {
            field: 'budget',
            headerName: 'Budget',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.currency,
            editable: true,
            flex: 1,
        },
    ];

    useEffect(() => {
        setDataGridData(rowsData1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Basic' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Button
                                    text={`${hiddenColumns.length ? 'Show' : 'Hidden'} 'date' Column`}
                                    onClick={() => setHiddenColumns(hiddenColumns.length ? [] : ['date'])}
                                />
                            </GridItem>
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRef}
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    // toolbarProps={{
                                    //     fileOptions: {
                                    //         import: {
                                    //             onImport: (data) =>
                                    //                 data.map((item) => {
                                    //                     return { ...item, firstName: 'Custom Import Name' };
                                    //                 }),
                                    //             showXLS: true,
                                    //         },
                                    //         export: {
                                    //             onExport: (data) =>
                                    //                 data.map((item) => {
                                    //                     return {
                                    //                         ...item,
                                    //                         firstName:
                                    //                             item.firstName === 'Jon'
                                    //                                 ? 'Custom Export Name'
                                    //                                 : item.firstName,
                                    //                         lastName:
                                    //                             item.lastName === 'Snow'
                                    //                                 ? 'Custom Export Lastname'
                                    //                                 : item.lastName,
                                    //                     };
                                    //                 }),
                                    //         },
                                    //     },
                                    // }}
                                    // apiRef={apiRef}
                                    // page={1}
                                    // strippedRows={false}
                                    // pageSize={6}
                                    // rowsPerPageOptions={[5, 10, 15]}
                                    // pagination
                                    // checkboxSelection
                                    selectionOnClickable
                                    // selectedCountView
                                    // selectionModel={[1]}
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('onSelectChange params', params);
                                    }}
                                    // selectionOnClickable
                                    // onRowClick={(params) => {
                                    //     // eslint-disable-next-line no-console
                                    //     console.log('params', params);
                                    // }}
                                    // isRowSelectable={(params) => true}
                                    // rowHeight={30}
                                    // headerHeight={50}
                                    // autoPageSize
                                    // loading
                                    // sortModel={[
                                    //     {
                                    //         field: 'lastName',
                                    //         sort: 'desc',
                                    //     },
                                    // ]}
                                    // initialState={{
                                    //     sorting: {
                                    //         sortModel: [
                                    //             {
                                    //                 field: 'lastName',
                                    //                 sort: 'desc',
                                    //             },
                                    //         ],
                                    //     },
                                    // }}
                                    hiddenColumns={hiddenColumns}
                                    onHiddenColumnsChange={(newHiddenModel) => {
                                        // eslint-disable-next-line no-console
                                        console.log('hiddenModel', newHiddenModel);
                                    }}
                                    // onEditRowsModelChange={(model) => {
                                    //     // eslint-disable-next-line no-console
                                    //     console.log(model);
                                    // }}
                                    // editMode="row"
                                    // onRowEditStop={(params) => {
                                    //     // eslint-disable-next-line no-console
                                    //     console.log(params);
                                    // }}
                                    // disableMultipleRowSelection
                                />
                            </GridItem>
                            <GridItem>
                                <Button
                                    text="Remove Row Data id===1"
                                    onClick={() => setDataGridData(dataGridData.filter((row) => row.id !== 1))}
                                />
                            </GridItem>
                            <GridItem>
                                <Button
                                    text="Change Rows Data"
                                    onClick={() =>
                                        setDataGridData([
                                            { lastName: 'Ali', firstName: 'Jon', age: 12, id: 1 },
                                            { lastName: 'Veli', firstName: 'Cersei', age: 13, id: 2 },
                                            { lastName: 'Ayşe', firstName: 'Jaime', age: 14, id: 3 },
                                        ])
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridBasicPage;
