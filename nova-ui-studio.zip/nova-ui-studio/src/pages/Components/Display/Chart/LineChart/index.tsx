import type { FC } from 'react';
import type { ILineChartData } from '../../../../../lib';
import { LineChart, Grid, GridItem, Paper, Box, Nav } from '../../../../../lib';
import { Layout } from '../../../../../App';

const data: ILineChartData[] = [
    {
        name: 'A',
        values: [
            {
                name: 'line1',
                value: 3200,
                valueUI: <div>Custom HTML : 3200 TL</div>,
            },
            { name: 'line2', value: 2500, valueUI: '2500 TL' },
            { name: 'line3', value: 1800, valueUI: '1800 TL' },
        ],
    },
    {
        name: 'B',
        values: [
            {
                name: 'line1',
                value: 500,
                valueUI: <div>Custom HTML : 500 TL</div>,
            },
            { name: 'line2', value: 3200, valueUI: '1400 TL' },
            { name: 'line3', value: 1000, valueUI: '1000 TL' },
        ],
    },
    {
        name: 'C',
        values: [
            {
                name: 'line1',
                value: 2350,
                valueUI: <div>Custom HTML : 2350 TL</div>,
            },
            { name: 'line2', value: 1380, valueUI: '1380 TL' },
            { name: 'line3', value: 2725, valueUI: '1725 TL' },
        ],
    },
    {
        name: 'D',
        values: [
            {
                name: 'line1',
                value: 2900,
                valueUI: <div>Custom HTML : 2900 TL</div>,
            },
            {
                name: 'line2',
                value: 1500,
                valueUI: <div>Custom Tooltip : 1500 TL</div>,
            },
            {
                name: 'line3',
                value: 2100,
                valueUI: <div>Custom Teset tooltip : 2100 TL</div>,
            },
        ],
    },
];
const colors: string[] = ['#127a3d', '#7db900', '#c3da0d'];

const LineChartPage: FC = () => {
    const chartName: string = 'Line Chart';
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Default' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart colors={colors} data={data} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Tooltip' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart
                                colors={colors}
                                data={data}
                                tooltip={{
                                    backgroundColor: 'pink',
                                    border: '5px solid brown',
                                    boxShadow: '50px black',
                                    labelColor: 'darkgrey',
                                    seperator: '>',
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Legend' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart colors={colors} data={data} legend={{ margin: 30 }} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Vertical' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart colors={colors} layout="vertical" data={data} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Grid' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart grid colors={colors} data={data} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Custom Grid' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart
                                grid={{ fill: '#ffe9ee', strokeDasharray: '1 1', vertical: false }}
                                colors={colors}
                                data={data}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Tick' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart tick={{ color: 'red', angle: { x: -15, y: 20 } }} colors={colors} data={data} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Line Label' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart lineLabels={['line1']} colors={colors} data={data} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Stroke Dash Line' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart lineStrokeDash={{ pv: '3 3' }} colors={colors} data={data} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Reference Line' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart
                                referenceLine={{
                                    labelX: 'Label X',
                                    labelY: 'Label Y',
                                    strokeX: 'red',
                                    strokeY: 'blue',
                                    x: 'Page D',
                                    y: '3000',
                                }}
                                colors={colors}
                                data={data}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName, subTitle: 'Custom Color' }} />
                        <Box sx={{ p: 3 }}>
                            <LineChart colors={['lightblue', 'pink', 'purple']} data={data} />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default LineChartPage;
