import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Button, Grid, GridItem, Nav, Paper, Popup } from '../../../../lib';

const PopupPage: FC = () => {
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Popup' }} />
                        <Box sx={{ p: 3 }}>
                            <Popup
                                // anchorTrigger="hover"
                                anchorEl={<Button text="Popup" />}
                                // tooltip="zsdfasdf"
                                onOpen={() => {
                                    // eslint-disable-next-line no-console
                                    console.log('open');
                                }}
                                onClose={() => {
                                    // eslint-disable-next-line no-console
                                    console.log('close');
                                }}>
                                <div style={{ width: 300, height: 300 }}>Contents</div>
                            </Popup>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default PopupPage;
