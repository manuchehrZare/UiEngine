import type { FC } from 'react';
import { Box, Breadcrumbs, Grid, GridItem, Nav, Paper } from '../../../../lib';
import { Layout } from '../../../../App';
import { HomeRounded, ViewTimeline } from '@mui/icons-material';

const BreadcrumbsPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                    },
                                    {
                                        text: 'Breadcrumbs',
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[{ text: 'Display', link: '/display' }, { text: 'Breadcrumbs' }]}
                                separator=">"
                                design="SET"
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs ICON' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                        link: '/display',
                                        iconLeft: <ViewTimeline sx={{ mr: 0.5 }} fontSize="small" />,
                                    },
                                    {
                                        text: 'Breadcrumbs',
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs Home Icon' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        icon: <HomeRounded fontSize="small" />,
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                        link: '/display',
                                    },
                                    {
                                        text: 'Breadcrumbs',
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs Home show=false' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        show: false,
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                    },
                                    {
                                        text: 'Breadcrumbs',
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs MaxItem&ItemAfterCollapse&ItemBeforeCollapse' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    { text: 'Display', link: '/display' },
                                    { text: 'Display1', link: '/display1' },
                                    { text: 'Display2', link: '/display2' },
                                    { text: 'Display3', link: '/display3' },
                                    { text: 'Display4', link: '/display4' },
                                    { text: 'Display5', link: '/display5' },
                                    { text: 'Breadcrumbs' },
                                ]}
                                maxItems={6}
                                itemsAfterCollapse={2}
                                itemsBeforeCollapse={2}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'BreadcrumbsItem Select' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                        select: [
                                            { text: 'Form', link: '/form' },
                                            { text: 'Display', link: '/display' },
                                            { text: 'Hooks', link: '/hooks' },
                                            { text: 'Utils', link: '/utils' },
                                        ],
                                    },
                                    {
                                        text: 'Breadcrumbs',
                                        select: [
                                            {
                                                text: 'Accordion',
                                                link: '/display/accordion',
                                            },
                                            { text: 'PieChart', link: '/display/pie-chart' },
                                            { text: 'LineChart', link: '/display/line-chart' },
                                            { text: 'BarChart', link: '/display/bar-chart' },
                                            { text: 'EmptyBox' },
                                        ],
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'BreadcrumbsItem Type' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                type="chip"
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                        select: [
                                            { text: 'Form', link: '/form' },
                                            { text: 'Display', link: '/display' },
                                            { text: 'Hooks', link: '/hooks' },
                                            { text: 'Utils', link: '/utils' },
                                        ],
                                    },
                                    {
                                        text: 'Breadcrumbs',
                                        select: [
                                            {
                                                text: 'Accordion',
                                                link: '/display/accordion',
                                            },
                                            { text: 'PieChart', link: '/display/pie-chart' },
                                            { text: 'LineChart', link: '/display/line-chart' },
                                            { text: 'BarChart', link: '/display/bar-chart' },
                                            { text: 'EmptyBox' },
                                        ],
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'BreadcrumbsItem Select With Horizon Icons ' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    {
                                        text: 'Display',
                                        select: [
                                            { text: 'Form', link: '/form' },
                                            { text: 'Display', link: '/display' },
                                            { text: 'Hooks', link: '/hooks' },
                                            { text: 'Utils', link: '/utils' },
                                        ],
                                    },
                                    {
                                        select: [
                                            {
                                                text: 'Accordion',
                                                link: '/display/accordion',
                                            },
                                            { text: 'PieChart', link: '/display/pie-chart' },
                                            { text: 'LineChart', link: '/display/line-chart' },
                                            { text: 'BarChart', link: '/display/bar-chart' },
                                            { text: 'EmptyBox' },
                                        ],
                                    },
                                ]}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Breadcrumbs Underline' }} />
                        <Box pt={1}>
                            <Breadcrumbs
                                homeItems={[
                                    {
                                        text: 'SekerUI',
                                    },
                                ]}
                                breadCrumbsItems={[
                                    { text: 'Display', link: '/display' },
                                    { text: 'Display1', link: '/display1' },
                                    { text: 'Display2', link: '/display2' },
                                    { text: 'Breadcrumbs' },
                                ]}
                                underline={{ breadcrumbs: 'always', home: 'always' }}
                                maxItems={6}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default BreadcrumbsPage;
