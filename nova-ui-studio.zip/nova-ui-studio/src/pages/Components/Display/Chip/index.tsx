import type { FC, JSX } from 'react';
import { Layout } from '../../../../App';
import { AddCard, Check, Cancel } from '@mui/icons-material';
import { Grid, GridItem, Nav, Paper, Label, Chip, Avatar } from '../../../../lib';
import { faker } from '@faker-js/faker';

const ChipPage: FC = (): JSX.Element => {
    const handleDelete = () => {
        // eslint-disable-next-line no-console
        console.log('You clicked the delete icon.');
    };

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem textAlign="center">
                    <Paper>
                        <Nav navTitleProps={{ title: 'Chip Variant' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem xs>
                                <Label text="type = 'primary'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip variant="filled" color="primary" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" color="primary" label="outlined - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="primary" label="standard - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="primary" label="standard - small" disabled />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="filled" color="primary" label="filled - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'error'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip variant="filled" color="error" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" color="error" label="outlined - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="error" label="standard - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            label="filled - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="filled" color="error" label="filled - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'info'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip variant="filled" color="info" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" color="info" label="outlined - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="info" label="standard - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="info" label="standard - small" disabled />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="filled" color="info" label="filled - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" color="info" label="outlined - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="info" label="standard - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'success'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip variant="filled" color="success" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" color="success" label="outlined - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="success" label="standard - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="success" label="standard - small" disabled />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="filled" color="success" label="filled - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="success"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'warning'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip variant="filled" color="warning" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" color="warning" label="outlined - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="warning" label="standard - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" color="warning" label="standard - small" disabled />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="filled" color="warning" label="filled - medium" size="medium" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem textAlign="center">
                    <Paper>
                        <Nav navTitleProps={{ title: 'Chip Variant With Icon' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem xs>
                                <Label text="type = 'primary'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="primary"
                                            label="filled - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="primary"
                                            label="filled - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'error'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip icon={<Check />} variant="filled" color="error" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="error"
                                            label="outlined - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="error"
                                            label="filled - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="error"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'info'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip icon={<Check />} variant="filled" color="info" label="filled - small" />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="info"
                                            label="outlined - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="info"
                                            label="filled - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="info"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'success'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="success"
                                            label="filled - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="success"
                                            label="outlined - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="success"
                                            label="standard - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="success"
                                            label="standard - small"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="success"
                                            label="filled - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="success"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'warning'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="warning"
                                            label="filled - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Check />}
                                            variant="filled"
                                            color="warning"
                                            label="filled - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<AddCard />}
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            icon={<Cancel />}
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem textAlign="center">
                    <Paper>
                        <Nav navTitleProps={{ title: 'Chip Variant with Avatar' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem xs>
                                <Label text="type = 'primary'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="primary"
                                            label="filled - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="primary"
                                            label="filled - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'error'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            label="filled - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            label="outlined - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            label="filled - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            label="outlined - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'info'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            label="filled - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            label="outlined - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            label="filled - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            label="outlined - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'success'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="success"
                                            label="filled - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="success"
                                            label="outlined - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="success"
                                            label="filled - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="success"
                                            label="outlined - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'warning'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="warning"
                                            label="filled - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="warning"
                                            label="filled - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            size="medium"
                                            avatar={<Avatar>A</Avatar>}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem textAlign="center">
                    <Paper>
                        <Nav navTitleProps={{ title: 'Chip Variant with DeleteIcon' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem xs>
                                <Label text="type = 'primary'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="primary"
                                            label="filled - small"
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="primary"
                                            label="filled - medium"
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - medium"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'error'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            label="filled - small"
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            label="filled - medium"
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            label="outlined - medium"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'info'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            label="filled - small"
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            label="filled - medium"
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            label="outlined - medium"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'success'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="success"
                                            label="filled - small"
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="success"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="success"
                                            label="filled - medium"
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="success"
                                            label="outlined - medium"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="success"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'warning'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="warning"
                                            label="filled - small"
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="warning"
                                            label="filled - medium"
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - medium"
                                            onDelete={handleDelete}
                                            deleteIcon={<Check />}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - medium"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            size="medium"
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem textAlign="center">
                    <Paper>
                        <Nav navTitleProps={{ title: 'Chip Variant With Cornered' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem xs>
                                <Label text="type = 'primary'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip variant="filled" size="small" label="filled - small" leftCornered />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="outlined" size="small" label="outlined - small" rightCornered />
                                    </GridItem>
                                    <GridItem>
                                        <Chip variant="standard" size="small" label="standard - small" cornered />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            size="small"
                                            label="standard - small"
                                            cornered
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="primary"
                                            label="filled - small"
                                            rightCornered
                                            onDelete={handleDelete}
                                            /*  sx={chipClasses.leftCornered} */
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="primary"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            leftCornered
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            cornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="primary"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'error'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            size="small"
                                            label="filled - small"
                                            leftCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            size="small"
                                            label="outlined - small"
                                            rightCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            size="small"
                                            label="standard - small"
                                            cornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            size="small"
                                            color="error"
                                            label="standard - small"
                                            cornered
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="error"
                                            label="filled - small"
                                            rightCornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="error"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            leftCornered
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            cornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="error"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'info'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            size="small"
                                            label="filled - small"
                                            leftCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            size="small"
                                            label="outlined - small"
                                            rightCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            size="small"
                                            label="standard - small"
                                            cornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            size="small"
                                            color="info"
                                            label="standard - small"
                                            cornered
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            label="filled - small"
                                            rightCornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            leftCornered
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            cornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'success'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            size="small"
                                            label="filled - small"
                                            leftCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            size="small"
                                            label="outlined - small"
                                            rightCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            size="small"
                                            label="standard - small"
                                            cornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            size="small"
                                            color="info"
                                            label="standard - small"
                                            cornered
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="info"
                                            label="filled - small"
                                            rightCornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="info"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            leftCornered
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            cornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="info"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem xs>
                                <Label text="type = 'warning'" align="center" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="warning"
                                            size="small"
                                            label="filled - small"
                                            leftCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            size="small"
                                            label="outlined - small"
                                            rightCornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            size="small"
                                            label="standard - small"
                                            cornered
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            size="small"
                                            color="warning"
                                            label="standard - small"
                                            cornered
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="filled"
                                            color="warning"
                                            label="filled - small"
                                            rightCornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="outlined"
                                            color="warning"
                                            label="outlined - small"
                                            onDelete={handleDelete}
                                            leftCornered
                                            deleteIcon={<Check />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            cornered
                                            onDelete={handleDelete}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Chip
                                            variant="standard"
                                            color="warning"
                                            label="standard - small"
                                            icon={<AddCard />}
                                            onDelete={handleDelete}
                                            disabled
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem textAlign="center">
                    <Paper>
                        <Nav navTitleProps={{ title: 'Chip Variant With Long Label' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem>
                                <Chip variant="filled" cornered label={faker.lorem.lines(20)} />
                            </GridItem>
                            <GridItem>
                                <Chip variant="outlined" cornered label={faker.lorem.lines(20)} />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ChipPage;
