import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, CustomScrollbar, Grid, GridItem, Nav, Paper } from '../../../../lib';

const CustomScrollbarPage: FC = () => {
    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'CustomScrollbar' }} />
                        <Box sx={{ p: 3 }}>
                            <Box
                                component="div"
                                sx={{
                                    position: 'relative',
                                    height: 'calc(100vh - 48px)',
                                    width: '%100',
                                    left: 0,
                                    top: 0,
                                }}>
                                <CustomScrollbar height="100%" autoHide={false}>
                                    Scroll Down <br /> <br />
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum perferendis harum
                                    voluptatum beatae, voluptatem natus a. Fugit et odio veritatis beatae impedit, nemo
                                    sint numquam magnam exercitationem necessitatibus illum, dignissimos reprehenderit
                                    nulla hic, cum culpa consectetur natus maxime cupiditate nihil. Consequuntur,
                                    facere. Nihil quos doloremque, tempora molestias ut nemo excepturi nam magni autem
                                    voluptate ab? Quae iure dignissimos pariatur eius, soluta eveniet veritatis deleniti
                                    dolore repellendus, cum reiciendis cupiditate a doloribus excepturi eaque recusandae
                                    voluptatum vero sint, dolor quod minima. Assumenda doloribus repellat ea quae soluta
                                    temporibus aliquam harum numquam itaque commodi magnam perferendis nihil asperiores
                                    vel explicabo mollitia similique aperiam, voluptatem nulla exercitationem fugiat ut
                                    eum nemo quam. Aliquid, ducimus labore. Autem voluptatum adipisci distinctio et
                                    itaque expedita error asperiores nostrum suscipit impedit. Unde iusto, explicabo
                                    dolore temporibus mollitia, sequi facere quis dicta omnis aspernatur odio porro
                                    illum velit voluptas architecto tempore distinctio eligendi minima optio aliquid?
                                    Culpa voluptatem suscipit repellendus aliquid aliquam labore nihil ex quo
                                    distinctio, voluptate sequi. Dignissimos quam nisi debitis eaque recusandae
                                    doloremque minus temporibus repellendus cum repudiandae ratione tenetur totam velit
                                    magnam mollitia, quibusdam asperiores similique molestias quae laborum reprehenderit
                                    aliquid! Aut tempore quia porro id? Et inventore facilis, vero illum repudiandae
                                    ipsum dolores asperiores autem! Iusto veniam sit facilis nulla, dolor perferendis
                                    cum quam ex, quod ipsam dolorum aut reprehenderit minus. Repellat, eius mollitia.
                                    Optio sit voluptatem assumenda maiores numquam labore dolorem sunt amet incidunt
                                    facilis, ab repellat non tempore eos velit perspiciatis expedita itaque dicta
                                    delectus quisquam nihil magnam iure! Nulla deleniti maiores, veniam vitae voluptates
                                    nemo reprehenderit omnis rem officia dolore nihil sequi molestiae alias commodi
                                    cupiditate libero porro repellendus iste fugit id quae. Saepe voluptatibus facilis
                                    mollitia molestias, animi commodi velit accusantium magnam architecto suscipit quasi
                                    error aliquid exercitationem minus sunt. Quia odit minima vel culpa sapiente vitae
                                    iusto! Molestiae nostrum eveniet illo ipsum facilis possimus in, reprehenderit
                                    ratione eius, quos facere voluptatibus incidunt tempore dolore? Tempore delectus
                                    praesentium libero deserunt nisi quod voluptatem fugit repudiandae dignissimos
                                    ipsum? Perspiciatis, eveniet! Excepturi, deleniti magni. Quibusdam deleniti
                                    perspiciatis tempore illum ab consectetur et amet placeat accusamus, saepe,
                                    voluptatum possimus, corrupti soluta blanditiis dolorem provident doloremque quam
                                    doloribus dicta molestias recusandae voluptates odio omnis! Voluptatem nulla
                                    possimus saepe laudantium est dolor quia illo amet consectetur consequatur optio
                                    perspiciatis quam voluptas aliquid, corporis a cum. Omnis, cumque quaerat cupiditate
                                    ex temporibus voluptatum aperiam a maiores quidem fugiat magnam quam iure, id porro
                                    praesentium. Cumque aliquam, tenetur, voluptatem ipsam, corrupti totam pariatur
                                    laudantium commodi culpa sint beatae eligendi cum doloremque placeat est quaerat
                                    asperiores quo facilis exercitationem natus minus animi. Laudantium, officia debitis
                                    quisquam voluptates, doloribus nisi a, necessitatibus hic voluptatibus cum odit vero
                                    quam odio aspernatur iusto asperiores quos qui numquam sit? Magni architecto maxime
                                    cum porro sapiente, quae possimus consequatur veniam fuga dignissimos nobis
                                    explicabo vero. Facere cumque sit a mollitia optio quisquam repudiandae vitae fugiat
                                    tenetur corporis minus reiciendis quas perspiciatis, doloribus consequatur facilis
                                    quia dolorum pariatur incidunt maiores accusantium quaerat nesciunt iure. Est
                                    laborum, aut facere dolor repudiandae qui! Deleniti amet impedit vel tempora nemo
                                    quae architecto debitis voluptate atque cumque repellendus neque blanditiis nesciunt
                                    consequuntur saepe culpa possimus sint, repudiandae dolores tenetur, libero unde
                                    quia a. Voluptate quo nesciunt consequatur qui deserunt fugiat? Eligendi vel facilis
                                    ratione error fugit exercitationem, voluptas, distinctio deleniti quibusdam ipsum
                                    repellat veritatis quam eaque tenetur minus non eum alias eveniet repudiandae,
                                    corporis cum atque dolore. Laborum id voluptate aliquam repellendus nostrum officiis
                                    neque suscipit modi nulla! Totam ab hic et enim porro. Laboriosam deleniti nulla
                                    fugiat quod, necessitatibus itaque modi? Aliquam suscipit non obcaecati, veritatis
                                    neque sunt incidunt nobis officiis provident deserunt animi minima magnam quis
                                    pariatur corporis! Blanditiis est atque porro provident expedita dolore rem? Quidem
                                    quas consequuntur quo quos autem accusamus ullam iste ducimus eius nisi! Dolorem
                                    dicta placeat sed ex cupiditate perspiciatis voluptas vitae molestias quasi
                                    expedita, blanditiis qui. Voluptate minima laborum optio. Necessitatibus provident
                                    praesentium aspernatur itaque facilis nulla, sint maiores fuga magnam id neque cum
                                    culpa molestias aliquam dolorum nostrum mollitia animi! Nisi esse a aut similique
                                    animi beatae assumenda iste dignissimos eaque rerum totam libero quisquam illo, quo
                                    cupiditate dolorem veritatis maiores ducimus consequatur. Optio eveniet harum facere
                                    rerum animi placeat veniam dolor laudantium soluta? Architecto laborum, temporibus
                                    vitae placeat quibusdam, nam sequi eum fuga aspernatur maiores, maxime corporis
                                    eveniet perspiciatis voluptatum cumque soluta nisi quasi et praesentium. Odit,
                                    consequatur impedit! Voluptatem iusto fugit fuga molestias a laudantium illo
                                    temporibus! Quis corrupti ut placeat impedit earum iste officiis itaque facere
                                    accusantium. Error molestias molestiae vero quas et hic, commodi, laborum pariatur
                                    earum dolor repellat id aut quis! Accusantium quibusdam odit iusto, quasi soluta
                                    libero aspernatur ut ullam odio expedita dolore reprehenderit rerum provident, magni
                                    eveniet alias exercitationem quod? A voluptatem porro amet asperiores at quis
                                    cupiditate dolores itaque totam, temporibus quaerat iste? Nihil corporis nam
                                    voluptates eveniet distinctio optio provident, eligendi architecto voluptatum
                                    quaerat officiis consectetur quod. Culpa deserunt placeat odio laboriosam ab eos
                                    dolor saepe, nisi, cumque iusto ut, deleniti iste similique repudiandae dolorem sunt
                                    perferendis? Autem excepturi iste placeat ex deserunt facilis architecto, aspernatur
                                    non, facere dolor quisquam at. Obcaecati, debitis. Voluptatibus, qui! Quia voluptas
                                    esse labore expedita. Quisquam sapiente quos, amet eaque dolor repellat quaerat
                                    veniam voluptates molestias earum beatae saepe cupiditate maiores consectetur
                                    consequuntur, architecto ullam. Officiis mollitia dolorum, pariatur beatae, illum
                                    asperiores repellendus iusto, distinctio debitis ex corporis at minima quos
                                    voluptates quidem non? Rerum tempore corrupti velit esse possimus reiciendis est,
                                    laudantium corporis illo itaque officia ipsam totam delectus cum dolor soluta
                                    doloribus error aliquam. Est natus, fugit sint molestiae quae perspiciatis incidunt
                                    laborum eius temporibus voluptates officia iusto ipsum animi fuga odit minus tenetur
                                    illum praesentium sapiente? Tempore consequatur maiores expedita earum est,
                                    praesentium optio iure, nesciunt quibusdam dolore deserunt, hic amet inventore
                                    possimus! Aspernatur harum quisquam aperiam ipsa corporis hic quod, nemo rerum
                                    necessitatibus non. Omnis assumenda delectus, perspiciatis porro, eveniet quaerat
                                    est labore, corporis eligendi aliquam incidunt laboriosam nemo quasi vitae! Fugiat
                                    sed aspernatur soluta cupiditate, itaque dolore tenetur! Ipsam, tenetur eveniet esse
                                    ratione eos adipisci dolore reiciendis odio voluptas atque. Praesentium perspiciatis
                                    delectus facere eius molestias, dolore temporibus at odio dolor facilis consequuntur
                                    debitis quod aliquid nemo, consequatur ducimus suscipit accusamus dignissimos fuga
                                    similique beatae fugiat architecto iure exercitationem? Fugit incidunt neque,
                                    voluptatem sit excepturi, labore natus sequi aliquam molestiae ducimus dolor.
                                    Repellendus nisi culpa, ipsa, voluptates itaque porro, accusantium obcaecati velit
                                    commodi corporis aliquid aperiam laborum! Esse iste numquam quam alias culpa maiores
                                    quibusdam, sapiente reiciendis tenetur ratione accusantium maxime omnis, laudantium
                                    illum eum. Eaque nulla, nihil reprehenderit itaque officia doloremque suscipit minus
                                    deleniti sed odio, in enim animi ratione neque laboriosam distinctio facere qui
                                    repellat, ullam labore aperiam ut modi voluptatum. Minus sed, eos a labore nesciunt
                                    in quisquam, nam alias ipsam et atque deleniti? Cum pariatur amet ipsum ipsa nemo
                                    quis soluta nesciunt itaque excepturi natus earum quas quae quod eveniet ad, fugiat
                                    explicabo molestiae provident ullam eum expedita deleniti. Adipisci, blanditiis.
                                    Suscipit odio facere amet eligendi porro sed at. Nisi cumque quis delectus corrupti,
                                    ullam, obcaecati quam molestias necessitatibus repudiandae ratione suscipit neque,
                                    assumenda sunt minima consectetur incidunt accusantium beatae quo! Voluptates non ad
                                    officia suscipit placeat aperiam quaerat maxime ab, temporibus modi fugiat quis sint
                                    magnam iure. Iure tenetur vel adipisci ab dolor explicabo alias ratione rerum,
                                    labore praesentium officia quae. Cum aut, quae voluptate iusto eligendi veritatis
                                    suscipit quis rerum labore explicabo praesentium, sed eaque assumenda. Velit, vel
                                    aspernatur aliquid mollitia libero harum, quis minus labore quae doloremque, optio
                                    molestias deserunt est consequatur voluptate obcaecati? Necessitatibus optio illum
                                    placeat eveniet possimus, repudiandae harum soluta, id, quo quae laborum tenetur ea
                                    in explicabo a itaque. Cum dignissimos fugiat, debitis adipisci voluptas fugit
                                    quisquam recusandae asperiores, ipsam delectus dolorum velit quidem voluptate
                                    aspernatur quia molestias animi? Necessitatibus nisi nihil, sint possimus esse dicta
                                    neque debitis quas repellendus fugit reiciendis deleniti consequatur mollitia
                                    officiis blanditiis adipisci, expedita earum nam eaque sed corrupti modi maiores
                                    velit ipsum? Minus doloribus atque culpa consectetur dolorem cum, voluptatum odit
                                    cumque pariatur, sint, dignissimos hic quas quasi praesentium deleniti labore sed
                                    recusandae quam quo nobis. At numquam, tempore aspernatur repellat iusto ad,
                                    debitis, fugit corrupti necessitatibus quae sapiente nemo vitae. Aliquam provident
                                    atque fugit ducimus consequatur adipisci eius ipsum. Nemo quod amet itaque quam
                                    architecto at blanditiis fugit aliquam, vero ipsa ducimus maiores accusamus sint
                                    obcaecati praesentium, animi dicta laborum tenetur. Perspiciatis provident dolorem
                                    id esse, beatae aperiam a quae neque, nam voluptas nostrum repellat sed labore
                                    accusamus dolorum, vero laborum asperiores natus ex. At, totam maiores voluptas
                                    error placeat fuga facere repellendus odio ut eum et. Ratione quisquam nemo
                                    inventore reprehenderit facere necessitatibus dignissimos fugiat minus voluptas
                                    beatae eum eos eius eveniet porro modi quis ut rem deserunt temporibus accusantium,
                                    obcaecati minima enim tempore expedita? Beatae iure fugiat quam tempore deleniti
                                    iste modi magni omnis voluptatum culpa deserunt expedita, fugit est nisi illo,
                                    eveniet dolorum rerum exercitationem labore ut vel at? Reprehenderit accusamus
                                    maxime harum! Facere a minus sapiente quas molestiae iure, amet labore. Animi
                                    asperiores ad voluptatum deserunt, vitae ratione laboriosam in expedita repellendus
                                    cupiditate quam sapiente culpa. Expedita repudiandae at praesentium, et, consequatur
                                    iusto vitae saepe assumenda porro enim ab quibusdam facilis nemo ratione atque
                                    aspernatur sunt. Quas cumque fugit nostrum nihil perferendis illum voluptatem
                                    cupiditate odio blanditiis, magnam mollitia adipisci doloribus tenetur temporibus
                                    modi voluptas autem eveniet quam aliquam ut eum iusto? Unde eaque tempore esse
                                    corporis eum sint consectetur, placeat quidem architecto earum velit animi expedita
                                    voluptas aspernatur eius voluptatem perferendis fugiat libero totam nihil? Hic
                                    eveniet doloribus facere quas provident dolore voluptate, natus, minima
                                    necessitatibus deserunt eligendi, impedit dolores? Est ratione maxime obcaecati at
                                    eum cum fuga dolor laudantium, voluptas libero distinctio suscipit ducimus tempora
                                    delectus dolores sequi consequuntur sint magni fugiat. Harum necessitatibus eius
                                    consequatur cum! Consectetur esse voluptatum illo placeat saepe enim cupiditate
                                    suscipit unde voluptate alias! Porro itaque amet, nostrum laudantium suscipit,
                                    cumque eum aliquid iste possimus, totam et. Sint maxime accusantium rerum doloribus
                                    porro ipsa itaque, consequatur provident quam temporibus molestias laboriosam esse
                                    error adipisci reprehenderit blanditiis reiciendis eos dolores necessitatibus
                                    veritatis, obcaecati quae quod? Nesciunt doloremque natus voluptatem officia eveniet
                                    architecto tenetur quidem quam aperiam, rerum alias repellendus, iure dolorem ad
                                    earum sit deserunt odio libero eos laborum nostrum. Aspernatur adipisci earum
                                    corporis neque qui nesciunt repellat ut iste, reprehenderit nisi libero deleniti ab.
                                    Voluptates maiores tenetur expedita? Nihil similique quisquam dolorem alias
                                    perferendis mollitia odit placeat error! Dolores, unde nisi. Neque a, ad expedita
                                    consequuntur ducimus, aut, ullam ipsam temporibus aperiam saepe possimus ipsum
                                    pariatur nulla officiis impedit doloribus quae? Hic, numquam. Dolorem fuga quidem
                                    nisi, est facere ducimus! Suscipit non soluta nobis, mollitia amet voluptas nemo,
                                    voluptates quasi harum id odit animi. Maxime, quod quidem molestiae voluptates
                                    sapiente, nemo at repellendus quo atque animi explicabo nihil qui! Odit minus rerum
                                    esse dolorum ex magni. Neque ab a aliquid odio? Officia quidem, esse adipisci
                                    voluptates atque sequi suscipit optio cumque rem cum reiciendis nemo tempora
                                    asperiores, accusantium nulla nisi! Animi, consequuntur. Soluta sed fuga dicta
                                    reiciendis vitae, porro at id placeat distinctio cumque maxime illo ea eius
                                    provident ipsa. Dolorem corrupti inventore quis commodi quasi voluptatibus dolores
                                    deleniti omnis unde minima! Suscipit, molestias aliquam error debitis, rerum quaerat
                                    maxime enim at consequuntur delectus cupiditate dolorum a consectetur aliquid? Neque
                                    quas quod ratione ipsam officia quia ullam harum fugiat tempore id possimus
                                    repellat, quo maxime nihil earum animi minus cupiditate laborum repellendus! Ipsam
                                    dolor cupiditate laudantium est, neque voluptatibus, esse laboriosam placeat quia,
                                    fugit corporis odit! Modi architecto, sed voluptatibus itaque blanditiis tenetur
                                    aliquid ab, ea praesentium odit dolores nesciunt consequuntur iste quas eius
                                    expedita quis? Animi obcaecati dolor provident praesentium doloribus dicta, hic non
                                    rerum nihil porro explicabo dolorem laborum. Inventore tenetur similique vero rerum
                                    eveniet optio, incidunt, provident perferendis aspernatur unde quo tempore obcaecati
                                    mollitia consequatur ea ullam maiores ipsa ducimus aut numquam! Ipsa praesentium
                                    accusantium beatae mollitia ad optio neque ipsam, natus suscipit hic cupiditate
                                    voluptatem maiores delectus aliquid dolorum? Laborum excepturi itaque eaque
                                    voluptates! Non natus maxime, voluptates possimus nihil impedit ut ullam labore
                                    delectus magni inventore dolores deleniti cupiditate sapiente ipsum architecto,
                                    aperiam corrupti nemo.
                                </CustomScrollbar>
                            </Box>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CustomScrollbarPage;
