import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, Label, Button, Nav } from '../../../../lib';

const LabelPage: FC = () => {
    const [align, setAlign] = useState<'center' | 'right' | 'left'>('left');

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Label' }} />
                        <Box p={1}>
                            <Label align={align} text="Lorem Ipsum" />
                        </Box>
                        <Box p={1}>
                            <Label
                                align={align}
                                text="FontSize & FontWeight"
                                // fontSize={9}
                                // fontWeight={200}
                            />
                        </Box>
                        <Box p={1}>
                            <Label
                                align={align}
                                text="Design Label"
                                // color={(theme) => theme.palette.error.main}
                                sx={
                                    {
                                        // color: (theme) => theme.palette.info.main,
                                        // [`.MuiTypography-root.${DesignTypeEnum.SET}`]: {
                                        //     color: (theme) => theme.palette.secondary.main,
                                        //     fontWeight: 400,
                                        // },
                                    }
                                }
                            />
                        </Box>
                        <Box p={1}>
                            <Label
                                align={align}
                                text="FontSize & FontWeight"
                                // fontSize={9}
                                // fontWeight={200}
                            />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Button text="left" onClick={() => setAlign('left')} />
                            <Button text="center" onClick={() => setAlign('center')} />
                            <Button text="right" onClick={() => setAlign('right')} />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default LabelPage;
