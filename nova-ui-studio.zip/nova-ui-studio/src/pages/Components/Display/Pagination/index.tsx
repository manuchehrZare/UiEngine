import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Nav, Pagination, Paper } from '../../../../lib';

const PaginationPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Pagination ' }} />
                        <Box
                            style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                width: '100%',
                                padding: '8px',
                            }}>
                            <Pagination sx={{ m: 0 }} count={10} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={12} alignItems={'center'}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Pagination -Show first and Last button' }} />
                        <Box
                            style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                width: '100%',
                                padding: '8px',
                            }}>
                            <Pagination sx={{ m: 0 }} count={10} showFirstButton showLastButton />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Pagination -Default Page' }} />
                        <Box
                            style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                width: '100%',
                                padding: '8px',
                            }}>
                            <Pagination sx={{ m: 0 }} count={10} defaultPage={3} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Pagination - Sibling Count and Boundary Count' }} />
                        <Box
                            style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                width: '100%',
                                padding: '8px',
                            }}>
                            <Pagination defaultPage={50} count={100} siblingCount={2} boundaryCount={1} />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default PaginationPage;
