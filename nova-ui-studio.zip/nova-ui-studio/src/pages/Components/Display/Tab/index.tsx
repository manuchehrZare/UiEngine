import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import { Grid, GridItem, Tab, TabItem, Button, Paper, Box, Nav } from '../../../../lib';

const TabPage: FC = () => {
    const [activeTab, setActiveTab] = useState<number>(1);
    const handleChange = (val: number) => {
        if (val !== activeTab) {
            // eslint-disable-next-line no-console
            console.log('--->', val);
            setActiveTab(val);
        }
    };

    const tabValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Button text="Open Tab Item 1" onClick={() => handleChange(1)} />
                    <Button text="Open Tab Item 2" onClick={() => handleChange(2)} />
                    <Button text="Open Tab Item 3" onClick={() => handleChange(3)} />
                </GridItem>
                <GridItem md={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tab' }} />
                        <Tab value={activeTab} onChange={(val) => handleChange(val)}>
                            {tabValues.map((item) => (
                                <TabItem key={String(item)} text={`Item ${item}`} value={item} />
                            ))}
                        </Tab>
                        <Box>
                            <Grid>
                                <GridItem>
                                    {activeTab === 1 && <Button color="error" text={String(activeTab)} />}
                                    {activeTab === 2 && <Button color="info" text={String(activeTab)} />}
                                    {activeTab === 3 && <Button color="warning" text={String(activeTab)} />}
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem md={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tab - small' }} />
                        <Tab small value={activeTab} onChange={(val) => handleChange(val)}>
                            {tabValues.map((item) => (
                                <TabItem key={String(item)} text={`Item ${item}`} value={item} />
                            ))}
                        </Tab>
                        <Box>
                            <Grid>
                                <GridItem>
                                    {activeTab === 1 && <Button color="error" text={String(activeTab)} />}
                                    {activeTab === 2 && <Button color="info" text={String(activeTab)} />}
                                    {activeTab === 3 && <Button color="warning" text={String(activeTab)} />}
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default TabPage;
