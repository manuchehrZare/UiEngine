import type { FC } from 'react';
import { Layout } from '../../../../App';
import {
    Box,
    Button,
    Grid,
    GridItem,
    Nav,
    NavContainer,
    NavItem,
    NavRow,
    NavTitle,
    Paper,
    Tab,
    TabItem,
} from '../../../../lib';

const GridPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <NavContainer>
                            <NavRow>
                                <NavItem>
                                    <NavTitle title="Button" />
                                </NavItem>
                            </NavRow>
                            <NavRow>
                                <NavItem pt={0} pb={0} width="100%">
                                    <Tab value="lorem" onChange={() => null} sx={{ borderBottom: 'none', mb: -0.25 }}>
                                        <TabItem text="Lorem" value="lorem" />
                                        <TabItem text="Ipsum" value="ipsum" />
                                        <TabItem text="Dolor" value="dolor" />
                                    </Tab>
                                </NavItem>
                            </NavRow>
                        </NavContainer>
                        <Box sx={{ p: 3 }}>
                            <Button text="Outlined" variant="outlined" />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button' }} />
                        <Box sx={{ p: 3 }}>
                            <Button text="Outlined" variant="outlined" />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default GridPage;
