import type { FC } from 'react';
import type { ICardNumberProps } from './type';
import { cardNumberFormatter, constants, useTranslation } from '../../../utils';
import NumberInput from '../../Form/NumberInput';
import NumberFormat from '../../Display/NumberFormat';
import { NumberInputReturnValueEnum } from '../../Form/NumberInput/type';
import type { FormatInputValueFunction } from 'react-number-format';
import { fill, omit } from 'lodash';

const CardNumber: FC<ICardNumberProps> = (props: ICardNumberProps) => {
    const { component, ...rest } = props;
    const { t, locale } = useTranslation();

    const formatter: FormatInputValueFunction = (value) => {
        if (props.format) {
            if (typeof props.format === 'string') {
                return props.format;
            }
            return props.format(value);
        }
        return cardNumberFormatter(value);
    };

    const generateCardNumberFormatCharSet = (length: number) =>
        cardNumberFormatter(fill(Array(length), '0').join('')).replace(/\d/g, '#');

    if (component === 'NumberInput') {
        return (
            <NumberInput
                label={props.label || t(locale.labels.cardNo)}
                returnValue={props.returnValue || NumberInputReturnValueEnum.value}
                format={props.length ? generateCardNumberFormatCharSet(props.length) : constants.format.design.cardNo}
                mask={props.mask || constants.format.char.underscore}
                name={props.name}
                control={props.control}
                {...omit(rest, ['length'])}
            />
        );
    }
    return <NumberFormat format={formatter || constants.format.design.cardNo} {...rest} />;
};
export default CardNumber;
