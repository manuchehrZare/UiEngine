import type { DatePickerProps, DatePickerSlotsComponents, DatePickerSlotsComponentsProps } from '@mui/x-date-pickers';
import type { TextFieldProps } from '@mui/material';
import type { ICommonFieldProps } from '../commonTypes';

export interface IDatePickerProps
    extends Pick<
            DatePickerProps<any>,
            | 'autoFocus'
            | 'className'
            | 'disableHighlightToday'
            | 'disableOpenPicker'
            | 'disablePast'
            | 'disabled'
            | 'displayWeekNumber'
            | 'format'
            | 'formatDensity'
            | 'label'
            | 'loading'
            | 'localeText'
            | 'maxDate'
            | 'minDate'
            | 'onClose'
            | 'onMonthChange'
            | 'onOpen'
            | 'onViewChange'
            | 'onYearChange'
            | 'shouldDisableDate'
            | 'shouldDisableYear'
            | 'views'
        >,
        Omit<ICommonFieldProps, 'startAdornment' | 'endAdornment'>,
        Pick<TextFieldProps, 'placeholder' | 'sx' | 'onKeyPress' | 'onFocus' | 'onBlur'> {
    clearable?: boolean | undefined;
    clearText?: any;
    disableCloseOnSelect?: boolean;
    disableWeekends?: boolean;
    required?: boolean;
    /*
    The props used for each component slot.
    */
    slotProps?: Omit<
        DatePickerSlotsComponentsProps<any>,
        'textField' | 'desktopPaper' | 'openPickerButton' | 'actionBar' | 'inputAdornment'
    >;
    /*
    Overridable component slots.
    */
    slots?: Omit<DatePickerSlotsComponents<any>, 'textField' | 'field' | 'TextField' | 'Field'>;
    unixTime?: boolean;
}

export enum DateTypeEnum {
    day = 'day',
    month = 'month',
    year = 'year',
}
export type DateType = keyof typeof DateTypeEnum;
