import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { useController } from 'react-hook-form';
import type { DateType, IDatePickerProps } from '../type';
import { DateTypeEnum } from '../type';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker as MuiDatePicker } from '@mui/x-date-pickers/DatePicker';
import { fromUnixTime, getUnixTime, isAfter, isDate, isValid, isWeekend } from 'date-fns';
import { EventOutlined } from '@mui/icons-material';
import { isNumber, isUndefined, omit } from 'lodash';
import { pickerProps } from '../../_helper';
import { Box, DesignTypeEnum, constants, i18n, manageClassNames, useMeasure } from '../../../..';
import { LocalesEnum } from '../../../../utils/locales';
import { FormControl, FormHelperText } from '@mui/material';
import { enUS, trTR } from '@mui/x-date-pickers';
import trLocale from 'date-fns/locale/tr';
import enLocale from 'date-fns/locale/en-US';

const DatePicker: FC<IDatePickerProps> = ({
    control,
    deps,
    disableWeekends,
    format,
    helperText,
    label,
    labelPlacement,
    labelWidth,
    labelEllipsis,
    name,
    onBlur,
    onClose,
    onFocus,
    onOpen,
    placeholder,
    required,
    shouldDisableDate,
    size,
    slotProps,
    slots,
    unixTime,
    views,
    sx,
    variant,
    ...rest
}: IDatePickerProps) => {
    const labelMeasure = useMeasure();
    const separator = pickerProps.SET.datePicker.dateSeparator;
    const [viewsFormat, setViewsFormat] = useState<string>(pickerProps.SET.datePicker.inputFormat);
    const [open, setOpen] = useState<boolean>(false);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const localeTextObj: any = {
        [LocalesEnum.TURKISH]: trTR.components.MuiLocalizationProvider.defaultProps.localeText,
        [LocalesEnum.ENGLISH]: enUS.components.MuiLocalizationProvider.defaultProps.localeText,
    };

    const getInputDate = (value: any) => {
        if (unixTime) {
            return value ? fromUnixTime(value) : value;
        }
        return value;
    };

    useEffect(() => {
        if (views?.length) {
            const formatArr: any[] = views?.map((item: DateType) => {
                if (item === DateTypeEnum.day) {
                    return 'dd';
                }
                if (item === DateTypeEnum.month) {
                    return 'MM';
                }
                if (item === DateTypeEnum.year) {
                    return 'yyyy';
                }
                return null;
            });
            setViewsFormat(formatArr.join(`${separator}`));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [views]);

    const placeholderFormat = (data: string) => {
        switch (!isUndefined(data)) {
            case data === 'dd' ||
                data === 'MM' ||
                data === 'yyyy' ||
                data === `dd${separator}MM` ||
                data === `dd${separator}yyyy` ||
                data === `MM${separator}dd` ||
                data === `MM${separator}yyyy` ||
                data === `yyyy${separator}dd` ||
                data === `yyyy${separator}MM` ||
                data === `dd${separator}MM${separator}yyyy` ||
                data === `dd${separator}yyyy${separator}MM` ||
                data === `MM${separator}dd${separator}yyyy` ||
                data === `MM${separator}yyyy${separator}dd` ||
                data === `yyyy${separator}dd${separator}MM` ||
                data === `yyyy${separator}MM${separator}dd`:
                return data;
            default:
                return '';
        }
    };

    const setOpenTo = () => {
        if (views) {
            if (views[0] === DateTypeEnum.year) return DateTypeEnum.year;
            if (views[0] === DateTypeEnum.month) return DateTypeEnum.month;
            return DateTypeEnum.day;
        }
        return DateTypeEnum.day;
    };

    /* istanbul ignore next */
    const toggleOpen = (val?: boolean) => {
        if (val !== undefined) {
            val && !open && onOpen?.();
            !val && open && onClose?.();
            setOpen(val);
        } else {
            !open && onOpen?.();
            open && onClose?.();
            setOpen(!open);
        }
    };

    const unSelectableWeekends = (date: any) => {
        return isWeekend(date);
    };

    const minDateControl = (date: any) => {
        return isAfter(isNumber(date) ? fromUnixTime(date) : date, new Date(1900, 1, 1));
    };

    const errorVal = Boolean(error) || (error && field?.value?.length > 0);
    const helperTextVal = validationControl
        ? // eslint-disable-next-line no-constant-binary-expression
          ((error || !minDateControl(field.value)) && field?.value?.length > 0 && '') ||
          error?.message ||
          helperText ||
          ''
        : helperText || '';

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    return (
        <LocalizationProvider
            dateAdapter={AdapterDateFns}
            adapterLocale={i18n.language === LocalesEnum.TURKISH ? trLocale : enLocale}>
            <FormControl
                variant={variant}
                className={manageClassNames(DesignTypeEnum.SET, labelPlacement, {
                    [constants.classNames.labelEllipsis]: labelEllipsis,
                })}
                error={errorVal && validationControl}
                sx={{ flexDirection: 'column', ...sx }}>
                <MuiDatePicker
                    {...field}
                    value={getInputDate(field?.value)}
                    className={manageClassNames(DesignTypeEnum.SET, labelPlacement, {
                        [constants.classNames.labelEllipsis]: labelEllipsis,
                    })}
                    inputRef={ref}
                    label={getLabel()}
                    autoFocus={false}
                    open={open}
                    onOpen={/* istanbul ignore next */ () => toggleOpen()}
                    onClose={/* istanbul ignore next */ () => toggleOpen(false)}
                    onChange={(date: any, context) => {
                        let d = null;
                        if (isDate(date) && isValid(date) && minDateControl(date)) {
                            d = unixTime ? Number(getUnixTime(new Date(date))) : date;
                        }
                        const inputEmpty = !d && !context.validationError && !open;
                        const pickerChange = open && !context.validationError && d;
                        if (context || pickerChange || inputEmpty) {
                            let resultD = d;
                            if (d === null) {
                                resultD = inputEmpty ? null : NaN;
                            }
                            field.onChange(resultD);
                        }
                    }}
                    views={views}
                    format={views ? viewsFormat : format || `dd${separator}MM${separator}yyyy`}
                    shouldDisableDate={(disableWeekends && unSelectableWeekends) || shouldDisableDate}
                    localeText={{
                        ...localeTextObj[i18n.language],
                    }}
                    openTo={setOpenTo()}
                    slots={{
                        openPickerIcon: () => <EventOutlined fontSize={size} />,
                        ...slots,
                    }}
                    slotProps={{
                        inputAdornment: {
                            position: 'end',
                        },
                        openPickerButton: {
                            onClick: () => toggleOpen(),
                        },
                        desktopPaper: {
                            className: `custom-picker ${DesignTypeEnum.SET}`,
                        },
                        textField: {
                            variant: variant,
                            size: size,
                            error: errorVal && validationControl,
                            onFocus: onFocus,
                            onBlur: (e) => {
                                field.onBlur();
                                onBlur?.(e);
                            },
                            inputProps: {
                                placeholder: placeholder
                                    ? placeholder
                                    : placeholderFormat(
                                          views ? viewsFormat : format || pickerProps.SET.datePicker.inputFormat,
                                      ).replace(/[a-zA-Z]/gm, '_'),
                            },
                            InputLabelProps: {
                                shrink: true,
                                ref: labelMeasure.ref as any,
                                className: manageClassNames(DesignTypeEnum.SET, labelPlacement, {
                                    [constants.classNames.labelEllipsis]: labelEllipsis,
                                }),
                                title: typeof getLabel() === 'string' ? `${getLabel()}` : '',
                                sx: {
                                    width: labelWidth,
                                    maxWidth: '100%',
                                },
                            },
                            sx: {
                                flexDirection: labelPlacement === 'start' ? 'initial' : 'column',
                            },
                            fullWidth: true,
                            className: manageClassNames('picker-input', DesignTypeEnum.SET),
                            id: name,
                            autoComplete: 'off',
                            spellCheck: false,
                        },
                        actionBar: {
                            actions: [],
                        },
                        ...slotProps,
                    }}
                    {...omit(rest, ['fullWidth', 'onKeyPress'])}
                />
                {helperTextVal && (
                    <Box component="div">
                        <FormHelperText
                            className={DesignTypeEnum.SET}
                            sx={{
                                ...(labelPlacement === 'start' && { marginLeft: `${labelMeasure.values.width}px` }),
                            }}>
                            {helperTextVal}
                        </FormHelperText>
                    </Box>
                )}
            </FormControl>
        </LocalizationProvider>
    );
};

export default DatePicker;
