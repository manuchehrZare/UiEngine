import type { FC } from 'react';
import { memo, useEffect, useRef } from 'react';
import { useController } from 'react-hook-form';
import type { Theme } from '@mui/material';
import { FormControl, FormHelperText, Typography } from '@mui/material';
import type { DesignType } from '../../..';
import {
    Box,
    DesignTypeEnum,
    constants,
    i18n,
    manageClassNames,
    useIsFirstRender,
    useMeasure,
    useStorage,
} from '../../..';
import 'froala-editor/css/froala_style.min.css';
import 'froala-editor/css/froala_editor.pkgd.min.css';
import 'froala-editor/js/froala_editor.pkgd.min.js';
import 'froala-editor/js/plugins.pkgd.min.js';
import Froala from 'react-froala-wysiwyg';
import type { IRichEditorProps } from './type';
import MuiRichEditorSxProps from './style';
import { color, toolbarFontFamilyList, toolbarFontSize, toolbarParagraph } from './helpers/Font';
import { calculateEditorContentHeight } from './helpers/action';
import { isNaN, isNumber } from 'lodash';
import ThemeProvider from '../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';
import { v4 as uuidv4 } from 'uuid';

const licenseKey = 'PYC4mA3B15C10C8C7F4D4eMRPYa1c1REe1BGQOQIc1CDBREJImD6F5F4E4E1B9D6C3C4F6==';

const id = uuidv4();

/* istanbul ignore next*/
const RichEditor: FC<IRichEditorProps> = ({
    charCounterCount = false,
    wordCounterCount = false,
    control,
    design,
    disabled,
    fontFamilyList,
    fontSizeList,
    height,
    helperText,
    label,
    labelEllipsis = true,
    name,
    placeholder,
    readOnly,
    required,
    sx,
    toolbar,
    deps,
    variant = 'outlined',
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const {
        // eslint-disable-next-line
        field: { ref, onChange, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });
    const froalaRef = useRef(null);
    const labelRef = useRef(null);
    const boxMeasure = useMeasure();
    const isFirstRender = useIsFirstRender();
    const editorId = `${name}-${id}`;
    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const setDocumentHeightCalculation = () => {
        const content: any = (froalaRef?.current as any)?.editor?.$wp;
        const codeView: any = (froalaRef?.current as any)?.editor?.$oel;
        const charCounterCountView: any = (froalaRef?.current as any)?.editor?.$second_tb;
        const wordCounterCountView: any = (froalaRef?.current as any)?.editor?.$second_tb;
        if (content?.length & charCounterCountView?.length) {
            codeView && charCounterCountView[0]?.setAttribute('style', 'display:block;');
        }
        if (content?.length & wordCounterCountView?.length) {
            codeView && wordCounterCountView[0]?.setAttribute('style', 'display:block;');
        }
        if (
            content?.length &&
            ((isNumber(height) && !isNaN(height)) ||
                (!isNumber(height) && !['undefined', 'NaN', 'null'].some((el) => height.includes(el))))
        ) {
            content[0]?.setAttribute(
                'style',
                `display: block; height: ${calculateEditorContentHeight({
                    height,
                    froalaRef,
                    charCounterCount,
                    wordCounterCount,
                    design: getComponentDesignProperty(design, storageDesign.newValue),
                    labelRef,
                })}`,
            );
        }
    };

    const timeoutHeightCalculation = () => {
        const timeOut = setTimeout(() => {
            setDocumentHeightCalculation();
        }, 500);

        return () => {
            clearTimeout(timeOut);
        };
    };

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        if ((froalaRef?.current as any)?.editor?.$tb) {
            setDocumentHeightCalculation();
        } else {
            timeoutHeightCalculation();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [boxMeasure?.values?.height, boxMeasure?.values?.width]);

    useEffect(() => {
        !isFirstRender && onChange(field.value === '<p></p>' ? '' : field.value);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [field.value]);

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <FormControl
                sx={{ ...sx, display: 'block', width: '100%' }}
                variant={variant}
                className={manageClassNames(generateClass('RichEditor-formControl'), {
                    [constants.classNames.labelEllipsis]: labelEllipsis,
                })}
                error={Boolean(error?.message) && validationControl}>
                <Box
                    id={editorId}
                    {...(variant === 'outlined' && {
                        component: 'fieldset',
                    })}
                    height={height}
                    ref={boxMeasure.ref}
                    className={manageClassNames(generateClass(`RichEditor-box`), variant, {
                        error: Boolean(error?.message),
                        [constants.classNames.labelEllipsis]: labelEllipsis,
                    })}
                    sx={{
                        ...(MuiRichEditorSxProps({
                            design: getComponentDesignProperty(design, storageDesign.newValue),
                            height,
                            froalaRef,
                            labelRef,
                            readOnly,
                            disabled,
                            toolbar,
                            variant,
                        }) as any),
                        ...sx,
                    }}>
                    {label && (
                        <Typography ref={labelRef as any} component="legend" title={getLabel()}>
                            {getLabel()}
                        </Typography>
                    )}
                    <Froala
                        {...field}
                        ref={froalaRef as any}
                        model={field.value}
                        onModelChange={onChange}
                        tag="textarea"
                        config={{
                            key: licenseKey,
                            language: i18n.language,
                            placeholderText: placeholder,
                            quickInsertEnabled: false,
                            events: {
                                'buttons.refresh': () => {
                                    setDocumentHeightCalculation();
                                },
                                focus: () => {
                                    document.getElementById(editorId)?.classList.add('focus');
                                },
                                blur: () => {
                                    document.getElementById(editorId)?.classList.remove('focus');
                                    field.onBlur();
                                },
                                initialized: function () {
                                    (readOnly || disabled) && (this as any)?.edit?.off();
                                },
                            },
                            toolbarButtons: {
                                inlineMode: false,
                                toolbarSticky: false,
                                spellcheck: true,
                                moreText: {
                                    buttons: toolbar
                                        ? toolbar
                                        : toolbar === false
                                          ? []
                                          : [
                                                'undo',
                                                'redo',
                                                'fontFamily',
                                                'fontSize',
                                                'paragraphFormat',
                                                'bold',
                                                'italic',
                                                'underline',
                                                'strikeThrough',
                                                'subscript',
                                                'superscript',
                                                'specialCharacters',
                                                'clearFormatting',
                                                'textColor',
                                                'backgroundColor',
                                                'lineHeight',
                                                'quote',
                                            ],
                                    buttonsVisible: toolbar ? toolbar.length : 99,
                                },
                                moreRich: !toolbar && {
                                    buttons:
                                        toolbar === false
                                            ? []
                                            : [
                                                  'formatOL',
                                                  'formatUL',
                                                  'alignLeft',
                                                  'alignCenter',
                                                  'alignRight',
                                                  'alignJustify',
                                                  'html',
                                                  'insertLink',
                                                  'insertTable',
                                                  'insertHR',
                                                  'print',
                                              ],
                                    buttonsVisible: 13,
                                },
                            },
                            charCounterCount: charCounterCount,
                            wordCounterCount: wordCounterCount,
                            codeViewKeepActiveButtons: ['selectAll'],
                            fontFamily: fontFamilyList || toolbarFontFamilyList,
                            fontSize: fontSizeList || toolbarFontSize,
                            paragraphFormat: toolbarParagraph,
                            tableEditButtons: [
                                'tableHeader',
                                'tableRows',
                                'tableColumns',
                                'tableCells',
                                'tableCellHorizontalAlign',
                                'tableCellBackground',
                                'tableRemove',
                            ],
                            imageDefaultDisplay: 'inline',
                            imageEditButtons: ['imageAlign', 'imageDisplay', 'imageRemove'],
                            imageInsertButtons: ['imageUpload'],
                            linkEditButtons: ['linkRemove'],
                            linkInsertButtons: ['linkBack'],
                            wordDeniedAttrs: ['width'],
                            wordPasteModal: false,
                            fontSizeSelection: true,
                            fontFamilySelection: true,
                            paragraphFormatSelection: true,
                            colorsText: color,
                            colorsBackground: color,
                            tableColors: color,
                        }}
                    />
                </Box>
                {((validationControl && error?.message) || helperText) && (
                    <FormHelperText
                        sx={{
                            fontSize:
                                getComponentDesignProperty(design, storageDesign.newValue) === DesignTypeEnum.Default
                                    ? 'calc(var(--field-label-font-size))'
                                    : `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 1px)`,
                        }}>
                        {error?.message || helperText}
                    </FormHelperText>
                )}
            </FormControl>
        </ThemeProvider>
    );
};

export default memo(RichEditor);
