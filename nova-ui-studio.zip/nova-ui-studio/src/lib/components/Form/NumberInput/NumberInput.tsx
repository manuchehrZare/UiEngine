import { isNaN, isNull, isNumber, isString } from 'lodash';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { Control } from 'react-hook-form';
import NumberFormat from 'react-number-format';
import type { NumberInputReturnValueType } from './type';

const NumberInputBaseComponent: FC = forwardRef(
    ({ name, onChange, value, returnValue, control, ...rest }: any, ref) => {
        const isAllZeros = (inputValue: string) => {
            return /^0+$/.test(inputValue?.replace(/[.,]/g, ''));
        };
        return (
            <NumberFormat
                {...rest}
                value={isNumber(value) || isString(value) ? value : ''}
                defaultValue={(control as Control)._defaultValues[name]}
                getInputRef={ref}
                name={name}
                onValueChange={
                    /* istanbul ignore next */ (values, info) => {
                        const defaultValue = (control as Control)._defaultValues[name];

                        const defaultReturnValue = isNaN(defaultValue)
                            ? NaN
                            : isNumber(defaultValue) || isNull(defaultValue)
                              ? null
                              : '';

                        let resultValue = isNumber(values.floatValue)
                            ? returnValue
                                ? values[returnValue as NumberInputReturnValueType]
                                : values.floatValue
                            : defaultReturnValue;

                        if (
                            rest?.fixedDecimalScale &&
                            rest?.decimalScale &&
                            isAllZeros(values?.value) &&
                            (!info?.event || info?.event?.type === 'blur')
                        ) {
                            resultValue = null;
                        }

                        onChange({
                            target: {
                                name,
                                value: resultValue,
                            },
                        });
                    }
                }
            />
        );
    },
);

export default NumberInputBaseComponent;
