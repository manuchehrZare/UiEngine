import type { SxProps, Theme } from '@mui/material';
import { GlobalFont } from '../../../theme/_css_global';
import type { DesignType } from '../../../utils/types/common';
import { DesignTypeEnum } from '../../../utils/types/common';
import { constants, importantStyle } from '../../../utils';
import type { IUploadProps } from './type';

interface IParams extends Pick<IUploadProps, 'variant'> {
    design: DesignType;
}

const MuiUploadSxProps = ({ design, variant }: IParams): SxProps<Theme> => ({
    position: 'relative',
    margin: 0,
    padding: 0,
    width: '100%',

    ...(design === DesignTypeEnum.Default && {
        ...(variant === 'outlined' && {
            border: (theme) => `1px solid ${theme.palette.grey?.[400]}`,
            borderRadius: 'var(--border-radius-5)',
            background: (theme) => theme.palette.common.white,
        }),
        ...(variant !== 'outlined' && {
            borderBottom: (theme) => `1px solid ${theme.palette.grey?.[700]}`,
        }),
        ...(variant === 'filled' && {
            borderTopLeftRadius: 'var(--border-radius-4)',
            borderTopRightRadius: 'var(--border-radius-4)',
            background: (theme) => theme.palette.grey[100],
        }),
    }),
    ...(design === DesignTypeEnum.SET && {
        border: (theme) => `1px solid ${theme.palette.grey[400]}`,
        borderRadius: `var(--field-border-radius-${DesignTypeEnum.SET})`,
    }),

    [`&.${constants.classNames.labelEllipsis}`]: {
        minInlineSize: 'initial',
    },

    ':hover': {
        borderColor: (theme) => theme.palette.grey[700],

        '& .filepond--wrapper': {
            label: {
                color: (theme) => `${theme.palette.grey[700]} !important`,
            },
        },
    },

    '& > legend': (theme) => ({
        margin: '0 10px',
        padding: '0 5px',
        ...(design === DesignTypeEnum.Default && {
            fontSize: 'calc(var(--field-label-font-size) * 0.875)',
            ...(variant === 'standard' && {
                margin: '0px',
                padding: '0px',
            }),
        }),
        ...(design === DesignTypeEnum.SET && {
            fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            color: theme.palette.common.black,
        }),

        [`.${constants.classNames.labelEllipsis} &`]: {
            maxWidth: 'calc(100% - 23px)',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
        },
    }),
    '& .filepond--wrapper': {
        '& .filepond--root': {
            fontFamily: GlobalFont,
            margin: 0,
            '& .filepond--panel-root': {
                backgroundColor: 'transparent !important',
            },
        },
        label: {
            fontFamily: GlobalFont,
            color: (theme) => `${theme.palette.grey[600]} !important`,
            display: 'flex',
            alignItems: 'center',
            fontSize:
                design === DesignTypeEnum.Default
                    ? 'var(--field-label-font-size)'
                    : `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            span: {
                fontFamily: GlobalFont,
                border: (theme) => `1px solid ${theme.palette.grey[500]}`,
                marginTop: '1px',
                borderRadius: '5px',
                fontSize:
                    design === DesignTypeEnum.Default
                        ? 'var(--field-label-font-size)'
                        : `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                color: (theme) => theme.palette.grey[600],
                outline: 'none',
                marginLeft: '15px',
                padding: '5px 15px',
                '&:hover': {
                    backgroundColor: (theme) => theme.palette.grey[50],
                    borderColor: (theme) => theme.palette.grey[700],
                    color: (theme) => theme.palette.grey[700],
                },
            },
        },
    },
    '&.error': {
        '& > legend': {
            color: (theme) => importantStyle(theme.palette.error.main),
        },
        borderColor: (theme) => theme.palette.error.main,
    },
    '& .filepond--credits': {
        display: 'none',
    },
});
export default MuiUploadSxProps;
