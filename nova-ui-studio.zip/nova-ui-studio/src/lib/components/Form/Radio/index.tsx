import Default from './DefaultRadio';
import SET from './SETRadio';
import type { FC } from 'react';
import { memo } from 'react';
import type { IRadioProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const Radio: FC<IRadioProps> = ({
    design,
    color = 'secondary',
    disabled = false,
    required = false,
    ...rest
}: IRadioProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: <Default color={color} disabled={disabled} required={required} {...rest} />,
        [DesignTypeEnum.SET]: <SET color={color} disabled={disabled} required={required} {...rest} />,
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default memo(Radio);
