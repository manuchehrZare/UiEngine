import type { FC } from 'react';
import { FormControl, FormHelperText, FormControlLabel, Radio as MuiRadio } from '@mui/material';
import type { IRadioProps } from '../type';
import { DesignTypeEnum } from '../../../../utils/types/common';
import { generateClass, manageClassNames } from '../../../../utils';

const Radio: FC<IRadioProps> = ({
    helperText,
    disabled,
    checkedIcon,
    onChange,
    icon,
    label,
    color,
    value,
    size,
    required,
    className,
    sx,
    ...rest
}: IRadioProps) => {
    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };
    return (
        <FormControl className={generateClass('Radio-formControl')} disabled={disabled} size={size} sx={sx}>
            <FormControlLabel
                disabled={disabled}
                value={value}
                label={getLabel()}
                className={manageClassNames(generateClass('Radio-label'), `${DesignTypeEnum.Default}`, className)}
                control={
                    <MuiRadio
                        className={DesignTypeEnum.Default}
                        color={color}
                        disabled={disabled}
                        inputProps={{ 'aria-label': label, role: 'radio' }}
                        size={size}
                        icon={icon}
                        checkedIcon={checkedIcon}
                        onChange={(event, checked) => {
                            onChange?.(event, checked);
                        }}
                        {...rest}
                    />
                }
            />
            {helperText && (
                <FormHelperText
                    className={manageClassNames(
                        generateClass('HelperText'),
                        'radio',
                        DesignTypeEnum.Default,
                        `${size}`,
                    )}>
                    {helperText}
                </FormHelperText>
            )}
        </FormControl>
    );
};

export default Radio;
