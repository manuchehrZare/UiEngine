import { TableCell as MuiTableCell } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { ITableCellProps } from './type';

const TableCell: FC<ITableCellProps> = forwardRef(({ children, ...rest }: ITableCellProps, ref) => {
    return (
        <MuiTableCell ref={ref} {...rest}>
            {children}
        </MuiTableCell>
    );
});

export default TableCell;
