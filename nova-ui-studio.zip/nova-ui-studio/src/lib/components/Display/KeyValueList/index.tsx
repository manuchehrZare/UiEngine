import type { FC } from 'react';
import { memo } from 'react';
import type { IKeyValueListProps } from './type';
import type { Theme } from '@mui/material';
import { List, ListItem, ListItemText } from '@mui/material';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const KeyValueList: FC<IKeyValueListProps> = ({ data, wrap = false, design, className, ...rest }) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });

    const renderList = () => {
        if (data?.length) {
            return data.map((item, i: number) => {
                return (
                    <ListItem
                        className={manageClassNames(generateClass('KeyValueList-item'))}
                        key={`kv_list_${String(i)}`}>
                        <ListItemText
                            className={manageClassNames(generateClass('KeyValueList-item-text'), {
                                wrap: wrap || item.wrap,
                            })}
                            primary={item.text}
                            secondary={item.value}
                            primaryTypographyProps={{
                                component: 'div',
                                className: manageClassNames(generateClass('KeyValueList-item-text-primary')),
                            }}
                            secondaryTypographyProps={{
                                component: 'div',
                                className: manageClassNames(generateClass('KeyValueList-item-text-secondary')),
                            }}
                        />
                    </ListItem>
                );
            });
        }

        return null;
    };

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <List className={manageClassNames(generateClass('KeyValueList'), className)} {...rest}>
                {renderList()}
            </List>
        </ThemeProvider>
    );
};

export default memo(KeyValueList);
