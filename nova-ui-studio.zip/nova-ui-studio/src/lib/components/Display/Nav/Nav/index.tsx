import type { FC, JSX } from 'react';
import { forwardRef, memo } from 'react';
import type { INavProps } from '../type';
import type { DesignType } from '../../../..';
import { NavContainer, NavItem, NavRow, NavTitle, View, constants, useStorage } from '../../../..';
import { generateClass, getComponentDesignProperty, manageClassNames } from '../../../../utils';

const Nav: FC<INavProps> = forwardRef(
    ({ design, navContainerProps, navItemProps, navRowProps, navTitleProps }: INavProps, ref): JSX.Element => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        return (
            <NavContainer
                ref={ref}
                className={manageClassNames(
                    generateClass('Nav'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                )}
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                {...navContainerProps}>
                {navContainerProps?.children}
                <View show={!!navContainerProps?.children === false}>
                    <NavRow design={getComponentDesignProperty(design, storageDesign.newValue)} {...navRowProps}>
                        {navRowProps?.children}
                        <View show={!!navRowProps?.children === false}>
                            <NavItem
                                design={getComponentDesignProperty(design, storageDesign.newValue)}
                                {...navItemProps}>
                                {navItemProps?.children}
                                <View show={!!navItemProps?.children === false}>
                                    <NavTitle
                                        design={getComponentDesignProperty(design, storageDesign.newValue)}
                                        title=""
                                        {...navTitleProps}
                                    />
                                </View>
                            </NavItem>
                        </View>
                    </NavRow>
                </View>
            </NavContainer>
        );
    },
);

export default memo(Nav);
