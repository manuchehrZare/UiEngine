import type { AlertProps, AlertSlotsAndSlotProps, AlertTitleProps } from '@mui/material';
import type { ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';

export interface IAlertProps
    extends ICommonProps,
        Pick<
            AlertProps,
            'action' | 'className' | 'closeText' | 'componentsProps' | 'hidden' | 'icon' | 'id' | 'sx' | 'variant'
        >,
        Pick<AlertSlotsAndSlotProps, 'slotProps'> {
    onClose?: () => void;
    text: ReactNode;
    title?: ReactNode;
    titleProps?: Pick<AlertTitleProps, 'className' | 'hidden' | 'id' | 'sx'>;
    type?: AlertProps['severity'];
    variant?: 'standard' | 'outlined' | 'filled';
}
