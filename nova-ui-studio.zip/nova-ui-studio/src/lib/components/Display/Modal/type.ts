import type { DialogProps, DialogTitleProps, DialogContentProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
import type { IButtonProps } from '../../Form/Button/type';

export enum ModalCloseReasonEnum {
    BackdropClick = 'backdropClick',
    EscapeKeyDown = 'escapeKeyDown',
    CloseIconClick = 'closeIconClick',
}

export type ModalCloseReasonType = `${ModalCloseReasonEnum}`;

export interface IModalProps
    extends ICommonProps,
        Pick<
            DialogProps,
            'className' | 'disableEscapeKeyDown' | 'fullScreen' | 'fullWidth' | 'maxWidth' | 'ref' | 'scroll' | 'sx'
        >,
        Required<Pick<DialogProps, 'children'>>,
        Pick<IButtonProps, 'loading'> {
    allowClose?: boolean;
    closeIcon?: boolean;
    disableBackdropClick?: boolean;
    draggable?: boolean;
    fullHeight?: boolean;
    keepMounted?: any;
    onBackdropClick?: () => void;
    onClose?: () => void;
    show: boolean;
}

export interface IModalTitleProps extends Pick<DialogTitleProps, 'ref' | 'sx' | 'className' | 'children'> {}
export interface IModalBodyProps extends DialogContentProps {}

export interface IModalFooterProps extends DialogContentProps {}
