import type { FC } from 'react';
import { Container as MuiContainer } from '@mui/material';
import type { IContainerProps } from './type';
import { generateClass, manageClassNames } from '../../../utils';

const Container: FC<IContainerProps> = ({ children, className, ...rest }) => {
    return (
        <MuiContainer className={manageClassNames(generateClass('Container'), className)} {...rest}>
            {children}
        </MuiContainer>
    );
};

export default Container;
