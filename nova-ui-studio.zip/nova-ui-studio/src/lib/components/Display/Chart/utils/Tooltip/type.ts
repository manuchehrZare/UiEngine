export interface ITooltip {
    backgroundColor?: string;
    border?: string;
    boxShadow?: string;
    fontSize?: number;
    labelColor?: string;
    radius?: number;
    seperator?: string;
    valueColor?: string;
}
