import type { FC } from 'react';
import { useEffect, useState } from 'react';
import {
    LineChart as ReLineChart,
    Line,
    XAxis,
    YAxis,
    ResponsiveContainer,
    CartesianGrid,
    LabelList,
    ReferenceLine,
} from 'recharts';
import CustomLegend from '../utils/Legend';
import type { ILineChartProps } from './type';
import { initialLineMargin } from './type';
import { v4 as uuidv4 } from 'uuid';
import { getDataModelForBarChart } from '../action';
import CustomTooltip from '../utils/Tooltip';
import { generateClass, manageClassNames, randomColor } from '../../../../utils';

const LineChart: FC<ILineChartProps> = ({
    data,
    className,
    colors,
    tick,
    range,
    grid,
    lineStrokeDash,
    referenceLine,
    height = '55%',
    axis = {
        xLine: true,
        yLine: true,
        lineColor: '#000',
    },
    layout = 'horizontal',
    legend = false,
    margin = initialLineMargin,
    tooltip = false,
    lineLabels = [],
}) => {
    const [newData, setNewData] = useState<any[]>(getDataModelForBarChart(data));
    // const lineData = Object.keys(data[0])?.filter((item, index) => index !== 0);
    const [activeTooltipData, setactiveTooltipData] = useState<any>(null);
    const axisData = {
        xData: {
            value: axis?.label?.xLabel,
            stroke: axis?.label?.color,
            fontSize: axis?.label?.fontSize,
            position: 'bottom',
        },
        yData: {
            value: axis?.label?.yLabel,
            stroke: axis?.label?.color,
            fontSize: axis?.label?.fontSize,
            angle: -90,
            position: 'left',
        },
    };
    const tickViewValues = {
        tick: {
            fontSize: tick?.fontSize || 11,
            fill: tick?.color || '#000',
            fontWeight: tick?.fontWeight || 'normal',
        },
        tickLine: tick?.line || false,
    };
    const CustomizedLabel: FC<any> = (props: any) => {
        const { x, y, stroke, value } = props;

        return (
            <text x={x} y={y} dy={-4} fill={stroke} fontSize={10} textAnchor="middle">
                {value}
            </text>
        );
    };

    const xAxisProps: any = {
        orientation: layout === 'vertical' ? axis?.yOrientation : axis?.xOrientation,
        dataKey: Object.keys(data[0])[0],
        stroke: axis?.lineColor,
        axisLine: layout === 'vertical' ? axis?.yLine : axis?.xLine,
        unit: axis?.xUnit,
        tick: {
            ...tickViewValues.tick,
            ...(layout === 'vertical'
                ? typeof tick?.yView !== 'undefined' &&
                  typeof tick?.yView === 'boolean' &&
                  !tick?.yView && { fill: 'transparent' }
                : typeof tick?.xView !== 'undefined' &&
                  typeof tick?.xView === 'boolean' &&
                  !tick?.xView && { fill: 'transparent' }),
            width: layout === 'vertical' ? tick?.width?.y : tick?.width?.x,
        },
        tickLine: tickViewValues.tickLine,
        type: 'category',
        angle: layout === 'vertical' ? tick?.angle?.y : tick?.angle?.x,
        tickMargin: layout === 'vertical' ? tick?.margin?.y : tick?.margin?.x,
        label: {
            ...(layout === 'vertical' ? axisData.yData : axisData.xData),
        },
    };

    const yAxisProps: any = {
        orientation: layout === 'vertical' ? axis?.xOrientation : axis?.yOrientation,
        stroke: axis?.lineColor,
        axisLine: layout === 'vertical' ? axis?.xLine : axis?.yLine,
        unit: axis?.yUnit && typeof axis?.yUnit !== 'string' ? axis?.yUnit[0] : axis?.yUnit,
        tick: {
            ...tickViewValues.tick,
            ...(layout === 'vertical'
                ? typeof tick?.xView !== 'undefined' &&
                  typeof tick?.xView === 'boolean' &&
                  !tick?.xView && { fill: 'transparent' }
                : typeof tick?.yView !== 'undefined' &&
                  typeof tick?.yView === 'boolean' &&
                  !tick?.yView && { fill: 'transparent' }),
            width: layout === 'vertical' ? tick?.width?.x : tick?.width?.y,
        },
        tickLine: tickViewValues.tickLine,
        ...(tick?.points && { ticks: tick?.points }),
        ...(range && { domain: range }),
        type: 'number',
        angle: layout === 'vertical' ? tick?.angle?.x : tick?.angle?.y,
        tickMargin: layout === 'vertical' ? tick?.margin?.x : tick?.margin?.y,
        label: {
            ...(layout === 'vertical' ? axisData.xData : axisData.yData),
        },
    };

    const renderLines = () => {
        const keysArr: string[] = Object.keys(newData[0]).slice(1);
        const lineArr: any[] = [];
        keysArr.forEach((item: string, index: number) => {
            lineArr.push(
                <Line
                    strokeDasharray={lineStrokeDash?.[item]}
                    key={index} // eslint-disable-line
                    type="monotone"
                    dataKey={item}
                    stroke={colors ? colors[index] : randomColor()}>
                    {lineLabels?.includes(item) && <LabelList content={<CustomizedLabel />} />}
                </Line>,
            );
        });
        return lineArr;
    };

    useEffect(() => setNewData(getDataModelForBarChart(data)), [data]);

    return (
        <div
            className={manageClassNames(generateClass('LineChart'), className)}
            style={{ position: 'relative', width: '100%', paddingBottom: height }}>
            <div
                style={{
                    position: 'absolute',
                    left: 0,
                    right: 0,
                    bottom: 0,
                    top: 0,
                }}>
                <ResponsiveContainer width="100%" height="100%">
                    <ReLineChart
                        layout={layout}
                        id={uuidv4()}
                        data={newData}
                        margin={margin}
                        {...(tooltip && {
                            /* istanbul ignore next */
                            onMouseMove: (state: any) => {
                                // For Tooltip custom valueUI
                                /* istanbul ignore next */
                                if (state?.isTooltipActive) setactiveTooltipData(state);
                                else setactiveTooltipData(null);
                            },
                        })}>
                        {!!grid &&
                            (typeof grid === 'boolean' && grid === true ? (
                                <CartesianGrid strokeDasharray="3 3" />
                            ) : (
                                <CartesianGrid {...grid} />
                            ))}
                        <XAxis
                            {...(layout === 'horizontal' && xAxisProps)}
                            {...(layout === 'vertical' && yAxisProps)}
                        />
                        <YAxis
                            {...(layout === 'horizontal' && yAxisProps)}
                            {...(layout === 'vertical' && xAxisProps)}
                        />

                        {referenceLine?.x && (
                            <ReferenceLine
                                x={referenceLine?.x}
                                stroke={referenceLine.strokeX}
                                label={referenceLine.labelX}
                            />
                        )}
                        {referenceLine?.y && (
                            <ReferenceLine
                                y={referenceLine?.y}
                                stroke={referenceLine.strokeY}
                                label={referenceLine.labelY}
                            />
                        )}

                        {tooltip && CustomTooltip('line', tooltip, activeTooltipData, data, axis?.yUnit)}
                        {legend && CustomLegend(legend)}
                        {renderLines()}
                    </ReLineChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default LineChart;
