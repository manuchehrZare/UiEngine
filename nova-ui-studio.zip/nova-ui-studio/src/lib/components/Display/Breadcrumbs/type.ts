import type { BreadcrumbsProps, SxProps, Theme } from '@mui/material';
import type { ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';

export type UnderlineType = 'none' | 'hover' | 'always';
export interface IUnderline {
    breadcrumbs?: UnderlineType;
    home?: UnderlineType;
}
export interface IBreadcrumbsItems {
    iconLeft?: ReactNode;
    iconRight?: ReactNode;
    link?: string;
    menuIcon?: ReactNode;
    select?: ISelectItems[];
    text?: string;
}

export interface ISelectItems extends Omit<IBreadcrumbsItems, 'select'> {}

export interface IHomeItems extends Omit<IBreadcrumbsItems, 'text' | 'select'> {
    icon?: ReactNode;
    show?: boolean;
    text?: string;
}
export interface IBreadcrumbsProps extends ICommonProps, Pick<BreadcrumbsProps, 'className' | 'id'> {
    breadCrumbsItems: IBreadcrumbsItems[];
    homeItems: IHomeItems[];
    itemsAfterCollapse?: number;
    itemsBeforeCollapse?: number;
    maxItems?: number;
    separator?: ReactNode;
    sx?: SxProps<Theme>;
    type?: 'chip' | 'default';
    underline?: IUnderline;
}
