import type { FC } from 'react';
import { memo } from 'react';
import type { IEmptyProps } from './type';
import type { Theme } from '@mui/material';
import { Box, Typography } from '@mui/material';
import { MoreHorizOutlined } from '@mui/icons-material';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme, manageClassNames } from '../../../utils';

const Empty: FC<IEmptyProps> = ({ design, text, loading = false, className = '', ...rest }) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <Box
                sx={{
                    height: 200,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlign: 'center',
                    position: 'relative',
                    color: (theme) => theme.palette.primary.main,
                }}
                component="div"
                className={manageClassNames(
                    generateClass('Empty'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                {...rest}>
                {loading ? <MoreHorizOutlined /> : <Typography variant="overline">{text}</Typography>}
            </Box>
        </ThemeProvider>
    );
};

export default memo(Empty);
