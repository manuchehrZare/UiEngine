/**
 * IMPORTS
 */

/**
 * EXPORTS
 */
// Others
export { FileAcceptValues, FileTypes } from './utils';
export { pickerProps } from './components/Form/_helper';
export {
    accordionActionsClasses,
    accordionClasses,
    accordionDetailsClasses,
    accordionSummaryClasses,
    alertClasses,
    alertTitleClasses,
    appBarClasses,
    autocompleteClasses,
    avatarClasses,
    avatarGroupClasses,
    backdropClasses,
    badgeClasses,
    bottomNavigationActionClasses,
    bottomNavigationClasses,
    boxClasses,
    breadcrumbsClasses,
    buttonBaseClasses,
    buttonClasses,
    buttonGroupClasses,
    cardActionAreaClasses,
    cardActionsClasses,
    cardClasses,
    cardContentClasses,
    cardHeaderClasses,
    cardMediaClasses,
    checkboxClasses,
    circularProgressClasses,
    collapseClasses,
    containerClasses,
    dialogActionsClasses,
    dialogClasses,
    dialogContentClasses,
    dialogContentTextClasses,
    dialogTitleClasses,
    dividerClasses,
    drawerClasses,
    fabClasses,
    filledInputClasses,
    formControlClasses,
    formControlLabelClasses,
    formGroupClasses,
    formHelperTextClasses,
    formLabelClasses,
    grid2Classes,
    gridClasses,
    iconButtonClasses,
    iconClasses,
    imageListClasses,
    imageListItemBarClasses,
    imageListItemClasses,
    inputAdornmentClasses,
    inputBaseClasses,
    inputClasses,
    inputLabelClasses,
    linearProgressClasses,
    linkClasses,
    listClasses,
    listItemAvatarClasses,
    listItemButtonClasses,
    listItemClasses,
    listItemIconClasses,
    listItemSecondaryActionClasses,
    listItemTextClasses,
    listSubheaderClasses,
    menuClasses,
    menuItemClasses,
    mobileStepperClasses,
    modalClasses,
    nativeSelectClasses,
    outlinedInputClasses,
    paginationClasses,
    paginationItemClasses,
    paperClasses,
    popoverClasses,
    radioClasses,
    radioGroupClasses,
    ratingClasses,
    scopedCssBaselineClasses,
    selectClasses,
    skeletonClasses,
    sliderClasses,
    snackbarClasses,
    snackbarContentClasses,
    speedDialActionClasses,
    speedDialClasses,
    speedDialIconClasses,
    stackClasses,
    stepButtonClasses,
    stepClasses,
    stepConnectorClasses,
    stepContentClasses,
    stepIconClasses,
    stepLabelClasses,
    stepperClasses,
    svgIconClasses,
    switchClasses,
    tabClasses,
    tabScrollButtonClasses,
    tableBodyClasses,
    tableCellClasses,
    tableClasses,
    tableContainerClasses,
    tableFooterClasses,
    tableHeadClasses,
    tablePaginationClasses,
    tableRowClasses,
    tableSortLabelClasses,
    tabsClasses,
    textFieldClasses,
    toggleButtonClasses,
    toggleButtonGroupClasses,
    toolbarClasses,
    tooltipClasses,
    touchRippleClasses,
    typographyClasses,
} from '@mui/material';
export { masonryClasses } from '@mui/lab';
export { treeViewClasses, treeItemClasses } from '@mui/x-tree-view';
export {
    GRID_CHECKBOX_SELECTION_COL_DEF as datagridCheckboxSelectionColDef,
    GridActionsCellItem as DataGridActionsCellItem,
    GridFooter as DataGridFooter,
    GridPagination as DataGridPagination,
    getGridBooleanOperators as getDataGridBooleanOperators,
    getGridDateOperators as getGridDateOperators,
    getGridNumericOperators as getDataGridNumericOperators,
    getGridSingleSelectOperators as getDataGridSingleSelectOperators,
    getGridStringOperators as getDataGridStringOperators,
    gridClasses as dataGridClasses,
    gridPageCountSelector as dataGridPageCountSelector,
    gridPageSelector as dataGridPageSelector,
    gridPageSizeSelector as dataGridPageSizeSelector,
    gridPaginatedVisibleSortedGridRowEntriesSelector as dataGridPaginatedVisibleSortedGridRowEntriesSelector,
    gridPaginatedVisibleSortedGridRowIdsSelector as dataGridPaginatedVisibleSortedGridRowIdsSelector,
    gridPaginationMetaSelector as dataGridPaginationMetaSelector,
    gridPaginationModelSelector as dataGridPaginationModelSelector,
    gridPaginationRowCountSelector as dataGridPaginationRowCountSelector,
    gridPaginationRowRangeSelector as dataGridPaginationRowRangeSelector,
    gridPanelClasses as dataGridPanelClasses,
    useGridApiRef as useDataGridApiRef,
} from '@mui/x-data-grid-pro';

export { chipClasses } from './components/Display/Chip/classes';

// Theme
export { theme } from './theme';

// App Components
export { default as Provider } from './components/App/Provider';

// Form Components
export { default as Autocomplete } from './components/Form/Autocomplete';
export { default as Button } from './components/Form/Button/Button';
export { default as ButtonGroup } from './components/Form/Button/ButtonGroup';
export { default as Checkbox } from './components/Form/Checkbox';
export { default as DatePicker } from './components/Form/DatePicker';
export { default as DateTimePicker } from './components/Form/DateTimePicker';
export { default as Input } from './components/Form/Input';
export { default as NumberInput } from './components/Form/NumberInput';
export { default as Radio } from './components/Form/Radio';
export { default as RadioGroup } from './components/Form/RadioGroup';
export { default as RangeInput } from './components/Form/RangeInput';
export { default as Rating } from './components/Display/Rating';
export { default as RichEditor } from './components/Form/RichEditor';
export { default as Select } from './components/Form/Select';
export { default as Switch } from './components/Form/Switch';
export { default as TimePicker } from './components/Form/TimePicker';
export { default as Upload } from './components/Form/Upload';
export { default as FileSelector } from './components/Form/FileSelector';

// Display Components
export { BarChart, PieChart, LineChart } from './components/Display/Chart';
export { default as Accordion } from './components/Display/Accordion';
export { default as Alert } from './components/Display/Alert';
export { default as Avatar } from '@mui/material/Avatar';
export { default as Box } from '@mui/material/Box';
export { default as Breadcrumbs } from './components/Display/Breadcrumbs';
export { default as Break } from './components/Display/Break';
export { default as Carousel } from './components/Display/Carousel/Carousel';
export { default as CarouselItem } from './components/Display/Carousel/CarouselItem';
export { default as Chip } from './components/Display/Chip';
export { default as Collapse } from './components/Display/Collapse';
export { default as ConfirmModal } from './components/Display/Confirm';
export { default as Container } from './components/Display/Container';
export { default as CustomScrollbar } from './components/Display/CustomScrollbar';
export { default as DataGrid } from './components/Display/DataGrid';
export { default as Divider } from './components/Display/Divider';
export { default as Empty } from './components/Display/Empty';
export { default as Grid } from './components/Display/Grid/Grid';
export { default as GridItem } from './components/Display/Grid/GridItem';
export { default as KeyValueList } from './components/Display/KeyValueList';
export { default as Label } from './components/Display/Label';
export { default as LoadingModal } from './components/Display/LoadingModal';
export { default as Masonry } from '@mui/lab/Masonry';
export { default as Menu } from '@mui/material/Menu';
export { default as MenuList } from '@mui/material/MenuList';
export { default as MenuItem } from '@mui/material/MenuItem';
export { default as Modal } from './components/Display/Modal';
export { default as ModalBody } from './components/Display/Modal/Body';
export { default as ModalFooter } from './components/Display/Modal/Footer';
export { default as ModalTitle } from './components/Display/Modal/Title';
export { default as Nav } from './components/Display/Nav/Nav';
export { default as NavContainer } from './components/Display/Nav/NavContainer';
export { default as NavItem } from './components/Display/Nav/NavItem';
export { default as NavRow } from './components/Display/Nav/NavRow';
export { default as NavTitle } from './components/Display/Nav/NavTitle';
export { default as NumberFormat } from './components/Display/NumberFormat';
export { default as Pagination } from './components/Display/Pagination';
export { default as Paper } from './components/Display/Paper';
export { default as PdfViewer } from './components/Display/PdfViewer';
export { default as Popup } from './components/Display/Popup';
export { default as Progress } from './components/Display/Progress';
export { default as ScrollPageTop } from './components/Display/ScrollPageTop';
export { default as Stepper } from './components/Display/Stepper';
export { default as Tab } from './components/Display/Tab/Tab';
export { default as TabItem } from './components/Display/Tab/TabItem';
export { default as Table } from './components/Display/Table';
export { default as TableBody } from './components/Display/Table/TableBody';
export { default as TableCell } from './components/Display/Table/TableCell';
export { default as TableFooter } from './components/Display/Table/TableFooter';
export { default as TableHead } from './components/Display/Table/TableHead';
export { default as TableRow } from './components/Display/Table/TableRow';
export { default as Tooltip } from './components/Display/Tooltip';
export { default as TreeView } from './components/Display/TreeView';
export { default as Typography } from '@mui/material/Typography';
export { default as VRKeyboard } from './components/Display/VRKeyboard';
export { default as View } from './components/Display/View';
export { SnackbarContent as MessageContent } from 'notistack';

// Others Components
export { default as CardNumber } from './components/Others/CardNumber';
export { default as PhoneNumber } from './components/Others/PhoneNumber';
export { default as Currency } from './components/Others/Currency';
export { default as IBAN } from './components/Others/IBAN';

// Hooks
export { default as useArrayField } from './hooks/useArrayField';
export { default as useAudio } from './hooks/useAudio';
export { default as useCapsLockDetector } from './hooks/useCapsLockDetector';
export { default as useClipboard } from './hooks/useClipboard';
export { default as useComputedStyles } from './hooks/useComputedStyles';
export { default as useDebounce } from './hooks/useDebounce';
export { default as useDevice } from './hooks/useDevice';
export { default as useForm } from './hooks/useForm';
export { default as useIsFirstRender } from './hooks/useIsFirstRender';
export { default as useMeasure } from './hooks/useMeasure';
export { default as useNow } from './hooks/useNow';
export { default as usePrint } from './hooks/usePrint';
export { default as useReRender } from './hooks/useReRender';
export { default as useStorage } from './hooks/useStorage';
export { default as useTimer } from './hooks/useTimer';
export { default as useTitle } from './hooks/useTitle';
export { default as useWatch } from './hooks/useWatch';
export { default as useWidth } from './hooks/useWidth';
export { default as useWindowOpen } from './hooks/useWindowOpen';

/**
 * TYPES & ENUM Export
 */
/** TYPES */
// Theme
export type { Theme, SxProps, Components } from '@mui/material';
export type { CSSSelectorObjectOrCssVariables } from '@mui/system';
export type {
    GridFilterItem as DataGridFilterItem,
    GridFilterModel as DataGridFilterModel,
    GridPaginationModel as DataGridPaginationModel,
    GridSortModel as DataGridSortModel,
    GridRowModel as DataGridRowModel,
    GridFetchRowsParams as DataGridFetchRowsParams,
} from '@mui/x-data-grid-pro';
export type {} from '@mui/x-data-grid-pro/themeAugmentation';
export type {} from '@mui/x-tree-view/themeAugmentation';

// General
export type { ChartDataTypes, ChartTooltipTypes, IChartData } from './components/Display/Chart/commonTypes';
export type { DataGridColumnsPropsType, PageSizeType } from './components/Display/DataGrid/type';
export type { DateTimeType } from './components/Form/DateTimePicker/type';
export type { DateType } from './components/Form/DatePicker/type';
export type { IBarChartData, IPieChartData, ILineChartData } from './components/Display/Chart';
export type { IDocumentDetail } from './components/Form/Upload/type';
export type { IResultData } from './utils/types/data';
export type { IUploadDocument } from './utils/types/upload';
export type { ModalCloseReasonType } from './components/Display/Modal/type';
export type { RichEditorToolbarItemType } from './components/Form/RichEditor/type';
export type { TimeType } from './components/Form/TimePicker/type';

// ComponentProps -> App
export type { IProviderProps } from './components/App/Provider';

// ComponentProps -> Display
export type { IAccordionProps } from './components/Display/Accordion/type';
export type { IAlertProps } from './components/Display/Alert/type';
export type { IBarChartProps } from './components/Display/Chart/Bar/type';
export type {
    AvatarProps as IAvatarProps,
    BoxProps as IBoxProps,
    MenuProps as IMenuProps,
    MenuListProps as IMenuListProps,
    MenuItemProps as IMenuItemProps,
} from '@mui/material';
export type { MasonryProps as IMasonryProps } from '@mui/lab';
export type { IBreadcrumbsProps } from './components/Display/Breadcrumbs/type';
export type { IBreakProps } from './components/Display/Break';
export type {
    ICarouselProps,
    ICarouselItemProps,
    CarouselContentPositionType,
    CarouselIndicatorsPositionType,
} from './components/Display/Carousel/type';
export type { IChartCommonProps } from './components/Display/Chart/commonTypes';
export type { ICircularProgressProps } from './components/Display/Progress/Circular/type';
export type { IChipProps } from './components/Display/Chip/type';
export type { ICollapseProps } from './components/Display/Collapse/type';
export type { IConfirmModalProps } from './components/Display/Confirm/type';
export type { IContainerProps } from './components/Display/Container/type';
export type { ICustomScrollValues, ICustomScrollbarProps } from './components/Display/CustomScrollbar/type';
export type { IDataGridProps, DataGridColDef } from './components/Display/DataGrid/type';
export type { IDividerProps } from './components/Display/Divider/type';
export type { IEmptyProps } from './components/Display/Empty/type';
export type { IGridItemProps, IGridProps } from './components/Display/Grid/type';
export type { IKeyValueListProps, IKeyValueListItem } from './components/Display/KeyValueList/type';
export type { ILabelProps } from './components/Display/Label/type';
export type { ILinearProgressProps } from './components/Display/Progress/Linear/type';
export type { ILineChartProps } from './components/Display/Chart/Line/type';
export type { ILoadingModalProps } from './components/Display/LoadingModal/type';
export type {
    IModalProps,
    IModalTitleProps,
    IModalBodyProps,
    IModalFooterProps,
} from './components/Display/Modal/type';
export type {
    INavProps,
    INavContainerProps,
    INavItemProps,
    INavRowProps,
    INavTitleProps,
    IBackButtonProps,
} from './components/Display/Nav/type';
export type { INumberFormatProps } from './components/Display/NumberFormat/type';
export type { IPaperProps } from './components/Display/Paper/type';
export type { IPDFViewerProps } from './components/Display/PdfViewer/type';
export type { IPieChartProps } from './components/Display/Chart/Pie/type';
export type { IPopupProps } from './components/Display/Popup/type';
export type { IRatingProps } from './components/Display/Rating/type';
export type { IScrollPageTopProps } from './components/Display/ScrollPageTop/index';
export type { IStepStepperRef, IStepType, IStepperProps } from './components/Display/Stepper/type';
export type { ITabItemProps, ITabProps } from './components/Display/Tab/type';
export type { ITableBodyProps } from './components/Display/Table/TableBody/type';
export type { ITableCellProps } from './components/Display/Table/TableCell/type';
export type { ITableFooterProps } from './components/Display/Table/TableFooter/type';
export type { ITableHeadProps } from './components/Display/Table/TableHead/type';
export type { ITableProps } from './components/Display/Table/type';
export type { ITableRowProps } from './components/Display/Table/TableRow/type';
export type { ITooltipProps } from './components/Display/Tooltip/type';
export type { ITreeViewProps } from './components/Display/TreeView/type';
export type { IVRKeyboardProps } from './components/Display/VRKeyboard/type';
export type { IViewProps } from './components/Display/View/type';

// ComponentProps -> Form
export type { IAutocompleteProps, IAutocompleteOptions } from './components/Form/Autocomplete/type';
export type { IButtonGroupProps, IButtonProps } from './components/Form/Button/type';
export type { ICheckboxProps } from './components/Form/Checkbox/type';
export type { IDatePickerProps } from './components/Form/DatePicker/type';
export type { IDateTimePickerProps } from './components/Form/DateTimePicker/type';
export type { IInputProps } from './components/Form/Input/type';
export type { INumberInputProps } from './components/Form/NumberInput/type';
export type { IRadioGroupProps } from './components/Form/RadioGroup/type';
export type { IRadioProps } from './components/Form/Radio/type';
export type { IRangeInputProps } from './components/Form/RangeInput/type';
export type { IRichEditorProps } from './components/Form/RichEditor/type';
export type { IBaseSelectProps, INativeSelectProps, ISelectOptions, ISelectProps } from './components/Form/Select/type';
export type { ISwitchProps } from './components/Form/Switch/type';
export type { ITimePickerProps } from './components/Form/TimePicker/type';
export type { IUploadProps } from './components/Form/Upload/type';
export type {
    IFileSelectorButtonProps,
    IFileSelectorInputProps,
    IFileSelectorProps,
} from './components/Form/FileSelector/type';

// ComponentProps -> Others
export type {
    ICardNumberFormatProps,
    ICardNumberInputProps,
    ICardNumberProps,
} from './components/Others/CardNumber/type';
export type {
    IPhoneNumberFormatProps,
    IPhoneNumberInputProps,
    IPhoneNumberProps,
} from './components/Others/PhoneNumber/type';
export type { ICurrencyFormatProps, ICurrencyInputProps, ICurrencyProps } from './components/Others/Currency/type';
export type { IIBANError, IIBANInputProps, IIBANDisplayProps, IBANProps } from './components/Others/IBAN/type';
// HookProps
export type { IUseArrayFieldProps } from './hooks/useArrayField';
export type {
    CallbackErrorType,
    CallbackSuccessType,
    IUseClipboardReturn,
    UseClipboardOptions,
    UseClipboardReturnType,
} from './hooks/useClipboard';
export type { UseComputedStylesReturnType } from './hooks/useComputedStyles';
export type { UseDeviceReturn } from './hooks/useDevice';
export type {
    Control,
    DefaultValues,
    FieldErrors,
    FieldValues,
    IUseFormProps,
    Path,
    PathValue,
    UseFormClearErrors,
    UseFormGetValues,
    UseFormReturnType,
} from './hooks/useForm';
export type { MeasureValues, UseMeasureOptions, UseMeasureReturnType } from './hooks/useMeasure';
export type { IUsePrintProps, UsePrintReturnType } from './hooks/usePrint';
export type { UseReRenderReturnType } from './hooks/useReRender';
export type { StorageValueType, UseStorageOptions, UseStorageReturnType } from './hooks/useStorage';
export type { UseTimerBaseOptions, UseTimerCallbackOptions, UseTimerOptions, UseTimerReturn } from './hooks/useTimer';
export type { IUseWatchProps, UseWatchReturnType } from './hooks/useWatch';
export type { WidthSize as UseWidthReturnType } from './hooks/useWidth';
export type {
    WindowOpenError,
    WindowOpenFeatures,
    WindowOpenMessageType,
    WindowOpenTarget,
} from './hooks/useWindowOpen';

// Utils
export type {
    ChangeLanguageOptions,
    ComputedStyles,
    DeepRequired,
    DesignType,
    Enumerate,
    ExcelToJsonAcceptType,
    ExcelToJsonReturnType,
    ExcelToJsonSheetRangeType,
    ExcelToJsonSheetRowsType,
    FixedSizeArray,
    GetFlashAnimationCSSOptions,
    HelperComponentProps,
    HelperFormProps,
    IConfirm,
    IExcelToJsonOptions,
    IExcelToJsonSheetCell,
    IExcelToJsonSheetRangeValues,
    IExportTableColumns,
    IExportTableDateOptions,
    IExportTableProps,
    IMessageProviderProps,
    IMessageVariantOverrides,
    INumberFormatOptions,
    IPhoneNumberFormatterOptions,
    MessageCustomContentProps,
    Now,
    PositiveRange,
    ReplaceTRtoEnCharsConfig,
    Time,
    TimeReturnValues,
} from './utils';

// Others
export type { Breakpoint } from '@mui/system';
export type { Config as SanitizeOptions } from 'isomorphic-dompurify';

/** ENUMS */
// General
export { GridLogicOperator as DataGridLogicOperatorEnum } from '@mui/x-data-grid-pro';

// ComponentEnums
export { CarouselContentPositionEnum } from './components/Display/Carousel/type';
export { DataGridColumnTypeEnum } from './components/Display/DataGrid/type';
export { DateTimeTypeEnum } from './components/Form/DateTimePicker/type';
export { DateTypeEnum } from './components/Form/DatePicker/type';
export { FileInsertLocationEnum, FileGenerateTypeEnum } from './components/Form/Upload/type';
export { IBANErrorTypeEnum } from './components/Others/IBAN/type';
export { InputTypeEnum } from './components/Form/Input/type';
export { ModalCloseReasonEnum } from './components/Display/Modal/type';
export { NumberInputReturnValueEnum } from './components/Form/NumberInput/type';
export { PopupAnchorTriggerEnum } from './components/Display/Popup/type';
export { ProgressTypeEnum } from './components/Display/Progress/type';
export { RichEditorToolbarItemEnum } from './components/Form/RichEditor/type';
export { TimeTypeEnum } from './components/Form/TimePicker/type';

// HookEnums
export { UseTimerErrorEnum } from './hooks/useTimer';
export { WindowOpenTargetEnum, WindowOpenProcessTypeEnum } from './hooks/useWindowOpen';

// TypesEnums
export { DesignTypeEnum, MessageTypeEnum, PrinterTypeEnum } from './utils';

// UtilsEnums
export { BgColorEnum, FileExtentionsEnum, ValidationsCompareTypeEnum } from './utils';

// Utils Export
export {
    alpha,
    asyncForEach,
    base64Decryption,
    base64Encryption,
    base64ToDataUri,
    cardNumberFormatter,
    cleanDeep,
    closeMessage,
    confirm,
    constants,
    currency,
    deepCopy,
    deepKeysAsArray,
    deepKeysAsObject,
    deepmerge,
    excelToJson,
    exportHtmlToPDF,
    exportHtmlToText,
    exportTable,
    exportWord,
    fileDownloader,
    findDeep,
    generateClass,
    getBgColorByClassName,
    getComputedStyles,
    getCookie,
    getDateFromExcelDate,
    getExcelDateFromDate,
    getFileSize,
    getLocalStorageItem,
    getNow,
    getProviderDesign,
    getSessionStorageItem,
    groupString,
    hideLoading,
    i18n,
    i18nChangeLanguage,
    i18nInit,
    i18nInitialize,
    iban,
    importantStyle,
    isBase64,
    isDataUri,
    isNumeric,
    isParsableToJson,
    isXmlString,
    jsToXml,
    jsonToQueryString,
    languageStorageKey,
    locale,
    manageClassNames,
    message,
    millisecondsToTime,
    mimeTypes,
    numberFormat,
    phoneNumberFormatter,
    printer,
    queryStringToJSON,
    randomColor,
    randomNumber,
    removeCookie,
    removeLocalStorageItem,
    removeProviderDesign,
    removeSessionStorageItem,
    replaceTRtoENChars,
    sanitizeHTML,
    scrollToElement,
    scrollToTop,
    setCookie,
    setLocalStorageItem,
    setProviderDesign,
    setSessionStorageItem,
    sharedEventListener,
    sharedIntersectionObserver,
    sharedMutationObserver,
    sharedResizeObserver,
    showLoading,
    sleep,
    stringHTMLToJSX,
    stripHtmlFromText,
    timeToMilliseconds,
    txtToString,
    useTranslation,
    validation,
    xmlToJs,
} from './utils';
