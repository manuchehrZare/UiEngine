import type { Components, Theme } from '@mui/material';

export const MuiAppbarTheme: Components = {
    MuiAppBar: {
        styleOverrides: {
            positionFixed: ({ theme }) => ({
                background: (theme as Theme).palette.common.white,
                boxShadow: 'none',
                padding: 0,
                width: '100%',
                flexShrink: 0,

                '&:before': {
                    content: '""',
                    left: 0,
                    position: 'absolute',
                    backgroundRepeat: 'repeat-x',
                    backgroundSize: '1px 7px',
                    height: 7,
                    width: '100%',
                    zIndex: 3,
                },
            }),
        },
    },
    MuiToolbar: {
        styleOverrides: {
            root: {
                padding: '0 1rem 0 0 !important',
            },
        },
    },
};
