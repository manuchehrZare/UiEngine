import type { Components, Theme } from '@mui/material';
import { DesignTypeEnum } from '../../utils';

export const MuiTableTheme: Components = {
    MuiTableContainer: {
        styleOverrides: {
            root: {},
        },
    },
    MuiTable: {
        styleOverrides: {
            root: {},
        },
    },
    MuiTableCell: {
        styleOverrides: {
            root: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                fontSize: 'var(--field-font-size)',

                [`.${DesignTypeEnum.SET} &`]: {
                    fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                },

                '.no-border &': {
                    border: 'none',
                },
            }),
            head: {
                fontWeight: 600,
            },
            footer: ({ theme }) => ({
                borderBottom: 'none',
                borderTop: `1px solid ${(theme as Theme).palette.grey[300]}`,
            }),
        },
    },
    MuiTableRow: {
        styleOverrides: {
            root: {
                '&:last-child': {
                    '& .MuiTableCell-root:not(.MuiTableCell-head):not(.MuiTableCell-footer)': {
                        border: 'none',
                    },
                },
            },
        },
    },
};
