import { KeyboardArrowDown } from '@mui/icons-material';
import type { Components } from '@mui/material';
import { importantStyle } from '../../../utils';

export const MuiSelectTheme: Components = {
    MuiSelect: {
        defaultProps: {
            IconComponent: KeyboardArrowDown,
            classes: {
                icon: 'arrow-icon',
            },
            MenuProps: {
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left',
                },
            },
        },
        styleOverrides: {
            select: ({ ownerState }) => {
                return {
                    ...((ownerState?.value as string) &&
                        !ownerState?.displayEmpty &&
                        !ownerState?.disabled &&
                        !ownerState?.readOnly && { paddingRight: importantStyle('64px') }),
                };
            },
            icon: {
                borderRadius: '50%',
            },
        },
    },
    MuiNativeSelect: {
        styleOverrides: {
            select: {
                option: {
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    paddingLeft: 0,
                    ':disabled': {
                        opacity: 0.38,
                    },
                },
                overflowY: 'auto',
            },
            outlined: {
                marginTop: importantStyle('1px'),
                padding: importantStyle('8.5px 0px 4.5px 14px'),
            },
            filled: ({ ownerState }) => ({
                marginTop: importantStyle(ownerState.size === 'small' ? '21.25px' : '24px'),
                padding: importantStyle('0px 0px 4.5px 14px'),
            }),
        },
    },
};
