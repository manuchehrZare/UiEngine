import type { Components } from '@mui/material';
import { breadcrumbsClasses, linkClasses } from '@mui/material';

export const MuiBreadcrumbsTheme: Components = {
    MuiBreadcrumbs: {
        styleOverrides: {
            root: {
                fontSize: 'var(--field-label-font-size)',
                '& .breadcrumbs-cursor': {
                    cursor: 'pointer',
                },
                '& .MuiTypography-root': {
                    fontSize: 'var(--field-label-font-size)',
                    display: 'flex',
                    alignItems: 'center',
                    '& .open': {
                        transform: 'rotate(90deg)',
                        transition: 'all .1s linear',
                    },
                    '& .open:focus': {
                        transform: 'rotate(0deg)',
                    },
                    '& .close': {
                        transform: 'rotate(0deg)',
                        transition: 'all .1s linear',
                    },
                    '& .close:focus': {
                        transform: 'rotate(90deg)',
                    },
                },
                [`& .${breadcrumbsClasses.li}`]: {
                    [`& .${linkClasses.underlineAlways}`]: {
                        '&:hover': {
                            textDecoration: 'underline !important',
                        },
                    },
                },
                a: {
                    display: 'flex',
                    alignItem: 'center',
                },
            },
        },
    },
};
