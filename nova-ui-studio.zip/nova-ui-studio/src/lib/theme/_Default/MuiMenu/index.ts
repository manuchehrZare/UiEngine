import type { Components } from '@mui/material';
import { menuClasses } from '../../..';

export const MuiMenuTheme: Components = {
    MuiMenuItem: {
        styleOverrides: {
            root: {},
        },
    },
    MuiMenu: {
        styleOverrides: {
            root: {
                '& .breadcrumbs-select': {
                    padding: '2px 10px 2px 10px !important',
                    fontSize: 'var(--field-label-font-size)',
                },
            },
            list: {
                [`.${menuClasses.root}[aria-hidden] &`]: {
                    pointerEvents: 'none',
                },
            },
        },
    },
};
