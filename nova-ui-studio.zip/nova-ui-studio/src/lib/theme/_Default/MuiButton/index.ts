import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { DesignTypeEnum } from '../../../utils';

const themeConfig = {
    iconButton: {
        small: {
            padding: 4,
        },
        medium: {
            padding: 6,
        },
        large: {
            padding: 8,
        },
    },
    small: {
        minHeight: 32.5,
    },
    medium: {
        minHeight: 36.5,
    },
    large: {
        minHeight: 40.5,
    },
    fontSize: `var(--button-font-size-${DesignTypeEnum.Default})`,
};

export const MuiButtonTheme: Components = {
    MuiButtonGroup: {
        styleOverrides: {
            root: {
                textTransform: 'none',
                fontWeight: 'bold',
                boxShadow: 'none',
            },
        },
    },
    MuiButton: {
        styleOverrides: {
            root: {
                fontWeight: 500,
                boxShadow: 'none',
                fontSize: themeConfig.fontSize,

                '&.rounded': {
                    borderRadius: 'var(--border-radius-full) !important',
                },

                '&.left-rounded': {
                    borderTopLeftRadius: 'var(--border-radius-full) !important',
                    borderBottomLeftRadius: 'var(--border-radius-full) !important',
                },

                '&.right-rounded': {
                    borderTopRightRadius: 'var(--border-radius-full) !important',
                    borderBottomRightRadius: 'var(--border-radius-full) !important',
                },
            },
            sizeSmall: {
                '.btn-loading': {
                    margin: 4.25,
                    width: `calc(${themeConfig.fontSize} + 2px) !important`,
                    height: `calc(${themeConfig.fontSize} + 2px) !important`,
                },

                '&.btn-no-text': {
                    padding: '4px 10px',

                    svg: {
                        margin: 3.25,
                        width: `calc(${themeConfig.fontSize} + 2px)`,
                        height: `calc(${themeConfig.fontSize} + 2px)`,
                    },

                    '.btn-loading': {
                        margin: 3.25,
                        svg: {
                            margin: 0,
                        },
                    },
                },

                '&.icon-button': {
                    minWidth: themeConfig.small.minHeight,
                    padding: themeConfig.iconButton.small.padding,
                },
            },
            sizeMedium: {
                '.btn-loading': {
                    margin: 3.75,
                    width: `calc(${themeConfig.fontSize} + 3px) !important`,
                    height: `calc(${themeConfig.fontSize} + 3px) !important`,
                },

                '&.btn-no-text': {
                    padding: '6px 16px',

                    svg: {
                        margin: 2.75,
                        width: `calc(${themeConfig.fontSize} + 3px)`,
                        height: `calc(${themeConfig.fontSize} + 3px)`,
                    },

                    '.btn-loading': {
                        margin: 2.75,
                        svg: {
                            margin: 0,
                        },
                    },
                },

                '&.icon-button': {
                    minWidth: themeConfig.medium.minHeight,
                    padding: themeConfig.iconButton.medium.padding,
                },
            },
            sizeLarge: {
                '.btn-loading': {
                    margin: 3.25,
                    width: `calc(${themeConfig.fontSize} + 4px) !important`,
                    height: `calc(${themeConfig.fontSize} + 4px) !important`,
                },

                '&.btn-no-text': {
                    padding: '8px 22px',

                    svg: {
                        margin: 2.25,
                        width: `calc(${themeConfig.fontSize} + 4px)`,
                        height: `calc(${themeConfig.fontSize} + 4px)`,
                    },

                    '.btn-loading': {
                        margin: 2.25,
                        svg: {
                            margin: 0,
                        },
                    },
                },

                '&.icon-button': {
                    minWidth: themeConfig.large.minHeight,
                    padding: themeConfig.iconButton.large.padding,
                },
            },
            outlinedPrimary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.primary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.primary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.primary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.primary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.primary.light, 0.3),
                    },
                },
            }),
            outlinedSecondary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.secondary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.secondary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.secondary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.secondary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.secondary.light, 0.3),
                    },
                },
            }),
            outlinedError: ({ theme }) => ({
                borderColor: (theme as Theme).palette.error.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.error.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.error.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.error.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.error.light, 0.3),
                    },
                },
            }),
            outlinedInfo: ({ theme }) => ({
                borderColor: (theme as Theme).palette.info.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.info.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.info.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.info.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.info.light, 0.3),
                    },
                },
            }),
            outlinedWarning: ({ theme }) => ({
                borderColor: (theme as Theme).palette.warning.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.warning.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.warning.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.warning.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.warning.light, 0.3),
                    },
                },
            }),
            outlinedSuccess: ({ theme }) => ({
                borderColor: (theme as Theme).palette.success.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.success.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.success.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.success.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.success.light, 0.3),
                    },
                },
            }),
            outlinedInherit: ({ theme }) => ({
                borderColor: (theme as Theme).palette.grey[700],

                '.btn-loading': {
                    color: (theme as Theme).palette.grey[500],
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.grey[700], 0.6),
                    borderColor: alpha((theme as Theme).palette.grey[700], 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.grey[500], 0.3),
                    },
                },
            }),
            containedPrimary: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.primary.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.primary.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.primary.light, 0.4),
                    },
                },
            }),
            containedSecondary: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.secondary.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.secondary.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.secondary.light, 0.4),
                    },
                },
            }),
            containedError: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.error.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.error.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.error.light, 0.4),
                    },
                },
            }),
            containedInfo: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.info.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.info.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.info.light, 0.4),
                    },
                },
            }),
            containedWarning: ({ theme }) => ({
                color: (theme as Theme).palette.common.white,

                '.btn-loading': {
                    color: (theme as Theme).palette.warning.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.warning.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.warning.light, 0.4),
                    },
                },
            }),
            containedSuccess: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.success.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.success.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.success.light, 0.4),
                    },
                },
            }),
            containedInherit: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.grey[500],
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.grey[700], 0.6),
                    backgroundColor: alpha((theme as Theme).palette.grey[500], 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.grey[500], 0.4),
                    },
                },
            }),
            textError: ({ theme }) => ({
                borderColor: (theme as Theme).palette.error.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.error.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.error.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.error.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.error.light, 0.4),
                    },
                },
            }),
            textPrimary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.primary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.primary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.primary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.primary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.primary.light, 0.3),
                    },
                },
            }),
            textSecondary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.secondary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.secondary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.secondary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.secondary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.green.light, 0.3),
                    },
                },
            }),
            textInfo: ({ theme }) => ({
                borderColor: (theme as Theme).palette.info.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.info.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.info.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.info.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.info.light, 0.4),
                    },
                },
            }),
            textWarning: ({ theme }) => ({
                borderColor: (theme as Theme).palette.warning.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.warning.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.warning.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.warning.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.warning.light, 0.4),
                    },
                },
            }),
            textSuccess: ({ theme }) => ({
                borderColor: (theme as Theme).palette.success.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.success.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.success.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.success.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.success.light, 0.4),
                    },
                },
            }),
            textInherit: ({ theme }) => ({
                borderColor: (theme as Theme).palette.grey[700],

                '.btn-loading': {
                    color: (theme as Theme).palette.grey[500],
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.grey[700], 0.6),
                    borderColor: alpha((theme as Theme).palette.grey[700], 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.grey[500], 0.4),
                    },
                },
            }),
        },
    },
};
