import type { Components } from '@mui/material';
import { MuiAccordionTheme } from './MuiAccordion';
import { MuiAlertTheme } from './MuiAlert';
import { MuiAutocompleteTheme } from './MuiAutoComplete';
import { MuiBreadcrumbsTheme } from './MuiBreadcrumbs';
import { MuiButtonTheme } from './MuiButton';
import { MuiCheckboxTheme } from './MuiCheckbox';
import { MuiDataGridTheme } from './MuiDataGrid';
import { MuiTreeViewTheme } from './MuiTreeView';
import { MuiDialogTheme } from './MuiDialog';
import { MuiDividerTheme } from './MuiDivider';
import { MuiFieldTheme } from './MuiField';
import { MuiFormTheme } from './MuiForm';
import { MuiGridTheme } from './MuiGrid';
import { MuiPaginationTheme } from './MuiPagination';
import { MuiIconButtonTheme } from './MuiIconButton';
import { MuiListTheme } from './MuiList';
import { MuiMenuTheme } from './MuiMenu';
import { MuiPaperTheme } from './MuiPaper';
import { MuiRadioTheme } from './MuiRadio';
import { MuiRatingTheme } from './MuiRating';
import { MuiSelectTheme } from './MuiSelect';
import { MuiSliderTheme } from './MuiSlider';
import { MuiSvgIconTheme } from './MuiSvgIcon';
import { MuiSwitchTheme } from './MuiSwitch';
import { MuiTabTheme } from './MuiTab';
import { MuiTooltipTheme } from './MuiTooltip';
import { MuiChipTheme } from './MuiChip';
import { MuiStepperTheme } from './MuiStepper';

const ComponentsTheme: Components = {
    ...MuiAccordionTheme,
    ...MuiAlertTheme,
    ...MuiAutocompleteTheme,
    ...MuiBreadcrumbsTheme,
    ...MuiButtonTheme,
    ...MuiCheckboxTheme,
    ...MuiChipTheme,
    ...MuiDataGridTheme,
    ...MuiDialogTheme,
    ...MuiDividerTheme,
    ...MuiFieldTheme,
    ...MuiFormTheme,
    ...MuiGridTheme,
    ...MuiIconButtonTheme,
    ...MuiListTheme,
    ...MuiMenuTheme,
    ...MuiPaginationTheme,
    ...MuiPaperTheme,
    ...MuiRadioTheme,
    ...MuiRatingTheme,
    ...MuiSelectTheme,
    ...MuiSliderTheme,
    ...MuiStepperTheme,
    ...MuiSvgIconTheme,
    ...MuiSwitchTheme,
    ...MuiTabTheme,
    ...MuiTooltipTheme,
    ...MuiTreeViewTheme,
};

export default ComponentsTheme;
