import type { Components, Theme } from '@mui/material';

const themeConfig = {
    padding: 0,
    margin: '4px',
    overflow: 'visible',
    small: {
        width: 36,
        height: 20,
    },
    medium: {
        width: 44,
        height: 24,
    },
    thumb: {
        small: {
            width: 18,
            height: 18,
        },
        medium: {
            width: 22,
            height: 22,
        },
    },
};

export const MuiSwitchTheme: Components = {
    MuiSwitch: {
        styleOverrides: {
            root: ({ theme }) => ({
                width: themeConfig.medium.width,
                height: themeConfig.medium.height,
                padding: themeConfig.padding,
                margin: themeConfig.margin,
                '& .MuiSwitch-switchBase': {
                    padding: themeConfig.padding,
                    margin: 1,
                    transitionDuration: '300ms',
                    '&.Mui-checked': {
                        transform: 'translateX(16px)',
                        color: (theme as Theme).palette.common.white,
                        margin: 1,
                        marginLeft: '4px',
                        '& + .MuiSwitch-track': {
                            backgroundColor: (theme as Theme).palette.secondary.main,
                            opacity: 1,
                            border: 0,
                        },
                        '&.Mui-disabled + .MuiSwitch-track': {
                            opacity: 0.5,
                        },
                    },
                    '&.Mui-focusVisible .MuiSwitch-thumb': {
                        color: (theme as Theme).palette.secondary.main,
                        border: `6px solid ${(theme as Theme).palette.common.white}`,
                    },
                    '&.Mui-disabled .MuiSwitch-thumb': {
                        color: (theme as Theme).palette.grey[600],
                    },
                    '&.Mui-disabled + .MuiSwitch-track': {
                        opacity: 0.8,
                    },
                },
                '& .MuiSwitch-thumb': {
                    boxSizing: 'border-box',
                    width: 22,
                    height: 22,
                },
                '& .MuiSwitch-track': {
                    borderRadius: 24 / 2,
                    backgroundColor: (theme as Theme).palette.grey[200],
                    opacity: 1,
                    transition: (theme as Theme).transitions.create(['background-color'], {
                        duration: 500,
                    }),
                },
            }),
            sizeSmall: ({ theme }) => ({
                width: themeConfig.small.width,
                height: themeConfig.small.height,
                padding: themeConfig.padding,
                overflow: themeConfig.overflow,

                '& .MuiSwitch-switchBase': {
                    '&.Mui-checked': {
                        '& .MuiSwitch-thumb': {
                            marginLeft: '-3px',
                        },
                    },
                },
                '& .MuiSwitch-thumb': {
                    boxSizing: 'border-box',
                    width: themeConfig.thumb.small.width,
                    height: themeConfig.thumb.small.height,
                },
                '& .MuiSwitch-track': {
                    borderRadius: themeConfig.small.height / 2,
                    backgroundColor: (theme as Theme).palette.grey[200],
                    opacity: 1,
                    transition: (theme as Theme).transitions.create(['background-color'], {
                        duration: 500,
                    }),
                    height: themeConfig.small.height,
                },
            }),
        },
    },
};
