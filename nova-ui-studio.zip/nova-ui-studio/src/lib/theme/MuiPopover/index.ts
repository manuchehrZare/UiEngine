import type { Components, Theme } from '@mui/material';
import { generateClass } from '../../utils/methods/design';

export const MuiPopoverTheme: Components = {
    MuiPopover: {
        styleOverrides: {
            paper: ({ theme }) => ({
                boxShadow:
                    '0 12px 28px 0 var(--shadow-2),0 2px 4px 0 var(--shadow-1),inset 0 0 0 1px var(--shadow-inset)',
                padding: 0,
                [`.${generateClass('Select-MenuList')}`]: {
                    '.Mui-disabled': { opacity: 1, color: (theme as Theme).palette.grey[200] },
                },
            }),
        },
    },
};
