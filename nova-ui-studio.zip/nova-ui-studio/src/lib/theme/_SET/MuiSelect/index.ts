import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { KeyboardArrowDown } from '@mui/icons-material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiSelectTheme: Components = {
    MuiSelect: {
        defaultProps: {
            IconComponent: KeyboardArrowDown,
            classes: {
                icon: 'arrow-icon',
            },
            MenuProps: {
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left',
                },
            },
        },
        styleOverrides: {
            icon: ({ ownerState, theme }) => ({
                top: 'calc(50% - 0.393em)',
                right: 'calc(0% - 0.01em)',
                backgroundColor: (theme as Theme).palette.secondary.main,
                color: (theme as Theme).palette.common.white,
                width: `var(--field-height-${DesignTypeEnum.SET})`,
                height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 1px)`,
                borderTopRightRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,
                borderBottomRightRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,

                ...(ownerState?.readOnly && {
                    backgroundColor: (theme as Theme).palette.lightGrey[600],
                    color: (theme as Theme).palette.common.white,

                    ':hover': {
                        backgroundColor: (theme as Theme).palette.lightGrey[600],
                    },
                }),

                '&.Mui-disabled': {
                    backgroundColor: alpha((theme as Theme).palette.lightGrey.main, 0.5),
                    color: (theme as Theme).palette.common.white,
                },
            }),
            nativeInput: {
                height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,
            },
            select: ({ ownerState, theme }) => {
                return {
                    width: `calc(100% - var(--field-height-${DesignTypeEnum.SET}))`,
                    height: `var(--field-height-${DesignTypeEnum.SET})`,
                    padding: '0 25px 0 0 !important',
                    textIndent: '5px',
                    lineHeight: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,

                    ...((ownerState?.value as string) &&
                        !ownerState?.displayEmpty &&
                        !ownerState?.readOnly &&
                        !ownerState?.disabled && {
                            width: `calc(100% - (var(--field-height-${DesignTypeEnum.SET}) * 2))`,
                            paddingRight: `calc(var(--field-height-${DesignTypeEnum.SET}) * 2) !important`,
                        }),
                    '&.Mui-disabled': {
                        color: alpha((theme as Theme).palette.common.black, 0.6),
                    },
                };
            },
        },
    },
    MuiNativeSelect: {
        styleOverrides: {
            select: ({ theme }) => ({
                margin: '1px 1px 1px 5px !important',
                padding: '0 !important',
                option: {
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    ':disabled': {
                        color: alpha((theme as Theme).palette.common.black, 0.6),
                    },
                },
                'option:checked': {
                    background: alpha(((theme as Theme).palette.slateGreen as any)[200], 0.5),
                },
                '&.MuiInputBase-input': {
                    borderRadius: '0',
                },
                overflowY: 'auto',
            }),
        },
    },
};
