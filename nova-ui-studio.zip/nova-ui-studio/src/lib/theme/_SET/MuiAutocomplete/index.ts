import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { generateClass } from '../../../utils/methods/design';

export const MuiAutocompleteTheme: Components = {
    MuiAutocomplete: {
        styleOverrides: {
            root: () => ({
                '& .MuiInputBase-formControl': {
                    height: '100%',
                },
                [`& .${generateClass('selectedItems-summary')}`]: {
                    padding: 'inherit',
                    paddingRight: '0px',
                },
            }),
            option: {
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                minHeight: '30px !important',
            },
            noOptions: {
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            },
            input: {
                width: `calc(100% - (var(--field-height-${DesignTypeEnum.SET}) * 2)) !important`,
            },
            listbox: {
                maxHeight: '35vh',
            },
            inputRoot: ({ ownerState, theme }) => ({
                paddingRight: `calc((var(--field-height-${DesignTypeEnum.SET}) * 2) + 5px) !important`,
                ...(ownerState?.readOnly && {
                    backgroundColor: alpha((theme as Theme).palette.grey[100], 0.6),
                    border: `1px solid ${(theme as Theme).palette.lightGrey[600]} !important`,
                }),
            }),
            endAdornment: {
                top: 0,
                transform: 'none',

                '.MuiIconButton-root': {
                    marginRight: '-0.4px',
                    marginTop: '-0.4px',
                    minWidth: `var(--field-height-${DesignTypeEnum.SET})`,
                    width: `var(--field-height-${DesignTypeEnum.SET})`,
                    height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 1px)`,
                },
                '& .disablePopupIconRotate': {
                    transform: 'none',
                },
            },
            popupIndicator: ({ ownerState, theme }) => ({
                backgroundColor: (theme as Theme).palette.secondary.main,
                color: (theme as Theme).palette.common.white,
                borderRadius: 0,
                borderTopRightRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,
                borderBottomRightRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,

                ':hover': {
                    backgroundColor: (theme as Theme).palette.secondary.main,
                },

                ...(ownerState?.readOnly && {
                    backgroundColor: (theme as Theme).palette.lightGrey[600],
                    color: (theme as Theme).palette.common.white,

                    ':hover': {
                        backgroundColor: (theme as Theme).palette.lightGrey[600],
                    },
                }),

                '&.Mui-disabled': {
                    backgroundColor: alpha((theme as Theme).palette.lightGrey.main, 0.5),
                    color: (theme as Theme).palette.common.white,
                },
            }),
        },
    },
};
