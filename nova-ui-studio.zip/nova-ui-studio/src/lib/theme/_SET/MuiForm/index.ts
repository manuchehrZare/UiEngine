import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';
import { DesignTypeEnum } from '../../../utils/types/common';
import { importantStyle } from '../../../utils/methods/style';
import { constants } from '../../../utils/constants';
import { dataGridClasses } from '../../..';

export const MuiFormTheme: Components = {
    MuiFormControl: {
        styleOverrides: {
            root: {
                display: 'flex',
                alignItems: 'flex-start',
                flexDirection: 'row',
                justifyContent: 'flex-start',

                '&.upload-form-control': {
                    width: '100%',
                },

                [`&.top, &.${generateClass('Checkbox-formControl')}, &.${generateClass(
                    'Switch-formControl',
                )}, &.${generateClass('Radio-formControl')},&.${generateClass(
                    'RadioGroup-formControl',
                )}, &.upload-form-control, &.${generateClass('RangeInput')}`]: {
                    flexDirection: 'column',
                },
                '&.radio-group-labelPlacement-start': {
                    flexDirection: 'initial',
                    flexWrap: 'wrap',
                },
            },
        },
    },
    MuiFormGroup: {
        styleOverrides: {
            root: {
                [`.${generateClass('RadioGroup-formControl')}.label-active &`]: {
                    marginTop: 1.75,
                },
                [`.${generateClass('Radio-formControl')}`]: {
                    marginBottom: 4,
                },
            },
        },
    },
    MuiFormHelperText: {
        styleOverrides: {
            root: ({ theme, ownerState }) => ({
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 1px)`,
                color: alpha((theme as Theme).palette.common.black, 0.85),
                margin: '1px 0px',
                padding: '0 5px',

                [`&.${generateClass('HelperText')}`]: {
                    '&:not(.radio-group):not(.select):not(.switch):not(.checkbox):not(.range-input):not(.radio):not(.upload)':
                        {
                            paddingLeft: 17,
                            marginTop: -5,
                        },
                    '&.radio-group': {
                        marginTop: importantStyle('-4px'),
                        marginLeft: 0,
                        paddingLeft: 0,
                        flex: '0 0 100%',
                    },
                    '&.range-input': {
                        ...(ownerState.size === 'small' && {
                            fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 2px)`,
                        }),
                    },
                    '&.select': {
                        marginLeft: 0,
                        marginRight: 0,
                    },
                    '&.upload': {
                        paddingLeft: 5,
                        marginTop: 0,
                    },
                    '&.checkbox': {
                        [`&.${DesignTypeEnum.SET}`]: {
                            marginTop: importantStyle('0px'),

                            '&.small': {
                                paddingLeft: '4px',
                            },
                            '&.medium': {
                                paddingLeft: '7px',
                            },
                            '.checbox-labelPlacement-end &': {
                                textAlign: 'start',
                                paddingLeft: '10px',
                                marginTop: '-1px',
                                '&.small': {
                                    paddingLeft: '7px',
                                },
                            },
                            '.checbox-labelPlacement-top &': {
                                marginTop: 1,
                            },
                            '.checbox-labelPlacement-bottom &': {
                                marginTop: 4,
                            },
                            ...(ownerState.className?.split(' ')[4] && {
                                '.checbox-labelPlacement-end &': {
                                    textAlign: 'end',
                                    paddingRight: '4px',
                                },
                            }),
                        },
                    },
                    '&.radio': {
                        [`&.${DesignTypeEnum.SET}`]: {
                            marginTop: '-5px',
                            paddingLeft: '14px',

                            '&.small': {
                                paddingLeft: '10px',
                            },
                            '&.medium': {
                                paddingLeft: '14px',
                            },
                        },
                    },
                    '&.switch': {
                        marginTop: importantStyle('0px'),
                        marginRight: 0,
                        marginLeft: 0,
                        '.switch-labelPlacement-start &': {
                            marginLeft: 0,
                        },
                        '.switch-labelPlacement-end &': {
                            textAlign: 'end',
                            paddingLeft: '43px',
                            '&.small': {
                                paddingLeft: '37px',
                            },
                        },
                        '.switch-labelPlacement-top &, .switch-labelPlacement-bottom &': {
                            margin: 0,
                        },
                    },
                },
                '.checbox-labelPlacement-start &, .checbox-labelPlacement-top &, .checbox-labelPlacement-bottom &, .switch-labelPlacement-start &':
                    {
                        paddingLeft: 0,
                        marginLeft: 0,
                        '&.small, &.medium': {
                            paddingLeft: '0 !important',
                        },
                    },
                '.checbox-labelPlacement-top &, .checbox-labelPlacement-bottom &, .switch-labelPlacement-top &, .switch-labelPlacement-bottom &':
                    {
                        textAlign: 'center',
                    },
            }),
        },
    },
    MuiFormControlLabel: {
        styleOverrides: {
            root: ({ ownerState, theme }) => ({
                cursor: 'text',
                [`&.${generateClass('Checkbox-label')}, &.${generateClass('Radio-label')}`]: {
                    [`&.${DesignTypeEnum.SET}`]: {
                        marginLeft: ownerState.labelPlacement === 'start' ? '0px' : '-3px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        [`.${dataGridClasses.cell} &`]: {
                            marginLeft: '0px !important',
                            marginRight: '0px !important',
                        },
                        ...(ownerState.className?.split(' ')[2] && {
                            width: `${ownerState.className?.split(' ')[2]}px`,
                        }),
                        '.checbox-labelPlacement-start &, .checbox-labelPlacement-end &': {
                            alignItems: 'flex-start',
                        },
                    },
                },
                [`&.${generateClass('Radio-label')}`]: {
                    alignItems: 'flex-start',
                },
                [`&.${generateClass('Switch-label')}`]: {
                    '& > .MuiFormControlLabel-label': {
                        fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                        '.switch-labelPlacement-start &': {
                            marginRight: 7.5,
                        },
                        '.switch-labelPlacement-end &': {
                            marginLeft: 7.5,
                        },
                    },
                    '& .MuiSwitch-switchBase.Mui-disabled': {
                        color: alpha((theme as Theme).palette.common.black, 0.6),
                    },
                    '.switch-labelPlacement-start &, .switch-labelPlacement-end &': {
                        marginLeft: 0,
                        alignItems: 'flex-start',
                    },
                    '.switch-labelPlacement-top &, .switch-labelPlacement-bottom &': {
                        marginLeft: 0,
                        marginRight: 0,
                        '& .MuiSwitch-root': {
                            //marginTop: 1,
                        },
                    },
                },
                [`&.${generateClass('RangeInput-label')}`]: {
                    marginLeft: '0px',
                    width: '100%',
                    ...(ownerState.labelPlacement === 'top' && {
                        alignItems: 'flex-start',
                    }),
                    '& .MuiSlider-root': {
                        ...(ownerState.disabled && {
                            color: alpha((theme as Theme).palette.common.black, 0.6),
                        }),
                    },

                    '& > .MuiFormControlLabel-label': {
                        [`.${constants.classNames.labelEllipsis} &`]: {
                            maxWidth: '100%',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                        },
                        ...(ownerState.labelPlacement === 'start' && {
                            paddingRight: 5,
                            marginRight: 5,
                        }),
                        ...(ownerState.control.props.size === 'small' && {
                            fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 1px)`,
                        }),
                        ...(ownerState.control.props.size === 'medium' && {
                            fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                        }),
                    },
                },

                '.Mui-disabled': {
                    color: `${alpha((theme as Theme).palette.common.black, 0.6)} !important`,
                },
            }),
            label: ({ theme }) => ({
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                color: (theme as Theme).palette.common.black,
                lineHeight: `var(--field-height-${DesignTypeEnum.SET})`,
                letterSpacing: 0,
            }),
        },
    },
    MuiFormLabel: {
        styleOverrides: {
            root: ({ theme }) => ({
                cursor: 'text',
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                color: (theme as Theme).palette.common.black,

                [`&.${generateClass('RadioGroup-label')}`]: {
                    [`&.${constants.classNames.labelEllipsis}`]: {
                        maxWidth: '100%',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                    },

                    [`&.${DesignTypeEnum.SET}`]: {
                        marginTop: 1,
                        // lineHeight: 1,
                    },
                    '.radio-group-labelPlacement-start &': {
                        paddingRight: '8px',
                    },
                },
            }),
        },
    },
};
