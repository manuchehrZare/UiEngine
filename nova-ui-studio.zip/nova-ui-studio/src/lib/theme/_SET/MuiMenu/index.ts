import type { Components } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { menuClasses } from '../../..';

export const MuiMenuTheme: Components = {
    MuiMenu: {
        styleOverrides: {
            root: {
                '& .breadcrumbs-select': {
                    padding: '2px 10px 2px 10px !important',
                    fontSize: 'var(--field-label-font-size)',
                },
                '.MuiMenu-list': {
                    '.MuiMenuItem-root': { fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})` },
                },
            },
            list: {
                [`.${menuClasses.root}[aria-hidden] &`]: {
                    pointerEvents: 'none',
                },
            },
        },
    },
};
