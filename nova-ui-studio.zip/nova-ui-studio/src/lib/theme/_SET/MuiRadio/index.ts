import type { Components, Theme } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiRadioTheme: Components = {
    MuiRadio: {
        styleOverrides: {
            root: ({ ownerState, theme }) => {
                const color = ((theme as Theme).palette as any)[
                    ownerState?.color && ownerState.color !== 'default' ? ownerState.color : 'secondary'
                ].main;
                const size = ownerState.size === 'small' ? 16 : 20;
                return {
                    color: color,

                    [`&.${DesignTypeEnum.SET}`]: {
                        '.label-active &': {
                            padding: '1.5px 3.5px 3.5px 3.5px !important',
                        },
                        padding: '0.35px 3.5px !important',
                        '& + .MuiFormControlLabel-label': {
                            transform: 'translate(4px, 0px)',
                        },

                        '& span': {
                            [`&.icon-${DesignTypeEnum.SET}, &.checked-icon-${DesignTypeEnum.SET}`]: {
                                border: `1px solid ${(theme as Theme).palette.grey[600]}`,
                                borderRadius: '50%',
                                width: size,
                                height: size,
                            },

                            [`&.checked-icon-${DesignTypeEnum.SET}`]: {
                                borderColor: color,
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                '&:before': {
                                    display: 'block',
                                    borderRadius: '50%',
                                    width: size - 6,
                                    height: size - 6,
                                    backgroundColor: color,
                                    content: '""',
                                },
                            },
                        },

                        'input:disabled': {
                            [`& + span.icon-${DesignTypeEnum.SET}`]: {
                                borderColor: (theme as Theme).palette.grey[500],
                            },
                            [`& + span.checked-icon-${DesignTypeEnum.SET}`]: {
                                borderColor: (theme as Theme).palette.grey[500],

                                '&:before': {
                                    backgroundColor: (theme as Theme).palette.grey[400],
                                },
                            },
                        },
                    },
                };
            },
        },
    },
};
