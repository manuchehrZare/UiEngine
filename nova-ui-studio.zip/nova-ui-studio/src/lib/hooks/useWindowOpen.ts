import { useRef, useEffect, useCallback, useState, useMemo } from 'react';
import { sharedEventListener } from '..'; // A shared utility to add/remove global event listeners

// Enum to define types of communication processes between windows
export enum WindowOpenProcessTypeEnum {
    WindowClosed = 'windowClosed',
    WindowMessage = 'windowMessage',
    WindowReady = 'windowReady',
}

// The structure of data sent between windows
export type WindowOpenMessageType<TMessagePayload = any> = {
    payload?: TMessagePayload;
    processType: `${WindowOpenProcessTypeEnum}`;
};

// Optional features for the opened window (popup configuration)
export type WindowOpenFeatures = {
    /**
     * @default false
     */
    fullscreen?: boolean;
    height?: number;
    left?: number;
    /**
     * @default false
     */
    location?: boolean;
    /**
     * @default false
     */
    menubar?: boolean;
    /**
     * @default false
     */
    noopener?: boolean;
    /**
     * @default false
     */
    noreferrer?: boolean;
    /**
     * @default false
     */
    resizable?: boolean;
    screenX?: number;
    screenY?: number;
    /**
     * @default false
     */
    scrollbars?: boolean;
    /**
     * @default false
     */
    status?: boolean;
    /**
     * @default false
     */
    toolbar?: boolean;
    top?: number;
    width?: number;
};

// Enum for specifying target of the new window
export enum WindowOpenTargetEnum {
    Blank = '_blank',
    Parent = '_parent',
    Self = '_self',
    Top = '_top',
}

// Custom target type (either one of enum or a custom string)
export type WindowOpenTarget = `${WindowOpenTargetEnum}` | string;

export type UseWindowOpenBaseOptions = {
    /** Custom window features */
    features?: WindowOpenFeatures;
    /**
     * Callback triggered when window is closed
     * @returns void
     */
    onClose?: () => void;
    /**
     * Callback triggered when window opens
     * @returns void
     */
    onOpen?: () => void;
    /**
     * Custom can be used as window.name with the expressions.
     * * **Enum :** Custom string value can be valued with **WindowOpenTargetEnum**.
     */
    target?: WindowOpenTarget; // Where to open the window (e.g., _blank, _self)
    /**
     * Target origin for postMessage (security)
     */
    targetOrigin?: string;
    /**
     * URL to open
     */
    url: string;
};

export type WithExpectedMessageUseWindowOpenOptions<TReceivedData> = UseWindowOpenBaseOptions & {
    /**
     * Indicates that the opened window will communicate back using postMessage.
     *
     * When set to `true`:
     * - `onMessage` will be used to handle incoming messages from the opened window.
     * - `onWindowReady` will be called when the window sends a "ready" message.
     * - `sendMessage` and `isWindowReady` will be available in the returned API.
     *
     * This enables type-safe postMessage integration between the two windows.
     */
    expectMessage: true;
    /**
     * Called when a postMessage is received from the child window.
     * Callback triggered when message is received from the window
     */
    onMessage?: (
        data: WindowOpenMessageType<TReceivedData>,
        event: MessageEvent<WindowOpenMessageType<TReceivedData>>,
    ) => void;
    /**
     * Callback triggered when opened window signals it's ready
     * Called when the child window sends a "WindowReady" message.
     * @returns void
     */
    onWindowReady?: () => void;
};

export type WithoutExpectedMessageUseWindowOpenOptions = UseWindowOpenBaseOptions & {
    /**
     * Indicates that the opened window will not communicate back using postMessage.
     *
     * When set to `false`:
     * - `sendMessage`, `isWindowReady`, `onMessage`, and `onWindowReady` will NOT be available.
     * - The hook will behave as a simple window opener.
     */
    expectMessage: false;
};

// Options that the hook accepts as parameters
export type UseWindowOpenOptions<TReceivedData> =
    | WithExpectedMessageUseWindowOpenOptions<TReceivedData>
    | WithoutExpectedMessageUseWindowOpenOptions;

type WindowHookErrorType = 'WindowOpenError' | 'MessageSendError' | 'UnknownError';

export type WindowOpenError = {
    message: string;
    type: WindowHookErrorType;
};

type WindowOpenResultBase = {
    /**
     * Method to close the opened window
     */
    close: () => void;
    /**
     * Error if window failed to open
     */
    error: WindowOpenError | null;
    /**
     * Indicates window is opened
     */
    isOpen: boolean;
    /**
     * Method to open the window
     */
    open: () => void;
    /**
     * Reference to the opened window
     */
    windowRef: Window | null;
};

type MessageEnabledResult<TSentData> = WindowOpenResultBase & {
    /**
     * Indicates if the opened window is ready
     */
    isWindowReady: boolean;
    /**
     * Method to send data to the window
     */
    sendMessage: (data: TSentData) => void;
};

type MessageDisabledResult = WindowOpenResultBase;

// Returned API from the hook
export type UseWindowOpenResult<TSentData, ExpectMessage extends boolean> = ExpectMessage extends true
    ? MessageEnabledResult<TSentData>
    : MessageDisabledResult;

// Utility to convert window features object into a string
const serializeFeatures = (features?: WindowOpenFeatures): string => {
    if (!features) return '';
    return Object.entries(features)
        .map(([key, value]) => `${key}=${typeof value === 'boolean' ? Number(value) : value}`)
        .join(',');
};

// This custom React Hook uses **TypeScript generics** to provide full type safety
// for both the data you **send to** the opened window and the data you **receive from** it.
//
// - `TSentData` represents the **type of data** that will be sent from the parent window
//    to the child window using `postMessage`.
// - `TReceivedData` represents the **type of data** expected to be received
//    from the child window using `message` event.
const useWindowOpen = <TSentData = any, TReceivedData = any, ExpectMessage extends boolean = true>(
    options: UseWindowOpenOptions<TReceivedData>,
): UseWindowOpenResult<TSentData, ExpectMessage> => {
    const { url, target, features, onOpen, onClose } = options;
    const [isWindowReady, setIsWindowReady] = useState(false); // Tracks if child window is ready
    const [isOpen, setOpen] = useState(false);
    const [error, setError] = useState<WindowOpenError | null>(null); // Holds any error that occurs
    const windowRef = useRef<Window | null>(null); // Holds reference to the opened window

    // Memoize derivedOrigin to avoid recalculations on each render
    const derivedOrigin = useMemo(() => {
        try {
            return new URL(url, window.location.origin).origin;
        } catch {
            return undefined;
        }
    }, [url]);

    // Function to get the target origin for postMessage
    const getTargetOrigin = useCallback(() => {
        return 'targetOrigin' in options ? (options.targetOrigin ?? derivedOrigin ?? '*') : (derivedOrigin ?? '*');
    }, [options, derivedOrigin]);

    const handleError = (type: WindowHookErrorType, message: string) => {
        const errObj: WindowOpenError = { type, message };
        setError(errObj);
        // eslint-disable-next-line no-console
        console.error(`[${type}]`, message);
    };

    // Opens a new window
    const open = useCallback(() => {
        try {
            // If the window is already open and not closed, just focus it
            if (windowRef.current && !windowRef.current.closed) {
                windowRef.current.focus();
                return;
            }

            // Convert features to string format
            const featureStr = serializeFeatures(features);

            // Try to open a new popup window
            const newWindow = window.open(url, target, featureStr);

            if (!newWindow) {
                // If popup is blocked
                handleError('WindowOpenError', 'Popup blocked or failed to open window.');
                return;
            }

            windowRef.current = newWindow; // Store reference
            !isOpen && setOpen(true);
            error !== null && setError(null);
            isWindowReady && setIsWindowReady(false);
            onOpen?.(); // Trigger onOpen callback
        } catch (e: any) {
            handleError('UnknownError', e?.message || 'Unknown error while opening window');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [url, target, features, onOpen]);

    // Closes the opened window
    const close = useCallback(() => {
        if (!windowRef.current) return;
        if (windowRef.current && !windowRef.current.closed) {
            windowRef.current.close(); // Attempt to close the window
        }
        windowRef.current = null;
        isWindowReady && setIsWindowReady(false);
        isOpen && setOpen(false);
        error !== null && setError(null);
        onClose?.(); // Trigger onClose callback
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [onClose]);

    // Sends a message to the child window using postMessage
    const sendMessage = useCallback(
        (data: TSentData) => {
            if (!('expectMessage' in options) || !options.expectMessage) return;
            if (!windowRef.current) return;
            const targetWin = windowRef.current;
            if (!targetWin || targetWin.closed) {
                handleError('MessageSendError', 'Cannot send message, window is closed or not available.');
                return;
            }

            try {
                targetWin.postMessage(data, getTargetOrigin());
            } catch (e: any) {
                handleError('MessageSendError', e?.message || 'Failed to send postMessage.');
            }
        },
        [options, getTargetOrigin],
    );

    const handleMessage = (event: MessageEvent<WindowOpenMessageType<TReceivedData>>) => {
        if (!('expectMessage' in options) || !options?.expectMessage) return;
        // Ignore if message is not from our window or origin
        if (event.origin !== getTargetOrigin() || event.source !== windowRef.current) return;
        if (!event.data?.processType) return;

        // If window signals it's ready
        if (event.data.processType === WindowOpenProcessTypeEnum.WindowReady) {
            !isWindowReady && setIsWindowReady(true);
            options.onWindowReady?.();
        } else if (event.data.processType === WindowOpenProcessTypeEnum.WindowClosed) {
            options.onMessage?.(event.data, event);
            close();
        } else {
            options.onMessage?.(event.data, event);
        }
    };

    // Set up message event listener
    useEffect(() => {
        // Use shared listener utility
        !(!('expectMessage' in options) || !options?.expectMessage) &&
            sharedEventListener.add(window, 'message', handleMessage);
        return () => {
            !(!('expectMessage' in options) || !options?.expectMessage) &&
                sharedEventListener.remove(window, 'message', handleMessage);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [options, getTargetOrigin, close]);

    useEffect(() => {
        let interval: NodeJS.Timeout | null = null;
        if (isOpen) {
            // Just make polling until Window is ready
            interval = setInterval(() => {
                if (!windowRef.current) {
                    interval && clearInterval(interval);
                    return;
                }
                try {
                    if (windowRef.current.closed) {
                        close();
                        interval && clearInterval(interval);
                    }
                    // eslint-disable-next-line
                } catch (err) {
                    interval && clearInterval(interval);
                }
            }, 500);
        } else {
            interval && clearInterval(interval);
        }
        return () => {
            interval && clearInterval(interval);
        };
    }, [close, isOpen]);

    const baseReturn: WindowOpenResultBase = {
        open,
        close,
        isOpen,
        windowRef: windowRef.current,
        error,
    };

    if ('expectMessage' in options && options.expectMessage) {
        return {
            ...baseReturn,
            isWindowReady,
            sendMessage,
        } as UseWindowOpenResult<TSentData, ExpectMessage>;
    }

    return baseReturn as UseWindowOpenResult<TSentData, ExpectMessage>;
};

export default useWindowOpen;
