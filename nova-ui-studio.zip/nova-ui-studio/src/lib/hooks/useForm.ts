import type {
    Control,
    DefaultValues,
    FieldErrors,
    FieldValues,
    Path,
    PathValue,
    UseFormClearErrors,
    UseFormGetValues,
    UseFormProps,
    UseFormReset,
    UseFormResetField,
    UseFormReturn as UseHookFormReturn,
} from 'react-hook-form';
import { useForm as useHookForm } from 'react-hook-form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { sleep } from '../utils';
import { isEmpty, isNaN, isNull, isString, isUndefined } from 'lodash';

export interface IUseFormProps<TFields>
    extends Pick<UseFormProps, 'mode' | 'reValidateMode' | 'criteriaMode' | 'delayError'> {
    defaultValues: TFields;
    validationSchema?: any;
}

interface IUseForm<TFields extends FieldValues = FieldValues>
    extends Pick<
        UseHookFormReturn<TFields>,
        | 'control'
        | 'handleSubmit'
        | 'resetField'
        | 'setValue'
        | 'watch'
        | 'getValues'
        | 'clearErrors'
        | 'reset'
        | 'setFocus'
        | 'trigger'
        | 'formState'
    > {
    setFieldError: (fieldName: Path<TFields>, errorMsg: string) => void;
}

export type UseFormReturnType<T extends FieldValues = FieldValues> = IUseForm<T>;
export type { Control, DefaultValues, FieldErrors, FieldValues, Path, PathValue, UseFormClearErrors, UseFormGetValues };

const useForm = <TFields extends FieldValues = FieldValues>({
    validationSchema,
    defaultValues,
    mode,
    reValidateMode,
    criteriaMode,
    delayError,
}: IUseFormProps<TFields>): UseFormReturnType<TFields> => {
    const {
        clearErrors,
        control,
        formState,
        getValues,
        handleSubmit,
        reset: resetForm,
        resetField: resetFieldForm,
        setError,
        setFocus,
        setValue,
        trigger,
        watch,
    }: UseHookFormReturn<TFields> = useHookForm<TFields>({
        defaultValues: defaultValues as DefaultValues<TFields>,
        ...(validationSchema && {
            resolver: yupResolver(
                yup.object().shape(
                    validationSchema,
                    Object.keys(defaultValues).flatMap((v, i) =>
                        Object.keys(defaultValues)
                            .slice(i + 1)
                            .map((w) => [v, w]),
                    ) as [string, string][],
                ),
            ),
        }),
        reValidateMode: reValidateMode || 'onChange',
        criteriaMode: criteriaMode || 'all',
        mode: mode || 'all',
        resetOptions: {
            keepDefaultValues: true,
        },
        delayError,
    });

    const setFieldError = (fieldName: Path<TFields>, errorMsg: string) => {
        setError(fieldName, {
            type: 'manual',
            message: errorMsg,
        });
    };

    const reset: UseFormReset<TFields> = (values, keepStateOptions) => {
        resetForm(values, { ...control._options.resetOptions, ...keepStateOptions });
        // * For some components, an error message appeared during the reset. For this reason, the second reset was executed.
        sleep(0).then(() => {
            if (!isEmpty(control._formState.errors)) {
                resetForm(values, { ...control._options.resetOptions, ...keepStateOptions });
            }
        });
    };

    const resetField: UseFormResetField<TFields> = (name, options) => {
        const defaultValue = (control._defaultValues as any)[name];
        resetFieldForm(name, options);

        (isNull(defaultValue) || isNaN(defaultValue) || (isString(defaultValue) && defaultValue.length === 0)) &&
            // * For some components, an error message appeared during the reset. For this reason, the second reset was executed. // Ex: NumberInput Component
            sleep(0).then(() => {
                if (!isUndefined((control._formState.errors as any)[name])) {
                    resetFieldForm(name, options);
                }
            });
    };

    return {
        control,
        formState,
        handleSubmit,
        setValue,
        resetField,
        getValues,
        clearErrors,
        reset,
        setFocus,
        trigger,
        setFieldError,
        watch,
    };
};

export default useForm;
