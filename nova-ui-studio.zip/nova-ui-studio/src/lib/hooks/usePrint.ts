import type { MutableRefObject } from 'react';
import { useRef } from 'react';
import type { IReactToPrintProps } from 'react-to-print';
import { useReactToPrint } from 'react-to-print';

export interface IUsePrintProps
    extends Omit<
        IReactToPrintProps,
        'removeAfterPrint' | 'nonce' | 'fonts' | 'suppressErrors' | 'trigger' | 'content'
    > {}

export type UsePrintReturnType = { handlePrint: () => void; ref: MutableRefObject<null> };

const usePrint = (props?: IUsePrintProps): UsePrintReturnType => {
    const ref = useRef(null);

    const handlePrint = useReactToPrint({
        removeAfterPrint: true,
        content: () => {
            return ref?.current;
        },
        ...props,
    });

    return { ref, handlePrint };
};

export default usePrint;
