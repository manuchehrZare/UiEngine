import * as yup from 'yup';
import { eq, isString, isUndefined } from 'lodash';
import { i18n, locale } from '../../locales';
import type { IStringOptions, ComporeMessageOptions } from '../type';
import { ValidationsCompareTypeEnum } from '../type';
import { getVerb } from '../_helper/method';
import type { FieldValues } from '../../../hooks/useForm';

export const stringValidation = <T extends FieldValues = FieldValues>(
    fieldLabel: string,
    options?: IStringOptions<T>,
    // eslint-disable-next-line
) => {
    const verb = options?.selectable
        ? i18n.t(locale.validations.common.verb.choosing)
        : i18n.t(locale.validations.common.verb.entry);

    const displayName = options?.selectable
        ? getVerb({ fieldLabel, verb })
        : options?.maxLength || options?.minLength || options?.length
          ? i18n.t(locale.validations.length.char)
          : '';

    const init = yup.string().typeError(
        options?.messageFormatter?.typeError
            ? options.messageFormatter?.typeError({ fieldLabel })
            : i18n.t(locale.validations.common.typeError, {
                  ...getVerb({ fieldLabel, verb }),
              }),
    );

    let yupMethod = options?.required
        ? init.required(
              options?.messageFormatter?.required
                  ? options.messageFormatter?.required({ fieldLabel })
                  : i18n.t(locale.validations.common.required, {
                        ...getVerb({ fieldLabel, verb, labelCapitalize: true }),
                    }),
          )
        : init;

    if (options?.length) {
        yupMethod = yupMethod.test({
            test: function (val) {
                if (val && options?.length && val.length !== options?.length) {
                    return this.createError({
                        message: options.messageFormatter?.length
                            ? options.messageFormatter?.length({ length: options.length, fieldLabel })
                            : i18n.t(locale.validations.length.length, {
                                  value: options?.length,
                                  displayName,
                                  verb,
                              }),
                    });
                }
                return true;
            },
        });
    }

    if (options?.minLength) {
        yupMethod = yupMethod.test({
            test: function (val) {
                if (val && options?.minLength && val.length < options?.minLength) {
                    return this.createError({
                        message: options.messageFormatter?.minLength
                            ? options.messageFormatter?.minLength({ minLength: options.minLength, fieldLabel })
                            : i18n.t(locale.validations.length.minLength, {
                                  value: options?.minLength,
                                  displayName,
                                  verb,
                              }),
                    });
                }
                return true;
            },
        });
    }

    if (options?.maxLength) {
        yupMethod = yupMethod.max(
            options?.maxLength,
            options.messageFormatter?.maxLength
                ? options.messageFormatter?.maxLength({ maxLength: options.maxLength, fieldLabel })
                : i18n.t(locale.validations.length.maxLength, { value: options?.maxLength, displayName, verb }),
        );
    }

    if (options?.regexp) {
        yupMethod = yupMethod.matches(options?.regexp, {
            message: options.messageFormatter?.regexp
                ? options.messageFormatter?.regexp(options?.regexp as any)
                : i18n.t(locale.validations.common.matches, {
                      ...getVerb({ fieldLabel, verb }),
                  }),
            excludeEmptyString: true,
        });
    }

    if (options?.compare?.length) {
        options?.compare.forEach((compareItem) => {
            /**
             * @param context for getting field name (label) that is compared
             * @description this method return field label value for validation
             */
            const getMessageValue = (context: yup.TestContext): string =>
                (compareItem.fieldLabel &&
                    getVerb({ fieldLabel: compareItem?.fieldLabel, verb, labelCapitalize: true }).field) ||
                compareItem?.valueFormatter?.(context?.parent[`${compareItem?.fieldName}`]) ||
                context.parent[`${compareItem?.fieldName}`];
            if (compareItem?.type === ValidationsCompareTypeEnum.Equal) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        const messageValue = i18n.t(locale.validations.compare.equal, {
                            value: getMessageValue(context),
                        });
                        const messageFormatterParams = {
                            fieldLabel,
                            compareName: compareItem?.fieldName,
                            compareValue: context.parent[`${compareItem?.fieldName}`],
                            type: compareItem.type,
                            value,
                        };
                        if (
                            (isUndefined(compareItem?.when) ||
                                compareItem?.when?.({
                                    value,
                                    compareValue: context.parent[`${compareItem?.fieldName}`],
                                    formValues: context?.parent,
                                })) &&
                            !eq(value, context.parent[`${compareItem?.fieldName}`]) &&
                            context.parent[`${compareItem?.fieldName}`] &&
                            value
                        )
                            return this.createError({
                                message: options.messageFormatter?.compare?.({})?.eq
                                    ? isString(options.messageFormatter?.compare({})?.eq)
                                        ? (options?.messageFormatter?.compare({
                                              ...messageFormatterParams,
                                          })?.eq as string)
                                        : (
                                              options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.eq as ComporeMessageOptions<T>[]
                                          ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                          messageValue
                                    : messageValue,
                            });
                        return true;
                    },
                });
            }
            if (compareItem?.type === ValidationsCompareTypeEnum.NotEqual) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        const messageValue = i18n.t(locale.validations.compare.notEqual, {
                            value: getMessageValue(context),
                        });
                        const messageFormatterParams = {
                            fieldLabel,
                            compareName: compareItem?.fieldName,
                            compareValue: context.parent[`${compareItem?.fieldName}`],
                            type: compareItem.type,
                            value,
                        };
                        if (
                            (isUndefined(compareItem.when) ||
                                compareItem?.when?.({
                                    value,
                                    compareValue: context.parent[`${compareItem?.fieldName}`],
                                    formValues: context?.parent,
                                })) &&
                            eq(value, context.parent[`${compareItem?.fieldName}`]) &&
                            context.parent[`${compareItem?.fieldName}`] &&
                            value
                        )
                            return this.createError({
                                message: options?.messageFormatter?.compare?.({})?.neq
                                    ? isString(options.messageFormatter?.compare({})?.neq)
                                        ? (options?.messageFormatter?.compare({
                                              ...messageFormatterParams,
                                          })?.neq as string)
                                        : (
                                              options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.neq as ComporeMessageOptions<T>[]
                                          ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                          messageValue
                                    : messageValue,
                            });
                        return true;
                    },
                });
            }
        });
    }

    return yupMethod;
};
