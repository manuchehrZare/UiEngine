import { capitalize, eq, isString, isUndefined } from 'lodash';
import * as yup from 'yup';
import { i18n, locale } from '../../locales';
import type { IBooleanOptions, ComporeMessageOptions } from '../type';
import { ValidationsCompareTypeEnum } from '../type';
import { getJustVerbForBoolValidation, getVerb } from '../_helper/method';
import type { FieldValues } from '../../../hooks/useForm';

export const booleanValidation = <T extends FieldValues = FieldValues>(
    fieldLabel: string,
    options?: IBooleanOptions<T>,
    // eslint-disable-next-line
) => {
    const verb = options?.selectable
        ? i18n.t(locale.validations.common.verb.choosing)
        : capitalize(i18n.t(locale.validations.common.verb.choosing));

    const init = yup.bool().typeError(
        options?.messageFormatter?.typeError
            ? options.messageFormatter?.typeError({ fieldLabel })
            : i18n.t(locale.validations.common.typeError, {
                  ...getVerb({ fieldLabel, verb }),
              }),
    );

    const requiredMessage = (field: string): any => {
        return options?.messageFormatter?.required
            ? options.messageFormatter?.required({ fieldLabel: field })
            : options?.selectable
              ? i18n.t(locale.validations.common.required, {
                    ...getVerb({ fieldLabel, verb, labelCapitalize: true }),
                })
              : getJustVerbForBoolValidation({ verb });
    };

    let yupMethod = options?.required ? init.oneOf([true], requiredMessage(fieldLabel)) : init;

    if (options?.compare?.length) {
        options?.compare.forEach((compareItem) => {
            /**
             * @param context for getting field name (label) that is compared
             * @description this method return field label value for validation
             */
            const getMessageValue = (context: yup.TestContext): string =>
                (compareItem?.fieldLabel &&
                    getVerb({ fieldLabel: compareItem?.fieldLabel, verb, labelCapitalize: true }).field) ||
                compareItem?.valueFormatter?.(context?.parent[`${compareItem?.fieldName}`]) ||
                context.parent[`${compareItem?.fieldName}`];

            if (compareItem?.type === ValidationsCompareTypeEnum.Equal) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        const messageValue = i18n.t(locale.validations.compare.equal, {
                            value: getMessageValue(context),
                        });
                        const messageFormatterParams = {
                            fieldLabel,
                            compareName: compareItem?.fieldName,
                            compareValue: context.parent[`${compareItem?.fieldName}`],
                            type: compareItem.type,
                            value,
                        };
                        if (
                            (isUndefined(compareItem.when) ||
                                compareItem.when?.({
                                    value,
                                    compareValue: context.parent[`${compareItem?.fieldName}`],
                                    formValues: context?.parent,
                                })) &&
                            !eq(value, context.parent[`${compareItem?.fieldName}`])
                        )
                            return this.createError({
                                message: options.messageFormatter?.compare?.({})?.eq
                                    ? isString(options.messageFormatter?.compare({})?.eq)
                                        ? (options?.messageFormatter?.compare({
                                              ...messageFormatterParams,
                                          })?.eq as string)
                                        : (
                                              options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.eq as ComporeMessageOptions<T>[]
                                          ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                          messageValue
                                    : messageValue,
                            });
                        return true;
                    },
                });
            }

            if (compareItem?.type === ValidationsCompareTypeEnum.NotEqual) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        const messageValue = i18n.t(locale.validations.compare.notEqual, {
                            value: getMessageValue(context),
                        });
                        const messageFormatterParams = {
                            fieldLabel,
                            compareName: compareItem?.fieldName,
                            compareValue: context.parent[`${compareItem?.fieldName}`],
                            type: compareItem.type,
                            value,
                        };
                        if (
                            (isUndefined(compareItem.when) ||
                                compareItem.when?.({
                                    value,
                                    compareValue: context.parent[`${compareItem?.fieldName}`],
                                    formValues: context?.parent,
                                })) &&
                            eq(value, context.parent[`${compareItem?.fieldName}`])
                        )
                            return this.createError({
                                message: options.messageFormatter?.compare?.({})?.neq
                                    ? isString(options.messageFormatter?.compare({})?.neq)
                                        ? (options?.messageFormatter?.compare({
                                              ...messageFormatterParams,
                                          })?.neq as string)
                                        : (
                                              options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.neq as ComporeMessageOptions<T>[]
                                          ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                          messageValue
                                    : messageValue,
                            });
                        return true;
                    },
                });
            }
        });
    }

    return yupMethod;
};
