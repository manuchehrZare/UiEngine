import { groupString } from '../groupString';

export const iban = (value: string, options?: { formatted?: boolean }): string => {
    if (options?.formatted) return groupString(value, 4) as string;
    return value.replace(/\s/g, '');
};
