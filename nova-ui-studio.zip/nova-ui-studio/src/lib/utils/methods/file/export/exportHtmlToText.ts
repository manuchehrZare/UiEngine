import jsPDF from 'jspdf';
import pretty from 'pretty';
import { FileExtentionsEnum } from '../type';

interface IExportHTMLToTextProps {
    data: string;
    fileName: string;
    fontSize?: number;
    marginBottom?: number;
    marginLeft?: number;
    marginRight?: number;
    marginTop?: number;
}

export const exportHtmlToText = ({
    data,
    fileName,
    marginLeft = 40,
    marginRight = 40,
    marginTop = 50,
    marginBottom = 70,
    fontSize = 10,
}: IExportHTMLToTextProps): void => {
    const paddingYValue = marginTop;
    const doc = new jsPDF('p', 'px', 'a4', true);
    const pageHeight = doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.width;
    const lineHeight = fontSize * 1.5;
    const splitText = doc.splitTextToSize(pretty(data), pageWidth - marginRight * 1.5, { fontSize: fontSize });
    doc.setFontSize(fontSize);
    doc.setFont('SourceSansPro-Regular', 'normal');
    for (let i = 0; i < splitText.length; i++) {
        if (marginTop + marginBottom > pageHeight) {
            doc.addPage();
            marginTop = paddingYValue;
        }
        doc.text(splitText[i], marginLeft, marginTop);
        marginTop = lineHeight + marginTop;
    }
    doc.save(`${fileName}.${FileExtentionsEnum.PDF}`);
};
