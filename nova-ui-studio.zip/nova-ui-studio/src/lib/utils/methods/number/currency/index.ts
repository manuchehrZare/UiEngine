import { omit } from 'lodash';
import type { INumberFormatOptions } from '..';
import { numberFormat } from '..';

export const currency = (
    number: string | number,
    options?: Omit<INumberFormatOptions, 'suffix' | 'prefix'> & { currency?: string },
): string => {
    return numberFormat(number, {
        maximumFractionDigits: 2,
        minimumFractionDigits: 2,
        thousandSeparator: '.',
        decimalSeparator: ',',
        ...(options?.currency && { suffix: ` ${options?.currency}` }),
        ...omit(options, ['currency']),
    });
};
