export { currency } from './currency';
export { numberFormat } from './numberFormat';
export { randomNumber } from './randomNumber';

export const isNumeric = (value: string): boolean => /^\d+$/.test(value);

/**
 * TYPES
 */
export type { INumberFormatOptions } from './numberFormat';
