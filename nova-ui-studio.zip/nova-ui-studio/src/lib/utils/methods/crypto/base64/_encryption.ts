import { encode } from 'iconv-lite';
import { isString } from 'lodash';

interface IStringEncryption {
    encoding?: string;
    onLoadingChange?: (isLoading: boolean) => void;
}
interface IFileEncryption {
    onFileLoad?: (onSuccess?: FileConversionResult | null, onError?: DOMException) => void;
    onLoadingChange?: (isLoading: boolean) => void;
}

type FileConversionResult = {
    b64Content: string;
    dataUrl: string;
    filename: string;
    lastModified: number;
    size: number;
    type: string;
    webkitRelativePath: string;
};

type StringConversionResult = {
    base64: string;
    buffer: Buffer;
};

const fileToBase64 = (file: File): Promise<{ error: DOMException | null; success: ArrayBuffer | string | null }> => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    return new Promise((resolve, reject) => {
        reader.onloadend = () => {
            if (reader.error) {
                reject({ error: reader.error, success: null });
            } else {
                resolve({ error: null, success: reader.result });
            }
        };
        reader.onerror = () => reject({ error: reader.error, success: null });
    });
};

const convertFiles = async (
    files: FileList | File[],
    callBack?: (onSuccess?: FileConversionResult | null, onError?: DOMException) => void,
): Promise<FileConversionResult[]> => {
    const convertedFiles: FileConversionResult[] = [];
    for (const file of files) {
        const converted = await fileToBase64(file);
        if (converted?.error) {
            callBack?.(null, converted?.error);
            break;
        }
        const fileAfterConversion: FileConversionResult = {
            b64Content: (converted.success as string).split(',')[1],
            dataUrl: converted.success as string,
            filename: file.name,
            type: file.type,
            size: file.size,
            lastModified: file.lastModified,
            webkitRelativePath: file.webkitRelativePath,
        };
        convertedFiles.push(fileAfterConversion);
        callBack?.(fileAfterConversion);
    }
    return convertedFiles;
};

const convertString = (data: string, encoding: string = 'UTF-8'): StringConversionResult => {
    const buffer = encode(JSON.stringify(data), encoding);
    return {
        buffer: buffer,
        base64: buffer.toString('base64'),
    };
};

/**
 * Returns decoded base64 data of a string or Promise of converted FileList base64 content with file properties.
 * @param data Data to be converted to base64. When typeof data is FileList or File[] the function need to use with async await because of the ():Promise<any> => () return type.
 * @param options Configuration options for the encryption process:
 * @param options.encoding (For string data only) Charset of base64 data. It could be one of the ISO family or windows, UTF etc. Default is UTF-8. https://encoding.spec.whatwg.org/
 * @param options.onLoadingChange (Optional) Loading state change callback function.
 * @param options.onFileLoad (For FileList data only) Callback function that fires when each file is loaded.
 * @returns Promise<any> Object with keys buffer and base64 depends of given data type.
 */
export function base64Encryption(data: string, options?: IStringEncryption): StringConversionResult;
export function base64Encryption(data: FileList | File[], options?: IFileEncryption): Promise<FileConversionResult[]>;
export function base64Encryption(
    data: string | FileList | File[],
    options?: IStringEncryption | IFileEncryption,
): Promise<FileConversionResult[]> | StringConversionResult {
    if (!isString(data)) {
        options?.onLoadingChange?.(true);
        const result = convertFiles(data, (options as IFileEncryption)?.onFileLoad);
        result.finally(() => options?.onLoadingChange?.(false));
        return result;
    }
    options?.onLoadingChange?.(true);
    const result = convertString(data, (options as IStringEncryption)?.encoding);
    options?.onLoadingChange?.(false);
    return result;
}
