export enum PrinterTypeEnum {
    html = 'html',
    pdf = 'pdf',
    json = 'json',
    rawHtml = 'raw-html',
    image = 'image',
}
