type SharedListenerEventMapFor<T> = T extends Window
    ? WindowEventMap
    : T extends Document
      ? DocumentEventMap
      : T extends HTMLElement
        ? HTMLElementEventMap
        : T extends MediaQueryList
          ? { change: MediaQueryListEvent }
          : Record<string, Event>;

type SharedListenerEventType<T> = Extract<keyof SharedListenerEventMapFor<T>, string>;

type SharedListenerTypedEventCallback<T, K extends SharedListenerEventType<T>> = (
    event: SharedListenerEventMapFor<T>[K],
) => void;

interface SharedListenerOptions {
    capture?: boolean;
    once?: boolean;
    passive?: boolean;
}

type SharedListenerRecord = {
    handler: EventListener;
    options?: SharedListenerOptions;
};

class SharedEventListener {
    private listeners = new WeakMap<EventTarget, Map<string, Set<SharedListenerRecord>>>();

    public add<T extends EventTarget, K extends SharedListenerEventType<T>>(
        source: T,
        event: K,
        callback: SharedListenerTypedEventCallback<T, K>,
        options?: SharedListenerOptions,
    ) {
        let eventMap = this.listeners.get(source);
        if (!eventMap) {
            eventMap = new Map();
            this.listeners.set(source, eventMap);
        }

        let records = eventMap.get(event);
        if (!records) {
            records = new Set();
            eventMap.set(event, records);
        }

        const alreadyExists = [...records].some((r) => r.handler === callback);
        if (!alreadyExists) {
            const record: SharedListenerRecord = {
                handler: callback as EventListener,
                options,
            };
            source.addEventListener(event, callback as EventListener, options);
            records.add(record);
        }
    }

    public remove<T extends EventTarget, K extends SharedListenerEventType<T>>(
        source: T,
        event: K,
        callback: SharedListenerTypedEventCallback<T, K>,
    ) {
        const eventMap = this.listeners.get(source);
        const records = eventMap?.get(event);

        if (records) {
            for (const record of records) {
                if (record.handler === callback) {
                    source.removeEventListener(event, record.handler, record.options);
                    records.delete(record);
                }
            }

            if (records.size === 0) {
                eventMap?.delete(event);
            }
        }

        if (eventMap?.size === 0) {
            this.listeners.delete(source);
        }
    }
}

export const sharedEventListener = new SharedEventListener();
