export default {
    common: {
        verb: {
            entry: 'Enter',
            choosing: 'Choose',
            mustBe: 'Must be',
        },
        required: '{{verb}} {{field}}.',
        matches: '{{verb}} a valid {{field}}.',
        typeError: '{{verb}} a valid {{field}}.',
        min: '{{verb}} at minimum {{value}}.',
        max: '{{verb}} at maximum {{value}}',
        length: '{{verb}} {{value}}',
    },
    length: {
        char: 'characters',
        length: '$t(validations:common.length, { "value": "{{value}} {{displayName}}" })',
        minLength: '$t(validations:common.min, { "value": "{{value}} {{displayName}}" })',
        maxLength: '$t(validations:common.max, { "value": "{{value}} {{displayName}}" })',
    },
    compare: {
        greaterThan: '$t(validations:common.verb.mustBe) greater than {{value}}.',
        lessThan: '$t(validations:common.verb.mustBe) less than {{value}}.',
        equal: '$t(validations:common.verb.mustBe) equal to {{value}}.',
        notEqual: '$t(validations:common.verb.mustBe) different from {{value}}',
        greaterThanOrEqual: '$t(validations:common.verb.mustBe) greater than or equal {{value}}.',
        lessThanOrEqual: '$t(validations:common.verb.mustBe) less than or equal {{value}}.',
    },
    range: {
        message: '{{field}} range $t(validations:common.verb.mustBe) more than {{value}}.',
    },
    iban: {
        iban: '{{country}} {{field}} $t(validations:common.verb.mustBe) {{value}} $t(validations:length.char).',
    },
    file: {
        accept: 'File $t(validations:common.verb.mustBe) {{accept}}.',
        max: '$t(validations:common.verb.choosing) {{max}} file maximum.',
        min: '$t(validations:common.verb.choosing) {{min}} file minimum.',
        maxFileSize: 'Maksimum file size $t(validations:common.verb.mustBe) {{maxFileSize}}{{type}}.',
    },
};
