export default {
    common: {
        verb: {
            entry: 'giriniz.',
            choosing: 'seçiniz.',
            mustBe: 'olmalıdır.',
        },
        required: '{{field}} {{verb}}',
        matches: 'Geçerli bir {{field}} {{verb}}',
        typeError: 'Geçerli bir {{field}} {{verb}}',
        min: 'Minimum {{value}} {{verb}}',
        max: 'Maksimum {{value}} {{verb}}',
        length: '{{value}} {{verb}}',
    },
    length: {
        char: 'karakter',
        length: '$t(validations:common.length, { "value": "{{value}} {{displayName}}" })',
        minLength: '$t(validations:common.min, { "value": "{{value}} {{displayName}}" })',
        maxLength: '$t(validations:common.max, { "value": "{{value}} {{displayName}}" })',
    },
    compare: {
        greaterThan: '{{value}} değerinden büyük $t(validations:common.verb.mustBe)',
        lessThan: '{{value}} değerinden küçük $t(validations:common.verb.mustBe)',
        equal: '{{value}} değeri ile eşit $t(validations:common.verb.mustBe)',
        notEqual: '{{value}} değerinden farklı $t(validations:common.verb.mustBe)',
        greaterThanOrEqual: '{{value}} değerinden büyük veya eşit $t(validations:common.verb.mustBe)',
        lessThanOrEqual: '{{value}} değerinden küçük veya eşit $t(validations:common.verb.mustBe)',
    },
    range: {
        message: '{{field}} aralığı en fazla {{value}} $t(validations:common.verb.mustBe)',
    },
    iban: {
        iban: '{{country}} {{field}} {{value}} $t(validations:length.char) $t(validations:common.verb.mustBe)',
    },
    file: {
        accept: 'Dosya {{accept}} $t(validations:common.verb.mustBe)',
        max: 'Maksimum {{max}} dosya $t(validations:common.verb.choosing)',
        min: 'Minimum {{min}} dosya $t(validations:common.verb.choosing)',
        maxFileSize: 'Dosya büyüklüğü maksimum {{maxFileSize}} {{type}} $t(validations:common.verb.mustBe)',
    },
};
