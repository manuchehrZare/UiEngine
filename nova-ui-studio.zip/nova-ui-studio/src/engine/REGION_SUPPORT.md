# Region Support in UI Engine

The UI engine now supports `JCSRegion` components, which allow you to define reusable sub-pages or components that can be referenced from other pages.

## Overview

Regions are defined in the `ui-definition.json` file with `Type: "region"` and can be embedded into pages using the `JCSRegion` component class.

## How It Works

### 1. Define a Region

In your `ui-definition.json`, create a region definition:

```json
{
  "Name": "MY_CUSTOM_REGION",
  "EbmlName": "MY_CUSTOM_REGION.ebml",
  "ModuleName": "common",
  "Type": "region",
  "ScreenCode": "REG001",
  "MenuName": "Custom Region",
  "EbmlContent": {
    "Interface": {
      "Structure": {
        "Bean": {
          "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSPanel",
          "Id": "RegionRoot",
          "Style": { "P": [] },
          "SubBean": [
            // Your region components here
          ]
        }
      }
    }
  }
}
```

### 2. Reference a Region

In any page, use `JCSRegion` with the `regionName` property:

```json
{
  "Name": "MY_PAGE",
  "Type": "page",
  "EbmlContent": {
    "Interface": {
      "Structure": {
        "Bean": {
          "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSPage",
          "SubBean": [
            {
              "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSRegion",
              "Id": "Page.myRegion",
              "Style": {
                "P": [
                  {
                    "Name": "regionName",
                    "Text": "MY_CUSTOM_REGION"
                  },
                  {
                    "Name": "bounds",
                    "Text": "10,10,200,100"
                  }
                ]
              },
              "SubBean": []
            }
          ]
        }
      }
    }
  }
}
```

## Implementation Details

### Component Type

Added `REGION` to the `EbmlComponentClass` enum:

```typescript
export enum EbmlComponentClass {
    // Container components
    PAGE = 'tr.com.cs.aurora.ebml.bean.swing.JCSPage',
    PANEL = 'tr.com.cs.aurora.ebml.bean.swing.JCSPanel',
    REGION = 'tr.com.cs.aurora.ebml.bean.swing.JCSRegion',  // <-- New
    // ...
}
```

### Component Mapper

The component mapper now handles regions:

```typescript
case 'Region':
    const regionName = properties.regionName;

    // Find the region definition in allPages
    const regionDef = findRegionByName(regionName, allPages);

    if (!regionDef) {
        // Show error if region not found
        return <Box>[Region not found: {regionName}]</Box>;
    }

    // Parse and render the region's content
    const regionBean = regionDef.EbmlContent.Interface.Structure.Bean;
    const parsedRegion = parseBean(regionBean);

    // Render region children
    return <Box>{/* render children */}</Box>;
```

### Region Lookup

The `findRegionByName` function searches for regions:

```typescript
const findRegionByName = (regionName: string, allPages: PageDefinition[]): PageDefinition | null => {
    return allPages.find(page => page.Type === 'region' && page.Name === regionName) || null;
};
```

### Updated Components

All components now accept and pass the `allPages` parameter:

- **PageRenderer**: Accepts `allPages` prop and passes it to `mapComponent`
- **AdminPanel**: Passes `pages` array to `PageRenderer`
- **mapComponent**: Accepts `allPages` parameter for region lookup

## Usage Example

```tsx
import { PageRenderer, usePageDefinitions } from './engine';

function MyComponent() {
    const { pages } = usePageDefinitions();
    const myPage = pages.find(p => p.Name === 'MY_PAGE');

    return (
        <PageRenderer
            pageDefinition={myPage}
            useAbsolutePositioning={true}
            allPages={pages}  // Required for region support
        />
    );
}
```

## Error Handling

The engine provides helpful error messages when regions fail:

1. **Region name not specified**:
   - Shows: `[Region: No name specified]`
   - Border: Orange dashed border

2. **Region not found**:
   - Shows: `[Region not found: REGION_NAME]`
   - Border: Red dashed border

3. **Region parsing error**:
   - Shows: `[Region error: REGION_NAME]`
   - Border: Red dashed border
   - Error logged to console

## Benefits

1. **Code Reusability**: Define common UI elements once, use them everywhere
2. **Consistency**: Ensure consistent UI across multiple pages
3. **Maintainability**: Update a region in one place, changes reflect everywhere
4. **Modularity**: Break complex pages into smaller, manageable components

## Example Use Cases

- **Header/Footer**: Common page headers or footers
- **Navigation Menus**: Reusable navigation components
- **Form Sections**: Standard form sections used across multiple pages
- **Toolbars**: Common toolbar layouts
- **Info Panels**: Reusable information display panels

## Notes

- Regions can contain any EBML components, including other regions (nested regions)
- Regions are positioned using the same `bounds` property as other components
- Regions inherit the absolute/relative positioning mode from their parent page
- All pages (including regions) are loaded once and cached by `usePageDefinitions` hook
