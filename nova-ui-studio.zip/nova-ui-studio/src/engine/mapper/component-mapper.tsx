/* eslint-disable */
/**
 * Component Mapper
 * Maps EBML components to React components using the component registry
 */

import React from 'react';
import type { ParsedComponent, PageDefinition, ComponentBounds } from '../types/ebml.types';
import { getComponentRenderer, UnknownComponent } from '../components/registry';
import type { BaseComponentProps } from '../components/registry/types';

/**
 * Map EBML component to React component using the component registry
 */
export const mapComponent = (
    component: ParsedComponent,
    key: string,
    useAbsolutePositioning: boolean = false,
    allPages: PageDefinition[] = [],
    parentBounds?: ComponentBounds,
): React.ReactNode => {
    const { type } = component;

    // Get the component renderer from the registry
    const renderer = getComponentRenderer(type);

    // Prepare props for the component
    const componentProps: BaseComponentProps = {
        component,
        componentKey: key,
        useAbsolutePositioning,
        allPages,
        parentBounds,
    };

    // If renderer exists in registry, use it
    if (renderer) {
        return renderer(componentProps);
    }

    // Fallback to UnknownComponent for unregistered types
    return <UnknownComponent {...componentProps} />;
};
