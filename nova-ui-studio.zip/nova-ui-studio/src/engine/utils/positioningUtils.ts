/* eslint-disable */
/**
 * Positioning Utilities
 * Handles conversion of Windows Forms bounds to web CSS positioning
 */

import type { ComponentBounds } from '../types/ebml.types';
import type { SxProps, Theme } from '@mui/material';

/**
 * Convert bounds to absolute positioning CSS styles
 * Used when useAbsolutePositioning = true
 */
export const boundsToAbsoluteStyle = (
    bounds: ComponentBounds,
    parentBounds?: ComponentBounds
): SxProps<Theme> => {
    // If parent bounds provided, calculate relative position
    const left = parentBounds ? bounds.x - parentBounds.x : bounds.x;
    const top = parentBounds ? bounds.y - parentBounds.y : bounds.y;

    return {
        position: 'absolute',
        left: `${left}px`,
        top: `${top}px`,
        width: `${bounds.width}px`,
        height: `${bounds.height}px`,
        boxSizing: 'border-box',
    };
};

/**
 * Convert bounds width to responsive grid columns
 * Used when useAbsolutePositioning = false (responsive mode)
 */
export const boundsToGridSize = (
    bounds: ComponentBounds,
    containerWidth: number = 960
): { xs: number; minHeight: number } => {
    const ratio = bounds.width / containerWidth;
    const columns = Math.round(ratio * 12);

    return {
        xs: Math.max(1, Math.min(12, columns)),
        minHeight: bounds.height,
    };
};

/**
 * Get container style for absolute positioning mode
 * Containers need position: relative to contain absolutely positioned children
 */
export const getContainerStyle = (
    bounds: ComponentBounds,
    useAbsolutePositioning: boolean
): SxProps<Theme> => {
    if (useAbsolutePositioning) {
        return {
            position: 'relative',
            width: `${bounds.width}px`,
            height: `${bounds.height}px`,
            minHeight: `${bounds.height}px`,
            overflow: 'visible',
        };
    }

    // Responsive mode - use full width
    return {
        width: '100%',
        minHeight: bounds.height > 0 ? `${bounds.height}px` : 'auto',
    };
};

/**
 * Get component style based on positioning mode
 * Main entry point for component styling
 */
export const getComponentStyle = (
    bounds: ComponentBounds,
    useAbsolutePositioning: boolean,
    parentBounds?: ComponentBounds,
    additionalStyles?: SxProps<Theme>
): SxProps<Theme> => {
    const baseStyle = useAbsolutePositioning
        ? boundsToAbsoluteStyle(bounds, parentBounds)
        : {};

    return {
        ...baseStyle,
        ...additionalStyles,
    } as SxProps<Theme>;
};

/**
 * Calculate the bounding box that contains all children
 * Useful for determining container dimensions
 */
export const calculateBoundingBox = (
    children: Array<{ bounds: ComponentBounds }>
): ComponentBounds => {
    if (!children || children.length === 0) {
        return { x: 0, y: 0, width: 0, height: 0 };
    }

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    children.forEach(child => {
        const { x, y, width, height } = child.bounds;
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x + width);
        maxY = Math.max(maxY, y + height);
    });

    return {
        x: minX,
        y: minY,
        width: maxX - minX,
        height: maxY - minY,
    };
};

/**
 * Normalize children positions relative to container
 * Converts absolute screen coordinates to relative container coordinates
 */
export const normalizeChildrenBounds = (
    children: Array<{ bounds: ComponentBounds }>,
    containerBounds: ComponentBounds
): void => {
    children.forEach(child => {
        child.bounds = {
            x: child.bounds.x - containerBounds.x,
            y: child.bounds.y - containerBounds.y,
            width: child.bounds.width,
            height: child.bounds.height,
        };
    });
};

/**
 * Sort components by visual position (top-to-bottom, left-to-right)
 * Used for tab order and accessibility
 */
export const sortByVisualPosition = <T extends { bounds: ComponentBounds }>(
    components: T[],
    rowTolerance: number = 10
): T[] => {
    return [...components].sort((a, b) => {
        // Group by row (Y position with tolerance)
        if (Math.abs(a.bounds.y - b.bounds.y) > rowTolerance) {
            return a.bounds.y - b.bounds.y;
        }
        // Within same row, sort by X position
        return a.bounds.x - b.bounds.x;
    });
};

/**
 * Group components into rows based on Y position
 * Used for responsive layout rendering
 */
export const groupComponentsByRow = <T extends { bounds: ComponentBounds }>(
    components: T[],
    rowTolerance: number = 10
): T[][] => {
    const sorted = sortByVisualPosition(components, rowTolerance);
    const rows: T[][] = [];
    let currentRow: T[] = [];
    let currentY: number | null = null;

    sorted.forEach(component => {
        if (currentY === null || Math.abs(component.bounds.y - currentY) <= rowTolerance) {
            currentRow.push(component);
            if (currentY === null) currentY = component.bounds.y;
        } else {
            if (currentRow.length > 0) {
                rows.push(currentRow);
            }
            currentRow = [component];
            currentY = component.bounds.y;
        }
    });

    if (currentRow.length > 0) {
        rows.push(currentRow);
    }

    return rows;
};

export default {
    boundsToAbsoluteStyle,
    boundsToGridSize,
    getContainerStyle,
    getComponentStyle,
    calculateBoundingBox,
    normalizeChildrenBounds,
    sortByVisualPosition,
    groupComponentsByRow,
};
