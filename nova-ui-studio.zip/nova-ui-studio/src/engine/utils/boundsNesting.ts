/* eslint-disable */
/**
 * Bounds Nesting Utilities
 * Functions to build component hierarchy based on coordinate containment
 */

import type { ParsedComponent } from '../types/ebml.types';

/**
 * Check if child bounds are completely inside parent bounds
 */
export const isInsideBounds = (child: ParsedComponent, parent: ParsedComponent): boolean => {
    const c = child.bounds;
    const p = parent.bounds;

    // Child must be completely contained within parent
    return (
        c.x >= p.x &&
        c.y >= p.y &&
        c.x + c.width <= p.x + p.width &&
        c.y + c.height <= p.y + p.height
    );
};

/**
 * Calculate the area of a component's bounds
 */
const getBoundsArea = (component: ParsedComponent): number => {
    return component.bounds.width * component.bounds.height;
};

/**
 * Build a hierarchical tree of components based on bounds containment
 * Components whose bounds are inside another component become children of that component
 */
export const buildComponentTree = (components: ParsedComponent[]): ParsedComponent[] => {
    if (!components || components.length === 0) {
        return [];
    }

    // Create a copy of components to avoid mutating original
    const workingComponents = components.map(comp => ({
        ...comp,
        children: comp.children ? [...comp.children] : [],
    }));

    // Sort by area descending - larger containers come first
    workingComponents.sort((a, b) => getBoundsArea(b) - getBoundsArea(a));

    // Track which components have been assigned as children
    const assigned = new Set<string>();

    // For each component, find its best parent (smallest container that contains it)
    const componentToParent = new Map<string, string>();

    for (let i = 0; i < workingComponents.length; i++) {
        const child = workingComponents[i];
        const childKey = getComponentKey(child);

        if (assigned.has(childKey)) continue;

        let bestParent: ParsedComponent | null = null;
        let bestParentArea = Infinity;

        // Look for the smallest container that contains this component
        for (let j = 0; j < workingComponents.length; j++) {
            if (i === j) continue;

            const potentialParent = workingComponents[j];
            const parentKey = getComponentKey(potentialParent);

            // Skip if potential parent is already a child of this component
            if (componentToParent.get(parentKey) === childKey) continue;

            // Check if child is inside potential parent
            if (isInsideBounds(child, potentialParent)) {
                const parentArea = getBoundsArea(potentialParent);

                // Find the smallest container
                if (parentArea < bestParentArea) {
                    bestParent = potentialParent;
                    bestParentArea = parentArea;
                }
            }
        }

        if (bestParent) {
            componentToParent.set(childKey, getComponentKey(bestParent));
            assigned.add(childKey);
        }
    }

    // Now build the tree by assigning children to parents
    const rootComponents: ParsedComponent[] = [];
    const componentMap = new Map<string, ParsedComponent>();

    // First pass: create component map
    workingComponents.forEach(comp => {
        componentMap.set(getComponentKey(comp), {
            ...comp,
            children: comp.children ? [...comp.children] : [],
        });
    });

    // Second pass: assign children to parents
    workingComponents.forEach(comp => {
        const compKey = getComponentKey(comp);
        const parentKey = componentToParent.get(compKey);

        if (parentKey) {
            const parent = componentMap.get(parentKey);
            const child = componentMap.get(compKey);

            if (parent && child) {
                // Add child to parent's children array
                if (!parent.children) {
                    parent.children = [];
                }
                // Check if not already a child (from original structure)
                const alreadyChild = parent.children.some(
                    c => getComponentKey(c) === compKey
                );
                if (!alreadyChild) {
                    parent.children.push(child);
                }
            }
        } else {
            // No parent - this is a root component
            const rootComp = componentMap.get(compKey);
            if (rootComp) {
                rootComponents.push(rootComp);
            }
        }
    });

    // Sort root components by Y then X for consistent rendering
    rootComponents.sort((a, b) => {
        if (Math.abs(a.bounds.y - b.bounds.y) > 10) {
            return a.bounds.y - b.bounds.y;
        }
        return a.bounds.x - b.bounds.x;
    });

    // Sort children of each component by Y then X
    const sortChildren = (comp: ParsedComponent) => {
        if (comp.children && comp.children.length > 0) {
            comp.children.sort((a, b) => {
                if (Math.abs(a.bounds.y - b.bounds.y) > 5) {
                    return a.bounds.y - b.bounds.y;
                }
                return a.bounds.x - b.bounds.x;
            });
            comp.children.forEach(sortChildren);
        }
    };

    rootComponents.forEach(sortChildren);

    return rootComponents;
};

/**
 * Get a unique key for a component
 */
const getComponentKey = (component: ParsedComponent): string => {
    return component.id || `${component.type}-${component.bounds.x}-${component.bounds.y}-${component.bounds.width}-${component.bounds.height}`;
};

/**
 * Flatten all components including nested children into a single array
 * Used when we need to rebuild the hierarchy from scratch
 */
export const flattenComponents = (components: ParsedComponent[]): ParsedComponent[] => {
    const result: ParsedComponent[] = [];

    const flatten = (comps: ParsedComponent[]) => {
        comps.forEach(comp => {
            // Add the component without its children
            result.push({
                ...comp,
                children: [],
            });

            // Recursively flatten children
            if (comp.children && comp.children.length > 0) {
                flatten(comp.children);
            }
        });
    };

    flatten(components);
    return result;
};

/**
 * Build component tree from a flat list, nesting based on bounds
 * This is the main function to use for converting EBML structure to proper nesting
 */
export const buildNestedTree = (components: ParsedComponent[]): ParsedComponent[] => {
    // First flatten everything to remove existing hierarchy
    const flattened = flattenComponents(components);

    // Then rebuild based on bounds containment
    return buildComponentTree(flattened);
};
