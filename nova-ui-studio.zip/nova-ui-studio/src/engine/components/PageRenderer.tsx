/* eslint-disable */
/**
 * Page Renderer Component
 * Renders a page from EBML definition
 */

import type { FC } from 'react';
import { useMemo } from 'react';
import type { PageDefinition } from '../types/ebml.types';
import { parseBeanWithNesting } from '../parser/ebml-parser';
import { mapComponent } from '../mapper/component-mapper';
import { Box, Paper, Alert } from '../../lib';

export interface PageRendererProps {
    pageDefinition: PageDefinition;
    useAbsolutePositioning?: boolean;
    allPages?: PageDefinition[];
}

const PageRenderer: FC<PageRendererProps> = ({ pageDefinition, useAbsolutePositioning = true, allPages = [] }) => {
    const renderedContent = useMemo(() => {
        try {
            // Parse the EBML structure
            const rootBean = pageDefinition.EbmlContent.Interface.Structure.Bean;
            const parsedComponent = parseBeanWithNesting(rootBean);

            // Map to React components, passing allPages for region lookup
            return mapComponent(parsedComponent, 'root', useAbsolutePositioning, allPages);
        } catch (error) {
            console.error('Error rendering page:', error);
            return (
                <Alert
                    type="error"
                    text={`Failed to render page: ${error instanceof Error ? error.message : 'Unknown error'}`}
                    sx={{ m: 2 }}
                />
            );
        }
    }, [pageDefinition, useAbsolutePositioning, allPages]);

    return (
        <Box
            sx={{
                width: '100%',
                height: '100%',
                overflow: 'auto',
            }}
        >
            <Paper
                sx={{
                    m: 2,
                    p: 2,
                    minHeight: 'calc(100vh - 120px)',
                    boxShadow: 1,
                }}
            >
                {renderedContent}
            </Paper>
        </Box>
    );
};

export default PageRenderer;
