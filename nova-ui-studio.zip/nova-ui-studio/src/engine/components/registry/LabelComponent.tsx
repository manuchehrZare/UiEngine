/* eslint-disable */
/**
 * Label Component
 * Renders EBML Label components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Label, GridItem } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const LabelComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    const labelContent = (
        <Label
            text={properties.text || ''}
            sx={{
                display: 'block',
                width: '100%',
                height: '100%',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                lineHeight: useAbsolutePositioning ? `${bounds.height}px` : 'normal',
            }}
        />
    );

    if (useAbsolutePositioning) {
        return labelContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {labelContent}
        </GridItem>
    );
};
