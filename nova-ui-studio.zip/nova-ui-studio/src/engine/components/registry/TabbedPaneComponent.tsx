/* eslint-disable */
/**
 * TabbedPane Component
 * Renders EBML TabbedPane components with Material-UI Tabs
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { GridItem, Grid, Box, Paper } from '../../../lib';
import { Tabs, Tab } from '@mui/material';
import type { BaseComponentProps } from './types';
import type { ParsedComponent } from '../../types/ebml.types';
import { groupComponentsByRow } from '../../utils/positioningUtils';

/**
 * Render children with absolute positioning
 * Child bounds are already relative to tab content area, so use them directly
 */
const renderAbsoluteLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[],
    tabIndex: number
) => {
    return children.map((child, index) => {
        // Child bounds are already relative to tab content
        const { x, y, width, height } = child.bounds;

        console.log(`  Tab ${tabIndex} child ${child.type} (${child.id}):`, {
            bounds: { x, y, width, height }
        });

        return (
            <Box
                key={`${componentKey}-tab-${tabIndex}-abs-${index}`}
                sx={{
                    position: 'absolute',
                    left: `${x}px`,
                    top: `${y}px`,
                    width: `${width}px`,
                    height: `${height}px`,
                }}
            >
                {mapComponent(child, `${componentKey}-tab-${tabIndex}-${index}`, true, allPages)}
            </Box>
        );
    });
};

export const TabbedPaneComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages = []
}) => {
    const { children, bounds } = component;
    const [value, setValue] = React.useState(0);

    // Import mapComponent dynamically to avoid circular dependency
    const { mapComponent } = require('../../mapper/component-mapper');

    const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
        setValue(newValue);
    };

    const childArray = children || [];

    // Calculate tab content height (total height minus tabs header)
    const tabHeaderHeight = 48;
    const contentHeight = bounds.height - tabHeaderHeight;

    if (useAbsolutePositioning) {
        // Absolute positioning mode
        return (
            <Paper
                sx={{
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    boxSizing: 'border-box',
                }}
            >
                <Tabs
                    value={value}
                    onChange={handleChange}
                    variant="scrollable"
                    scrollButtons="auto"
                    sx={{ borderBottom: 1, borderColor: 'divider', minHeight: tabHeaderHeight }}
                >
                    {childArray.map((child, index) => {
                        const tabLabel = child.properties?.tabTitle || child.properties?.title || `Tab ${index + 1}`;
                        return <Tab key={index} label={tabLabel} />;
                    })}
                </Tabs>
                {childArray.map((child, index) => (
                    <Box
                        key={index}
                        hidden={value !== index}
                        sx={{
                            position: 'relative',
                            width: '100%',
                            height: `${contentHeight}px`,
                            overflow: 'auto',
                        }}
                    >
                        {child.children && child.children.length > 0 && (
                            renderAbsoluteLayout(child.children, componentKey, mapComponent, allPages, index)
                        )}
                    </Box>
                ))}
            </Paper>
        );
    }

    // Responsive grid mode
    return (
        <GridItem xs={12} sx={{ display: 'flex', flexDirection: 'column' }}>
            <Paper sx={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
                <Tabs
                    value={value}
                    onChange={handleChange}
                    variant="scrollable"
                    scrollButtons="auto"
                    sx={{ borderBottom: 1, borderColor: 'divider' }}
                >
                    {childArray.map((child, index) => {
                        const tabLabel = child.properties?.tabTitle || child.properties?.title || `Tab ${index + 1}`;
                        return <Tab key={index} label={tabLabel} />;
                    })}
                </Tabs>
                {childArray.map((child, index) => (
                    <Box key={index} hidden={value !== index} sx={{ p: { xs: 1, sm: 2 }, width: '100%', flex: 1 }}>
                        {child.children && child.children.length > 0 ? (
                            <Grid container spacing={{ xs: 1, sm: 1.5, md: 2 }}>
                                {groupComponentsByRow(child.children).map((row, rowIndex) =>
                                    row.map((rowChild, colIndex) =>
                                        mapComponent(
                                            rowChild,
                                            `${componentKey}-tab-${index}-${rowIndex}-${colIndex}`,
                                            useAbsolutePositioning,
                                            allPages
                                        ),
                                    ),
                                )}
                            </Grid>
                        ) : null}
                    </Box>
                ))}
            </Paper>
        </GridItem>
    );
};
