/* eslint-disable */
/**
 * Checkbox Component
 * Renders EBML CheckBox components as Checkbox
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Checkbox, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const CheckboxComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the checkbox control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.value === 'true' || properties.selected === 'true' || false,
        },
    });

    const checkboxContent = (
        <Checkbox
            name={component.id || 'field'}
            control={control}
            label={properties.label || properties.text}
            disabled={properties.enabled === 'false'}
        />
    );

    if (useAbsolutePositioning) {
        return checkboxContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {checkboxContent}
        </GridItem>
    );
};
