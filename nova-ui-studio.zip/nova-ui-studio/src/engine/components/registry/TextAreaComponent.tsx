/* eslint-disable */
/**
 * TextArea Component
 * Renders EBML TextArea/TextPane components with multiline input
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Input, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const TextAreaComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;
    const gridSize = boundsToGridSize(bounds, containerWidth);

    // Create a form instance for the input control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.text || properties.value || '',
        },
    });

    const textAreaContent = (
        <Input
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            placeholder={properties.placeholder || properties.text}
            disabled={properties.enabled === 'false'}
            fullWidth
            multiline
            rows={useAbsolutePositioning ? undefined : Math.max(3, Math.floor(gridSize.minHeight / 25))}
            sx={{
                height: '100%',
                '& .MuiInputBase-root': {
                    height: useAbsolutePositioning ? '100%' : 'auto',
                },
                '& textarea': {
                    height: useAbsolutePositioning ? '100% !important' : 'auto',
                },
            }}
        />
    );

    if (useAbsolutePositioning) {
        return textAreaContent;
    }

    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {textAreaContent}
        </GridItem>
    );
};
