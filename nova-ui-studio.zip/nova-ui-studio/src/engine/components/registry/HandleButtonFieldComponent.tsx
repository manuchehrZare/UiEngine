/* eslint-disable */
/**
 * HandleButtonField Component
 * Renders EBML HandleButtonField - Text field with button
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { GridItem, Input, useForm, Box } from '../../../lib';
import { FormControl, InputLabel, IconButton } from '@mui/material';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

// Helper to parse color from EBML format (R,G,B)
const parseColor = (colorStr?: string): string => {
    if (!colorStr) return 'rgb(255, 255, 255)';
    const parts = colorStr.split(',').map(p => parseInt(p.trim()));
    if (parts.length === 3) {
        return `rgb(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }
    return colorStr;
};

// Helper to parse boolean from string
const parseBoolean = (value?: string): boolean => {
    if (!value) return true;
    return value.toLowerCase() !== 'false';
};

export const HandleButtonFieldComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;
    const gridSize = boundsToGridSize(bounds, containerWidth);
    const bgColor = parseColor(properties.background || '255,255,255');
    const fieldId = component.id?.split('.').pop() || 'handlefield';
    const label = properties.label || properties.fieldLabel || '';

    // Create a form instance for the input control
    const { control } = useForm({
        defaultValues: {
            [fieldId]: properties.text || properties.value || '',
        },
    });

    const handleButtonContent = (
        <FormControl fullWidth variant="standard" sx={{ m: 0 }}>
            {label && <InputLabel htmlFor={fieldId}>{label}</InputLabel>}
            <Box
                sx={{
                    display: 'flex',
                    gap: 0.5,
                    alignItems: 'flex-end',
                    height: useAbsolutePositioning ? '100%' : 'auto',
                }}
            >
                <Input
                    name={fieldId}
                    control={control}
                    placeholder={properties.placeholder}
                    disabled={properties.enabled === 'false'}
                    sx={{
                        flex: 1,
                        backgroundColor: bgColor,
                        minHeight: useAbsolutePositioning ? '100%' : gridSize.minHeight || 'auto',
                        px: 1,
                    }}
                />
                {parseBoolean(properties.buttonVisible) && (
                    <IconButton size="small" sx={{ border: '1px solid #ccc', mb: 0.5 }}>
                        ...
                    </IconButton>
                )}
            </Box>
        </FormControl>
    );

    if (useAbsolutePositioning) {
        return handleButtonContent;
    }

    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {handleButtonContent}
        </GridItem>
    );
};
