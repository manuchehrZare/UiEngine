/* eslint-disable */
/**
 * RadioGroup Component
 * Renders EBML ButtonGroup components as RadioGroup container
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { GridItem, RadioGroup, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import type { ParsedComponent } from '../../types/ebml.types';
import { boundsToGridSize } from '../../utils/positioningUtils';

// Helper to parse color from EBML format (R,G,B)
const parseColor = (colorStr?: string): string => {
    if (!colorStr) return 'transparent';
    const parts = colorStr.split(',').map(p => parseInt(p.trim()));
    if (parts.length === 3) {
        return `rgb(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }
    return colorStr;
};

export const RadioGroupComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages,
    parentBounds
}) => {
    const { properties, bounds, children } = component;
    const containerWidth = parentBounds?.width || 960;
    const bgColor = parseColor(properties.background || '236,233,216');

    // Create a form instance for the radio group control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'radioGroup']: properties.value || properties.selectedValue || '',
        },
    });

    // Import mapComponent dynamically to avoid circular dependency
    const { mapComponent } = require('../../mapper/component-mapper');

    const radioGroupContent = (
        <RadioGroup
            name={component.id || 'radioGroup'}
            control={control}
            helperText={properties.helperText}
            labelPlacement="top"
            label={properties.title || properties.label}
            row={properties.orientation !== 'vertical'}
            sx={{
                backgroundColor: bgColor,
                p: 1,
                height: useAbsolutePositioning ? '100%' : 'auto',
            }}
        >
            {children?.map((child: ParsedComponent, index: number) =>
                mapComponent(child, `${componentKey}-radio-${index}`, useAbsolutePositioning, allPages)
            )}
        </RadioGroup>
    );

    if (useAbsolutePositioning) {
        return radioGroupContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {radioGroupContent}
        </GridItem>
    );
};
