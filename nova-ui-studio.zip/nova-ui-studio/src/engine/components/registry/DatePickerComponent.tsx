/* eslint-disable */
/**
 * DatePicker Component
 * Renders EBML DateField components as DatePicker
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { DatePicker, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const DatePickerComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the datepicker control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.value || properties.date || null,
        },
    });

    const datePickerContent = (
        <DatePicker
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            disabled={properties.enabled === 'false'}
            fullWidth
        />
    );

    if (useAbsolutePositioning) {
        return datePickerContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {datePickerContent}
        </GridItem>
    );
};
