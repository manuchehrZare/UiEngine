/* eslint-disable */
/**
 * TimePicker Component
 * Renders EBML TimeField components as TimePicker
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { TimePicker, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const TimePickerComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the timepicker control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.value || properties.time || null,
        },
    });

    const timePickerContent = (
        <TimePicker
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            disabled={properties.enabled === 'false'}
            fullWidth
        />
    );

    if (useAbsolutePositioning) {
        return timePickerContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {timePickerContent}
        </GridItem>
    );
};
