/* eslint-disable */
/**
 * Page Component
 * Renders EBML Page components (root container)
 * Supports both absolute positioning (Windows Forms matching) and responsive grid layout
 */

import React from 'react';
import { Box, Grid, GridItem, Paper } from '../../../lib';
import type { BaseComponentProps } from './types';
import type { ParsedComponent } from '../../types/ebml.types';
import { groupComponentsByRow, calculateBoundingBox } from '../../utils/positioningUtils';

/**
 * Render children with absolute positioning
 * Each child is positioned exactly according to its bounds
 * Top-level page children use absolute page coordinates
 */
const renderAbsoluteLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[]
) => {
    return children.map((child, index) => {
        // Top-level components use absolute page coordinates directly
        const { x, y, width, height } = child.bounds;

        console.log(`Component ${child.type} (${child.id}):`, {
            bounds: { x, y, width, height }
        });

        return (
            <Box
                key={`${componentKey}-abs-${index}`}
                sx={{
                    position: 'absolute',
                    left: `${x}px`,
                    top: `${y}px`,
                    width: `${width}px`,
                    height: `${height}px`,
                }}
            >
                {mapComponent(child, `${componentKey}-${index}`, true, allPages)}
            </Box>
        );
    });
};

/**
 * Render children with responsive grid layout
 * Groups components by Y position (rows) and uses grid columns for width
 */
const renderResponsiveLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[],
    useAbsolutePositioning: boolean
) => {
    // Use children directly - SubBean hierarchy is already correct
    // Group into rows for layout
    const rows = groupComponentsByRow(children);

    return (
        <Grid container spacing={2} direction="row">
            {rows.map((row, rowIndex) => (
                <GridItem key={`row-${rowIndex}`} xs={12}>
                    <Grid container spacing={2} direction="row">
                        {row.map((child, colIndex) =>
                            mapComponent(
                                child,
                                `${componentKey}-${rowIndex}-${colIndex}`,
                                useAbsolutePositioning,
                                allPages
                            ),
                        )}
                    </Grid>
                </GridItem>
            ))}
        </Grid>
    );
};

export const PageComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages = []
}) => {
    const { children, bounds, properties } = component;

    if (!children || children.length === 0) {
        return (
            <Paper sx={{ width: '100%', p: 2 }}>
                <Grid
                    minHeight={400}
                    height="100%"
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                >
                    {/* Empty page */}
                </Grid>
            </Paper>
        );
    }

    // Import mapComponent dynamically to avoid circular dependency
    const { mapComponent } = require('../../mapper/component-mapper');

    // Get page dimensions from properties or bounds
    // pageSize can be "width,height" format
    let pageWidth = 1024;
    let pageHeight = 768;

    if (properties.pageSize) {
        const [w, h] = String(properties.pageSize).split(',').map(Number);
        if (w && h) {
            pageWidth = w;
            pageHeight = h;
        }
    } else if (properties.pageWidth && properties.pageHeight) {
        pageWidth = Number(properties.pageWidth);
        pageHeight = Number(properties.pageHeight);
    } else if (bounds.width > 0 && bounds.height > 0) {
        pageWidth = bounds.width;
        pageHeight = bounds.height;
    } else if (children.length > 0) {
        // Calculate bounding box from children if no explicit size
        const childrenBox = calculateBoundingBox(children);
        pageWidth = Math.max(pageWidth, childrenBox.x + childrenBox.width + 20);
        pageHeight = Math.max(pageHeight, childrenBox.y + childrenBox.height + 20);
    }

    console.log('PageComponent dimensions:', { pageWidth, pageHeight, bounds, properties });

    if (useAbsolutePositioning) {
        // Use the original children with SubBean hierarchy intact
        // SubBeans already have relative coordinates to their parent containers
        console.log('PageComponent absolute mode - children:', children.map(c => ({
            type: c.type,
            id: c.id,
            bounds: c.bounds,
            childCount: c.children?.length || 0
        })));

        // Absolute positioning mode - match Windows Forms layout exactly
        // Using the template: Paper > Grid > Content
        return (
            <Paper sx={{ width: '100%', overflow: 'auto' }}>
                <Grid
                    minHeight={pageHeight}
                    height="100%"
                    display="flex"
                    justifyContent="center"
                    alignItems="flex-start"
                >
                    <Box
                        sx={{
                            position: 'relative',
                            width: `${pageWidth}px`,
                            height: `${pageHeight}px`,
                            minHeight: `${pageHeight}px`,
                            backgroundColor: properties.backgroundColor || '#ece9d8',
                            margin: '0 auto',
                        }}
                    >
                        {renderAbsoluteLayout(children, componentKey, mapComponent, allPages)}
                    </Box>
                </Grid>
            </Paper>
        );
    }

    // Responsive grid mode
    return (
        <Paper sx={{ width: '100%', p: 2 }}>
            <Grid
                minHeight={pageHeight}
                height="100%"
                display="flex"
                justifyContent="center"
                alignItems="center"
            >
                <Box sx={{ width: '100%' }}>
                    {renderResponsiveLayout(children, componentKey, mapComponent, allPages, useAbsolutePositioning)}
                </Box>
            </Grid>
        </Paper>
    );
};
