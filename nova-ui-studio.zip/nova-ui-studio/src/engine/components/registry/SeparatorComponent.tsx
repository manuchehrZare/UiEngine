/* eslint-disable */
/**
 * Separator Component
 * Renders EBML Separator components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Divider, GridItem } from '../../../lib';
import type { BaseComponentProps } from './types';

export const SeparatorComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false
}) => {
    const { properties } = component;
    const orientation = properties.orientation === 'vertical' ? 'vertical' : 'horizontal';

    const separatorContent = (
        <Divider
            orientation={orientation}
            sx={{
                my: orientation === 'horizontal' ? 1 : 0,
                mx: orientation === 'vertical' ? 1 : 0,
                height: orientation === 'vertical' ? '100%' : 'auto',
            }}
        />
    );

    if (useAbsolutePositioning) {
        return separatorContent;
    }

    return (
        <GridItem key={componentKey} xs={12}>
            {separatorContent}
        </GridItem>
    );
};
