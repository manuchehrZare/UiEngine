/* eslint-disable */
/**
 * Component Registry Exports
 */

export * from './types';
export * from './componentRegistry';
export { LabelComponent } from './LabelComponent';
export { ButtonComponent } from './ButtonComponent';
export { TableComponent } from './TableComponent';
export { TextFieldComponent } from './TextFieldComponent';
export { CurrencyComponent } from './CurrencyComponent';
export { PanelComponent } from './PanelComponent';
export { RegionComponent } from './RegionComponent';
export { TabbedPaneComponent } from './TabbedPaneComponent';
export { TabPageComponent } from './TabPageComponent';
export { SeparatorComponent } from './SeparatorComponent';
export { PageComponent } from './PageComponent';
export { UnknownComponent } from './UnknownComponent';
