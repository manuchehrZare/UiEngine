/* eslint-disable */
/**
 * FileSelector Component
 * Renders EBML FilePicker components as FileSelector
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { FileSelector, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const FileSelectorComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the file selector control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.value || null,
        },
    });

    const fileSelectorContent = (
        <FileSelector
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            disabled={properties.enabled === 'false'}
            accept={properties.accept || properties.fileFilter}
            multiple={properties.multiple === 'true'}
            fullWidth
        />
    );

    if (useAbsolutePositioning) {
        return fileSelectorContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {fileSelectorContent}
        </GridItem>
    );
};
