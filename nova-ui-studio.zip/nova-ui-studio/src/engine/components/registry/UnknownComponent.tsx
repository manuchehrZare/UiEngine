/* eslint-disable */
/**
 * Unknown Component
 * Fallback renderer for unknown component types
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Box, Label, GridItem, Grid } from '../../../lib';
import type { BaseComponentProps } from './types';
import type { ParsedComponent } from '../../types/ebml.types';
import { boundsToGridSize, groupComponentsByRow } from '../../utils/positioningUtils';

/**
 * Render children with absolute positioning
 */
const renderAbsoluteLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[]
) => {
    return children.map((child, index) => (
        <Box
            key={`${componentKey}-unknown-abs-${index}`}
            sx={{
                position: 'absolute',
                left: `${child.bounds.x}px`,
                top: `${child.bounds.y}px`,
                width: `${child.bounds.width}px`,
                height: `${child.bounds.height}px`,
            }}
        >
            {mapComponent(child, `${componentKey}-unknown-${index}`, true, allPages)}
        </Box>
    ));
};

export const UnknownComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages,
    parentBounds
}) => {
    const { type, children, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    console.warn(`Unknown component type: ${type}`, component);

    // Import mapComponent dynamically to avoid circular dependency
    const { mapComponent } = require('../../mapper/component-mapper');

    const unknownContent = (
        <Box sx={{
            border: '1px dashed #ccc',
            backgroundColor: '#f5f5f5',
            p: 1,
            height: '100%',
            position: useAbsolutePositioning ? 'relative' : 'static',
        }}>
            <Label text={`Unknown: ${type}`} />
            {children && children.length > 0 && (
                useAbsolutePositioning ? (
                    renderAbsoluteLayout(children, componentKey, mapComponent, allPages)
                ) : (
                    <Grid container spacing={1} sx={{ mt: 1 }}>
                        {groupComponentsByRow(children).map((row, rowIndex) =>
                            row.map((child, colIndex) =>
                                mapComponent(
                                    child,
                                    `${componentKey}-unknown-${rowIndex}-${colIndex}`,
                                    useAbsolutePositioning,
                                    allPages
                                ),
                            ),
                        )}
                    </Grid>
                )
            )}
        </Box>
    );

    if (useAbsolutePositioning) {
        return unknownContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {unknownContent}
        </GridItem>
    );
};
