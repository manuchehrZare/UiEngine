/* eslint-disable */
/**
 * Radio Component
 * Renders EBML RadioButton components as Radio (for use inside RadioGroup)
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Radio } from '../../../lib';
import type { BaseComponentProps } from './types';

export const RadioComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false
}) => {
    const { properties } = component;

    // Radio is typically used inside RadioGroup, so it doesn't need GridItem wrapper
    return (
        <Radio
            key={componentKey}
            label={properties.text || properties.label || ''}
            value={properties.value || component.id || ''}
            helperText={properties.helperText}
            disabled={properties.enabled === 'false'}
        />
    );
};
