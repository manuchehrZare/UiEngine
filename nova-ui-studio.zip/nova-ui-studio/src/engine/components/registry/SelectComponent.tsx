/* eslint-disable */
/**
 * Select Component
 * Renders EBML ComboBox components as Select dropdown
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Select, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import type { ISelectOptions } from '../../../lib';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const SelectComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the select control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.value || properties.selectedValue || '',
        },
    });

    // Parse options from properties
    let options: ISelectOptions[] = [];

    if (properties.options && Array.isArray(properties.options)) {
        options = properties.options;
    } else if (properties.items) {
        if (typeof properties.items === 'string') {
            options = properties.items.split(',').map((item: string) => ({
                label: item.trim(),
                value: item.trim(),
            }));
        } else if (Array.isArray(properties.items)) {
            options = properties.items.map((item: any) => ({
                label: typeof item === 'object' ? item.label || item.value : String(item),
                value: typeof item === 'object' ? item.value : String(item),
            }));
        }
    } else if (component.adapterInfo?.items) {
        const adapterItems = component.adapterInfo.items;
        if (Array.isArray(adapterItems)) {
            options = adapterItems.map((item: any) => ({
                label: typeof item === 'object' ? item.label || item.value || item.name : String(item),
                value: typeof item === 'object' ? item.value || item.id : String(item),
            }));
        }
    }

    // Default empty option if no options provided
    if (options.length === 0) {
        options = [
            { label: 'Option 1', value: '1' },
            { label: 'Option 2', value: '2' },
            { label: 'Option 3', value: '3' },
        ];
    }

    const selectContent = (
        <Select
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            placeholder={properties.placeholder}
            options={options}
            disabled={properties.enabled === 'false'}
            fullWidth
        />
    );

    if (useAbsolutePositioning) {
        return selectContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {selectContent}
        </GridItem>
    );
};
