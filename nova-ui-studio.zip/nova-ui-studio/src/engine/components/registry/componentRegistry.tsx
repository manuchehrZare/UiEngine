/* eslint-disable */
/**
 * Component Registry
 * Central registry for all EBML component renderers
 */

import type { ComponentRegistry } from './types';
import { LabelComponent } from './LabelComponent';
import { ButtonComponent } from './ButtonComponent';
import { HandleButtonFieldComponent } from './HandleButtonFieldComponent';
import { TableComponent } from './TableComponent';
import { TextFieldComponent } from './TextFieldComponent';
import { TextAreaComponent } from './TextAreaComponent';
import { SelectComponent } from './SelectComponent';
import { DatePickerComponent } from './DatePickerComponent';
import { TimePickerComponent } from './TimePickerComponent';
import { DateTimePickerComponent } from './DateTimePickerComponent';
import { FileSelectorComponent } from './FileSelectorComponent';
import { CheckboxComponent } from './CheckboxComponent';
import { RadioGroupComponent } from './RadioGroupComponent';
import { RadioComponent } from './RadioComponent';
import { MaskFieldComponent } from './MaskFieldComponent';
import { PanelComponent } from './PanelComponent';
import { RegionComponent } from './RegionComponent';
import { TabbedPaneComponent } from './TabbedPaneComponent';
import { TabPageComponent } from './TabPageComponent';
import { SeparatorComponent } from './SeparatorComponent';
import { PageComponent } from './PageComponent';
import { CurrencyComponent } from './CurrencyComponent';

/**
 * Create and populate the component registry
 */
export const createComponentRegistry = (): ComponentRegistry => {
    const registry: ComponentRegistry = new Map();

    // Register all component types
    registry.set('Label', (props) => <LabelComponent {...props} />);
    registry.set('Button', (props) => <ButtonComponent {...props} />);
    registry.set('HandleButtonField', (props) => <HandleButtonFieldComponent {...props} />);
    registry.set('Table', (props) => <TableComponent {...props} />);
    registry.set('TextField', (props) => <TextFieldComponent {...props} />);
    registry.set('TextArea', (props) => <TextAreaComponent {...props} />);
    registry.set('TextPane', (props) => <TextAreaComponent {...props} />);
    registry.set('CurrencyField', (props) => <CurrencyComponent {...props} />);
    registry.set('NumberField', (props) => <TextFieldComponent {...props} />);
    registry.set('DateField', (props) => <DatePickerComponent {...props} />);
    registry.set('TimeField', (props) => <TimePickerComponent {...props} />);
    registry.set('DateTimeField', (props) => <DateTimePickerComponent {...props} />);
    registry.set('FilePicker', (props) => <FileSelectorComponent {...props} />);
    registry.set('CheckBox', (props) => <CheckboxComponent {...props} />);
    registry.set('ButtonGroup', (props) => <RadioGroupComponent {...props} />);
    registry.set('RadioButton', (props) => <RadioComponent {...props} />);
    registry.set('ComboBox', (props) => <SelectComponent {...props} />);
    registry.set('MaskField', (props) => <MaskFieldComponent {...props} />);
    registry.set('Panel', (props) => <PanelComponent {...props} />);
    registry.set('Region', (props) => <RegionComponent {...props} />);
    registry.set('TabbedPane', (props) => <TabbedPaneComponent {...props} />);
    registry.set('TabPage', (props) => <TabPageComponent {...props} />);
    registry.set('Separator', (props) => <SeparatorComponent {...props} />);
    registry.set('Page', (props) => <PageComponent {...props} />);

    return registry;
};

/**
 * Global component registry instance
 */
export const componentRegistry = createComponentRegistry();

/**
 * Get a component renderer by type
 */
export const getComponentRenderer = (type: string) => {
    return componentRegistry.get(type);
};

/**
 * Register a new component type
 */
export const registerComponent = (type: string, renderer: any) => {
    componentRegistry.set(type, renderer);
};

/**
 * Check if a component type is registered
 */
export const hasComponent = (type: string): boolean => {
    return componentRegistry.has(type);
};
