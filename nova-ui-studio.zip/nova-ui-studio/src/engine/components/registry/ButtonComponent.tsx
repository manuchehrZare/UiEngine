/* eslint-disable */
/**
 * Button Component
 * Renders EBML Button components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Button, GridItem } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const ButtonComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    const buttonContent = (
        <Button
            text={properties.text || 'Button'}
            disabled={properties.enabled === 'false'}
            sx={{
                width: useAbsolutePositioning ? '100%' : 'auto',
                height: useAbsolutePositioning ? '100%' : 'auto',
            }}
        />
    );

    if (useAbsolutePositioning) {
        return buttonContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {buttonContent}
        </GridItem>
    );
};
