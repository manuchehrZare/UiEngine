/* eslint-disable */
/**
 * Component Registry Types
 * Types for the component registry system
 */

import type { ParsedComponent, PageDefinition, ComponentBounds } from '../../types/ebml.types';
import type React from 'react';

/**
 * Common props passed to all registered components
 */
export interface BaseComponentProps {
    component: ParsedComponent;
    componentKey: string;
    useAbsolutePositioning?: boolean;
    allPages?: PageDefinition[];
    parentBounds?: ComponentBounds;
}

/**
 * Component renderer function type
 */
export type ComponentRenderer = (props: BaseComponentProps) => React.ReactNode;

/**
 * Component registry entry
 */
export interface ComponentRegistryEntry {
    type: string;
    renderer: ComponentRenderer;
}

/**
 * Component registry type
 */
export type ComponentRegistry = Map<string, ComponentRenderer>;
