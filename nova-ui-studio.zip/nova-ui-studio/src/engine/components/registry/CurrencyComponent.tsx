/* eslint-disable */
/**
 * Currency Component
 * Renders EBML CurrencyField components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { GridItem, useForm, Currency } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const CurrencyComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the input control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.text || properties.value || '',
        },
    });

    const currencyContent = (
        <Currency
            component="NumberInput"
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            placeholder={properties.placeholder || properties.text}
            disabled={properties.enabled === 'false'}
            fullWidth
            sx={{ height: '100%' }}
        />
    );

    if (useAbsolutePositioning) {
        return currencyContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {currencyContent}
        </GridItem>
    );
};
