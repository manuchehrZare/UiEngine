/* eslint-disable */
/**
 * DateTimePicker Component
 * Renders EBML DateTimeField components as DateTimePicker
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { DateTimePicker, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const DateTimePickerComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the datetimepicker control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.value || properties.datetime || null,
        },
    });

    const dateTimePickerContent = (
        <DateTimePicker
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            disabled={properties.enabled === 'false'}
            fullWidth
        />
    );

    if (useAbsolutePositioning) {
        return dateTimePickerContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {dateTimePickerContent}
        </GridItem>
    );
};
