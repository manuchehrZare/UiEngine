/* eslint-disable */
/**
 * Table Component
 * Renders EBML Table components with DataGrid
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { DataGrid, GridItem, Box } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

// Column definition from EBML adapterInfo
interface Column {
    Id?: string;
    Title?: string;
    Type?: string;
    Visible?: boolean;
    Editable?: boolean;
    Order?: number;
    Alignment?: string;
    Width?: number;
}

// Map EBML column type to DataGrid column type
const mapColumnType = (type?: string): string => {
    if (!type) return 'string';

    const typeMap: Record<string, string> = {
        'String': 'string',
        'Number': 'number',
        'Integer': 'number',
        'Decimal': 'number',
        'Date': 'date',
        'DateTime': 'dateTime',
        'Boolean': 'boolean',
    };

    return typeMap[type] || 'string';
};

// Map EBML alignment to DataGrid alignment
const mapAlignment = (alignment?: string): 'left' | 'center' | 'right' => {
    if (!alignment) return 'left';

    const alignmentMap: Record<string, 'left' | 'center' | 'right'> = {
        'Left': 'left',
        'Center': 'center',
        'Right': 'right',
        'LEADING': 'left',
        'TRAILING': 'right',
    };

    return alignmentMap[alignment] || 'left';
};

// Parse background color from EBML format (e.g., "255,255,255")
const parseColor = (color?: string): string => {
    if (!color) return '#ffffff';

    const parts = color.split(',').map(p => parseInt(p.trim()));
    if (parts.length === 3) {
        return `rgb(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }

    return color;
};

export const TableComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const bgColor = parseColor(properties.background);
    // Calculate grid size based on parent container width
    const containerWidth = parentBounds?.width || 960;

    // Parse columns from adapterInfo
    const adapterInfo = properties.adapterInfo;
    let tableColumns: Column[] = [];
    let dataGridColumns: any[] = [];
    let rows: any[] = [{ id: 1 }]; // Sample data row

    if (adapterInfo) {
        try {
            const adapter = typeof adapterInfo === 'string' ? JSON.parse(adapterInfo) : adapterInfo;

            if (adapter.Column && Array.isArray(adapter.Column)) {
                tableColumns = adapter.Column;
            } else if (adapter.columns && Array.isArray(adapter.columns)) {
                tableColumns = adapter.columns.map((col: any) => ({
                    Id: col.field || col.name || col.columnName || col.Id,
                    Title: col.headerName || col.label || col.title || col.Title,
                    Type: col.type || col.Type,
                    Visible: col.visible !== false && col.Visible !== false,
                    Editable: col.editable || col.Editable || false,
                    Order: col.order || col.Order,
                    Alignment: col.align || col.Alignment,
                    Width: col.width || col.Width,
                }));
            }

            if (tableColumns.length > 0) {
                dataGridColumns = tableColumns
                    .filter((col) => col.Visible !== false)
                    .sort((a, b) => (a.Order || 0) - (b.Order || 0))
                    .map((col) => ({
                        field: col.Id || col.Title || 'field',
                        headerName: col.Title || col.Id || 'Column',
                        editable: col.Editable || false,
                        type: mapColumnType(col.Type),
                        align: mapAlignment(col.Alignment),
                        headerAlign: mapAlignment(col.Alignment),
                        flex: 1,
                    }));
            }
        } catch (error) {
            console.error('Error parsing table adapterInfo:', error);
        }
    }

    // If no columns defined, use default columns
    if (dataGridColumns.length === 0) {
        dataGridColumns = [
            { field: 'id', headerName: 'ID', width: 100 },
            { field: 'value', headerName: 'Value', flex: 1 },
        ];
    }

    const tableContent = (
        <Box
            sx={{
                width: '100%',
                height: useAbsolutePositioning ? '100%' : bounds?.height || 400,
                backgroundColor: bgColor,
                display: 'flex',
                flexDirection: 'column',
            }}
            minHeight={200}
        >
            <DataGrid
                rows={rows}
                columns={dataGridColumns}
                pagination
                pageSize={10}
                pageSizeOptions={[5, 10, 25, 50]}
                
                sx={{
                    border: '1px solid #ddd',
                    '& .MuiDataGrid-cell': {
                        borderColor: '#ddd',
                    },
                    '& .MuiDataGrid-columnHeaders': {
                        backgroundColor: '#f5f5f5',
                        borderColor: '#ddd',
                    },
                }}
            />
        </Box>
    );

    if (useAbsolutePositioning) {
        return tableContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={12}
            sm={12}
            md={12}
            lg={12}
            sx={{ display: 'flex', flexDirection: 'column', minHeight: gridSize.minHeight }}
        >
            {tableContent}
        </GridItem>
    );
};
