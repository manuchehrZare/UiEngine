/* eslint-disable */
/**
 * MaskField Component
 * Renders EBML MaskField components as Input with mask
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Input, GridItem, useForm } from '../../../lib';
import type { BaseComponentProps } from './types';
import { boundsToGridSize } from '../../utils/positioningUtils';

export const MaskFieldComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;

    // Create a form instance for the input control
    const { control } = useForm({
        defaultValues: {
            [component.id || 'field']: properties.text || properties.value || '',
        },
    });

    const maskFieldContent = (
        <Input
            name={component.id || 'field'}
            control={control}
            label={properties.label}
            placeholder={properties.placeholder || properties.text}
            helperText={properties.helperText}
            mask={properties.mask || properties.format}
            required={properties.required === 'true'}
            disabled={properties.enabled === 'false'}
            fullWidth
            sx={{ height: '100%' }}
        />
    );

    if (useAbsolutePositioning) {
        return maskFieldContent;
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {maskFieldContent}
        </GridItem>
    );
};
