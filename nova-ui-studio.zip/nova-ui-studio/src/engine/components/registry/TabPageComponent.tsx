/* eslint-disable */
/**
 * TabPage Component
 * Renders EBML JCSTabPage components (individual tab page within TabbedPane)
 * Simply renders children without wrapper - the parent TabbedPane handles the tab structure
 */

import React from 'react';
import type { BaseComponentProps } from './types';

export const TabPageComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages = []
}) => {
    const { children } = component;

    if (!children || children.length === 0) {
        return null;
    }

    // Import mapComponent dynamically to avoid circular dependency
    const { mapComponent } = require('../../mapper/component-mapper');

    // TabPage just renders its children - the TabbedPane parent handles positioning
    return (
        <>
            {children.map((child, index) =>
                mapComponent(
                    child,
                    `${componentKey}-tabpage-${index}`,
                    useAbsolutePositioning,
                    allPages
                )
            )}
        </>
    );
};
