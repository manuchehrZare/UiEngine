/* eslint-disable */
/**
 * Region Component
 * Renders EBML Region components (references to reusable sub-pages)
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Box, Label, GridItem, Grid } from '../../../lib';
import type { BaseComponentProps } from './types';
import type { PageDefinition, ParsedComponent } from '../../types/ebml.types';
import { parseBeanWithNesting } from '../../parser/ebml-parser';
import { boundsToGridSize, groupComponentsByRow } from '../../utils/positioningUtils';

const findRegionByName = (regionName: string, allPages: PageDefinition[]): PageDefinition | null => {
    return allPages.find(page => page.Type === 'region' && page.Name === regionName) || null;
};

/**
 * Render children with absolute positioning
 */
const renderAbsoluteLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[],
    containerBounds: { x: number; y: number }
) => {
    return children.map((child, index) => {
        const relativeX = child.bounds.x - containerBounds.x;
        const relativeY = child.bounds.y - containerBounds.y;

        return (
            <Box
                key={`${componentKey}-region-abs-${index}`}
                sx={{
                    position: 'absolute',
                    left: `${relativeX}px`,
                    top: `${relativeY}px`,
                    width: `${child.bounds.width}px`,
                    height: `${child.bounds.height}px`,
                }}
            >
                {mapComponent(child, `${componentKey}-region-${index}`, true, allPages)}
            </Box>
        );
    });
};

export const RegionComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages = [],
    parentBounds
}) => {
    const { properties, bounds } = component;
    const containerWidth = parentBounds?.width || 960;
    const gridSize = boundsToGridSize(bounds, containerWidth);
    const regionName = properties.regionName;

    // No region name specified
    if (!regionName) {
        if (useAbsolutePositioning) {
            return (
                <Box sx={{
                    border: '2px dashed #ff9800',
                    p: 1,
                    width: '100%',
                    height: '100%',
                    boxSizing: 'border-box'
                }}>
                    <Label text="[Region: No name specified]" />
                </Box>
            );
        }
        return (
            <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
                <Box sx={{ border: '2px dashed #ff9800', p: 1, height: '100%' }}>
                    <Label text="[Region: No name specified]" />
                </Box>
            </GridItem>
        );
    }

    const regionDef = findRegionByName(regionName, allPages);

    // Region not found
    if (!regionDef) {
        if (useAbsolutePositioning) {
            return (
                <Box sx={{
                    border: '2px dashed #f44336',
                    p: 1,
                    width: '100%',
                    height: '100%',
                    boxSizing: 'border-box'
                }}>
                    <Label text={`[Region not found: ${regionName}]`} />
                </Box>
            );
        }
        return (
            <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
                <Box sx={{ border: '2px dashed #f44336', p: 1, height: '100%' }}>
                    <Label text={`[Region not found: ${regionName}]`} />
                </Box>
            </GridItem>
        );
    }

    try {
        const regionBean = regionDef.EbmlContent.Interface.Structure.Bean;
        const parsedRegion = parseBeanWithNesting(regionBean);

        // Import mapComponent dynamically to avoid circular dependency
        const { mapComponent } = require('../../mapper/component-mapper');

        if (parsedRegion.children && parsedRegion.children.length > 0) {
            if (useAbsolutePositioning) {
                // Absolute positioning mode
                return (
                    <Box sx={{
                        position: 'relative',
                        width: '100%',
                        height: '100%',
                    }}>
                        {renderAbsoluteLayout(
                            parsedRegion.children,
                            componentKey,
                            mapComponent,
                            allPages,
                            parsedRegion.bounds
                        )}
                    </Box>
                );
            }

            // Responsive grid mode
            const rows = groupComponentsByRow(parsedRegion.children);
            return (
                <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
                    <Grid container spacing={1}>
                        {rows.map((row, rowIndex) =>
                            row.map((child, colIndex) =>
                                mapComponent(
                                    child,
                                    `${componentKey}-region-${rowIndex}-${colIndex}`,
                                    useAbsolutePositioning,
                                    allPages
                                ),
                            ),
                        )}
                    </Grid>
                </GridItem>
            );
        }

        // Empty region
        if (useAbsolutePositioning) {
            return <Box sx={{ width: '100%', height: '100%' }} />;
        }
        return (
            <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }} />
        );
    } catch (error) {
        console.error('Error rendering region:', regionName, error);
        if (useAbsolutePositioning) {
            return (
                <Box sx={{
                    border: '2px dashed #f44336',
                    p: 1,
                    width: '100%',
                    height: '100%',
                    boxSizing: 'border-box'
                }}>
                    <Label text={`[Region error: ${regionName}]`} />
                </Box>
            );
        }
        return (
            <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
                <Box sx={{ border: '2px dashed #f44336', p: 1, height: '100%' }}>
                    <Label text={`[Region error: ${regionName}]`} />
                </Box>
            </GridItem>
        );
    }
};
