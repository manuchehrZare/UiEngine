/* eslint-disable */
/**
 * Panel Component
 * Renders EBML Panel components (container with children)
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Paper, GridItem, Grid, Box } from '../../../lib';
import { Typography } from '@mui/material';
import type { BaseComponentProps } from './types';
import type { ParsedComponent } from '../../types/ebml.types';
import { boundsToGridSize, groupComponentsByRow } from '../../utils/positioningUtils';

// Helper to parse color from EBML format (R,G,B)
const parseColor = (colorStr?: string): string => {
    if (!colorStr) return 'rgb(236, 233, 216)';
    const parts = colorStr.split(',').map(p => parseInt(p.trim()));
    if (parts.length === 3) {
        return `rgb(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }
    return colorStr;
};

/**
 * Render children with absolute positioning
 * Child bounds are already relative to parent panel, so use them directly
 */
const renderAbsoluteLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[]
) => {
    return children.map((child, index) => {
        // Child bounds are already relative to parent panel
        // e.g., if panel is at (5,209,780,305) and table is at (5,5,780,295)
        // the table position (5,5) is relative to the panel, not the page
        const { x, y, width, height } = child.bounds;

        console.log(`  Child ${child.type} (${child.id}) in Panel:`, {
            bounds: { x, y, width, height }
        });

        return (
            <Box
                key={`${componentKey}-panel-abs-${index}`}
                sx={{
                    position: 'absolute',
                    left: `${x}px`,
                    top: `${y}px`,
                    width: `${width}px`,
                    height: `${height}px`,
                }}
            >
                {mapComponent(child, `${componentKey}-panel-${index}`, true, allPages)}
            </Box>
        );
    });
};

/**
 * Render children with responsive grid layout
 */
const renderResponsiveLayout = (
    children: ParsedComponent[],
    componentKey: string,
    mapComponent: any,
    allPages: any[],
    useAbsolutePositioning: boolean,
    panelBounds: { x: number; y: number; width: number; height: number }
) => {
    const rows = groupComponentsByRow(children);

    return (
        <Grid container spacing={{ xs: 1, sm: 1.5, md: 2 }} direction="column">
            {rows.map((row, rowIndex) => (
                <GridItem key={`row-${rowIndex}`} xs={12}>
                    <Grid container spacing={{ xs: 1, sm: 1.5, md: 2 }} direction="row">
                        {row.map((child, colIndex) =>
                            mapComponent(
                                child,
                                `${componentKey}-panel-${rowIndex}-${colIndex}`,
                                useAbsolutePositioning,
                                allPages,
                                panelBounds
                            ),
                        )}
                    </Grid>
                </GridItem>
            ))}
        </Grid>
    );
};

export const PanelComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning = false,
    allPages = [],
    parentBounds
}) => {
    const { children, bounds, properties } = component;
    // Calculate grid size based on parent container width, not page width
    const containerWidth = parentBounds?.width || 960;
    const gridSize = boundsToGridSize(bounds, containerWidth);
    const bgColor = parseColor(properties.background || '236,233,216');
    const hasTitle = !!properties.title;

    // Import mapComponent dynamically to avoid circular dependency
    const { mapComponent } = require('../../mapper/component-mapper');

    // Empty panel
    if (!children || children.length === 0) {
        if (useAbsolutePositioning) {
            // Panel is already positioned by parent
            return (
                <Paper
                    sx={{
                        width: '100%',
                        height: '100%',
                        backgroundColor: bgColor,
                        p: hasTitle ? 2 : 1,
                        border: '1px solid #ccc',
                        boxSizing: 'border-box',
                        boxShadow: 1,
                    }}
                >
                    {hasTitle && (
                        <Typography variant="h6" gutterBottom sx={{ borderBottom: '1px solid #ddd', pb: 1, mb: 2 }}>
                            {properties.title}
                        </Typography>
                    )}
                </Paper>
            );
        }

        return (
            <GridItem key={componentKey} xs={gridSize.xs}>
                <Paper
                    sx={{
                        backgroundColor: bgColor,
                        p: hasTitle ? 2 : 1,
                        border: '1px solid #ccc',
                        height: '100%',
                        minHeight: gridSize.minHeight || 'auto',
                        boxShadow: 1,
                    }}
                >
                    {hasTitle && (
                        <Typography variant="h6" gutterBottom sx={{ borderBottom: '1px solid #ddd', pb: 1, mb: 2 }}>
                            {properties.title}
                        </Typography>
                    )}
                </Paper>
            </GridItem>
        );
    }

    // Panel with children - absolute positioning mode
    if (useAbsolutePositioning) {
        // Panel is already positioned by parent, so use relative positioning for content
        return (
            <Paper
                sx={{
                    width: '100%',
                    height: '100%',
                    backgroundColor: bgColor,
                    p: hasTitle ? 2 : 0,
                    border: '1px solid #ccc',
                    boxSizing: 'border-box',
                    overflow: 'visible',
                    boxShadow: 1,
                }}
            >
                {hasTitle && (
                    <Typography variant="h6" gutterBottom sx={{ borderBottom: '1px solid #ddd', pb: 1, mb: 2 }}>
                        {properties.title}
                    </Typography>
                )}
                <Box sx={{
                    position: 'relative',
                    width: '100%',
                    height: hasTitle ? 'calc(100% - 50px)' : '100%'
                }}>
                    {renderAbsoluteLayout(children, componentKey, mapComponent, allPages)}
                </Box>
            </Paper>
        );
    }

    // Panel with children - responsive grid mode
    return (
        <GridItem key={componentKey} xs={gridSize.xs}>
            <Paper
                sx={{
                    backgroundColor: bgColor,
                    p: hasTitle ? 2 : 1,
                    border: '1px solid #ccc',
                    height: '100%',
                    minHeight: gridSize.minHeight || 'auto',
                    boxShadow: 1,
                }}
            >
                {hasTitle && (
                    <Typography variant="h6" gutterBottom sx={{ borderBottom: '1px solid #ddd', pb: 1, mb: 2 }}>
                        {properties.title}
                    </Typography>
                )}
                <Box sx={{ position: 'relative' }}>
                    {renderResponsiveLayout(children, componentKey, mapComponent, allPages, useAbsolutePositioning, bounds)}
                </Box>
            </Paper>
        </GridItem>
    );
};
