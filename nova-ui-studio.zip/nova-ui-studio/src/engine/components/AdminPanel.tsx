/* eslint-disable */
/**
 * Admin Panel Component
 * Main layout for the UI engine with navigation menu and page content
 */

import type { FC } from 'react';
import React, { useState, useMemo } from 'react';
import {
    Box,
    CustomScrollbar,
    NavContainer,
    NavTitle,
    NavRow,
    Paper,
    Alert,
    Progress,
    useForm,
    Input,
    Label,
    Chip,
} from '../../lib';
import { usePageDefinitions } from '../hooks/usePageDefinitions';
import PageRenderer from './PageRenderer';
import type { PageDefinition } from '../types/ebml.types';
import TextField from '@mui/material/TextField';
import { InputAdornment } from '@mui/material';

export interface AdminPanelProps {
    useAbsolutePositioning?: boolean;
}

const AdminPanel: FC<AdminPanelProps> = ({ useAbsolutePositioning = true }) => {
    const { pages, loading, error } = usePageDefinitions();
    const [selectedPage, setSelectedPage] = useState<PageDefinition | null>(null);

    // Form for search input
    const { control } = useForm({
        defaultValues: {
            search: '',
        },
    });

    const [searchTerm, setSearchTerm] = useState('');

    // Group pages by module (only show pages, not regions/popups/screens)
    const groupedPages = useMemo(() => {
        const groups: Record<string, PageDefinition[]> = {};

        pages
            .filter((page) => page.Type === 'page') // Only show pages
            .forEach((page) => {
                const module = page.ModuleName || 'Other';
                if (!groups[module]) {
                    groups[module] = [];
                }
                groups[module].push(page);
            });

        return groups;
    }, [pages]);

    // Filter pages based on search
    const filteredGroups = useMemo(() => {
        if (!searchTerm) return groupedPages;

        const filtered: Record<string, PageDefinition[]> = {};
        Object.entries(groupedPages).forEach(([module, modulePages]) => {
            const matchingPages = modulePages.filter(
                (page) =>
                    page.MenuName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    page.ScreenCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    page.Name.toLowerCase().includes(searchTerm.toLowerCase()),
            );

            if (matchingPages.length > 0) {
                filtered[module] = matchingPages;
            }
        });

        return filtered;
    }, [groupedPages, searchTerm]);

    const handlePageSelect = (page: PageDefinition) => {
        setSelectedPage(page);
    };

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <Progress type="circular" />
            </Box>
        );
    }

    if (error) {
        return (
            <Box sx={{ p: 3 }}>
                <Alert type="error" text={`Failed to load page definitions: ${error.message}`} />
            </Box>
        );
    }

    return (
        <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
            {/* Left Sidebar - Navigation Menu */}
            <Paper
                sx={{
                    width: 300,
                    height: '100%',
                    borderRadius: 0,
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    boxShadow: 2,
                }}
            >
                {/* Search Box */}
                <Box sx={{ p: 2, borderBottom: '1px solid #e0e0e0' }}>
                     <TextField
              fullWidth
              placeholder="Search pages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              size="small"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                  </InputAdornment>
                ),
              }}
            />
                </Box>

                {/* Navigation Menu */}
                <CustomScrollbar height="calc(100% - 80px)">
                    <NavContainer>
                        {Object.entries(filteredGroups).map(([module, modulePages]) => (
                            <React.Fragment key={module}>
                                {/* <NavTitle title={module} /> */}
                                {modulePages.map((page) => (
                                    <Box
                                        key={page.Name}
                                        onClick={() => handlePageSelect(page)}
                                        sx={{
                                            cursor: 'pointer',
                                            backgroundColor: selectedPage?.Name === page.Name ? '#f0f0f0' : 'transparent',
                                            '&:hover': {
                                                backgroundColor: '#f5f5f5',
                                            },
                                            p: 1.5,
                                            borderBottom: '1px solid #e0e0e0',
                                            display: 'flex',
                                            justifyContent: 'space-between',
                                            alignItems: 'center',
                                            width: '100%',
                                        }}
                                    >
                                        <Label text={page.MenuName + ' ('+page.ScreenCode+')'} sx={{ fontSize: '0.875rem', flex: 1 }} />
                                        {/* <Chip text={page.ScreenCode} size="small" sx={{ fontSize: '0.75rem' }} /> */}
                                    </Box>
                                ))}
                            </React.Fragment>
                        ))}
                    </NavContainer>
                </CustomScrollbar>

                {/* Footer Info */}
                <Box
                    sx={{
                        p: 2,
                        borderTop: '1px solid #e0e0e0',
                        backgroundColor: '#f5f5f5',
                        fontSize: '0.875rem',
                        color: '#666',
                    }}
                >
                    <Label text={`Total Pages: ${pages.filter(p => p.Type === 'page').length}`} sx={{ fontSize: '0.875rem' }} />
                </Box>
            </Paper>

            {/* Right Content Area */}
            <Box sx={{ flex: 1, overflow: 'hidden' }}>
                {selectedPage ? (
                    <>
                        {/* Page Header */}
                        <Box
                            sx={{
                                p: 2,
                                borderBottom: '1px solid #e0e0e0',
                                backgroundColor: '#fff',
                            }}
                        >
                            <Label text={selectedPage.MenuName} sx={{ fontSize: '1.25rem', fontWeight: 600, mb: 0.5 }} />
                            <Label
                                text={`Screen Code: ${selectedPage.ScreenCode} | Module: ${selectedPage.ModuleName}`}
                                sx={{ fontSize: '0.875rem', color: '#666' }}
                            />
                        </Box>

                        {/* Page Content */}
                        <Box sx={{ height: 'calc(100% - 80px)', overflow: 'auto' }}>
                            <PageRenderer
                                pageDefinition={selectedPage}
                                useAbsolutePositioning={useAbsolutePositioning}
                                allPages={pages}
                            />
                        </Box>
                    </>
                ) : (
                    <Box
                        sx={{
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            height: '100%',
                            color: '#999',
                        }}
                    >
                        <Box sx={{ textAlign: 'center' }}>
                            <Box sx={{ fontSize: '3rem', mb: 2 }}>📄</Box>
                            <Label text="Select a page from the menu" sx={{ fontSize: '1.25rem' }} />
                        </Box>
                    </Box>
                )}
            </Box>
        </Box>
    );
};

export default AdminPanel;
