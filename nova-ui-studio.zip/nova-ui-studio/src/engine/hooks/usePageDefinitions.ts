/* eslint-disable */
/**
 * Hook to load and manage page definitions
 */

import { useState, useEffect } from 'react';
import type { PageDefinition } from '../types/ebml.types';

export const usePageDefinitions = () => {
    const [pages, setPages] = useState<PageDefinition[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<Error | null>(null);

    useEffect(() => {
        const loadDefinitions = async () => {
            try {
                setLoading(true);
                // Load the ui-definition.json file
                const response = await fetch('/src/assets/docs/ui-definition.json');
                if (!response.ok) {
                    throw new Error('Failed to load page definitions');
                }
                const data = await response.json();
                setPages(data);
                setError(null);
            } catch (err) {
                console.error('Error loading page definitions:', err);
                setError(err instanceof Error ? err : new Error('Unknown error'));
            } finally {
                setLoading(false);
            }
        };

        loadDefinitions();
    }, []);

    return { pages, loading, error };
};

/**
 * Hook to get a specific page by name or screen code
 */
export const usePage = (identifier: string) => {
    const { pages, loading, error } = usePageDefinitions();

    const page = pages.find(
        (p) => p.Name === identifier || p.ScreenCode === identifier || p.MenuName === identifier,
    );

    return { page, loading, error, allPages: pages };
};
