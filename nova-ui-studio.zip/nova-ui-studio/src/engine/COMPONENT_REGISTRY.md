# Component Registry Architecture

The UI engine now uses a **component registry pattern** for mapping EBML components to React components. This provides better maintainability, extensibility, and separation of concerns.

## Overview

Instead of a single large switch statement in the component mapper, each EBML component type is now:
1. Implemented as a separate component file
2. Registered in a central component registry
3. Resolved dynamically at runtime

## Architecture

### Component Registry Pattern

```
EBML Component Type → Component Registry → Component Renderer → React Component
```

### Benefits

✅ **Separation of Concerns**: Each component type has its own file
✅ **Maintainability**: Easy to modify individual components without affecting others
✅ **Extensibility**: Add new component types by creating a file and registering it
✅ **Testability**: Components can be tested in isolation
✅ **Type Safety**: Full TypeScript support with strict typing
✅ **Dynamic Registration**: Components can be registered/unregistered at runtime

## Directory Structure

```
src/engine/components/registry/
├── types.ts                    # TypeScript type definitions
├── componentRegistry.ts        # Registry implementation
├── index.ts                    # Public exports
├── LabelComponent.tsx          # Label component renderer
├── ButtonComponent.tsx         # Button component renderer
├── TableComponent.tsx          # Table/DataGrid component renderer
├── TextFieldComponent.tsx      # TextField component renderer
├── PanelComponent.tsx          # Panel container component renderer
├── RegionComponent.tsx         # Region reference component renderer
├── TabbedPaneComponent.tsx     # TabbedPane component renderer
├── SeparatorComponent.tsx      # Separator component renderer
├── PageComponent.tsx           # Page root component renderer
└── UnknownComponent.tsx        # Fallback for unknown types
```

## Component Structure

### Base Component Props

All component renderers receive the same props:

```typescript
interface BaseComponentProps {
    component: ParsedComponent;      // Parsed EBML component
    componentKey: string;            // Unique React key
    useAbsolutePositioning?: boolean; // Layout mode flag
    allPages?: PageDefinition[];     // All page definitions (for region lookup)
}
```

### Component Renderer Type

```typescript
type ComponentRenderer = (props: BaseComponentProps) => React.ReactNode;
```

## Creating a Component Renderer

### 1. Create Component File

Create a new file in `src/engine/components/registry/`:

```typescript
/* eslint-disable */
/**
 * MyComponent
 * Description of what this component does
 */

import React from 'react';
import { GridItem, /* other imports */ } from '../../../lib';
import type { BaseComponentProps } from './types';

const boundsToGridSize = (bounds: { width: number; height: number }, containerWidth: number = 960) => {
    const ratio = bounds.width / containerWidth;
    const columns = Math.round(ratio * 12);
    return {
        xs: Math.max(1, Math.min(12, columns)),
        minHeight: bounds.height,
    };
};

export const MyComponent: React.FC<BaseComponentProps> = ({ component, componentKey }) => {
    const { properties, bounds } = component;
    const gridSize = boundsToGridSize(bounds);

    return (
        <GridItem
            key={componentKey}
            xs={gridSize.xs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {/* Component content */}
        </GridItem>
    );
};
```

### 2. Register Component

Add to `src/engine/components/registry/componentRegistry.ts`:

```typescript
import { MyComponent } from './MyComponent';

export const createComponentRegistry = (): ComponentRegistry => {
    const registry: ComponentRegistry = new Map();

    // ... existing registrations
    registry.set('MyComponentType', (props) => <MyComponent {...props} />);

    return registry;
};
```

### 3. Export Component

Add to `src/engine/components/registry/index.ts`:

```typescript
export { MyComponent } from './MyComponent';
```

## Component Examples

### Simple Component (Label)

```typescript
export const LabelComponent: React.FC<BaseComponentProps> = ({ component, componentKey }) => {
    const { properties, bounds } = component;
    const gridSize = boundsToGridSize(bounds);

    return (
        <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
            <Label text={properties.text || ''} sx={{ display: 'block', height: '100%' }} />
        </GridItem>
    );
};
```

### Container Component (Panel)

```typescript
export const PanelComponent: React.FC<BaseComponentProps> = ({
    component,
    componentKey,
    useAbsolutePositioning,
    allPages
}) => {
    const { children, bounds } = component;
    const gridSize = boundsToGridSize(bounds);

    if (!children || children.length === 0) {
        return (
            <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
                <Paper sx={{ p: 1, height: '100%', boxShadow: 1 }} />
            </GridItem>
        );
    }

    const { mapComponent } = require('../../mapper/component-mapper');
    const rows = groupByRow(children);

    return (
        <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
            <Paper sx={{ p: 1, height: '100%', boxShadow: 1 }}>
                <Grid container spacing={1}>
                    {rows.map((row, rowIndex) =>
                        row.map((child, colIndex) =>
                            mapComponent(child, `${componentKey}-panel-${rowIndex}-${colIndex}`, useAbsolutePositioning, allPages),
                        ),
                    )}
                </Grid>
            </Paper>
        </GridItem>
    );
};
```

### Complex Component (Table/DataGrid)

```typescript
export const TableComponent: React.FC<BaseComponentProps> = ({ component, componentKey }) => {
    const { properties, bounds } = component;
    const gridSize = boundsToGridSize(bounds);

    const adapterInfo = properties.adapterInfo;
    let columns: any[] = [];
    let rows: any[] = [];

    if (adapterInfo) {
        try {
            const adapter = typeof adapterInfo === 'string' ? JSON.parse(adapterInfo) : adapterInfo;

            if (adapter.columns && Array.isArray(adapter.columns)) {
                columns = adapter.columns.map((col: any, index: number) => ({
                    field: col.field || col.name || col.columnName || `col${index}`,
                    headerName: col.headerName || col.label || col.title || col.name || `Column ${index + 1}`,
                    width: col.width || 150,
                    type: col.type || 'string',
                    editable: col.editable || false,
                    sortable: col.sortable !== false,
                    ...col,
                }));
            }
        } catch (error) {
            console.error('Error parsing table adapterInfo:', error);
        }
    }

    if (columns.length === 0) {
        return (
            <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
                <Box sx={{ border: '1px solid #ccc', p: 2, height: '100%', minHeight: 200 }}>
                    <Label text="[DataGrid - No columns defined]" />
                </Box>
            </GridItem>
        );
    }

    return (
        <GridItem key={componentKey} xs={gridSize.xs} sx={{ minHeight: gridSize.minHeight }}>
            <Box sx={{ height: '100%', minHeight: 400, width: '100%' }}>
                <DataGrid
                    columns={columns}
                    rows={rows}
                    autoHeight={false}
                    pagination={false}
                    sx={{ height: '100%' }}
                />
            </Box>
        </GridItem>
    );
};
```

## Registry API

### Core Functions

#### `createComponentRegistry()`
Creates and populates a new component registry.

```typescript
const registry = createComponentRegistry();
```

#### `getComponentRenderer(type: string)`
Gets a component renderer by type name.

```typescript
const renderer = getComponentRenderer('Label');
if (renderer) {
    const node = renderer(props);
}
```

#### `registerComponent(type: string, renderer: ComponentRenderer)`
Registers a new component type at runtime.

```typescript
registerComponent('CustomType', (props) => <CustomComponent {...props} />);
```

#### `hasComponent(type: string)`
Checks if a component type is registered.

```typescript
if (hasComponent('Label')) {
    // Type is registered
}
```

## Component Mapper

The component mapper is now simplified to use the registry:

```typescript
export const mapComponent = (
    component: ParsedComponent,
    key: string,
    useAbsolutePositioning: boolean = false,
    allPages: PageDefinition[] = [],
): React.ReactNode => {
    const { type } = component;

    // Get the component renderer from the registry
    const renderer = getComponentRenderer(type);

    // Prepare props
    const componentProps: BaseComponentProps = {
        component,
        componentKey: key,
        useAbsolutePositioning,
        allPages,
    };

    // If renderer exists, use it; otherwise use UnknownComponent
    if (renderer) {
        return renderer(componentProps);
    }

    return <UnknownComponent {...componentProps} />;
};
```

## Registered Components

### Current Registrations

| Type | Component | Description |
|------|-----------|-------------|
| `Label` | LabelComponent | Text labels |
| `Button` | ButtonComponent | Action buttons |
| `Table` | TableComponent | DataGrid tables |
| `TextField` | TextFieldComponent | Text input fields |
| `NumberField` | TextFieldComponent | Number input fields |
| `DateField` | TextFieldComponent | Date picker fields |
| `TimeField` | TextFieldComponent | Time picker fields |
| `DateTimeField` | TextFieldComponent | DateTime picker fields |
| `CheckBox` | LabelComponent | Checkbox inputs |
| `RadioButton` | LabelComponent | Radio button inputs |
| `ComboBox` | TextFieldComponent | Dropdown selects |
| `Panel` | PanelComponent | Container panels |
| `Region` | RegionComponent | Reusable sub-pages |
| `TabbedPane` | TabbedPaneComponent | Tabbed interfaces |
| `Separator` | SeparatorComponent | Horizontal dividers |
| `Page` | PageComponent | Root page container |

### Unknown Types

Any component type not in the registry falls back to `UnknownComponent`, which:
- Displays a warning message
- Shows the unknown type name
- Renders any children if present
- Logs a console warning

## Common Utilities

### `boundsToGridSize()`

Converts EBML bounds to responsive Grid size:

```typescript
const boundsToGridSize = (bounds: { width: number; height: number }, containerWidth: number = 960) => {
    const ratio = bounds.width / containerWidth;
    const columns = Math.round(ratio * 12);
    return {
        xs: Math.max(1, Math.min(12, columns)),
        minHeight: bounds.height,
    };
};
```

### `groupByRow()`

Groups components by Y position for row-based layouts:

```typescript
const groupByRow = (components: ParsedComponent[], rowTolerance: number = 5): ParsedComponent[][] => {
    // Sort by Y then X
    const sorted = [...components].sort((a, b) => {
        if (a.bounds.y !== b.bounds.y) return a.bounds.y - b.bounds.y;
        return a.bounds.x - b.bounds.x;
    });

    // Group by similar Y values
    const rows: ParsedComponent[][] = [];
    let currentRow: ParsedComponent[] = [];
    let currentY: number | null = null;

    sorted.forEach(component => {
        if (currentY === null || Math.abs(component.bounds.y - currentY) <= rowTolerance) {
            currentRow.push(component);
            if (currentY === null) currentY = component.bounds.y;
        } else {
            if (currentRow.length > 0) rows.push(currentRow);
            currentRow = [component];
            currentY = component.bounds.y;
        }
    });

    if (currentRow.length > 0) rows.push(currentRow);
    return rows;
};
```

## Advanced Usage

### Dynamic Component Registration

Register components at runtime based on configuration:

```typescript
import { registerComponent } from './engine/components/registry';

// Register a custom component
registerComponent('CustomWidget', (props) => {
    return <CustomWidgetComponent {...props} />;
});
```

### Component Overriding

Override existing components with custom implementations:

```typescript
// Override the default Label component
registerComponent('Label', (props) => {
    return <MyCustomLabelComponent {...props} />;
});
```

### Conditional Rendering

Components can implement conditional rendering logic:

```typescript
export const ConditionalComponent: React.FC<BaseComponentProps> = ({ component }) => {
    if (component.properties.visible === 'false') {
        return null;
    }

    return <div>{/* Component content */}</div>;
};
```

## Best Practices

### 1. Component Isolation

Each component should be self-contained and not depend on other components except through the mapper.

### 2. Shared Utilities

Extract common utilities (like `boundsToGridSize`) to shared utility files if they're used across many components.

### 3. Error Handling

Always handle parsing errors and provide meaningful fallbacks:

```typescript
try {
    const parsed = JSON.parse(properties.config);
    // Use parsed data
} catch (error) {
    console.error('Error parsing config:', error);
    // Show error state
}
```

### 4. TypeScript Types

Use proper TypeScript types for all component props and state:

```typescript
interface CustomComponentProps extends BaseComponentProps {
    // Additional props
}

export const CustomComponent: React.FC<CustomComponentProps> = (props) => {
    // Component implementation
};
```

### 5. Circular Dependencies

For container components that render children, import `mapComponent` dynamically:

```typescript
// Import dynamically to avoid circular dependency
const { mapComponent } = require('../../mapper/component-mapper');
```

## Migration from Old Architecture

### Old Approach (Switch Statement)

```typescript
switch (type) {
    case 'Label':
        return <GridItem><Label text={properties.text} /></GridItem>;
    case 'Button':
        return <GridItem><Button text={properties.text} /></GridItem>;
    // ... many more cases
}
```

### New Approach (Registry)

```typescript
// In registry
registry.set('Label', (props) => <LabelComponent {...props} />);
registry.set('Button', (props) => <ButtonComponent {...props} />);

// In mapper
const renderer = getComponentRenderer(type);
return renderer ? renderer(props) : <UnknownComponent {...props} />;
```

## Future Enhancements

Planned improvements:

- [ ] Plugin system for third-party components
- [ ] Lazy loading of component renderers
- [ ] Component composition system
- [ ] Runtime component validation
- [ ] Component metadata (description, props schema, etc.)
- [ ] Visual component editor integration
- [ ] Hot-reload support for component development
- [ ] Performance profiling for component renderers

## Troubleshooting

### Component Not Rendering

**Issue**: Component type shows as "Unknown"

**Solution**:
1. Check if component type is registered in `componentRegistry.ts`
2. Verify the type name matches exactly (case-sensitive)
3. Ensure the component file is imported in the registry

### Circular Dependency Errors

**Issue**: Import cycle detected

**Solution**: Use dynamic imports for `mapComponent` in container components:

```typescript
const { mapComponent } = require('../../mapper/component-mapper');
```

### TypeScript Errors

**Issue**: Type mismatch in component props

**Solution**: Ensure component extends `BaseComponentProps`:

```typescript
export const MyComponent: React.FC<BaseComponentProps> = (props) => { ... }
```
