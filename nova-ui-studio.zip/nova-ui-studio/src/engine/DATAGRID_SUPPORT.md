# DataGrid Support for JCSTable

The UI engine now properly renders `JCSTable` components using Material-UI DataGrid with columns defined in the `adapterInfo.columns` property.

## Overview

Legacy EBML tables (`tr.com.cs.aurora.ebml.bean.swing.JCSTable`) are converted to modern DataGrid components with full column configuration support.

## EBML Table Structure

In your `ui-definition.json`, a table is defined with `adapterInfo` containing column definitions:

```json
{
  "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSTable",
  "Id": "Page.myTable",
  "Style": {
    "P": [
      {
        "Name": "bounds",
        "Text": "10,50,940,300"
      },
      {
        "Name": "adapterInfo",
        "Text": "{\"columns\": [{\"field\": \"id\", \"headerName\": \"ID\", \"width\": 100}, {\"field\": \"name\", \"headerName\": \"Name\", \"width\": 200}]}"
      }
    ]
  },
  "SubBean": []
}
```

## Column Configuration

### Basic Column Structure

```json
{
  "columns": [
    {
      "field": "id",           // Column field name (required)
      "headerName": "ID",      // Column header text
      "width": 100,            // Column width in pixels
      "type": "number",        // Data type: string, number, date, boolean
      "editable": false        // Allow editing
    },
    {
      "field": "name",
      "headerName": "Full Name",
      "width": 200,
      "type": "string"
    }
  ]
}
```

### Field Name Mapping

The engine supports multiple property names for column fields:

```typescript
field: col.field || col.name || col.columnName || `col${index}`
```

### Header Name Mapping

Multiple property names are supported for headers:

```typescript
headerName: col.headerName || col.label || col.title || col.name || `Column ${index + 1}`
```

## Column Types

DataGrid supports these column types:

- `string` - Text data (default)
- `number` - Numeric data
- `date` - Date values
- `dateTime` - Date and time
- `boolean` - True/false values
- `singleSelect` - Dropdown selection

## AdapterInfo Format

### JSON String Format

```json
{
  "Name": "adapterInfo",
  "Text": "{\"columns\": [...]}"
}
```

### JSON Object Format

```json
{
  "Name": "adapterInfo",
  "Text": {
    "columns": [...]
  }
}
```

Both formats are automatically parsed by the engine.

## Complete Example

### EBML Definition

```json
{
  "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSTable",
  "Id": "Page.employeeTable",
  "Style": {
    "P": [
      {
        "Name": "bounds",
        "Text": "10,100,940,400"
      },
      {
        "Name": "adapterInfo",
        "Text": "{\"columns\": [{\"field\": \"employeeId\", \"headerName\": \"Employee ID\", \"width\": 120, \"type\": \"number\"}, {\"field\": \"firstName\", \"headerName\": \"First Name\", \"width\": 150}, {\"field\": \"lastName\", \"headerName\": \"Last Name\", \"width\": 150}, {\"field\": \"department\", \"headerName\": \"Department\", \"width\": 200}, {\"field\": \"hireDate\", \"headerName\": \"Hire Date\", \"width\": 150, \"type\": \"date\"}, {\"field\": \"active\", \"headerName\": \"Active\", \"width\": 100, \"type\": \"boolean\"}]}"
      }
    ]
  },
  "SubBean": []
}
```

### Rendered Output

This renders as a Material-UI DataGrid with:
- 6 columns (Employee ID, First Name, Last Name, Department, Hire Date, Active)
- Proper column types (number, string, date, boolean)
- Specified column widths
- Full DataGrid features (sorting, filtering, etc.)

## DataGrid Features

The rendered DataGrid includes:

✅ **Column Headers**: Customizable text from `headerName`
✅ **Column Sizing**: Widths from `width` property (default: 150px)
✅ **Data Types**: Automatic formatting based on `type`
✅ **Sorting**: Click column headers to sort
✅ **Filtering**: Built-in column filters
✅ **Column Menu**: Column visibility, filters, sorting options
✅ **Responsive**: Adapts to container width in Grid layout

## Column Properties

### Required

- `field` (or `name`, `columnName`) - Column identifier

### Optional

| Property | Description | Default |
|----------|-------------|---------|
| `headerName` | Column header text | `Column N` |
| `width` | Column width in pixels | `150` |
| `type` | Data type | `'string'` |
| `editable` | Allow cell editing | `false` |
| `sortable` | Allow sorting | `true` |
| `filterable` | Show filter option | `true` |
| `hideable` | Allow hiding column | `true` |
| `minWidth` | Minimum width | `50` |
| `maxWidth` | Maximum width | `Infinity` |
| `flex` | Flexible width ratio | `undefined` |

## Error Handling

### No Columns Defined

If `adapterInfo` is missing or has no columns:

```
┌────────────────────────────────────┐
│ [DataGrid - No columns defined]   │
└────────────────────────────────────┘
```

### Parse Error

If `adapterInfo` JSON is invalid:
- Error logged to console
- Falls back to "No columns defined" display

## Responsive Behavior

### Grid Layout

Tables use responsive GridItem sizing:

```typescript
// 940px width table in 960px container
xs = (940 / 960) * 12 ≈ 12 columns (full width)
```

### Height

- Default minimum height: 400px
- Respects `bounds` height from EBML
- `autoHeight={false}` for fixed height

## Data Rows

Currently, the DataGrid renders with empty rows (`rows={[]}`). To populate with data:

1. **Future Enhancement**: Load data from EBML `model` or `data` properties
2. **Custom Integration**: Pass data through props
3. **API Integration**: Fetch data based on table configuration

## Advanced Column Configuration

### Custom Rendering

Columns can include custom renderers (future enhancement):

```json
{
  "field": "status",
  "headerName": "Status",
  "type": "string",
  "valueOptions": ["Active", "Inactive", "Pending"]
}
```

### Computed Columns

Derived values from other columns:

```json
{
  "field": "fullName",
  "headerName": "Full Name",
  "valueGetter": "row.firstName + ' ' + row.lastName"
}
```

### Actions Column

Column with action buttons:

```json
{
  "field": "actions",
  "type": "actions",
  "headerName": "Actions",
  "width": 150
}
```

## Migration from Legacy

### Legacy JCSTable
```xml
<JCSTable id="myTable" bounds="10,50,940,300">
  <columns>
    <column field="id" header="ID" width="100"/>
    <column field="name" header="Name" width="200"/>
  </columns>
</JCSTable>
```

### New EBML Format
```json
{
  "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSTable",
  "Style": {
    "P": [
      {"Name": "bounds", "Text": "10,50,940,300"},
      {"Name": "adapterInfo", "Text": "{\"columns\": [{\"field\": \"id\", \"headerName\": \"ID\", \"width\": 100}, {\"field\": \"name\", \"headerName\": \"Name\", \"width\": 200}]}"}
    ]
  }
}
```

## Best Practices

### 1. Define Column Widths

Always specify width to ensure proper layout:

```json
{"field": "id", "headerName": "ID", "width": 100}
```

### 2. Use Appropriate Types

Set correct types for better formatting:

```json
{"field": "amount", "type": "number", "width": 120}
{"field": "date", "type": "date", "width": 150}
```

### 3. Full Width Tables

For full-width tables, use bounds width ≈ 960:

```json
{"Name": "bounds", "Text": "10,50,940,300"}
```

### 4. Minimum Height

Ensure tables have sufficient height:

```json
{"Name": "bounds", "Text": "10,50,940,400"}  // 400px height
```

## Troubleshooting

### Table Not Rendering

**Issue**: Shows "[DataGrid - No columns defined]"

**Solutions**:
1. Check `adapterInfo` property exists
2. Verify JSON syntax in `adapterInfo.Text`
3. Ensure `columns` array exists and is not empty

### Columns Not Showing

**Issue**: Empty DataGrid

**Solution**: Check column definitions have valid `field` property

### Parse Errors

**Issue**: Console shows "Error parsing table adapterInfo"

**Solution**: Validate JSON format:
```bash
echo '{"columns":[...]}' | jq
```

### Wrong Column Names

**Issue**: Shows "Column 1", "Column 2" instead of proper names

**Solution**: Add `headerName` property to each column

## Future Enhancements

Planned improvements:

- [ ] Load row data from EBML `model` property
- [ ] Support for editable columns with save handlers
- [ ] Custom cell renderers
- [ ] Action columns with buttons
- [ ] Pagination configuration
- [ ] Export to CSV/Excel
- [ ] Column grouping
- [ ] Row grouping
- [ ] Aggregation (sum, avg, etc.)
