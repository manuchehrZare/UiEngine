/* eslint-disable */
/**
 * Example: Using the UI Engine components
 * This file demonstrates how to use the UI engine in different ways
 */

import type { FC } from 'react';
import { Box, Paper, Typography } from '../../lib';
import { AdminPanel, PageRenderer, usePageDefinitions, usePage } from '../index';

/**
 * Example 1: Using AdminPanel (Full admin interface)
 */
export const AdminPanelExample: FC = () => {
    return <AdminPanel useAbsolutePositioning={true} />;
};

/**
 * Example 2: Using PageRenderer with a specific page
 */
export const SinglePageExample: FC = () => {
    const { page, loading, error, allPages } = usePage('MOP001_ADMIN_SPECIALITY_DEFINITION');

    if (loading) {
        return <Box sx={{ p: 3 }}>Loading page...</Box>;
    }

    if (error) {
        return (
            <Box sx={{ p: 3 }}>
                <Typography color="error">Error: {error.message}</Typography>
            </Box>
        );
    }

    if (!page) {
        return <Box sx={{ p: 3 }}>Page not found</Box>;
    }

    return (
        <Box sx={{ p: 3 }}>
            <Typography variant="h4" gutterBottom>
                {page.MenuName}
            </Typography>
            <PageRenderer pageDefinition={page} useAbsolutePositioning={true} allPages={allPages} />
        </Box>
    );
};

/**
 * Example 3: Listing all pages
 */
export const PageListExample: FC = () => {
    const { pages, loading, error } = usePageDefinitions();

    if (loading) return <Box sx={{ p: 3 }}>Loading...</Box>;
    if (error) return <Box sx={{ p: 3 }}>Error: {error.message}</Box>;

    return (
        <Box sx={{ p: 3 }}>
            <Typography variant="h4" gutterBottom>
                Available Pages ({pages.length})
            </Typography>
            {pages.map((page) => (
                <Paper key={page.Name} sx={{ p: 2, mb: 2 }}>
                    <Typography variant="h6">{page.MenuName}</Typography>
                    <Typography variant="body2" color="text.secondary">
                        Screen Code: {page.ScreenCode}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        Module: {page.ModuleName}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        Type: {page.Type}
                    </Typography>
                </Paper>
            ))}
        </Box>
    );
};

/**
 * Example 4: Custom page selector
 */
export const CustomPageSelectorExample: FC = () => {
    const { pages, loading } = usePageDefinitions();
    const [selectedPageName, setSelectedPageName] = React.useState<string>('');
    const { page } = usePage(selectedPageName);

    if (loading) return <Box sx={{ p: 3 }}>Loading...</Box>;

    return (
        <Box sx={{ p: 3 }}>
            <Paper sx={{ p: 2, mb: 2 }}>
                <Typography variant="h6" gutterBottom>
                    Select a Page
                </Typography>
                <select
                    value={selectedPageName}
                    onChange={(e) => setSelectedPageName(e.target.value)}
                    style={{ width: '100%', padding: '8px', fontSize: '14px' }}
                >
                    <option value="">-- Select a page --</option>
                    {pages.map((p) => (
                        <option key={p.Name} value={p.Name}>
                            {p.MenuName} ({p.ScreenCode})
                        </option>
                    ))}
                </select>
            </Paper>

            {page && <PageRenderer pageDefinition={page} useAbsolutePositioning={true} allPages={pages} />}
        </Box>
    );
};

/**
 * Example 5: Using with responsive layout (no absolute positioning)
 */
export const ResponsivePageExample: FC = () => {
    const { page, allPages } = usePage('MOP001_ADMIN_SPECIALITY_DEFINITION');

    if (!page) return null;

    return (
        <Box sx={{ p: 3 }}>
            <Typography variant="h4" gutterBottom>
                Responsive Layout Mode
            </Typography>
            <PageRenderer pageDefinition={page} useAbsolutePositioning={false} allPages={allPages} />
        </Box>
    );
};

// Don't forget to import React for state management
import React from 'react';
