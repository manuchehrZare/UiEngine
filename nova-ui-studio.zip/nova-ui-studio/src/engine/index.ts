/* eslint-disable */
/**
 * UI Engine - Main Entry Point
 *
 * This module provides the UI engine that renders legacy EBML pages
 * from the Java application into React components using the @Lib components.
 */

// Components
export { default as AdminPanel } from './components/AdminPanel';
export { default as PageRenderer } from './components/PageRenderer';

// Hooks
export { usePageDefinitions, usePage } from './hooks/usePageDefinitions';

// Parser utilities
export * from './parser/ebml-parser';

// Component mapper
export { mapComponent } from './mapper/component-mapper';

// Types
export type {
    EbmlProperty,
    EbmlStyle,
    EbmlBean,
    EbmlStructure,
    EbmlInterface,
    EbmlContent,
    PageDefinition,
    ComponentBounds,
    ParsedComponent,
    EbmlComponentMap,
} from './types/ebml.types';
export { EbmlComponentClass } from './types/ebml.types';
