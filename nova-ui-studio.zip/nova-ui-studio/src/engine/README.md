# UI Engine

A React-based UI rendering engine that converts legacy EBML (XML-based UI schema) from Java applications into modern React components.

## Overview

This UI engine allows you to:
- Load and parse EBML UI definitions from `ui-definition.json`
- Render legacy Java Swing-based UIs using modern React components from `@Lib`
- Navigate through multiple pages in an admin panel interface
- Search and filter pages by name, screen code, or module

## Architecture

The UI engine consists of several key modules:

### 1. Types (`types/ebml.types.ts`)
Defines TypeScript interfaces for EBML schema structure:
- `PageDefinition`: Complete page definition with metadata
- `EbmlBean`: Component bean structure from EBML
- `ParsedComponent`: Parsed component ready for React rendering
- `EbmlComponentClass`: Enum of supported EBML component types

### 2. Parser (`parser/ebml-parser.ts`)
Utilities for parsing EBML structure:
- `parseBean()`: Converts EBML bean to ParsedComponent
- `extractProperties()`: Extracts component properties
- `getBounds()`: Parses component positioning and sizing
- `findBeanById()`: Searches for specific components

### 3. Component Mapper (`mapper/component-mapper.tsx`)
Maps EBML components to React components:
- Converts Java Swing components to React equivalents
- Handles layout and positioning
- Maps properties to component props

### 4. Components

#### AdminPanel (`components/AdminPanel.tsx`)
Main UI with:
- Left sidebar navigation menu
- Search functionality
- Grouped pages by module
- Page content area
- Page metadata display

#### PageRenderer (`components/PageRenderer.tsx`)
Renders individual pages:
- Parses EBML structure
- Maps components to React
- Error handling and display

### 5. Hooks (`hooks/usePageDefinitions.ts`)
React hooks for data management:
- `usePageDefinitions()`: Loads all page definitions
- `usePage(identifier)`: Gets a specific page by name/code

## Usage

### Accessing the UI Engine

Navigate to `/ui-engine` route in your application.

### Using AdminPanel Component

```tsx
import { AdminPanel } from '../engine';

function App() {
    return <AdminPanel useAbsolutePositioning={true} />;
}
```

### Using PageRenderer Directly

```tsx
import { PageRenderer, usePage } from '../engine';

function MyPage() {
    const { page, loading, error } = usePage('MOP001');

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error.message}</div>;
    if (!page) return <div>Page not found</div>;

    return <PageRenderer pageDefinition={page} />;
}
```

### Component Mapping

The engine maps EBML/Java Swing components to React components:

| EBML Component | React Component |
|---------------|-----------------|
| JCSLabel | Label |
| JCSTextField | Input |
| JCSNumberField | NumberInput |
| JCSDateField | DatePicker |
| JCSTimeField | TimePicker |
| JCSDateTimeField | DateTimePicker |
| JCSCheckBox | Checkbox |
| JCSRadioButton | Radio |
| JCSComboBox | Select |
| JCSButton | Button |
| JCSTable | DataGrid |
| JCSPanel | Paper |
| JCSTabbedPane | Tab |
| JSeparator | Divider |

## Data Structure

### ui-definition.json

The engine expects a JSON file at `src/assets/docs/ui-definition.json` with this structure:

```json
[
  {
    "Name": "PAGE_NAME",
    "EbmlName": "PAGE_NAME.ebml",
    "ModuleName": "module-name",
    "Type": "page",
    "ScreenCode": "SCR001",
    "MenuName": "Page Display Name",
    "EbmlContent": {
      "Interface": {
        "Structure": {
          "Bean": {
            "Class": "tr.com.cs.aurora.ebml.bean.swing.JCSPage",
            "Id": "Page",
            "Style": {
              "P": [
                {
                  "Name": "pageSize",
                  "Text": "960,700"
                },
                {
                  "Name": "title",
                  "Text": "Page Title"
                }
              ]
            },
            "SubBean": [...]
          }
        }
      }
    }
  }
]
```

## Features

### 1. Search & Filter
- Real-time search across page names, screen codes, and modules
- Instant filtering of navigation menu

### 2. Module Grouping
- Pages automatically grouped by module
- Collapsible module sections in navigation

### 3. Layout Options
- **Absolute Positioning**: Components positioned exactly as in legacy UI
- **Relative Positioning**: Modern responsive layout

### 4. Error Handling
- Graceful error display for parsing issues
- Loading states
- Unknown component type warnings

## Extending the Engine

### Adding New Component Mappings

Edit [mapper/component-mapper.tsx](src/engine/mapper/component-mapper.tsx):

```tsx
case 'NewComponentType':
    return (
        <YourComponent
            {...commonProps}
            // Map properties
            sx={{ ...style }}
        />
    );
```

### Custom Parsers

Create custom property parsers in [parser/ebml-parser.ts](src/engine/parser/ebml-parser.ts):

```tsx
export const parseCustomProperty = (bean: EbmlBean): CustomType => {
    const value = getProperty(bean, 'customProp');
    // Parse and return
};
```

## Development

### File Structure

```
src/engine/
├── components/
│   ├── AdminPanel.tsx      # Main admin interface
│   └── PageRenderer.tsx    # Page rendering component
├── hooks/
│   └── usePageDefinitions.ts  # Data loading hooks
├── mapper/
│   └── component-mapper.tsx   # EBML to React mapping
├── parser/
│   └── ebml-parser.ts      # EBML parsing utilities
├── types/
│   └── ebml.types.ts       # TypeScript definitions
├── index.ts                # Public API exports
└── README.md              # This file
```

### Testing

To test the engine:
1. Ensure `ui-definition.json` is properly formatted
2. Navigate to `/ui-engine`
3. Select a page from the menu
4. Verify component rendering

## Troubleshooting

### Pages Not Loading
- Check browser console for fetch errors
- Verify `ui-definition.json` path and format
- Check JSON syntax validity

### Component Not Rendering
- Check console for unknown component warnings
- Verify EBML bean structure
- Add mapping in `component-mapper.tsx`

### Layout Issues
- Try toggling `useAbsolutePositioning` prop
- Check bounds values in EBML properties
- Verify CSS conflicts

## Future Enhancements

Potential improvements:
- [ ] Add data binding support
- [ ] Implement event handlers from EBML
- [ ] Support for custom validation rules
- [ ] Export/import page definitions
- [ ] Visual page editor
- [ ] Component preview mode
- [ ] Responsive layout conversion
- [ ] Theme customization per page
