/* eslint-disable */
/**
 * EBML Parser
 * Parses EBML bean structure and extracts properties
 */

import type { EbmlBean, EbmlProperty, ComponentBounds, ParsedComponent } from '../types/ebml.types';

/**
 * Parse bounds string (e.g., "15,40,110,20") to ComponentBounds object
 */
export const parseBounds = (boundsText: string): ComponentBounds => {
    const [x, y, width, height] = boundsText.split(',').map(Number);
    return { x, y, width, height };
};

/**
 * Extract properties from EBML Style object
 */
export const extractProperties = (bean: EbmlBean): Record<string, any> => {
    const properties: Record<string, any> = {};

    if (!bean.Style?.P) {
        return properties;
    }

    bean.Style.P.forEach((prop: EbmlProperty) => {
         if (prop.Name) {
      // For properties with Columns (like adapterInfo), use Columns instead of Text
      if (prop.Columns) {
                properties[prop.Name] = prop.Columns;
      } else if (prop.Text !== undefined) {
                properties[prop.Name] = prop.Text;
      }
    }
    });

    return properties;
};

/**
 * Get property value by name
 */
export const getProperty = (bean: EbmlBean, propertyName: string): string | undefined => {
    if (!bean.Style?.P) {
        return undefined;
    }

    const prop = bean.Style.P.find((p: EbmlProperty) => p.Name === propertyName);
    return prop?.Text;
};

/**
 * Get bounds property
 */
export const getBounds = (bean: EbmlBean): ComponentBounds | null => {
    const boundsText = getProperty(bean, 'bounds');
    if (!boundsText) {
        return null;
    }
    return parseBounds(boundsText);
};

/**
 * Extract component type from Java class name
 * e.g., "tr.com.cs.aurora.ebml.bean.swing.JCSLabel" -> "Label"
 */
export const extractComponentType = (className: string): string => {
    const parts = className.split('.');
    const componentName = parts[parts.length - 1];

    // Remove JCS prefix if present
    if (componentName.startsWith('JCS')) {
        return componentName.substring(3);
    }

    // Remove J prefix for standard Swing components
    if (componentName.startsWith('J')) {
        return componentName.substring(1);
    }

    return componentName;
};

/**
 * Parse EBML bean to ParsedComponent
 */
export const parseBean = (bean: EbmlBean): ParsedComponent => {
    const properties = extractProperties(bean);
    const bounds = getBounds(bean) || { x: 0, y: 0, width: 100, height: 20 };
    const type = extractComponentType(bean.Class);

    const component: ParsedComponent = {
        id: bean.Id,
        type,
        bounds,
        properties,
    };

    // Recursively parse children
    if (bean.SubBean && bean.SubBean.length > 0) {
        component.children = bean.SubBean.map(parseBean);
    }

    return component;
};

/**
 * Check if child bounds are completely inside parent bounds
 */
const isInsideBounds = (child: ParsedComponent, parent: ParsedComponent): boolean => {
    const c = child.bounds;
    const p = parent.bounds;

    return (
        c.x >= p.x &&
        c.y >= p.y &&
        c.x + c.width <= p.x + p.width &&
        c.y + c.height <= p.y + p.height
    );
};

/**
 * Get bounds area for sorting
 */
const getBoundsArea = (component: ParsedComponent): number => {
    return component.bounds.width * component.bounds.height;
};

/**
 * Reorganize flat children by nesting them inside their parent containers based on bounds
 * This handles cases where beans are flattened at root level but should be nested
 */
export const nestComponentsByBounds = (component: ParsedComponent): ParsedComponent => {
    if (!component.children || component.children.length === 0) {
        return component;
    }

    // First, recursively process all children
    const processedChildren = component.children.map(child => nestComponentsByBounds(child));

    // Separate containers (Panel, Region, TabbedPane) from other components
    const containers: ParsedComponent[] = [];
    const nonContainers: ParsedComponent[] = [];

    processedChildren.forEach(child => {
        if (['Panel', 'Region', 'TabbedPane', 'TabPage'].includes(child.type)) {
            containers.push(child);
        } else {
            nonContainers.push(child);
        }
    });

    // Sort containers by area (smallest first) to find the tightest fit
    containers.sort((a, b) => getBoundsArea(a) - getBoundsArea(b));

    // For each non-container, find if it should be inside a container
    const remainingChildren: ParsedComponent[] = [...containers];

    nonContainers.forEach(child => {
        // Find the smallest container that contains this child
        let bestContainer: ParsedComponent | null = null;

        for (const container of containers) {
            if (isInsideBounds(child, container)) {
                bestContainer = container;
                break; // Since sorted by area, first match is smallest
            }
        }

        if (bestContainer) {
            // Add child to container's children
            if (!bestContainer.children) {
                bestContainer.children = [];
            }

            // Convert bounds to be relative to the container
            const relativeChild: ParsedComponent = {
                ...child,
                bounds: {
                    x: child.bounds.x - bestContainer.bounds.x,
                    y: child.bounds.y - bestContainer.bounds.y,
                    width: child.bounds.width,
                    height: child.bounds.height,
                },
            };

            bestContainer.children.push(relativeChild);
        } else {
            // No container found, keep at current level
            remainingChildren.push(child);
        }
    });

    // Sort remaining children by position
    remainingChildren.sort((a, b) => {
        if (Math.abs(a.bounds.y - b.bounds.y) > 10) {
            return a.bounds.y - b.bounds.y;
        }
        return a.bounds.x - b.bounds.x;
    });

    return {
        ...component,
        children: remainingChildren,
    };
};

/**
 * Parse EBML bean and reorganize by bounds containment
 */
export const parseBeanWithNesting = (bean: EbmlBean): ParsedComponent => {
    const parsed = parseBean(bean);
    return nestComponentsByBounds(parsed);
};

/**
 * Parse page size property
 */
export const parsePageSize = (pageSizeText: string): { width: number; height: number } => {
    const [width, height] = pageSizeText.split(',').map(Number);
    return { width, height };
};

/**
 * Get all beans as flat array (depth-first traversal)
 */
export const flattenBeans = (bean: EbmlBean): EbmlBean[] => {
    const result: EbmlBean[] = [bean];

    if (bean.SubBean && bean.SubBean.length > 0) {
        bean.SubBean.forEach((subBean) => {
            result.push(...flattenBeans(subBean));
        });
    }

    return result;
};

/**
 * Find bean by ID
 */
export const findBeanById = (rootBean: EbmlBean, id: string): EbmlBean | null => {
    if (rootBean.Id === id) {
        return rootBean;
    }

    if (rootBean.SubBean && rootBean.SubBean.length > 0) {
        for (const subBean of rootBean.SubBean) {
            const found = findBeanById(subBean, id);
            if (found) {
                return found;
            }
        }
    }

    return null;
};
