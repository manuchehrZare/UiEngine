# Responsive Grid Layout

The UI engine now uses **responsive Grid/GridItem layouts** instead of absolute pixel positioning, making pages adapt to different screen sizes.

## Overview

Legacy EBML pages were designed for fixed 960×700px windows. The new implementation converts these fixed layouts into responsive Material-UI Grid layouts that work on any screen size.

## How It Works

### 1. Pixel to Grid Conversion

The legacy `bounds` property (e.g., `"15,40,110,20"` = x, y, width, height) is converted to responsive grid columns:

```typescript
// Legacy: 960px wide window with 12-column grid
// Component width of 240px → 3 columns (240/960 * 12 = 3)
// Component width of 480px → 6 columns (480/960 * 12 = 6)
// Component width of 960px → 12 columns (full width)

const pixelsToGridColumns = (width: number, containerWidth: number = 960): number => {
    const ratio = width / containerWidth;
    const columns = Math.round(ratio * 12);
    return Math.max(1, Math.min(12, columns));
};
```

### 2. Row Grouping

Components are automatically grouped into rows based on their Y position:

- Components with similar Y values (within 5px tolerance) are placed in the same row
- Components are sorted by Y position (top to bottom), then X position (left to right)
- Each row becomes a Grid container with the components as GridItems

```typescript
// Example: Three components at Y=10, Y=12, Y=50
// Results in two rows:
// Row 1: [Component1 (Y=10), Component2 (Y=12)]  // Similar Y values
// Row 2: [Component3 (Y=50)]                     // Different Y value
```

### 3. Grid Structure

Pages are rendered as nested Grid containers:

```tsx
<Box>
  <Grid container spacing={2}>
    {/* Row 1 */}
    <GridItem xs={3}>Label</GridItem>
    <GridItem xs={9}>Input</GridItem>

    {/* Row 2 */}
    <GridItem xs={6}>Button 1</GridItem>
    <GridItem xs={6}>Button 2</GridItem>
  </Grid>
</Box>
```

## Benefits

### ✅ Responsive Design
- Pages adapt to different screen sizes
- Components reflow on smaller screens
- No horizontal scrolling on mobile

### ✅ Modern Layout
- Uses CSS Grid instead of absolute positioning
- Maintains proper spacing with MUI `spacing` prop
- Consistent padding and margins

### ✅ Accessibility
- Proper document flow for screen readers
- Better keyboard navigation
- Semantic HTML structure

### ✅ Maintainability
- Easier to modify layouts
- Predictable behavior across devices
- Standard MUI Grid patterns

## Layout Examples

### Form Layout (Label + Input)
```
Legacy (960px):
┌─────────────────────────────────────────┐
│ [Label: 110px]  [Input: 300px]         │
└─────────────────────────────────────────┘

Responsive Grid:
┌─────────────────────────────────────────┐
│ [Label: 2col]  [Input: 10col]          │  Desktop
└─────────────────────────────────────────┘

┌──────────────┐
│ [Label: 12]  │  Mobile
│ [Input: 12]  │  (stacks vertically)
└──────────────┘
```

### Button Row
```
Legacy (960px):
┌─────────────────────────────────────────┐
│ [Btn1: 200px]  [Btn2: 200px]  [Btn3]   │
└─────────────────────────────────────────┘

Responsive Grid:
┌─────────────────────────────────────────┐
│ [Btn1: 4col]  [Btn2: 4col]  [Btn3: 4]  │
└─────────────────────────────────────────┘
```

## Configuration

### Default Mode: Responsive

By default, pages use responsive Grid layout:

```tsx
<AdminPanel useAbsolutePositioning={false} />  // Default
```

### Absolute Positioning Mode

For exact pixel-perfect legacy layout (if needed):

```tsx
<AdminPanel useAbsolutePositioning={true} />
```

## Grid Properties

### GridItem Props

Each component is wrapped in a `GridItem` with:

```tsx
<GridItem
    xs={calculatedColumns}     // Responsive width (1-12)
    sx={{
        minHeight: originalHeight,  // Preserve minimum height
    }}
>
    {/* Component content */}
</GridItem>
```

### Grid Container Props

Containers (Page, Panel, Region) use:

```tsx
<Grid
    container
    spacing={1 | 2}  // Spacing between items
>
    {/* GridItems */}
</Grid>
```

## Component-Specific Behavior

### Separator
Always takes full width (12 columns):
```tsx
<GridItem xs={12}>
    <Divider />
</GridItem>
```

### Panel
Creates nested Grid with its children:
```tsx
<GridItem xs={calculatedColumns}>
    <Paper>
        <Grid container spacing={1}>
            {/* Panel children */}
        </Grid>
    </Paper>
</GridItem>
```

### Tab/TabbedPane
Each tab content uses Grid layout:
```tsx
<Tab>
    <TabItem>
        <Grid container spacing={1}>
            {/* Tab content */}
        </Grid>
    </TabItem>
</Tab>
```

### Region
Renders referenced region content in Grid:
```tsx
<GridItem xs={calculatedColumns}>
    <Grid container spacing={1}>
        {/* Region children */}
    </Grid>
</GridItem>
```

## Conversion Formula

### Width Conversion
```
Grid Columns = round((componentWidth / 960) * 12)
Minimum: 1 column
Maximum: 12 columns
```

### Height Preservation
```
minHeight = componentHeight (in pixels)
```

### Spacing
```
Page level: spacing={2}   (16px gap)
Panel level: spacing={1}  (8px gap)
Tab level: spacing={1}    (8px gap)
```

## Fallback Behavior

If `useAbsolutePositioning={true}`, components use absolute positioning with pixel values:

```tsx
<Box sx={{
    position: 'absolute',
    left: x,
    top: y,
    width: width,
    height: height,
}}>
    {/* Component */}
</Box>
```

## Row Grouping Algorithm

```typescript
1. Sort components by Y position, then X position
2. Group components with Y values within 5px of each other
3. Each group becomes a row in the Grid
4. Components in the row are rendered left to right
```

Example:
```
Input Components:
- Label: (x=10, y=20, w=100, h=20)
- Input: (x=120, y=22, w=200, h=20)  // Similar Y (within 5px)
- Button: (x=10, y=50, w=150, h=30)  // Different Y

Output Grid:
Row 1: [Label (xs=2), Input (xs=4)]
Row 2: [Button (xs=3)]
```

## Best Practices

### 1. Test on Different Screen Sizes
```tsx
// Responsive layout adapts automatically
<PageRenderer pageDefinition={page} useAbsolutePositioning={false} />
```

### 2. Use Absolute Mode for Exact Layouts
```tsx
// When pixel-perfect legacy layout is required
<PageRenderer pageDefinition={page} useAbsolutePositioning={true} />
```

### 3. Consistent Spacing
Grid spacing is automatically applied - no manual margin needed

### 4. Full-Width Components
Components with width ≈ 960px automatically become full-width (12 columns)

## Migration Notes

### From Legacy to Responsive

**Before (Legacy):**
- Fixed 960×700px window
- Absolute pixel positioning
- No mobile support

**After (Responsive):**
- Fluid layout (any screen size)
- Grid-based responsive design
- Mobile-friendly

### Compatibility

- ✅ All existing EBML pages work automatically
- ✅ Regions work with Grid layout
- ✅ Nested panels maintain proper structure
- ✅ Tabs flow responsively

## Troubleshooting

### Components Overlap
**Issue**: Components appear on top of each other

**Solution**: Check Y positions - components with similar Y values should be in the same row

### Wrong Column Sizes
**Issue**: Component takes up too much/little space

**Solution**: Adjust the containerWidth (default 960) or component width in EBML

### Layout Looks Different
**Issue**: Responsive layout doesn't match legacy exactly

**Solution**: Use `useAbsolutePositioning={true}` for pixel-perfect legacy layout
