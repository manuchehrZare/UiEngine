/* eslint-disable */
/**
 * EBML Schema Type Definitions
 * These types represent the structure of EBML UI definitions from the legacy Java application
 */

export interface EbmlProperty {
    Name: string;
    Text: string;
    Columns?: any;
    Id?: string | null;
    M?: any;
    Rule?: any;
    Var?: any;
    N?: any;
    Comp?: any;
}

export interface EbmlStyle {
    P: EbmlProperty[];
}

export interface EbmlBean {
    Style: EbmlStyle;
    Class: string;
    Id: string;
    Text?: string | null;
    SubBean: EbmlBean[];
}

export interface EbmlStructure {
    Bean: EbmlBean;
}

export interface EbmlInterface {
    Structure: EbmlStructure;
}

export interface EbmlContent {
    Interface: EbmlInterface;
}

export interface PageDefinition {
    Name: string;
    EbmlName: string;
    ModuleName: string;
    Type: 'page' | 'popup' | 'region' | 'screen';
    ScreenCode: string;
    MenuName: string;
    EbmlContent: EbmlContent;
}

/**
 * Component mapping types
 */
export interface ComponentBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface ParsedComponent {
    id: string;
    type: string;
    bounds: ComponentBounds;
    properties: Record<string, any>;
    children?: ParsedComponent[];
}

/**
 * Known EBML component classes and their React counterparts
 */
export enum EbmlComponentClass {
    // Container components
    PAGE = 'tr.com.cs.aurora.ebml.bean.swing.JCSPage',
    PANEL = 'tr.com.cs.aurora.ebml.bean.swing.JCSPanel',
    REGION = 'tr.com.cs.aurora.ebml.bean.swing.JCSRegion',
    TABBED_PANE = 'tr.com.cs.aurora.ebml.bean.swing.JCSTabbedPane',
    TAB = 'tr.com.cs.aurora.ebml.bean.swing.JCSTab',

    // Form components
    TEXT_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSTextField',
    TEXT_AREA = 'tr.com.cs.aurora.ebml.bean.swing.JCSTextArea',
    NUMBER_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSNumberField',
    DATE_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSDateField',
    TIME_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSTimeField',
    DATETIME_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSDateTimeField',
    CHECKBOX = 'tr.com.cs.aurora.ebml.bean.swing.JCSCheckBox',
    RADIO = 'tr.com.cs.aurora.ebml.bean.swing.JCSRadioButton',
    COMBOBOX = 'tr.com.cs.aurora.ebml.bean.swing.JCSComboBox',
    CURRENCY_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSCurrencyField',

    // Display components
    LABEL = 'tr.com.cs.aurora.ebml.bean.swing.JCSLabel',
    TABLE = 'tr.com.cs.aurora.ebml.bean.swing.JCSTable',
    BUTTON = 'tr.com.cs.aurora.ebml.bean.swing.JCSButton',
    HANDLEBUTTON = 'tr.com.cs.aurora.ebml.bean.swing.JCSHandleButtonField',

    // Other components
    SEPARATOR = 'tr.com.cs.aurora.ebml.bean.swing.JSeparator',
}

export type EbmlComponentMap = {
    [key in EbmlComponentClass]?: string;
};
