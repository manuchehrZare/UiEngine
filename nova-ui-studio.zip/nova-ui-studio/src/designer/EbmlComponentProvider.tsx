/* eslint-disable */
/**
 * EBML Component Provider
 * Provides all EBML engine components to the designer
 */

import type { ComponentDefinition } from './types';
import { registerComponentProvider } from './ComponentProvider';

/**
 * EBML component provider - loads all EBML engine components
 */
export const ebmlComponentProvider = (): ComponentDefinition[] => {
    return [
        // Input Components
        {
            type: 'TextField',
            name: 'Text Field',
            icon: '📝',
            category: 'Input',
            defaultProps: {
                name: 'textField',
                label: 'Text Field',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'textField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Text Field' },
                { name: 'placeholder', label: 'Placeholder', type: 'string' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
                { name: 'fullWidth', label: 'Full Width', type: 'boolean', defaultValue: true },
            ],
        },
        {
            type: 'TextArea',
            name: 'Text Area',
            icon: '📄',
            category: 'Input',
            defaultProps: {
                name: 'textArea',
                label: 'Text Area',
                rows: 4,
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'textArea' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Text Area' },
                { name: 'placeholder', label: 'Placeholder', type: 'string' },
                { name: 'rows', label: 'Rows', type: 'number', defaultValue: 4 },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'TextPane',
            name: 'Text Pane',
            icon: '📃',
            category: 'Input',
            defaultProps: {
                name: 'textPane',
                label: 'Text Pane',
                rows: 6,
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'textPane' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Text Pane' },
                { name: 'rows', label: 'Rows', type: 'number', defaultValue: 6 },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'NumberField',
            name: 'Number Field',
            icon: '🔢',
            category: 'Input',
            defaultProps: {
                name: 'numberField',
                label: 'Number Field',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'numberField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Number Field' },
                { name: 'min', label: 'Min', type: 'number' },
                { name: 'max', label: 'Max', type: 'number' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'CurrencyField',
            name: 'Currency Field',
            icon: '💰',
            category: 'Input',
            defaultProps: {
                name: 'currencyField',
                label: 'Currency Field',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'currencyField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Currency Field' },
                { name: 'currency', label: 'Currency', type: 'string', defaultValue: 'USD' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'MaskField',
            name: 'Mask Field',
            icon: '🎭',
            category: 'Input',
            defaultProps: {
                name: 'maskField',
                label: 'Mask Field',
                mask: '(000) 000-0000',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'maskField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Mask Field' },
                { name: 'mask', label: 'Mask', type: 'string', defaultValue: '(000) 000-0000' },
                { name: 'placeholder', label: 'Placeholder', type: 'string' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },

        // Date/Time Components
        {
            type: 'DateField',
            name: 'Date Picker',
            icon: '📅',
            category: 'Input',
            defaultProps: {
                name: 'dateField',
                label: 'Date',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'dateField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Date' },
                { name: 'format', label: 'Format', type: 'string', defaultValue: 'MM/dd/yyyy' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'TimeField',
            name: 'Time Picker',
            icon: '⏰',
            category: 'Input',
            defaultProps: {
                name: 'timeField',
                label: 'Time',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'timeField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Time' },
                { name: 'format', label: 'Format', type: 'string', defaultValue: 'HH:mm' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'DateTimeField',
            name: 'DateTime Picker',
            icon: '📆',
            category: 'Input',
            defaultProps: {
                name: 'dateTimeField',
                label: 'Date & Time',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'dateTimeField' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Date & Time' },
                { name: 'format', label: 'Format', type: 'string', defaultValue: 'MM/dd/yyyy HH:mm' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
            ],
        },

        // Selection Components
        {
            type: 'ComboBox',
            name: 'Select / ComboBox',
            icon: '📋',
            category: 'Input',
            defaultProps: {
                name: 'comboBox',
                label: 'Select',
                options: [],
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'comboBox' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Select' },
                { name: 'options', label: 'Options', type: 'array', defaultValue: [] },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'required', label: 'Required', type: 'boolean', defaultValue: false },
                { name: 'multiple', label: 'Multiple', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'CheckBox',
            name: 'Checkbox',
            icon: '☑️',
            category: 'Input',
            defaultProps: {
                name: 'checkbox',
                label: 'Checkbox',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'checkbox' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Checkbox' },
                { name: 'checked', label: 'Checked', type: 'boolean', defaultValue: false },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'RadioButton',
            name: 'Radio Button',
            icon: '🔘',
            category: 'Input',
            defaultProps: {
                name: 'radioButton',
                label: 'Radio Option',
                value: 'option1',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'radioButton' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Radio Option' },
                { name: 'value', label: 'Value', type: 'string', defaultValue: 'option1' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'ButtonGroup',
            name: 'Radio Group',
            icon: '🔵',
            category: 'Input',
            defaultProps: {
                name: 'buttonGroup',
                label: 'Radio Group',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'buttonGroup' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Radio Group' },
                { name: 'orientation', label: 'Orientation', type: 'select', options: [
                    { label: 'Horizontal', value: 'horizontal' },
                    { label: 'Vertical', value: 'vertical' },
                ], defaultValue: 'horizontal' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },

        // File Components
        {
            type: 'FilePicker',
            name: 'File Selector',
            icon: '📁',
            category: 'Input',
            defaultProps: {
                name: 'filePicker',
                label: 'Select File',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'filePicker' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Select File' },
                { name: 'accept', label: 'Accept', type: 'string', description: 'File types to accept (e.g., .pdf,.doc)' },
                { name: 'multiple', label: 'Multiple', type: 'boolean', defaultValue: false },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },

        // Button Components
        {
            type: 'HandleButtonField',
            name: 'Handle Button',
            icon: '🔧',
            category: 'Input',
            defaultProps: {
                name: 'handleButton',
                text: 'Handle',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'handleButton' },
                { name: 'text', label: 'Text', type: 'string', defaultValue: 'Handle' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },

        // Layout Components
        {
            type: 'Panel',
            name: 'Panel',
            icon: '🖼️',
            category: 'Layout',
            defaultProps: {
                title: 'Panel',
            },
            propertySchema: [
                { name: 'title', label: 'Title', type: 'string', defaultValue: 'Panel' },
                { name: 'collapsible', label: 'Collapsible', type: 'boolean', defaultValue: false },
                { name: 'collapsed', label: 'Collapsed', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'Region',
            name: 'Region',
            icon: '📍',
            category: 'Layout',
            defaultProps: {
                name: 'region',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'region' },
                { name: 'direction', label: 'Direction', type: 'select', options: [
                    { label: 'Row', value: 'row' },
                    { label: 'Column', value: 'column' },
                ], defaultValue: 'row' },
            ],
        },
        {
            type: 'TabbedPane',
            name: 'Tabbed Pane',
            icon: '📑',
            category: 'Layout',
            defaultProps: {
                name: 'tabbedPane',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'tabbedPane' },
                { name: 'selectedIndex', label: 'Selected Index', type: 'number', defaultValue: 0 },
            ],
        },
        {
            type: 'Separator',
            name: 'Separator',
            icon: '➖',
            category: 'Layout',
            defaultProps: {},
            propertySchema: [
                { name: 'orientation', label: 'Orientation', type: 'select', options: [
                    { label: 'Horizontal', value: 'horizontal' },
                    { label: 'Vertical', value: 'vertical' },
                ], defaultValue: 'horizontal' },
            ],
        },
        {
            type: 'Page',
            name: 'Page',
            icon: '📃',
            category: 'Layout',
            defaultProps: {
                name: 'page',
                title: 'Page',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'page' },
                { name: 'title', label: 'Title', type: 'string', defaultValue: 'Page' },
            ],
        },

        // Display Components
        {
            type: 'Table',
            name: 'Table',
            icon: '📊',
            category: 'Display',
            defaultProps: {
                name: 'table',
                columns: [],
                rows: [],
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'table' },
                { name: 'columns', label: 'Columns', type: 'array', defaultValue: [] },
                { name: 'rows', label: 'Rows', type: 'array', defaultValue: [] },
                { name: 'pagination', label: 'Pagination', type: 'boolean', defaultValue: true },
                { name: 'pageSize', label: 'Page Size', type: 'number', defaultValue: 10 },
                { name: 'selectable', label: 'Selectable', type: 'boolean', defaultValue: false },
            ],
        },
    ];
};

// Register EBML component provider
registerComponentProvider('ebml', ebmlComponentProvider);

export default ebmlComponentProvider;
