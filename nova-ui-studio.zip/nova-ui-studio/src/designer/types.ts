/* eslint-disable */
/**
 * Designer Types
 * Type definitions for the UI designer system
 */

export interface DesignerComponent {
    id: string;
    type: string;
    name: string;
    icon?: string;
    category: string;
    properties: Record<string, any>;
    children?: DesignerComponent[];
    styles?: Record<string, any>;
    code?: string;
}

export interface ComponentDefinition {
    type: string;
    name: string;
    icon?: string;
    category: string;
    defaultProps: Record<string, any>;
    propertySchema: PropertySchema[];
}

export interface PropertySchema {
    name: string;
    label: string;
    type: 'string' | 'number' | 'boolean' | 'select' | 'color' | 'object' | 'array';
    defaultValue?: any;
    options?: { label: string; value: any }[];
    description?: string;
}

export interface DesignCanvas {
    components: DesignerComponent[];
    selectedComponentId: string | null;
    zoom: number;
    gridSize: number;
}

export interface DesignerState {
    canvas: DesignCanvas;
    history: DesignCanvas[];
    historyIndex: number;
    mode: 'visual' | 'code' | 'json' | 'css';
}

export type ComponentProvider = () => ComponentDefinition[];
