# Grid Layout Guide

## Understanding Grid and GridItem

### Basic Structure

**Grid** is a container component that uses Material-UI's 12-column responsive grid system.
**GridItem** defines how many columns a child should occupy within a Grid.

```
Grid (container, spacing=2)
  ├─ GridItem (xs=6)    ← Takes 6/12 columns (50% width)
  │   └─ [Content]
  └─ GridItem (xs=6)    ← Takes 6/12 columns (50% width)
      └─ [Content]
```

### Key Rules

1. **Grid must have `container` prop** to act as a parent
2. **GridItem is the only direct child of Grid**
3. **GridItem can contain any component** including nested Grids
4. **Grid columns add up to 12** for each row

### Column Breakpoints

GridItem supports responsive column sizes:

- `xs`: Extra small screens (mobile) - 0px+
- `sm`: Small screens (tablet) - 600px+
- `md`: Medium screens (laptop) - 900px+
- `lg`: Large screens (desktop) - 1200px+

## Common Patterns

### 1. Two-Column Layout (50/50)

```
Grid (container, spacing=2)
  ├─ GridItem (xs=6)
  │   └─ Label "Left Column"
  └─ GridItem (xs=6)
      └─ Label "Right Column"
```

### 2. Three-Column Layout (33/33/33)

```
Grid (container, spacing=2)
  ├─ GridItem (xs=4)
  │   └─ Label "Column 1"
  ├─ GridItem (xs=4)
  │   └─ Label "Column 2"
  └─ GridItem (xs=4)
      └─ Label "Column 3"
```

### 3. Sidebar Layout (25/75)

```
Grid (container, spacing=2)
  ├─ GridItem (xs=3)
  │   └─ Paper "Sidebar"
  └─ GridItem (xs=9)
      └─ Paper "Main Content"
```

### 4. Responsive Layout (Stacks on Mobile)

```
Grid (container, spacing=2)
  ├─ GridItem (xs=12, md=6)    ← Full width on mobile, half on desktop
  │   └─ Label "Content 1"
  └─ GridItem (xs=12, md=6)    ← Full width on mobile, half on desktop
      └─ Label "Content 2"
```

On mobile (xs): Each takes 12 columns (stacks vertically)
On desktop (md): Each takes 6 columns (side by side)

## Nested Grids

**GridItem can contain another Grid** for complex layouts:

```
Grid (container, spacing=2)
  └─ GridItem (xs=12)
      └─ Grid (container, spacing=1)    ← Nested Grid inside GridItem
          ├─ GridItem (xs=6)
          │   └─ Label "Nested 1"
          └─ GridItem (xs=6)
              └─ Label "Nested 2"
```

### Complex Nested Example

```
Grid (container, spacing=2)
  ├─ GridItem (xs=12, md=8)
  │   └─ Paper
  │       └─ Grid (container, spacing=1)        ← Nested Grid 1
  │           ├─ GridItem (xs=12)
  │           │   └─ Label "Header"
  │           ├─ GridItem (xs=6)
  │           │   └─ Input "First Name"
  │           └─ GridItem (xs=6)
  │               └─ Input "Last Name"
  └─ GridItem (xs=12, md=4)
      └─ Paper
          └─ Grid (container, spacing=1)        ← Nested Grid 2
              ├─ GridItem (xs=12)
              │   └─ Label "Sidebar"
              └─ GridItem (xs=12)
                  └─ Button "Action"
```

## In the Designer

### Creating a Grid Layout

1. **Drag Grid** from toolbar to canvas
2. **Drag GridItem** and drop it on the Grid
3. **Drag any component** and drop it on the GridItem
4. **Select GridItem** and adjust xs/sm/md/lg in properties

### Visual Indicators

- **Grid** shows "Grid Container (Drop GridItems here)" when empty
- **GridItem** shows "GridItem (xs=N)" when empty
- Selected components have blue border

### Properties Panel

**Grid Properties:**
- `container`: Always true for Grid parent
- `spacing`: Gap between GridItems (0-10)

**GridItem Properties:**
- `xs`: Columns on extra small screens (1-12)
- `sm`: Columns on small screens (1-12)
- `md`: Columns on medium screens (1-12)
- `lg`: Columns on large screens (1-12)

## Column Math

Grid uses 12 columns. Examples:

```
xs=12  → 100% width (12/12)
xs=6   → 50% width  (6/12)
xs=4   → 33% width  (4/12)
xs=3   → 25% width  (3/12)
xs=2   → 16% width  (2/12)
xs=1   → 8% width   (1/12)
```

### Multi-Row Grids

If GridItems exceed 12 columns, they wrap to next row:

```
Grid (container)
  ├─ GridItem (xs=8)    ← Row 1
  ├─ GridItem (xs=6)    ← Row 2 (wraps because 8+6 > 12)
  └─ GridItem (xs=4)    ← Row 2
```

## Best Practices

### 1. Always Use Grid as Container

```
✅ CORRECT:
Grid (container=true, spacing=2)
  └─ GridItem (xs=12)
      └─ Content

❌ WRONG:
Grid (container=false)
  └─ Content
```

### 2. GridItem as Direct Child of Grid

```
✅ CORRECT:
Grid
  └─ GridItem
      └─ Label

❌ WRONG:
Grid
  └─ Label  ← Should be inside GridItem
```

### 3. Use Spacing for Gaps

```
✅ CORRECT:
Grid (spacing=2)
  └─ GridItem

❌ WRONG:
Grid (spacing=0)
  └─ GridItem (sx={ margin: 2 })  ← Use spacing instead
```

### 4. Responsive Breakpoints

```
✅ CORRECT:
GridItem (xs=12, md=6, lg=4)
  → Mobile: Full width
  → Tablet: Half width
  → Desktop: Third width

❌ WRONG:
GridItem (xs=4)
  → Always third width, not responsive
```

## Common Layouts

### Dashboard Layout

```
Grid (container, spacing=2)
  ├─ GridItem (xs=12, md=8, lg=9)
  │   └─ Paper "Main Dashboard"
  └─ GridItem (xs=12, md=4, lg=3)
      └─ Paper "Sidebar Widgets"
```

### Form Layout

```
Grid (container, spacing=2)
  ├─ GridItem (xs=12)
  │   └─ Label "User Information"
  ├─ GridItem (xs=12, md=6)
  │   └─ Input "First Name"
  ├─ GridItem (xs=12, md=6)
  │   └─ Input "Last Name"
  ├─ GridItem (xs=12)
  │   └─ Input "Email"
  └─ GridItem (xs=12, md=6)
      └─ Button "Submit"
```

### Card Grid

```
Grid (container, spacing=3)
  ├─ GridItem (xs=12, sm=6, md=4)
  │   └─ Paper "Card 1"
  ├─ GridItem (xs=12, sm=6, md=4)
  │   └─ Paper "Card 2"
  ├─ GridItem (xs=12, sm=6, md=4)
  │   └─ Paper "Card 3"
  ├─ GridItem (xs=12, sm=6, md=4)
  │   └─ Paper "Card 4"
  ├─ GridItem (xs=12, sm=6, md=4)
  │   └─ Paper "Card 5"
  └─ GridItem (xs=12, sm=6, md=4)
      └─ Paper "Card 6"
```

## Troubleshooting

### GridItem Not Appearing in Grid

**Problem**: GridItem doesn't show up
**Solution**: Ensure Grid has `container=true` property

### Layout Not Responsive

**Problem**: Layout doesn't change on different screen sizes
**Solution**: Use multiple breakpoints (xs, md, lg) in GridItem

### Components Overflow

**Problem**: Content exceeds GridItem width
**Solution**: Reduce GridItem xs value or use `sx={{ overflow: 'hidden' }}`

### Uneven Spacing

**Problem**: Gaps between GridItems look wrong
**Solution**: Use Grid's `spacing` property instead of manual margins

## Summary

- **Grid** = Container with 12 columns
- **GridItem** = Column definition (xs/sm/md/lg)
- **Nesting** = GridItem can contain Grid
- **Responsive** = Different columns for different screen sizes
- **Always** = GridItem as direct child of Grid

Use Grid/GridItem for all responsive layouts in the designer!
