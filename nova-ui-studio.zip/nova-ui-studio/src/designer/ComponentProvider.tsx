/* eslint-disable */
/**
 * Component Provider
 * Extensible provider system for designer components
 */

import type { ComponentDefinition } from './types';

// Registry for component providers
const componentProviders: Map<string, () => ComponentDefinition[]> = new Map();

/**
 * Register a component provider
 */
export const registerComponentProvider = (name: string, provider: () => ComponentDefinition[]) => {
    componentProviders.set(name, provider);
};

/**
 * Unregister a component provider
 */
export const unregisterComponentProvider = (name: string) => {
    componentProviders.delete(name);
};

/**
 * Get all available components from all providers
 */
export const getAllComponents = (): ComponentDefinition[] => {
    const allComponents: ComponentDefinition[] = [];

    componentProviders.forEach((provider) => {
        try {
            const components = provider();
            allComponents.push(...components);
        } catch (error) {
            console.error('Error loading components from provider:', error);
        }
    });

    return allComponents;
};

/**
 * Get components by category
 */
export const getComponentsByCategory = (): Record<string, ComponentDefinition[]> => {
    const components = getAllComponents();
    const categorized: Record<string, ComponentDefinition[]> = {};

    components.forEach((comp) => {
        if (!categorized[comp.category]) {
            categorized[comp.category] = [];
        }
        categorized[comp.category].push(comp);
    });

    return categorized;
};

/**
 * Default component provider - loads all @Lib components
 */
export const defaultComponentProvider = (): ComponentDefinition[] => {
    return [
        {
            type: 'Box',
            name: 'Box',
            icon: '📦',
            category: 'Layout',
            defaultProps: {
                sx: { p: 2 },
            },
            propertySchema: [
                { name: 'sx', label: 'Styles', type: 'object', defaultValue: {} },
            ],
        },
        {
            type: 'Grid',
            name: 'Grid',
            icon: '🔲',
            category: 'Layout',
            defaultProps: {
                container: true,
                spacing: 2,
            },
            propertySchema: [
                { name: 'container', label: 'Container', type: 'boolean', defaultValue: true },
                { name: 'spacing', label: 'Spacing', type: 'number', defaultValue: 2 },
            ],
        },
        {
            type: 'GridItem',
            name: 'Grid Item',
            icon: '▪️',
            category: 'Layout',
            defaultProps: {
                xs: 12,
            },
            propertySchema: [
                { name: 'xs', label: 'XS Columns', type: 'number', defaultValue: 12 },
                { name: 'sm', label: 'SM Columns', type: 'number' },
                { name: 'md', label: 'MD Columns', type: 'number' },
                { name: 'lg', label: 'LG Columns', type: 'number' },
            ],
        },
        {
            type: 'Paper',
            name: 'Paper',
            icon: '📄',
            category: 'Layout',
            defaultProps: {
                sx: { p: 2 },
            },
            propertySchema: [
                { name: 'sx', label: 'Styles', type: 'object', defaultValue: {} },
            ],
        },
        {
            type: 'Label',
            name: 'Label',
            icon: '🏷️',
            category: 'Display',
            defaultProps: {
                text: 'Label',
            },
            propertySchema: [
                { name: 'text', label: 'Text', type: 'string', defaultValue: 'Label' },
                { name: 'sx', label: 'Styles', type: 'object', defaultValue: {} },
            ],
        },
        {
            type: 'Button',
            name: 'Button',
            icon: '🔘',
            category: 'Input',
            defaultProps: {
                text: 'Button',
            },
            propertySchema: [
                { name: 'text', label: 'Text', type: 'string', defaultValue: 'Button' },
                { name: 'variant', label: 'Variant', type: 'select', options: [
                    { label: 'Contained', value: 'contained' },
                    { label: 'Outlined', value: 'outlined' },
                    { label: 'Text', value: 'text' },
                ], defaultValue: 'contained' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
            ],
        },
        {
            type: 'Input',
            name: 'Input',
            icon: '📝',
            category: 'Input',
            defaultProps: {
                name: 'field',
                label: 'Input Field',
            },
            propertySchema: [
                { name: 'name', label: 'Name', type: 'string', defaultValue: 'field' },
                { name: 'label', label: 'Label', type: 'string', defaultValue: 'Input Field' },
                { name: 'placeholder', label: 'Placeholder', type: 'string' },
                { name: 'disabled', label: 'Disabled', type: 'boolean', defaultValue: false },
                { name: 'fullWidth', label: 'Full Width', type: 'boolean', defaultValue: true },
            ],
        },
        {
            type: 'DataGrid',
            name: 'Data Grid',
            icon: '📊',
            category: 'Display',
            defaultProps: {
                rows: [],
                columns: [],
            },
            propertySchema: [
                { name: 'columns', label: 'Columns', type: 'array', defaultValue: [] },
                { name: 'rows', label: 'Rows', type: 'array', defaultValue: [] },
                { name: 'pagination', label: 'Pagination', type: 'boolean', defaultValue: true },
                { name: 'pageSize', label: 'Page Size', type: 'number', defaultValue: 10 },
            ],
        },
        {
            type: 'Tab',
            name: 'Tab Container',
            icon: '📑',
            category: 'Layout',
            defaultProps: {},
            propertySchema: [],
        },
        {
            type: 'TabItem',
            name: 'Tab Item',
            icon: '📋',
            category: 'Layout',
            defaultProps: {
                text: 'Tab',
                value: 0,
            },
            propertySchema: [
                { name: 'text', label: 'Text', type: 'string', defaultValue: 'Tab' },
                { name: 'value', label: 'Value', type: 'number', defaultValue: 0 },
            ],
        },
        {
            type: 'Divider',
            name: 'Divider',
            icon: '➖',
            category: 'Layout',
            defaultProps: {},
            propertySchema: [],
        },
    ];
};

// Register default provider
registerComponentProvider('default', defaultComponentProvider);
