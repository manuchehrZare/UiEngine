/* eslint-disable */
/**
 * Properties Panel
 * Component property editor
 */

import React from 'react';
import { Box, Paper, Label, Input, useForm, Button } from '../../lib';
import type { DesignerComponent, PropertySchema } from '../types';
import { getAllComponents } from '../ComponentProvider';

interface PropertiesPanelProps {
    selectedComponent: DesignerComponent | null;
    onPropertyChange: (componentId: string, propertyName: string, value: any) => void;
    onDeleteComponent: (componentId: string) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
    selectedComponent,
    onPropertyChange,
    onDeleteComponent,
}) => {
    const { control } = useForm({
        defaultValues: selectedComponent?.properties || {},
    });

    if (!selectedComponent) {
        return (
            <Paper
                sx={{
                    width: 320,
                    height: '100%',
                    borderRadius: 0,
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    boxShadow: 2,
                }}
            >
                <Box sx={{ p: 2, borderBottom: '1px solid #e0e0e0', backgroundColor: '#f5f5f5' }}>
                    <Label text="Properties" sx={{ fontSize: '1rem', fontWeight: 600 }} />
                </Box>
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: '100%',
                        color: '#999',
                    }}
                >
                    <Label text="No component selected" sx={{ fontSize: '0.875rem' }} />
                </Box>
            </Paper>
        );
    }

    // Get component definition to find property schema
    const allComponents = getAllComponents();
    const componentDef = allComponents.find((c) => c.type === selectedComponent.type);
    const propertySchema: PropertySchema[] = componentDef?.propertySchema || [];

    const handlePropertyChange = (propertyName: string, value: any) => {
        onPropertyChange(selectedComponent.id, propertyName, value);
    };

    const renderPropertyInput = (schema: PropertySchema) => {
        const currentValue = selectedComponent.properties[schema.name] ?? schema.defaultValue;

        switch (schema.type) {
            case 'string':
                return (
                    <Input
                        key={schema.name}
                        name={schema.name}
                        control={control}
                        label={schema.label}
                        placeholder={schema.description}
                        defaultValue={currentValue}
                        onChange={(e: any) => handlePropertyChange(schema.name, e.target.value)}
                        fullWidth
                        sx={{ mb: 2 }}
                    />
                );

            case 'number':
                return (
                    <Input
                        key={schema.name}
                        name={schema.name}
                        control={control}
                        label={schema.label}
                        type="number"
                        defaultValue={currentValue}
                        onChange={(e: any) => handlePropertyChange(schema.name, parseInt(e.target.value))}
                        fullWidth
                        sx={{ mb: 2 }}
                    />
                );

            case 'boolean':
                return (
                    <Box key={schema.name} sx={{ mb: 2 }}>
                        <Label text={schema.label} sx={{ fontSize: '0.875rem', mb: 0.5 }} />
                        <Box
                            onClick={() => handlePropertyChange(schema.name, !currentValue)}
                            sx={{
                                cursor: 'pointer',
                                p: 1,
                                border: '1px solid #ddd',
                                borderRadius: '4px',
                                backgroundColor: currentValue ? '#1976d2' : '#fff',
                                color: currentValue ? '#fff' : '#000',
                            }}
                        >
                            <Label text={currentValue ? 'True' : 'False'} sx={{ fontSize: '0.875rem' }} />
                        </Box>
                    </Box>
                );

            case 'select':
                return (
                    <Box key={schema.name} sx={{ mb: 2 }}>
                        <Label text={schema.label} sx={{ fontSize: '0.875rem', mb: 0.5 }} />
                        {schema.options?.map((option) => (
                            <Box
                                key={option.value}
                                onClick={() => handlePropertyChange(schema.name, option.value)}
                                sx={{
                                    cursor: 'pointer',
                                    p: 1,
                                    mb: 0.5,
                                    border: '1px solid #ddd',
                                    borderRadius: '4px',
                                    backgroundColor: currentValue === option.value ? '#1976d2' : '#fff',
                                    color: currentValue === option.value ? '#fff' : '#000',
                                    '&:hover': {
                                        backgroundColor: currentValue === option.value ? '#1565c0' : '#f5f5f5',
                                    },
                                }}
                            >
                                <Label text={option.label} sx={{ fontSize: '0.875rem' }} />
                            </Box>
                        ))}
                    </Box>
                );

            default:
                return (
                    <Box key={schema.name} sx={{ mb: 2 }}>
                        <Label text={`${schema.label} (${schema.type})`} sx={{ fontSize: '0.875rem' }} />
                    </Box>
                );
        }
    };

    return (
        <Paper
            sx={{
                width: 320,
                height: '100%',
                borderRadius: 0,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: 2,
            }}
        >
            {/* Header */}
            <Box sx={{ p: 2, borderBottom: '1px solid #e0e0e0', backgroundColor: '#f5f5f5' }}>
                <Label text="Properties" sx={{ fontSize: '1rem', fontWeight: 600 }} />
                <Label
                    text={`${selectedComponent.type} (${selectedComponent.name})`}
                    sx={{ fontSize: '0.75rem', color: '#666', mt: 0.5 }}
                />
            </Box>

            {/* Properties Form */}
            <Box sx={{ p: 2, flex: 1, overflowY: 'auto' }}>
                {/* Component ID */}
                <Box sx={{ mb: 2 }}>
                    <Label text="Component ID" sx={{ fontSize: '0.875rem', mb: 0.5 }} />
                    <Label
                        text={selectedComponent.id}
                        sx={{ fontSize: '0.75rem', color: '#666', p: 1, backgroundColor: '#f5f5f5', borderRadius: '4px' }}
                    />
                </Box>

                {/* Dynamic Properties */}
                {propertySchema.map((schema) => renderPropertyInput(schema))}

                {/* Delete Button */}
                <Button
                    text="Delete Component"
                    onClick={() => onDeleteComponent(selectedComponent.id)}
                    sx={{ width: '100%', mt: 2, backgroundColor: '#d32f2f' }}
                />
            </Box>
        </Paper>
    );
};
