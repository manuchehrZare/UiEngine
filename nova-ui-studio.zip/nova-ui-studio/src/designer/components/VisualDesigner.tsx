/* eslint-disable */
/**
 * Visual Designer
 * Drag & drop visual design canvas
 */

import React, { useState } from 'react';
import { Box, Grid, GridItem } from '../../lib';
import type { DesignerComponent } from '../types';
import { RenderableComponent } from './RenderableComponent';

interface VisualDesignerProps {
    components: DesignerComponent[];
    selectedComponentId: string | null;
    onComponentDrop: (component: DesignerComponent, parentId?: string, index?: number) => void;
    onComponentSelect: (componentId: string) => void;
    onComponentMove: (componentId: string, parentId: string | null, index: number) => void;
}

export const VisualDesigner: React.FC<VisualDesignerProps> = ({
    components,
    selectedComponentId,
    onComponentDrop,
    onComponentSelect,
    onComponentMove,
}) => {
    const [dragOverId, setDragOverId] = useState<string | null>(null);

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
    };

    const handleDrop = (e: React.DragEvent, parentId?: string, index?: number) => {
        e.preventDefault();
        e.stopPropagation();

        try {
            // Check if it's an existing component being moved
            const existingComponentData = e.dataTransfer.getData('application/x-designer-component');
            if (existingComponentData) {
                const existingComponent = JSON.parse(existingComponentData);
                // Move existing component
                onComponentMove(existingComponent.id, parentId || null, index || 0);
                setDragOverId(null);
                return;
            }

            // Otherwise, it's a new component from the toolbar
            const data = e.dataTransfer.getData('application/json');
            if (data) {
                const componentDef = JSON.parse(data);

                // Create new component instance
                const newComponent: DesignerComponent = {
                    id: `${componentDef.type}-${Date.now()}`,
                    type: componentDef.type,
                    name: componentDef.name,
                    category: componentDef.category,
                    properties: { ...componentDef.defaultProps },
                    children: [],
                    styles: {},
                };

                onComponentDrop(newComponent, parentId, index);
            }
        } catch (error) {
            console.error('Error handling drop:', error);
        }

        setDragOverId(null);
    };

    const handleDragEnter = (componentId: string) => {
        setDragOverId(componentId);
    };

    const handleDragLeave = () => {
        setDragOverId(null);
    };

    return (
        <Box
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e)}
            sx={{
                width: '100%',
                height: '100%',
                backgroundColor: '#fafafa',
                backgroundImage: 'radial-gradient(#ddd 1px, transparent 1px)',
                backgroundSize: '20px 20px',
                overflow: 'auto',
                p: 4,
                position: 'relative',
            }}
        >
            {components.length === 0 ? (
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: '100%',
                        color: '#999',
                        fontSize: '1.25rem',
                    }}
                >
                    Drop components here to start designing
                </Box>
            ) : (
                <Grid container spacing={2}>
                    {components.map((comp, index) => (
                        <RenderableComponent
                            key={comp.id}
                            component={comp}
                            isSelected={comp.id === selectedComponentId}
                            isDragOver={comp.id === dragOverId}
                            onSelect={() => onComponentSelect(comp.id)}
                            onDrop={(e) => handleDrop(e, comp.id)}
                            onDragEnter={() => handleDragEnter(comp.id)}
                            onDragLeave={handleDragLeave}
                        />
                    ))}
                </Grid>
            )}
        </Box>
    );
};
