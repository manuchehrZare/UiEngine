/* eslint-disable */
/**
 * Code Editor
 * Simple code editor for JSON, CSS, and JavaScript
 */

import React from 'react';
import { Box } from '../../lib';

interface CodeEditorProps {
    mode: 'code' | 'json' | 'css';
    content: string;
    onChange: (value: string) => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ mode, content, onChange }) => {
    return (
        <Box
            component="textarea"
            value={content}
            onChange={(e: any) => onChange(e.target.value)}
            sx={{
                width: '100%',
                height: '100%',
                fontFamily: 'monospace',
                fontSize: '14px',
                padding: 2,
                border: 'none',
                outline: 'none',
                resize: 'none',
                backgroundColor: '#1e1e1e',
                color: '#d4d4d4',
                lineHeight: 1.6,
                tabSize: 2,
            }}
        />
    );
};
