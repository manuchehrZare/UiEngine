/* eslint-disable */
/**
 * Designer Toolbar
 * Draggable component palette
 */

import React, { useState } from 'react';
import { Box, Paper, Label, CustomScrollbar } from '../../lib';
import { getComponentsByCategory } from '../ComponentProvider';
import type { ComponentDefinition } from '../types';

interface ToolbarProps {
    onDragStart: (component: ComponentDefinition) => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({ onDragStart }) => {
    const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set(['Layout', 'Input', 'Display']));
    const componentsByCategory = getComponentsByCategory();

    const toggleCategory = (category: string) => {
        const newExpanded = new Set(expandedCategories);
        if (newExpanded.has(category)) {
            newExpanded.delete(category);
        } else {
            newExpanded.add(category);
        }
        setExpandedCategories(newExpanded);
    };

    const handleDragStart = (e: React.DragEvent, component: ComponentDefinition) => {
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('application/json', JSON.stringify(component));
        onDragStart(component);
    };

    return (
        <Paper
            sx={{
                width: 280,
                height: '100%',
                borderRadius: 0,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: 2,
            }}
        >
            {/* Toolbar Header */}
            <Box sx={{ p: 2, borderBottom: '1px solid #e0e0e0', backgroundColor: '#f5f5f5' }}>
                <Label text="Components" sx={{ fontSize: '1rem', fontWeight: 600 }} />
            </Box>

            {/* Component List */}
            <CustomScrollbar height="calc(100% - 60px)">
                <Box sx={{ p: 1 }}>
                    {Object.entries(componentsByCategory).map(([category, components]) => (
                        <Box key={category} sx={{ mb: 1 }}>
                            {/* Category Header */}
                            <Box
                                onClick={() => toggleCategory(category)}
                                sx={{
                                    cursor: 'pointer',
                                    p: 1,
                                    backgroundColor: '#f0f0f0',
                                    borderRadius: '4px',
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                    '&:hover': {
                                        backgroundColor: '#e0e0e0',
                                    },
                                }}
                            >
                                <Label
                                    text={category}
                                    sx={{ fontSize: '0.875rem', fontWeight: 600 }}
                                />
                                <Label
                                    text={expandedCategories.has(category) ? '▼' : '▶'}
                                    sx={{ fontSize: '0.75rem' }}
                                />
                            </Box>

                            {/* Component Items */}
                            {expandedCategories.has(category) && (
                                <Box sx={{ mt: 0.5 }}>
                                    {components.map((comp) => (
                                        <Box
                                            key={comp.type}
                                            draggable
                                            onDragStart={(e) => handleDragStart(e, comp)}
                                            sx={{
                                                cursor: 'grab',
                                                p: 1.5,
                                                mb: 0.5,
                                                backgroundColor: '#fff',
                                                border: '1px solid #ddd',
                                                borderRadius: '4px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1,
                                                '&:hover': {
                                                    backgroundColor: '#f5f5f5',
                                                    borderColor: '#1976d2',
                                                },
                                                '&:active': {
                                                    cursor: 'grabbing',
                                                },
                                            }}
                                        >
                                            <Box sx={{ fontSize: '1.25rem' }}>{comp.icon || '📦'}</Box>
                                            <Label text={comp.name} sx={{ fontSize: '0.875rem' }} />
                                        </Box>
                                    ))}
                                </Box>
                            )}
                        </Box>
                    ))}
                </Box>
            </CustomScrollbar>
        </Paper>
    );
};
