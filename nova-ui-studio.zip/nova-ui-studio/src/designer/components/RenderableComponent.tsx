/* eslint-disable */
/**
 * Renderable Component
 * Renders a component in the designer with selection and drag support
 */

import React from 'react';
import { Box, Grid, GridItem, Paper, Label, Button, Input, DataGrid, Tab, TabItem, Divider, useForm } from '../../lib';
import type { DesignerComponent } from '../types';

interface RenderableComponentProps {
    component: DesignerComponent;
    isSelected: boolean;
    isDragOver: boolean;
    onSelect: () => void;
    onDrop: (e: React.DragEvent) => void;
    onDragEnter: () => void;
    onDragLeave: () => void;
    onComponentDragStart?: (component: DesignerComponent) => void;
}

export const RenderableComponent: React.FC<RenderableComponentProps> = ({
    component,
    isSelected,
    isDragOver,
    onSelect,
    onDrop,
    onDragEnter,
    onDragLeave,
    onComponentDragStart,
}) => {
    const { control } = useForm({ defaultValues: {} });

    const containerStyle = {
        position: 'relative' as const,
        border: isSelected ? '2px solid #1976d2' : isDragOver ? '2px dashed #1976d2' : '1px solid transparent',
        cursor: 'move',
        '&:hover': {
            border: '1px solid #1976d2',
        },
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        onDragEnter();
    };

    const handleDragStart = (e: React.DragEvent) => {
        e.stopPropagation();
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('application/x-designer-component', JSON.stringify(component));
        if (onComponentDragStart) {
            onComponentDragStart(component);
        }
    };

    const renderComponent = () => {
        const props = component.properties;

        switch (component.type) {
            case 'Box':
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        onDragOver={handleDragOver}
                        onDragLeave={onDragLeave}
                        onDrop={onDrop}
                        sx={{ ...containerStyle, ...props.sx, minHeight: 100 }}
                    >
                        {component.children && component.children.length > 0 ? (
                            component.children.map((child) => (
                                <RenderableComponent
                                    key={child.id}
                                    component={child}
                                    isSelected={false}
                                    isDragOver={false}
                                    onSelect={() => {}}
                                    onDrop={() => {}}
                                    onDragEnter={() => {}}
                                    onDragLeave={() => {}}
                                />
                            ))
                        ) : (
                            <Label text="Box Container (Drop components here)" />
                        )}
                    </Box>
                );

            case 'Grid':
                return (
                    <Grid
                        container
                        spacing={props.spacing || 2}
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        onDragOver={handleDragOver}
                        onDragLeave={onDragLeave}
                        onDrop={onDrop}
                        sx={containerStyle}
                    >
                        {component.children && component.children.length > 0 ? (
                            component.children.map((child) => (
                                <RenderableComponent
                                    key={child.id}
                                    component={child}
                                    isSelected={false}
                                    isDragOver={false}
                                    onSelect={() => {}}
                                    onDrop={() => {}}
                                    onDragEnter={() => {}}
                                    onDragLeave={() => {}}
                                />
                            ))
                        ) : (
                            <GridItem xs={12}>
                                <Box sx={{ p: 2, border: '1px dashed #ddd', minHeight: 100 }}>
                                    <Label text="Grid Container (Drop GridItems here)" />
                                </Box>
                            </GridItem>
                        )}
                    </Grid>
                );

            case 'GridItem':
                return (
                    <GridItem
                        xs={props.xs || 12}
                        sm={props.sm}
                        md={props.md}
                        lg={props.lg}
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        onDragOver={handleDragOver}
                        onDragLeave={onDragLeave}
                        onDrop={onDrop}
                        sx={containerStyle}
                    >
                        {component.children && component.children.length > 0 ? (
                            component.children.map((child) => (
                                <RenderableComponent
                                    key={child.id}
                                    component={child}
                                    isSelected={false}
                                    isDragOver={false}
                                    onSelect={() => {}}
                                    onDrop={() => {}}
                                    onDragEnter={() => {}}
                                    onDragLeave={() => {}}
                                />
                            ))
                        ) : (
                            <Box sx={{ p: 2, border: '1px dashed #ddd', minHeight: 80 }}>
                                <Label text={`GridItem (xs=${props.xs || 12})`} />
                            </Box>
                        )}
                    </GridItem>
                );

            case 'Paper':
                return (
                    <Paper
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        onDragOver={handleDragOver}
                        onDragLeave={onDragLeave}
                        onDrop={onDrop}
                        sx={{ ...containerStyle, ...props.sx, p: 2, minHeight: 100 }}
                    >
                        {component.children && component.children.length > 0 ? (
                            component.children.map((child) => (
                                <RenderableComponent
                                    key={child.id}
                                    component={child}
                                    isSelected={false}
                                    isDragOver={false}
                                    onSelect={() => {}}
                                    onDrop={() => {}}
                                    onDragEnter={() => {}}
                                    onDragLeave={() => {}}
                                />
                            ))
                        ) : (
                            <Label text="Paper Container (Drop components here)" />
                        )}
                    </Paper>
                );

            case 'Label':
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        sx={containerStyle}
                    >
                        <Label text={props.text || 'Label'} sx={props.sx} />
                    </Box>
                );

            case 'Button':
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        sx={containerStyle}
                    >
                        <Button
                            text={props.text || 'Button'}
                            variant={props.variant}
                            disabled={props.disabled}
                        />
                    </Box>
                );

            case 'Input':
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        sx={containerStyle}
                    >
                        <Input
                            name={props.name || 'field'}
                            control={control}
                            label={props.label}
                            placeholder={props.placeholder}
                            disabled={props.disabled}
                            fullWidth={props.fullWidth}
                        />
                    </Box>
                );

            case 'DataGrid':
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        sx={containerStyle}
                    >
                        <DataGrid
                            columns={props.columns || []}
                            rows={props.rows || []}
                            pagination={props.pagination}
                            pageSize={props.pageSize}
                            sx={{ height: 400 }}
                        />
                    </Box>
                );

            case 'Divider':
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        sx={containerStyle}
                    >
                        <Divider />
                    </Box>
                );

            default:
                return (
                    <Box
                        draggable
                        onDragStart={handleDragStart}
                        onClick={(e) => { e.stopPropagation(); onSelect(); }}
                        sx={containerStyle}
                    >
                        <Label text={`Unknown Component: ${component.type}`} />
                    </Box>
                );
        }
    };

    return renderComponent();
};
