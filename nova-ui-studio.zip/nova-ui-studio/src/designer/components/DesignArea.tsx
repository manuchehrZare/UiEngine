/* eslint-disable */
/**
 * Design Area
 * Visual designer and code editors
 */

import React, { useState } from 'react';
import { Box, Paper, Label, Button, Grid, GridItem } from '../../lib';
import type { DesignerComponent } from '../types';
import { VisualDesigner } from './VisualDesigner';
import { CodeEditor } from './CodeEditor';

interface DesignAreaProps {
    components: DesignerComponent[];
    selectedComponentId: string | null;
    mode: 'visual' | 'code' | 'json' | 'css';
    onModeChange: (mode: 'visual' | 'code' | 'json' | 'css') => void;
    onComponentDrop: (component: DesignerComponent, parentId?: string, index?: number) => void;
    onComponentSelect: (componentId: string) => void;
    onComponentMove: (componentId: string, parentId: string | null, index: number) => void;
    onJsonChange: (json: string) => void;
    onCssChange: (css: string) => void;
    onCodeChange: (code: string) => void;
}

export const DesignArea: React.FC<DesignAreaProps> = ({
    components,
    selectedComponentId,
    mode,
    onModeChange,
    onComponentDrop,
    onComponentSelect,
    onComponentMove,
    onJsonChange,
    onCssChange,
    onCodeChange,
}) => {
    const modes = [
        { value: 'visual', label: 'Visual', icon: '👁️' },
        { value: 'code', label: 'Code', icon: '💻' },
        { value: 'json', label: 'JSON', icon: '📋' },
        { value: 'css', label: 'CSS', icon: '🎨' },
    ] as const;

    const getEditorContent = () => {
        switch (mode) {
            case 'json':
                return JSON.stringify(components, null, 2);
            case 'css':
                // Generate CSS from all component styles
                return components.map(comp =>
                    `#${comp.id} {\n${Object.entries(comp.styles || {}).map(([key, value]) =>
                        `  ${key}: ${value};`
                    ).join('\n')}\n}`
                ).join('\n\n');
            case 'code':
                return components.map(comp => comp.code || '').join('\n\n');
            default:
                return '';
        }
    };

    return (
        <Paper
            sx={{
                flex: 1,
                height: '100%',
                borderRadius: 0,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: 1,
            }}
        >
            {/* Mode Selector */}
            <Box sx={{ p: 1, borderBottom: '1px solid #e0e0e0', backgroundColor: '#f5f5f5', display: 'flex', gap: 1 }}>
                {modes.map((m) => (
                    <Button
                        key={m.value}
                        text={`${m.icon} ${m.label}`}
                        onClick={() => onModeChange(m.value)}
                        sx={{
                            backgroundColor: mode === m.value ? '#1976d2' : '#fff',
                            color: mode === m.value ? '#fff' : '#000',
                            '&:hover': {
                                backgroundColor: mode === m.value ? '#1565c0' : '#f5f5f5',
                            },
                        }}
                    />
                ))}
            </Box>

            {/* Content Area */}
            <Box sx={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
                {mode === 'visual' ? (
                    <VisualDesigner
                        components={components}
                        selectedComponentId={selectedComponentId}
                        onComponentDrop={onComponentDrop}
                        onComponentSelect={onComponentSelect}
                        onComponentMove={onComponentMove}
                    />
                ) : (
                    <CodeEditor
                        mode={mode}
                        content={getEditorContent()}
                        onChange={(value) => {
                            if (mode === 'json') onJsonChange(value);
                            else if (mode === 'css') onCssChange(value);
                            else if (mode === 'code') onCodeChange(value);
                        }}
                    />
                )}
            </Box>
        </Paper>
    );
};
