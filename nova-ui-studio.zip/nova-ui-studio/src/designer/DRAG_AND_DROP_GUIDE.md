# Drag & Drop Guide

## Overview

The designer supports two types of drag & drop operations:

1. **Adding Components**: Drag from toolbar → Drop on canvas
2. **Moving Components**: Drag existing component → Drop in new location

## Adding Components

### From Toolbar to Canvas

1. Find component in left toolbar (categorized by Layout, Input, Display)
2. Click and drag the component
3. Drop it on the canvas or inside a container

**Visual Indicators:**
- **Solid blue border**: Component you're hovering over
- **Dashed blue border**: Valid drop target
- **Move cursor**: Draggable component

### Valid Drop Targets

- **Canvas** (root level) - Drop anywhere on the gray grid background
- **Box** - General container, accepts any component
- **Grid** - Must drop GridItem inside
- **GridItem** - Accepts any component including nested Grids
- **Paper** - Accepts any component

## Moving Components

### Reordering Within Same Container

1. Click and drag an existing component (cursor changes to "move")
2. Drag to desired position within same container
3. Drop to reorder

**Example**: Reorder labels in a Box
```
Before:
Box
  ├─ Label "First"
  ├─ Label "Second"
  └─ Label "Third"

After dragging "Third" to top:
Box
  ├─ Label "Third"    ← Moved here
  ├─ Label "First"
  └─ Label "Second"
```

### Moving Between Containers

1. Click and drag component from source container
2. Drag over target container (shows dashed blue border)
3. Drop inside target container

**Example**: Move Label from one GridItem to another
```
Before:
Grid
  ├─ GridItem (xs=6)
  │   └─ Label "Hello"    ← Drag this
  └─ GridItem (xs=6)
      └─ [Empty]

After:
Grid
  ├─ GridItem (xs=6)
  │   └─ [Empty]
  └─ GridItem (xs=6)
      └─ Label "Hello"    ← Dropped here
```

### Moving to Root Level

1. Drag component from nested container
2. Drop on canvas background (gray grid)
3. Component moves to root level

## Drag Behavior by Component Type

### Container Components (Accept Drops)

**Box**
- ✅ Accepts: Any component
- 📦 Can contain: Multiple children
- 🔄 Draggable: Yes
- 🎯 Drop into: Box, Paper, GridItem, Canvas

**Grid** (container)
- ✅ Accepts: GridItem only
- 📦 Can contain: Multiple GridItems
- 🔄 Draggable: Yes
- 🎯 Drop into: Box, Paper, GridItem, Canvas

**GridItem**
- ✅ Accepts: Any component
- 📦 Can contain: Multiple children, including nested Grid
- 🔄 Draggable: Yes (within Grid)
- 🎯 Drop into: Grid only

**Paper**
- ✅ Accepts: Any component
- 📦 Can contain: Multiple children
- 🔄 Draggable: Yes
- 🎯 Drop into: Box, Paper, GridItem, Canvas

### Leaf Components (No Children)

**Label, Button, Input, DataGrid, Divider**
- ✅ Accepts: Nothing (no children)
- 🔄 Draggable: Yes
- 🎯 Drop into: Box, Paper, GridItem, Canvas

## Tips & Tricks

### 1. Precise Placement

When dropping into a container:
- **Drop near top** = Insert at beginning
- **Drop in middle** = Insert in middle
- **Drop near bottom** = Insert at end

### 2. Visual Feedback

Watch for these indicators:
- **Blue solid border** = Selected component
- **Blue dashed border** = Valid drop target (hovering)
- **Move cursor** = Component is draggable
- **Pointer cursor** = Component is selectable

### 3. Nested Layouts

For complex layouts, build from outside-in:
```
1. Grid (container)
2. Add GridItems to Grid
3. Add Paper/Box to GridItem
4. Add components to Paper/Box
```

### 4. Reordering Siblings

To reorder components at the same level:
1. Drag component
2. Drop on parent container
3. Component reorders within parent

### 5. Moving Between Grids

To move GridItem between Grids:
1. Drag GridItem from source Grid
2. Hover over target Grid (shows blue dashed border)
3. Drop onto target Grid

## Common Patterns

### Building a Form

```
Step 1: Add Grid
  Drag Grid → Drop on canvas

Step 2: Add GridItems
  Drag GridItem → Drop on Grid (repeat for rows)

Step 3: Add Inputs
  Drag Input → Drop on GridItem (for each field)

Result:
Grid
  ├─ GridItem (xs=12)
  │   └─ Input "Name"
  ├─ GridItem (xs=12)
  │   └─ Input "Email"
  └─ GridItem (xs=12)
      └─ Button "Submit"
```

### Reorganizing Layout

```
Move sidebar from left to right:

Before:
Grid
  ├─ GridItem (xs=3) - Sidebar
  └─ GridItem (xs=9) - Main

After dragging:
Grid
  ├─ GridItem (xs=9) - Main
  └─ GridItem (xs=3) - Sidebar
```

### Nesting Grids

```
Step 1: Grid + GridItem
  Grid → GridItem

Step 2: Nested Grid in GridItem
  Drag Grid → Drop on GridItem

Step 3: GridItems in nested Grid
  Drag GridItem → Drop on nested Grid

Result:
Grid
  └─ GridItem
      └─ Grid (nested)
          ├─ GridItem
          └─ GridItem
```

## Troubleshooting

### Component Won't Drop

**Problem**: Component won't drop into container
**Solution**:
- Check if container accepts that component type
- Grid only accepts GridItem as direct child
- Ensure you're dropping ON the container, not next to it

### Component Disappears After Drag

**Problem**: Component vanishes when dropped
**Solution**:
- This shouldn't happen - it's a bug
- Use Undo (planned) or reload and try again
- Check browser console for errors

### Can't Drag Component

**Problem**: Component won't drag
**Solution**:
- Ensure component is rendered (visible in visual mode)
- All components should have `draggable` attribute
- Try clicking to select first, then drag

### Wrong Drop Location

**Problem**: Component drops in wrong place
**Solution**:
- Drop operations insert at index 0 by default
- For precise placement, drop directly on parent
- Components are added to end of children array

### Dragging Creates Copy

**Problem**: Dragging creates duplicate instead of moving
**Solution**:
- Toolbar items create NEW components (copies)
- Canvas items MOVE (no copying)
- This is correct behavior

## Keyboard + Mouse

### Drag Operation

1. **Mouse Down**: Click on component
2. **Mouse Move**: Drag to new location
3. **Mouse Up**: Drop component

### Cancel Drag

- **Escape**: Cancel drag operation (not implemented yet)
- **Drop outside**: Cancels drag, component stays in place

## Best Practices

### 1. Use Containers Wisely

```
✅ GOOD:
Grid → GridItem → Paper → Label

❌ BAD:
Grid → Label (Grid needs GridItem)
```

### 2. Group Related Components

```
✅ GOOD:
Paper
  └─ Box
      ├─ Label "Title"
      ├─ Label "Description"
      └─ Button "Action"

❌ BAD:
Canvas
  ├─ Label "Title"
  ├─ Label "Description"
  └─ Button "Action"
```

### 3. Plan Layout First

1. Decide structure (Grid-based? Box-based?)
2. Add containers first
3. Add content components last
4. Adjust properties after placement

## Future Enhancements

Planned drag & drop improvements:

- [ ] Drag preview (ghost image of component)
- [ ] Snap to grid
- [ ] Drop zones highlight
- [ ] Insert indicators (line showing where component will land)
- [ ] Keyboard shortcuts for moving (arrow keys)
- [ ] Multi-select and drag
- [ ] Copy component (Ctrl+Drag)
- [ ] Undo/Redo for moves

## Summary

### Adding Components
- Drag from **toolbar** → Drop on **canvas/container**
- Creates NEW component

### Moving Components
- Drag from **canvas** → Drop on **canvas/container**
- MOVES existing component (no copy)

### All Components
- ✅ Are draggable (cursor: move)
- ✅ Can be moved between containers
- ✅ Can be reordered within container
- ✅ Show visual indicators when dragging

**You can now fully rearrange your UI by dragging components!** 🎨
