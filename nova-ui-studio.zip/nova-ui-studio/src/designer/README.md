# UI Designer

A comprehensive drag & drop UI designer for creating pages and forms visually with real-time code editing capabilities.

## Quick Links

- 📘 [Grid Layout Guide](./GRID_GUIDE.md) - Complete guide to Grid/GridItem usage
- 🎯 [Drag & Drop Guide](./DRAG_AND_DROP_GUIDE.md) - How to move and reorder components
- 🚀 [Quick Start](../../DESIGNER_QUICKSTART.md) - Get started quickly

## Features

### ✅ Implemented Features

1. **Extensible Component Provider System**
   - Register custom component providers
   - Default provider with all @Lib components
   - Category-based component organization

2. **Drag & Drop Toolbar**
   - Draggable component palette
   - Categorized components (Layout, Input, Display)
   - Expandable/collapsible categories
   - Visual component icons

3. **Multi-Mode Design Area**
   - **Visual Mode**: Drag & drop visual designer
   - **Code Mode**: JavaScript/TypeScript code editor
   - **JSON Mode**: JSON schema editor
   - **CSS Mode**: CSS style editor

4. **Properties Panel**
   - Dynamic property editing based on component type
   - Support for string, number, boolean, select properties
   - Component deletion
   - Visual property editors (no typing for booleans/selects)

5. **Drag & Drop Component Placement**
   - Drag from toolbar to canvas
   - Drop into containers (Box, Grid, Paper, etc.)
   - Visual drop indicators
   - Component selection highlighting

6. **Multi-Level Layout Support**
   - Nested containers (Grid → GridItem → Box → Components)
   - Unlimited nesting depth
   - Container-aware dropping

7. **JSON Import/Export**
   - Export design as JSON file
   - Import JSON to restore design
   - Real-time JSON editing in JSON mode

8. **Real-Time Code Editing**
   - JSON editor syncs with visual design
   - CSS editor for styling
   - Code editor for component logic

## Architecture

### Directory Structure

```
src/designer/
├── types.ts                          # TypeScript type definitions
├── ComponentProvider.tsx             # Extensible component provider system
├── components/
│   ├── Toolbar.tsx                   # Draggable component palette
│   ├── DesignArea.tsx                # Main design area with mode switching
│   ├── VisualDesigner.tsx            # Visual drag & drop canvas
│   ├── RenderableComponent.tsx       # Component renderer in designer
│   ├── PropertiesPanel.tsx           # Property editor panel
│   └── CodeEditor.tsx                # Code/JSON/CSS editor
└── README.md                         # This file
```

### Component Provider System

The designer uses an extensible provider system that allows registering custom components:

```typescript
// Register a custom provider
registerComponentProvider('myProvider', () => [
    {
        type: 'CustomComponent',
        name: 'My Component',
        icon: '🎨',
        category: 'Custom',
        defaultProps: { text: 'Hello' },
        propertySchema: [
            { name: 'text', label: 'Text', type: 'string', defaultValue: 'Hello' }
        ],
    },
]);

// Get all components
const components = getAllComponents();

// Get by category
const categorized = getComponentsByCategory();
```

## Usage

### Accessing the Designer

Navigate to `/designer` in your application to access the UI designer.

### Creating a UI

1. **Drag Components** from the left toolbar
2. **Drop on Canvas** or into container components
3. **Select Component** by clicking on it
4. **Edit Properties** in the right panel
5. **Switch Modes** to view/edit code, JSON, or CSS
6. **Export Design** using the "Export" button
7. **Import Design** using the "Import" button

### Component Categories

#### Layout Components
- **Box**: Container component with styling
- **Grid**: Responsive grid container
- **GridItem**: Grid column item
- **Paper**: Material design paper container
- **Tab**: Tab container
- **TabItem**: Individual tab
- **Divider**: Horizontal divider

#### Input Components
- **Button**: Action button
- **Input**: Text input field

#### Display Components
- **Label**: Text label
- **DataGrid**: Data table with columns and rows

### Multi-Level Layouts

Create complex nested layouts:

```
Page
└── Grid (container)
    ├── GridItem (xs=6)
    │   └── Paper
    │       └── Box
    │           ├── Label
    │           └── Button
    └── GridItem (xs=6)
        └── DataGrid
```

### Property Editing

Each component has editable properties based on its type:

- **String Properties**: Text input
- **Number Properties**: Number input
- **Boolean Properties**: Toggle button
- **Select Properties**: Option buttons

### JSON Structure

The designer exports/imports JSON in this format:

```json
[
    {
        "id": "Grid-1234567890",
        "type": "Grid",
        "name": "Grid",
        "category": "Layout",
        "properties": {
            "container": true,
            "spacing": 2
        },
        "children": [
            {
                "id": "GridItem-1234567891",
                "type": "GridItem",
                "name": "Grid Item",
                "category": "Layout",
                "properties": {
                    "xs": 12
                },
                "children": [],
                "styles": {}
            }
        ],
        "styles": {}
    }
]
```

## Keyboard Shortcuts

- `Delete`: Delete selected component (when properties panel is visible)
- `Ctrl/Cmd + S`: Export design (planned)
- `Ctrl/Cmd + O`: Import design (planned)

## Extending the Designer

### Adding Custom Components

1. **Create Component Provider**:

```typescript
import { registerComponentProvider } from './designer/ComponentProvider';

export const myComponentProvider = (): ComponentDefinition[] => {
    return [
        {
            type: 'MyComponent',
            name: 'My Component',
            icon: '🎨',
            category: 'Custom',
            defaultProps: {
                title: 'Hello',
                color: 'primary',
            },
            propertySchema: [
                {
                    name: 'title',
                    label: 'Title',
                    type: 'string',
                    defaultValue: 'Hello',
                },
                {
                    name: 'color',
                    label: 'Color',
                    type: 'select',
                    options: [
                        { label: 'Primary', value: 'primary' },
                        { label: 'Secondary', value: 'secondary' },
                    ],
                    defaultValue: 'primary',
                },
            ],
        },
    ];
};

// Register it
registerComponentProvider('custom', myComponentProvider);
```

2. **Update RenderableComponent.tsx** to render your component:

```typescript
case 'MyComponent':
    return (
        <Box onClick={(e) => { e.stopPropagation(); onSelect(); }} sx={containerStyle}>
            <MyComponent title={props.title} color={props.color} />
        </Box>
    );
```

### Property Schema Types

- `string`: Text input
- `number`: Number input
- `boolean`: Toggle button
- `select`: Radio button group with options
- `color`: Color picker (planned)
- `object`: JSON editor (planned)
- `array`: Array editor (planned)

## State Management

The designer maintains state with:

```typescript
interface DesignerState {
    canvas: {
        components: DesignerComponent[];
        selectedComponentId: string | null;
        zoom: number;
        gridSize: number;
    };
    history: DesignCanvas[];      // Undo/redo support (planned)
    historyIndex: number;
    mode: 'visual' | 'code' | 'json' | 'css';
}
```

## Planned Features

- [ ] Undo/Redo functionality
- [ ] Component reordering via drag & drop
- [ ] Zoom controls for canvas
- [ ] Grid snap
- [ ] Component copying
- [ ] Component grouping
- [ ] Keyboard shortcuts
- [ ] Component search
- [ ] Template library
- [ ] Preview mode
- [ ] Responsive breakpoint preview
- [ ] Monaco editor integration for better code editing
- [ ] Syntax highlighting
- [ ] Code completion
- [ ] Live preview
- [ ] Component marketplace

## Best Practices

### 1. Use Containers for Organization

Always use Grid/GridItem for responsive layouts:

```
Grid (container, spacing=2)
  GridItem (xs=12, md=6)
    Paper
      Label
      Input
  GridItem (xs=12, md=6)
    DataGrid
```

### 2. Set Meaningful IDs

Component IDs are auto-generated but shown in the properties panel for reference.

### 3. Test Responsive Layouts

Use different GridItem sizes (xs, sm, md, lg) to ensure responsive behavior.

### 4. Export Frequently

Export your designs regularly to avoid losing work.

### 5. Use Property Schema

When creating custom components, always define a complete property schema for the best editing experience.

## Troubleshooting

### Component Not Appearing

- Check if component type is registered in ComponentProvider
- Verify component is added to RenderableComponent switch statement
- Check browser console for errors

### Properties Not Updating

- Ensure property schema matches component type
- Check that property name matches exactly
- Verify onPropertyChange is called correctly

### Drag & Drop Not Working

- Ensure draggable attribute is set
- Check onDragStart, onDragOver, onDrop handlers
- Verify dataTransfer is working correctly

### JSON Import Fails

- Validate JSON structure
- Check all component IDs are unique
- Ensure all referenced component types exist

## Performance Tips

1. **Limit Nesting Depth**: Avoid excessive nesting (>5 levels)
2. **Use Grid Wisely**: Grid is powerful but can be slow with many items
3. **Minimize Re-renders**: Component selection triggers re-render
4. **Export Large Designs**: For complex designs, work in smaller sections

## Contributing

To add features to the designer:

1. Update types in `types.ts`
2. Implement feature in appropriate component
3. Update this documentation
4. Test with various component combinations
5. Ensure backward compatibility with existing designs

## License

This designer is part of the Nova UI Studio project.
