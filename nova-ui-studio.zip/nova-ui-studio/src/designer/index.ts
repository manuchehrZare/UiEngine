/* eslint-disable */
/**
 * Designer Module Exports
 */

export * from './types';
export * from './ComponentProvider';
export * from './EbmlComponentProvider';

// Import to register EBML components
import './EbmlComponentProvider';
export { Toolbar } from './components/Toolbar';
export { DesignArea } from './components/DesignArea';
export { PropertiesPanel } from './components/PropertiesPanel';
export { VisualDesigner } from './components/VisualDesigner';
export { RenderableComponent } from './components/RenderableComponent';
export { CodeEditor } from './components/CodeEditor';
