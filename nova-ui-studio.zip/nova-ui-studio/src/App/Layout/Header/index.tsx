import type { FC } from 'react';
import { memo, useEffect } from 'react';
import type { DesignType } from '../../../lib';
import {
    Box,
    TabItem,
    Tab,
    useForm,
    languageStorageKey,
    getLocalStorageItem,
    DesignTypeEnum,
    Select,
    useTranslation,
    GridItem,
    Grid,
    setProviderDesign,
    useStorage,
    constants,
    i18nChangeLanguage,
} from '../../../lib';
import { useLocation, useNavigate } from 'react-router-dom';
import { Typography } from '@mui/material';
import { menu } from '../../_root/data';
import { capitalize, kebabCase } from 'lodash';
import { getComponentDesignProperty } from '../../../lib/utils';

const Header: FC = () => {
    const { t, locale, i18n } = useTranslation();
    const navigate = useNavigate();
    const location = useLocation();
    const storageDesign = useStorage<DesignType | undefined>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });

    const { control, setValue } = useForm({
        defaultValues: {
            language: getLocalStorageItem<string>(languageStorageKey) || '',
            design: getComponentDesignProperty(undefined, storageDesign.newValue),
        },
    });

    useEffect(() => {
        setValue('design', getComponentDesignProperty(undefined, storageDesign.newValue));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [storageDesign]);

    const redirect = (slug: string) => {
        navigate(`/${slug}`);
    };

    return (
        <Box
            component="header"
            sx={{
                position: 'fixed',
                left: 0,
                top: 0,
                height: 48,
                width: '100%',
                borderBottom: (theme) => `1px solid ${theme.palette.grey[300]}`,
                zIndex: (theme) => theme.zIndex.appBar,
            }}>
            <Box height="100%" sx={{ pl: 2, pr: 2, display: 'flex', alignItems: 'center' }}>
                <Box sx={{ width: 200, cursor: 'pointer', flexShrink: 0 }} onClick={() => redirect('')}>
                    <Typography variant="h5">{import.meta.env.VITE_APP_NAME}</Typography>
                </Box>
                <Box height="100%" width="100%">
                    <Tab
                        design={DesignTypeEnum.Default}
                        value={location.pathname.split('/')[1]}
                        onChange={(val) => redirect(val)}
                        sx={{ height: '100%' }}>
                        <TabItem text="Home" value="" />
                        {Object.keys(menu).map((item, index) => (
                            <TabItem key={`${item}-${String(index)}`} text={capitalize(item)} value={kebabCase(item)} />
                        ))}
                    </Tab>
                </Box>
                <Box ml="auto" width={300} flexShrink={0}>
                    <Grid spacing={2}>
                        <GridItem md={6}>
                            <Select
                                design={DesignTypeEnum.SET}
                                name="design"
                                control={control}
                                label={t(locale.labels.design)}
                                labelPlacement="start"
                                setValue={setValue}
                                labelWidth={60}
                                options={{
                                    data: Object.keys(DesignTypeEnum).map((designItem) => ({
                                        name: designItem,
                                        value: (DesignTypeEnum as any)[designItem],
                                    })),
                                    displayField: 'name',
                                    displayValue: 'value',
                                }}
                                onChange={(e: DesignType) => {
                                    setProviderDesign(e);
                                }}
                            />
                        </GridItem>
                        <GridItem md={6}>
                            <Select
                                design={DesignTypeEnum.SET}
                                name="language"
                                control={control}
                                label={t(locale.labels.language)}
                                labelPlacement="start"
                                setValue={setValue}
                                labelWidth={60}
                                options={{
                                    data: i18n.languages?.map((lang) => ({
                                        name: i18n.t((locale.languages as any)[lang]),
                                        value: lang,
                                    })),
                                    displayField: 'name',
                                    displayValue: 'value',
                                }}
                                onChange={(e) => i18nChangeLanguage({ lng: e })}
                            />
                        </GridItem>
                    </Grid>
                </Box>
            </Box>
        </Box>
    );
};

export default memo(Header);
