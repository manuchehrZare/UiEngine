import { createRoot } from 'react-dom/client';
import App from './App';
import { i18nInitialize } from './lib/locales/i18n';
import './polyfills';

const renderAsync = async () => {
    await i18nInitialize();
    createRoot(document.getElementById('root')!).render(<App />);
};

renderAsync();
