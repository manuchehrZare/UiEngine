import type { FC } from 'react';
import { Layout } from '../../../App';

const NotFound: FC = () => {
    return (
        <Layout>
            <div className="p-3">
                <div className="not-fount-page d-flex align-items-center flex-column ">
                    <img
                        src={`/images/404.png`}
                        alt=""
                        style={{
                            height: '450px',
                        }}
                    />

                    <h5
                        style={{
                            fontSize: 15,
                            fontWeight: 'bold',
                            textTransform: 'uppercase',
                            marginBottom: 20,
                        }}>
                        Böyle bir sayfa bulunmuyor
                    </h5>
                </div>
            </div>
        </Layout>
    );
};

export default NotFound;
