import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../App';
import {
    Box,
    Button,
    Grid,
    GridItem,
    Paper,
    useForm,
    Input,
    Label,
    useMeasure,
    Tab,
    TabItem,
    View,
    Nav,
} from '../../../lib';
import * as yup from 'yup';
import { Tab1, Tab2, Tab3 } from './Tabs';

interface IForm {
    input: string;
    input2: string;
}

const UseMeasurePage: FC = () => {
    const measure1 = useMeasure();
    const measure2 = useMeasure();
    const [activeTab, setActiveTab] = useState<number>(1);

    const { control, handleSubmit, reset } = useForm<IForm>({
        defaultValues: {
            input: '',
            input2: '',
        },
        validationSchema: {
            input: yup.string().required('Required'),
            input2: yup
                .string()
                .required('Required - Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum'),
        },
    });

    const onSubmit = (data: IForm) => {
        // eslint-disable-next-line no-console
        console.log(data);
    };

    return (
        <Layout>
            <Grid p={1} spacing={2}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useMeasure' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Grid spacing={1}>
                                    <GridItem ref={measure1?.ref}>
                                        <Input name="input" label="Input 1" control={control} />
                                    </GridItem>
                                    <GridItem ref={measure2?.ref}>
                                        <Input name="input2" label="Input 2" control={control} />
                                    </GridItem>
                                    <GridItem>
                                        <Button text="Submit" type="submit" />
                                        <Button text="Reset" onClick={reset} />
                                    </GridItem>
                                </Grid>
                            </form>
                            <Grid spacing={1} my={1}>
                                <GridItem>
                                    <Label text="Measure - Input1" />
                                </GridItem>
                                <GridItem>{JSON.stringify(measure1.values, null, 4)}</GridItem>
                            </Grid>
                            <Grid spacing={1}>
                                <GridItem>
                                    <Label text="Measure - Input2" />
                                </GridItem>
                                <GridItem>{JSON.stringify(measure2.values, null, 4)}</GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={8}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useMeasure with Tab' }} />
                        <Box>
                            <Grid px={1}>
                                <GridItem>
                                    <Tab
                                        value={activeTab}
                                        onChange={(val) => {
                                            if (val !== activeTab) {
                                                setActiveTab(val);
                                            }
                                        }}>
                                        {[1, 2, 3].map((item) => (
                                            <TabItem key={String(item)} text={`Item ${item}`} value={item} />
                                        ))}
                                    </Tab>
                                </GridItem>
                            </Grid>
                            <Grid p={1}>
                                <GridItem>
                                    <View show={activeTab === 1}>
                                        <Tab1 />
                                    </View>
                                    <View show={activeTab === 2}>
                                        <Tab2 />
                                    </View>
                                    <View show={activeTab === 3}>
                                        <Tab3 />
                                    </View>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseMeasurePage;
