import type { FC, JSX } from 'react';
import * as yup from 'yup';
import {
    Button,
    Checkbox,
    DataGrid,
    Grid,
    GridItem,
    Input,
    Label,
    Radio,
    RadioGroup,
    Switch,
    useForm,
    useMeasure,
} from '../../../../lib';
import { sum } from 'lodash';

interface IFormValues {
    checkbox1: boolean;
    input1: string;
    input2: string;
    input3: string;
    radio1: string;
    switch1: boolean;
}

const Tab1: FC = (): JSX.Element => {
    const measure1 = useMeasure();
    const measure2 = useMeasure();
    const measure3 = useMeasure();
    const measure4 = useMeasure();

    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            input1: '',
            input2: '',
            input3: '',
            checkbox1: false,
            radio1: '1',
            switch1: false,
        },
        validationSchema: {
            input1: yup.string().required('Zorunlu').typeError('Tip Hatası'),
            input2: yup.string().required('Zorunlu').typeError('Tip Hatası'),
            input3: yup.string().required('Zorunlu').typeError('Tip Hatası'),
            radio1: yup.string().required('Required').oneOf(['1', '2', '3', '4'], 'Radio must be accepted'),
        },
    });

    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('tab1 -- formData', formData);
    };

    return (
        <Grid spacing={1}>
            <GridItem>
                <Label text="Tab1" />
            </GridItem>
            <GridItem ref={measure1?.ref}>
                <Input name="input1" control={control} label="Input1" />
            </GridItem>
            <GridItem ref={measure2?.ref}>
                <Input name="input2" control={control} label="Input2" />
            </GridItem>
            <GridItem ref={measure3?.ref}>
                <Grid spacing={1}>
                    <GridItem xs maxWidth={'120px !important'}>
                        <Input
                            labelWidth="auto"
                            labelPlacement="start"
                            name="input2"
                            control={control}
                            label="Input2"
                            helperText="Helper Text"
                        />
                    </GridItem>
                    <GridItem xs>
                        <Switch
                            name="switch1"
                            label="Label"
                            control={control}
                            helperText="Helper Text"
                            labelPlacement="end"
                            size="small"
                        />
                    </GridItem>
                    <GridItem xs>
                        <RadioGroup
                            name="radio1"
                            // label="Input2"
                            // labelWidth={50}
                            helperText="Helper Text"
                            row
                            control={control}>
                            <Radio
                                label="Radio 1"
                                value="1"
                                // helperText="HelperText 1"
                                // size="medium"
                            />
                            <Radio
                                label="Radio 2"
                                value="2"
                                // helperText="HelperText 2"
                                disabled
                                // size="medium"
                            />
                        </RadioGroup>
                    </GridItem>
                    <GridItem xs>
                        <Checkbox
                            name="checkbox1"
                            label="Checkbox 1"
                            control={control}
                            helperText="Helper Text"
                            // labelPlacement="top"
                        />
                    </GridItem>
                    <GridItem xs>
                        <Switch
                            name="switch1"
                            label="Label Switch"
                            labelPlacement="top"
                            control={control}
                            helperText="Helper Text"
                        />
                    </GridItem>
                </Grid>
            </GridItem>
            <GridItem ref={measure4?.ref}>
                <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                <Button text="Reset" onClick={reset} />
            </GridItem>
            <GridItem
                height={
                    (window.innerHeight -
                        sum([
                            measure1?.values?.height ?? 0,
                            measure2?.values?.height ?? 0,
                            measure3?.values?.height ?? 0,
                            measure4?.values?.height ?? 0,
                            212,
                        ])) *
                    0.5
                }>
                <DataGrid
                    columns={[
                        {
                            field: 'name',
                            headerName: 'Name',
                        },
                        {
                            field: 'surname',
                            headerName: 'Surname',
                        },
                        {
                            field: 'age',
                            headerName: 'Age',
                        },
                    ]}
                    rows={[]}
                />
            </GridItem>
            <GridItem
                height={
                    (window.innerHeight -
                        sum([
                            measure1.values.height,
                            measure2.values.height,
                            measure3.values.height,
                            measure4.values.height,
                            212,
                        ])) *
                    0.5
                }>
                <DataGrid
                    columns={[
                        {
                            field: 'name',
                            headerName: 'Name',
                        },
                        {
                            field: 'surname',
                            headerName: 'Surname',
                        },
                        {
                            field: 'age',
                            headerName: 'Age',
                        },
                    ]}
                    rows={[]}
                />
            </GridItem>
        </Grid>
    );
};

export default Tab1;
