import type { FC, JSX } from 'react';
import * as yup from 'yup';
import { Button, DataGrid, Grid, GridItem, Input, Label, useForm, useMeasure } from '../../../../lib';

interface IFormValues {
    input1: string;
    input2: string;
    input3: string;
}

const Tab3: FC = (): JSX.Element => {
    const measure1 = useMeasure();
    const measure2 = useMeasure();
    const measure3 = useMeasure();
    const measure4 = useMeasure();

    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            input1: '',
            input2: '',
            input3: '',
        },
        validationSchema: {
            input1: yup.string().required('Zorunlu').typeError('Tip Hatası'),
            input2: yup.string().required('Zorunlu').typeError('Tip Hatası'),
            input3: yup.string().required('Zorunlu').typeError('Tip Hatası'),
        },
    });

    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('tab3 -- formData', formData);
    };

    return (
        <Grid spacing={1}>
            <GridItem>
                <Label text="Tab3" />
            </GridItem>
            <GridItem ref={measure1?.ref}>
                <Input name="input1" control={control} label="Input1" />
            </GridItem>
            <GridItem ref={measure2?.ref}>
                <Input name="input2" control={control} label="Input2" />
            </GridItem>
            <GridItem ref={measure3?.ref}>
                <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                <Button text="Reset" onClick={reset} />
            </GridItem>
            <GridItem
                height={`calc((100vh - ${
                    (measure1?.values?.height ?? 0) +
                    (measure2?.values?.height ?? 0) +
                    (measure3?.values?.height ?? 0) +
                    (measure4?.values?.height ?? 0) +
                    212
                }px) * 1/3)`}>
                <DataGrid
                    columns={[
                        {
                            field: 'name',
                            headerName: 'Name',
                        },
                        {
                            field: 'surname',
                            headerName: 'Surname',
                        },
                        {
                            field: 'age',
                            headerName: 'Age',
                        },
                    ]}
                    rows={[]}
                />
            </GridItem>
            <GridItem
                height={`calc((100vh - ${
                    (measure1?.values?.height ?? 0) +
                    (measure2?.values?.height ?? 0) +
                    (measure3?.values?.height ?? 0) +
                    (measure4?.values?.height ?? 0) +
                    212
                }px) * 1/3)`}>
                <DataGrid
                    columns={[
                        {
                            field: 'name',
                            headerName: 'Name',
                        },
                        {
                            field: 'surname',
                            headerName: 'Surname',
                        },
                        {
                            field: 'age',
                            headerName: 'Age',
                        },
                    ]}
                    rows={[]}
                />
            </GridItem>
            <GridItem
                height={`calc((100vh - ${
                    (measure1?.values?.height ?? 0) +
                    (measure2?.values?.height ?? 0) +
                    (measure3?.values?.height ?? 0) +
                    (measure4?.values?.height ?? 0) +
                    212
                }px) * 1/3)`}>
                <DataGrid
                    columns={[
                        {
                            field: 'name',
                            headerName: 'Name',
                        },
                        {
                            field: 'surname',
                            headerName: 'Surname',
                        },
                        {
                            field: 'age',
                            headerName: 'Age',
                        },
                    ]}
                    rows={[]}
                />
            </GridItem>
            <GridItem ref={measure4?.ref}>
                <Input name="input3" control={control} label="Input3" />
            </GridItem>
        </Grid>
    );
};

export default Tab3;
