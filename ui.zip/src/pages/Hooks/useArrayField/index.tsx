import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Grid, GridItem, Paper, useArrayField, Input, useForm, Button, Nav } from '../../../lib';

const UseArrayFieldPage: FC = () => {
    const { control, handleSubmit } = useForm<any>({
        defaultValues: {
            test: [{ firstName: 'Ali', lastName: 'Veli' }],
        },
    });
    const { fields, remove, append, prepend, insert, swap, move, replace, update } = useArrayField({
        control,
        name: 'test',
    });

    const onSubmit = (formData: any) => {
        // eslint-disable-next-line no-console
        console.log('submit', formData);
    };

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useArrayField' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        {fields.map((item, index) => {
                                            return (
                                                <Grid key={item.id} spacing={1} mt={1}>
                                                    <GridItem xs={4.5}>
                                                        <Input
                                                            control={control}
                                                            name={`test.${index}.firstName`}
                                                            label="Ad"
                                                        />
                                                    </GridItem>
                                                    <GridItem xs={4.5}>
                                                        <Input
                                                            control={control}
                                                            name={`test.${index}.lastName`}
                                                            label="Soyad"
                                                        />
                                                    </GridItem>
                                                    <GridItem xs={3}>
                                                        <Button
                                                            text="Delete"
                                                            onClick={() => remove(index)}
                                                            fullWidth
                                                            sx={{ height: '40px' }}
                                                        />
                                                    </GridItem>
                                                </Grid>
                                            );
                                        })}
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacing={1}>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Append"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => {
                                                        append({ firstName: 'Ayşe', lastName: 'Fatma' });
                                                    }}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Prepend"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => {
                                                        prepend({
                                                            firstName: 'prependFirstName',
                                                            lastName: 'prependLastName',
                                                        });
                                                    }}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Insert At"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => {
                                                        insert(parseInt('2', 10), {
                                                            firstName: 'Ahmet',
                                                            lastName: 'Mehmet',
                                                        });
                                                    }}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Swap"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => swap(1, 3)}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacing={1}>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Move"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => move(1, 4)}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Replace"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => {
                                                        replace([
                                                            {
                                                                firstName: 'test1',
                                                                lastName: 'test1',
                                                            },
                                                            {
                                                                firstName: 'test2',
                                                                lastName: 'test2',
                                                            },
                                                        ]);
                                                    }}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Remove At"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => remove(0)}
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                            <GridItem xs={3}>
                                                <Button
                                                    text="Update"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() =>
                                                        update(1, { firstName: 'Updated', lastName: 'Updated' })
                                                    }
                                                    color="warning"
                                                    sx={{ height: '40px' }}
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Button
                                            text="Submit"
                                            fullWidth
                                            type="submit"
                                            color="warning"
                                            sx={{ height: '40px' }}
                                        />
                                    </GridItem>
                                </Grid>
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseArrayFieldPage;
