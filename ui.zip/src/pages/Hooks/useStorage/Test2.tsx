import type { FC, JSX } from 'react';
import { useStorage } from '../../../lib';

const Test2: FC = (): JSX.Element => {
    const localeStorageHook = useStorage({ source: 'local', key: 'localeInput2' });
    // eslint-disable-next-line no-console
    console.log('render - Test 2 ->', localeStorageHook);
    return <div>localeStorageHook 2- {localeStorageHook.newValue as any}</div>;
};

export default Test2;
