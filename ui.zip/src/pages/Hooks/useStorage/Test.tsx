import type { FC, JSX } from 'react';
import { useStorage } from '../../../lib';

const Test: FC = (): JSX.Element => {
    const localeStorageHook = useStorage({ source: 'local', key: 'localeInput' });
    // eslint-disable-next-line no-console
    console.log('render - Test 1 ->', localeStorageHook);
    return <div>localeStorageHook 1- {localeStorageHook.newValue as any}</div>;
};

export default Test;
