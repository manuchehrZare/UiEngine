import { useEffect, type JSX } from 'react';
import {
    Button,
    Grid,
    GridItem,
    Input,
    removeLocalStorageItem,
    removeSessionStorageItem,
    setLocalStorageItem,
    setSessionStorageItem,
    useForm,
    useStorage,
} from '../../../lib';

const Form = (): JSX.Element => {
    const localeStorageHook = useStorage({ source: 'local', key: 'localeInput' });
    const sessionStorageHook = useStorage({ source: 'session', key: 'sessionInput' });

    const { control, getValues, setValue } = useForm({
        defaultValues: { sessionInput: '', localeInput: '', localeInput2: '' },
        validationSchema: {},
    });

    useEffect(() => {
        // eslint-disable-next-line no-console
        console.log('sessionStorageHook', sessionStorageHook);
    }, [sessionStorageHook]);

    useEffect(() => {
        // eslint-disable-next-line no-console
        console.log('localeStorageHook', localeStorageHook);
    }, [localeStorageHook]);

    return (
        <Grid spacing={3}>
            <GridItem xs={6}>
                <Grid spacing={1}>
                    <GridItem>
                        <Grid spacingType="common">
                            <GridItem>
                                <Input name="localeInput" label="Locale Input" control={control} />
                            </GridItem>
                            <GridItem>
                                <Button
                                    text="Set Local Storage Item"
                                    onClick={() => setLocalStorageItem('localeInput', getValues('localeInput'))}
                                />
                            </GridItem>
                            <GridItem>
                                <Button
                                    text="Remove Local Storage Item 1"
                                    onClick={() => {
                                        removeLocalStorageItem('localeInput');
                                        setValue('localeInput', '');
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem>
                        <Grid spacingType="common">
                            <GridItem>
                                <Input name="localeInput2" label="Locale Input 2" control={control} />
                            </GridItem>
                            <GridItem>
                                <Button
                                    text="Set Local Storage Item 2"
                                    onClick={() => setLocalStorageItem('localeInput2', getValues('localeInput2'))}
                                />
                            </GridItem>
                            <GridItem>
                                <Button
                                    text="Remove Local Storage Item 2"
                                    onClick={() => {
                                        removeLocalStorageItem('localeInput2');
                                        setValue('localeInput2', '');
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                </Grid>
            </GridItem>
            <GridItem xs={6}>
                <Grid spacing={1}>
                    <GridItem>
                        <Input name="sessionInput" label="Session Input" control={control} />
                    </GridItem>
                    <GridItem>
                        <Button
                            text="Set Session Storage Item"
                            onClick={() => setSessionStorageItem('sessionInput', getValues('sessionInput'))}
                        />
                    </GridItem>
                    <GridItem>
                        <Button
                            text="Remove Session Storage Item"
                            onClick={() => {
                                removeSessionStorageItem('sessionInput');
                                setValue('sessionInput', '');
                            }}
                        />
                    </GridItem>
                </Grid>
            </GridItem>
        </Grid>
    );
};

export default Form;
