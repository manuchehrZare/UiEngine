import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Grid, GridItem, Nav, Paper, getLocalStorageItem } from '../../../lib';
import Test from './Test';
import Test2 from './Test2';
import Form from './Form';

const UseStoragePage: FC = () => {
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useStorage' }} />
                        <Box sx={{ p: 3 }}>
                            <Form />
                            <Grid>
                                <GridItem>
                                    <Box>getLocalStorageItem 1- {getLocalStorageItem('localeInput')}</Box>
                                    <Test />
                                </GridItem>
                                <GridItem>
                                    <Box>getLocalStorageItem 2 - {getLocalStorageItem('localeInput2')}</Box>
                                    <Test2 />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseStoragePage;
