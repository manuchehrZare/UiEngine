import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import {
    Button,
    DesignTypeEnum,
    Grid,
    GridItem,
    Input,
    Label,
    message,
    MessageTypeEnum,
    Nav,
    Paper,
    useClipboard,
    useForm,
    useWatch,
} from '../../../lib';

const UseClipboardPage: FC = () => {
    const { copy, copiedValue, isCopied } = useClipboard<number>({
        successDuration: 2000,
        onSuccess: (value) =>
            message({ variant: MessageTypeEnum.success, message: `Kopyalandı! ${JSON.stringify(value)}` }),
        onError: () => message({ variant: MessageTypeEnum.error, message: 'Kopyalama işlemi başarısız!' }),
    });

    const { control } = useForm({
        defaultValues: {
            input: 5,
        },
    });
    const inputWatch = useWatch({ control, fieldName: 'input' });

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useClipboard' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Input
                                        design={DesignTypeEnum.Default}
                                        label="Input for Copy Value"
                                        name="input"
                                        control={control}
                                        endAdornment={
                                            <Box sx={{ margin: '1px -12px 0px 0px' }}>
                                                <Button
                                                    text={isCopied ? 'Copied!' : 'Copy'}
                                                    onClick={() =>
                                                        copy(
                                                            inputWatch,
                                                            (val) => {
                                                                // eslint-disable-next-line no-console
                                                                console.log('SUCCESS', val, typeof val);
                                                            },
                                                            (err) => {
                                                                // eslint-disable-next-line no-console
                                                                console.log('ERROR', err);
                                                            },
                                                        )
                                                    }
                                                />
                                            </Box>
                                        }
                                    />
                                </GridItem>
                                <GridItem>
                                    <Label text="Kopyalanma Durumu" />
                                    <Label text={String(isCopied)} />
                                </GridItem>
                                <GridItem>
                                    <Label text="Kopyalanan Data" />
                                    {copiedValue && <Label text={JSON.stringify(copiedValue)} />}
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseClipboardPage;
