import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { DesignTypeEnum, Grid, GridItem, Input, Label, Nav, Paper, useDebounce, useForm, useWatch } from '../../../lib';

const UseDebouncePage: FC = () => {
    const { control } = useForm({
        defaultValues: {
            input: '',
        },
    });
    const inputWatch = useWatch({ control, fieldName: 'input' });
    const debounceValue = useDebounce<string>(inputWatch, 1000);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useDebounce' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Input
                                        design={DesignTypeEnum.Default}
                                        label="Input"
                                        name="input"
                                        control={control}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Label text="Input Value" />
                                    <Label text={inputWatch} />
                                </GridItem>
                                <GridItem>
                                    <Label text="Debounce Value" />
                                    <Label text={debounceValue} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseDebouncePage;
