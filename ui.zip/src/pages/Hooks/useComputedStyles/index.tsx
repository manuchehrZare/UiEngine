import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Paper, Nav, useComputedStyles, Label } from '../../../lib';

const UseComputedStylesPage: FC = () => {
    const element1 = useComputedStyles();
    const element2 = useComputedStyles();
    const element3 = useComputedStyles();

    const getNumberValue = (value: string) => {
        if (!value) return null;

        // Replace comma with dot to standardize decimal separator
        const standardized = value.replace(',', '.');

        // Regex to extract a number (supports optional negative sign and decimal)
        const match = /-?\d+(\.\d+)?/.exec(standardized);

        return match ? parseFloat(match[0]) : null;
    };

    const stylesWidth2 = getNumberValue(element2?.styles?.width);
    const stylesWidth3 = getNumberValue(element3?.styles?.width);

    // eslint-disable-next-line
    console.log('useComputedStyles-element1-styles', element1?.styles);
    // eslint-disable-next-line
    console.log('useComputedStyles-element2-styles', element2?.styles);
    // eslint-disable-next-line
    console.log('useComputedStyles-element3-styles', element3?.styles);

    return (
        <Layout>
            <Box height="100%">
                <Paper sx={{ height: '100%' }}>
                    <Nav ref={element1?.ref} navTitleProps={{ title: 'useComputedStyles (Element 1)' }} />
                    <Box
                        ref={element2?.ref}
                        sx={{ p: 3, ...(stylesWidth2 && { color: stylesWidth2 <= 900 ? 'blue' : 'red' }) }}>
                        <Label text="Element 2 (width <= 900 ? blue : red)" />
                        <Box>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ducimus alias cum error quae
                            labore soluta consequuntur voluptatum dolor earum accusantium magni assumenda aperiam
                            dignissimos, voluptates nam nisi, reprehenderit minus fuga? Accusantium corporis cumque et
                            minus, ratione placeat aut nisi ea quasi voluptatibus recusandae sequi sed consequuntur quod
                            magnam facere atque? Repellat minus atque aut nulla magni necessitatibus suscipit tempora
                            porro!
                        </Box>
                    </Box>
                    <Box
                        ref={element3?.ref}
                        sx={{ p: 3, ...(stylesWidth3 && { color: stylesWidth3 <= 900 ? 'red' : 'blue' }) }}>
                        <Label text="Element 3 (width <= 900 ? red : blue)" />
                        <Box>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ducimus alias cum error quae
                            labore soluta consequuntur voluptatum dolor earum accusantium magni assumenda aperiam
                            dignissimos, voluptates nam nisi, reprehenderit minus fuga? Accusantium corporis cumque et
                            minus, ratione placeat aut nisi ea quasi voluptatibus recusandae sequi sed consequuntur quod
                            magnam facere atque? Repellat minus atque aut nulla magni necessitatibus suscipit tempora
                            porro!
                        </Box>
                    </Box>
                    <Box
                        height={`calc(100% - ${element1?.styles?.height} - ${element2?.styles?.height} - ${element3?.styles?.height})`}
                        bgcolor={(theme) => theme.palette.warning.main}>
                        <Box sx={{ p: 3 }}>
                            Dynamic Element (100% - element1.styles.height - element2.styles.height -
                            element3.styles.height)
                        </Box>
                    </Box>
                </Paper>
            </Box>
        </Layout>
    );
};

export default UseComputedStylesPage;
