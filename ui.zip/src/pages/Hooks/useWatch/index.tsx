import { Box } from '@mui/material';
import type { FC } from 'react';
import { useEffect } from 'react';
import { Layout } from '../../../App';
import { Button, Grid, GridItem, Paper, useForm, Input, useWatch, Nav } from '../../../lib';

const UseWatchPage: FC = () => {
    interface IForm {
        input: string;
        input2: string;
    }

    const { control, handleSubmit } = useForm<IForm>({
        defaultValues: {
            input: '',
            input2: '',
        },
        validationSchema: {},
    });

    const [watchInput, watchInput2] = useWatch({ control, fieldName: ['input', 'input2'] });

    const onSubmit = (data: IForm) => {
        // eslint-disable-next-line no-console
        console.log(data);
    };

    useEffect(() => {
        // eslint-disable-next-line no-console
        console.log('watchInput', watchInput);
    }, [watchInput]);

    useEffect(() => {
        // eslint-disable-next-line no-console
        console.log('watchInput2', watchInput2);
    }, [watchInput2]);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useWatch' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Input name="input" label="Input" control={control} sx={{ marginBottom: 1 }} />
                                <Input name="input2" label="Input2" control={control} sx={{ marginBottom: 1 }} />
                                <Button text="Submit" type="submit" fullWidth sx={{ marginBottom: 1 }} />
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseWatchPage;
