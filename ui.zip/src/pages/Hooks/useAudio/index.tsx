import { Box } from '@mui/material';
import type { FC } from 'react';
import { useEffect, useMemo } from 'react';
import { Layout } from '../../../App';
import {
    Button,
    Checkbox,
    confirm,
    Grid,
    GridItem,
    message,
    Nav,
    Paper,
    RangeInput,
    useForm,
    useWatch,
    useAudio,
} from '../../../lib';

const UseAudioPage: FC = () => {
    const {
        playing,
        duration,
        currentTime,
        volume,
        muted,
        playbackRate,
        play,
        pause,
        stop,
        setVolume,
        setMuted,
        setPlaybackRate,
        seek,
        setLoop,
        error,
        loop,
    } = useAudio('/audio/useAudio.mp3', {
        autoplay: false,
        onPlayError: async (errorFrom) => {
            const response = await confirm({
                title: `Error:${errorFrom}`,
                body: 'Cannot play audio file do you want to play ?',
                okText: 'Yes',
                cancelText: 'No',
            });
            if (response) {
                play();
                message({ variant: 'success', message: `Response: ${response}` });
            }
        },
    });

    const { control, setValue } = useForm({
        defaultValues: { audioCheckbox: false, volume, playbackRate, currentTime },
    });
    const audioCheckboxVal = useWatch({ control, fieldName: 'audioCheckbox' });

    const formattedTime = useMemo(() => {
        const formatTime = (time: number) => {
            const minutes = Math.floor(time / 60);
            const seconds = Math.floor(time % 60);
            return `${minutes}:${seconds.toString().padStart(2, '0')}`;
        };
        return `${formatTime(currentTime)} / ${formatTime(duration)}`;
    }, [currentTime, duration]);

    useEffect(() => {
        audioCheckboxVal ? play() : pause();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [audioCheckboxVal]);

    useEffect(() => {
        setValue('currentTime', currentTime);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentTime]);

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useAudio' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="form">
                                        <GridItem>
                                            <Checkbox name="audioCheckbox" label="Audio Play/Pause" control={control} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>{error && <Box component="div">{error}</Box>}</GridItem>
                                <GridItem>
                                    <GridItem>
                                        <Grid spacingType="button">
                                            <GridItem xs="auto">
                                                <Button
                                                    text={playing ? 'Pause' : 'Play'}
                                                    onClick={playing ? pause : play}
                                                />
                                            </GridItem>
                                            <GridItem xs="auto">
                                                <Button text="Stop" onClick={stop} />
                                            </GridItem>
                                            <GridItem xs="auto">
                                                <Button
                                                    text={muted ? 'UnMute' : 'Mute'}
                                                    onClick={() => setMuted(!muted)}
                                                />
                                            </GridItem>
                                            <GridItem xs="auto">
                                                <Button
                                                    text={loop ? 'Unloop' : 'Loop'}
                                                    onClick={() => setLoop(!loop)}
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Grid columnGap={1}>
                                            <GridItem xs={6}>
                                                <RangeInput
                                                    min={0}
                                                    max={1}
                                                    step={0.1}
                                                    name="volume"
                                                    onChange={(_, val) => {
                                                        setVolume(Number(val));
                                                        setValue('volume', Number(val));
                                                    }}
                                                    control={control}
                                                    label="Volume"
                                                />
                                            </GridItem>
                                            <GridItem xs={6}>
                                                <RangeInput
                                                    min={0.5}
                                                    max={2}
                                                    step={0.1}
                                                    name="playbackRate"
                                                    onChange={(_, val) => {
                                                        setPlaybackRate(Number(val));
                                                        setValue('playbackRate', Number(val));
                                                    }}
                                                    control={control}
                                                    label="Playback Rate"
                                                />
                                            </GridItem>
                                            <GridItem xs={6}>
                                                <Box component="span">{formattedTime}</Box>
                                                <RangeInput
                                                    min={0}
                                                    max={duration}
                                                    step={0.1}
                                                    name="currentTime"
                                                    onChange={(_, val) => {
                                                        seek(Number(val));
                                                    }}
                                                    control={control}
                                                    label="Duration"
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseAudioPage;
