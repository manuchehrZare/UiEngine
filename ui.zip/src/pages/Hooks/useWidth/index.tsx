import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Grid, GridItem, Nav, Paper, useWidth } from '../../../lib';

const UseWidthPage: FC = () => {
    const width = useWidth();
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useWidth' }} />
                        <Box sx={{ p: 3 }}>{JSON.stringify(width)}</Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseWidthPage;
