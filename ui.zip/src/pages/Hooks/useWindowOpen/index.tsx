import { Box } from '@mui/material';
import type { FC } from 'react';
import { useEffect } from 'react';
import { Layout } from '../../../App';
import type { WindowOpenFeatures } from '../../../lib';
import {
    Button,
    Grid,
    GridItem,
    Label,
    Nav,
    Paper,
    useWindowOpen,
    WindowOpenProcessTypeEnum,
    // WindowOpenTargetEnum,
} from '../../../lib';

type WindowSentDataType = {
    name: string;
    token: string;
};

type WindowReceivedDataType = {};

const UseWindowOpenPage: FC = () => {
    const newWindowOrigins = {
        first: 'http://localhost:8022',
        second: 'https://reactjs.org',
    };
    const windowStyles = { width: 464, margin: { top: 72, bottom: 32, right: 24 } };
    const exampleFeautures: WindowOpenFeatures = {
        width: windowStyles.width,
        height: window.innerHeight - windowStyles.margin.top - windowStyles.margin.bottom - 52,
        left: window.innerWidth - windowStyles.width - windowStyles.margin.right,
        top: -window.innerHeight + windowStyles.margin.top,
        resizable: false,
        scrollbars: false,
        menubar: false,
        toolbar: false,
        location: false,
        status: false,
        fullscreen: false,
        noopener: false,
        noreferrer: false,
    };
    const newWindow1 = useWindowOpen<WindowSentDataType, WindowReceivedDataType, true>({
        expectMessage: true,
        url: newWindowOrigins.first,
        target: 'newWindow1',
        // target: WindowOpenTargetEnum.Blank,
        targetOrigin: newWindowOrigins.first,
        features: exampleFeautures,
        onOpen: () => {
            // eslint-disable-next-line no-console
            console.log('newWindow1 : onOpen - Window is opened.');
        },
        onClose: () => {
            // eslint-disable-next-line no-console
            console.log('newWindow1 : onClose - Window is closed.');
        },
        onWindowReady: () => {
            // eslint-disable-next-line no-console
            console.log('newWindow1 : onWindowReady - Window is ready.');
        },
        onMessage: (data) => {
            if (data.processType === WindowOpenProcessTypeEnum.WindowClosed) {
                // eslint-disable-next-line no-console
                console.log('newWindow1 : onMessage - Window is closed!', data);
            }
            if (data.processType === WindowOpenProcessTypeEnum.WindowReady) {
                // eslint-disable-next-line no-console
                console.log('newWindow1 : onMessage - Window is ready!');
            }
            if (data.processType === WindowOpenProcessTypeEnum.WindowMessage) {
                // eslint-disable-next-line no-console
                console.log('newWindow1 : onMessage - Window is talking!');
            }
        },
    });

    const newWindow2 = useWindowOpen<WindowSentDataType, WindowReceivedDataType, false>({
        expectMessage: false,
        url: newWindowOrigins.second,
        target: 'newWindow2',
        targetOrigin: newWindowOrigins.second,
        features: exampleFeautures,
        onOpen: () => {
            // eslint-disable-next-line no-console
            console.log('newWindow2 : onOpen - Window is opened.');
        },
        onClose: () => {
            // eslint-disable-next-line no-console
            console.log('newWindow2 : onClose - Window is closed.');
        },
    });

    useEffect(() => {
        return () => {
            newWindow1.close();
            newWindow2.close();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // // eslint-disable-next-line no-console
    // console.log('newWindow1', newWindow1);
    // // eslint-disable-next-line no-console
    // console.log('newWindow2', newWindow2);
    return (
        <Layout>
            <Grid spacing={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useWindowOpen' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={1}>
                                <GridItem>
                                    <Label text={`expectMessage : true`} />
                                </GridItem>
                                <GridItem>
                                    <Label text={`isOpen : ${newWindow1.isOpen}`} />
                                </GridItem>
                                <GridItem>
                                    <Label text={`isWindowReady : ${newWindow1.isWindowReady}`} />
                                </GridItem>
                                <GridItem>
                                    <Label text="Error 1" />
                                    {newWindow1.error && <Box>{JSON.stringify(newWindow1.error, null, 4)}</Box>}
                                </GridItem>
                                <GridItem>
                                    <Button text="Open Window 1" onClick={() => newWindow1.open()} />
                                </GridItem>
                                <GridItem>
                                    <Button
                                        text="Send Message"
                                        disabled={!newWindow1.isWindowReady}
                                        onClick={() => newWindow1.sendMessage({ token: '123', name: 'SekerUI' })}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Button text="Close Window 1" onClick={() => newWindow1.close()} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useWindowOpen' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={1}>
                                <GridItem>
                                    <Label text={`expectMessage : false`} />
                                </GridItem>
                                <GridItem>
                                    <Label text={`isOpen : ${newWindow2.isOpen}`} />
                                </GridItem>
                                <GridItem>
                                    <Label text="Error 2" />
                                    {newWindow2.error && <Box>{JSON.stringify(newWindow2.error, null, 4)}</Box>}
                                </GridItem>
                                <GridItem>
                                    <Button text="Open Window 2" onClick={() => newWindow2.open()} />
                                </GridItem>
                                <GridItem>
                                    <Button text="Close Window 2" onClick={() => newWindow2.close()} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseWindowOpenPage;
