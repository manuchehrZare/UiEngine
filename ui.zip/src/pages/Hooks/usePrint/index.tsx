import type { FC } from 'react';
import { Layout } from '../../../App';
import { Box, Button, Grid, GridItem, Label, Nav, Paper, usePrint } from '../../../lib';
import SubComponent from './SubComponent';

const UsePrintPage: FC = () => {
    const { handlePrint: handlePrintHidden, ref: refHidden } = usePrint({
        documentTitle: 'Document_Hidden',
    });

    const { handlePrint: handlePrint1, ref: ref1 } = usePrint({
        documentTitle: 'Document_1',
    });

    const { handlePrint: handlePrint2, ref: ref2 } = usePrint({
        documentTitle: 'Document_2',
    });

    const { handlePrint: handlePrintSub, ref: refSub } = usePrint();

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'usePrint' }} />
                        <Box sx={{ p: 3 }} hidden>
                            <Grid spacing={3} ref={refHidden}>
                                <GridItem>
                                    <Label design="SET" align="center" text="Printed Hidden Value" />
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3} ref={ref1}>
                                <GridItem>
                                    <Label design="SET" align="center" text="Printed 1 Value" />
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3} ref={ref2}>
                                <GridItem>
                                    <Label design="SET" align="center" text="Printed 2 Value" />
                                </GridItem>
                            </Grid>
                        </Box>
                        <SubComponent ref={refSub} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Button text="Print Hidden" onClick={handlePrintHidden} />
                                    <Button text="Print 1" onClick={handlePrint1} />
                                    <Button text="Print 2" onClick={handlePrint2} />
                                    <Button text="Print Sub" onClick={handlePrintSub} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UsePrintPage;
