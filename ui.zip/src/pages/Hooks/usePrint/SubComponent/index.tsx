import type { FC, ForwardedRef } from 'react';
import { forwardRef } from 'react';
import { Grid, GridItem, Box, Label } from '../../../../lib';

interface IProps {
    ref: ForwardedRef<null>;
}

const SubComponent: FC<IProps> = forwardRef((_, ref) => {
    return (
        <Box sx={{ p: 3 }} ref={ref}>
            <Grid spacing={3}>
                <GridItem>
                    <Label design="SET" align="center" text="SubComponent Printed Value" />
                </GridItem>
            </Grid>
        </Box>
    );
});

export default SubComponent;
