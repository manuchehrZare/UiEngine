import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Grid, GridItem, Paper, Button, Nav, useTimer, message } from '../../../lib';

const UseTimerPage: FC = () => {
    const {
        changeSpeedMultiplier,
        hours,
        milliseconds,
        minutes,
        seconds,
        start,
        stop,
        reset,
        isRunning,
        isCompleted,
        remainingTime,
        progress,
    } = useTimer({
        stopValues: { seconds: 3 },
        // startValues: { hours: 0, minutes: 0, seconds: 2, milliseconds: 0 },
        // stopValues: { hours: 0, minutes: 0, seconds: 5, milliseconds: 0 },
        // isCountdown: true, // Geri sayım
        // speedMultiplier: 50, // Hız çarpanı
        // returnValues: {
        //     hours: false,
        //     // minutes: false,
        //     // seconds: false,
        //     milliseconds: false,
        // },
        onStart: (options) => {
            // eslint-disable-next-line
            console.log('Timer started!', options);
        },
        onStop: (stoppedTime, options) => {
            // eslint-disable-next-line
            console.log('Timer stopped:', stoppedTime, options);
        },
        onReset: (lastTime, newOptions) => {
            // eslint-disable-next-line
            console.log('Reset Timer:', lastTime, newOptions);
        },
        onError: (error) => {
            message({ variant: 'error', message: error.message });
        },
    });

    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useTimer' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Box textAlign="center">
                                        <Box component="b">{hours}</Box> {hours > 1 ? 'Hours' : 'Hour'} &nbsp;
                                        <Box component="b">{minutes}</Box> {minutes > 1 ? 'Minutes' : 'Minute'} &nbsp;
                                        <Box component="b">{seconds}</Box> {seconds > 1 ? 'Seconds' : 'Second'} &nbsp;
                                        <Box component="b">{milliseconds}</Box>&nbsp;
                                        {milliseconds > 1 ? 'Milliseconds' : 'Millisecond'}
                                        <Box mt={1}>
                                            <Box component="b">progress :</Box>&nbsp; %{progress.toFixed(2)}
                                        </Box>
                                        <Box mt={1}>
                                            <Box component="b">remainingTime :</Box>&nbsp;{' '}
                                            {JSON.stringify(remainingTime, null, 4)}
                                        </Box>
                                        <Box mt={1}>
                                            <Box component="b">isRunning :</Box>&nbsp;
                                            {String(isRunning)}
                                        </Box>
                                        <Box mt={1}>
                                            <Box component="b">isCompleted :</Box>&nbsp;
                                            {String(isCompleted)}
                                        </Box>
                                    </Box>
                                </GridItem>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem xs="auto">
                                            <Button onClick={start} text="start" />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button onClick={stop} text="stop" />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button onClick={() => reset()} text="reset" />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button
                                                onClick={() =>
                                                    reset({
                                                        isCountdown: true,
                                                        startValues: { seconds: 8 },
                                                        stopValues: { seconds: 0 },
                                                        // speedMultiplier: 10,
                                                        // returnValues: { minutes: false },
                                                    })
                                                }
                                                text="reset({...})"
                                            />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button
                                                onClick={() => changeSpeedMultiplier(10)}
                                                text="changeSpeedMultiplier"
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseTimerPage;
