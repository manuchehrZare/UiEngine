import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Button, Grid, GridItem, Label, Nav, Paper, useIsFirstRender, useReRender } from '../../../lib';

const UseIsFirstRenderPage: FC = () => {
    const isFirst = useIsFirstRender();
    const { reRender } = useReRender();

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useIsFirstRender' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Label text="First Render? " />
                                    <Label text={isFirst ? 'Yes' : 'No'} />
                                </GridItem>
                                <GridItem>
                                    <Button text="reRender" onClick={reRender} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseIsFirstRenderPage;
