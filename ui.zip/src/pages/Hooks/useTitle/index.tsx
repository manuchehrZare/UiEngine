import { Box } from '@mui/material';
import { upperFirst } from 'lodash';
import type { FC } from 'react';
import { Layout } from '../../../App';
import {
    Button,
    DesignTypeEnum,
    Grid,
    GridItem,
    Input,
    Label,
    Nav,
    Paper,
    useForm,
    useTitle,
    useWatch,
} from '../../../lib';

const UseTitlePage: FC = () => {
    const pageTitle: string = 'useTitle';
    const initTitle: string = `${import.meta.env.VITE_APP_TITLE} | Hooks - ${upperFirst(pageTitle)}`;
    const { control, reset } = useForm({
        defaultValues: {
            input: initTitle,
        },
    });
    const inputWatch = useWatch({ control, fieldName: 'input' });

    useTitle(inputWatch || initTitle);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: pageTitle }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Input
                                        design={DesignTypeEnum.Default}
                                        label="Input"
                                        name="input"
                                        control={control}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Label text="Input Value" />
                                    <Label text={inputWatch} />
                                </GridItem>
                                <GridItem>
                                    <Button text="Reset" onClick={() => reset()} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseTitlePage;
