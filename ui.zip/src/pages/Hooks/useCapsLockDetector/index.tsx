import type { FC } from 'react';
import { useRef } from 'react';
import * as yup from 'yup';
import { Layout } from '../../../App';
import { Box, Button, Grid, GridItem, Input, Nav, Paper, useForm } from '../../../lib';
interface IFormValues {
    multilineTextInput: string;
    textInput: string;
    validationTextInput: string;
}

const UseCapsLockDetectorPage: FC = () => {
    const { handleSubmit, control } = useForm<IFormValues>({
        defaultValues: {
            textInput: '',
            multilineTextInput: '',
            validationTextInput: '',
        },
        validationSchema: {
            validationTextInput: yup.string().min(10).required('This field is required.'),
        },
    });

    const textInputRef = useRef<HTMLInputElement>(null);
    const multilineTextInputRef = useRef<HTMLInputElement>(null);
    const validationTextInputRef = useRef<HTMLInputElement>(null);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useCapsLockDetector - Text Input' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Input
                                        control={control}
                                        type="password"
                                        name="textInput"
                                        label="CapsLockState Detect - Text Input"
                                        inputRef={textInputRef}
                                        passwordVisibility
                                        capslockDetector={{
                                            /* onCapslockDetector: (status, text) => {
                                                console.log('CapslockStatus ==> ', status);
                                                console.log('Helper text ==> ', text);
                                            }, */
                                            Tooltip: { show: false, title: 'Capslock custom uyarı!!!' },
                                        }}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        control={control}
                                        name="multilineTextInput"
                                        label="CapsLockState Detect - Multiline Text Input"
                                        inputRef={multilineTextInputRef}
                                        multiline
                                        rows={3}
                                        capslockDetector={{
                                            onCapslockDetector: (status, text) => {
                                                // eslint-disable-next-line no-console
                                                console.log('CapslockStatus ==> ', status);
                                                // eslint-disable-next-line no-console
                                                console.log('Helper text ==> ', text);
                                            },
                                            Tooltip: { placement: 'bottom-start', sx: { background: 'red' } },
                                        }}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        control={control}
                                        name="validationTextInput"
                                        label="CapsLockState Detect - Validation Text Input"
                                        inputRef={validationTextInputRef}
                                        capslockDetector
                                    />
                                </GridItem>
                                <GridItem>
                                    <Button
                                        text="Submit"
                                        onClick={handleSubmit((data) => {
                                            // eslint-disable-next-line no-console
                                            console.log('data ===> ', data);
                                        })}
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseCapsLockDetectorPage;
