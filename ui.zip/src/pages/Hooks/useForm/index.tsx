import { Box } from '@mui/material';
import type { FC } from 'react';
import { useEffect } from 'react';
import * as yup from 'yup';
import { Layout } from '../../../App';
import { Button, Grid, GridItem, Paper, useForm, Input, DatePicker, Nav } from '../../../lib';

const UseFormPage: FC = () => {
    interface IForm {
        date: number | null;
        input: string;
        input2: string;
    }

    const {
        control,
        handleSubmit,
        getValues,
        setValue,
        clearErrors,
        trigger,
        reset,
        setFieldError,
        watch,
        setFocus,
        resetField,
        formState,
    } = useForm<IForm>({
        defaultValues: {
            input: '123',
            input2: '123',
            date: null,
        },
        validationSchema: {
            input: yup.string().required('Boş olamaz.'),
            input2: yup.string().required('Input2 boş olamaz.'),
        },
    });

    const { touchedFields, dirtyFields } = formState;

    useEffect(() => {
        watch((input, { name, type }) => {
            // eslint-disable-next-line no-console
            console.log(input, name, type);
        });
    }, [watch]);

    const onSubmit = (data: IForm) => {
        // eslint-disable-next-line no-console
        console.log(data);
    };

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useForm' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Input name="input" label="Input" control={control} sx={{ marginBottom: 1 }} />
                                <Input name="input2" label="Input2" control={control} sx={{ marginBottom: 1 }} />
                                <DatePicker
                                    name="date"
                                    label="date"
                                    control={control}
                                    sx={{ marginBottom: 1 }}
                                    unixTime
                                />
                                <Button text="Submit" type="submit" fullWidth sx={{ marginBottom: 1 }} />
                                <Button text={`getValues ${getValues('input')}`} fullWidth sx={{ marginBottom: 1 }} />
                                <Button
                                    text="setValue"
                                    onClick={() => {
                                        setValue('input2', 'Hello');
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="resetField"
                                    onClick={() => {
                                        resetField('input2');
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="Trigger"
                                    onClick={() => {
                                        trigger();
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="setFieldError"
                                    onClick={() => {
                                        setFieldError('input2', 'setFieldError errorMsg');
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="clearErrors"
                                    onClick={() => {
                                        clearErrors();
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="setFocus"
                                    onClick={() => {
                                        setFocus('input');
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="reset"
                                    onClick={() => {
                                        reset();
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="show touchedFields"
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('console.log(touchedFields)', touchedFields);
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                                <Button
                                    text="show dirtyFields"
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('console.log(dirtyFields)', dirtyFields);
                                    }}
                                    fullWidth
                                    sx={{ marginBottom: 1 }}
                                />
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseFormPage;
