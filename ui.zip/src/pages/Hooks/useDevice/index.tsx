import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Grid, GridItem, Nav, Paper, useDevice } from '../../../lib';

const UseDevicePage: FC = () => {
    const device = useDevice();
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useDevice' }} />
                        <Box sx={{ p: 3 }}>
                            <h1>{JSON.stringify(device)}</h1>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseDevicePage;
