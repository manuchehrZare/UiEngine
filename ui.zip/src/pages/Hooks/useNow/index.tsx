import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Grid, GridItem, Paper, Nav, useNow } from '../../../lib';
import { format } from 'date-fns';

const UseNavPage: FC = () => {
    const { days, hours, milliseconds, minutes, months, seconds, years } = useNow();
    const formattedNow = format(
        new Date(years, months, days, hours, minutes, seconds, milliseconds),
        'dd MMMM, eeee, yyyy, kk:mm:ss:SSS',
    );
    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useNow' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Box textAlign="center">
                                        <Box component="b">{formattedNow}</Box>
                                    </Box>
                                </GridItem>
                                <GridItem>
                                    <Box textAlign="center">
                                        <Box component="b">{days}</Box> {days > 1 ? 'Days' : 'Day'} &nbsp;
                                        <Box component="b">{months + 1}</Box> {months + 1 > 1 ? 'Months' : 'Month'}{' '}
                                        &nbsp;
                                        <Box component="b">{years}</Box> {years > 1 ? 'Years' : 'Year'} &nbsp;
                                    </Box>
                                </GridItem>
                                <GridItem>
                                    <Box textAlign="center">
                                        <Box component="b">{hours}</Box> {hours > 1 ? 'Hours' : 'Hour'} &nbsp;
                                        <Box component="b">{minutes}</Box> {minutes > 1 ? 'Minutes' : 'Minute'} &nbsp;
                                        <Box component="b">{seconds}</Box> {seconds > 1 ? 'Seconds' : 'Second'} &nbsp;
                                        <Box component="b">{milliseconds}</Box>&nbsp;
                                        {milliseconds > 1 ? 'Milliseconds' : 'Millisecond'}
                                    </Box>
                                </GridItem>
                                <GridItem>
                                    <Box textAlign="center">
                                        <Box component="b">{hours.toString().padStart(2, '0')} :</Box> &nbsp;
                                        <Box component="b">{minutes.toString().padStart(2, '0')} :</Box> &nbsp;
                                        <Box component="b">{seconds.toString().padStart(2, '0')} :</Box> &nbsp;
                                        <Box component="b">{milliseconds.toString().padStart(3, '0')}</Box> &nbsp;
                                    </Box>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseNavPage;
