import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../App';
import { Button, Grid, GridItem, Label, Nav, Paper, useReRender } from '../../../lib';

const UseReRenderPage: FC = () => {
    const { reRender } = useReRender();

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useReRender' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Label text="Date Value" />
                                    <Label text={new Date().toString()} />
                                </GridItem>
                                <GridItem>
                                    <Button text="reRender" onClick={reRender} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseReRenderPage;
