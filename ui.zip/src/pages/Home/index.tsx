import type { FC } from 'react';
import { Layout } from '../../App';
import { DesignTypeEnum, Grid, GridItem, Label, Paper } from '../../lib';
import {
    LibraryAddOutlined,
    SettingsOutlined,
    StorageRounded,
    ViewTimelineOutlined,
    WebhookOutlined,
} from '@mui/icons-material';
import { Link } from 'react-router-dom';
import { MenuGroupEnum } from '../../App/_root/data';
import { kebabCase } from 'lodash';

const Dashboard: FC = () => {
    const boxes = [
        {
            title: 'Form Components',
            group: MenuGroupEnum.FORM,
            icon: <StorageRounded fontSize="large" />,
        },
        {
            title: 'Display Components',
            group: MenuGroupEnum.DISPLAY,
            icon: <ViewTimelineOutlined fontSize="large" />,
        },
        {
            title: 'Others',
            group: MenuGroupEnum.OTHERS,
            icon: <LibraryAddOutlined fontSize="large" />,
        },
        {
            title: 'Hooks',
            group: MenuGroupEnum.HOOKS,
            icon: <WebhookOutlined fontSize="large" />,
        },
        {
            title: 'Utils',
            group: MenuGroupEnum.UTILS,
            icon: <SettingsOutlined fontSize="large" />,
        },
    ];

    return (
        <Layout showSidebar={false}>
            <Grid spacingType="common">
                <GridItem>
                    <Label align="center" text="Şekerbank React UI Library" />
                </GridItem>
                <GridItem pb={2}>
                    <Grid spacingType="common">
                        {boxes.map((item, index) => (
                            <GridItem key={`${String(index)}`} md={6} lg>
                                <Link to={kebabCase(item.group)}>
                                    <Paper
                                        sx={{
                                            p: 5,
                                            textAlign: 'center',
                                            ':hover': {
                                                borderColor: (theme) => theme.palette.green.main,
                                                color: (theme) => theme.palette.green.main,

                                                '.sekerUI-Label': {
                                                    '.MuiTypography-root': {
                                                        color: (theme) => theme.palette.green.main,
                                                    },
                                                },
                                            },
                                        }}>
                                        {item.icon}
                                        <Label design={DesignTypeEnum.Default} text={item.title} align="center" />
                                    </Paper>
                                </Link>
                            </GridItem>
                        ))}
                    </Grid>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default Dashboard;
