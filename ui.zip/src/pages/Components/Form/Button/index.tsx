import { StarOutlineRounded } from '@mui/icons-material';
import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Button, Grid, GridItem, Label, Nav, Paper } from '../../../../lib';

const ButtonPage: FC = () => {
    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Sizes' }} />
                        <Box p={2}>
                            <Grid>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="text"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button size="small" text="Small" variant="text" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="medium" text="Medium" variant="text" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="large" text="Large" variant="text" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="outlined"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button size="small" text="Small" variant="outlined" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="medium" text="Medium" variant="outlined" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="large" text="Large" variant="outlined" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="large" text="Large" variant="outlined" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="contained"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button size="small" text="Small" variant="contained" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="medium" text="Medium" variant="contained" />
                                        </GridItem>
                                        <GridItem>
                                            <Button size="large" text="Large" variant="contained" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text="With Icon" align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button
                                                size="small"
                                                text="Small"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                size="medium"
                                                text="Medium"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                size="large"
                                                text="Large"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Rounded' }} />
                        <Box p={2}>
                            <Grid>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="text"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Rounded" variant="text" rounded />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Left Rounded" variant="text" leftRounded />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Right Rounded" variant="text" rightRounded />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="outlined"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Rounded" variant="outlined" rounded />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Left Rounded" variant="outlined" leftRounded />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Right Rounded" variant="outlined" rightRounded />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="contained"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Rounded" variant="contained" rounded />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Left Rounded" variant="contained" leftRounded />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Right Rounded" variant="contained" rightRounded />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text="With Icon" align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button
                                                text="Rounded"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                rounded
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Left Rounded"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                leftRounded
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Right Rounded"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                rightRounded
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Colors' }} />
                        <Box p={2}>
                            <Grid>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="text"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Primary" variant="text" color="primary" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Secondary" variant="text" color="secondary" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Error" variant="text" color="error" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Info" variant="text" color="info" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Warning" variant="text" color="warning" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Success" variant="text" color="success" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Inherit" variant="text" color="inherit" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="outlined"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Primary" variant="outlined" color="primary" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Secondary" variant="outlined" color="secondary" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Error" variant="outlined" color="error" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Info" variant="outlined" color="info" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Warning" variant="outlined" color="warning" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Success" variant="outlined" color="success" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Inherit" variant="outlined" color="inherit" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="contained"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Primary" variant="contained" color="primary" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Secondary" variant="contained" color="secondary" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Error" variant="contained" color="error" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Info" variant="contained" color="info" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Warning" variant="contained" color="warning" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Success" variant="contained" color="success" />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Inherit" variant="contained" color="inherit" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text="With Icon" align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button
                                                text="Primary"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="primary"
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Secondary"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="secondary"
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Error"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="error"
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Info"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="info"
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Warning"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="warning"
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Success"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="success"
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Inherit"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="inherit"
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Disabled' }} />
                        <Box p={2}>
                            <Grid>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="text"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Primary" variant="text" color="primary" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Secondary" variant="text" color="secondary" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Error" variant="text" color="error" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Info" variant="text" color="info" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Warning" variant="text" color="warning" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Success" variant="text" color="success" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Inherit" variant="text" color="inherit" disabled />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="outlined"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Primary" variant="outlined" color="primary" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Secondary" variant="outlined" color="secondary" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Error" variant="outlined" color="error" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Info" variant="outlined" color="info" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Warning" variant="outlined" color="warning" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Success" variant="outlined" color="success" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Inherit" variant="outlined" color="inherit" disabled />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text='Variant="contained"' align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button text="Primary" variant="contained" color="primary" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Secondary" variant="contained" color="secondary" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Error" variant="contained" color="error" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Info" variant="contained" color="info" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Warning" variant="contained" color="warning" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Success" variant="contained" color="success" disabled />
                                        </GridItem>
                                        <GridItem>
                                            <Button text="Inherit" variant="contained" color="inherit" disabled />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={3} textAlign="center">
                                    <Label text="With Icon" align="center" />
                                    <Grid pt={0.5} spacingType="button">
                                        <GridItem>
                                            <Button
                                                text="Primary"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="primary"
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Secondary"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="secondary"
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Error"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="error"
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Info"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="info"
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Warning"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="warning"
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Success"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="success"
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text="Inherit"
                                                variant="contained"
                                                iconRight={<StarOutlineRounded />}
                                                color="inherit"
                                                disabled
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button Loading' }} />
                        <Box p={2}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Label
                                        text="Variant & Size"
                                        align="center"
                                        color={(theme) => theme.palette.common.black}
                                    />
                                    <Grid>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="text"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button size="small" text="Small" variant="text" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button size="medium" text="Medium" variant="text" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button size="large" text="Large" variant="text" loading />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="outlined"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button size="small" text="Small" variant="outlined" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button size="medium" text="Medium" variant="outlined" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button size="large" text="Large" variant="outlined" loading />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="contained"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button size="small" text="Small" variant="contained" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button size="medium" text="Medium" variant="contained" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button size="large" text="Large" variant="contained" loading />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text="With Icon" align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        size="small"
                                                        text="Small"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        size="medium"
                                                        text="Medium"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        size="large"
                                                        text="Large"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Label
                                        text="Variant & Color"
                                        align="center"
                                        color={(theme) => theme.palette.common.black}
                                    />
                                    <Grid>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="text"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button text="Primary" variant="text" color="primary" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Secondary" variant="text" color="secondary" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Error" variant="text" color="error" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Info" variant="text" color="info" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Warning" variant="text" color="warning" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Success" variant="text" color="success" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Inherit" variant="text" color="inherit" loading />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="outlined"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button text="Primary" variant="outlined" color="primary" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="outlined"
                                                        color="secondary"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Error" variant="outlined" color="error" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Info" variant="outlined" color="info" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Warning" variant="outlined" color="warning" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Success" variant="outlined" color="success" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Inherit" variant="outlined" color="inherit" loading />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="contained"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        text="Primary"
                                                        variant="contained"
                                                        color="primary"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="contained"
                                                        color="secondary"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Error" variant="contained" color="error" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Info" variant="contained" color="info" loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Warning"
                                                        variant="contained"
                                                        color="warning"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Success"
                                                        variant="contained"
                                                        color="success"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Inherit"
                                                        variant="contained"
                                                        color="inherit"
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text="With Icon" align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        text="Primary"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="primary"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="secondary"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Error"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="error"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Info"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="info"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Warning"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="warning"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Success"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="success"
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Inherit"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="inherit"
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Label
                                        text="Variant & Disabled & Color"
                                        align="center"
                                        color={(theme) => theme.palette.common.black}
                                    />
                                    <Grid>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="text"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        text="Primary"
                                                        variant="text"
                                                        color="primary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="text"
                                                        color="secondary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Error"
                                                        variant="text"
                                                        color="error"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Info" variant="text" color="info" disabled loading />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Warning"
                                                        variant="text"
                                                        color="warning"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Success"
                                                        variant="text"
                                                        color="success"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Inherit"
                                                        variant="text"
                                                        color="inherit"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="outlined"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        text="Primary"
                                                        variant="outlined"
                                                        color="primary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="outlined"
                                                        color="secondary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Error"
                                                        variant="outlined"
                                                        color="error"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Info"
                                                        variant="outlined"
                                                        color="info"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Warning"
                                                        variant="outlined"
                                                        color="warning"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Success"
                                                        variant="outlined"
                                                        color="success"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Inherit"
                                                        variant="outlined"
                                                        color="inherit"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text='Variant="contained"' align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        text="Primary"
                                                        variant="contained"
                                                        color="primary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="contained"
                                                        color="secondary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Error"
                                                        variant="contained"
                                                        color="error"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Info"
                                                        variant="contained"
                                                        color="info"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Warning"
                                                        variant="contained"
                                                        color="warning"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Success"
                                                        variant="contained"
                                                        color="success"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Inherit"
                                                        variant="contained"
                                                        color="inherit"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem xs={3} textAlign="center">
                                            <Label text="With Icon" align="center" />
                                            <Grid pt={0.5} spacingType="button">
                                                <GridItem>
                                                    <Button
                                                        text="Primary"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="primary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Secondary"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="secondary"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Error"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="error"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Info"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="info"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Warning"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="warning"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Success"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="success"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text="Inherit"
                                                        variant="contained"
                                                        iconRight={<StarOutlineRounded />}
                                                        color="inherit"
                                                        disabled
                                                        loading
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Button with Long Text' }} />
                        <Box p={2}>
                            <Grid spacingType="button">
                                <GridItem>
                                    <Button
                                        size="small"
                                        color="primary"
                                        text="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose"
                                        variant="contained"
                                    />
                                </GridItem>
                                <GridItem>
                                    <Button
                                        size="small"
                                        text="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose"
                                        variant="outlined"
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ButtonPage;
