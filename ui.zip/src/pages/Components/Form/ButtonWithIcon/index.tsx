import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, DesignTypeEnum, Button, Divider, Nav } from '../../../../lib';
import { StarOutlineRounded } from '@mui/icons-material';

const ButtonWithIconPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Default Icon Button' }} />
                        <Box sx={{ p: 3 }}>
                            <Divider sx={{ fontWeight: 600 }}>Default Just Icon</Divider>
                            <Grid spacing={3} py={2}>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="small" icon={<StarOutlineRounded />} />
                                    <Button variant="outlined" size="small" icon={<StarOutlineRounded />} />
                                    <Button variant="contained" size="small" icon={<StarOutlineRounded />} />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="small" icon={<StarOutlineRounded />} rounded />
                                    <Button variant="outlined" size="small" icon={<StarOutlineRounded />} rounded />
                                    <Button variant="contained" size="small" icon={<StarOutlineRounded />} rounded />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="medium" icon={<StarOutlineRounded />} />
                                    <Button variant="outlined" size="medium" icon={<StarOutlineRounded />} />
                                    <Button variant="contained" size="medium" icon={<StarOutlineRounded />} />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="medium" icon={<StarOutlineRounded />} rounded />
                                    <Button variant="outlined" size="medium" icon={<StarOutlineRounded />} rounded />
                                    <Button variant="contained" size="medium" icon={<StarOutlineRounded />} rounded />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="large" icon={<StarOutlineRounded />} />
                                    <Button variant="outlined" size="large" icon={<StarOutlineRounded />} />
                                    <Button variant="contained" size="large" icon={<StarOutlineRounded />} />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="large" icon={<StarOutlineRounded />} rounded />
                                    <Button variant="outlined" size="large" icon={<StarOutlineRounded />} rounded />
                                    <Button variant="contained" size="large" icon={<StarOutlineRounded />} rounded />
                                </GridItem>
                                {/** Loading */}
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="small" icon={<StarOutlineRounded />} loading />
                                    <Button variant="outlined" size="small" icon={<StarOutlineRounded />} loading />
                                    <Button variant="contained" size="small" icon={<StarOutlineRounded />} loading />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="small" icon={<StarOutlineRounded />} rounded loading />
                                    <Button
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="medium" icon={<StarOutlineRounded />} loading />
                                    <Button variant="outlined" size="medium" icon={<StarOutlineRounded />} loading />
                                    <Button variant="contained" size="medium" icon={<StarOutlineRounded />} loading />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="large" icon={<StarOutlineRounded />} loading />
                                    <Button variant="outlined" size="large" icon={<StarOutlineRounded />} loading />
                                    <Button variant="contained" size="large" icon={<StarOutlineRounded />} loading />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="large" icon={<StarOutlineRounded />} rounded loading />
                                    <Button
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                </GridItem>
                            </Grid>
                            <Divider sx={{ fontWeight: 600 }}>Default Icon Button</Divider>
                            <Grid spacing={3} py={2}>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="small" icon={<StarOutlineRounded />} iconButton />
                                    <Button variant="outlined" size="small" icon={<StarOutlineRounded />} iconButton />
                                    <Button variant="contained" size="small" icon={<StarOutlineRounded />} iconButton />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="medium" icon={<StarOutlineRounded />} iconButton />
                                    <Button variant="outlined" size="medium" icon={<StarOutlineRounded />} iconButton />
                                    <Button
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button variant="text" size="large" icon={<StarOutlineRounded />} iconButton />
                                    <Button variant="outlined" size="large" icon={<StarOutlineRounded />} iconButton />
                                    <Button variant="contained" size="large" icon={<StarOutlineRounded />} iconButton />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                </GridItem>
                                {/** Loading */}
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'SET Icon Button' }} />
                        <Box sx={{ p: 3 }}>
                            <Divider sx={{ fontWeight: 600 }}>SET Just Icon</Divider>
                            <Grid spacing={3} py={2}>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                    />
                                </GridItem>
                                {/** Loading */}
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        loading
                                    />
                                </GridItem>
                            </Grid>
                            <Divider sx={{ fontWeight: 600 }}>SET Icon Button</Divider>
                            <Grid spacing={3} py={2}>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                    />
                                </GridItem>
                                {/** Loading */}
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="small"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="medium"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                                <GridItem display="flex" justifyContent="space-around">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="text"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="outlined"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        variant="contained"
                                        size="large"
                                        icon={<StarOutlineRounded />}
                                        rounded
                                        iconButton
                                        loading
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ButtonWithIconPage;
