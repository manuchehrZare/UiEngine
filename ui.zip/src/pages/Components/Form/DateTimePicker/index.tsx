import { Layout } from '../../../../App';
import type { FC } from 'react';
import * as yup from 'yup';
import { Box, Button, Grid, GridItem, Paper, useForm, DateTimePicker, useWatch, Nav } from '../../../../lib';
import { faker } from '@faker-js/faker';

const DateTimePickerPage: FC = () => {
    const { control, handleSubmit, reset } = useForm({
        defaultValues: {
            dateTimePicker: null,
            dateTimePicker2: null,
            dateTimePicker3: null,
            dateTimePicker4: null,
            dateTimePickerDisabled: new Date(),
        },
        validationSchema: {
            dateTimePicker: yup.number().nullable().required('Boş olamaz.').typeError('Type Error'),
            dateTimePicker2: yup.date().nullable().required('Boş olamaz.').typeError('Type Error'),
            dateTimePicker3: yup.date().nullable().required('Boş olamaz.').typeError('Type Error'),
        },
    });
    const dateTimeVal = useWatch({ control, fieldName: 'dateTimePicker' });

    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log('--', data);
    };

    // eslint-disable-next-line no-console
    console.log('dateTimeVal', dateTimeVal);

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Variant' }} />
                        <Grid spacingType="form" p={2}>
                            <GridItem xs>
                                <DateTimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="outlined"
                                    control={control}
                                    unixTime
                                    variant="outlined"
                                    helperText="Variant Outlined"
                                />
                            </GridItem>
                            <GridItem xs>
                                <DateTimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="standard"
                                    control={control}
                                    unixTime
                                    variant="standard"
                                    helperText="Variant Standard"
                                />
                            </GridItem>
                            <GridItem xs>
                                <DateTimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="filled"
                                    control={control}
                                    unixTime
                                    variant="filled"
                                    helperText="Variant Filled"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form">
                            <GridItem xs>
                                <DateTimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="dateTimePicker"
                                    control={control}
                                    unixTime
                                    variant="filled"
                                />
                            </GridItem>
                            <GridItem xs>
                                <DateTimePicker
                                    label={faker.lorem.sentence(15)}
                                    labelPlacement="start"
                                    name="dateTimePicker"
                                    control={control}
                                    unixTime
                                    variant="outlined"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'DateTimePicker' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <DateTimePicker
                                            label="DateTimePicker -- UnixTime"
                                            name="dateTimePicker"
                                            control={control}
                                            unixTime
                                            analogClock
                                            // placeholder="Placeholder"
                                            // onOpen={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onOpen');
                                            // }}
                                            // onClose={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onClose');
                                            // }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            label="DateTimePicker -- Date"
                                            name="dateTimePicker2"
                                            control={control}
                                            // placeholder="Placeholder"
                                            // onOpen={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onOpen');
                                            // }}
                                            // onClose={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onClose');
                                            // }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            label="DateTimePicker -- Views"
                                            name="dateTimePicker3"
                                            control={control}
                                            views={['day', 'year', 'hours', 'minutes']}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            label="DateTimePicker -- String Date"
                                            name="dateTimePicker4"
                                            control={control}
                                            format="EEEE, dd MMMM yyyy HH:mm"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            label="DateTimePicker -- Disabled"
                                            name="dateTimePickerDisabled"
                                            control={control}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            label="DateTimePicker -- ReadOnly"
                                            name="dateTimePickerDisabled"
                                            control={control}
                                            readOnly
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            labelPlacement="start"
                                            label="SET LabelPlacement='start' DateTimePicker"
                                            name="dateTimePicker"
                                            control={control}
                                            unixTime
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DateTimePicker
                                            label="SET LabelPlacement='top' DateTimePicker"
                                            name="dateTimePicker"
                                            control={control}
                                            unixTime
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button text="Submit" type="submit" />
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default DateTimePickerPage;
