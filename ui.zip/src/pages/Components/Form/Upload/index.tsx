import type { FC } from 'react';
import type { IUploadDocument } from '../../../../lib';
import { Box, Button, Grid, GridItem, Nav, Paper, Upload, useForm } from '../../../../lib';
import { Layout } from '../../../../App';
import * as yup from 'yup';
import { faker } from '@faker-js/faker';

interface IFormValues {
    Document: IUploadDocument[];
}

const UploadPage: FC = () => {
    const initData: IFormValues = {
        Document: [],
    };
    const { control, handleSubmit, setValue, reset } = useForm({
        defaultValues: initData,
        validationSchema: {
            Document: yup
                .array()
                .nullable()
                .min(1, 'En az 1 dosya yüklemelisiniz')
                .required('Lütfen bir dosya yükleyin'),
        },
    });

    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log('Upload -->', data);
    };
    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Upload' }} />
                            <Box sx={{ p: 3 }}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <Upload
                                            required
                                            name="Document"
                                            // label="Upload"
                                            label={faker.lorem.sentence(25)}
                                            // acceptedFileTypes={['image/png']}
                                            token={
                                                'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQZXJzb25hbENvZGUiOiI3OTk2NyIsIk5hbWUiOiJBeWt1dCBTZXpnaW4iLCJFbWFpbCI6IkF5a3V0LlNlemdpbkBzZWtlcmJhbmsuY29tLnRyIiwiVW5pdElkIjoiMTAwMDUyNSIsIlRpdGxlSWQiOiIxMDAwODMwIiwiTWlzc2lvbklkIjoiMTAwMjU1MSIsIlNlcnZpY2VJZCI6IjYwMCIsIkJyYW5jaElkIjoiMSIsIkFwcElkcyI6IjEsMiwzLDQsNyw4LDEwLDExLDE0LDE1LDE2LDE3LDIwLDIxLDIyLDIzLDI1LDI2LDI3IiwiaWF0IjoiNi8xOC8yMDIyIDExOjA3OjU0IFBNIiwibmJmIjoxNjU1NTkzNjc0LCJleHAiOjE2NTU2MzY4NzQsImlzcyI6Imh0dHBzOi8vd3d3LnNla2VyYmFuay5jb20udHIiLCJhdWQiOiJTZWtlcmJhbmsuRXJwIn0.3N394-R5fn2ZrTVHpTfUBiAoo_AKa9LwoxYHA3Ux758'
                                            }
                                            apiUrl="http://10.1.4.225/DMSApi/api/Document"
                                            path="EBanka/Publish_Form_Documents/9502df6f-a1c1-41af-a5f1-b21bb4c92349"
                                            fileName="file"
                                            maxSize={20000}
                                            onError={(error: any, file: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('---', error, file);
                                            }}
                                            multiple
                                            control={control}
                                            // allowImagePreview
                                            // itemInsertLocation="after"
                                            setValue={setValue}
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacingType="button">
                                            <GridItem xs="auto">
                                                <Button type="submit" text="Send" />
                                            </GridItem>
                                            <GridItem xs="auto">
                                                <Button text="Reset" onClick={() => reset()} />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                </Grid>
                            </Box>
                        </Paper>
                    </form>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UploadPage;
