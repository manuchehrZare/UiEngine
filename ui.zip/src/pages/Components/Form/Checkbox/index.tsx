import type { FC } from 'react';
import { Layout } from '../../../../App';
import { pick } from 'lodash';
import * as yup from 'yup';
import {
    Checkbox,
    Box,
    useForm,
    Button,
    Grid,
    GridItem,
    Paper,
    Label,
    DesignTypeEnum,
    Input,
    Nav,
} from '../../../../lib';

const CheckboxPage: FC = () => {
    const { control, handleSubmit, reset } = useForm({
        defaultValues: {
            checkbox: false,
            checkboxTrue: true,
        },
        validationSchema: {
            checkbox: yup.bool().required('Required').oneOf([true], 'Checkbox must be accepted'),
            checkboxTrue: yup.bool().required('Required').oneOf([true], 'Checkbox must be accepted'),
        },
    });
    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log('-->', data);
    };

    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Checkbox' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit((data) => onSubmit(pick(data, 'validation')))}>
                                <Grid>
                                    <GridItem>
                                        <Label text="Default" />
                                        <Checkbox
                                            label="Checkbox Disabled"
                                            name="checkbox"
                                            control={control}
                                            disabled
                                            helperText="Helper Text"
                                            size="medium"
                                        />
                                        <Checkbox
                                            label="Checkbox ReadOnly"
                                            name="checkboxTrue"
                                            control={control}
                                            readOnly
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            label="Checkbox Start"
                                            name="checkbox"
                                            control={control}
                                            size="small"
                                            helperText="Helper Text"
                                            labelPlacement="start"
                                        />
                                        <Checkbox
                                            label="Checkbox End"
                                            name="checkbox"
                                            control={control}
                                            size="small"
                                            helperText="Helper Text"
                                            labelPlacement="end"
                                        />
                                        <Checkbox
                                            label="Checkbox Top"
                                            name="checkbox"
                                            control={control}
                                            size="small"
                                            helperText="Helper Text"
                                            labelPlacement="top"
                                        />
                                        <Checkbox
                                            label="Checkbox Bottom"
                                            name="checkbox"
                                            control={control}
                                            size="small"
                                            helperText="Helper Text"
                                            labelPlacement="bottom"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="SET" />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox Disabled"
                                            name="checkbox"
                                            control={control}
                                            disabled
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox ReadOnly"
                                            name="checkboxTrue"
                                            control={control}
                                            readOnly
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="SET Color" />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            color="error"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkboxTrue"
                                            control={control}
                                            helperText="Helper Text"
                                            color="info"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            color="primary"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            color="secondary"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            color="success"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Checkbox"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            color="warning"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Start"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            labelPlacement="start"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label End"
                                            name="checkbox"
                                            control={control}
                                            helperText="Helper Text"
                                            labelPlacement="end"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Top Top Top"
                                            name="checkbox"
                                            control={control}
                                            labelPlacement="top"
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Bottom"
                                            name="checkbox"
                                            control={control}
                                            labelPlacement="bottom"
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Width"
                                            name="checkbox"
                                            control={control}
                                            labelWidth={150}
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Width Start"
                                            name="checkbox"
                                            control={control}
                                            labelWidth={150}
                                            labelPlacement="start"
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Width End"
                                            name="checkbox"
                                            control={control}
                                            labelWidth={150}
                                            labelPlacement="end"
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Width Top"
                                            name="checkbox"
                                            control={control}
                                            labelWidth={150}
                                            labelPlacement="top"
                                            helperText="Helper Text"
                                        />
                                        <Checkbox
                                            design={DesignTypeEnum.SET}
                                            label="Label Width Bottom"
                                            name="checkbox"
                                            control={control}
                                            labelWidth={150}
                                            labelPlacement="bottom"
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacing={0.5}>
                                            <GridItem xs={3} pt={2.2}>
                                                <Checkbox
                                                    label="Checkbox"
                                                    name="checkbox1"
                                                    control={control}
                                                    helperText="Helper Text"
                                                />
                                            </GridItem>
                                            <GridItem xs={6}>
                                                <Input
                                                    label="input"
                                                    name="input1"
                                                    control={control}
                                                    helperText="Helper Text"
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Checkbox
                                            label="Small Checkbox"
                                            name="checkbox1"
                                            control={control}
                                            helperText="Helper Text"
                                            size="small"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button type="submit" text="Send" sx={{ mt: 1 }} />
                                        <Button text="Reset" sx={{ mt: 1 }} onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CheckboxPage;
