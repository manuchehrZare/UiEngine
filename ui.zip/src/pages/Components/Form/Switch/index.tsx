import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, useForm, Switch, DesignTypeEnum, Button, Input, Nav } from '../../../../lib';

const SwitchPage: FC = () => {
    const { control, handleSubmit } = useForm({
        defaultValues: {
            switch: false,
            disabled: false,
        },
    });

    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log(data);
    };
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Switch' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Grid spacing={2}>
                                    <GridItem>
                                        <Switch
                                            name="switch"
                                            label="Switch"
                                            control={control}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            name="switch"
                                            label="Switch LabelPlacement-Start"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="start"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            name="switch"
                                            label="Switch LabelPlacement-end"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="end"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            name="switch"
                                            label="Switch LabelPlacement-top"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="top"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            name="switch"
                                            label="Switch LabelPlacement-bottom"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="bottom"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            design={DesignTypeEnum.SET}
                                            name="switch"
                                            label="SET Switch"
                                            control={control}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            design={DesignTypeEnum.SET}
                                            name="disabled"
                                            label="SET Disabled Switch"
                                            control={control}
                                            helperText="helperText"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            design={DesignTypeEnum.SET}
                                            name="switch"
                                            label="SET Switch LabelPlacement-Start"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="start"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            design={DesignTypeEnum.SET}
                                            name="switch"
                                            label="SET Switch LabelPlacement-end"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="end"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            design={DesignTypeEnum.SET}
                                            name="switch"
                                            label="SET Switch LabelPlacement-top"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="top"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            design={DesignTypeEnum.SET}
                                            name="switch"
                                            label="SET Switch LabelPlacement-bottom"
                                            control={control}
                                            helperText="helperText"
                                            labelPlacement="bottom"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacing={0.2}>
                                            <GridItem xs={6}>
                                                <Input
                                                    name="input1"
                                                    label="input"
                                                    control={control}
                                                    helperText="helperText"
                                                />
                                            </GridItem>
                                            <GridItem xs={6} pt={2.5}>
                                                <Switch
                                                    name="switch1"
                                                    label="switch switch"
                                                    control={control}
                                                    helperText="helperText"
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Switch
                                            name="smallSwitch1"
                                            label="Small switch"
                                            control={control}
                                            size="small"
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button type="submit" text="Send" />
                                    </GridItem>
                                </Grid>
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default SwitchPage;
