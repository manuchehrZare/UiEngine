import { Layout } from '../../../../App';
import type { FC } from 'react';
import * as yup from 'yup';
import { Box, Button, Grid, GridItem, Paper, useForm, TimePicker, useWatch, Nav } from '../../../../lib';
import { faker } from '@faker-js/faker';

const TimePickerPage: FC = () => {
    const { control, handleSubmit, reset } = useForm({
        defaultValues: {
            timePicker: null,
            timePicker2: null,
            timePicker3: null,
            timePickerDisabled: new Date(),
            timePickerTest: null,
        },
        validationSchema: {
            timePicker: yup.number().nullable().required('Boş olamaz.').typeError('Type Error'),
            timePicker2: yup.date().nullable().required('Boş olamaz.').typeError('Type Error'),
            timePicker3: yup.date().nullable().required('Boş olamaz.').typeError('Type Error'),
        },
    });
    const timeVal = useWatch({ control, fieldName: 'timePicker' });

    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log('data', data);
    };

    // eslint-disable-next-line no-console
    console.log('timeVal', timeVal);

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Variants' }} />
                        <Grid spacingType="form">
                            <GridItem xs>
                                <TimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="outlined"
                                    control={control}
                                    unixTime
                                    variant="outlined"
                                    helperText="Variant Outlined"
                                />
                            </GridItem>
                            <GridItem xs>
                                <TimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="filled"
                                    control={control}
                                    unixTime
                                    variant="filled"
                                    helperText="Variant Filled"
                                />
                            </GridItem>
                            <GridItem xs>
                                <TimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="standard"
                                    control={control}
                                    unixTime
                                    variant="standard"
                                    helperText="Variant Standard"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form">
                            <GridItem xs>
                                <TimePicker
                                    label={faker.lorem.sentence(15)}
                                    name="timePicker"
                                    control={control}
                                    unixTime
                                    onOpen={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('onOpen');
                                    }}
                                    onClose={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('onClose');
                                    }}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem xs>
                                <TimePicker
                                    label={faker.lorem.sentence(15)}
                                    labelPlacement="start"
                                    name="timePicker"
                                    control={control}
                                    unixTime
                                    onOpen={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('onOpen');
                                    }}
                                    onClose={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('onClose');
                                    }}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'TimePicker' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <TimePicker
                                            label="TimePicker -- UnixTime"
                                            name="timePicker"
                                            control={control}
                                            unixTime
                                            // placeholder="Placeholder"
                                            onOpen={() => {
                                                // eslint-disable-next-line no-console
                                                console.log('onOpen');
                                            }}
                                            onClose={() => {
                                                // eslint-disable-next-line no-console
                                                console.log('onClose');
                                            }}
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <TimePicker
                                            label="TimePicker -- Date"
                                            name="timePicker2"
                                            control={control}
                                            // placeholder="Placeholder"
                                            onOpen={() => {
                                                // eslint-disable-next-line no-console
                                                console.log('onOpen');
                                            }}
                                            onClose={() => {
                                                // eslint-disable-next-line no-console
                                                console.log('onClose');
                                            }}
                                            helperText="Helper Text"
                                            analogClock
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <TimePicker
                                            label="TimePicker -- Views"
                                            name="timePicker3"
                                            control={control}
                                            views={['minutes', 'seconds']}
                                            analogClock
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <TimePicker
                                            label="TimePicker -- Disabled"
                                            name="timePickerDisabled"
                                            control={control}
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <TimePicker
                                            label="TimePicker -- ReadOnly"
                                            name="timePickerDisabled"
                                            control={control}
                                            readOnly
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <TimePicker
                                            label="LabelPlacement='top' TimePicker"
                                            name="timePicker"
                                            control={control}
                                            unixTime
                                            // placeholder="Placeholder"
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <TimePicker
                                            labelPlacement="start"
                                            label="LabelPlacement='start' TimePicker"
                                            name="timePicker"
                                            control={control}
                                            unixTime
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button text="Submit" type="submit" />
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default TimePickerPage;
