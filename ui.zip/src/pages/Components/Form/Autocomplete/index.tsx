import { Layout } from '../../../../App';
import * as yup from 'yup';
import { useForm, Button, Grid, GridItem, Paper, Autocomplete, Nav, Box, Chip } from '../../../../lib';
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Person, Search } from '@mui/icons-material';
import { isBoolean, isNumber, isString, sortBy } from 'lodash';
import { faker } from '@faker-js/faker';

interface IFormValues {
    base: string | null;
    customIconPlaceholder: string | null;
    dataFormatterAutocomplete: string | null;
    disabled: string | null;
    emptyData: string | null;
    genericAutocomplete: string | null;
    genericMultiAutocomplete: string[];
    multi: string[];
    openCloseText: string | null;
    readOnly: string | null;
    timeoutData_autocomplete: string | null;
    timeoutData_multi_autocomplete: string[];
}

interface IGenericData {
    age: number;
    id: string;
    name: string;
    surname: string;
}

interface IMovieItem {
    title: string;
    year: string;
}

const AutocompletePage: FC = () => {
    const [movies, setMovies] = useState<IMovieItem[]>([]);
    const [timeoutData, setTimeoutData] = useState<IGenericData[]>([]);
    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            base: null,
            customIconPlaceholder: null,
            dataFormatterAutocomplete: null,
            disabled: '1994',
            emptyData: null,
            genericAutocomplete: null,
            genericMultiAutocomplete: [],
            multi: [],
            openCloseText: null,
            readOnly: '1994',
            timeoutData_autocomplete: '11',
            timeoutData_multi_autocomplete: ['11'],
        },
        validationSchema: {
            base: yup.string().typeError('Please select a data.').required('Please select a data.'),
            multi: yup.array().required('Boş olamaz.').min(1, 'Boş olamaz.'),
        },
    });

    const genericData: IGenericData[] = [
        {
            id: '11',
            age: 30,
            name: 'Ameera',
            surname: 'Moss',
        },
        {
            id: '22',
            age: 37,
            name: 'Zackary',
            surname: 'Solis',
        },
        {
            id: '33',
            age: 22,
            name: 'Wilma',
            surname: 'Wood',
        },
        {
            id: '44',
            age: 25,
            name: 'Barry',
            surname: 'Conley',
        },
        {
            id: '55',
            age: 44,
            name: 'John',
            surname: 'Martin',
        },
        {
            id: '66',
            age: 33,
            name: 'Benjamin',
            surname: 'Mayer',
        },
    ];

    const withEmptyData = [
        {
            id: 1,
            text: 'Text1',
        },
        {
            id: 2,
            text: 'Text2',
        },
        {
            id: 3,
            text: 'Text3',
        },
        {
            id: 4,
            text: ' ',
        },
        {
            id: 5,
            text: 'Text5',
        },
    ];

    useEffect(() => {
        const movieTimeout = setTimeout(() => {
            setMovies([
                { title: "The Pirates of the Caribbean - Captain Jack Sparrow - At World's End", year: '2004' },
                { title: 'The Shawshank Redemption', year: '1994' },
                { title: 'The Godfather', year: '1972' },
                { title: 'The Godfather: Part II', year: '1974' },
                { title: 'The Dark Knight', year: '2008' },
                { title: '12 Angry Men', year: '1957' },
                { title: "Schindler's List", year: '1993' },
                { title: 'The Lord of the Rings: The Return of the King', year: '2003' },
                { title: 'Pulp Fiction', year: '1994' },
                { title: 'The Good, the Bad and the Ugly', year: '1966' },
                { title: 'Fight Club', year: '1999' },
                { title: 'Joker', year: '2019' },
                { title: 'Life Is Beautiful', year: '1997' },
                { title: 'Forrest Gump', year: '1994' },
                { title: 'Inception', year: '2010' },
            ]);
        }, 1);

        return () => {
            clearTimeout(movieTimeout);
        };
    }, []);

    useEffect(() => {
        const timeoutForSelectData = setTimeout(() => {
            setTimeoutData(genericData);
        }, 10000);
        return () => {
            clearTimeout(timeoutForSelectData);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onSubmit = (data: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('onSubmit-->', data);
    };

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Variant' }} />
                        <Grid spacingType="form">
                            <GridItem xs>
                                <Autocomplete
                                    name="outlined"
                                    label={faker.lorem.sentence(15)}
                                    options={{
                                        data: movies.slice(0, 4),
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param: any) => `${param.year} asd`,
                                        renderDisplayList: (param: any) => `${param.title} list`,
                                    }}
                                    control={control}
                                    helperText="Variant Outlined"
                                    variant="outlined"
                                />
                            </GridItem>
                            <GridItem xs>
                                <Autocomplete
                                    name="standard"
                                    label={faker.lorem.sentence(15)}
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param: any) => `${param.year} asd`,
                                        renderDisplayList: (param: any) => `${param.title} list`,
                                    }}
                                    control={control}
                                    helperText="Variant Standard"
                                    variant="standard"
                                />
                            </GridItem>
                            <GridItem xs>
                                <Autocomplete
                                    name="filled"
                                    label={faker.lorem.sentence(15)}
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param: any) => `${param.year} asd`,
                                        renderDisplayList: (param: any) => `${param.title} list`,
                                    }}
                                    control={control}
                                    helperText="Variant Filled"
                                    variant="filled"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form">
                            <GridItem xs={6}>
                                <Autocomplete
                                    name="base"
                                    label={faker.lorem.sentence(15)}
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param: any) => `${param.year} asd`,
                                        renderDisplayList: (param: any) => `${param.title} list`,
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem xs={6}>
                                <Autocomplete
                                    name="base"
                                    label={faker.lorem.sentence(15)}
                                    labelPlacement="start"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param: any) => `${param.year} asd`,
                                        renderDisplayList: (param: any) => `${param.title} list`,
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem md={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Autocomplete' }} />
                        <Grid p={2} spacingType="form">
                            <GridItem>
                                <Autocomplete<IMovieItem>
                                    name="base"
                                    label="Base"
                                    // componentsProps={{
                                    //     paper: {
                                    //         sx: {
                                    //             fontSize: 12,
                                    //         },
                                    //     },
                                    // }}
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param) => `test ${param.title}`,
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                    // sx={{
                                    //     '.MuiAutocomplete-inputRoot': {
                                    //         borderRadius: 10,
                                    //     },
                                    // }}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="multi"
                                    label="Multiple"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                        renderDisplayField: (param: any) => `${param.year} asd`,
                                        renderDisplayList: (param: any) => `${param.title} list`,
                                    }}
                                    renderTags={(tagValue, getTagProps) => {
                                        return tagValue?.map((option, index) => {
                                            let displayLabel = '';
                                            if (
                                                (isString(option) || isNumber(option) || isBoolean(option)) &&
                                                movies.length &&
                                                option
                                            ) {
                                                const item = movies.filter((findItem) => findItem.year === option)[0];
                                                displayLabel = String(item.title);
                                            }
                                            return (
                                                <Chip
                                                    {...getTagProps({ index })}
                                                    key={option}
                                                    label={displayLabel}
                                                    color={index % 2 === 0 ? 'error' : 'success'}
                                                    size="small"
                                                />
                                            );
                                        });
                                    }}
                                    multiple
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="emptyData"
                                    label="With Empty Data"
                                    options={{
                                        data: withEmptyData,
                                        displayField: 'text',
                                        displayValue: 'id',
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="disabled"
                                    label="Disabled"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    disabled
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="readOnly"
                                    label="ReadOnly"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    readOnly
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="timeoutData_autocomplete"
                                    label="Timeout Data Autocomplete"
                                    options={{
                                        data: timeoutData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                    }}
                                    control={control}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="timeoutData_multi_autocomplete"
                                    label="Timeout Data Multiple Autocomplete"
                                    options={{
                                        data: timeoutData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                    }}
                                    multiple
                                    ChipProps={{
                                        color: 'success',
                                    }}
                                    control={control}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="customIconPlaceholder"
                                    label="Custom Icon & Placeholder"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                    placeholder="Placeholder"
                                    popupIcon={<Search />}
                                    // disablePopupIconRotate
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="customIconPlaceholder"
                                    label="Custom Icon & Placeholder & disablePopupIconRotate"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                    placeholder="Placeholder"
                                    popupIcon={<Search />}
                                    disablePopupIconRotate
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="openCloseText"
                                    label="Open & Close Text"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                    openText="Aç"
                                    closeText="Kapat"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="multi"
                                    // label="SET Autocomplete Multiple"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    multiple
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="multi"
                                    label="Multiple With showSelectedItemsSummary"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    showSelectedItemsSummary
                                    multiple
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="multi"
                                    label="Multiple With showSelectedItemsSummary"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    showSelectedItemsSummary={(count) => `${count} custom item seçildi.`}
                                    multiple
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="labelWidth"
                                    labelPlacement="start"
                                    label="LabelPlacement='start'"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete
                                    name="labelWidth"
                                    labelPlacement="start"
                                    labelWidth={200}
                                    label="LabelWidth= 200"
                                    options={{
                                        data: movies,
                                        displayField: 'title',
                                        displayValue: 'year',
                                    }}
                                    control={control}
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete<IGenericData>
                                    label="Generic Autocomplete"
                                    name="genericAutocomplete"
                                    options={{
                                        data: genericData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                        renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                        renderDisplayList: (params) =>
                                            `id: ${params.id} - ${params.name} ${params.surname} - ${params.age} years old.`,
                                    }}
                                    control={control}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete<IGenericData>
                                    label="Generic Autocomplete with JSX"
                                    name="genericAutocomplete"
                                    options={{
                                        data: genericData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                        renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                        renderDisplayList: (params) => (
                                            <Box display="flex" alignItems="center" width="100%">
                                                <Person fontSize="small" />
                                                <Box ml={1} flex={1}>
                                                    <Box
                                                        display="flex"
                                                        alignItems="center"
                                                        justifyContent="space-between">
                                                        <Box>User ID : {params.id}</Box>
                                                        <Box>Age : {params.age}</Box>
                                                    </Box>
                                                    <Box>
                                                        {params.name} {params.surname}
                                                    </Box>
                                                </Box>
                                            </Box>
                                        ),
                                    }}
                                    control={control}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete<IGenericData>
                                    label="Generic Multiple Autocomplete"
                                    name="genericMultiAutocomplete"
                                    multiple
                                    options={{
                                        data: genericData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                        renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                        renderDisplayList: (params) =>
                                            `id: ${params.id} - ${params.name} ${params.surname} - ${params.age} years old.`,
                                    }}
                                    control={control}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete<IGenericData>
                                    label="Generic Multiple Autocomplete with JSX DENEME DENEME DENEME"
                                    name="genericMultiAutocomplete"
                                    multiple
                                    options={{
                                        data: genericData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                        renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                        renderDisplayList: (params) => (
                                            <Box display="flex" alignItems="center" width="100%">
                                                <Person fontSize="small" />
                                                <Box ml={1} flex={1}>
                                                    <Box
                                                        display="flex"
                                                        alignItems="center"
                                                        justifyContent="space-between">
                                                        <Box>User ID : {params.id}</Box>
                                                        <Box>Age : {params.age}</Box>
                                                    </Box>
                                                    <Box>
                                                        {params.name} {params.surname}
                                                    </Box>
                                                </Box>
                                            </Box>
                                        ),
                                    }}
                                    control={control}
                                    ChipProps={{ leftCornered: true }}
                                />
                            </GridItem>
                            <GridItem>
                                <Autocomplete<IGenericData>
                                    label="Data Formatter"
                                    name="dataFormatterAutocomplete"
                                    options={{
                                        data: genericData,
                                        displayField: 'name',
                                        displayValue: 'id',
                                        renderDisplayList: (params) =>
                                            `${params.name} ${params.surname} - Age: ${params.age}`,
                                        dataFormatter: (data) =>
                                            sortBy(data, ['age'])
                                                .reverse()
                                                .filter((item) => item.age > 30),
                                    }}
                                    control={control}
                                />
                            </GridItem>
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem sm="auto">
                                        <Button type="submit" text="Send" onClick={handleSubmit(onSubmit)} />
                                    </GridItem>
                                    <GridItem sm="auto">
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default AutocompletePage;
