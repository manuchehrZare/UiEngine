import { Layout } from '../../../../App';
import * as yup from 'yup';
import type { IInputProps } from '../../../../lib';
import { Box, useForm, Button, Grid, GridItem, Paper, Input, Tooltip, Nav, Select, useWatch } from '../../../../lib';
import type { FC } from 'react';
import { MoreHoriz, SupervisorAccount } from '@mui/icons-material';
import { faker } from '@faker-js/faker';

interface IFormValues {
    adornment: string;
    erpInput: string;
    erpLength: string;
    erpMask1: string;
    erpMask2: string;
    erpPhoneMask: string;
    erpTextArea: string;
    longLabelStart: string;
    longLabelTop: string;
    maskChar: string;
    passwordInput: string;
    setDisabled: string;
    setInput: string;
    setLength: string;
    setMask1: string;
    setMask2: string;
    setReadOnly: string;
    setTextArea: string;
    setTopLabelInput: string;
    size: IInputProps['size'];
    variant: IInputProps['variant'];
    variantFilled: string;
    variantOutlined: string;
    variantStandard: string;
}

const InputPage: FC = () => {
    const propsControlDatas = {
        variant: [{ key: 'filled' }, { key: 'outlined' }, { key: 'standard' }],
        size: [{ key: 'medium' }, { key: 'small' }],
    };
    const { control, handleSubmit, reset, setValue } = useForm<IFormValues>({
        defaultValues: {
            adornment: '',
            erpInput: '',
            erpLength: '',
            erpMask1: '',
            erpMask2: '',
            erpPhoneMask: '',
            erpTextArea: '',
            longLabelStart: '',
            longLabelTop: '',
            maskChar: '',
            passwordInput: '',
            setDisabled: 'Text',
            setInput: '',
            setLength: '',
            setMask1: '',
            setMask2: '',
            setReadOnly: 'Text',
            setTextArea: '',
            setTopLabelInput: '',
            size: 'medium',
            variant: 'outlined',
            variantFilled: '',
            variantOutlined: '',
            variantStandard: '',
        },
        validationSchema: {
            erpInput: yup.string().required('Boş olamaz'),
            erpTextArea: yup.string().required('Boş olamaz'),
            setDisabled: yup.string().required('Boş olamaz'),
            setReadOnly: yup.string().required('Boş olamaz'),
            setMask: yup
                .string()
                .required('Boş olamaz')
                .matches(/[0-9]{2}[/][0-9]{2}[/][0-9]{4}/gm, 'Geçerli bir tarih giriniz.'),
            erpMask: yup
                .string()
                .required('Boş olamaz')
                .matches(/[0-9]{2}[/][0-9]{2}[/][0-9]{4}/gm, 'Geçerli bir tarih giriniz.'),
            erpPhoneMask: yup
                .string()
                .matches(/\(\d{3}\) \d{3} \d{2} \d{2}/gm, 'Geçerli bir telefon numarası giriniz.')
                .required('Boş olamaz'),
            passwordInput: yup.string().required('Boş olamaz'),
            // setInput: yup.string().required('Boş olamaz'),
            setTopLabelInput: yup.string().required('Boş olamaz'),
            setTextArea: yup.string().required('Boş olamaz'),
            maskChar: yup.string().required('Boş olamaz'),
            erpLength: yup.string().min(2, 'Min 2 character').max(4, 'Max 4 character').required('Boş olamaz'),
            setLength: yup.string().min(2, 'Min 2 character').max(4, 'Max 4 character').required('Boş olamaz'),
        },
    });
    const [variantValue, sizeValue] = useWatch({ control, fieldName: ['variant', 'size'] });

    const onSubmit = (data: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('-->', data);
    };

    return (
        <Layout>
            <Grid spacing={2}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Props Control' }} />
                        <Grid p={1} spacingType="form">
                            <GridItem md>
                                <Select
                                    label="Variant"
                                    control={control}
                                    name="variant"
                                    options={{
                                        data: propsControlDatas.variant,
                                        displayField: 'key',
                                        displayValue: 'key',
                                    }}
                                    setValue={setValue}
                                />
                            </GridItem>
                            <GridItem md>
                                <Select
                                    label="Size"
                                    control={control}
                                    name="size"
                                    options={{
                                        data: propsControlDatas.size,
                                        displayField: 'key',
                                        displayValue: 'key',
                                    }}
                                    setValue={setValue}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Variants' }} />
                        <Grid>
                            <GridItem>
                                <Grid spacing={2} p={1}>
                                    <GridItem xs>
                                        <Input
                                            label={faker.lorem.sentence(15)}
                                            name="variantOutlined"
                                            control={control}
                                            helperText="Variant Outlined"
                                            variant="outlined"
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Input
                                            label={faker.lorem.sentence(15)}
                                            name="variantStandard"
                                            control={control}
                                            helperText="Variant Standard"
                                            variant="standard"
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Input
                                            label={faker.lorem.sentence(15)}
                                            name="variantFilled"
                                            control={control}
                                            helperText="Variant Filled"
                                            variant="filled"
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form">
                            <GridItem xs>
                                <Input
                                    label={faker.lorem.sentence(15)}
                                    // labelEllipsis={false}
                                    name="longLabelTop"
                                    control={control}
                                    helperText="Long Label - LabelPlacement top"
                                    variant={variantValue}
                                    size={sizeValue}
                                />
                            </GridItem>
                            <GridItem xs>
                                <Input
                                    label={faker.lorem.sentence(15)}
                                    labelPlacement="start"
                                    name="longLabelStart"
                                    control={control}
                                    helperText="Long Label - LabelPlacement start"
                                    variant={variantValue}
                                    size={sizeValue}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Input' }} />
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <Box sx={{ p: 3 }}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <Input
                                            required
                                            label="Single Line Input"
                                            name="erpInput"
                                            control={control}
                                            helperText="Helper Text"
                                            // readOnly
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="Multi Line Input"
                                            name="erpTextArea"
                                            control={control}
                                            multiline
                                            rows={3}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="Length"
                                            name="erpLength"
                                            control={control}
                                            helperText="Helper Text"
                                            minLength={2}
                                            maxLength={5}
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="Mask Input"
                                            name="erpMask1"
                                            control={control}
                                            helperText="Helper Text"
                                            mask={'00/00/0000'}
                                            placeholder="placeholder"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            label="Mask (000000{XXXXX}000)"
                                            name="erpMask2"
                                            control={control}
                                            helperText="Helper Text"
                                            mask={'000000{XXXXX}000'}
                                            maskChar="_"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="PhoneMask"
                                            name="erpPhoneMask"
                                            control={control}
                                            helperText="Helper Text"
                                            mask={'(000) 000 00 00'}
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="MaskChar"
                                            name="maskChar"
                                            control={control}
                                            helperText="Helper Text"
                                            // mask={'00/00/0000'}
                                            // maskChar="*"
                                            placeholder="placeholder"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            type="password"
                                            label="Password Input"
                                            name="passwordInput"
                                            control={control}
                                            endAdornment={<SupervisorAccount />}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            type="password"
                                            label="Password Input passwordVisibility"
                                            name="passwordInput"
                                            control={control}
                                            helperText="Helper Text"
                                            passwordVisibility
                                            // endAdornment={<SupervisorAccount />}
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET Single Line Input"
                                            labelWidth="auto"
                                            name="setInput"
                                            control={control}
                                            helperText="Helper Text"
                                            onKeyPress={(e: any) => {
                                                if (e.code === 'Enter') {
                                                    // eslint-disable-next-line no-console
                                                    console.log('Pressed Enter', e);
                                                }
                                            }}
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET Disabled Input"
                                            name="setDisabled"
                                            control={control}
                                            helperText="Helper Text"
                                            disabled
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET ReadOnly Input"
                                            name="setReadOnly"
                                            control={control}
                                            helperText="Helper Text"
                                            readOnly
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET Length"
                                            name="setLength"
                                            control={control}
                                            helperText="Helper Text"
                                            minLength={2}
                                            maxLength={5}
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            // label="SET Single Line Input"
                                            // labelWidth="auto"
                                            name="setInput"
                                            control={control}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            // label="SET Single Line Input"
                                            labelWidth="175px"
                                            name="setInput"
                                            control={control}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            label="SET Single Line Top Label Input"
                                            labelPlacement="top"
                                            name="setTopLabelInput"
                                            control={control}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            label="SET Multi Line Input"
                                            name="setTextArea"
                                            control={control}
                                            multiline
                                            rows={3}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET Mask Input"
                                            name="setMask1"
                                            control={control}
                                            helperText="Helper Text"
                                            mask={'00/00/0000'}
                                            placeholder="placeholder"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET MaskChar"
                                            name="maskChar"
                                            control={control}
                                            helperText="Helper Text"
                                            // mask={'00/00/0000'}
                                            placeholder="placeholder"
                                            // maskChar="*"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET PhoneMask"
                                            name="erpPhoneMask"
                                            control={control}
                                            helperText="Helper Text"
                                            // mask={'(000)000 00 00'}
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            required
                                            label="SET Mask (000*aaa*)"
                                            name="setMask2"
                                            control={control}
                                            helperText="Helper Text"
                                            // mask="000*aaa*"
                                            placeholder="placeholder"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Input
                                            type="password"
                                            label="SET Password Input"
                                            name="passwordInput"
                                            control={control}
                                            helperText="Helper Text"
                                            variant={variantValue}
                                            size={sizeValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button type="submit" text="Send" />
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </form>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Adornment' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Input
                                        label="startAdornment Button"
                                        name="adornment"
                                        control={control}
                                        startAdornment={
                                            <Tooltip sx={{ ml: '-8.5px' }} title="Test">
                                                <Button iconButton icon={<MoreHoriz />} />
                                            </Tooltip>
                                        }
                                        variant={variantValue}
                                        size={sizeValue}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        label="endAdornment Button with Tooltip"
                                        name="adornment"
                                        control={control}
                                        endAdornment={
                                            <Tooltip sx={{ mr: '-5px' }} title="Test">
                                                <Button iconButton icon={<MoreHoriz />} />
                                            </Tooltip>
                                        }
                                        variant={variantValue}
                                        size={sizeValue}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        label="endAdornment Button"
                                        name="adornment"
                                        control={control}
                                        endAdornment={<Button iconButton icon={<MoreHoriz />} sx={{ mr: '-5px' }} />}
                                        variant={variantValue}
                                        size={sizeValue}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        label="endAdornment Button Disabled"
                                        name="adornment"
                                        control={control}
                                        disabled
                                        endAdornment={
                                            <Tooltip sx={{ mr: '-5px' }} title="Test">
                                                <Button iconButton icon={<MoreHoriz />} disabled />
                                            </Tooltip>
                                        }
                                        variant={variantValue}
                                        size={sizeValue}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        label="endAdornment Icon"
                                        name="adornment"
                                        control={control}
                                        endAdornment={<MoreHoriz />}
                                        variant={variantValue}
                                        size={sizeValue}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        label="endAdornment Icon Disabled"
                                        name="adornment"
                                        control={control}
                                        disabled
                                        endAdornment={<MoreHoriz />}
                                        variant={variantValue}
                                        size={sizeValue}
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default InputPage;
