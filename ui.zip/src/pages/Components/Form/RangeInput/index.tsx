import { Typography } from '@mui/material';
import type { FC } from 'react';
import { Box, Button, Grid, GridItem, Paper, useForm, RangeInput, Label, DesignTypeEnum, Nav } from '../../../../lib';
import * as yup from 'yup';
import { Layout } from '../../../../App';
import { faker } from '@faker-js/faker';

interface IFormValues {
    range: number | null;
    range2: number;
    rangeMultiple: number | number[];
}

const RangeInputPage: FC = () => {
    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            range: null,
            range2: 10,
            rangeMultiple: [10, 30],
        },
        validationSchema: {
            range: yup.number().nullable().min(1, 'Select minimum 1').required('Select a range'),
        },
    });

    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('-->', formData);
    };

    const marks = [
        {
            value: 10,
            label: <Typography fontSize={14}>10</Typography>,
        },
        {
            value: 20,
            label: '20',
        },
        {
            value: 50,
            label: '50',
        },
        {
            value: 100,
            label: '100',
        },
    ];

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form">
                            <GridItem xs={6}>
                                <RangeInput
                                    label={faker.lorem.sentence(25)}
                                    labelPlacement="top"
                                    name="range"
                                    control={control}
                                    helperText="HelperText"
                                />
                            </GridItem>
                            <GridItem xs={6}>
                                <RangeInput
                                    label={faker.lorem.sentence(25)}
                                    labelPlacement="top"
                                    name="range"
                                    control={control}
                                    helperText="HelperText"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'RangeInput' }} />
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <Box sx={{ p: 3 }}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <Label text="Small" />
                                        <RangeInput
                                            label="Label"
                                            labelPlacement="top"
                                            name="range"
                                            control={control}
                                            valueLabelDisplay="auto"
                                            // step={5}
                                            color="primary"
                                            size="small"
                                            helperText="HelperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="Medium" />
                                        <RangeInput
                                            label="Label"
                                            labelPlacement="start"
                                            name="range"
                                            control={control}
                                            valueLabelDisplay="auto"
                                            // step={5}
                                            color="primary"
                                            size="medium"
                                            helperText="HelperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="SET Default" />
                                        <RangeInput
                                            label="Label"
                                            design={DesignTypeEnum.SET}
                                            name="range"
                                            control={control}
                                            valueLabelDisplay="auto"
                                            size="small"
                                            helperText="HelperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="SET Small" />
                                        <RangeInput
                                            label="Label"
                                            // labelPlacement="top"
                                            design={DesignTypeEnum.SET}
                                            name="range"
                                            control={control}
                                            valueLabelDisplay="auto"
                                            // step={5}
                                            size="small"
                                            color="primary"
                                            helperText="HelperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="SET Medium" />
                                        <RangeInput
                                            label="Label"
                                            // labelPlacement="top"
                                            design={DesignTypeEnum.SET}
                                            name="range"
                                            control={control}
                                            valueLabelDisplay="auto"
                                            // step={5}
                                            size="medium"
                                            color="primary"
                                            helperText="HelperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="SET Disabled" />
                                        <RangeInput
                                            label="Label"
                                            design={DesignTypeEnum.SET}
                                            size="small"
                                            name="range"
                                            control={control}
                                            valueLabelDisplay="auto"
                                            helperText="HelperText"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <RangeInput
                                            name="range2"
                                            control={control}
                                            // color="primary"
                                            // track={false}
                                            valueLabelDisplay="auto"
                                            valueLabelFormat={(value: number) =>
                                                marks.findIndex((item) => item.value === value) + 1
                                            }
                                            min={0}
                                            max={100}
                                            marks={marks}
                                            step={null}
                                            size="medium"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Label text="Orientation Vertical" />
                                        <RangeInput
                                            name="vertical"
                                            control={control}
                                            color="primary"
                                            label="Label Label Label Label Label Label "
                                            helperText="helperText"
                                            sx={{
                                                '& .MuiSlider-root': {
                                                    height: 200,
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                },
                                            }}
                                            labelPlacement="top"
                                            orientation="vertical"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <RangeInput name="rangeMultiple" control={control} valueLabelDisplay="on" />
                                    </GridItem>
                                    <GridItem>
                                        <Button type="submit" text="Send" />
                                        <Button type="reset" text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </form>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default RangeInputPage;
