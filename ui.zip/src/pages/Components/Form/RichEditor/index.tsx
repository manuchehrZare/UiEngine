import type { FC } from 'react';
import {
    Grid,
    GridItem,
    Paper,
    Box,
    useForm,
    Button,
    RichEditor,
    Select,
    useMeasure,
    showLoading,
    hideLoading,
    Nav,
} from '../../../../lib';
import * as yup from 'yup';
import { Layout } from '../../../../App';
import { faker } from '@faker-js/faker';

const RichEditorPage: FC = () => {
    const queryMeasure = useMeasure();

    const { handleSubmit, control, setValue, reset, getValues } = useForm<any>({
        defaultValues: {
            reactFroalaSet: '',
            reactFroalaDefault: '',
        },
        validationSchema: {
            reactFroalaSet: yup.string().required('Boş olamaz'),
            reactFroalaDefault: yup.string().required('Boş olamaz'),
        },
    });

    const onSubmit = (formData: any) => {
        // eslint-disable-next-line no-console
        console.log('formData', formData);
    };

    const optionsDataList: any = [
        {
            id: '0',
            text: 'Url1',
        },
        {
            id: '1',
            text: 'Url2',
        },
        {
            id: '2',
            text: 'Url3',
        },
        {
            id: '3',
            text: 'Url4',
        },
    ];

    const fethDataList: any = [
        {
            id: '0',
            url: 'https://mocki.io/v1/8b54dade-03b4-4ebc-8b5e-4c7860a48c66',
        },
        {
            id: '1',
            url: 'https://mocki.io/v1/f488466f-d27b-40a0-a8e8-20dec8b658b9',
        },
        {
            id: '2',
            url: 'https://mocki.io/v1/6d62bbd0-db67-4f99-b72d-2368acf00835',
        },
        {
            id: '3',
            url: 'https://mocki.io/v1/d08a563f-fb4b-4cc6-8ac9-14f75a7eb72a',
        },
    ];

    const fetchData = async () => {
        const result = await fetch(fethDataList[getValues('select')].url).then((x) => x.json());
        setValue('reactFroalaSet', await result?.htmlData);
        setValue('reactFroalaErp', await result?.htmlData);
    };

    return (
        <Layout>
            <form onSubmit={handleSubmit(onSubmit)}>
                <Grid spacingType="common">
                    <GridItem>
                        <Paper>
                            <Nav navTitleProps={{ title: 'RichEditor Froala' }} />
                            <Box sx={{ p: 3 }}>
                                <Grid spacing={1} ref={queryMeasure?.ref}>
                                    <GridItem xs={4}>
                                        <Select
                                            control={control}
                                            name="select"
                                            setValue={setValue}
                                            options={{
                                                data: optionsDataList,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            label="URL"
                                        />
                                    </GridItem>
                                    <GridItem xs={3} mt={2.25}>
                                        <Button
                                            text="Example Fetch Data"
                                            onClick={async () => {
                                                showLoading();
                                                fetchData();
                                                hideLoading();
                                            }}
                                        />
                                    </GridItem>
                                </Grid>
                                <Grid spacing={2}>
                                    <GridItem>
                                        <RichEditor
                                            label={faker.lorem.sentence(45)}
                                            control={control}
                                            name="reactFroalaSet"
                                            height={`calc((100vh - ${queryMeasure.values.height}px)*0.5)`}
                                            // readOnly
                                            // disabled
                                            // toolbar={[]}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacingType="button">
                                            <GridItem sm="auto">
                                                <Button type="submit" text="Send" fullWidth />
                                            </GridItem>
                                            <GridItem sm="auto">
                                                <Button type="reset" text="Reset" onClick={() => reset()} fullWidth />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                </Grid>
                            </Box>
                        </Paper>
                    </GridItem>
                </Grid>
            </form>
        </Layout>
    );
};

export default RichEditorPage;
