import { Layout } from '../../../../App';
import * as yup from 'yup';
import {
    Box,
    useForm,
    Button,
    Grid,
    GridItem,
    Paper,
    NumberInput,
    useWatch,
    NumberInputReturnValueEnum,
    Tooltip,
    Label,
    Nav,
    constants,
} from '../../../../lib';
import type { FC } from 'react';
import { useState } from 'react';
import { MoreHoriz, SupervisorAccount } from '@mui/icons-material';
import { faker } from '@faker-js/faker';

interface IFormValues {
    cardNumber: number | null;
    disabledNumberInput: number | null;
    numberInput: number | string | null;
    numberInputMask: number | null;
    numberInputMask2: number | null;
    numberInputMask3: string | null;
    numberInputSet: number | string | null;
    passwordNumberInput: number | string | null;
    phoneNumber: string;
    readOnlyNumberInput: number | null;
    texAlignErp: number | null;
    texAlignSet: number | null;
}

const NumberInputPage: FC = () => {
    const [textAlign, setTextAlign] = useState<'left' | 'right' | 'center'>('left');
    const { control, handleSubmit, reset, resetField } = useForm<IFormValues>({
        defaultValues: {
            numberInput: null,
            numberInputSet: '',
            passwordNumberInput: null,
            numberInputMask: null,
            numberInputMask2: null,
            numberInputMask3: '',
            texAlignErp: null,
            texAlignSet: null,
            readOnlyNumberInput: 5,
            disabledNumberInput: 5,
            cardNumber: null,
            phoneNumber: '',
        },
        validationSchema: {
            numberInput: yup.number().nullable().required('Required').typeError('TypeError'),
            numberInputSet: yup.string().nullable().required('Set Boş olamaz').typeError('TypeError'),
            numberInputMask: yup
                .string()
                .nullable()
                .matches(/\d{4} \d{3} \d{2} \d{2}/gm, 'Geçerli formatta giriniz.')
                .required('Boş olamaz')
                .typeError('TypeError'),
            numberInputMask2: yup
                .mixed()
                .required('Boş olamaz')
                .test({
                    name: 'test',
                    message: 'Geçerli formatta giriniz.',
                    test: (val: any) => {
                        const regex = /^(\d{3})(\d{3})(\d{4}).*/;
                        const testing = regex.test(String(val));
                        return testing;
                    },
                })
                .typeError('TypeError'),
        },
    });
    const watchNumberInput = useWatch({ control, fieldName: 'numberInput' });

    const onSubmit = (data: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('-->', data);
    };

    // eslint-disable-next-line no-console
    console.log('watchNumberInput', watchNumberInput, typeof watchNumberInput);

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Variants' }} />
                        <Grid spacingType="form" p={2}>
                            <GridItem xs>
                                <NumberInput
                                    name="outlined"
                                    label={faker.lorem.sentence(15)}
                                    control={control}
                                    variant="outlined"
                                    helperText="Variant Outlined"
                                />
                            </GridItem>
                            <GridItem xs>
                                <NumberInput
                                    name="standard"
                                    label={faker.lorem.sentence(15)}
                                    control={control}
                                    variant="standard"
                                    helperText="Variant Standard"
                                />
                            </GridItem>
                            <GridItem xs>
                                <NumberInput
                                    name="filled"
                                    label={faker.lorem.sentence(15)}
                                    control={control}
                                    variant="filled"
                                    helperText="Variant Filled"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form" p={2}>
                            <GridItem xs>
                                <NumberInput name="numberInput" label={faker.lorem.sentence(15)} control={control} />
                            </GridItem>
                            <GridItem xs>
                                <NumberInput
                                    name="numberInput"
                                    label={faker.lorem.sentence(15)}
                                    labelPlacement="start"
                                    control={control}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Number Input' }} />
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <Box sx={{ p: 3 }}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInput"
                                            label="Number Input"
                                            control={control}
                                            // helperText="Helper Text"
                                            // placeholder="ASASASAS"
                                            // format="### ### ##"
                                            // mask="_"
                                            // decimalSeparator=","
                                            // thousandSeparator="."
                                            // suffix=" TL"
                                            // returnValue={NumberInputReturnValueEnum.floatValue}
                                            // allowLeadingZeros
                                            // onKeyPress={(e: any) => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log(e);
                                            // }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputMask"
                                            label="Number Input Format&Mask"
                                            control={control}
                                            helperText="Helper Text"
                                            returnValue={NumberInputReturnValueEnum.formattedValue}
                                            format="#### ### ## ##"
                                            mask="_"
                                            allowEmptyFormatting
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="cardNumber"
                                            label="Number Input CardNumber Mask & Format"
                                            control={control}
                                            helperText="Helper Text"
                                            format="######***###"
                                            mask="_"
                                            allowEmptyFormatting
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputMask3"
                                            label="Number Input Format&Mask Array"
                                            control={control}
                                            helperText="Helper Text"
                                            returnValue={NumberInputReturnValueEnum.formattedValue}
                                            format="#### ### ## ##"
                                            mask={['*', '*', '*', '_', '_', '_', '_', '_', '_', '_', '_']}
                                            allowEmptyFormatting
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputMask2"
                                            label="Number Input Format&Mask Placeholder"
                                            control={control}
                                            helperText="Helper Text"
                                            placeholder="Placeholder"
                                            format="### ### ####"
                                            mask="*"
                                            allowEmptyFormatting
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            type="password"
                                            name="passwordNumberInput"
                                            label="Password Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                            endAdornment={<SupervisorAccount />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            type="password"
                                            name="passwordNumberInput"
                                            label="Password Number Input passwordVisibility"
                                            control={control}
                                            helperText="Helper Text"
                                            endAdornment={<SupervisorAccount />}
                                            passwordVisibility
                                        />
                                    </GridItem>
                                    {/* <GridItem>
                                        <NumberInput
                                            name="numberInput"
                                            label="SET Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                            returnValue={NumberInputReturnValueEnum.formattedValue}
                                            onKeyPress={(e: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log(e);
                                            }}
                                            placeholder="Placeholder"
                                        />
                                    </GridItem> */}
                                    <GridItem>
                                        <NumberInput
                                            name="disabledNumberInput"
                                            label="SET Disabled Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                            disabled
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="readOnlyNumberInput"
                                            label="SET ReadOnly Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                            readOnly
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputMask2"
                                            label="SET Number Input Format&Mask"
                                            control={control}
                                            helperText="Helper Text"
                                            placeholder="Placeholder"
                                            format="### ### ####"
                                            mask="*"
                                            allowEmptyFormatting
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputSet"
                                            // label="SET Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                            returnValue={NumberInputReturnValueEnum.formattedValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputSet"
                                            //label="SET Number Input"
                                            labelWidth="175px"
                                            control={control}
                                            helperText="Helper Text"
                                            returnValue={NumberInputReturnValueEnum.formattedValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="numberInputSet"
                                            label="SET Number Input"
                                            labelPlacement="top"
                                            control={control}
                                            helperText="Helper Text"
                                            returnValue={NumberInputReturnValueEnum.formattedValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            type="password"
                                            name="passwordNumberInput"
                                            label="SET Password Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <NumberInput
                                            name="phoneNumber"
                                            label="Phone Number Input"
                                            control={control}
                                            helperText="Helper Text"
                                            format={
                                                constants.format.design.phoneNumber.withAreaCode.withBrackets
                                                    .withoutZero
                                            }
                                            mask={constants.format.char.underscore}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button type="submit" text="Send" />
                                        <Button onClick={() => reset()} text="Reset" />
                                        <Button onClick={() => resetField('numberInput')} text="ResetField" />
                                        <Button onClick={() => resetField('numberInputSet')} text="SET ResetField" />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </form>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Text Align' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Button text="Left" onClick={() => setTextAlign('left')} />
                                    <Button text="Center" onClick={() => setTextAlign('center')} />
                                    <Button text="Right" onClick={() => setTextAlign('right')} />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        name="texAlignSet"
                                        label="SET Number Input TextAlign"
                                        control={control}
                                        helperText="Helper Text"
                                        placeholder="placeholder"
                                        textAlign={textAlign}
                                    />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        name="texAlignErp"
                                        label="Number Input TextAlign"
                                        control={control}
                                        helperText="Helper Text"
                                        placeholder="placeholder"
                                        textAlign={textAlign}
                                    />
                                </GridItem>
                                <GridItem>
                                    <Label text="Adornment" />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        label="startAdornment Button"
                                        name="adornment"
                                        control={control}
                                        startAdornment={
                                            <Tooltip sx={{ ml: '-8.5px' }} title="Test">
                                                <Button iconButton icon={<MoreHoriz />} />
                                            </Tooltip>
                                        }
                                    />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        label="endAdornment Button"
                                        name="adornment"
                                        control={control}
                                        endAdornment={
                                            <Tooltip sx={{ mr: '-5px' }} title="Test">
                                                <Button iconButton icon={<MoreHoriz />} />
                                            </Tooltip>
                                        }
                                    />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        label="endAdornment Button Disabled"
                                        name="adornment"
                                        control={control}
                                        disabled
                                        endAdornment={
                                            <Tooltip sx={{ mr: '-5px' }} title="Test">
                                                <Button iconButton icon={<MoreHoriz />} disabled />
                                            </Tooltip>
                                        }
                                    />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        label="endAdornment Icon"
                                        name="adornment"
                                        control={control}
                                        endAdornment={<MoreHoriz />}
                                    />
                                </GridItem>
                                <GridItem>
                                    <NumberInput
                                        label="endAdornment Icon Disabled"
                                        name="adornment"
                                        control={control}
                                        disabled
                                        endAdornment={<MoreHoriz />}
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NumberInputPage;
