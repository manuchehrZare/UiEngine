import { Layout } from '../../../../App';
import type { FC } from 'react';
import * as yup from 'yup';
import { Box, Button, Grid, GridItem, Paper, DatePicker, useForm, useWatch, Nav } from '../../../../lib';
import { isNull, isNaN } from 'lodash';
import { faker } from '@faker-js/faker';

interface IFormValues {
    datePicker: number | null;
    datePicker2: Date | string | null;
    datePicker3: number | null;
    datePicker4: string | null;
    datePickerDisabled: number | null;
    endDate: number | null;
    startDate: number | null;
}

const DatePickerPage: FC = () => {
    const { control, handleSubmit, reset, clearErrors, setFieldError } = useForm<IFormValues>({
        defaultValues: {
            datePicker: null,
            datePicker2: null,
            datePicker3: null,
            datePicker4: null,
            startDate: null,
            endDate: null,
            datePickerDisabled: Number(new Date()),
        },
        validationSchema: {
            datePicker: yup.number().nullable().required('Required').typeError('Type Error'),
            datePicker2: yup.date().nullable().required('Required').typeError('Type Error'),
            startDate: yup
                .number()
                .nullable()
                .required('Tarih giriniz.')
                .typeError('Geçerli tarih giriniz.')
                .test({
                    name: 'start',
                    message: 'Bitişten küçük olmalıdır.',
                    test: (val, context) => {
                        const { endDate } = context.parent as IFormValues;
                        if (
                            (isNull(val) && isNull(endDate)) ||
                            (val && !isNaN(val) && !isNull(val) && isNull(endDate)) ||
                            (isNull(val) && !isNaN(endDate) && !isNull(endDate))
                        ) {
                            return true;
                        } else if (val && !isNaN(val) && !isNull(val) && isNaN(endDate)) {
                            clearErrors('startDate');
                            return true;
                        }
                        if (val && endDate) {
                            val <= endDate && clearErrors('endDate');
                            val >= endDate && setFieldError('endDate', 'Başlangıçtan büyük olmalıdır');
                            return val <= endDate;
                        }
                        return false;
                    },
                }),
            endDate: yup
                .number()
                .nullable()
                .required('Tarih giriniz.')
                .typeError('Geçerli tarih giriniz.')
                .test({
                    name: 'end',
                    message: 'Başlangıçtan büyük olmalıdır',
                    test: (val, context) => {
                        const { startDate } = context.parent as IFormValues;
                        if (
                            (isNull(val) && isNull(startDate)) ||
                            (val && !isNaN(val) && !isNull(val) && isNull(startDate)) ||
                            (isNull(val) && !isNaN(startDate) && !isNull(startDate))
                        ) {
                            return true;
                        } else if (val && !isNaN(val) && !isNull(val) && isNaN(startDate)) {
                            clearErrors('endDate');
                            return true;
                        }
                        if (val && startDate) {
                            val >= startDate && clearErrors('startDate');
                            val <= startDate && setFieldError('startDate', 'Bitişten küçük olmalıdır');
                            return val >= startDate;
                        }
                        return false;
                    },
                }),
        },
    });
    const dateVal = useWatch({ control, fieldName: 'datePicker' });

    const onSubmit = (data: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('--', data);
    };

    // eslint-disable-next-line no-console
    console.log('--dateVal', dateVal);

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Variants' }} />
                        <Grid spacingType="form" p={2}>
                            <GridItem xs>
                                <DatePicker
                                    label={faker.lorem.sentence(15)}
                                    name="outlined"
                                    control={control}
                                    unixTime
                                    helperText="Variant Outlined"
                                    variant="outlined"
                                />
                            </GridItem>
                            <GridItem xs>
                                <DatePicker
                                    label={faker.lorem.sentence(15)}
                                    name="standard"
                                    control={control}
                                    unixTime
                                    helperText="Variant Standard"
                                    variant="standard"
                                />
                            </GridItem>
                            <GridItem xs>
                                <DatePicker
                                    label={faker.lorem.sentence(15)}
                                    name="filled"
                                    control={control}
                                    unixTime
                                    helperText="Variant Filled"
                                    variant="filled"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                        <Grid spacingType="form" p={2}>
                            <GridItem xs>
                                <DatePicker
                                    label={faker.lorem.sentence(15)}
                                    name="datePicker"
                                    control={control}
                                    unixTime
                                    helperText="Helper Text"
                                />
                            </GridItem>
                            <GridItem xs>
                                <DatePicker
                                    label={faker.lorem.sentence(15)}
                                    labelPlacement="start"
                                    name="datePicker"
                                    control={control}
                                    unixTime
                                    helperText="Helper Text"
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'DatePicker' }} />
                        <Box sx={{ p: 3 }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <DatePicker
                                            label="DatePicker -- UnixTime"
                                            name="datePicker"
                                            control={control}
                                            unixTime
                                            // placeholder="Placeholder"
                                            // views={['month', 'year']}
                                            // onOpen={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onOpen');
                                            // }}
                                            // onClose={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onClose');
                                            // }}
                                            helperText="Helper Text"
                                            // invalidMessage="Geçerli tarih giriniz."
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DatePicker
                                            label="DatePicker -- Date"
                                            name="datePicker2"
                                            control={control}
                                            // placeholder="Placeholder"
                                            // views={['month', 'year']}
                                            // onOpen={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onOpen');
                                            // }}
                                            // onClose={() => {
                                            //     // eslint-disable-next-line no-console
                                            //     console.log('onClose');
                                            // }}
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DatePicker
                                            label="DatePicker -- Views"
                                            name="datePicker3"
                                            control={control}
                                            views={['year', 'day']}
                                            format={'dd.MM.yyyy'}
                                            helperText="Helper Text"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DatePicker
                                            label="DatePicker -- String Date"
                                            name="datePicker4"
                                            control={control}
                                            helperText="Helper Text"
                                            format="EEEE dd MMMM yyyy"
                                            // views={['month', 'year']}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DatePicker
                                            label="DatePicker -- Disabled"
                                            name="datePickerDisabled"
                                            control={control}
                                            helperText="Helper Text"
                                            disabled
                                            // format="yyyy"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <DatePicker
                                            label="DatePicker -- ReadOnly"
                                            name="datePickerDisabled"
                                            control={control}
                                            helperText="Helper Text"
                                            readOnly
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Grid>
                                            <GridItem xs>
                                                <DatePicker
                                                    label="Start Date"
                                                    name="startDate"
                                                    control={control}
                                                    unixTime
                                                />
                                            </GridItem>
                                            <GridItem xs>
                                                <DatePicker
                                                    label="End Date"
                                                    name="endDate"
                                                    control={control}
                                                    unixTime
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Button text="Submit" type="submit" />
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </form>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default DatePickerPage;
