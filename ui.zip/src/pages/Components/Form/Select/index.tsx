import { Layout } from '../../../../App';
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, NumberFormat, Paper, Select, useForm } from '../../../../lib';
import { Person, StarBorderRounded } from '@mui/icons-material';
import * as yup from 'yup';
import { sortBy } from 'lodash';
import { faker } from '@faker-js/faker';

export interface IFormValues {
    adornment_multi_select: string[];
    adornment_select: boolean | null;
    booleanData_select: boolean | null;
    dataFormatter_select: string;
    disabled_select: string;
    emptyData: string;
    jsxListRendering_multi_select: string[];
    jsxListRendering_select: string;
    labelPlacement_select: string;
    multi_select: string[];
    nativeHeightControl_select: string[];
    nativeMultipleLimit_select: string[];
    nativeRow_select: string[];
    nativeTimeoutData_select: string[];
    numberData_select: number | null;
    readOnly_select: string;
    renderingDisplayFieldWithElement_select: string;
    select: string;
    stringData_select: string;
    stringDataRendering_multi_select: string[];
    stringDataRendering_select: string;
    timeoutData_select: string;
}

interface IGenericData {
    age: number;
    id: string;
    name: string;
    surname: string;
}

const SelectPage: FC = () => {
    const [timeoutData, setTimeoutData] = useState<IGenericData[]>([]);
    const { control, handleSubmit, setValue, reset } = useForm<IFormValues>({
        defaultValues: {
            adornment_multi_select: [],
            adornment_select: null,
            booleanData_select: null,
            dataFormatter_select: '',
            disabled_select: '1',
            emptyData: '',
            jsxListRendering_multi_select: [],
            jsxListRendering_select: '',
            labelPlacement_select: '',
            multi_select: [],
            nativeHeightControl_select: [],
            nativeMultipleLimit_select: [],
            nativeRow_select: [],
            nativeTimeoutData_select: ['11'],
            numberData_select: null,
            readOnly_select: '1',
            renderingDisplayFieldWithElement_select: '',
            select: '',
            stringDataRendering_multi_select: [],
            stringDataRendering_select: '',
            stringData_select: '',
            timeoutData_select: '11',
        },
        validationSchema: {
            select: yup.string().required('Boş olamaz.'),
            multi_select: yup.array().required('Boş olamaz.').min(1, 'Boş olamaz.'),
            booleanData_select: yup.boolean().nullable().required('Boş olamaz.'),
            nativeRow_select: yup.array().required('Boş olamaz.').min(1, 'Boş olamaz.'),
            timeoutData_select: yup.string().required('Boş olamaz.'),
        },
    });

    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log('--', data);
    };

    const optionsData = [
        {
            id: '1',
            text: 'Text 1Text 1Text 1Text 1Text 1Text 1Text 1Text 1Text 1Text 1 Text 1Text 1Text 1Text 1Text 1Text 1Text 1Text 1Text 1Text 1',
        },
        {
            id: '2',
            text: 'Text 2',
        },
        {
            id: '3',
            text: 'Text 3',
        },
        {
            id: '4',
            text: 'Text 4',
        },
        {
            id: '5',
            text: 'Text 5',
        },
        {
            id: '6',
            text: 'Text 6',
        },
        {
            id: '7',
            text: 'Text 7',
        },
        {
            id: '8',
            text: 'Text 8',
        },
        {
            id: '9',
            text: 'Text 9',
        },
        {
            id: '10',
            text: 'Text 10',
        },
        {
            id: '11',
            text: 'Text 11',
        },
        {
            id: '12',
            text: 'Text 12',
        },
        {
            id: '13',
            text: 'Text 13',
        },
        {
            id: '14',
            text: 'Text 14',
        },
        {
            id: '15',
            text: 'Text 15',
        },
    ];

    const booleanData = [
        {
            id: true,
            text: 'Doğru',
        },
        {
            id: false,
            text: 'Yanlış',
        },
    ];

    const withEmptyData = [
        {
            id: 1,
            text: 'Text1',
        },
        {
            id: 2,
            text: 'Text2',
        },
        {
            id: 3,
            text: 'Text3',
        },
        {
            id: 4,
            text: ' ',
        },
        {
            id: 5,
            text: 'Text5',
        },
    ];

    const stringData = [
        {
            id: '000',
            text: 'Data0',
        },
        {
            id: '001',
            text: 'Data1',
        },
        {
            id: '002',
            text: 'Data2',
        },
        {
            id: '003',
            text: 'Data3',
        },
    ];

    const referenceDataList = [
        {
            code: 'APPROVE',
            name: 'Onaylı',
            filter: '',
        },
        {
            code: 'FOLLOW_UP',
            name: 'Takip',
            filter: '',
        },
        {
            code: 'INSURANCE_DEBT',
            name: 'Sigorta Borcu Vardır',
            filter: '',
        },
        {
            code: 'IS_KRDY',
            name: 'Krd Yön Tlb ile Girilmis',
            filter: '',
        },
        {
            code: 'IS_TEMLIK',
            name: 'Temlik Edilmis',
            filter: '',
        },
        {
            code: 'SINGLE_CREDIT',
            name: 'Tek Kredi',
            filter: '',
        },
        {
            code: 'SINGLE_CREDIT_SUPPLEMENT',
            name: 'Tek Kredi Munzam',
            filter: '',
        },
        {
            code: 'SUPPLEMENT',
            name: 'Munzam',
            filter: '',
        },
        {
            code: 'TAX_DEBT',
            name: 'Vergi Borcu Vardır',
            filter: '',
        },
        {
            code: 'Z_FOLLOW_UP_MODULE',
            name: 'Takip Modülüne Aktarılan Teminatlar',
            filter: '',
        },
    ];

    const postDetayBilgisiList = [
        {
            code: '1',
            name: 'Üye İşyeri : 340010042',
        },
        {
            code: '2',
            name: 'Ticari Adı : AKÇAY PETROL LTD.ŞTI',
        },
        {
            code: '3',
            name: 'Pos No : 10347',
        },
        {
            code: '4',
            name: 'Kuruluş Tarihi : 19.04.2012',
        },
    ];

    const customerAccountList = [
        {
            accountName: 'Ana Hesabım',
            accountType: 'Vadesiz',
            balance: '20004',
            currencyType: 'TL',
            iban: 'TR360005902280130228090757',
        },
        {
            accountName: 'Birikim',
            accountType: 'Vadesiz',
            balance: '20000',
            currencyType: 'USD',
            iban: 'TR360005902280130228090757',
        },
        {
            accountName: 'Diğer',
            accountType: 'Vadesiz',
            balance: 0,
            currencyType: 'TL',
            iban: 'TR360005902280130228090757',
        },
        {
            accountName: 'Altın',
            accountType: 'Vadesiz',
            balance: '20000',
            currencyType: 'TL',
            iban: 'TR360005902280130228090757',
        },
        {
            accountName: 'Gümüş',
            accountType: 'Vadesiz',
            balance: '20000',
            currencyType: 'TL',
            iban: 'TR360005902280130228090757',
        },
    ];

    const genericData: IGenericData[] = [
        {
            id: '11',
            age: 30,
            name: 'Ameera',
            surname: 'Moss',
        },
        {
            id: '22',
            age: 37,
            name: 'Zackary',
            surname: 'Solis',
        },
        {
            id: '33',
            age: 22,
            name: 'Wilma',
            surname: 'Wood',
        },
        {
            id: '44',
            age: 25,
            name: 'Barry',
            surname: 'Conley',
        },
        {
            id: '55',
            age: 44,
            name: 'John',
            surname: 'Martin',
        },
        {
            id: '66',
            age: 33,
            name: 'Benjamin',
            surname: 'Mayer',
        },
    ];

    useEffect(() => {
        const timeoutForSelectData = setTimeout(() => {
            setTimeoutData(genericData);
        }, 10000);
        return () => {
            clearTimeout(timeoutForSelectData);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Grid spacingType="button">
                        <GridItem xs="auto">
                            <Button text="Submit" type="submit" onClick={handleSubmit(onSubmit)} />
                        </GridItem>
                        <GridItem xs="auto">
                            <Button text="Reset" onClick={() => reset()} />
                        </GridItem>
                    </Grid>
                </GridItem>
                <GridItem>
                    <Grid spacingType="common">
                        <GridItem>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Variants' }} />
                                <Grid spacingType="form" p={2}>
                                    <GridItem xs>
                                        <Select
                                            label={faker.lorem.sentence(25)}
                                            name="outlined"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="Variant Outlined"
                                            variant="outlined"
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Select
                                            label={faker.lorem.sentence(15)}
                                            labelPlacement="start"
                                            name="standard"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="Variant Standard"
                                            variant="standard"
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Select
                                            label={faker.lorem.sentence(15)}
                                            labelPlacement="start"
                                            name="filled"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="Variant Filled"
                                            variant="filled"
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem>
                            <Paper>
                                <Nav navTitleProps={{ title: 'LabelEllipsis for Long Label' }} />
                                <Grid spacingType="form" p={2}>
                                    <GridItem xs>
                                        <Select
                                            label={faker.lorem.sentence(25)}
                                            name="select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Select
                                            label={faker.lorem.sentence(15)}
                                            labelPlacement="start"
                                            name="select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Base Select' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            label="Select"
                                            name="select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Disabled Select"
                                            name="disabled_select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            disabled
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="ReadOnly Select"
                                            name="readOnly_select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            readOnly
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Multi Select' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            label="Multi Select"
                                            name="multi_select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            multiple
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Data Types' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            labelWidth="175px"
                                            label="String Data Select"
                                            name="stringData_select"
                                            options={{
                                                data: stringData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            // labelPlacement="top"
                                            label="Boolean Data Select"
                                            name="booleanData_select"
                                            options={{
                                                data: booleanData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Number Data Select"
                                            name="numberData_select"
                                            options={{
                                                data: [
                                                    { id: 0, text: 'Number Text 0' },
                                                    { id: 1, text: 'Number Text 1' },
                                                    { id: 2, text: 'Number Text 2' },
                                                ],
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Label Placement' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            label="Select LabelPlacement-Start"
                                            name="labelPlacement_select"
                                            labelPlacement="start"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            displayEmpty
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Select LabelPlacement-Top"
                                            name="labelPlacement_select"
                                            labelPlacement="top"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            displayEmpty
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'With Empty Data' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            label="Empty Data Select"
                                            name="emptyData"
                                            options={{
                                                data: withEmptyData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Adornment' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            label="Adornment Select"
                                            name="adornment_select"
                                            options={{
                                                data: booleanData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            displayEmpty
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            startAdornment={<StarBorderRounded fontSize="small" />}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Adornment Multi Select"
                                            name="adornment_multi_select"
                                            options={{
                                                data: optionsData,
                                                displayField: 'text',
                                                displayValue: 'id',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            displayEmpty
                                            multiple
                                            startAdornment={'Ads:'}
                                            disabledItems={['1', '2']}
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Native' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select
                                            label="Native Row Select"
                                            name="nativeRow_select"
                                            options={{
                                                data: postDetayBilgisiList,
                                                displayField: 'name',
                                                displayValue: 'code',
                                                renderDisplayList: (params) => `${params.code} - ${params.name}`,
                                                renderDisplayField: (params) => params.code,
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            multiple
                                            native
                                            nativeProps={{
                                                row: 7,
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Native Height Control Select"
                                            name="nativeHeightControl_select"
                                            options={{
                                                data: referenceDataList,
                                                displayField: 'name',
                                                displayValue: 'code',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            multiple
                                            native
                                            sx={{
                                                select: {
                                                    height: '80px !important',
                                                },
                                            }}
                                            //disabledItems={['FOLLOW_UP', 'SUPPLEMENT']}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Native Multiple Limit Select"
                                            name="nativeMultipleLimit_select"
                                            options={{
                                                data: referenceDataList,
                                                displayField: 'name',
                                                displayValue: 'code',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            multiple={2}
                                            native
                                            disabledItems={['FOLLOW_UP', 'SUPPLEMENT']}
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'With Timeout Data' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select<IGenericData>
                                            label="Timeout Data Select"
                                            name="timeoutData_select"
                                            options={{
                                                data: timeoutData || [],
                                                displayField: 'name',
                                                displayValue: 'id',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Native Row Timeout Data Select"
                                            name="nativeTimeoutData_select"
                                            options={{
                                                data: timeoutData,
                                                displayField: 'name',
                                                displayValue: 'id',
                                            }}
                                            control={control}
                                            setValue={setValue}
                                            helperText="helperText"
                                            multiple
                                            native
                                            nativeProps={{
                                                row: 7,
                                            }}
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav
                                    navTitleProps={{ title: 'Data Rendering (renderDisplayField, renderDisplayList)' }}
                                />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select<IGenericData>
                                            label="String Data Rendering Select"
                                            name="stringDataRendering_select"
                                            options={{
                                                data: genericData,
                                                displayField: 'name',
                                                displayValue: 'id',
                                                renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                                renderDisplayList: (params) =>
                                                    `id: ${params.id} - ${params.name} ${params.surname} - ${params.age} years old.`,
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select<IGenericData>
                                            label="String Data Rendering Multi Select"
                                            name="stringDataRendering_multi_select"
                                            multiple
                                            options={{
                                                data: genericData,
                                                displayField: 'name',
                                                displayValue: 'id',
                                                renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                                renderDisplayList: (params) =>
                                                    `id: ${params.id} - ${params.name} ${params.surname} - ${params.age} years old.`,
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select<IGenericData>
                                            label="JSX List Rendering Select"
                                            name="jsxListRendering_select"
                                            options={{
                                                data: genericData,
                                                displayField: 'name',
                                                displayValue: 'id',
                                                renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                                renderDisplayList: (params) => (
                                                    <Box display="flex" alignItems="center" width="100%">
                                                        <Person fontSize="small" />
                                                        <Box ml={1} flex={1}>
                                                            <Box
                                                                display="flex"
                                                                alignItems="center"
                                                                justifyContent="space-between">
                                                                <Box>User ID : {params.id}</Box>
                                                                <Box>Age : {params.age}</Box>
                                                            </Box>
                                                            <Box>
                                                                {params.name} {params.surname}
                                                            </Box>
                                                        </Box>
                                                    </Box>
                                                ),
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Rendering Display Field With React Element"
                                            name="renderingDisplayFieldWithElement_select"
                                            options={{
                                                data: customerAccountList,
                                                displayField: 'accountName',
                                                displayValue: 'accountName',
                                                renderDisplayField: (params) => {
                                                    return (
                                                        <Box
                                                            display="flex"
                                                            alignItems="center"
                                                            width="100%"
                                                            justifyContent="space-between"
                                                            flex={1}>
                                                            <Box>
                                                                {params?.accountType} {params?.currencyType}
                                                            </Box>
                                                            <Box>
                                                                Bakiye :{' '}
                                                                <NumberFormat
                                                                    value={Number(params?.balance)}
                                                                    decimalSeparator=","
                                                                    thousandSeparator="."
                                                                    fixedDecimalScale
                                                                    decimalScale={2}
                                                                    styledValue
                                                                    suffix={` ${params?.currencyType}`}
                                                                />
                                                            </Box>
                                                        </Box>
                                                    );
                                                },
                                                renderDisplayList: (params) => {
                                                    return (
                                                        <Box
                                                            display="flex"
                                                            alignItems="center"
                                                            width="100%"
                                                            justifyContent="space-between"
                                                            flex={1}>
                                                            <Box>
                                                                {params?.accountType} {params?.currencyType}
                                                            </Box>
                                                            <Box>
                                                                Bakiye :{' '}
                                                                <NumberFormat
                                                                    value={Number(params?.balance)}
                                                                    decimalSeparator=","
                                                                    thousandSeparator="."
                                                                    fixedDecimalScale
                                                                    decimalScale={2}
                                                                    styledValue
                                                                    suffix={` ${params?.currencyType}`}
                                                                />
                                                            </Box>
                                                        </Box>
                                                    );
                                                },
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select
                                            label="Rendering Display Field With Multiline React Element "
                                            name="renderingDisplayFieldWithElement_select"
                                            options={{
                                                data: customerAccountList,
                                                displayField: 'accountName',
                                                displayValue: 'accountName',
                                                renderDisplayField: (params) => {
                                                    return (
                                                        <>
                                                            <Box
                                                                display="flex"
                                                                alignItems="center"
                                                                width="100%"
                                                                justifyContent="space-between"
                                                                flex={1}>
                                                                <Box>
                                                                    {params?.accountType} {params?.currencyType}
                                                                </Box>
                                                                <Box>
                                                                    Bakiye :{' '}
                                                                    <NumberFormat
                                                                        value={Number(params?.balance)}
                                                                        decimalSeparator=","
                                                                        thousandSeparator="."
                                                                        fixedDecimalScale
                                                                        decimalScale={2}
                                                                        styledValue
                                                                        suffix={` ${params?.currencyType}`}
                                                                    />
                                                                </Box>
                                                            </Box>
                                                            <Box>{params.iban}</Box>
                                                        </>
                                                    );
                                                },
                                                renderDisplayList: (params) => {
                                                    return (
                                                        <Box
                                                            display="flex"
                                                            alignItems="center"
                                                            width="100%"
                                                            justifyContent="space-between"
                                                            flex={1}>
                                                            <Box>
                                                                {params?.accountType} {params?.currencyType}
                                                            </Box>
                                                            <Box>
                                                                Bakiye :{' '}
                                                                <NumberFormat
                                                                    value={Number(params?.balance)}
                                                                    decimalSeparator=","
                                                                    thousandSeparator="."
                                                                    fixedDecimalScale
                                                                    decimalScale={2}
                                                                    styledValue
                                                                    suffix={` ${params?.currencyType}`}
                                                                />
                                                            </Box>
                                                        </Box>
                                                    );
                                                },
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Select<IGenericData>
                                            label="JSX List Rendering Multi Select"
                                            name="jsxListRendering_multi_select"
                                            multiple
                                            options={{
                                                data: genericData,
                                                displayField: 'name',
                                                displayValue: 'id',
                                                renderDisplayField: (params) => `${params.name} ${params.surname}`,
                                                renderDisplayList: (params) => (
                                                    <Box display="flex" alignItems="center" width="100%">
                                                        <Person fontSize="small" />
                                                        <Box ml={1} flex={1}>
                                                            <Box
                                                                display="flex"
                                                                alignItems="center"
                                                                justifyContent="space-between">
                                                                <Box>User ID : {params.id}</Box>
                                                                <Box>Age : {params.age}</Box>
                                                            </Box>
                                                            <Box>
                                                                {params.name} {params.surname}
                                                            </Box>
                                                        </Box>
                                                    </Box>
                                                ),
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Data Formatter' }} />
                                <Grid spacingType="common">
                                    <GridItem>
                                        <Select<IGenericData>
                                            label="Data Formatter Select"
                                            name="dataFormatter_select"
                                            options={{
                                                data: genericData,
                                                displayField: 'name',
                                                displayValue: 'id',
                                                renderDisplayList: (params) =>
                                                    `${params.name} ${params.surname} - Age: ${params.age}`,
                                                dataFormatter: (data) =>
                                                    sortBy(data, ['age'])
                                                        .reverse()
                                                        .filter((item) => item.age > 30),
                                            }}
                                            control={control}
                                            setValue={setValue}
                                        />
                                    </GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                    </Grid>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default SelectPage;
