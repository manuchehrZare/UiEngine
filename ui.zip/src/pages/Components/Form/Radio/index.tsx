import type { FC } from 'react';
import { Layout } from '../../../../App';
import * as yup from 'yup';
import { RadioGroup, Radio, Box, useForm, Button, Grid, GridItem, Paper, Label, Input, Nav } from '../../../../lib';
import { faker } from '@faker-js/faker';

interface IFormValues {
    radio: string;
}

const RadioPage: FC = () => {
    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            radio: '4',
        },
        validationSchema: {
            radio: yup.string().required('Required').oneOf(['1', '2', '3', '4'], 'Radio must be accepted'),
        },
    });
    const onSubmit = (data: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('-->', data);
    };

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Radio with RadioGroup' }} />
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <Box sx={{ p: 3 }}>
                                <Grid spacing={3}>
                                    <GridItem>
                                        <RadioGroup
                                            name="radio"
                                            control={control}
                                            helperText="RadioGroup HelperText"
                                            label={faker.lorem.sentence(15)}
                                            labelPlacement="top">
                                            <Radio label="Radio 1" value="1" helperText="HelperText 1" />
                                            <Radio label="Radio 2" value="2" helperText="HelperText 2" />
                                            <Radio
                                                label="Radio 3 Disabled"
                                                value="3"
                                                helperText="HelperText 3"
                                                disabled
                                            />
                                            <Radio
                                                label="Radio 4 Disabled"
                                                value="4"
                                                helperText="HelperText 4"
                                                disabled
                                            />
                                        </RadioGroup>
                                    </GridItem>
                                    <GridItem>
                                        <Label text="Color" />
                                        <RadioGroup
                                            name="radio"
                                            labelPlacement="top"
                                            control={control}
                                            label="RadioGroup Label">
                                            <Radio
                                                label="Radio 1"
                                                value="1"
                                                helperText="HelperText 1"
                                                color="error"
                                                size="medium"
                                            />
                                            <Radio label="Radio 2" value="2" helperText="HelperText 2" color="info" />
                                            <Radio
                                                label="Radio 3"
                                                value="3"
                                                helperText="HelperText 3"
                                                color="primary"
                                            />
                                            <Radio
                                                label="Radio 4"
                                                value="4"
                                                helperText="HelperText 4"
                                                color="secondary"
                                            />
                                            <Radio
                                                label="Radio 5"
                                                value="5"
                                                helperText="HelperText 5"
                                                color="success"
                                            />
                                            <Radio
                                                label="Radio 6"
                                                value="6"
                                                helperText="HelperText 6"
                                                color="warning"
                                            />
                                        </RadioGroup>
                                    </GridItem>
                                    <GridItem>
                                        <Label text="RadioGroup LabelPlacement-start" />
                                        <RadioGroup
                                            name="radio"
                                            labelPlacement="start"
                                            helperText="RadioGroup HelperText"
                                            control={control}
                                            label="RadioGroup Label">
                                            <Radio label="Radio 1" value="1" helperText="HelperText 1" />
                                            <Radio label="Radio 2" value="2" helperText="HelperText 2" />
                                        </RadioGroup>
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacing={0.5}>
                                            <GridItem xs={5}>
                                                <RadioGroup
                                                    name="radios"
                                                    labelPlacement="top"
                                                    row
                                                    control={control}
                                                    label="RadioGroup Label">
                                                    <Radio label="Radio 1" value="1" helperText="Size 1" />
                                                    <Radio label="Radio 2" value="2" helperText="Size 2" />
                                                </RadioGroup>
                                            </GridItem>
                                            <GridItem xs={6}>
                                                <Input
                                                    name="radios"
                                                    control={control}
                                                    label="Label input"
                                                    helperText="Helper Text 1"
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Grid spacing={0.5}>
                                            <GridItem xs={6}>
                                                <RadioGroup
                                                    name="radioss"
                                                    labelPlacement="top"
                                                    row
                                                    control={control}
                                                    label="RadioGroup Label">
                                                    <Radio
                                                        label="Radio 1"
                                                        value="1"
                                                        size="small"
                                                        helperText="Small Size 1"
                                                    />
                                                    <Radio
                                                        label="Radio 2"
                                                        value="2"
                                                        size="small"
                                                        helperText="Small Size 2"
                                                    />
                                                </RadioGroup>
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem>
                                        <Button type="submit" text="Send" />
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </form>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default RadioPage;
