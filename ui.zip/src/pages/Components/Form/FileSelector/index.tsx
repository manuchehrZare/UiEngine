import { StarOutlineRounded } from '@mui/icons-material';
import type { FC } from 'react';
import { Layout } from '../../../../App';
import {
    base64Encryption,
    Box,
    Button,
    FileSelector,
    Grid,
    GridItem,
    message,
    MessageTypeEnum,
    Nav,
    Paper,
    useForm,
    validation,
} from '../../../../lib';

interface IFormValues {
    FileSelectorAdornment: File[] | null;
    FileSelectorButton: File[] | null;
    FileSelectorButtonb64: File[] | null;
    FileSelectorMulti: File[] | null;
    FileSelectorMultiEncryption: File[] | null;
    FileSelectorSingle: File[] | null;
}

const FileSelectorPage: FC = () => {
    const { control, handleSubmit, reset, formState } = useForm({
        defaultValues: {
            FileSelectorSingle: null,
            FileSelectorMulti: null,
            FileSelectorAdornment: null,
            FileSelectorMultiEncryption: null,
            FileSelectorButton: null,
            FileSelectorButtonb64: null,
        },
        validationSchema: {
            FileSelectorSingle: validation.file('Dosya', {
                required: true,
                accept: ['pdf', 'docx'],
                maxFileSize: { type: 'MB', size: 0.7 },
                messageFormatter: { accept: (params) => `test dosyalar ${params.accept}` },
            }),
            FileSelectorMulti: validation.file('Dosya', { required: true, max: 3 }),
        },
    });
    const onSubmit = async (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('FileSelector -> formData ==> ', formData);
    };

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'FileSelector - Input' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem xs={6}>
                                            <GridItem>
                                                <FileSelector
                                                    control={control}
                                                    name="FileSelectorSingle"
                                                    accept={['pdf', 'docx']}
                                                    multiple
                                                    onUpdateFile={async (files) => {
                                                        // eslint-disable-next-line
                                                        console.log('files from FileSelectorSingle ==>', files);

                                                        const b64files = await base64Encryption(files, {
                                                            onFileLoad: (detail) => {
                                                                message({
                                                                    autoHideDuration: 5,
                                                                    variant: MessageTypeEnum.success,
                                                                    message: `${detail?.filename} başarıyla yüklendi.`,
                                                                });
                                                            },
                                                        });
                                                        // eslint-disable-next-line
                                                        console.log('files after b64 conversion => ', b64files);
                                                    }}
                                                    label="Single file selection - Base"
                                                />
                                            </GridItem>
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <GridItem>
                                                <FileSelector
                                                    control={control}
                                                    name="FileSelectorMulti"
                                                    accept={['pdf', 'docx']}
                                                    onUpdateFile={async (files) => {
                                                        // eslint-disable-next-line no-console
                                                        console.log('file from FileSelectorMulti ==>', files);
                                                        const b64files = await base64Encryption(files, {
                                                            onFileLoad: (detail) => {
                                                                message({
                                                                    variant: MessageTypeEnum.success,
                                                                    message: `${detail?.filename} başarıyla yüklendi.`,
                                                                });
                                                            },
                                                        });
                                                        // eslint-disable-next-line
                                                        console.log('files after b64 conversion => ', b64files);
                                                    }}
                                                    label="Multiple file selection"
                                                    multiple
                                                />
                                            </GridItem>
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <GridItem>
                                                <FileSelector
                                                    control={control}
                                                    name="FileSelectorAdornment"
                                                    onUpdateFile={async (files) => {
                                                        // eslint-disable-next-line no-console
                                                        console.log('file from FileSelectorAdornment ==>', files);
                                                    }}
                                                    adornmentType="startAdornment"
                                                    label="Single file selection - Adornment align"
                                                />
                                            </GridItem>
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <GridItem>
                                                <FileSelector
                                                    control={control}
                                                    name="FileSelectorMultiEncryption"
                                                    onUpdateFile={async (files) => {
                                                        // eslint-disable-next-line no-console
                                                        console.log('file from FileSelectorMultiEncryption ==>', files);
                                                        const b64files = await base64Encryption(files, {
                                                            onFileLoad: (detail) => {
                                                                message({
                                                                    variant: MessageTypeEnum.success,
                                                                    message: `${detail?.filename} başarıyla yüklendi.`,
                                                                });
                                                            },
                                                        });
                                                        // eslint-disable-next-line
                                                        console.log('files after b64 conversion => ', b64files);
                                                    }}
                                                    label="Multiple file selection - b64 encryption"
                                                    multiple
                                                />
                                            </GridItem>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'FileSelector - Button (with Props)' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem xs={6}>
                                            <GridItem>
                                                <FileSelector
                                                    control={control}
                                                    name="FileSelectorButton"
                                                    onUpdateFile={(files) => {
                                                        // eslint-disable-next-line no-console
                                                        console.log('file from FileSelectorButton ==>', files);
                                                    }}
                                                    component="Button"
                                                    multiple
                                                />
                                            </GridItem>
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <GridItem>
                                                <FileSelector
                                                    control={control}
                                                    name="FileSelectorButtonb64"
                                                    onUpdateFile={async (files) => {
                                                        // eslint-disable-next-line no-console
                                                        console.log('file from FileSelectorButtonb64 ==>', files);
                                                        const b64files = await base64Encryption(files, {
                                                            onLoadingChange: (loading) => {
                                                                // eslint-disable-next-line no-console
                                                                console.log(loading);
                                                            },
                                                        });
                                                        // eslint-disable-next-line no-console
                                                        console.log('files after b64 conversion => ', b64files);
                                                    }}
                                                    component="Button"
                                                    ButtonProps={{ icon: <StarOutlineRounded /> }}
                                                />
                                            </GridItem>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={12}>
                                    <Grid spacingType="button">
                                        <GridItem xs="auto">
                                            <Button
                                                text="Submit"
                                                onClick={() => {
                                                    handleSubmit(onSubmit)();
                                                    // eslint-disable-next-line no-console
                                                    console.log('errors', formState.errors);
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button text="Reset" onClick={() => reset()} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default FileSelectorPage;
