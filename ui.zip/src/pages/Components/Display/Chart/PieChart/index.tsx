import type { FC } from 'react';
import { Layout } from '../../../../../App';
import type { IPieChartData } from '../../../../../lib';
import { Box, Grid, GridItem, Paper, PieChart, Nav } from '../../../../../lib';
import { List, ListItem, ListItemText, ListItemIcon } from '@mui/material';
import { Circle } from '@mui/icons-material';

const ButtonPage: FC = () => {
    const chartName = {
        pie: 'Pie & Donut Chart',
    };
    const colors: string[] = ['#127a3d', '#7db900', '#c3da0d'];
    const data: IPieChartData[] = [
        { name: 'Group A', value: 400, valueUI: '400 TL' },
        { name: 'Group B', value: 300, valueUI: '300 TL' },
        { name: 'Group C', value: 300, valueUI: '300 TL' },
    ];

    const activeIndexInfo = [
        {
            property: 'activeIndex={3}',
            desc: 'activeShape eventType varsa; tek bir parcanin aktif kalmasini saglar',
        },
        {
            property: 'activeIndex={[0, 2]} veya activeIndex={{ value: [1, 2] }}',
            desc: '2 tanımlama da aynıdır. ActiveShape eventType varsa; "hover" ise tek bir parcanin, "click" ise birden fazla parcanin aktif kalmasini saglar',
        },
        {
            property: 'activeIndex={{ value: 1 }}',
            desc: 'activeShape eventType varsa; tek bir parcanin aktif kalmasini saglar',
        },
        {
            property: 'activeIndex={{ constant: true, value: 1 }}',
            desc: 'Chartta sabit olarak aktif parca gorunmesini saglar. activeShape eventType varsa; sabit parca disinda tek bir parcanin aktif kalmasini saglar',
        },
        {
            property: 'activeIndex={{ constant: true, value: [0, 1] }}',
            desc: 'Chartta sabit olarak aktif parca gorunmesini saglar. activeShape eventType varsa; sabit parca ile birlikte birden fazla parcanin aktif kalmasini saglar. "hover" ise sabitlerin disinda bir aktif parcayi saglar; "click" ise sabitlerin disinda birden fazla aktif parcayi saglar.',
        },
    ];
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ActiveIndex Özelliğinin Ayrıntıları' }} />
                        <Box sx={{ p: 3 }}>
                            <List>
                                {activeIndexInfo.map((item, index: number) => (
                                    <ListItem key={`list-${String(index)}`}>
                                        <ListItemIcon sx={{ minWidth: 25 }}>
                                            <Circle sx={{ fontSize: 10 }} />
                                        </ListItemIcon>
                                        <ListItemText primary={item.property} secondary={item.desc} />
                                    </ListItem>
                                ))}
                            </List>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'Base' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} />
                            <PieChart data={data} colors={colors} insideRadius={40} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'Label' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} label={'Label'} />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                // label={'Label'}
                                label={{
                                    value: 'Label',
                                    position: 'center',
                                    color: '#4b4f54',
                                    fontWeight: 600,
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'InsideRadius' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} insideRadius={20} />
                            <PieChart data={data} colors={colors} insideRadius={50} />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'Tooltip' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} tooltip />
                            <PieChart data={data} colors={colors} insideRadius={40} tooltip />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'Custom Tooltip' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart
                                data={data}
                                colors={colors}
                                tooltip={{
                                    backgroundColor: '#f3f3f3',
                                    valueColor: '#f00',
                                    fontSize: 12,
                                    labelColor: '#000',
                                    radius: 10,
                                }}
                            />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                tooltip={{
                                    backgroundColor: '#92a3b4',
                                    valueColor: '#fff',
                                    fontSize: 14,
                                    border: '1px solid #000',
                                    labelColor: '#fff',
                                    radius: 20,
                                    seperator: ':',
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'Legend' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} legend />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                // legend
                                legend={{
                                    iconType: 'star',
                                    position: 'top',
                                    iconSize: 12,
                                    color: '#4b4f54',
                                    fontSize: 14,
                                    margin: 10,
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'ActiveIndex' }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} activeIndex={[0, 1, 2, 3]} />
                            <PieChart data={data} colors={colors} insideRadius={40} activeIndex={[0, 1, 2, 3]} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: "ActiveShape : { type: 'default' }" }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} activeIndex={[0]} activeShape={{ type: 'default' }} />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={[0]}
                                activeShape={{ type: 'default' }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: "ActiveShape : { type: 'bold' }" }} />
                        <Box sx={{ p: 3, display: 'flex' }}>
                            <PieChart data={data} colors={colors} activeIndex={[0]} activeShape={{ type: 'bold' }} />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={[0]}
                                activeShape={{ type: 'bold' }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav navTitleProps={{ title: chartName.pie, subTitle: 'ActiveShape : { infoView: true }' }} />
                        <Box sx={{ p: 3 }}>
                            <PieChart data={data} colors={colors} activeIndex={[0]} activeShape={{ infoView: true }} />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={[0]}
                                activeShape={{ infoView: true }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav
                            navTitleProps={{
                                title: chartName.pie,
                                subTitle: "ActiveShape : { type: 'bold', insideRate: true | object }",
                            }}
                        />
                        <Box sx={{ p: 3 }}>
                            <PieChart
                                data={data}
                                colors={colors}
                                activeIndex={[0]}
                                activeShape={{ type: 'bold', insideRate: true }}
                            />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={[0]}
                                activeShape={{
                                    type: 'bold',
                                    // insideRate: true,
                                    insideRate: { color: '#fff', textShadowColor: '#000', fontWeight: 'bold' },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav
                            navTitleProps={{
                                title: chartName.pie,
                                subTitle: 'ActiveShape : { partialNameView: true | object }',
                            }}
                        />
                        <Box sx={{ p: 3 }}>
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={[0]}
                                activeShape={{
                                    partialNameView: true,
                                }}
                            />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={[0]}
                                activeShape={{
                                    type: 'bold',
                                    // partialNameView: true,
                                    partialNameView: {
                                        color: '#888',
                                        fontSize: 16,
                                        fontWeight: 600,
                                    },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav
                            navTitleProps={{ title: chartName.pie, subTitle: "ActiveShape : { eventType: 'click' }" }}
                        />
                        <Box sx={{ p: 3 }}>
                            <PieChart data={data} colors={colors} activeShape={{ eventType: 'click' }} />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeShape={{ eventType: 'click' }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav
                            navTitleProps={{ title: chartName.pie, subTitle: "ActiveShape : { eventType: 'hover' }" }}
                        />
                        <Box sx={{ p: 3 }}>
                            <PieChart data={data} colors={colors} activeShape={{ eventType: 'hover' }} />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeShape={{ eventType: 'hover' }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <Grid p={1} spacing={1}>
                <GridItem xs={4}>
                    <Paper>
                        <Nav
                            navTitleProps={{
                                title: chartName.pie,
                                subTitle:
                                    "Constant ActiveIndex : { value: [0], constant: true }, ActiveShape : { eventType: 'click' }",
                            }}
                        />
                        <Box sx={{ p: 3 }}>
                            <PieChart
                                data={data}
                                colors={colors}
                                activeIndex={{ value: [0], constant: true }}
                                activeShape={{ eventType: 'click' }}
                            />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={{ value: [0], constant: true }}
                                activeShape={{ eventType: 'click' }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={4}>
                    <Paper>
                        <Nav
                            navTitleProps={{
                                title: chartName.pie,
                                subTitle:
                                    "Constant ActiveIndex : { value: [0], constant: true }, ActiveShape : { eventType: 'hover' }",
                            }}
                        />
                        <Box sx={{ p: 3 }}>
                            <PieChart
                                data={data}
                                colors={colors}
                                activeIndex={{ value: [0], constant: true }}
                                activeShape={{ eventType: 'hover' }}
                            />
                            <PieChart
                                data={data}
                                colors={colors}
                                insideRadius={40}
                                activeIndex={{ value: [0], constant: true }}
                                activeShape={{ eventType: 'hover' }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ButtonPage;
