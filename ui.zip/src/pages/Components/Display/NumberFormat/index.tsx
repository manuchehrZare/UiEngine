import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, importantStyle, Label, Nav, NumberFormat, Paper, theme } from '../../../../lib';

const NumberFormatPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'NumberFormat' }} />
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Base Example String Value" />
                            <NumberFormat value="123123" />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Base Example Number Value" />
                            <NumberFormat value={123123} />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Formatted Value (# ### ##)" />
                            <NumberFormat value={123123} format="# ### ##" />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Formatted and Masked Value (format: ###***, value:'123456')" />
                            <NumberFormat value={123456} format="###***" />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Suffix" />
                            <NumberFormat value={123} suffix="₺" />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Prefix" />
                            <NumberFormat value={123} prefix="₺" />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Thousand Seperator" />
                            <NumberFormat value={123123123.23} thousandSeparator="," />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Decimal Seperator" />
                            <NumberFormat value={123.23} decimalSeparator="." />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Allow Leading" />
                            <NumberFormat value={'00123'} />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Decimal Scale - Fixed Decimal Scale" />
                            <NumberFormat value={-123} decimalScale={3} fixedDecimalScale />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Decimal Scale - With Styled Value" />
                            <NumberFormat value={123.23} decimalSeparator="." styledValue />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="Decimal Scale - With Styled Value and Component Props" />
                            <NumberFormat
                                value={123.23}
                                decimalSeparator=","
                                // renderText={(formattedValue) => <Box>{formattedValue}</Box>}
                                styledValue
                                prefix="Prefix "
                                suffix=" Suffix"
                                componentProps={{
                                    styledValueProps: {
                                        fractionalPartProps: {
                                            sx: { color: importantStyle(theme.palette.secondary.main) },
                                        },
                                        integerPartProps: {
                                            sx: { color: importantStyle('red') },
                                        },
                                    },
                                }}
                            />
                        </Box>
                        <Box sx={{ px: 3, py: 2 }}>
                            <Label text="With Styled Value and Firt Part of Integer Part" />
                            <NumberFormat
                                value={2758654.53}
                                decimalSeparator=","
                                thousandSeparator="."
                                styledValue
                                prefix="Prefix "
                                suffix=" Suffix"
                                // sx={{ fontSize: 30 }}
                                componentProps={{
                                    prefixProps: {
                                        color: importantStyle(theme.palette.warning.main),
                                        fontSize: importantStyle('18px'),
                                    },
                                    suffixProps: { color: importantStyle(theme.palette.info.main) },
                                    // valueProps: { color: importantStyle(theme.palette.grey[500]) },
                                    styledValueProps: {
                                        fractionalPartProps: {
                                            sx: { color: importantStyle(theme.palette.secondary.main) },
                                        },
                                        integerPartProps: {
                                            sx: { color: importantStyle('red') },
                                        },
                                        integerFirstPartProps: {
                                            sx: { color: importantStyle('blue'), fontSize: importantStyle('22px') },
                                        },
                                    },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NumberFormatPage;
