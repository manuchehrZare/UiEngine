import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import {
    Box,
    Button,
    Grid,
    GridItem,
    Input,
    Nav,
    NumberInput,
    Paper,
    VRKeyboard,
    useForm,
    useWatch,
} from '../../../../lib';
import { Close, KeyboardHide } from '@mui/icons-material';
import * as yup from 'yup';

const VRKeyboardPage: FC = () => {
    const [open, setOpen] = useState(false);
    const [open3, setOpen3] = useState(false);

    const { handleSubmit, control, reset } = useForm({
        defaultValues: { keyboard: '', numberKeyboard: null },
        validationSchema: {
            keyboard: yup.string().required('Required').typeError('TypeError'),
            numberKeyboard: yup.number().nullable().required('Required').typeError('TypeError'),
        },
    });

    const onSubmit = (data: any) => {
        // eslint-disable-next-line no-console
        console.log('data', data);
    };

    const keyboardValue = useWatch({ control: control, fieldName: ['keyboard', 'numberKeyboard'] });

    // eslint-disable-next-line no-console
    console.log('watch', keyboardValue);

    return (
        <Layout>
            <Box>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <Grid p={1} spacing={2}>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'VRKeyboard' }} />
                                <Box sx={{ p: 3 }}>
                                    <Grid spacing={2}>
                                        <GridItem>
                                            <Button
                                                text="Toggle Keyboard"
                                                onClick={() => {
                                                    setOpen((prevState) => !prevState);
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <VRKeyboard
                                                // placement="right-end"
                                                open={open}
                                                anchorEl={
                                                    <Input
                                                        name="keyboard"
                                                        control={control}
                                                        endAdornment={
                                                            <Button
                                                                iconButton
                                                                variant="text"
                                                                rounded
                                                                icon={open ? <Close /> : <KeyboardHide />}
                                                                onClick={() => {
                                                                    setOpen((prevState) => !prevState);
                                                                }}
                                                            />
                                                        }
                                                    />
                                                }
                                            />
                                        </GridItem>
                                    </Grid>
                                </Box>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Number VRKeyboard' }} />
                                <Box sx={{ p: 3 }}>
                                    <VRKeyboard
                                        numPad
                                        placement="bottom-end"
                                        open={open3}
                                        anchorEl={
                                            <NumberInput
                                                name="numberKeyboard"
                                                control={control}
                                                allowNegative
                                                allowLeadingZeros
                                                thousandSeparator="."
                                                decimalSeparator=","
                                                type="text"
                                                endAdornment={
                                                    <Button
                                                        iconButton
                                                        variant="text"
                                                        rounded
                                                        icon={open3 ? <Close /> : <KeyboardHide />}
                                                        onClick={() => {
                                                            setOpen3((prevState) => !prevState);
                                                        }}
                                                    />
                                                }
                                            />
                                        }
                                    />
                                </Box>
                            </Paper>
                        </GridItem>
                    </Grid>
                    <Grid p={1}>
                        <GridItem>
                            <Button text="Submit" type="submit" />
                            <Button text="Reset" onClick={() => reset()} />
                        </GridItem>
                    </Grid>
                </form>
            </Box>
        </Layout>
    );
};

export default VRKeyboardPage;
