import type { FC } from 'react';
import { useEffect } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Nav,
    Paper,
    message,
    useDataGridApiRef,
} from '../../../../../lib';
import { rowsExample } from '../data';

const DataGridSelectionPage: FC = () => {
    const apiRef = useDataGridApiRef();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'id',
            headerName: 'Id',
        },
        {
            field: 'fullName',
            headerName: 'Full Name',
        },
        {
            field: 'age',
            headerName: 'Age',
        },
    ];

    useEffect(() => {
        message({
            variant: 'info',
            message: 'Check console after select row to see onSelectChange function params',
        });
        message({ variant: 'info', message: 'To select multiple row use CTRL' });
        apiRef.current.selectRow(0);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Grid spacing={1} p={1}>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'standart selection' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    selectionOnClickable
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={rowsExample}
                                    columns={columns}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'disableMultipleRowSelection' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    selectionOnClickable
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    disableMultipleRowSelection
                                    rows={rowsExample}
                                    columns={columns}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'disableMultipleRowSelectionWithCheckbox' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    selectionOnClickable
                                    checkboxSelection
                                    onSelectChange={(params) => console.log('params', params)} //eslint-disable-line
                                    disableMultipleRowSelection
                                    rows={rowsExample}
                                    columns={columns}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'select row with apiRef' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem height={300}>
                                <DataGrid
                                    apiRef={apiRef}
                                    selectionOnClickable
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    rows={rowsExample}
                                    columns={columns}
                                />
                            </GridItem>
                            <GridItem>
                                <Grid spacing={0.5}>
                                    <GridItem xs>
                                        <Button
                                            text="Remove all selections"
                                            fullWidth
                                            onClick={() => apiRef.current.selectRows([], true, true)}
                                            // onClick={() => apiRef.current.setRowSelectionModel([])}
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Button
                                            text="Select 3 row"
                                            fullWidth
                                            onClick={() => apiRef.current.setRowSelectionModel([0, 1, 2])}
                                        />
                                    </GridItem>
                                    <GridItem xs>
                                        <Button
                                            text="Select a row with old selects"
                                            fullWidth
                                            onClick={() => apiRef.current.selectRow(3)}
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridSelectionPage;
