import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    DataGrid,
    DataGridColumnTypeEnum,
    DataGridFooter,
    dataGridPaginationRowCountSelector,
    Grid,
    GridItem,
    Label,
    Nav,
    Paper,
    Typography,
    useDataGridApiRef,
} from '../../../../../lib';

interface IData {
    abbreviation?: string;
    age: number | null;
    budget?: string | null;
    date?: Date;
    firstName: string | null;
    id: number;
    lastName: string;
}

const DataGridPaginationPage: FC = () => {
    const apiRef = useDataGridApiRef();
    const apiRefNum1 = useDataGridApiRef();
    const apiRefNum2 = useDataGridApiRef();
    const apiRefNum3 = useDataGridApiRef();
    const [dataGridData, setDataGridData] = useState<IData[]>([]);

    // * rows = data
    const rowsData1: IData[] = [
        { id: 1, lastName: 'Snow', firstName: 'Jon', abbreviation: 'JS', age: 35, budget: '10000' },
        { id: 2, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '20000' },
        { id: 3, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '77777' },
        { id: 4, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '7777' },
        { id: 5, lastName: 'Lannister', firstName: 'Jaime', abbreviation: 'JL', age: 45, budget: '30000' },
        { id: 6, lastName: 'Stark', firstName: 'Arya', abbreviation: 'AS', age: 16, budget: '15000' },
        { id: 7, lastName: 'Targaryen', firstName: 'Daenerys', abbreviation: 'DT', age: null, budget: '10000.75' },
        { id: 8, lastName: 'Melisandre', firstName: null, abbreviation: 'M', age: 150, budget: '123123.123' },
        { id: 9, lastName: 'Clifford', firstName: 'Ferrara', abbreviation: 'FC', age: 44, budget: '500000' },
        { id: 10, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '200000' },
        { id: 11, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '0' },
        { id: 12, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '' },
        { id: 13, lastName: 'Roxie', firstName: 'Harvey', abbreviation: 'HR', age: 65, budget: null },
        { id: 14, lastName: 'Snow', firstName: 'Jon', abbreviation: 'JS', age: 35, budget: '10000' },
        { id: 15, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '20000' },
        { id: 16, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '77777' },
        { id: 17, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '7777' },
        { id: 18, lastName: 'Lannister', firstName: 'Jaime', abbreviation: 'JL', age: 45, budget: '30000' },
        { id: 19, lastName: 'Stark', firstName: 'Arya', abbreviation: 'AS', age: 16, budget: '15000' },
        { id: 20, lastName: 'Targaryen', firstName: 'Daenerys', abbreviation: 'DT', age: null, budget: '10000.75' },
        { id: 21, lastName: 'Melisandre', firstName: null, abbreviation: 'M', age: 150, budget: '123123.123' },
        { id: 22, lastName: 'Clifford', firstName: 'Ferrara', abbreviation: 'FC', age: 44, budget: '500000' },
        { id: 23, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '200000' },
        { id: 24, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '0' },
        { id: 25, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '' },
        { id: 26, lastName: 'Roxie', firstName: 'Harvey', abbreviation: 'HR', age: 65, budget: null },
        { id: 27, lastName: 'Snow', firstName: 'Jon', abbreviation: 'JS', age: 35, budget: '10000' },
        { id: 28, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '20000' },
        { id: 29, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '77777' },
        { id: 30, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '7777' },
        { id: 31, lastName: 'Lannister', firstName: 'Jaime', abbreviation: 'JL', age: 45, budget: '30000' },
        { id: 32, lastName: 'Stark', firstName: 'Arya', abbreviation: 'AS', age: 16, budget: '15000' },
        { id: 33, lastName: 'Targaryen', firstName: 'Daenerys', abbreviation: 'DT', age: null, budget: '10000.75' },
        { id: 34, lastName: 'Melisandre', firstName: null, abbreviation: 'M', age: 150, budget: '123123.123' },
        { id: 35, lastName: 'Clifford', firstName: 'Ferrara', abbreviation: 'FC', age: 44, budget: '500000' },
        { id: 36, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '200000' },
        { id: 37, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '0' },
        { id: 38, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '' },
        { id: 39, lastName: 'Roxie', firstName: 'Harvey', abbreviation: 'HR', age: 65, budget: null },
        { id: 40, lastName: 'Snow', firstName: 'Jon', abbreviation: 'JS', age: 35, budget: '10000' },
        { id: 41, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '20000' },
        { id: 42, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '77777' },
        { id: 43, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '7777' },
        { id: 44, lastName: 'Lannister', firstName: 'Jaime', abbreviation: 'JL', age: 45, budget: '30000' },
        { id: 45, lastName: 'Stark', firstName: 'Arya', abbreviation: 'AS', age: 16, budget: '15000' },
        { id: 46, lastName: 'Targaryen', firstName: 'Daenerys', abbreviation: 'DT', age: null, budget: '10000.75' },
        { id: 47, lastName: 'Melisandre', firstName: null, abbreviation: 'M', age: 150, budget: '123123.123' },
        { id: 48, lastName: 'Clifford', firstName: 'Ferrara', abbreviation: 'FC', age: 44, budget: '500000' },
        { id: 49, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '200000' },
        { id: 50, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '0' },
    ];

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            width: 90,
            editable: true,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'firstName',
            headerName: 'First name',
            width: 150,
            minWidth: 150,
            maxWidth: 200,
            description: 'The identification used by the person with access to the online service.',
            flex: 1,
            type: '',
            // resizable: false,
            // hideable: false,
            align: 'right',
            headerAlign: 'right',
            disableColumnMenu: true,
            // disableExport: true,
            editable: true,
            sortable: true,
            sortingOrder: ['desc', 'asc', null],
            filterable: false,
        },
        {
            field: 'lastName',
            headerName: 'Last nameeeeee',
            width: 150,
            editable: true,
            renderCell: (params) => {
                return (
                    <Box
                        component="div"
                        sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            width: '100%',
                        }}>
                        <Label
                            text={params.value}
                            className="MuiDataGrid-cellContent"
                            color="common.black"
                            fontWeight={400}
                        />
                    </Box>
                );
            },
        },
        {
            field: 'abbreviation',
            headerName: 'Abbreviation',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.abbreviation,
        },
        {
            field: 'age',
            headerName: 'Age',
            headerAlign: 'center',
            type: 'number',
            width: 110,
            editable: true,
            sortable: false,
        },
        {
            field: 'date',
            headerName: 'Date',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.date,
            editable: true,
            flex: 1,
        },
        {
            field: 'budget',
            headerName: 'Budget',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.currency,
            editable: true,
            flex: 1,
        },
    ];

    useEffect(() => {
        setDataGridData(rowsData1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const CustomFooter = (props: any) => {
        return (
            <Box
                sx={{
                    display: 'flex',
                    alignItems: 'center',
                    width: '100%',
                    borderTop: '1px solid rgba(224, 224, 224, 1)',
                }}>
                <Typography
                    variant="body2"
                    sx={{
                        mr: 'auto',
                        display: 'flex',
                        alignItems: 'center',
                    }}>
                    Toplam Veri: {dataGridPaginationRowCountSelector(apiRef)}
                </Typography>
                <DataGridFooter
                    {...props}
                    sx={{
                        border: 'none', // Footer'ın kendi border'ını da kaldırır
                    }}
                />
            </Box>
        );
    };

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Pagination - AutoSize' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 310 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRef}
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    pagination
                                    autoPageSize
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    selectionOnClickable
                                    // selectedCountView
                                    // selectionModel={[1]}
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('onSelectChange params', params);
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Pagination - Custom Page Size' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRef}
                                    pageSize={4}
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    pagination
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    selectedCountView
                                    selectionOnClickable
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('onSelectChange params', params);
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Pagination - Page Size Options' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRef}
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    pagination
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    pageSizeOptions={[
                                        10,
                                        100,
                                        { value: 1000, label: '1,000' },
                                        { value: -1, label: 'All' },
                                    ]}
                                    selectionOnClickable
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Pagination - Custom Footer with number of total row' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRef}
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    slots={{
                                        footer: CustomFooter,
                                    }}
                                    pagination
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    pageSizeOptions={[
                                        10,
                                        100,
                                        { value: 1000, label: '1,000' },
                                        { value: -1, label: 'All' },
                                    ]}
                                    selectionOnClickable
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Pagination -With Number Pagination' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRefNum1}
                                    numberPagination
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    onPaginationModelChange={(model) => {
                                        // eslint-disable-next-line no-console
                                        console.log('Pagination Model Changed:', model);
                                    }}
                                    pagination
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    selectionOnClickable
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav
                        navTitleProps={{ title: 'Data Grid - Pagination -With Number Pagination And PageSizeOptions' }}
                    />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRefNum2}
                                    numberPagination
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    onPaginationModelChange={(model) => {
                                        // eslint-disable-next-line no-console
                                        console.log('Pagination Model Changed:', model);
                                    }}
                                    pagination
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    pageSizeOptions={[
                                        10,
                                        100,
                                        { value: 1000, label: '1,000' },
                                        { value: -1, label: 'All' },
                                    ]}
                                    selectionOnClickable
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Pagination - With Number Pagination and Custom Item' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData}
                                    columns={columns}
                                    toolbar
                                    apiRef={apiRefNum3}
                                    numberPagination
                                    slots={{
                                        footer: CustomFooter,
                                    }}
                                    pagination
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                    }}
                                    selectionOnClickable
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridPaginationPage;
