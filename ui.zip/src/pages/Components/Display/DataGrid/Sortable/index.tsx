import type { FC } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Nav,
    Paper,
    PhoneNumber,
    numberFormat,
} from '../../../../../lib';
import { customData, employeesData } from '../data';

const DataGridSortablePage: FC = () => {
    const cityList = [
        {
            key: '16',
            value: 'Bursa',
        },
        {
            key: '34',
            value: 'İstanbul',
        },
        {
            key: '10',
            value: 'Balıkesir',
        },
        {
            key: '35',
            value: 'İzmir',
        },
        {
            key: '06',
            value: 'Ankara',
        },
        {
            key: '66',
            value: 'Yozgat',
        },
        {
            key: '45',
            value: 'Manisa',
        },
        {
            key: '81',
            value: 'Düzce',
        },
    ];

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
            headerAlign: 'center',
            align: 'center',
        },
        {
            field: 'userId',
            headerName: 'Kullanıcı Adı',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'jobTitleName',
            headerName: 'Meslek',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'firstName',
            headerName: 'Ad',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'lastName',
            headerName: 'Soyad',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'preferredFullName',
            headerName: 'Tam Ad',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'age',
            headerName: 'Yaş',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'employeeCode',
            headerName: 'Çalışan Kodu',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'region',
            headerName: 'Bölge',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
        {
            field: 'phoneNumber',
            headerName: 'Telefon Numarası',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
            renderCell: (params) => <PhoneNumber component="NumberFormat" value={params.value} />,
        },
        {
            field: 'emailAddress',
            headerName: 'Email',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
        },
    ];

    const numbersColumns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
            headerAlign: 'center',
            align: 'center',
        },
        {
            field: 'typeNumber',
            headerName: 'Column Type Number',
            headerAlign: 'center',
            sortable: true,
            align: 'right',
            type: 'number',
            flex: 1,
            valueFormatter: (value) =>
                numberFormat(value, {
                    minimumFractionDigits: 2,
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                }),
        },
        {
            field: 'typeString',
            headerName: 'Column Type String (default)',
            headerAlign: 'center',
            sortable: true,
            align: 'right',
            type: 'string',
            flex: 1,
            valueFormatter: (value) =>
                numberFormat(value, {
                    minimumFractionDigits: 2,
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                }),
        },
        {
            field: 'typeCurrency',
            headerName: 'Column Type Currency',
            headerAlign: 'center',
            sortable: true,
            align: 'right',
            type: 'currency',
            flex: 1,
        },
    ];

    const cityColumns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
            headerAlign: 'center',
            align: 'center',
        },
        {
            field: 'citySortKey',
            headerName: 'City Sort For Key (default)',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
            valueOptions: () => cityList,
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => `${value.key} - ${value.value}`,
            type: 'singleSelect',
        },
        {
            field: 'citySortValue',
            headerName: 'City Sort For Value',
            headerAlign: 'center',
            sortable: true,
            flex: 1,
            valueOptions: () => cityList,
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => `${value.key} - ${value.value}`,
            type: 'singleSelect',
            sortComparator: (v1, v2) =>
                cityList
                    .find((item) => item.key === v1)
                    ?.value?.localeCompare(cityList?.find((item) => item.key === v2)?.value as string) as number,
        },
    ];

    const numbersRows = [
        {
            typeNumber: '1000000',
            typeString: '1000000',
            typeCurrency: '1000000',
        },
        {
            typeNumber: '105500',
            typeString: '105500',
            typeCurrency: '105500',
        },
        {
            typeNumber: '10750',
            typeString: '10750',
            typeCurrency: '10750',
        },
        {
            typeNumber: '1200',
            typeString: '1200',
            typeCurrency: '1200',
        },
        {
            typeNumber: '900',
            typeString: '900',
            typeCurrency: '900',
        },
        {
            typeNumber: '3000000',
            typeString: '3000000',
            typeCurrency: '3000000',
        },
    ];

    const cityRows = [
        {
            citySortKey: '16',
            citySortValue: '16',
        },
        {
            citySortKey: '34',
            citySortValue: '34',
        },
        {
            citySortKey: '10',
            citySortValue: '10',
        },
        {
            citySortKey: '81',
            citySortValue: '81',
        },
        {
            citySortKey: '45',
            citySortValue: '45',
        },
        {
            citySortKey: '66',
            citySortValue: '66',
        },
        {
            citySortKey: '06',
            citySortValue: '06',
        },
        {
            citySortKey: '35',
            citySortValue: '35',
        },
    ];

    const customColums: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            width: 90,
            editable: true,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'cell1',
            headerName: 'Cell 1',
            headerAlign: 'center',
            minWidth: 100,
            sortComparator: (v1, v2) => {
                const [v1Part1, v1Part2] = v1.split('-');
                const [v2Part1, v2Part2] = v2.split('-');

                const part1Diff = Number(v1Part1) - Number(v2Part1);
                if (part1Diff !== 0) return part1Diff;

                const part2Diff = Number(v1Part2) - Number(v2Part2);
                if (part2Diff !== 0) return part2Diff;

                return v1Part2.localeCompare(v2Part2);
            },
        },
        {
            field: 'cell2',
            headerName: 'Cell 2',
            headerAlign: 'center',
            minWidth: 100,
            sortComparator: (v1, v2) => {
                const diff = Number(v1) - Number(v2);
                return diff !== 0 ? diff : v1.localeCompare(v2);
            },
        },
    ];

    return (
        <Grid spacing={1}>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Sortable' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 300 }}>
                                        <DataGrid rows={employeesData} columns={columns} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'String Numbers Example' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 300 }}>
                                        <DataGrid rows={numbersRows} columns={numbersColumns} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Key - Value Example' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 300 }}>
                                        <DataGrid rows={cityRows} columns={cityColumns} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Custom Example' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 300 }}>
                                        <DataGrid rows={customData} columns={customColums} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridSortablePage;
