import type { FC } from 'react';
import { useCallback, useEffect, useState } from 'react';
import type { DataGridColumnsPropsType, DataGridPaginationModel } from '../../../../../lib';
import { Box, Grid, GridItem, Paper, DataGrid, Nav } from '../../../../../lib';
import { sortBy, uniq } from 'lodash';

interface IData {
    body: string;
    id: number;
    title: string;
    userId: number;
}

const DataGridServerSidePaginationPage: FC = () => {
    const PAGESIZE = 20;
    const [dataGridData, setDataGridData] = useState<{
        data: IData[];
        totalCount: number;
    }>({ data: [], totalCount: 0 });
    const [paginationModel, setPaginationModel] = useState<DataGridPaginationModel>({
        page: 0,
        pageSize: PAGESIZE,
    });
    const [loading, setLoading] = useState<boolean>(false);

    const fetchPosts = useCallback(async () => {
        setLoading(true);
        try {
            const response = await fetch(
                `https://jsonplaceholder.typicode.com/posts?_page=${(paginationModel.page + 1).toString()}&_limit=${paginationModel.pageSize.toString()}`,
            );

            const data = await response.json();
            const totalCount = Number(response.headers.get('X-Total-Count'));

            setDataGridData({
                data,
                totalCount,
            });
        } catch (error) {
            // eslint-disable-next-line no-console
            console.error('Veri çekilirken hata oluştu:', error);
        } finally {
            setLoading(false);
        }
    }, [paginationModel]);

    const columns: DataGridColumnsPropsType = [
        {
            field: 'id',
            headerName: 'No',
            headerAlign: 'center',
            width: 90,
            type: 'number',
        },
        {
            field: 'userId',
            headerName: 'User ID',
            headerAlign: 'center',
            type: 'number',
            width: 90,
        },
        {
            field: 'title',
            headerName: 'Title',
            width: 150,
            flex: 1,
        },
        {
            field: 'body',
            headerName: 'Body',
            width: 150,
            flex: 1,
        },
    ];

    useEffect(() => {
        fetchPosts();
    }, [fetchPosts]);

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - ServerSide' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={dataGridData.data}
                                    columns={columns}
                                    toolbar
                                    pagination
                                    numberPagination
                                    pageSize={paginationModel.pageSize}
                                    pageSizeOptions={sortBy(uniq([PAGESIZE, 10, 15, dataGridData.totalCount]))}
                                    paginationMode="server"
                                    loading={loading}
                                    rowCount={dataGridData.totalCount}
                                    paginationModel={paginationModel}
                                    onPaginationModelChange={setPaginationModel}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridServerSidePaginationPage;
