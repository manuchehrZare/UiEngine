import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import {
    Box,
    Button,
    Checkbox,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    message,
    MessageTypeEnum,
    Nav,
    Paper,
    randomNumber,
    useDataGridApiRef,
    useWatch,
} from '../../../../../lib';
import type { IMeslekItem } from '../data';
import { meslekData, meslekDataNoId } from '../data';
import { v4 as uuidv4 } from 'uuid';

interface IFormValues {
    useId: boolean;
}

const DataGridExamplePage: FC = () => {
    const [data, setData] = useState<IMeslekItem[]>([]);
    const [selectedItem, setSelectedItem] = useState<IMeslekItem | null>(null);
    const apiRef = useDataGridApiRef();

    const { control } = useForm<IFormValues>({
        defaultValues: {
            useId: true,
        },
    });
    const useIdWatch = useWatch({ control, fieldName: 'useId' });

    const getTodos = () => {
        setData([...(useIdWatch ? meslekData : meslekDataNoId)]);
    };

    const deleteItem = () => {
        if (selectedItem) {
            setData(data?.filter((row) => row.oid !== selectedItem.oid));
            message({ variant: MessageTypeEnum.success, message: 'Silindi.' });
        } else message({ variant: MessageTypeEnum.error, message: 'Seçim yapınız.' });
        setSelectedItem(null);
        apiRef.current.setRowSelectionModel([]);
    };

    const addItem = () => {
        const rndNumber = randomNumber(6, 55);
        const uid = uuidv4();
        setData((prev) => [
            ...prev,
            {
                ...(useIdWatch && { id: uid }),
                oid: uid,
                jobCode: `${rndNumber}`,
                jobName: `Job ${rndNumber}`,
                occpCode: `${rndNumber}`,
            },
        ]);

        setTimeout(() => {
            apiRef.current.scrollToIndexes({
                rowIndex: apiRef.current.getRowsCount() - 1,
            });
        });
    };

    useEffect(() => {
        getTodos();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [useIdWatch]);

    useEffect(() => {
        // eslint-disable-next-line no-console
        console.log('selectedItem', selectedItem);
    }, [selectedItem]);

    useEffect(() => {
        // eslint-disable-next-line no-console
        console.log('data', data);
    }, [data]);

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Example' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Checkbox control={control} name="useId" label="Id'li data kullan" />
                            </GridItem>
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem
                                        sm={9}
                                        sx={{
                                            height: 300,
                                            width: '100%',
                                        }}>
                                        <DataGrid
                                            sx={{
                                                '.orange': {
                                                    backgroundColor: '#ff943975 !important',
                                                    color: '#1a3e72',
                                                },
                                            }}
                                            getRowClassName={(params: any) => {
                                                // // eslint-disable-next-line no-console
                                                // console.log('params', params);
                                                if (params?.row?.occpCode === '04') {
                                                    return 'orange';
                                                }
                                                return '';
                                            }}
                                            apiRef={apiRef}
                                            checkboxSelection
                                            disableMultipleRowSelection
                                            columns={[
                                                {
                                                    field: 'no',
                                                    headerName: 'No',
                                                    type: DataGridColumnTypeEnum.counter,
                                                    headerAlign: 'center',
                                                    align: 'center',
                                                },
                                                {
                                                    field: 'occpCode',
                                                    headerName: 'Çalışma Şekli Kodu',
                                                    headerAlign: 'center',
                                                    flex: 1,
                                                },
                                                {
                                                    field: 'jobName',
                                                    headerName: 'Meslek Kodu',
                                                    headerAlign: 'center',
                                                    flex: 1,
                                                },
                                            ]}
                                            rows={data}
                                            selectionOnClickable
                                            onSelectChange={(params) => {
                                                // eslint-disable-next-line no-console
                                                console.log('onSelectChange', params);
                                                setSelectedItem(params.row);
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem sm={3}>
                                        <Grid spacingType="button">
                                            <GridItem>
                                                <Button
                                                    text="Ekle"
                                                    fullWidth
                                                    onClick={() => {
                                                        addItem();
                                                    }}
                                                />
                                            </GridItem>
                                            <GridItem>
                                                <Button text="Sil" color="error" fullWidth onClick={deleteItem} />
                                            </GridItem>
                                            <GridItem>
                                                <Button
                                                    text="Go index 12"
                                                    variant="outlined"
                                                    fullWidth
                                                    onClick={() => {
                                                        apiRef.current.scrollToIndexes({
                                                            rowIndex: 12 + 4,
                                                        });
                                                    }}
                                                />
                                            </GridItem>
                                        </Grid>
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridExamplePage;
