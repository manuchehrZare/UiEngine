import type { FC } from 'react';
import { useCallback, useEffect, useState } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import { Box, Grid, GridItem, Paper, DataGrid, Nav, DataGridColumnTypeEnum } from '../../../../../lib';

interface IData {
    body: string;
    id: number;
    title: string;
    userId: number;
}

const DataGridVirtualizationPage: FC = () => {
    const PAGE_SIZE = 20;
    const INITIAL_PAGE_NUMBER = 1;
    const [rows, setRows] = useState<IData[]>([]);
    const [page, setPage] = useState(INITIAL_PAGE_NUMBER);
    const [loading, setLoading] = useState<boolean>(false);
    const [hasMore, setHasMore] = useState(true);

    const fetchPosts = useCallback(
        async (pageToLoad: number) => {
            if (loading || !hasMore) return;

            setLoading(true);
            try {
                const response = await fetch(
                    `https://jsonplaceholder.typicode.com/posts?_page=${pageToLoad}&_limit=${PAGE_SIZE}`,
                );
                const data: IData[] = await response.json();
                const totalCount = Number(response.headers.get('X-Total-Count'));

                setRows((prev) => [...prev, ...data]);
                setPage(pageToLoad);

                if (data.length < PAGE_SIZE || pageToLoad * PAGE_SIZE >= totalCount) {
                    setHasMore(false);
                }
            } catch (error) {
                // eslint-disable-next-line no-console
                console.error('Veri çekilirken hata oluştu:', error);
            } finally {
                setLoading(false);
            }
        },
        [loading, hasMore],
    );

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            headerAlign: 'center',
            width: 90,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'id',
            headerName: 'ID',
            headerAlign: 'center',
            type: 'number',
            width: 90,
        },
        {
            field: 'userId',
            headerName: 'User ID',
            headerAlign: 'center',
            type: 'number',
            width: 90,
        },
        {
            field: 'title',
            headerName: 'Title',
            width: 150,
            flex: 1,
        },
        {
            field: 'body',
            headerName: 'Body',
            width: 150,
            flex: 1,
        },
    ];

    useEffect(() => {
        fetchPosts(INITIAL_PAGE_NUMBER);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Data Grid - Virtualization' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    toolbar
                                    columns={columns}
                                    rows={rows}
                                    loading={loading}
                                    onRowsScrollEnd={() => {
                                        if (!loading && hasMore) {
                                            fetchPosts(page + 1);
                                        }
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridVirtualizationPage;
