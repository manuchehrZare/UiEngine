import type { FC } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import {
    Box,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Nav,
    Paper,
    PhoneNumber,
    getBgColorByClassName,
} from '../../../../../lib';
import { employeesData } from '../data';

const DataGridExamplePage: FC = () => {
    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
            headerAlign: 'center',
            align: 'center',
        },
        {
            field: 'userId',
            headerName: 'Kullanıcı Adı',
            headerAlign: 'center',
        },
        {
            field: 'jobTitleName',
            headerName: 'Meslek',
            headerAlign: 'center',
        },
        {
            field: 'firstName',
            headerName: 'Ad',
            headerAlign: 'center',
        },
        {
            field: 'lastName',
            headerName: 'Soyad',
            headerAlign: 'center',
        },
        {
            field: 'preferredFullName',
            headerName: 'Tam Ad',
            headerAlign: 'center',
        },
        {
            field: 'age',
            headerName: 'Yaş',
            headerAlign: 'center',
        },
        {
            field: 'employeeCode',
            headerName: 'Çalışan Kodu',
            headerAlign: 'center',
        },
        {
            field: 'region',
            headerName: 'Bölge',
            headerAlign: 'center',
        },
        {
            field: 'phoneNumber',
            headerName: 'Telefon Numarası',
            headerAlign: 'center',
            renderCell: (params) => <PhoneNumber component="NumberFormat" value={params.value} />,
        },
        {
            field: 'emailAddress',
            headerName: 'Email',
            headerAlign: 'center',
        },
    ];

    return (
        <Grid spacing={1}>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Row' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sm={9} sx={{ height: 300 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            sx={{
                                                ...getBgColorByClassName({
                                                    className: 'error',
                                                    bgColor: 'error',
                                                }),
                                                ...getBgColorByClassName({
                                                    className: 'warning',
                                                    bgColor: 'warning',
                                                    flashing: true,
                                                }),
                                            }}
                                            getRowClassName={(params: any) => {
                                                if (Number(params?.row?.age) >= 35) {
                                                    return 'error';
                                                }
                                                if (Number(params?.row?.age) === 22) {
                                                    return 'warning';
                                                }
                                                return '';
                                            }}
                                            selectionOnClickable
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem>
                <Paper>
                    <Nav navTitleProps={{ title: 'Cell' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sm={9} sx={{ height: 300 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            sx={{
                                                ...getBgColorByClassName({
                                                    className: 'error',
                                                    bgColor: 'error',
                                                }),
                                                ...getBgColorByClassName({
                                                    className: 'warning',
                                                    bgColor: 'warning',
                                                    flashing: true,
                                                }),
                                                ...getBgColorByClassName({
                                                    className: 'info',
                                                    bgColor: 'info',
                                                }),
                                                '.analist': {
                                                    '.MuiDataGrid-cellContent': {
                                                        color: (theme) => theme.palette.error.main,
                                                    },
                                                },
                                            }}
                                            getRowClassName={(params: any) => {
                                                if (Number(params?.row?.age) >= 35) {
                                                    return 'error';
                                                }
                                                if (Number(params?.row?.age) === 22) {
                                                    return 'warning';
                                                }
                                                return '';
                                            }}
                                            getCellClassName={(params) => {
                                                if (params?.field === 'region' && params?.formattedValue === 'LA') {
                                                    return 'info';
                                                }
                                                if (
                                                    params?.field === 'jobTitleName' &&
                                                    params?.formattedValue === 'Analist'
                                                ) {
                                                    return 'analist';
                                                }
                                                return '';
                                            }}
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridExamplePage;
