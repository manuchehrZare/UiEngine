import type { FC } from 'react';
import { useState } from 'react';
import type { DataGridColumnsPropsType, DataGridFilterItem, DataGridFilterModel } from '../../../../../lib';
import {
    Box,
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Divider,
    getDataGridStringOperators,
    Grid,
    GridItem,
    Input,
    Label,
    Nav,
    Paper,
    Select,
    useForm,
    useDataGridApiRef,
} from '../../../../../lib';

interface IData {
    abbreviation?: string;
    age: number | null;
    budget?: string;
    date?: Date;
    firstName: string | null;
    id: number;
    lastName: string;
}

const DataGridFilter: FC = () => {
    const apiRef = useDataGridApiRef();

    const rowsData1: IData[] = [
        { id: 1, lastName: 'Snow', firstName: 'Jon', abbreviation: 'JS', age: 35, budget: '10000' },
        { id: 2, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '20000' },
        { id: 2, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '77777' },
        { id: 2, lastName: 'Lannister', firstName: 'Cersei', abbreviation: 'CL', age: 42, budget: '7777' },
        { id: 3, lastName: 'Lannister', firstName: 'Jaime', abbreviation: 'JL', age: 45, budget: '30000' },
        { id: 4, lastName: 'Stark', firstName: 'Arya', age: 16, abbreviation: 'AS', budget: '15000' },
        { id: 5, lastName: 'Targaryen', firstName: 'Daenerys', abbreviation: 'DT', age: null, budget: '10000.75' },
        { id: 6, lastName: 'Melisandre', firstName: null, abbreviation: 'M', age: 150, budget: '123123.123' },
        { id: 7, lastName: 'Clifford', firstName: 'Ferrara', abbreviation: 'FC', age: 44, budget: '500000' },
        { id: 8, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '200000' },
        { id: 8, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '0' },
        { id: 8, lastName: 'Frances', firstName: 'Rossini', abbreviation: 'RF', age: 36, budget: '' },
        { id: 9, lastName: 'Roxie', firstName: 'Harvey', abbreviation: 'HR', age: 65 },
    ];

    const { control, handleSubmit, reset, setValue, getValues } = useForm<any>({
        defaultValues: {
            firstName: '',
            firstNameOperator: 'contains',
            lastName: '',
            lastNameOperator: 'contains',
            searchField: '',
        },
        validationSchema: {},
    });

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            width: 90,
            editable: true,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'firstName',
            headerName: 'First name',
            width: 150,
            minWidth: 150,
            maxWidth: 200,
            description: 'The identification used by the person with access to the online service.',
            flex: 1,
            type: '',
            align: 'right',
            headerAlign: 'right',
            disableColumnMenu: true,
            editable: true,
            sortable: true,
            sortingOrder: ['desc', 'asc', null],
        },
        {
            field: 'lastName',
            headerName: 'Last nameeeeee',
            width: 150,
            editable: true,
            renderCell: (params) => {
                return (
                    <Box
                        component="div"
                        sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            width: '100%',
                        }}>
                        <Label
                            text={params.value}
                            className="MuiDataGrid-cellContent"
                            color="common.black"
                            fontWeight={400}
                        />
                    </Box>
                );
            },
        },
        {
            field: 'abbreviation',
            headerName: 'Abbreviation',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.abbreviation,
            filterable: false,
        },
        {
            field: 'age',
            headerName: 'Age',
            headerAlign: 'center',
            type: 'number',
            width: 110,
            editable: true,
            sortable: false,
        },
        {
            field: 'date',
            headerName: 'Date',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.date,
            editable: true,
            flex: 1,
        },
        {
            field: 'budget',
            headerName: 'Budget',
            headerAlign: 'center',
            minWidth: 100,
            type: DataGridColumnTypeEnum.currency,
            editable: true,
            flex: 1,
        },
    ];

    const defaultItems: DataGridFilterItem[] = [
        { id: 1, field: 'age', operator: '>', value: 15 },
        { id: 2, field: 'firstName', operator: 'contains', value: '' },
        { id: 3, field: 'lastName', operator: 'contains', value: '' },
    ];

    const defaultQuickFilterValue: string[] = [''];

    const [gridFilterModel, setGridFilterModel] = useState<DataGridFilterModel>({
        items: defaultItems,
        quickFilterValues: defaultQuickFilterValue,
    });

    const handleReset = (type?: string) => {
        // to reset separating filter form
        if (type === 'seperate') {
            reset();
            setGridFilterModel((prevModel) => {
                return {
                    ...prevModel,
                    items: defaultItems,
                };
            });
        } else {
            //to reset searchField
            setValue('searchField', '');
            setGridFilterModel((prevModel) => {
                return {
                    ...prevModel,
                    quickFilterValues: defaultQuickFilterValue,
                };
            });
        }
    };

    const seperateOnSubmit = (data: any) => {
        let newFilterItems: DataGridFilterItem[] = [...gridFilterModel.items];
        const formFields = Object.keys(control._defaultValues);

        //search formfields and operator to make filter model
        formFields.forEach((key, i) => {
            if (data[key] && key !== 'serachField') {
                if (!key.endsWith('Operator')) {
                    const operatorKey = `${key}Operator`;

                    const existingFirstNameFilter = newFilterItems.find((item) => item.field === key);
                    if (existingFirstNameFilter) {
                        existingFirstNameFilter.operator = data[operatorKey];
                        existingFirstNameFilter.value = data[key];
                    } else {
                        newFilterItems.push({
                            id: i,
                            field: key,
                            operator: data[operatorKey] || 'contains',
                            value: data[key],
                        });
                    }
                }
            } else {
                newFilterItems = newFilterItems.filter((item) => item.field !== key);
            }
        });
        if (data?.searchField && typeof data.searchField === 'string') {
            setGridFilterModel((prevModel) => {
                return {
                    ...prevModel,
                    quickFilterValues: data.searchField.length > 0 ? data.searchField.trim().split(/\s+/) : [''],
                };
            });
        }
        setGridFilterModel((prevModel) => {
            return {
                ...prevModel, // Spread the previous model to retain other values
                items: newFilterItems, // Update the 'items' part of the model
            };
        });
    };

    const filterChange = (newFilterModel: any) => {
        setGridFilterModel(newFilterModel);
        // Grid'in kendi quick filter'ı değişirse input'u güncelle
        if (newFilterModel.quickFilterValues !== getValues('searchField')) {
            setValue('searchField', newFilterModel.quickFilterValues || '');
        }
    };

    return (
        <Grid>
            <GridItem>
                <Paper>
                    <form onSubmit={handleSubmit(seperateOnSubmit)}>
                        <GridItem p={2}>
                            <Nav navTitleProps={{ title: 'Data Grid - Filter By Column ' }} />
                            <Grid rowGap={2}>
                                <GridItem>
                                    <Grid gap={3} columnGap={2}>
                                        <GridItem xs>
                                            <Input label="FirstName" name="firstName" control={control} />
                                        </GridItem>
                                        <GridItem xs>
                                            <Select
                                                label="Operator"
                                                name="firstNameOperator"
                                                options={{
                                                    data: getDataGridStringOperators(),
                                                    displayField: 'value',
                                                    displayValue: 'value',
                                                }}
                                                displayEmpty
                                                control={control}
                                                setValue={setValue}
                                            />
                                        </GridItem>
                                        <GridItem xs>
                                            <Input label="lastName" name="lastName" control={control} />
                                        </GridItem>
                                        <GridItem xs>
                                            <Select
                                                label="Operator"
                                                name="lastNameOperator"
                                                options={{
                                                    data: getDataGridStringOperators(),
                                                    displayField: 'value',
                                                    displayValue: 'value',
                                                }}
                                                displayEmpty
                                                control={control}
                                                setValue={setValue}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Button type="submit" text="Filter" sx={{ mr: 4 }} />
                                    <Button text="Reset" onClick={() => handleReset('seperate')} />
                                </GridItem>
                            </Grid>
                            <Divider sx={{ margin: 2 }} />
                            <Nav navTitleProps={{ title: 'Data Grid - Quick Filter ' }} />
                            <Grid rowGap={2}>
                                <GridItem>
                                    <Grid gap={3} columnGap={2}>
                                        <GridItem xs={12}>
                                            <Input label="searchField" name="searchField" control={control} />
                                        </GridItem>
                                        <GridItem xs>
                                            <Button type="submit" text="Filter" sx={{ mr: 4 }} />
                                            <Button text="Reset" onClick={handleReset} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </GridItem>
                    </form>
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <DataGrid
                                    sx={{ height: 300 }}
                                    rows={rowsData1}
                                    columns={columns}
                                    apiRef={apiRef}
                                    toolbar
                                    onEditChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('params', params);
                                    }}
                                    toolbarProps={{
                                        fileOptions: {
                                            export: undefined,
                                            import: undefined,
                                        },
                                        showQuickFilter: true,
                                    }}
                                    selectionOnClickable
                                    onSelectChange={(params) => {
                                        // eslint-disable-next-line no-console
                                        console.log('onSelectChange params', params);
                                    }}
                                    filterModel={gridFilterModel}
                                    onFilterModelChange={(newFilterModel) => filterChange(newFilterModel)}
                                />
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridFilter;
