export interface IExampleData {
    age: number;
    bool?: boolean;
    currency?: string;
    fullName: string;
    id?: string | number;
}

export interface IMeslekItem {
    id?: string;
    jobCode: string | null;
    jobName: string | null;
    occpCode: string | null;
    oid: string;
}

export interface IEmployee {
    age: string;
    emailAddress: string;
    employeeCode: string;
    firstName: string;
    jobTitleName: string;
    lastName: string;
    phoneNumber: string;
    preferredFullName: string;
    region: string;
    userId: string;
}

export interface ICustomData {
    cell1: string;
    cell2: string;
}

export const rowsExample: IExampleData[] = [
    {
        id: 1,
        age: 25,
        fullName: 'John Doe',
        bool: false,
        currency: '10000',
    },
    {
        id: 2,
        age: 32,
        fullName: 'Jack Sparrow',
        bool: true,
        currency: '20000',
    },
    {
        id: 3,
        age: 29,
        fullName: 'Will Turner',
        bool: false,
        currency: '77777',
    },
    {
        id: 4,
        age: 54,
        fullName: 'Hector Smith',
        bool: false,
        currency: '30000',
    },
    {
        id: 5,
        age: 53,
        fullName: 'Davy Jones',
        bool: false,
        currency: '15000',
    },
    {
        id: 6,
        age: 42,
        fullName: 'Sao Feng',
        bool: false,
        currency: '10000.75',
    },
    {
        id: 7,
        age: 29,
        fullName: 'Elizabeth Swann',
        bool: false,
        currency: '123123.123',
    },
    {
        id: 8,
        age: 47,
        fullName: 'Ragnar Lothbrok',
        bool: true,
        currency: '500000',
    },
    {
        id: 9,
        age: 33,
        fullName: 'Bjorn Ironside',
        bool: false,
        currency: '10000',
    },
    {
        id: 10,
        age: 25,
        fullName: 'Ivar Ragnarsson',
        bool: false,
        currency: '20000',
    },
    {
        id: 11,
        age: 23,
        fullName: 'Tuncay Şanlı',
        bool: true,
        currency: '10000.75',
    },
    {
        id: 12,
        age: 27,
        fullName: 'Volkan Demirel',
        bool: false,
        currency: '500000',
    },
];

export const rowsExampleNoId: IExampleData[] = [
    {
        age: 25,
        fullName: 'John Doe',
        bool: true,
    },
    {
        age: 32,
        fullName: 'Jack Sparrow',
    },
    {
        age: 29,
        fullName: 'Will Turner',
        bool: true,
    },
    {
        age: 54,
        fullName: 'Hector Smith',
    },
    {
        age: 53,
        fullName: 'Davy Jones',
        bool: false,
    },
    {
        age: 42,
        fullName: 'Sao Feng',
    },
    {
        age: 29,
        fullName: 'Elizabeth Swann',
    },
    {
        age: 29,
        fullName: 'Elizabeth Swann',
    },
];

export const meslekData: IMeslekItem[] = [
    {
        id: 'tcvgyygijxfpgdgs',
        oid: 'tcvgyygijxfpgdgs',
        occpCode: '01',
        jobCode: '004',
        jobName: 'Askeri Personel / TSK Mensubu',
    },
    {
        id: 'auvhwcepvdwciuqv',
        oid: 'auvhwcepvdwciuqv',
        occpCode: '01',
        jobCode: '030',
        jobName: 'Diplomat / Büyükelçi',
    },
    { id: 'mjfvgrzdgeamtnbw', oid: 'mjfvgrzdgeamtnbw', occpCode: '01', jobCode: '049', jobName: 'Güvenlik Görevlisi' },
    {
        id: 'meotdogewtyjqlus',
        oid: 'meotdogewtyjqlus',
        occpCode: '01',
        jobCode: '050',
        jobName: 'Hakim / Savcı / Yargıç',
    },
    { id: 'thyassqmotluknev', oid: 'thyassqmotluknev', occpCode: '02', jobCode: '010', jobName: 'Bakkal / Market' },
    { id: 'uixsuqvnpfssxmji', oid: 'uixsuqvnpfssxmji', occpCode: '02', jobCode: '043', jobName: 'Finanscı' },
    { id: 'xvjjamslfrlmsaff', oid: 'xvjjamslfrlmsaff', occpCode: '02', jobCode: '017', jobName: 'Çiçekçi' },
    { id: 'myxwgsbwxpznrlmc', oid: 'myxwgsbwxpznrlmc', occpCode: '04', jobCode: '038', jobName: 'Emlakçı / Eksper' },
    { id: 'srdzsxqwwbmjbjpz', oid: 'srdzsxqwwbmjbjpz', occpCode: '04', jobCode: '042', jobName: 'Fırıncı' },
    { id: 'mgmcwdmubdkylccb', oid: 'mgmcwdmubdkylccb', occpCode: '04', jobCode: '044', jobName: 'Fotoğrafçı' },
    { id: 'illattkiajghbqvk', oid: 'illattkiajghbqvk', occpCode: '04', jobCode: '045', jobName: 'Gazete / Loto Bayii' },
    { id: 'vmqoozwuunxdztyf', oid: 'vmqoozwuunxdztyf', occpCode: '04', jobCode: '046', jobName: 'Gazeteci' },
    { id: '6e2posl5rsqw4i00', oid: '6e2posl5rsqw4i00', occpCode: null, jobCode: null, jobName: null },
    { id: '6e2posl5rsqw4k00', oid: '6e2posl5rsqw4k00', occpCode: null, jobCode: null, jobName: null },
    { id: '6e2posl5rsqw4t00', oid: '6e2posl5rsqw4t00', occpCode: null, jobCode: null, jobName: null },
    { id: '6e2qnel5rsrej600', oid: '6e2qnel5rsrej600', occpCode: '01', jobCode: '033', jobName: 'Doktor' },
    { id: '6e2qnel5rsrev500', oid: '6e2qnel5rsrev500', occpCode: null, jobCode: null, jobName: null },
    { id: '6e2posl5rssace00', oid: '6e2posl5rssace00', occpCode: null, jobCode: null, jobName: null },
    { id: '6e0ioal3k2h8fb00', oid: '6e0ioal3k2h8fb00', occpCode: '03', jobCode: '001', jobName: 'Akademisyen' },
    {
        id: '6e07ntl4zgwb9g00',
        oid: '6e07ntl4zgwb9g00',
        occpCode: '01',
        jobCode: '002',
        jobName: 'Anahtarcı / Çilingir',
    },
    { id: '6d1snil59me3nd00', oid: '6d1snil59me3nd00', occpCode: null, jobCode: null, jobName: null },
    { id: '6e1q53l5arz3i400', oid: '6e1q53l5arz3i400', occpCode: '01', jobCode: '043', jobName: 'Finanscı' },
    { id: '6d0tk6l5as1xrc00', oid: '6d0tk6l5as1xrc00', occpCode: null, jobCode: null, jobName: null },
    { id: '6d1yapl38m5xkd00', oid: '6d1yapl38m5xkd00', occpCode: '05', jobCode: '001', jobName: 'Akademisyen' },
    { id: '6e24vwl56v8cm500', oid: '6e24vwl56v8cm500', occpCode: '01', jobCode: '998', jobName: 'Öğrenci' },
];

export const meslekDataNoId: IMeslekItem[] = [
    { oid: 'tcvgyygijxfpgdgs', occpCode: '01', jobCode: '004', jobName: 'Askeri Personel / TSK Mensubu' },
    { oid: 'auvhwcepvdwciuqv', occpCode: '01', jobCode: '030', jobName: 'Diplomat / Büyükelçi' },
    { oid: 'mjfvgrzdgeamtnbw', occpCode: '01', jobCode: '049', jobName: 'Güvenlik Görevlisi' },
    { oid: 'meotdogewtyjqlus', occpCode: '01', jobCode: '050', jobName: 'Hakim / Savcı / Yargıç' },
    { oid: 'thyassqmotluknev', occpCode: '02', jobCode: '010', jobName: 'Bakkal / Market' },
    { oid: 'uixsuqvnpfssxmji', occpCode: '02', jobCode: '043', jobName: 'Finanscı' },
    { oid: 'xvjjamslfrlmsaff', occpCode: '02', jobCode: '017', jobName: 'Çiçekçi' },
    { oid: 'myxwgsbwxpznrlmc', occpCode: '04', jobCode: '038', jobName: 'Emlakçı / Eksper' },
    { oid: 'srdzsxqwwbmjbjpz', occpCode: '04', jobCode: '042', jobName: 'Fırıncı' },
    { oid: 'mgmcwdmubdkylccb', occpCode: '04', jobCode: '044', jobName: 'Fotoğrafçı' },
    { oid: 'illattkiajghbqvk', occpCode: '04', jobCode: '045', jobName: 'Gazete / Loto Bayii' },
    { oid: 'vmqoozwuunxdztyf', occpCode: '04', jobCode: '046', jobName: 'Gazeteci' },
    { oid: '6e2posl5rsqw4i00', occpCode: null, jobCode: null, jobName: null },
    { oid: '6e2posl5rsqw4k00', occpCode: null, jobCode: null, jobName: null },
    { oid: '6e2posl5rsqw4t00', occpCode: null, jobCode: null, jobName: null },
    { oid: '6e2qnel5rsrej600', occpCode: '01', jobCode: '033', jobName: 'Doktor' },
    { oid: '6e2qnel5rsrev500', occpCode: null, jobCode: null, jobName: null },
    { oid: '6e2posl5rssace00', occpCode: null, jobCode: null, jobName: null },
    { oid: '6e0ioal3k2h8fb00', occpCode: '03', jobCode: '001', jobName: 'Akademisyen' },
    { oid: '6e07ntl4zgwb9g00', occpCode: '01', jobCode: '002', jobName: 'Anahtarcı / Çilingir' },
    { oid: '6d1snil59me3nd00', occpCode: null, jobCode: null, jobName: null },
    { oid: '6e1q53l5arz3i400', occpCode: '01', jobCode: '043', jobName: 'Finanscı' },
    { oid: '6d0tk6l5as1xrc00', occpCode: null, jobCode: null, jobName: null },
    { oid: '6d1yapl38m5xkd00', occpCode: '05', jobCode: '001', jobName: 'Akademisyen' },
    { oid: '6e24vwl56v8cm500', occpCode: '01', jobCode: '998', jobName: 'Öğrenci' },
];

export const employeesData: IEmployee[] = [
    {
        userId: 'rirani',
        jobTitleName: 'Developer',
        firstName: 'Romin',
        lastName: 'Irani',
        preferredFullName: 'Romin Irani',
        age: '22',
        employeeCode: 'E1',
        region: 'CA',
        phoneNumber: '408-1234567',
        emailAddress: 'romin.k.irani@gmail.com',
    },
    {
        userId: 'nirani',
        jobTitleName: 'Developer',
        firstName: 'Neil',
        lastName: 'Irani',
        preferredFullName: 'Neil Irani',
        age: '33',
        employeeCode: 'E2',
        region: 'CA',
        phoneNumber: '408-1234545',
        emailAddress: 'neilrirani@gmail.com',
    },
    {
        userId: 'thanks',
        jobTitleName: 'Program Directory',
        firstName: 'Tom',
        lastName: 'Hanks',
        preferredFullName: 'Tom Hanks',
        age: '45',
        employeeCode: 'E3',
        region: 'CA',
        phoneNumber: '408-2345656',
        emailAddress: 'tomhanks@gmail.com',
    },
    {
        userId: 'randommman',
        jobTitleName: 'Analist',
        firstName: 'Thierry',
        lastName: 'Henry',
        preferredFullName: 'Thierry Henry',
        age: '30',
        employeeCode: 'E4',
        region: 'LA',
        phoneNumber: '408-5678989',
        emailAddress: 't_henrry@gmail.com',
    },
    {
        userId: 'aliveli',
        jobTitleName: 'Developer',
        firstName: 'Ali',
        lastName: 'Veli',
        preferredFullName: 'Ali Veli',
        age: '20',
        employeeCode: 'E5',
        region: 'LA',
        phoneNumber: '402-2345656',
        emailAddress: 'a_veliy@gmail.com',
    },
    {
        userId: 'aysefatma',
        jobTitleName: 'Developer',
        firstName: 'Ayse',
        lastName: 'Fatma',
        preferredFullName: 'Ayse Fatma',
        age: '24',
        employeeCode: 'E6',
        region: 'CA',
        phoneNumber: '202-1234545',
        emailAddress: 'aysefatma@gmail.com',
    },
];

export const customData: ICustomData[] = [
    {
        cell1: '2013-51',
        cell2: '28',
    },
    {
        cell1: '2013-48',
        cell2: '13',
    },
    {
        cell1: '2013-4',
        cell2: '02',
    },
    {
        cell1: '2013-52',
        cell2: '18',
    },
    {
        cell1: '2013-56',
        cell2: '34',
    },
    {
        cell1: '2013-45',
        cell2: '33',
    },
    {
        cell1: '2013-59',
        cell2: '25',
    },
    {
        cell1: '2013-7',
        cell2: '20',
    },
    {
        cell1: '2012-89',
        cell2: '10',
    },
    {
        cell1: '2013-98',
        cell2: '45',
    },
    {
        cell1: '2012-76',
        cell2: '123',
    },
    {
        cell1: '2013-40',
        cell2: '1234',
    },
    {
        cell1: '2013-23',
        cell2: '12345',
    },
];
