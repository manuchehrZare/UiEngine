import type { FC } from 'react';
import type { DataGridColumnsPropsType } from '../../../../../lib';
import { Box, DataGrid, DataGridColumnTypeEnum, Grid, GridItem, Nav, Paper } from '../../../../../lib';
import { employeesData } from '../data';

const DataGridExamplePage: FC = () => {
    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: 'No',
            type: DataGridColumnTypeEnum.counter,
            headerAlign: 'center',
            align: 'center',
        },
        {
            field: 'userId',
            headerName: 'Kullanıcı Adı',
            headerAlign: 'center',
        },
        {
            field: 'jobTitleName',
            headerName: 'Meslek',
            headerAlign: 'center',
        },
        {
            field: 'firstName',
            headerName: 'Ad',
            headerAlign: 'center',
        },
        {
            field: 'lastName',
            headerName: 'Soyad',
            headerAlign: 'center',
        },
        {
            field: 'preferredFullName',
            headerName: 'Tam Ad',
            headerAlign: 'center',
        },
        {
            field: 'age',
            headerName: 'Yaş',
            headerAlign: 'center',
        },
        {
            field: 'employeeCode',
            headerName: 'Çalışan Kodu',
            headerAlign: 'center',
        },
        {
            field: 'region',
            headerName: 'Bölge',
            headerAlign: 'center',
        },
        {
            field: 'phoneNumber',
            headerName: 'Telefon Numarası',
            headerAlign: 'center',
        },
        {
            field: 'emailAddress',
            headerName: 'Email',
            headerAlign: 'center',
        },
    ];

    return (
        <Grid spacing={1}>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Pinned Column - right' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 200 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            initialState={{
                                                pinnedColumns: { right: ['emailAddress'] },
                                            }}
                                            // unpinCounterColumn
                                            // pinnedColumns={{ left: ['firstName'], right: ['emailAddress'] }}
                                            selectionOnClickable
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Pinned Column - left' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 200 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            // initialState={{ pinnedColumns: { right: ['emailAddress'] } }}
                                            pinnedColumns={{ left: ['firstName'] }}
                                            // unpinCounterColumn
                                            selectionOnClickable
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Pinned Row - bottom' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 200 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            pinnedRows={{
                                                bottom: [
                                                    {
                                                        userId: 'Test User',
                                                        jobTitleName: 'Job 1',
                                                        age: 174,
                                                    },
                                                ],
                                            }}
                                            selectionOnClickable
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
            <GridItem md={6}>
                <Paper>
                    <Nav navTitleProps={{ title: 'Pinned Row - top' }} />
                    <Box p={1}>
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="common">
                                    <GridItem sx={{ height: 200 }}>
                                        <DataGrid
                                            rows={employeesData}
                                            columns={columns}
                                            pinnedRows={{
                                                top: [
                                                    {
                                                        userId: 'Test User 1',
                                                        jobTitleName: 'Job 1',
                                                        age: 174,
                                                    },
                                                    {
                                                        userId: 'Test User 2',
                                                        jobTitleName: 'Job 2',
                                                        ages: 112,
                                                    },
                                                ],
                                            }}
                                            selectionOnClickable
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Box>
                </Paper>
            </GridItem>
        </Grid>
    );
};

export default DataGridExamplePage;
