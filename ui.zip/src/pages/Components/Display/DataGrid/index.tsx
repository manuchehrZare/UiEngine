import type { FC } from 'react';
import { Children, useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Tab, TabItem, View } from '../../../../lib';
import Basic from './Basic';
import Example from './Example';
import Example2 from './Example2';
import Example3 from './Example3';
import RowAndCellCSS from './RowAndCellCSS';
import Editable from './Editable';
import Selection from './Selection';
import Pinned from './Pinned';
import Sortable from './Sortable';
import CollapseRow from './CollapseRow';
import Filter from './Filter';
import Pagination from './Pagination';
import DataGridCheckbox from './Checkbox';
import DataGridAutoCompletePage from './Autocomplete';
import ServerSidePagination from './ServerSidePagination';
import Virtualization from './Virtualization';

const DataGridPage: FC = () => {
    const tabs = [
        { title: 'Virtualization', element: <Virtualization /> },
        { title: 'Basic', element: <Basic /> },
        { title: 'Example', element: <Example /> },
        { title: 'Example2', element: <Example2 /> },
        { title: 'Example3', element: <Example3 /> },
        { title: 'Row and Cell CSS', element: <RowAndCellCSS /> },
        { title: 'Editable', element: <Editable /> },
        { title: 'Selection', element: <Selection /> },
        { title: 'Pinned', element: <Pinned /> },
        { title: 'Sortable', element: <Sortable /> },
        { title: 'Collapse Row', element: <CollapseRow /> },
        { title: 'Filter', element: <Filter /> },
        { title: 'Pagination', element: <Pagination /> },
        { title: 'ServerSidePagination', element: <ServerSidePagination /> },
        { title: 'Checkbox', element: <DataGridCheckbox /> },
        { title: 'Autocomplete', element: <DataGridAutoCompletePage /> },
    ];

    const [activeTab, setActiveTab] = useState<number>(0);

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Tab small value={activeTab} onChange={(val) => setActiveTab(val)}>
                        {Children.toArray(tabs.map((item, index) => <TabItem text={item.title} value={index} />))}
                    </Tab>
                </GridItem>
                <GridItem>
                    {Children.toArray(
                        tabs.map((item, index) => (
                            <View show={activeTab === index}>
                                <Box pt={0.5}>{item.element}</Box>
                            </View>
                        )),
                    )}
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default DataGridPage;
