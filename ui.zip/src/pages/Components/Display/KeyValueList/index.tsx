import type { FC } from 'react';
import { Layout } from '../../../../App';
import {
    Box,
    DesignTypeEnum,
    Grid,
    GridItem,
    KeyValueList,
    Nav,
    Paper,
    Rating,
    Switch,
    useForm,
} from '../../../../lib';

interface IFormValues {
    switch: boolean;
}

const KeyValueListPage: FC = () => {
    const { control } = useForm<IFormValues>({
        defaultValues: {
            switch: false,
        },
    });
    return (
        <Layout>
            <Grid p={1} spacing={2}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'KeyValueList' }} />
                        <KeyValueList
                            // wrap
                            sx={{
                                '.sekerUI-Switch-formControl': {
                                    '&.switch-labelPlacement-end': {
                                        '.sekerUI-Switch-label': {
                                            height: '15px !important',
                                            ml: 'auto !important',
                                            mr: 0,
                                        },
                                    },
                                },
                            }}
                            data={[
                                { text: 'Text', value: 'Value' },
                                { text: 'Text', value: 'Value' },
                                {
                                    text: 'Text',
                                    value: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).",
                                },
                                {
                                    text: <Box>Text</Box>,
                                    value: (
                                        <Switch
                                            control={control}
                                            name="switch"
                                            sx={{
                                                ml: 'auto',
                                            }}
                                        />
                                    ),
                                },
                                { text: 'Text', value: 'Value', wrap: true },
                            ]}
                        />
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'KeyValueList' }} />
                        <KeyValueList
                            // wrap
                            data={[
                                { text: 'Text', value: 'Value' },
                                { text: 'Text', value: 'Value' },
                                {
                                    text: 'Text',
                                    value: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).",
                                },
                                { text: 'Text', value: 'Value' },
                                { text: 'Text', value: 'Value', wrap: true },
                                {
                                    text: 'Text',
                                    value: (
                                        <Rating
                                            design={DesignTypeEnum.SET}
                                            name="rating"
                                            precision={0.1}
                                            defaultValue={3.3}
                                        />
                                    ),
                                },
                                { text: 'Text', value: '' },
                            ]}
                        />
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default KeyValueListPage;
