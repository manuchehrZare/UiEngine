import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, ConfirmModal, Button, Nav, generateClass } from '../../../../lib';

const ConfirmPage: FC = () => {
    const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
    const [customConfirmOpen, setCustomConfirmOpen] = useState<boolean>(false);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Confirm' }} />
                        <Box sx={{ p: 2 }}>
                            <Grid spacingType="button">
                                <GridItem sm="auto">
                                    <Button
                                        text="Open Confirm Modal"
                                        onClick={() => {
                                            setConfirmOpen(true);
                                        }}
                                    />
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="Custom Style Confirm Modal"
                                        onClick={() => {
                                            setCustomConfirmOpen(true);
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <ConfirmModal
                // actionProps={{
                //     cancelProps: {
                //         className: '123',
                //     },
                //     okProps: {
                //         className: '456',
                //     },
                //     cancelGridItemProps: {
                //         xs: 4,
                //     },
                //     okGridItemProps: {
                //         xs: 8,
                //     },
                //     gridProps: {
                //         spacing: 4,
                //     },
                // }}
                // loading
                // actionDirection="row-reverse"
                // cancelText="Vazgeç"
                // okText="Kabul"
                title="Confirm Modal"
                body="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cum inventore dolor facilis sed eos voluptas maxime quam quidem dolore harum officiis veritatis reprehenderit iure sequi nesciunt, odit quibusdam delectus atque!
                                Enim, beatae iure officia, fugit exercitationem animi atque voluptatum cupiditate perspiciatis dignissimos porro voluptatibus, soluta molestiae. Fuga officiis aut repellat, perspiciatis incidunt facilis maxime itaque id voluptatum facere exercitationem."
                onClose={() => {
                    // eslint-disable-next-line no-console
                    console.log('confirm closed');
                }}
                onConfirm={(status) => {
                    // eslint-disable-next-line no-console
                    console.log('confirm Status', status);
                    setConfirmOpen(false);
                }}
                show={confirmOpen}
            />
            <ConfirmModal
                modalFooterProps={{
                    sx: {
                        background: (theme) => theme.palette.grey[50],
                        justifyContent: 'right',
                        [`.${generateClass('Grid')}`]: { flexDirection: 'row !important' },
                    },
                }}
                modalTitleProps={{
                    sx: {
                        background: (theme) => theme.palette.grey[50],
                        justifyContent: 'left',
                    },
                }}
                modalBodyProps={{
                    sx: {
                        fontWeight: 600,
                        [`.${generateClass('Grid')}`]: { textAlign: 'left !important' },
                    },
                    dividers: true,
                }}
                title="Confirm Modal"
                body="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cum inventore dolor facilis sed eos voluptas maxime quam quidem dolore harum officiis veritatis reprehenderit iure sequi nesciunt, odit quibusdam delectus atque!
                                Enim, beatae iure officia, fugit exercitationem animi atque voluptatum cupiditate perspiciatis dignissimos porro voluptatibus, soluta molestiae. Fuga officiis aut repellat, perspiciatis incidunt facilis maxime itaque id voluptatum facere exercitationem."
                onClose={() => {
                    // eslint-disable-next-line no-console
                    console.log('confirm closed');
                }}
                onConfirm={(status) => {
                    // eslint-disable-next-line no-console
                    console.log('confirm Status', status);
                    setCustomConfirmOpen(false);
                }}
                show={customConfirmOpen}
            />
        </Layout>
    );
};

export default ConfirmPage;
