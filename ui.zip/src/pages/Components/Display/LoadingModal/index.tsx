import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, LoadingModal, Button, View, hideLoading, showLoading, Nav } from '../../../../lib';

const LoadingModalPage: FC = () => {
    const [show, setShow] = useState<boolean>(false);
    const id = 'app-loading';
    const time = 3000;

    useEffect(() => {
        const timer = setTimeout(() => {
            setShow(false);
        }, time);
        return () => {
            clearTimeout(timer);
        };
    }, [show]);

    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LoadingModal with hidden attribute' }} />
                        <Box sx={{ p: 3 }}>
                            <Button
                                text="Start Loading"
                                onClick={() => {
                                    showLoading(id);
                                    setTimeout(() => {
                                        hideLoading(id);
                                    }, time);
                                }}
                            />
                            <LoadingModal id={id} hidden /* text="Yükleniyor..." */ />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LoadingModal with View component' }} />
                        <Box sx={{ p: 3 }}>
                            <Button text="Start Loading" onClick={() => setShow(true)} />
                            <View show={show}>
                                <LoadingModal /* text="Yükleniyor..." */ />
                            </View>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default LoadingModalPage;
