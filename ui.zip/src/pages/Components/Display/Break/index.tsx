import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Break, Button, Grid, GridItem, Nav, Paper } from '../../../../lib';

const BreakPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Break' }} />
                        <Box pt={1}>
                            <Grid spacing={1}>
                                <GridItem xs>
                                    <Button text="Outlined" variant="outlined" />
                                </GridItem>
                                <Break />
                                <GridItem xs>
                                    <Button text="Outlined" variant="outlined" />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default BreakPage;
