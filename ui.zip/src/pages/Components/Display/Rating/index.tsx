import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Nav, Paper, Rating } from '../../../../lib';

const RatingPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacing={2}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Rating' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Rating name="rating" precision={0.1} defaultValue={3.3} size="large" />
                                </GridItem>
                                <GridItem>
                                    <Rating name="rating" precision={0.1} defaultValue={3.3} size="medium" />
                                </GridItem>
                                <GridItem>
                                    <Rating name="rating" precision={0.1} defaultValue={3.3} size="small" />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default RatingPage;
