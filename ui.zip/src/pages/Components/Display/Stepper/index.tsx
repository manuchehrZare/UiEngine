import type { FC } from 'react';
import { useRef, useState } from 'react';
import { Layout } from '../../../../App';
import type { IStepStepperRef } from '../../../../lib';
import {
    Box,
    Button,
    Checkbox,
    DatePicker,
    Grid,
    GridItem,
    Input,
    Label,
    message,
    Nav,
    Paper,
    Select,
    Stepper,
    useForm,
    validation,
} from '../../../../lib';

const StepperPage: FC = () => {
    const customStepperRef = useRef<IStepStepperRef>(null);
    const [isFirstStep, setIsFirstStep] = useState<boolean>(true);
    const [isLastStep, setIsLastStep] = useState<boolean>(false);

    const { control: controlStep1, handleSubmit: handleSubmitStep1 } = useForm({
        defaultValues: {
            formInput: '',
            formDatePicker: null,
        },
        validationSchema: {
            formInput: validation.string('formInput', { required: true }),
            formDatePicker: validation.string('formDatePicker', { required: true }),
        },
    });

    const {
        control: controlStep2,
        handleSubmit: handleSubmitStep2,
        setValue: setValueStep2,
    } = useForm({
        defaultValues: {
            formSelect: '',
            formCheckbox: false,
        },
        validationSchema: {
            ...(isLastStep && {
                formSelect: validation.string('formSelect', { required: true }),
            }),
            formCheckbox: validation.boolean('formCheckbox', { required: true }),
        },
    });

    const onFormSubmit = (formValues: any) => {
        // eslint-disable-next-line
        console.log('formValues', formValues);
    };

    // const onCustomButonSubmit = (formValues) => {
    //     // eslint-disable-next-line
    //     console.log('formValues', formValues);
    //     customStepperRef?.current?.next();
    // };

    const stepsBase = [
        {
            label: 'Bilgi 1',
            content: (
                <Box height={300} p={2}>
                    <Label text="Bilgi sayfası 1" />
                </Box>
            ),
        },
        {
            label: 'Bilgi 2',
            content: (
                <Box height={300} p={2}>
                    <Label text="Bilgi sayfası 2" />
                </Box>
            ),
        },
        {
            label: 'Onay',
            content: <Box height={300}>Devam etmek istiyor musunuz?</Box>,
        },
    ];

    const stepForm = [
        {
            label: 'Adım 1',
            content: (
                <Grid spacing={1} p={1}>
                    <GridItem>
                        <Input name="formInput" control={controlStep1} label="Input" />
                    </GridItem>
                    <GridItem>
                        <DatePicker name="formDatePicker" control={controlStep1} label="DatePicker" />
                    </GridItem>
                </Grid>
            ),
            onNext: async () => {
                let isValid = false;
                await handleSubmitStep1(
                    (data) => {
                        onFormSubmit(data);
                        isValid = true;
                    },
                    () => {
                        isValid = false;
                    },
                )();
                return isValid;
            },
        },
        {
            label: 'Adım 2',
            content: (
                <Grid spacing={1} p={1}>
                    <GridItem>
                        <Select
                            name="formSelect"
                            label="Select"
                            control={controlStep2}
                            setValue={setValueStep2}
                            options={{ data: [{ key: '1', name: 'Lorem' }], displayField: 'name', displayValue: 'key' }}
                        />
                    </GridItem>
                    <GridItem>
                        <Checkbox label="Checkbox" name="formCheckbox" control={controlStep2} />
                    </GridItem>
                </Grid>
            ),
            onNext: async () => {
                let isValid = false;
                await handleSubmitStep2(
                    (data) => {
                        onFormSubmit(data);
                        isValid = true;
                    },
                    () => {
                        isValid = false;
                    },
                )();
                return isValid;
            },
        },
    ];

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Grid spacingType="common">
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Stepper Base' }} />
                                <Stepper
                                    stepItems={stepsBase}
                                    onFinish={() => message({ variant: 'success', message: 'Finish' })}
                                />
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Stepper Vertical' }} />
                                <Stepper
                                    stepItems={stepsBase}
                                    orientation="vertical"
                                    onFinish={() => message({ variant: 'success', message: 'Finish' })}
                                />
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Stepper Form' }} />
                                <Stepper
                                    stepItems={stepForm}
                                    onFinish={() => message({ variant: 'success', message: 'Finish' })}
                                />
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Stepper custom Button' }} />
                                <Stepper
                                    stepItems={stepsBase}
                                    showButtons={false}
                                    ref={customStepperRef}
                                    onStepChange={(_, isFirst, isLast) => {
                                        setIsLastStep(isLast);
                                        setIsFirstStep(isFirst);
                                    }}
                                    onFinish={() => message({ variant: 'success', message: 'Finish' })}
                                />
                                <Button
                                    onClick={() => customStepperRef?.current?.prev()}
                                    disabled={isFirstStep}
                                    text=" Geri"
                                />
                                <Button
                                    onClick={() => customStepperRef?.current?.next()}
                                    text={isLastStep ? 'Bitir' : 'İleri'}
                                />
                                <Button onClick={() => customStepperRef?.current?.goToStep(1)} text="Step 2 ye git" />
                                <Button
                                    onClick={() => {
                                        customStepperRef?.current?.goToStep(0);
                                        customStepperRef?.current?.reset();
                                    }}
                                    text="Reset"
                                />
                            </Paper>
                        </GridItem>
                    </Grid>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StepperPage;
