import type { FC } from 'react';
import { Children, useEffect, useState } from 'react';
import { Layout } from '../../../../App';
import {
    Box,
    Carousel,
    Grid,
    GridItem,
    Paper,
    CarouselItem,
    CarouselContentPositionEnum,
    Button,
    Nav,
    useMeasure,
    theme,
    importantStyle,
    useWidth,
    manageClassNames,
    Chip,
    View,
    chipClasses,
} from '../../../../lib';
import { ArrowBack, ArrowForward, CheckCircleRounded, StarRounded } from '@mui/icons-material';
import { faker } from '@faker-js/faker';
import { upperCase } from 'lodash';

interface IExampleCardInfo {
    blockCode: string;
    cardDistributionStatus: string;
    cardName: string;
    cardNumber: string;
    cardType: string;
    cardUser: string;
    debitCardType: string;
    limit: string;
}

const CarouselPage: FC = () => {
    const boxFullWidthMeasure = useMeasure();
    const boxHalfWidthMeasure = useMeasure();
    const boxHalfWidthThumbnailsMeasure = useMeasure();
    const boxThumbnailsMeasure = useMeasure();
    const screenWidth = useWidth();
    const [carouselActiveIndex, setCarouselActiveIndex] = useState<number | undefined>(0);
    const [activeCardIndex, setActiveCardIndex] = useState(-1);
    const thumbnailsExample = {
        height: 80,
        dataIds: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    };

    const exampleCardList: IExampleCardInfo[] = [
        {
            cardNumber: '6501 **** **** **** 8142',
            limit: '498,500,00 / 500,000,00 TL',
            cardType: 'Asıl Kart',
            blockCode: 'AA',
            cardDistributionStatus: 'Teslim Edildi',
            debitCardType: 'Visa',
            cardName: 'Şeker Bonus Memleketim Kart',
            cardUser: 'Neriman İpek Canpolat Akbaşoğulları',
        },
        {
            cardNumber: '6501 **** **** **** 3479',
            limit: '498,500,00 / 500,000,00 TL',
            cardType: 'Asıl Kart',
            blockCode: 'BB',
            cardDistributionStatus: 'Teslim Edildi',
            debitCardType: 'Visa',
            cardName: 'Şeker Bonus Memleketim Kart',
            cardUser: 'Neriman İpek Canpolat Akbaşoğulları',
        },
        {
            cardNumber: '6501 **** **** **** 5645',
            limit: '498,500,00 / 500,000,00 TL',
            cardType: 'Asıl Kart',
            blockCode: 'CC',
            cardDistributionStatus: 'Teslim Edildi',
            debitCardType: 'Visa',
            cardName: 'Şeker Bonus Memleketim Kart',
            cardUser: 'Neriman İpek Canpolat Akbaşoğulları',
        },
        {
            cardNumber: '6501 **** **** **** 1520',
            limit: '498,500,00 / 500,000,00 TL',
            cardType: 'Asıl Kart',
            blockCode: 'DD',
            cardDistributionStatus: 'Teslim Edildi',
            debitCardType: 'Visa',
            cardName: 'Şeker Bonus Memleketim Kart',
            cardUser: 'Neriman İpek Canpolat Akbaşoğulları',
        },
        {
            cardNumber: '8301 **** **** **** 1521',
            limit: '498,500,00 / 500,000,00 TL',
            cardType: 'Asıl Kart',
            blockCode: 'DD',
            cardDistributionStatus: 'Teslim Edildi',
            debitCardType: 'Visa',
            cardName: 'Şeker Bonus Memleketim Kart',
            cardUser: 'Neriman İpek Canpolat Akbaşoğulları',
        },
    ];

    const getExampleCard = (cardItem: IExampleCardInfo) => {
        const cardItemIndex = exampleCardList.findIndex((item) => item === cardItem);
        return (
            <Paper
                borderBox
                className={manageClassNames({ selected: cardItemIndex === activeCardIndex })}
                onClick={() => {
                    setActiveCardIndex(cardItemIndex);
                }}
                sx={{
                    '&.sekerUI-Paper': {
                        width: 290,
                        backgroundColor: theme.palette.common.white,
                        maxWidth: 290,
                        fontSize: 14,
                        padding: 0,
                        borderRadius: '13px',
                        position: 'relative',
                        cursor: 'pointer',
                        '&.selected': {
                            borderColor: 'transparent',
                            '&:before': {
                                content: "' '",
                                position: 'absolute',
                                borderRadius: '13px',
                                top: -1,
                                left: -1,
                                width: 290,
                                height: 300,
                                border: 2,
                                borderColor: theme.palette.secondary.main,
                                zIndex: 2,
                            },
                        },
                    },
                    '.card-info-label': { color: theme.palette.grey[500] },
                }}>
                <Grid borderRadius="13px" overflow="hidden">
                    <View show={cardItemIndex === activeCardIndex}>
                        <Chip
                            label="Seçilen"
                            color="secondary"
                            size="medium"
                            icon={
                                <CheckCircleRounded
                                    sx={{ [`&.${chipClasses.icon}`]: { fontSize: importantStyle('20px'), ml: 0.25 } }}
                                />
                            }
                            sx={{
                                position: 'absolute',
                                right: 16,
                                bottom: -12,
                                fontSize: 14,
                                zIndex: 2,
                            }}
                        />
                    </View>
                    <GridItem>
                        <Box
                            height={70}
                            position="relative"
                            overflow="hidden"
                            sx={{
                                '.card-img': {
                                    opacity: 0.8,
                                    position: 'absolute',
                                    left: 0,
                                    top: 0,
                                },

                                ':before': {
                                    content: "' '",
                                    position: 'absolute',
                                    bottom: 0,
                                    left: 0,
                                    width: '100%',
                                    height: '100%',
                                    zIndex: 1,
                                    boxShadow: `inset 0px -12px 10px ${theme.palette.common.white}`,
                                },
                            }}>
                            <Box className="card-img" component="img" src="https://picsum.photos/id/0/290/70" />
                        </Box>
                    </GridItem>
                    <GridItem position="relative">
                        <Box display="inline" position="absolute" right={8} top={4} fontWeight="bold">
                            {upperCase(cardItem.debitCardType)}
                        </Box>
                        <Box px={2} py={2.5}>
                            <Grid spacing={4}>
                                <GridItem>
                                    <Grid spacing={1}>
                                        <GridItem fontWeight="bold">{cardItem.cardName}</GridItem>
                                        <GridItem>
                                            <Box fontSize={16} color={theme.palette.secondary.main}>
                                                {cardItem.cardNumber}
                                            </Box>
                                        </GridItem>
                                        <GridItem fontWeight="bold">{cardItem.cardUser}</GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid spacing={0.5}>
                                        <GridItem>
                                            <Box className="card-info-label" display="inline" mr={0.5}>
                                                Limit:
                                            </Box>
                                            {cardItem.limit}
                                        </GridItem>
                                        <GridItem>
                                            <Box className="card-info-label" display="inline" mr={0.5}>
                                                Kart Tipi:
                                            </Box>
                                            {cardItem.cardType}
                                        </GridItem>
                                        <GridItem>
                                            <Box className="card-info-label" display="inline" mr={0.5}>
                                                Blok Kodu:
                                            </Box>
                                            {cardItem.blockCode}
                                        </GridItem>
                                        <GridItem>
                                            <Box className="card-info-label" display="inline" mr={0.5}>
                                                Kart Dağıtım Durumu:
                                            </Box>
                                            {cardItem.cardDistributionStatus}
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </GridItem>
                </Grid>
            </Paper>
        );
    };

    const getExampleCardGroupContent = (cardGroupList: IExampleCardInfo[]) => {
        return (
            <Grid columnSpacing={6} height="100%" justifyContent="center">
                {Children.toArray(
                    cardGroupList.map((cardItem) => <GridItem xs="auto">{getExampleCard(cardItem)}</GridItem>),
                )}
            </Grid>
        );
    };

    const getExampleCardGroupList = (cardList: IExampleCardInfo[], groupSize: number) => {
        const groupArr: IExampleCardInfo[][] = [];
        let partialArr: IExampleCardInfo[] = [];

        cardList.forEach((item, index) => {
            partialArr.push(item);
            if ((index + 1) % groupSize === 0) {
                groupArr.push(partialArr);
                partialArr = [];
            } else if (index === cardList.length - 1 && partialArr.length < groupSize) {
                groupArr.push(partialArr);
            }
        });

        return groupArr;
    };

    const getExampleCardGroupSize = () => {
        switch (screenWidth) {
            case 'xxl':
                return 4;
            case 'xl':
                return 3;
            case 'lg':
                return 2;
            case 'md':
                return 1;
            case 'sm':
                return 1;
            case 'xs':
                return 1;
            default:
                return 3;
        }
    };

    useEffect(() => {
        carouselActiveIndex !== 0 && setCarouselActiveIndex(0);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [screenWidth]);

    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel Example' }} />
                        <Box>
                            <Carousel
                                height={300}
                                indicators
                                index={carouselActiveIndex}
                                indicatorsPosition="out"
                                navButtonsAlwaysVisible
                                cycleNavigation={false}
                                swipe={false}
                                onChange={(now) => {
                                    setCarouselActiveIndex(now);
                                }}
                                navButtonsProps={{
                                    style: {
                                        backgroundColor: 'transparent',
                                        color: theme.palette.secondary.main,
                                        height: 64,
                                        width: 64,
                                        transform: 'translateY(-50%)',
                                    },
                                }}
                                activeIndicatorIconButtonProps={{
                                    style: {
                                        backgroundColor: theme.palette.secondary.main,
                                        color: 'transparent',
                                        width: 24,
                                        marginRight: 4,
                                        marginLeft: 4,
                                        borderRadius: 20,
                                    },
                                }}
                                indicatorIconButtonProps={{
                                    style: {
                                        color: theme.palette.grey[300],
                                        height: 8,
                                        width: 8,
                                        minWidth: 16,
                                    },
                                }}
                                sx={{
                                    '.sekerUI-CarouselItem': {
                                        '.sekerUI-CarouselItem-content': {
                                            width: '100%',
                                            height: '100%',
                                            px: 10,
                                            py: 0,

                                            '.sekerUI-Paper': {
                                                height: '100%',
                                            },
                                        },
                                    },
                                    '.sekerUI-Carousel-NavButton': {
                                        opacity: importantStyle('1'),
                                        margin: 0,
                                        svg: { height: importantStyle('64px'), width: importantStyle('64px') },
                                        '&:hover': {
                                            opacity: importantStyle('1'),
                                        },
                                    },
                                    '.sekerUI-Carousel-indicator': {
                                        mt: 2,
                                        '.sekerUI-Carousel-indicator-iconButton': {
                                            svg: {
                                                height: importantStyle('12px'),
                                            },
                                            '&:hover': {
                                                backgroundColor: 'transparent',
                                            },
                                        },
                                    },
                                }}>
                                {Children.toArray(
                                    getExampleCardGroupList(exampleCardList, getExampleCardGroupSize()).map((group) => (
                                        <CarouselItem content={getExampleCardGroupContent(group)} />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel Base' }} />
                        <Box ref={boxFullWidthMeasure.ref}>
                            <Carousel height={400}>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            image={`https://via.assets.so/img.jpg?w=${String(boxFullWidthMeasure.values.width || 0)}&h=${String(boxFullWidthMeasure.values.height || 0)}&t=CarouselItem${String(item)}`}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: "Carousel Indicators & indicatorsPosition='in'" }} />
                        <Box ref={boxHalfWidthMeasure.ref}>
                            <Carousel height={400} indicators>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: "Carousel Indicators & indicatorsPosition='out'" }} />
                        <Box>
                            <Carousel height={400} indicators indicatorsPosition="out">
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel Custom IndicatorIcon' }} />
                        <Box>
                            <Carousel
                                indicators
                                height={400}
                                indicatorIcon={<StarRounded />}
                                activeIndicatorIconButtonProps={{
                                    style: {
                                        color: theme.palette.common.white,
                                    },
                                }}
                                indicatorContainerProps={{
                                    style: {
                                        padding: '10px',
                                        bottom: '10px',
                                    },
                                }}
                                indicatorIconButtonProps={{
                                    style: {
                                        color: theme.palette.green.main,
                                    },
                                }}>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel animation' }} />
                        <Box>
                            <Carousel height={400} animation="fade">
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel navButtonsAlwaysInvisible= false' }} />
                        <Box>
                            <Carousel height={400} navButtonsAlwaysInvisible={false}>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel navButtonsAlwaysVisible' }} />
                        <Box>
                            <Carousel height={400} navButtonsAlwaysInvisible={false} navButtonsAlwaysVisible>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel Custom Next&Prev Icon' }} />
                        <Box>
                            <Carousel
                                height={400}
                                prevNav={<ArrowBack />}
                                nextNav={<ArrowForward />}
                                navButtonsAlwaysInvisible={false}
                                navButtonsAlwaysVisible>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            content={item}
                                            contentPosition="center"
                                            sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel contentPosition' }} />
                        <Box>
                            <Carousel height={400} indicators>
                                {Object.keys(CarouselContentPositionEnum).map((item: any) => (
                                    <CarouselItem
                                        key={item}
                                        content={(CarouselContentPositionEnum as any)[item]}
                                        contentPosition={(CarouselContentPositionEnum as any)[item]}
                                        sx={{ fontSize: 32, backgroundColor: theme.palette.grey[400] }}
                                    />
                                ))}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel Content' }} />
                        <Box>
                            <Carousel height={400}>
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.CenterStart}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="center-start"
                                    sx={{ color: theme.palette.common.white, backgroundColor: theme.palette.info.main }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.Center}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="center"
                                    sx={{
                                        color: theme.palette.common.white,
                                        backgroundColor: theme.palette.warning.main,
                                    }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.CenterEnd}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="center-end"
                                    sx={{
                                        color: theme.palette.common.white,
                                        backgroundColor: theme.palette.green.main,
                                    }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.TopStart}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="top-start"
                                    image={`https://picsum.photos/id/0/${String(boxHalfWidthMeasure.values.width || 0)}/${String(boxHalfWidthMeasure.values.height || 0)}`}
                                    sx={{ color: theme.palette.common.white }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.TopCenter}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="top-center"
                                    image={`https://picsum.photos/id/0/${String(boxHalfWidthMeasure.values.width || 0)}/${String(boxHalfWidthMeasure.values.height || 0)}`}
                                    sx={{ color: theme.palette.common.white }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.TopEnd}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="top-end"
                                    image={`https://picsum.photos/id/0/${String(boxHalfWidthMeasure.values.width || 0)}/${String(boxHalfWidthMeasure.values.height || 0)}`}
                                    sx={{ color: theme.palette.common.white }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.BottomStart}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="bottom-start"
                                    image={`https://picsum.photos/id/0/${String(boxHalfWidthMeasure.values.width || 0)}/${String(boxHalfWidthMeasure.values.height || 0)}`}
                                    sx={{ color: theme.palette.common.white }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.BottomCenter}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="bottom-center"
                                    image={`https://picsum.photos/id/0/${String(boxHalfWidthMeasure.values.width || 0)}/${String(boxHalfWidthMeasure.values.height || 0)}`}
                                    sx={{ color: theme.palette.common.white }}
                                />
                                <CarouselItem
                                    content={
                                        <Box sx={{ width: 200, textAlign: 'normal', p: 1, border: 1 }}>
                                            <Box component="h1" fontWeight="bold">
                                                {CarouselContentPositionEnum.BottomEnd}
                                            </Box>
                                            <Box>{faker.lorem.paragraph()}</Box>
                                            <Button text="Button" />
                                        </Box>
                                    }
                                    contentPosition="bottom-end"
                                    image={`https://picsum.photos/id/0/${String(boxHalfWidthMeasure.values.width || 0)}/${String(boxHalfWidthMeasure.values.height || 0)}`}
                                    sx={{ color: theme.palette.common.white }}
                                />
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Carousel Image' }} />
                        <Box ref={boxHalfWidthMeasure.ref}>
                            <Carousel height={400} indicators>
                                {Children.toArray(
                                    [0, 1, 2, 3].map((item) => (
                                        <CarouselItem
                                            image={`https://picsum.photos/id/${String(item)}/${String(Math.floor(boxHalfWidthMeasure?.values?.width ?? 0) || 0)}/${String(Math.floor(boxHalfWidthMeasure?.values?.height ?? 0) || 0)}`}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem lg={6}>
                    <Paper>
                        <Nav
                            navTitleProps={{
                                title: 'Carousel Custom - Image & Indicators & IndicatorIcon(Thumbnails)',
                            }}
                        />
                        <Box ref={boxHalfWidthThumbnailsMeasure.ref}>
                            <Carousel
                                height={400}
                                autoPlay
                                navButtonsAlwaysVisible
                                navButtonsProps={{
                                    style: {
                                        transform: `translateY(-${thumbnailsExample.height / 2}px)`,
                                    },
                                }}
                                indicators
                                indicatorsPosition="out"
                                indicatorContainerProps={{
                                    style: {
                                        height: thumbnailsExample.height,
                                        overflowX: 'auto',
                                        overflowY: 'hidden',
                                        display: 'inline-flex',
                                        ...(thumbnailsExample.dataIds.length <
                                            Math.floor(
                                                (boxHalfWidthThumbnailsMeasure?.values?.width ?? 0) /
                                                    (boxThumbnailsMeasure?.values.width ?? 0),
                                            ) && {
                                            justifyContent: 'center',
                                        }),
                                        scrollbarWidth: 'thin',
                                    },
                                }}
                                indicatorIconButtonProps={{
                                    style: {
                                        height: thumbnailsExample.height,
                                        width: boxThumbnailsMeasure?.values.width
                                            ? (boxThumbnailsMeasure?.values.width || 0) + 2
                                            : 'auto',
                                        padding: '0 1px',
                                        opacity: 0.5,
                                    },
                                }}
                                activeIndicatorIconButtonProps={{
                                    style: {
                                        opacity: 1,
                                    },
                                }}
                                onChange={(now) => {
                                    boxThumbnailsMeasure?.node?.parentElement?.parentElement?.scrollTo({
                                        behavior: 'smooth',
                                        left: (now as number) * (boxThumbnailsMeasure?.values?.width ?? 0),
                                    });
                                }}
                                indicatorIcon={Children.toArray(
                                    thumbnailsExample.dataIds.map((item) => (
                                        <Box
                                            ref={boxThumbnailsMeasure.ref}
                                            component="img"
                                            sx={{
                                                height: thumbnailsExample.height,
                                                objectFit: 'contain',
                                            }}
                                            src={`https://picsum.photos/id/${String(item)}/${String(Math.floor(boxHalfWidthThumbnailsMeasure?.values?.width ?? 0) || 0)}/${String(Math.floor(boxHalfWidthThumbnailsMeasure?.values?.height ?? 0) || 0)}`}
                                        />
                                    )),
                                )}>
                                {Children.toArray(
                                    thumbnailsExample.dataIds.map((item) => (
                                        <CarouselItem
                                            image={`https://picsum.photos/id/${String(item)}/${String(Math.floor(boxHalfWidthThumbnailsMeasure?.values?.width ?? 0) || 0)}/${String(Math.floor((boxHalfWidthThumbnailsMeasure?.values?.height ?? 0) - (boxThumbnailsMeasure?.values?.height ?? 0) - 13) || 0)}`}
                                        />
                                    )),
                                )}
                            </Carousel>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CarouselPage;
