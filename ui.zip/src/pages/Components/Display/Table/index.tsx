import type { FC } from 'react';
import { Layout } from '../../../../App';
import {
    Box,
    Grid,
    GridItem,
    Nav,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableFooter,
    TableHead,
    TableRow,
} from '../../../../lib';

const TooltipPage: FC = () => {
    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Table' }} />
                        <Box sx={{ p: 1 }}>
                            <Table
                                noBorder
                                containerProps={{
                                    className: 'seker-table-container',
                                }}>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>HeaderCell</TableCell>
                                        <TableCell>HeaderCell</TableCell>
                                        <TableCell>HeaderCell</TableCell>
                                        <TableCell>HeaderCell</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                        <TableCell>BodyCell</TableCell>
                                    </TableRow>
                                </TableBody>
                                <TableFooter>
                                    <TableRow>
                                        <TableCell>FooterCell</TableCell>
                                        <TableCell>FooterCell</TableCell>
                                        <TableCell>FooterCell</TableCell>
                                        <TableCell>FooterCell</TableCell>
                                    </TableRow>
                                </TableFooter>
                            </Table>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default TooltipPage;
