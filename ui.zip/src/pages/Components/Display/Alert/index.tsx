import type { FC } from 'react';
import { Layout } from '../../../../App';
import type { IAlertProps } from '../../../../lib';
import { Grid, GridItem, Paper, Alert, Button, Nav, Label, Select, useForm, useWatch } from '../../../../lib';
import { faker } from '@faker-js/faker';

interface IFormValues extends Pick<IAlertProps, 'variant'> {}

const AlertPage: FC = () => {
    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            variant: 'outlined',
        },
    });
    const [variantWatch] = useWatch({ control, fieldName: ['variant'] });
    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Alert' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem>
                                <Select
                                    label="Variant Selection"
                                    control={control}
                                    name="variant"
                                    setValue={setValue}
                                    displayEmpty
                                    options={{
                                        data: [
                                            { id: 'filled', text: 'filled' },
                                            { id: 'outlined', text: 'outlined' },
                                            { id: 'standard', text: 'standard' },
                                        ],
                                        displayField: 'text',
                                        displayValue: 'id',
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Alert - type' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem>
                                <Alert type="primary" text="Primary" variant={variantWatch} />
                            </GridItem>
                            <GridItem>
                                <Alert type="error" text="Error" variant={variantWatch} />
                            </GridItem>
                            <GridItem>
                                <Alert type="info" text="Info" variant={variantWatch} />
                            </GridItem>
                            <GridItem>
                                <Alert type="success" text="Success" variant={variantWatch} />
                            </GridItem>
                            <GridItem>
                                <Alert type="warning" text="Warning" variant={variantWatch} />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Alert - onClose & action' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem>
                                <Alert
                                    text={faker.lorem.lines(2)}
                                    variant={variantWatch}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    text={faker.lorem.lines(2)}
                                    variant={variantWatch}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    title={faker.lorem.lines(2)}
                                    text={faker.lorem.lines(2)}
                                    variant={variantWatch}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert text={faker.lorem.lines(2)} action={<span>Close</span>} variant={variantWatch} />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    title="Title"
                                    text={faker.lorem.lines(2)}
                                    action={<Button text="Close" />}
                                    variant={variantWatch}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Alert Variant' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem sm={6} lg={4}>
                                <Label text="type = 'primary'" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Alert variant="filled" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert variant="filled" title="Filled Title" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert variant="outlined" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert variant="outlined" title="Outlined Title" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert variant="standard" text="Standard" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert variant="standard" title="Standard Title" text="Standard" />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem sm={6} lg={4}>
                                <Label text="type = 'error'" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Alert type="error" variant="filled" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="error" variant="filled" title="Filled Title" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="error" variant="outlined" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="error" variant="outlined" title="Outlined Title" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="error" variant="standard" text="Standard" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="error" variant="standard" title="Standard Title" text="Standard" />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem sm={6} lg={4}>
                                <Label text="type = 'info'" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Alert type="info" variant="filled" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="info" variant="filled" title="Filled Title" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="info" variant="outlined" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="info" variant="outlined" title="Outlined Title" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="info" variant="standard" text="Standard" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="info" variant="standard" title="Standard Title" text="Standard" />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem sm={6} lg={4}>
                                <Label text="type = 'success'" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Alert type="success" variant="filled" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="success" variant="filled" title="Filled Title" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="success" variant="outlined" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert
                                            type="success"
                                            variant="outlined"
                                            title="Outlined Title"
                                            text="Outlined"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="success" variant="standard" text="Standard" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert
                                            type="success"
                                            variant="standard"
                                            title="Standard Title"
                                            text="Standard"
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem sm={6} lg={4}>
                                <Label text="type = 'warning'" />
                                <Grid pt={0.5} spacingType="common">
                                    <GridItem>
                                        <Alert type="warning" variant="filled" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="warning" variant="filled" title="Filled Title" text="Filled" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="warning" variant="outlined" text="Outlined" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert
                                            type="warning"
                                            variant="outlined"
                                            title="Outlined Title"
                                            text="Outlined"
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Alert type="warning" variant="standard" text="Standard" />
                                    </GridItem>
                                    <GridItem>
                                        <Alert
                                            type="warning"
                                            variant="standard"
                                            title="Standard Title"
                                            text="Standard"
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Alert - Examples' }} />
                        <Grid pt={1} spacingType="common">
                            <GridItem>
                                <Alert type="primary" variant={variantWatch} text={faker.lorem.lines(5)} />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="primary"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="primary"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert type="error" variant={variantWatch} text={faker.lorem.lines(5)} />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="error"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="error"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert type="info" variant={variantWatch} text={faker.lorem.lines(5)} />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="info"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="info"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert type="success" variant={variantWatch} text={faker.lorem.lines(5)} />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="success"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="success"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert type="warning" variant={variantWatch} text={faker.lorem.lines(5)} />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="warning"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                />
                            </GridItem>
                            <GridItem>
                                <Alert
                                    type="warning"
                                    variant={variantWatch}
                                    title={faker.lorem.lines(5)}
                                    text={faker.lorem.lines(5)}
                                    onClose={() => {
                                        //
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default AlertPage;
