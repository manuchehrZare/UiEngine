import { faker } from '@faker-js/faker';
import { Check, ReportProblemOutlined, StarOutlineRounded } from '@mui/icons-material';
import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import type { IBoxProps, IModalProps, IModalTitleProps } from '../../../../lib';
import {
    Box,
    Button,
    Grid,
    GridItem,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    Nav,
    Paper,
    Select,
    theme,
    useForm,
    useWatch,
} from '../../../../lib';

interface IModalState
    extends Pick<IModalProps, 'draggable' | 'show' | 'fullWidth' | 'fullScreen' | 'fullHeight'>,
        Pick<IBoxProps, 'height'>,
        Pick<IModalTitleProps, 'children'> {
    bodyText: string;
}

interface IFormValues extends Pick<IModalProps, 'maxWidth'> {
    contentBody: string;
    customBodyWidth: any;
}

const ModalPage: FC = () => {
    const initialModalState: IModalState = {
        draggable: false,
        show: false,
        children: 'Modal Title',
        bodyText: 'Modal Body',
    };
    const [modalState, setModalState] = useState<IModalState>(initialModalState);
    const [modalStateCM, setModalStateCM] = useState<boolean>(false);

    const { control, setValue, reset } = useForm<IFormValues>({
        defaultValues: { maxWidth: 'md', customBodyWidth: 'sm', contentBody: 'top' },
    });
    const [maxWidthWatch, customBodyWidthWatch, contentBodyWatch] = useWatch({
        control,
        fieldName: ['maxWidth', 'customBodyWidth', 'contentBody'],
    });

    return (
        <>
            <Layout>
                <Grid spacingType="common">
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Modal - maxWidth' }} />
                            <Grid p={2} spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem>
                                            <Select
                                                label="maxWidth Select"
                                                control={control}
                                                name="maxWidth"
                                                setValue={setValue}
                                                options={{
                                                    data: [
                                                        { key: 'false', value: false },
                                                        ...theme.breakpoints.keys.map((item) => ({
                                                            key: item,
                                                            value: item,
                                                        })),
                                                    ],
                                                    displayField: 'key',
                                                    displayValue: 'value',
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Grid spacingType="button">
                                                <GridItem>
                                                    <Button text="Reset" onClick={() => reset()} />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem sm="auto">
                                            <Button
                                                text="Open Modal"
                                                onClick={() => {
                                                    setModalState((prevState) => ({
                                                        ...prevState,
                                                        show: true,
                                                        children: (
                                                            <>
                                                                {maxWidthWatch}
                                                                {prevState?.children}
                                                            </>
                                                        ),
                                                    }));
                                                }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Modal - fullWidth & fullHeight & fullScreen' }} />
                            <Grid p={2} spacingType="button">
                                <GridItem sm="auto">
                                    <Button
                                        text="fullWidth"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                fullWidth: true,
                                            }));
                                        }}
                                    />
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="fullHeight"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                fullHeight: true,
                                                bodyText: faker.lorem.paragraphs(100),
                                            }));
                                        }}
                                    />
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="fullWidth & fullHeight"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                fullWidth: true,
                                                fullHeight: true,
                                            }));
                                        }}
                                    />
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="fullScreen"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                fullScreen: true,
                                            }));
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Modal - Draggable' }} />
                            <Grid p={2} spacingType="button">
                                <GridItem sm="auto">
                                    <Button
                                        text="Draggable"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                draggable: true,
                                            }));
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Modal - Long Content' }} />
                            <Grid p={2} spacingType="button">
                                <GridItem sm="auto">
                                    <Button
                                        text="Long Title"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                children: faker.lorem.sentences(5),
                                            }));
                                        }}
                                    />
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="Long Content Height"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                height: 1200,
                                            }));
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Modal - Custom ModalTitle' }} />
                            <Grid p={2} spacingType="button">
                                <GridItem sm="auto">
                                    <Button
                                        text="Open Custom Modal"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                children: (
                                                    <Box
                                                        sx={{
                                                            display: 'flex',
                                                            justifyContent: 'stretch',
                                                            svg: { textAlign: 'center' },
                                                        }}>
                                                        <Check sx={{ left: '8px' }} />
                                                        Icon ile kullanım
                                                        <Check sx={{ right: '50px' }} />
                                                    </Box>
                                                ),
                                            }));
                                        }}
                                    />
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="Open Custom Modal"
                                        onClick={() => {
                                            setModalState((prevState) => ({
                                                ...prevState,
                                                show: true,
                                                children: (
                                                    <Box>
                                                        <Button
                                                            sx={{ position: 'absolute', left: '8px' }}
                                                            variant="text"
                                                            size="small"
                                                            icon={<StarOutlineRounded />}
                                                            rounded
                                                            iconButton
                                                            // eslint-disable-next-line
                                                            onClick={() => console.log('ikona tıklandı')}
                                                        />
                                                        Label
                                                    </Box>
                                                ),
                                            }));
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'Modal - customBody' }} />
                            <Grid p={2} spacingType="common">
                                <GridItem>
                                    <Grid xs={'auto'} spacingType="common">
                                        <GridItem>
                                            <Select
                                                label="maxWidth Select"
                                                control={control}
                                                name="customBodyWidth"
                                                setValue={setValue}
                                                options={{
                                                    data: [
                                                        { key: 'false', value: false },
                                                        ...theme.breakpoints.keys.map((item) => ({
                                                            key: item,
                                                            value: item,
                                                        })),
                                                    ],
                                                    displayField: 'key',
                                                    displayValue: 'value',
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Select
                                                label="maxWidth Select"
                                                control={control}
                                                name="contentBody"
                                                setValue={setValue}
                                                options={{
                                                    data: [
                                                        { key: 'top' },
                                                        { key: 'left' },
                                                        { key: 'right' },
                                                        { key: 'bottom' },
                                                    ],
                                                    displayField: 'key',
                                                    displayValue: 'key',
                                                }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem sm="auto">
                                    <Button
                                        text="Open Custom Modal"
                                        onClick={() => {
                                            setModalStateCM(true);
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </Layout>
            <Modal
                show={modalState.show}
                draggable={modalState.draggable}
                maxWidth={maxWidthWatch}
                fullWidth={modalState.fullWidth}
                fullHeight={modalState.fullHeight}
                fullScreen={modalState.fullScreen}
                onClose={() => {
                    // eslint-disable-next-line no-console
                    console.log('modal closed');
                    setModalState(initialModalState);
                }}>
                <ModalTitle>{modalState.children}</ModalTitle>
                <ModalBody>
                    <Box height={modalState.height}>{modalState.bodyText}</Box>
                </ModalBody>
                <ModalFooter>
                    <Box>Modal Footer</Box>
                </ModalFooter>
            </Modal>
            <Modal
                show={modalStateCM}
                maxWidth={customBodyWidthWatch}
                onClose={() => {
                    // eslint-disable-next-line no-console
                    console.log('modal closed');
                    setModalStateCM(false);
                }}>
                <ModalBody>
                    <Grid p={2} pt={3}>
                        {contentBodyWatch === 'top' && (
                            <>
                                <GridItem textAlign="center">
                                    <Grid>
                                        <GridItem textAlign="center">
                                            <ReportProblemOutlined color="error" sx={{ fontSize: 70 }} />
                                        </GridItem>
                                        <GridItem pt={2} pb={2} textAlign="center">
                                            <Box sx={{ fontSize: 'large', fontWeight: 600 }}>Bloke Onayı</Box>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem pl={1} pr={1} textAlign="center">
                                    <Box sx={{ fontSize: 'large', fontWeight: 100 }}>{faker.lorem.lines(6)}</Box>
                                </GridItem>
                                <GridItem pt={3} pb={4} display={'flex'} justifyContent="center">
                                    <Grid xs={10} spacingType="form">
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="error"
                                                text="Kartı Kapat"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="success"
                                                variant="outlined"
                                                text="Vazgeç"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </>
                        )}
                        {contentBodyWatch === 'left' && (
                            <>
                                <GridItem pl={1} pr={1} textAlign="center">
                                    <Grid>
                                        <GridItem display="flex" justifyContent="center" xs={4} alignItems="center">
                                            <ReportProblemOutlined color="error" sx={{ fontSize: 70 }} />
                                        </GridItem>
                                        <GridItem xs={8} textAlign="left">
                                            <Box sx={{ fontSize: 'large', fontWeight: 100 }}>
                                                {faker.lorem.lines(6)}
                                            </Box>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem pt={3} pb={4} display={'flex'} justifyContent="center">
                                    <Grid xs={10} spacingType="form">
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="error"
                                                text="Kartı Kapat"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="success"
                                                variant="outlined"
                                                text="Vazgeç"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </>
                        )}
                        {contentBodyWatch === 'right' && (
                            <>
                                <GridItem pl={1} pr={1} textAlign="center">
                                    <Grid>
                                        <GridItem xs={8} textAlign="left">
                                            <Box sx={{ fontSize: 'large', fontWeight: 100 }}>
                                                {faker.lorem.lines(6)}
                                            </Box>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={4} alignItems="center">
                                            <ReportProblemOutlined color="error" sx={{ fontSize: 70 }} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem pt={3} pb={4} display={'flex'} justifyContent="center">
                                    <Grid xs={10} spacingType="form">
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="error"
                                                text="Kartı Kapat"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="success"
                                                variant="outlined"
                                                text="Vazgeç"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </>
                        )}
                        {contentBodyWatch === 'bottom' && (
                            <>
                                <GridItem textAlign="center">
                                    <Grid>
                                        <GridItem pt={2} pb={2} textAlign="center">
                                            <Box sx={{ fontSize: 'large', fontWeight: 600 }}>Bloke Onayı</Box>
                                        </GridItem>
                                        <GridItem textAlign="center">
                                            <ReportProblemOutlined color="error" sx={{ fontSize: 70 }} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem pl={1} pr={1} textAlign="center">
                                    <Box sx={{ fontSize: 'large', fontWeight: 100 }}>{faker.lorem.lines(6)}</Box>
                                </GridItem>
                                <GridItem pt={3} pb={4} display={'flex'} justifyContent="center">
                                    <Grid xs={10} spacingType="form">
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="error"
                                                text="Kartı Kapat"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                fullWidth
                                                type="submit"
                                                color="success"
                                                variant="outlined"
                                                text="Vazgeç"
                                                sx={{ minHeight: 50 }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </>
                        )}
                    </Grid>
                </ModalBody>
            </Modal>
        </>
    );
};

export default ModalPage;
