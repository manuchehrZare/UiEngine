import type { FC } from 'react';
import { Layout } from '../../../../App';
import {
    Box,
    DesignTypeEnum,
    Divider,
    Grid,
    GridItem,
    NavContainer,
    NavItem,
    NavRow,
    NavTitle,
    Paper,
} from '../../../../lib';
import { useNavigate } from 'react-router-dom';
import { StarOutlineRounded, KeyboardArrowLeft, KeyboardArrowRight } from '@mui/icons-material';

const NavPage: FC = () => {
    const navigate = useNavigate();
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem>
                    <Paper>
                        <NavContainer>
                            <NavRow>
                                <NavItem>
                                    <NavTitle title="Default Nav Container" />
                                </NavItem>
                            </NavRow>
                        </NavContainer>
                        <Box py={2}>
                            <NavContainer>
                                <NavRow>
                                    <NavItem>
                                        <NavTitle
                                            title="NavContainer > NavRow > NavItem > NavTitle"
                                            backButtonProps={{ show: true, onClick: () => navigate(-1) }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Box py={2}>
                            <NavContainer>
                                <NavRow>
                                    <NavItem>
                                        <NavTitle
                                            label="Label"
                                            title="NavContainer > NavRow > NavItem > NavTitle > Custom Back Icon"
                                            subTitle="Sub Title"
                                            backButtonProps={{
                                                show: true,
                                                rounded: false,
                                                tooltipTitle: 'Tooltip Text',
                                                color: 'secondary',
                                                variant: 'contained',
                                                text: 'button text',
                                                icon: <StarOutlineRounded />,
                                                // disabled: true,
                                                iconLeft: <KeyboardArrowLeft />,
                                                iconRight: <KeyboardArrowRight />,
                                            }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Divider>SMALL</Divider>
                        <Box py={2}>
                            <NavContainer small>
                                <NavRow>
                                    <NavItem>
                                        <NavTitle
                                            title="NavContainer > NavRow > NavItem > NavTitle"
                                            backButtonProps={{ show: true, size: 'small', onClick: () => navigate(-1) }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Box py={2}>
                            <NavContainer small>
                                <NavRow>
                                    <NavItem>
                                        <NavTitle
                                            label="Label"
                                            title="NavContainer > NavRow > NavItem > NavTitle > Custom Back Icon"
                                            subTitle="Sub Title"
                                            backButtonProps={{
                                                show: true,
                                                size: 'small',
                                                rounded: false,
                                                tooltipTitle: 'Tooltip Text',
                                                color: 'secondary',
                                                variant: 'contained',
                                                text: 'button text',
                                                icon: <StarOutlineRounded />,
                                                // disabled: true,
                                                iconLeft: <KeyboardArrowLeft />,
                                                iconRight: <KeyboardArrowRight />,
                                            }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <NavContainer>
                            <NavRow>
                                <NavItem>
                                    <NavTitle title="SET Nav Container" />
                                </NavItem>
                            </NavRow>
                        </NavContainer>
                        <Box py={2}>
                            <NavContainer design={DesignTypeEnum.SET}>
                                <NavRow design={DesignTypeEnum.SET}>
                                    <NavItem design={DesignTypeEnum.SET}>
                                        <NavTitle
                                            design={DesignTypeEnum.SET}
                                            title="NavContainer > NavRow > NavItem > NavTitle"
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Box py={2}>
                            <NavContainer design={DesignTypeEnum.SET}>
                                <NavRow design={DesignTypeEnum.SET}>
                                    <NavItem design={DesignTypeEnum.SET}>
                                        <NavTitle
                                            design={DesignTypeEnum.SET}
                                            title="NavContainer > NavRow > NavItem > NavTitle"
                                            backButtonProps={{
                                                show: true,
                                                // variant: 'contained',
                                                onClick: () => navigate(-1),
                                            }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Box py={2}>
                            <NavContainer design={DesignTypeEnum.SET}>
                                <NavRow design={DesignTypeEnum.SET}>
                                    <NavItem design={DesignTypeEnum.SET}>
                                        <NavTitle
                                            design={DesignTypeEnum.SET}
                                            label="Label"
                                            title="NavContainer > NavRow > NavItem > NavTitle > Custom Back Icon"
                                            subTitle="Sub Title"
                                            backButtonProps={{
                                                show: true,
                                                rounded: false,
                                                tooltipTitle: 'Tooltip Text',
                                                color: 'secondary',
                                                variant: 'contained',
                                                text: 'button text',
                                                // icon: <StarOutlineRounded />,
                                                // disabled: true,
                                                iconLeft: <KeyboardArrowLeft />,
                                                iconRight: <KeyboardArrowRight />,
                                            }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Divider>SMALL</Divider>
                        <Box py={2}>
                            <NavContainer design={DesignTypeEnum.SET} small>
                                <NavRow design={DesignTypeEnum.SET}>
                                    <NavItem design={DesignTypeEnum.SET}>
                                        <NavTitle
                                            design={DesignTypeEnum.SET}
                                            title="NavContainer > NavRow > NavItem > NavTitle"
                                            backButtonProps={{
                                                show: true,
                                                size: 'small',
                                                variant: 'contained',
                                                onClick: () => navigate(-1),
                                            }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                        <Box py={2}>
                            <NavContainer design={DesignTypeEnum.SET} small>
                                <NavRow design={DesignTypeEnum.SET}>
                                    <NavItem design={DesignTypeEnum.SET}>
                                        <NavTitle
                                            design={DesignTypeEnum.SET}
                                            label="Label"
                                            title="NavContainer > NavRow > NavItem > NavTitle > Custom Back Icon"
                                            subTitle="Sub Title"
                                            backButtonProps={{
                                                show: true,
                                                size: 'small',
                                                rounded: false,
                                                tooltipTitle: 'Tooltip Text',
                                                color: 'secondary',
                                                variant: 'contained',
                                                text: 'button text',
                                                // icon: <StarOutlineRounded />,
                                                // disabled: true,
                                                iconLeft: <KeyboardArrowLeft />,
                                                iconRight: <KeyboardArrowRight />,
                                            }}
                                        />
                                    </NavItem>
                                </NavRow>
                            </NavContainer>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NavPage;
