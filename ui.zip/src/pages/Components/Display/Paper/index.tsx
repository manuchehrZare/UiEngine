import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Nav, Paper } from '../../../../lib';
import { faker } from '@faker-js/faker';

const PaperPage: FC = () => {
    return (
        <Layout>
            <Grid p={1} spacingType="common">
                <GridItem>
                    <Grid spacingType="common">
                        <GridItem xs={6}>
                            <Paper>
                                <Nav navTitleProps={{ title: 'Paper' }} />
                                <Box p={1}>{faker.lorem.paragraphs()}</Box>
                            </Paper>
                        </GridItem>
                        <GridItem xs={6}>
                            <Paper borderBox>
                                <Nav navTitleProps={{ title: 'Paper with borderBox' }} />
                                <Box p={1}>{faker.lorem.paragraphs()}</Box>
                            </Paper>
                        </GridItem>
                    </Grid>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default PaperPage;
