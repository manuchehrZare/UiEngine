import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, Empty, Nav } from '../../../../lib';

const EmptyPage: FC = () => {
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => {
            setLoading(false);
        }, 1500);
        return () => {
            clearTimeout(timer);
        };
    }, [loading]);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Empty Box' }} />
                        <Box sx={{ p: 3 }}>
                            <Empty text="Empty Box Text" loading={loading} />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default EmptyPage;
