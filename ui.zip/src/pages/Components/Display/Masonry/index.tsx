import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Paper, Nav, Masonry, Grid, GridItem, useForm, Checkbox, useWatch } from '../../../../lib';

type FormValues = {
    sequential: boolean;
};

const MasonryPage: FC = () => {
    const { control } = useForm<FormValues>({ defaultValues: { sequential: false } });
    const sequentialValue = useWatch({ control, fieldName: 'sequential' });
    return (
        <Layout>
            <Nav navTitleProps={{ title: 'Masonry' }} />
            <Grid py={1} spacing={1}>
                <GridItem>
                    <Checkbox name="sequential" control={control} label="sequential" />
                </GridItem>
                <GridItem>
                    <Masonry
                        columns={{ xxl: 3, xl: 3, lg: 2, md: 2, sm: 1, xs: 1 }}
                        spacing={2}
                        sequential={sequentialValue}>
                        <Paper>
                            <Box p={1}>
                                Recusandae eum vel modi quae! Velit numquam impedit officiis. Voluptates suscipit illo
                                ipsam reiciendis totam, magnam saepe animi nisi ipsum a consequuntur! Autem dolores
                                architecto vel, soluta perspiciatis necessitatibus dolorum sed mollitia nostrum velit
                                debitis praesentium accusantium nesciunt nemo, aliquam dolor. Adipisci aspernatur
                                eveniet facere quos accusamus? Animi beatae voluptatem hic vel?
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Recusandae eum vel modi quae! Velit numquam impedit officiis. Voluptates suscipit illo
                                ipsam reiciendis totam, magnam saepe animi nisi ipsum a consequuntur! Autem dolores
                                architecto vel, soluta perspiciatis necessitatibus dolorum sed mollitia nostrum velit
                                debitis praesentium accusantium nesciunt nemo, aliquam dolor. Adipisci aspernatur
                                eveniet facere quos accusamus? Animi beatae voluptatem hic vel?
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Recusandae eum vel modi quae! Velit numquam impedit officiis. Voluptates suscipit illo
                                ipsam reiciendis totam, magnam saepe animi nisi ipsum a consequuntur! Autem dolores
                                architecto vel, soluta perspiciatis necessitatibus dolorum sed mollitia nostrum velit
                                debitis praesentium accusantium nesciunt nemo, aliquam dolor. Adipisci aspernatur
                                eveniet facere quos accusamus? Animi beatae voluptatem hic vel?
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Voluptates suscipit illo ipsam reiciendis totam, magnam saepe animi nisi ipsum a
                                consequuntur! Autem dolores architecto vel, soluta perspiciatis necessitatibus dolorum
                                sed mollitia nostrum velit debitis praesentium accusantium nesciunt nemo, aliquam dolor.
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Autem dolores architecto vel, soluta perspiciatis necessitatibus dolorum sed mollitia
                                nostrum velit debitis praesentium accusantium nesciunt nemo, aliquam dolor.
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Autem dolores architecto vel, soluta perspiciatis necessitatibus dolorum sed mollitia
                                nostrum velit debitis praesentium accusantium nesciunt nemo, aliquam dolor. Adipisci
                                aspernatur eveniet facere quos accusamus? Animi beatae voluptatem hic vel?
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Autem dolores architecto vel, soluta perspiciatis necessitatibus dolorum sed mollitia
                                nostrum velit debitis praesentium accusantium nesciunt nemo, aliquam dolor. Adipisci
                                aspernatur eveniet facere quos accusamus? Animi beatae voluptatem hic vel?
                            </Box>
                        </Paper>
                        <Paper>
                            <Box p={1}>
                                Adipisci aspernatur eveniet facere quos accusamus? Animi beatae voluptatem hic vel?
                            </Box>
                        </Paper>
                    </Masonry>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default MasonryPage;
