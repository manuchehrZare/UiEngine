import { MoreHoriz } from '@mui/icons-material';
import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import type { Theme } from '../../../../lib';
import {
    Avatar,
    Box,
    Button,
    Chip,
    DesignTypeEnum,
    Grid,
    GridItem,
    Input,
    Label,
    Nav,
    Paper,
    Tab,
    TabItem,
    Tooltip,
    useForm,
} from '../../../../lib';

const TooltipPage: FC = () => {
    const { control } = useForm<any>({
        defaultValues: {},
        validationSchema: {},
    });
    const [show, setShow] = useState<boolean>(false);
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                {/* Label -start tamamlandı */}
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tooltip -Label' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem display="flex" justifyContent="left" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="left">
                                                <Label text="Test Label" align="left" />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem xs={3}>
                                            <Tooltip title="SET Tooltip" placement="bottom">
                                                <Label text="Test Label" align="center" />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem xs={3}>
                                            <Tooltip title="SET Tooltip" placement="top">
                                                <Label text="Test Label" align="center" />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="right" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="right">
                                                <Label text="Test Label" align="right" />
                                            </Tooltip>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                {/* Label -end */}
                {/* Button -start tamamlandı*/}
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tooltip -Button' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem xs={3}>
                                            <Tooltip sx={{ height: '100%' }} title="SET Tooltip" placement="left">
                                                <Button text="Tooltip" fullWidth />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem xs={3}>
                                            <Tooltip sx={{ height: '100%' }} title="SET Tooltip" placement="bottom">
                                                <Button text="Tooltip" fullWidth />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem xs={3}>
                                            <Tooltip sx={{ height: '100%' }} title="SET Tooltip" placement="top">
                                                <Button text="Tooltip" fullWidth />
                                            </Tooltip>
                                        </GridItem>

                                        <GridItem xs={3}>
                                            <Tooltip sx={{ height: '100%' }} title="SET Tooltip" placement="right">
                                                <Button text="Tooltip" fullWidth />
                                            </Tooltip>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                {/* Button -end */}
                {/* Adornments -start */}
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tooltip -Adornments' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem>
                                            <Input
                                                label="startAdornment Button"
                                                name="adornment"
                                                control={control}
                                                startAdornment={
                                                    <Tooltip sx={{ ml: '-8.5px' }} title="Test">
                                                        <Button iconButton icon={<MoreHoriz />} />
                                                    </Tooltip>
                                                }
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Input
                                                label="endAdornment Button with Tooltip"
                                                name="adornment"
                                                control={control}
                                                endAdornment={
                                                    <Tooltip sx={{ mr: '-5px' }} title="Test">
                                                        <Button iconButton icon={<MoreHoriz />} />
                                                    </Tooltip>
                                                }
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Input
                                                label="endAdornment Button Disabled"
                                                name="adornment"
                                                control={control}
                                                disabled
                                                endAdornment={
                                                    <Tooltip show sx={{ mr: '-5px' }} title="Test">
                                                        <Button iconButton icon={<MoreHoriz />} disabled />
                                                    </Tooltip>
                                                }
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                {/* Adornments -end */}

                <GridItem xs={12}>
                    <Paper>
                        <Grid>
                            {/* Chip -start tamamlandı*/}
                            <GridItem xs={12}>
                                <Nav navTitleProps={{ title: 'Tooltip -Chip&Avatar' }} />
                                <Box sx={{ p: 3 }}>
                                    <Grid spacingType="common">
                                        <GridItem display="flex" justifyContent="left" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="left">
                                                <Chip variant="filled" color="error" label="filled - small" />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="bottom">
                                                <Chip variant="filled" color="error" label="filled - small" />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="top">
                                                <Chip variant="filled" color="error" label="filled - small" />
                                            </Tooltip>
                                        </GridItem>

                                        <GridItem display="flex" justifyContent="right" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="right">
                                                <Chip variant="filled" color="error" label="filled - small" />
                                            </Tooltip>
                                        </GridItem>
                                    </Grid>
                                </Box>
                            </GridItem>
                            {/* Chip -end */}
                            {/* Avatar -start tamamlandı*/}
                            <GridItem xs={12}>
                                <Nav navTitleProps={{ title: 'Tooltip -Avatar' }} />
                                <Box sx={{ p: 3 }}>
                                    <Grid spacingType="common">
                                        <GridItem display="flex" justifyContent="left" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="left">
                                                <Avatar>A</Avatar>
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="bottom">
                                                <Avatar>A</Avatar>
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="top">
                                                <Avatar>A</Avatar>
                                            </Tooltip>
                                        </GridItem>

                                        <GridItem display="flex" justifyContent="right" xs={3}>
                                            <Tooltip title="SET Tooltip" placement="right">
                                                <Avatar>A</Avatar>
                                            </Tooltip>
                                        </GridItem>
                                    </Grid>
                                </Box>
                            </GridItem>
                            {/* Avatar -end */}
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tooltip Show' }} />
                        <Box sx={{ p: 1 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem display="flex" justifyContent="left" xs={3}>
                                            <Tooltip
                                                title="Show Tooltip"
                                                show={show}
                                                className="test"
                                                placement="right">
                                                <Button
                                                    text="Tooltip"
                                                    onClick={() => setShow((prevState) => !prevState)}
                                                />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={3}>
                                            <Tooltip title="Show Tooltip" show={show} className="test" placement="top">
                                                <Button
                                                    text="Tooltip"
                                                    onClick={() => setShow((prevState) => !prevState)}
                                                />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="center" xs={3}>
                                            <Tooltip
                                                title="Show Tooltip"
                                                show={show}
                                                className="test"
                                                placement="bottom">
                                                <Button
                                                    text="Tooltip"
                                                    onClick={() => setShow((prevState) => !prevState)}
                                                />
                                            </Tooltip>
                                        </GridItem>
                                        <GridItem display="flex" justifyContent="right" xs={3}>
                                            <Tooltip
                                                title="Show Tooltip"
                                                show={show}
                                                className="test"
                                                placement="right">
                                                <Button
                                                    text="Tooltip"
                                                    onClick={() => setShow((prevState) => !prevState)}
                                                />
                                            </Tooltip>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 1 }}>
                            <Button
                                text="Toggle Show"
                                design={DesignTypeEnum.SET}
                                onClick={() => setShow((prevState) => !prevState)}
                            />
                        </Box>
                    </Paper>
                </GridItem>

                {/* TabItem -start */}
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tab' }} />
                        <Tab value={1} onChange={() => null}>
                            {(
                                [
                                    { value: 1, p: 'left' },
                                    { value: 2, p: 'bottom' },
                                    { value: 3, p: 'top' },
                                    { value: 4, p: 'right' },
                                ] as unknown as [
                                    {
                                        p:
                                            | 'top'
                                            | 'right'
                                            | 'bottom'
                                            | 'left'
                                            | 'bottom-end'
                                            | 'bottom-start'
                                            | 'left-end'
                                            | 'left-start'
                                            | 'right-end'
                                            | 'right-start'
                                            | 'top-end'
                                            | 'top-start';
                                        value: any;
                                    },
                                ]
                            ).map((item) => (
                                <TabItem
                                    key={String(item.value)}
                                    text={
                                        <Tooltip title="SET Tooltip" placement={item.p}>
                                            <span>{`Item ${item.value}`}</span>
                                        </Tooltip>
                                    }
                                    value={item.value}
                                />
                            ))}
                        </Tab>
                    </Paper>
                </GridItem>
                {/* TabItem -end */}

                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Tooltip Style' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Tooltip
                                        className="aykut"
                                        title={
                                            <Grid textAlign="center">
                                                <GridItem>
                                                    <Label
                                                        text="Label"
                                                        align="center"
                                                        color={(theme) => theme.palette.common.white}
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button text="Deneme1" />
                                                </GridItem>
                                            </Grid>
                                        }
                                        arrow={false}
                                        componentsProps={{
                                            tooltip: {
                                                sx: { backgroundColor: (theme) => (theme as Theme).palette.info.main },
                                            },
                                        }}>
                                        <Button text="Tooltip" fullWidth />
                                    </Tooltip>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default TooltipPage;
