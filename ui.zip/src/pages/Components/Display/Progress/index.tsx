import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Nav, Paper, Progress, ProgressTypeEnum } from '../../../../lib';

const ProgressPage: FC = () => {
    const [progress, setProgress] = useState<number>(10);

    useEffect(() => {
        const timer = setInterval(() => {
            setProgress((prevProgress) => (prevProgress >= 100 ? 0 : prevProgress + 10));
        }, 800);
        return () => {
            clearInterval(timer);
        };
    }, []);
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Circular Progress' }} />
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Circular} />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Circular} value={35} />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Circular} value={65} thickness={5} />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress
                                type={ProgressTypeEnum.Circular}
                                value={65}
                                rounded
                                thickness={8}
                                color={(theme) => theme.palette.error.main}
                            />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Circular} value={65} label />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress
                                type={ProgressTypeEnum.Circular}
                                value={progress}
                                label={{
                                    fontSize: 20,
                                    fontWeight: 600,
                                }}
                                rounded
                                thickness={5}
                            />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress
                                type={ProgressTypeEnum.Circular}
                                value={progress}
                                label={{
                                    fontSize: 20,
                                    color: (theme) => theme.palette.warning.main,
                                    fontWeight: 600,
                                }}
                                rounded
                                thickness={5}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Linear Progress' }} />
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Linear} />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Linear} value={35} />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Linear} value={65} thickness={8} />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress
                                type={ProgressTypeEnum.Linear}
                                value={65}
                                rounded
                                thickness={8}
                                color={(theme) => theme.palette.error.main}
                            />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress type={ProgressTypeEnum.Linear} value={65} label rounded />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress
                                type={ProgressTypeEnum.Linear}
                                value={progress}
                                label={{
                                    fontSize: 20,
                                    fontWeight: 600,
                                }}
                                rounded
                                thickness={8}
                            />
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Progress
                                type={ProgressTypeEnum.Linear}
                                value={progress}
                                label={{
                                    color: (theme) => theme.palette.info.main,
                                    fontSize: 20,
                                    fontWeight: 600,
                                }}
                                rounded
                                thickness={8}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ProgressPage;
