import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, Collapse, Button, Nav } from '../../../../lib';

const CollapsePage: FC = () => {
    const [collapseVertical, setCollapseVertical] = useState(false);
    const [collapseHorizantal, setCollapseHorizantal] = useState(false);

    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Collapse - Vertical' }} />
                        <Box sx={{ p: 3 }}>
                            <Button
                                onClick={() =>
                                    setCollapseVertical((prevState) => {
                                        return !prevState;
                                    })
                                }
                                text="Toggle Collapse"
                            />
                            <Collapse in={collapseVertical}>
                                <Box sx={{ backgroundColor: 'red', height: 300, width: 300, mt: 1 }} />
                            </Collapse>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Collapse - Horizantal' }} />
                        <Box sx={{ p: 3 }}>
                            <Button
                                onClick={() =>
                                    setCollapseHorizantal((prevState) => {
                                        return !prevState;
                                    })
                                }
                                text="Toggle Collapse"
                            />
                            <Collapse in={collapseHorizantal} orientation="horizontal" timeout={3000}>
                                <Box sx={{ backgroundColor: 'red', height: 300, width: 300, mt: 1 }} />
                            </Collapse>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CollapsePage;
