import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Nav, Paper, TreeView, Typography } from '../../../../lib';
import { ExpandMore, ChevronRight, Circle, StarOutline } from '@mui/icons-material';

const TreeViewPage: FC = () => {
    const [expanded, setExpanded] = useState<string[]>([]);
    const treeData: any[] = [
        {
            id: '1',
            label: 'Parent 1',
            children: [
                {
                    id: '1-1',
                    label: 'Child 1 - 1',
                },
                {
                    id: '1-2',
                    label: 'Child 1 - 2',
                    children: [
                        {
                            id: '1-2-1',
                            label: 'Child 1 - 2 - 1',
                        },
                        {
                            id: '1-2-2',
                            label: 'Child 1 - 2 - 2',
                        },
                    ],
                },
            ],
        },
        {
            id: '2',
            label: 'Parent 2',
            children: [
                {
                    id: '2-1',
                    label: 'Child 2 - 1',
                },
                {
                    id: '2-2',
                    label: 'Child 2 - 2',
                    children: [
                        {
                            id: '2-2-1',
                            label: 'Child 2 - 2 - 1',
                            children: [
                                {
                                    id: '2-2-1-1',
                                    label: 'Child 2 - 2 - 1 - 1',
                                },
                            ],
                        },
                    ],
                },
            ],
        },
        {
            id: '3',
            label: 'Parent 3',
            disabled: true,
            children: [
                {
                    id: '3-1',
                    label: 'Child 3 - 1',
                },
                {
                    id: '3-2',
                    label: 'Child 3 - 2',
                    children: [
                        {
                            id: '3-2-1',
                            label: 'Child 3 - 2 - 1',
                        },
                    ],
                },
            ],
        },
    ];
    const treeData2: any[] = [
        {
            id: '1',
            label: 'Parent 1',
        },
        {
            id: '2',
            label: 'Parent 2',
            disabled: true,
        },
        {
            id: '3',
            label: (
                <Box
                    sx={{
                        display: 'flex',
                        alignItems: 'center',
                    }}>
                    <StarOutline sx={{ mr: 0.5 }} />
                    <Typography>Parent 3</Typography>
                </Box>
            ),
        },
        {
            id: '4',
            label: 'Parent 4',
            children: [
                {
                    id: '4-1',
                    label: 'Child 4-1',
                },
            ],
        },
    ];

    const treeData3: any[] = [
        {
            id: '1',
            label: 'Parent 1',
            children: [
                {
                    id: '1-1',
                    label: 'Child 1 - 1',
                },
                {
                    id: '1-2',
                    label: 'Child 1 - 2',
                    children: [
                        {
                            id: '1-2-1',
                            label: 'Child 1 - 2 - 1',
                        },
                        {
                            id: '1-2-2',
                            label: 'Child 1 - 2 - 2',
                        },
                    ],
                },
            ],
        },
        {
            id: '2',
            label: 'Parent 2',
            children: [
                {
                    id: '2-1',
                    label: 'Child 2 - 1',
                },
                {
                    id: '2-2',
                    label: 'Child 2 - 2',
                    children: [
                        {
                            id: '2-2-1',
                            label: 'Child 2 - 2 - 1',
                            children: [
                                {
                                    id: '2-2-1-1',
                                    label: 'Child 2 - 2 - 1 - 1',
                                },
                            ],
                        },
                    ],
                },
            ],
        },
        {
            id: '3',
            label: 'Parent 3',
            disabled: true,
            children: [
                {
                    id: '3-1',
                    label: 'Child 3 - 1',
                },
                {
                    id: '3-2',
                    label: 'Child 3 - 2',
                    children: [
                        {
                            id: '3-2-1',
                            label: 'Child 3 - 2 - 1',
                        },
                    ],
                },
            ],
        },
    ];

    useEffect(() => {
        // eslint-disable-next-line
        setExpanded(['1']);
    }, []);
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'TreeView' }} />
                        <Box sx={{ p: 3 }}>
                            <TreeView
                                options={{
                                    data: treeData,
                                    displayLabel: 'label',
                                    displayId: 'id',
                                    displayChildren: 'children', // default : 'children'
                                    displayDisabled: 'disabled', // default : 'disabled'
                                }}
                                expanded={expanded}
                                // selected={['2']}
                                // multiSelect
                                // disableSelection
                                onToggle={(treeItems, nodeIds) => {
                                    // eslint-disable-next-line no-console
                                    console.log('Toggle', treeItems, nodeIds);
                                }}
                                onFocus={(treeItem) => {
                                    // eslint-disable-next-line no-console
                                    console.log('Focus', treeItem);
                                }}
                                onSelect={(treeItems, nodeIds) => {
                                    // eslint-disable-next-line no-console
                                    console.log('Select', treeItems, nodeIds);
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'TreeView - Custom Icon' }} />
                        <Box sx={{ p: 3 }}>
                            <TreeView
                                options={{
                                    data: treeData2,
                                    displayLabel: 'label',
                                    displayId: 'id',
                                    // displayChildren: 'children', // default : 'children'
                                    // displayDisabled: 'disabled', // default : 'disabled'
                                }}
                                expandIcon={ChevronRight}
                                collapseIcon={ExpandMore}
                                endIcon={Circle}
                            />
                        </Box>
                    </Paper>
                </GridItem>

                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'TreeView - Checkbox Icon' }} />
                        <Box sx={{ p: 3 }}>
                            <TreeView
                                multiSelect
                                checkboxSelection
                                options={{
                                    data: treeData3,
                                    displayLabel: 'label',
                                    displayId: 'id',
                                    displayChildren: 'children', // default : 'children'
                                    displayDisabled: 'disabled', // default : 'disabled'
                                }}
                                expanded={expanded}
                                // selected={['2']}
                                // multiSelect
                                // disableSelection
                                onToggle={(treeItems, nodeIds) => {
                                    // eslint-disable-next-line no-console
                                    console.log('Toggle', treeItems, nodeIds);
                                }}
                                onFocus={(treeItem) => {
                                    // eslint-disable-next-line no-console
                                    console.log('Focus', treeItem);
                                }}
                                onSelect={(treeItems, nodeIds, indeterminateItemIds) => {
                                    // eslint-disable-next-line no-console
                                    console.log('Select', treeItems, nodeIds, indeterminateItemIds);
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default TreeViewPage;
