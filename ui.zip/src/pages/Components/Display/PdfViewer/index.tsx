import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, PdfViewer } from '../../../../lib';
import { Layout } from '../../../../App';
import pdf from './pdf.pdf';
import pdf2 from './pdf2.pdf';
import rapor from './rapor.pdf';
import largeViewPDF from './largeView.pdf';
import { faker } from '@faker-js/faker';
import { MailOutline } from '@mui/icons-material';

const PdfViewerPage: FC = () => {
    const [showPDFModal, setShowPDFModal] = useState<boolean>(false);
    const [pdfFile, setPdfFile] = useState(pdf);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PdfViewer Set' }} />
                        <Box sx={{ p: 1 }}>
                            <Grid spacing={0.5}>
                                <GridItem>
                                    <Button text="SET Open Report (base64Data)" onClick={() => setShowPDFModal(true)} />
                                </GridItem>
                                <GridItem>
                                    <Button text="Reset PdfViewer Set" onClick={() => setPdfFile(undefined)} />
                                </GridItem>
                                <GridItem height={700}>
                                    <PdfViewer
                                        source={pdfFile}
                                        // browserViewer
                                        componentProps={{
                                            documentProps: {
                                                loading: 'SekerUI - PDFViewer - Dosya yükleniyor...',
                                            },
                                            pageProps: {
                                                loading: 'Selam',
                                            },
                                            toolbarProps: {
                                                tools: {
                                                    // save: { passive: true },
                                                    // actualSize: { passive: true },
                                                    // fitPage: { passive: true },
                                                    // fitWidth: { order: 2 },
                                                },
                                            },
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PdfViewer Default' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer source={pdf2} height={500} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PdfViewer - No Source' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer source={null} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PdfViewer - LargeView' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer source={pdfFile} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PdfViewer - text selection' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer source={largeViewPDF} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'toolbarProps - tools text' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer
                                source={rapor}
                                height={700}
                                componentProps={{
                                    toolbarProps: {
                                        tools: {
                                            save: {
                                                label: 'save',
                                            },
                                            previousPage: {
                                                label: 'previous',
                                            },
                                        },
                                    },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'toolbarProps - tools passive' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer
                                source={rapor}
                                height={700}
                                componentProps={{
                                    toolbarProps: {
                                        tools: {
                                            save: {
                                                passive: true,
                                            },
                                            fitPage: {
                                                passive: true,
                                            },
                                        },
                                    },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'toolbarProps - tools customTools' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer
                                source={rapor}
                                height={700}
                                componentProps={{
                                    toolbarProps: {
                                        customTools: [
                                            {
                                                icon: <MailOutline />,
                                                // eslint-disable-next-line
                                                onClick: () => console.log('mail gönderildi'),
                                                label: 'Mail Gönder',
                                                // order: 1,
                                                // passive: true,
                                            },
                                        ],
                                    },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'toolbarProps - tools order' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer
                                source={rapor}
                                height={700}
                                componentProps={{
                                    toolbarProps: {
                                        tools: {
                                            save: {
                                                order: 3,
                                            },
                                            fitPage: {
                                                order: 1,
                                            },
                                        },
                                    },
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'fileName' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer
                                source={rapor}
                                height={700}
                                componentProps={{
                                    fileName: 'SekerUI',
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'browserViewer' }} />
                        <Box sx={{ p: 1 }}>
                            <PdfViewer source={rapor} height={600} browserViewer />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
            <PdfViewer
                source={rapor}
                // height={500}
                // browserViewer
                modal
                modalProps={{
                    show: showPDFModal,
                    title: faker.lorem.sentences(5),
                    onClose: () => setShowPDFModal(false),
                }}
            />
        </Layout>
    );
};
export default PdfViewerPage;
