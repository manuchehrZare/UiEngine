import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Button, DesignTypeEnum, Divider, Grid, GridItem, Label, Nav, Paper } from '../../../../lib';

const DividerPage: FC = () => {
    const [variant, setVariant] = useState<'fullWidth' | 'inset' | 'middle'>('fullWidth');
    const [align, setAlign] = useState<'left' | 'center' | 'right'>('center');
    return (
        <Layout>
            <Grid p={1} spacing={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Divider - orientation' }} />
                        <Box sx={{ p: 3 }}>
                            <Label text="Default" align="center" />
                            <Grid spacing={2}>
                                <GridItem>
                                    <Label text="Horizontal" align="center" />
                                    <Grid>
                                        <GridItem>
                                            <Divider orientation="horizontal" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                        <Divider orientation="vertical" flexItem />
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Label text="SET" align="center" />
                            <Grid spacing={2}>
                                <GridItem>
                                    <Label text="Horizontal" align="center" />
                                    <Grid>
                                        <GridItem>
                                            <Divider design={DesignTypeEnum.SET} orientation="horizontal" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                        <Divider design={DesignTypeEnum.SET} orientation="vertical" flexItem />
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Divider - children & textAlign' }} />
                        <Box sx={{ p: 3 }}>
                            <Label text="Default" align="center" />
                            <Grid spacing={3}>
                                <GridItem>
                                    <Label text="Horizontal" align="center" />
                                    <Grid>
                                        <GridItem>
                                            <Divider textAlign={align}>{align}</Divider>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                        <Divider orientation="vertical" flexItem textAlign={align}>
                                            {align}
                                        </Divider>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Label text="SET" align="center" />
                            <Grid spacing={3}>
                                <GridItem>
                                    <Label text="Horizontal" align="center" />
                                    <Grid>
                                        <GridItem>
                                            <Divider design={DesignTypeEnum.SET} textAlign={align}>
                                                {align}
                                            </Divider>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                        <Divider
                                            design={DesignTypeEnum.SET}
                                            orientation="vertical"
                                            flexItem
                                            textAlign={align}>
                                            {align}
                                        </Divider>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Button text="left" onClick={() => setAlign('left')} />
                                    <Button text="center" onClick={() => setAlign('center')} />
                                    <Button text="right" onClick={() => setAlign('right')} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Divider - variant' }} />
                        <Box sx={{ p: 3 }}>
                            <Label text="Default" align="center" />
                            <Grid spacing={3}>
                                <GridItem>
                                    <Label text="Horizontal" align="center" />
                                    <Grid>
                                        <GridItem>
                                            <Divider variant={variant}>{variant}</Divider>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                        <Divider orientation="vertical" flexItem variant={variant}>
                                            {variant}
                                        </Divider>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Label text="SET" align="center" />
                            <Grid spacing={3}>
                                <GridItem>
                                    <Label text="Horizontal" align="center" />
                                    <Grid>
                                        <GridItem>
                                            <Divider design={DesignTypeEnum.SET} variant={variant}>
                                                {variant}
                                            </Divider>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                        <Divider
                                            design={DesignTypeEnum.SET}
                                            orientation="vertical"
                                            flexItem
                                            variant={variant}>
                                            {variant}
                                        </Divider>
                                        <GridItem xs>
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                            <Label text="Vertical" align="center" />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                        <Box sx={{ p: 3 }}>
                            <Grid spacing={3}>
                                <GridItem>
                                    <Button text="fullWidth" onClick={() => setVariant('fullWidth')} />
                                    <Button text="middle" onClick={() => setVariant('middle')} />
                                    <Button text="inset" onClick={() => setVariant('inset')} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default DividerPage;
