import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Label, Nav, NavItem, NavRow, NavTitle, Paper, useMeasure } from '../../../../lib';

const NavPage: FC = () => {
    const navMeasure = useMeasure();
    return (
        <Layout>
            <Grid px={2}>
                <GridItem>
                    <Label text="Note" />
                    <Box px={1} component="ul" sx={{ listStyle: 'circle' }}>
                        <Box component="li">Hierarchy : NavContainer &gt; NavRow &gt; NavItem &gt; NavTitle</Box>
                        <Box component="li">
                            In children props definitions, the value of the parent component will remain dominant
                            according to the hierarchy.
                        </Box>
                        <Box component="li">
                            If children are defined in the navContainerProps when we define all props; This feature will
                            remain dominant.
                        </Box>
                    </Box>
                </GridItem>
                <GridItem>
                    <Label text="Examples" />
                    <Grid px={1} spacingType="common">
                        <GridItem>
                            <Paper>
                                <Nav ref={navMeasure?.ref} navTitleProps={{ title: 'With NavTitle Props' }} />
                                <Grid>
                                    <GridItem>Measure Ref Values for Nav</GridItem>
                                    <GridItem>{JSON.stringify(navMeasure.values, null, 4)}</GridItem>
                                </Grid>
                            </Paper>
                        </GridItem>
                        <GridItem>
                            <Paper>
                                <Nav
                                    navItemProps={{
                                        children: (
                                            <>
                                                <NavTitle title="With NavItem Children" />
                                                <NavTitle title="With NavItem Children" />
                                            </>
                                        ),
                                    }}
                                />
                            </Paper>
                        </GridItem>
                        <GridItem>
                            <Paper>
                                <Nav
                                    navRowProps={{
                                        children: (
                                            <>
                                                <NavItem>
                                                    <NavTitle title="With NavRow Children" />
                                                </NavItem>
                                                <NavItem>
                                                    <NavTitle title="With NavRow Children" />
                                                </NavItem>
                                            </>
                                        ),
                                    }}
                                />
                            </Paper>
                        </GridItem>
                        <GridItem>
                            <Paper>
                                <Nav
                                    navContainerProps={{
                                        children: (
                                            <>
                                                <NavRow>
                                                    <NavItem>
                                                        <NavTitle title="With NavContainer Children" />
                                                    </NavItem>
                                                </NavRow>
                                                <NavRow>
                                                    <NavItem>
                                                        <NavTitle title="With NavContainer Children" />
                                                    </NavItem>
                                                </NavRow>
                                            </>
                                        ),
                                    }}
                                />
                            </Paper>
                        </GridItem>
                    </Grid>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NavPage;
