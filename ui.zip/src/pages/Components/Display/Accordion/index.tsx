import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../App';
import { Box, Grid, GridItem, Paper, Accordion, Nav } from '../../../../lib';
import StarOutlineRoundedIcon from '@mui/icons-material/StarOutlineRounded';

const AccordionPage: FC = () => {
    const [expanded, setExpanded] = useState<number | false>(false);

    const handleChange = (panel: number) => (_: React.SyntheticEvent, isExpanded: boolean) => {
        setExpanded(isExpanded ? panel : false);
    };

    const accordionData = [
        {
            id: 0,
            title: 'Title1',
            defaultExpanded: true,
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 1,
            title: 'Title2',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 2,
            title: 'Title3',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 3,
            title: 'Title4',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 4,
            title: 'Title5',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 5,
            title: 'Title6',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 6,
            title: 'Title7',
            defaultExpanded: true,
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 7,
            title: 'Title8',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 8,
            title: 'Title9',
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
        {
            id: 9,
            title: 'Title10',
            defaultExpanded: true,
            content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, repellat.',
        },
    ];

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem sm={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Basic Accordion' }} />
                        <Box>
                            <Accordion
                                title="Title"
                                content="Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellendus dolores ut esse! Consequatur qui recusandae labore incidunt hic est adipisci?"
                                icon={<StarOutlineRoundedIcon />}
                            />
                            <Accordion
                                title="Title2"
                                defaultExpanded
                                content="Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellendus dolores ut esse! Consequatur qui recusandae labore incidunt hic est adipisci?"
                            />
                            <Accordion
                                title="Title3"
                                content="Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellendus dolores ut esse! Consequatur qui recusandae labore incidunt hic est adipisci?"
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem sm={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Expanded Control' }} />
                        <Box>
                            {accordionData.map((item) => {
                                return (
                                    <Accordion
                                        key={item.id}
                                        expanded={expanded === item.id}
                                        onChange={handleChange(item.id)}
                                        title={item.title}
                                        content={item.content}
                                    />
                                );
                            })}
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default AccordionPage;
