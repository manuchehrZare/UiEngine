import type { FC } from 'react';
import { Box, Button, Grid, GridItem, IBAN, Nav, Paper, useForm, validation } from '../../../../lib';
import { Layout } from '../../../../App';

const IBANPage: FC = () => {
    const { control, handleSubmit, reset } = useForm<any>({
        defaultValues: {
            ibanInputDefault: 'TR888888888888888888F',
            ibanInput: '',
            ibanInput2: 'TR3600 05902280 130228090 574',
            ibanInput3: 'TR888888888888888888F',
            ibanInput4: '',
        },
        validationSchema: {
            ibanInputDefault: validation.iban(),
            ibanInput: validation.iban({
                required: true,
                fieldLabel: 'ibanxx',
            }),
            ibanInput2: validation.iban({ fieldLabel: 'ibanyy', required: true }),
            ibanInput3: validation.iban(),
            ibanInput4: validation.iban(),
        },
    });
    const onSubmit = (formData: any) => {
        // eslint-disable-next-line no-console
        console.log('Currency--formData', formData);
    };

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'IBAN - Input' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem xs={6}>
                                            <IBAN
                                                input
                                                label="IBAN -default"
                                                name="ibanInputDefault"
                                                onError={(error) => {
                                                    // eslint-disable-next-line
                                                    console.log(error);
                                                }}
                                                control={control}
                                                fixedCountryCode="DE"
                                            />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <IBAN input name="ibanInput" label="ibanInput" control={control} />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <IBAN
                                                input
                                                name="ibanInput2"
                                                label="ibanInput2"
                                                control={control}
                                                fixedCountryCode
                                            />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <IBAN input name="ibanInput3" label="ibanInput3" control={control} />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <IBAN
                                                input
                                                fixedCountryCode
                                                label="ibanInput4"
                                                name="ibanInput4"
                                                control={control}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem xs="auto">
                                            <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button text="Reset" onClick={() => reset()} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'IBAN - Bold Account No Display' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid>
                                <GridItem>
                                    <IBAN value="TR360005902280130228090574" showBoldAccountNo />
                                </GridItem>
                                <GridItem>
                                    <IBAN value="TR360005902280130228090571" showBoldAccountNo accountNoLength={15} />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default IBANPage;
