import type { FC } from 'react';
import { useEffect } from 'react';
import { Box, Button, Grid, GridItem, Label, Nav, Paper, useForm } from '../../../../lib';
import { Layout } from '../../../../App';
import PhoneNumber from '../../../../lib/components/Others/PhoneNumber';

interface IFormValues {
    numberInput1: string;
    numberInput2: string;
    numberInput3: string;
    numberInput4: string;
    numberInput5: string;
    numberInput6: string;
}

const PhoneNumberPage: FC = () => {
    const { control, handleSubmit, reset, setValue } = useForm<IFormValues>({
        defaultValues: {
            numberInput1: '',
            numberInput2: '',
            numberInput3: '',
            numberInput4: '',
            numberInput5: '',
            numberInput6: '',
        },
    });

    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('PhoneNumber--formData', formData);
    };

    useEffect(() => {
        setValue('numberInput2', '5987855441');
        setValue('numberInput3', '05987855441');
        setValue('numberInput4', '05987855441');
        setValue('numberInput5', '5978445');
        setValue('numberInput6', '905906211415');
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PhoneNumber - Input' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem xs={6}>
                                    <Label text="default" />
                                    <Grid spacingType="form">
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberInput"
                                                name="numberInput1"
                                                control={control}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withoutBrackets" />
                                    <Grid spacingType="form" pt={0.5}>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberInput"
                                                name="numberInput2"
                                                control={control}
                                                withoutBrackets
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withoutBrackets & withZero" />
                                    <Grid spacingType="form" pt={0.5}>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberInput"
                                                name="numberInput3"
                                                control={control}
                                                withoutBrackets
                                                withZero
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withZero" />
                                    <Grid spacingType="form" pt={0.5}>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberInput"
                                                name="numberInput4"
                                                control={control}
                                                withZero
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withoutAreaCode" />
                                    <Grid spacingType="form" pt={0.5}>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberInput"
                                                name="numberInput5"
                                                control={control}
                                                withoutAreaCode
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withZero & withCountryCode" />
                                    <Grid spacingType="form" pt={0.5}>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberInput"
                                                name="numberInput6"
                                                control={control}
                                                withZero
                                                withCountryCode
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem xs="auto">
                                            <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button text="Reset" onClick={() => reset()} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PhoneNumber - Format' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid>
                                <GridItem xs={6}>
                                    <Label text="default" />
                                    <Grid>
                                        <GridItem>
                                            <PhoneNumber component="NumberFormat" value={'5958455212'} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withZero & withoutBrackets" />
                                    <Grid>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberFormat"
                                                value={'05958455212'}
                                                withZero
                                                withoutBrackets
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withZero" />
                                    <Grid>
                                        <GridItem>
                                            <PhoneNumber component="NumberFormat" value={'05958455212'} withZero />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withoutBrackets" />
                                    <Grid>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberFormat"
                                                value={'5958455212'}
                                                withoutBrackets
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withoutAreaCode" />
                                    <Grid>
                                        <GridItem>
                                            <PhoneNumber component="NumberFormat" value={'5799557'} withoutAreaCode />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem xs={6}>
                                    <Label text="withZero & withCountryCode" />
                                    <Grid>
                                        <GridItem>
                                            <PhoneNumber
                                                component="NumberFormat"
                                                value={'905906211415'}
                                                withZero
                                                withCountryCode
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default PhoneNumberPage;
