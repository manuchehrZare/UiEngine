import type { FC } from 'react';
import { Children, useEffect } from 'react';
import { Box, Button, CardNumber, Grid, GridItem, Nav, Paper, cardNumberFormatter, useForm } from '../../../../lib';
import { Layout } from '../../../../App';
import { fill, keys } from 'lodash';

interface IFormValues {
    numberInput1: string;
    numberInput2: string;
    numberInput3: string;
    numberInput4: string;
}

const CardNumberPage: FC = () => {
    const cardNumbers = {
        14: '12345678901234',
        16: '1234567890123456',
        19: '1234567890123456789',
        masked: '4238330000004809',
    };
    const { control, handleSubmit, reset, setValue } = useForm<IFormValues>({
        defaultValues: {
            numberInput1: '',
            numberInput2: '',
            numberInput3: cardNumbers[16],
            numberInput4: cardNumbers.masked,
        },
    });

    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('CardNumber--formData', formData);
    };

    useEffect(() => {
        setValue('numberInput2', cardNumbers[16]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'CardNumber - Input' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem xs={6}>
                                            <CardNumber
                                                component="NumberInput"
                                                name="numberInput1"
                                                returnValue="floatValue"
                                                control={control}
                                                length={19}
                                            />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <CardNumber
                                                component="NumberInput"
                                                name="numberInput2"
                                                readOnly
                                                control={control}
                                            />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <CardNumber
                                                label="KartNo - NumberInput & format"
                                                component="NumberInput"
                                                name="numberInput3"
                                                readOnly
                                                control={control}
                                                format={(value) =>
                                                    cardNumberFormatter(fill(value.split(''), '*', 4, 10).join(''))
                                                }
                                            />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <CardNumber
                                                component="NumberInput"
                                                name="numberInput4"
                                                returnValue="floatValue"
                                                control={control}
                                                format={(value) => {
                                                    return cardNumberFormatter(
                                                        fill(value.split(''), 'x', 6, 12).join(''),
                                                    );
                                                }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem xs="auto">
                                            <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button text="Reset" onClick={() => reset()} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'CardNumber - Format' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid>
                                {Children.toArray(
                                    keys(cardNumbers).map((key) => (
                                        <GridItem>
                                            <CardNumber
                                                component="NumberFormat"
                                                value={(cardNumbers as any)[key]}
                                                {...(key === 'masked' && {
                                                    format: (value) =>
                                                        cardNumberFormatter(fill(value.split(''), 'x', 6, 12).join('')),
                                                })}
                                            />
                                        </GridItem>
                                    )),
                                )}
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CardNumberPage;
