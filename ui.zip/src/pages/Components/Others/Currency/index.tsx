import type { FC } from 'react';
import { Box, Button, Currency, Grid, GridItem, Label, Nav, Paper, useForm } from '../../../../lib';
import { Layout } from '../../../../App';

interface IFormValues {
    currencyInput1: number | null;
    currencyInput2: number | null;
    currencyInput3: number | null;
}

const CurrencyPage: FC = () => {
    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            currencyInput1: 58.346,
            currencyInput2: 155.85,
            currencyInput3: 155.85,
        },
    });
    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('Currency--formData', formData);
    };

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Currency - Input' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="common">
                                        <GridItem xs={6}>
                                            <Currency component="NumberInput" name="currencyInput1" control={control} />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <Currency
                                                component="NumberInput"
                                                name="currencyInput2"
                                                readOnly
                                                control={control}
                                                currency="TL"
                                            />
                                        </GridItem>
                                        <GridItem xs={6}>
                                            <Currency
                                                component="NumberInput"
                                                name="currencyInput3"
                                                readOnly
                                                control={control}
                                                currency="$"
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem xs="auto">
                                            <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                                        </GridItem>
                                        <GridItem xs="auto">
                                            <Button text="Reset" onClick={() => reset()} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'currency' }} />
                        <Grid spacingType="common" p={1}>
                            <GridItem lg={6}>
                                <Label text="Base Example" />
                                <Paper borderBox sx={{ '&.sekerUI-Paper': { p: 2 } }}>
                                    <Box>
                                        <Currency component="NumberFormat" value={8835465465445.12} />
                                    </Box>
                                </Paper>
                            </GridItem>
                            <GridItem lg={6}>
                                <Label text="turkishCurrency" />
                                <Paper borderBox sx={{ '&.sekerUI-Paper': { p: 2 } }}>
                                    <Box>
                                        <Currency component="NumberFormat" value={8835465465445.12} currency="TL" />
                                    </Box>
                                </Paper>
                            </GridItem>
                            <GridItem lg={6}>
                                <Label text="europeCurrency" />
                                <Paper borderBox sx={{ '&.sekerUI-Paper': { p: 2 } }}>
                                    <Box>
                                        <Currency
                                            component="NumberFormat"
                                            value={8835465465445.12}
                                            currency="EUR"
                                            styledValue
                                        />
                                    </Box>
                                </Paper>
                            </GridItem>
                            <GridItem lg={6}>
                                <Label text="americanCurrency" />
                                <Paper borderBox sx={{ '&.sekerUI-Paper': { p: 2 } }}>
                                    <Box>
                                        <Currency component="NumberFormat" value={88354465445.85} currency="$" />
                                    </Box>
                                </Paper>
                            </GridItem>
                            <GridItem lg={6}>
                                <Label text="turkishCurrency - with styledValue" />
                                <Paper borderBox sx={{ '&.sekerUI-Paper': { p: 2 } }}>
                                    <Box>
                                        <Currency
                                            component="NumberFormat"
                                            value={88354465445.85}
                                            currency="TL"
                                            styledValue
                                        />
                                    </Box>
                                </Paper>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default CurrencyPage;
