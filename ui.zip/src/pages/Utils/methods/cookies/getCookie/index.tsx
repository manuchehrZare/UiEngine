import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { Grid, GridItem, Paper, setCookie, getCookie, Nav } from '../../../../../lib';

const GetCookiePage: FC = () => {
    setCookie('cookieName', 'cookieValue', 1);
    const cookie = getCookie('cookieName');
    // eslint-disable-next-line no-console
    console.log(cookie);
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'setCookie' }} />
                        <Box sx={{ p: 1 }}>
                            <pre>
                                {`
                                setCookie('cookieName', 'cookieValue', 1);
                                const cookie = getCookie('cookieName');

                                console.log(cookie);
                                // output: "cookieValue"
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default GetCookiePage;
