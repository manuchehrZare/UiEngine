import type { FC } from 'react';
import { Layout } from '../../../../App';
import { Box, Button, Grid, GridItem, Nav, Paper, message } from '../../../../lib';
import { confirm } from '../../../../lib/utils/methods';

const ConfirmPage: FC = () => {
    const showDefaultConfirm = async () => {
        const response = await confirm();
        if (response) {
            // eslint-disable-next-line no-console
            console.log('response', response);
            message({ variant: 'success', message: `Response: ${response}` });
        } else {
            // eslint-disable-next-line no-console
            console.log('response', response);
            message({ variant: 'error', message: `Response: ${response}` });
        }
    };

    const showDobuleConfirm = async () => {
        const response = await confirm();

        if (response) {
            // eslint-disable-next-line no-console
            console.log('response', response);
            message({ variant: 'success', message: `Response: ${response}` });

            const response2 = await confirm({ title: '2. Uyarı', body: 'Emin misin?' });

            if (response2) {
                // eslint-disable-next-line no-console
                console.log('response2', response2);
                message({ variant: 'success', message: `Response: ${response2}` });
            } else {
                // eslint-disable-next-line no-console
                console.log('response2', response2);
                message({ variant: 'error', message: `Response: ${response2}` });
            }
        } else {
            // eslint-disable-next-line no-console
            console.log('response', response);
            message({ variant: 'error', message: `Response: ${response}` });
        }
        // eslint-disable-next-line no-console
        console.log('kod devam ediyor...');
    };

    const showCustomConfirm = async () => {
        const response = await confirm({
            title: 'CUSTOM TITLE',
            body: 'Custom question ?',
            okText: 'Okay',
            cancelText: 'None',
            actionProps: {
                okProps: {
                    color: 'info',
                    variant: 'contained',
                },
                cancelProps: {
                    color: 'warning',
                    variant: 'contained',
                },
            },
        });
        if (response) {
            // eslint-disable-next-line no-console
            console.log('response', response);
            message({ variant: 'success', message: `Response: ${response}` });
        } else {
            // eslint-disable-next-line no-console
            console.log('response', response);
            message({ variant: 'error', message: `Response: ${response}` });
        }
    };

    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'confirm' }} />
                        <Box sx={{ p: 3 }}>
                            <Grid spacingType="button">
                                <GridItem xs>
                                    <Button
                                        text="Open Default Confirm"
                                        onClick={() => showDefaultConfirm()}
                                        fullWidth
                                    />
                                </GridItem>
                                <GridItem xs>
                                    <Button text="Open Double Confirm" onClick={() => showDobuleConfirm()} fullWidth />
                                </GridItem>
                                <GridItem xs>
                                    <Button text="Open Custom Confirm" onClick={() => showCustomConfirm()} fullWidth />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ConfirmPage;
