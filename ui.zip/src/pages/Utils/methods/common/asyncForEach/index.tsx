import type { FC } from 'react';
import { useEffect } from 'react';
import { Layout } from '../../../../../App';
import { Box, Grid, GridItem, Nav, Paper, asyncForEach } from '../../../../../lib';

const AsyncForEachPage: FC = () => {
    const arr = [1, 5, 2, 4];
    useEffect(() => {
        asyncForEach(arr, async (eachItem) => {
            await fetch(`https://reqres.in/api/users/${eachItem}?delay=${eachItem}`).then((response) => response.json);
        });
        // eslint-disable-next-line
    }, []);

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'asyncForEach' }} />
                        <Box sx={{ p: 1 }}>
                            <pre>
                                {`
                                const arr = [1, 5, 2, 4];
                                asyncForEach(arr, async (eachItem) => {
                                    await fetch('https://reqres.in/api/users/$eachItem?delay=$eachItem').then(
                                        (response) => response.json,
                                    );
                                })

                                // output: Network should be looked at to see changes

                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default AsyncForEachPage;
