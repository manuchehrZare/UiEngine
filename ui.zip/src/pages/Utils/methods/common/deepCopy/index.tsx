import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { deepCopy, Grid, GridItem, Nav, Paper } from '../../../../../lib';

const DeepCopyPage: FC = () => {
    const data = 'Text 1';
    let copyData = deepCopy(data);
    copyData = 'Text 2';
    // eslint-disable-next-line no-console
    console.log(data);
    // output: 'Text 1'
    // eslint-disable-next-line no-console
    console.log(copyData);
    // output: 'Text 2'

    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'deepCopy' }} />
                        <Box sx={{ p: 1 }}>
                            <pre>
                                {`
                                const data = 'Text 1'; 
                                let copyData = deepCopy(data); 
                                copyData = 'Text 2';

                                console.log(data); 
                                // output: 'Text 1' 

                                console.log(copyData);
                                // output: 'Text 2'
                            `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default DeepCopyPage;
