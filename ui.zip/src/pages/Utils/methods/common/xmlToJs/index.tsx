import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { Grid, GridItem, Label, Nav, Paper, xmlToJs } from '../../../../../lib';
import { xmlData } from './data';

const XmlToJsPage: FC = () => {
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'xmlToJs' }} />
                        <Grid spacingType="common" p={1}>
                            <GridItem lg={6}>
                                <Label text="XML Data" />
                                <Paper
                                    borderBox
                                    sx={{
                                        '&.sekerUI-Paper': {
                                            p: 2,
                                        },
                                    }}>
                                    <pre style={{ whiteSpace: 'pre-wrap' }}>{xmlData}</pre>
                                </Paper>
                            </GridItem>
                            <GridItem lg={6}>
                                <Label text="JSON Data" />
                                <Paper
                                    borderBox
                                    sx={{
                                        '&.sekerUI-Paper': {
                                            p: 2,
                                        },
                                    }}>
                                    <pre style={{ whiteSpace: 'pre-wrap' }}>{JSON.stringify(xmlToJs(xmlData))}</pre>
                                </Paper>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default XmlToJsPage;
