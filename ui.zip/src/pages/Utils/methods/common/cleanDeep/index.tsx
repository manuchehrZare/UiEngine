import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { cleanDeep, Grid, GridItem, Nav, Paper } from '../../../../../lib';

const CleanDeepPage: FC = () => {
    const data: any = {
        key0: {},
        key1: 1,
        key2: '',
        key3: null,
        key4: undefined,
        key5: '5',
        key6Arr: [],
        key7: {
            key7sub1: '',
            key7sub2: {},
            key7sub3: null,
            key7sub4: undefined,
            key7sub5: '1',
            key7sub6: NaN,
        },
        key8Arr: [
            {
                key8ArrSub1: '',
                key8ArrSub2: '1',
            },
        ],
    };
    // eslint-disable-next-line no-console
    console.log(cleanDeep(data));

    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'cleanDeep' }} />
                        <Box sx={{ p: 1 }}>
                            <pre>
                                {`
                                 const data: any = {
                                    key0: {},
                                    key1: 1,
                                    key2: '',
                                    key3: null,
                                    key4: undefined,
                                    key5: '5',
                                    key6Arr: [],
                                    key7: {
                                        key7sub1: '',
                                        key7sub2: {},
                                        key7sub3: null,
                                        key7sub4: undefined,
                                        key7sub5: '1',
                                        key7sub6: NaN,
                                    },
                                    key8Arr: [
                                        {
                                            key8ArrSub1: '',
                                            key8ArrSub2: '1',
                                        },
                                    ],
                                };
                                
                                console.log(cleanDeep(data));

                                // output: ${JSON.stringify(cleanDeep(data))}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CleanDeepPage;
