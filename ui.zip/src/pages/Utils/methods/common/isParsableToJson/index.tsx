import type { FC, JSX } from 'react';
import { Grid, GridItem, Nav, Paper, isParsableToJson } from '../../../../../lib';
import { Layout } from '../../../../../App';
import { Box } from '@mui/system';

const IsParsableToJsonPage: FC = (): JSX.Element => {
    const plainString = 'abcdfg';
    // eslint-disable-next-line no-console
    console.log('isParsableToJson(plainString)', isParsableToJson(plainString));

    const objectString = '{"name":"test","age":"12"}';
    // eslint-disable-next-line no-console
    console.log('isParsableToJson(objectString)', isParsableToJson(objectString));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'isParsableToJson' }} />
                        <Box p={1} px={3}>
                            <pre>
                                {`
const plainString = ${plainString}
console.log(isParsableToJson(plainString));
// output: ${isParsableToJson(plainString)}

const objectString = ${objectString}
console.log(isParsableToJson(objectString));
// output: ${isParsableToJson(objectString)}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default IsParsableToJsonPage;
