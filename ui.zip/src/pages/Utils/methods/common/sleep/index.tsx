import { Box } from '@mui/material';
import type { FC } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../../App';
import { sleep, Button, Grid, GridItem, Paper, Nav } from '../../../../../lib';

const SleepPage: FC = () => {
    const [show, setShow] = useState<boolean>(false);
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'sleep' }} />
                        <Box sx={{ p: 3 }}>
                            <Button
                                text={show ? 'Show' : 'Click me'}
                                onClick={() => {
                                    sleep(2000).then(() => {
                                        setShow((prevState) => !prevState);
                                    });
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default SleepPage;
