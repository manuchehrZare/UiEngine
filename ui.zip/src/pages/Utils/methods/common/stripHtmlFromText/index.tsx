import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { stripHtmlFromText, Grid, GridItem, Paper, Divider, Nav } from '../../../../../lib';

const StripHtmlFromTextPage: FC = () => {
    const data: any = 'Some <b>  TEXT to Clean</b>';
    const textWithEntities: string =
        '&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.01 Transitional//EN&quot;&gt;&lt;html&gt;&lt;link rel=&quot;stylesheet&quot; href=&quot;slip.css&quot; /&gt;SekerUI';
    // eslint-disable-next-line no-console
    console.log(stripHtmlFromText(data));
    return (
        <Layout>
            <Grid p={1}>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'stripHtmlFromText' }} />
                        <Box sx={{ p: 1 }}>
                            <pre style={{ whiteSpace: 'pre-wrap' }}>
                                {`
                                const data = '${data}';
                                
                                console.log(stripHtmlFromText(data));

                                // output: ${stripHtmlFromText(data)}
                                `}
                            </pre>
                            <Divider />
                            <pre style={{ whiteSpace: 'pre-wrap' }}>
                                {`
                                const data = '${textWithEntities}';
                                
                                console.log(stripHtmlFromText(data));

                                // output: ${stripHtmlFromText(textWithEntities)}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StripHtmlFromTextPage;
