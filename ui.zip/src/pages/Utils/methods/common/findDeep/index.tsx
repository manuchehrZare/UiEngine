import { Box } from '@mui/material';
import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { findDeep, Grid, GridItem, Nav, Paper } from '../../../../../lib';

const FindDeepPage: FC = () => {
    const treeData: any[] = [
        {
            id: '1',
            label: 'Parent 1',
            children: [
                {
                    id: '1-1',
                    label: 'Child 1 - 1',
                },
                {
                    id: '1-2',
                    label: 'Child 1 - 2',
                    children: [
                        {
                            id: '1-2-1',
                            label: 'Child 1 - 2 - 1',
                        },
                    ],
                },
            ],
        },
        {
            id: '2',
            label: 'Parent 2',
        },
    ];
    // eslint-disable-next-line no-console
    console.log(findDeep(treeData, '1-2', 'id', 'children'));
    return (
        <Layout>
            <Grid p={1}>
                <GridItem xs={12}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'findDeep' }} />
                        <Box sx={{ p: 1 }}>
                            <pre>
                                {`
                                    const data: any[] = [
                                        {
                                            id: '1',
                                            label: 'Parent 1',
                                            children: [
                                                {
                                                    id: '1-1',
                                                    label: 'Child 1 - 1',
                                                },
                                                {
                                                    id: '1-2',
                                                    label: 'Child 1 - 2',
                                                    children: [
                                                        {
                                                            id: '1-2-1',
                                                            label: 'Child 1 - 2 - 1',
                                                        },
                                                    ],
                                                },
                                            ],
                                        },
                                        {
                                            id: '2',
                                            label: 'Parent 2'
                                        }
                                    ];

                                    console.log(findDeep(data, '1-2', 'id', 'children'));
                                    // output: {id: '1-2', label: 'Child 1 - 2', children: Array(1)}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default FindDeepPage;
