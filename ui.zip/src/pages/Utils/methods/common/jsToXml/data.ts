export const myJsonData = `{"breakfast_menu":{"food":[{"name":{"_text":"Belgian Waffles"},"price":{"_text":"$5.95"},"description":{"_text":"Two of our famous Belgian Waffles with plenty of real maple syrup"},"calories":{"_text":"650"}},{"name":{"_text":"Strawberry Belgian Waffles"},"price":{"_text":"$7.95"},"description":{"_text":"Light Belgian waffles covered with strawberries and whipped cream"},"calories":{"_text":"900"}},{"name":{"_text":"Berry-Berry Belgian Waffles"},"price":{"_text":"$8.95"},"description":{"_text":"Light Belgian waffles covered with an assortment of fresh berries and whipped cream"},"calories":{"_text":"900"}},{"name":{"_text":"French Toast"},"price":{"_text":"$4.50"},"description":{"_text":"Thick slices made from our homemade sourdough bread"},"calories":{"_text":"600"}},{"name":{"_text":"Homestyle Breakfast"},"price":{"_text":"$6.95"},"description":{"_text":"Two eggs, bacon or sausage, toast, and our ever-popular hash browns"},"calories":{"_text":"950"}}]}}`;
export const myObjectData = {
    breakfast_menu: {
        food: [
            {
                name: { _text: 'Belgian Waffles' },
                price: { _text: '$5.95' },
                description: { _text: 'Two of our famous Belgian Waffles with plenty of real maple syrup' },
                calories: { _text: '650' },
            },
            {
                name: { _text: 'Strawberry Belgian Waffles' },
                price: { _text: '$7.95' },
                description: { _text: 'Light Belgian waffles covered with strawberries and whipped cream' },
                calories: { _text: '900' },
            },
            {
                name: { _text: 'Berry-Berry Belgian Waffles' },
                price: { _text: '$8.95' },
                description: {
                    _text: 'Light Belgian waffles covered with an assortment of fresh berries and whipped cream',
                },
                calories: { _text: '900' },
            },
            {
                name: { _text: 'French Toast' },
                price: { _text: '$4.50' },
                description: { _text: 'Thick slices made from our homemade sourdough bread' },
                calories: { _text: '600' },
            },
            {
                name: { _text: 'Homestyle Breakfast' },
                price: { _text: '$6.95' },
                description: { _text: 'Two eggs, bacon or sausage, toast, and our ever-popular hash browns' },
                calories: { _text: '950' },
            },
        ],
    },
};
