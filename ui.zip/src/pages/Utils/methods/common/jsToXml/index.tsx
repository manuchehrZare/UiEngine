import type { FC } from 'react';
import { Layout } from '../../../../../App';
import { Grid, GridItem, Label, Nav, Paper, jsToXml } from '../../../../../lib';
import { myJsonData } from './data';

const JsToXmlPage: FC = () => {
    return (
        <Layout>
            <Grid>
                <GridItem p={1}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'jsToXml' }} />
                        <Grid spacingType="common" p={1}>
                            <GridItem lg={6}>
                                <Label text="Js Data - (Js Object or JSON Format)" />
                                <Paper
                                    borderBox
                                    sx={{
                                        '&.sekerUI-Paper': {
                                            p: 2,
                                        },
                                    }}>
                                    {myJsonData}
                                </Paper>
                            </GridItem>
                            <GridItem lg={6}>
                                <Label text="XML Data" />
                                <Paper
                                    borderBox
                                    sx={{
                                        '&.sekerUI-Paper': {
                                            p: 2,
                                        },
                                    }}>
                                    {jsToXml(myJsonData)}
                                </Paper>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default JsToXmlPage;
