export interface ILayout {
    children: any;
    showSidebar?: boolean;
}
