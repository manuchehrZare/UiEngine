export interface IHeaderProps {
    actions?: any;
    content?: any;
    subTitle?: string;
    title?: any;
    titleView?: boolean;
}
