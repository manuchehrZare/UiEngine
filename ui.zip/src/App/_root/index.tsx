import type { FC } from 'react';
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import { menu, menuData } from './data';
import { kebabCase, lowerCase, toLower } from 'lodash';
import Home from '../../pages/Home';
import NotFound from '../../pages/Error/NotFound';

const Root: FC = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="*" element={<NotFound />} />
                <Route path={lowerCase(menu.form[0].group)} element={<Navigate to={kebabCase(menu.form[0].text)} />} />
                <Route
                    path={lowerCase(menu.display[0].group)}
                    element={<Navigate to={kebabCase(menu.display[0].text)} />}
                />
                <Route
                    path={lowerCase(menu.others[0].group)}
                    element={<Navigate to={kebabCase(menu.others[0].text)} />}
                />
                <Route
                    path={lowerCase(menu.hooks[0].group)}
                    element={<Navigate to={kebabCase(menu.hooks[0].text)} />}
                />
                <Route
                    path={lowerCase(menu.utils[0].group)}
                    element={<Navigate to={kebabCase(menu.utils[0].text)} />}
                />
                <Route
                    path={lowerCase(menu.example[0].group)}
                    element={<Navigate to={kebabCase(menu.example[0].text)} />}
                />
                {menuData
                    .filter((item) => item.element)
                    .map((item) => {
                        const RouteElement: any = item.element;
                        return (
                            <Route
                                key={kebabCase(item.text)}
                                path={`${toLower(item.group)}/${kebabCase(item.text)}`}
                                element={<RouteElement />}
                            />
                        );
                    })}
            </Routes>
        </Router>
    );
};

export default Root;
