import type { FC } from 'react';
import { Provider, theme } from '../lib';
import Root from './_root';

const App: FC = () => {
    return (
        <Provider
            loadingProps={{ keepMounted: true }}
            globalStyles={{ body: { backgroundColor: theme.palette.grey[50] } }}>
            <Root />
        </Provider>
    );
};

export { default as Layout, Header, Sidebar } from './Layout';
export default App;
