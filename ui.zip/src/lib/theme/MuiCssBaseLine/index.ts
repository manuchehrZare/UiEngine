import type { Components } from '@mui/material';
import { getCssReset } from '../_css_reset';

export const Mui_CssBaseline: Components = {
    MuiCssBaseline: {
        styleOverrides: {
            ...getCssReset(),
        },
    },
};
