import type { Components } from '@mui/material';
import { DesignTypeEnum } from '../../../utils';

export const MuiStepperTheme: Components = {
    MuiStepLabel: {
        styleOverrides: {
            label: {
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.Default})`,
            },
        },
    },
};
