import type { Components, Theme } from '@mui/material';
import { menuItemClasses } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';

export const MuiListTheme: Components = {
    MuiList: {
        styleOverrides: {
            root: {
                padding: 0,
                [`&.${generateClass('Select-MenuList')}`]: {
                    maxHeight: '35vh',
                    [`& .${menuItemClasses.root}`]: {
                        minHeight: '36px',
                    },
                },
                //time-picker
                '.MuiMultiSectionDigitalClock-root &': {
                    '& .MuiMenuItem-root': {
                        fontSize: '0.75rem',
                    },
                },
            },
        },
    },
    MuiListItem: {
        styleOverrides: {
            root: ({ theme }) => ({
                [`&.${generateClass('KeyValueList-item')}`]: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '.5rem 1.5rem',
                    borderBottom: `1px solid ${(theme as Theme).palette.grey[200]}`,

                    '&:last-child': {
                        border: 'none',
                    },
                },
            }),
        },
    },
    MuiListItemText: {
        styleOverrides: {
            root: ({ theme }) => ({
                [`&.${generateClass('KeyValueList-item-text')}`]: {
                    display: 'flex',
                    alignItems: 'flex-start',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    color: (theme as Theme).palette.primary.main,
                    marginTop: '6px',
                    marginBottom: '6px',
                    '&.wrap': {
                        flexDirection: 'column',
                        justifyContent: 'center',

                        [`& > .${generateClass('KeyValueList-item-text-primary')}`]: {
                            marginBottom: 2,
                        },

                        [`& > .${generateClass('KeyValueList-item-text-secondary')}`]: {
                            textAlign: 'left',
                        },
                    },

                    [`& > .${generateClass('KeyValueList-item-text-secondary')}`]: {
                        fontWeight: 400,
                        fontSize: 'var(--field-label-font-size)',
                        lineHeight: 1.2,
                        textAlign: 'right',
                        flex: 2,
                        flexShrink: 0,
                        color: (theme as Theme).palette.primary.main,
                    },

                    [`& > .${generateClass('KeyValueList-item-text-primary')}`]: {
                        fontWeight: 400,
                        fontSize: 'var(--field-label-font-size)',
                        lineHeight: 1.2,
                        flex: 1,
                        flexShrink: 0,
                    },
                },
            }),
        },
    },
};
