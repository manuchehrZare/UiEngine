import type { Components, Theme } from '@mui/material';
import {
    autocompleteClasses,
    filledInputClasses,
    inputBaseClasses,
    inputClasses,
    outlinedInputClasses,
} from '@mui/material';
import { generateClass } from '../../../utils/methods/design';
import { importantStyle } from '../../../utils/methods/style';
import { InputTypeEnum } from '../../../components/Form/Input/type';

export const MuiFieldTheme: Components = {
    MuiInputLabel: {
        styleOverrides: {
            root: ({ ownerState }) => ({
                [`&.${generateClass('Mui-InputBase-Capslock')}`]: {
                    ...(ownerState.className?.split(' ')[1] && {
                        pointerEvents: 'none',
                    }),
                },
            }),
            outlined: ({ ownerState }) => ({
                transform: 'translate(14px, -9px) scale(0.75)',
                ...(!ownerState.shrink && {
                    transform:
                        ownerState.size === 'small'
                            ? 'translate(14px, 8px) scale(1)'
                            : 'translate(14px, 14px) scale(1)',
                    [`.${autocompleteClasses.root} &, .picker-input &, .select-input-base &`]: {
                        maxWidth: 'calc(100% - 50px)',
                    },
                }),
            }),
            filled: ({ ownerState }) => ({
                transform:
                    ownerState.size === 'small'
                        ? 'translate(14px, 0px) scale(0.75)'
                        : 'translate(14px, 4px) scale(0.75)',
                ...(!ownerState.shrink && {
                    transform:
                        ownerState.size === 'small'
                            ? 'translate(14px, 8px) scale(1)'
                            : 'translate(14px, 14px) scale(1)',
                    [`.${autocompleteClasses.root} &, .picker-input &, .select-input-base &`]: {
                        maxWidth: 'calc(100% - 50px)',
                    },
                }),
            }),
            standard: ({ ownerState }) => ({
                transform: 'translate(0px, -8.5px) scale(0.75)',
                ...(!ownerState.shrink && {
                    transform:
                        ownerState.size === 'small' ? 'translate(0px, 8px) scale(1)' : 'translate(0px, 14px) scale(1)',
                    [`.${autocompleteClasses.root} &, .picker-input &, .select-input-base &`]: {
                        maxWidth: 'calc(100% - 25px)',
                    },
                }),
            }),
        },
    },
    MuiInputBase: {
        styleOverrides: {
            root: ({ ownerState, theme }) => ({
                marginTop: importantStyle('0.5px'),

                // Variant : standard
                [`&.${inputClasses.underline}`]: {
                    [`&:not(.${autocompleteClasses.inputRoot})`]: {
                        marginTop: importantStyle('1px'),
                    },
                },

                // Variant : filled
                [`&.${filledInputClasses.underline}`]: {
                    [`&:not(.${autocompleteClasses.inputRoot})`]: {
                        marginTop: importantStyle('1px'),
                    },
                },

                ...(ownerState.type === InputTypeEnum.File && {
                    'input[type=file]::file-selector-button': { visibility: 'hidden', position: 'absolute' },
                    'input[type=file]': {
                        ...(!ownerState?.value && { opacity: '0' }),
                    },
                }),
                [`&.${generateClass('Mui-InputBase-Capslock')}`]: {
                    ...(ownerState.className?.split(' ')[1] && {
                        pointerEvents: 'none',
                    }),
                },
                color: (theme as Theme).palette.primary.main,
                ...(ownerState.readOnly && {
                    color: (theme as Theme).palette.primary.main,
                }),
                [`&.${filledInputClasses.root}`]: {
                    ...(ownerState.multiline && {
                        paddingLeft: '14px',
                        paddingRight: '14px',
                    }),
                },
                [`&.${autocompleteClasses.inputRoot}`]: {
                    paddingBottom: importantStyle('0px'),
                },
                '&.select-input-base': {
                    paddingRight: importantStyle('0px'),

                    [`&.standard`]: {
                        marginTop: '18px',
                        [`&.${inputBaseClasses.sizeSmall}`]: {
                            marginTop: '16px',
                        },
                    },
                },
                ':hover': {
                    '& > .select-svg': {
                        color: importantStyle(`${(theme as Theme).palette.secondary.main}`),
                    },
                },
            }),
            input: ({ ownerState, theme }) => ({
                pointerEvents: 'auto',
                ...(ownerState?.inputProps?.readOnly && {
                    color: (theme as Theme).palette.primary.main,
                }),

                ...(ownerState.size !== 'small' &&
                    !ownerState?.multiline && {
                        // Standard
                        padding: importantStyle('14.5px 0px 14px'),

                        [`.${outlinedInputClasses.root} &`]: {
                            padding: importantStyle('14.5px 14px'),
                        },
                    }),

                ...(ownerState.size === 'small' &&
                    !ownerState?.multiline && {
                        // Standard
                        padding: importantStyle('8.5px 0px 8.5px'),

                        [`.${outlinedInputClasses.root} &`]: {
                            padding: importantStyle('8.5px 14px'),
                        },
                    }),

                [`.${filledInputClasses.root} &`]: {
                    ...(!ownerState.multiline && {
                        ...(ownerState.size !== 'small' && {
                            padding: importantStyle('20.5px 0px 8px'),
                        }),
                        ...(ownerState.size === 'small' && {
                            padding: importantStyle('14.5px 0px 2.5px'),
                        }),
                        [`:not(.${inputBaseClasses.inputAdornedStart})`]: {
                            paddingLeft: importantStyle('14px'),
                            paddingRight: importantStyle('14px'),

                            [`.${autocompleteClasses.root} &`]: {
                                paddingLeft: importantStyle('6px'),
                                paddingRight: importantStyle('6px'),
                            },
                        },
                    }),
                },

                [`.${generateClass('Currency')} &`]: {
                    fontWeight: 'bold',
                },
            }),
        },
    },
    MuiOutlinedInput: {
        styleOverrides: {
            root: ({ ownerState, theme }) => ({
                ...(ownerState.type === InputTypeEnum.Hidden && {
                    '& > fieldset': {
                        border: 'none',
                    },
                }),
                ':hover:not(.Mui-error):not(.Mui-focused)': {
                    '& > fieldset': {
                        borderColor: `${(theme as Theme).palette.grey[700]} !important`,
                    },
                },

                '&.Mui-focused:not(.Mui-error)': {
                    '& > fieldset': {
                        borderColor: `${(theme as Theme).palette.secondary.main} !important`,
                    },
                },
            }),
            notchedOutline: ({ theme }) => ({
                borderColor: (theme as Theme).palette.grey[400],
            }),
        },
    },
    MuiInputAdornment: {
        styleOverrides: {
            root: { pointerEvents: 'auto' },
        },
    },
};
