import type { Components, Theme } from '@mui/material';
import { alpha, filledInputClasses } from '@mui/material';

export const MuiSvgIconTheme: Components = {
    MuiSvgIcon: {
        styleOverrides: {
            root: ({ theme }) => ({
                '&.select-svg': {
                    '.select-input-base &': {
                        position: 'absolute',
                        right: 31,
                        cursor: 'pointer',
                        color: 'transparent',
                        width: '1.2em',
                        height: '1.2em',
                        padding: '5px',

                        ':hover': {
                            backgroundColor: (theme as Theme).palette.grey[50],
                            color: alpha((theme as Theme).palette.common.black, 0.54),
                            borderRadius: '50%',
                        },
                    },
                    '.Mui-focused &': {
                        color: alpha((theme as Theme).palette.common.black, 0.54),
                    },

                    [`.${filledInputClasses.root} &`]: {
                        ':hover': {
                            backgroundColor: (theme as Theme).palette.grey[200],
                        },
                    },
                },
            }),
        },
    },
};
