import type { Components, Theme } from '@mui/material';
import { autocompleteClasses, checkboxClasses, inputBaseClasses, tablePaginationClasses } from '@mui/material';
import type {} from '@mui/x-data-grid-pro/themeAugmentation';
import { dataGridClasses } from '../../..';
import { DesignTypeEnum } from '../../../utils/types/common';
import { palette } from '../../_palette';
import { importantStyle } from '../../../utils/methods/style';
import { generateClass } from '../../../utils/methods/design';

const themeConfig = {
    common: {
        color: 'var(--color-text)',
        border: {
            color: palette.slateGreen[50],
            radius: 4,
            width: 1,
            style: 'solid',
        },
    },
    seperator: {
        border: {
            color: palette.common?.white,
            width: 2,
            style: 'solid',
        },
    },
    header: {
        backgroundColor: palette.slateGreen[100],
        fontWeight: 600,
        fontSize: `var(--field-label-font-size)`,
    },
    cell: {
        fontWeight: 400,
        checkbox: { height: '20px', width: '20px' },
    },
    row: {
        default: {
            backgroundColor: palette.grey[50],
        },
        selected: {
            backgroundColor: palette.green[50],
        },
        hover: {
            backgroundColor: palette.grey[400],
        },
    },
    strippedRows: {
        even: {
            backgroundColor: palette.slateGreen[50],
        },
        selected: {
            backgroundColor: palette.green[50],
        },
        hover: {
            backgroundColor: palette.grey[400],
        },
    },
    footer: {
        borderColor: '',
    },
};

export const MuiDataGridTheme: Components = {
    MuiDataGrid: {
        styleOverrides: {
            root: ({ ownerState }) => ({
                borderRadius: themeConfig.common.border.radius,
                border: `${themeConfig.common.border.width}px ${themeConfig.common.border.style}`,
                ...(!ownerState?.slots?.toolbar && { borderTop: 'none' }),
                borderColor: themeConfig.common.border.color,
                minHeight: '100%',
                fontSize: 'var(--field-font-size)',
                color: themeConfig.common.color,
                '.MuiLinearProgress-root': {
                    height: 2,
                },
                [`.${dataGridClasses.scrollbarFiller}`]: {
                    backgroundColor: themeConfig.header.backgroundColor,
                    border: importantStyle('none'),
                },
                [`.${dataGridClasses.filler}`]: {
                    display: 'none',
                },
                [`.${dataGridClasses.main}`]: {
                    [`.${dataGridClasses.virtualScroller}`]: {
                        [`&.${dataGridClasses['virtualScroller--hasScrollX']}`]: {
                            paddingBottom: 'var(--DataGrid-scrollbarSize)',
                        },
                    },
                },
                '&.strippedRows': {
                    [`.${dataGridClasses.row}`]: {
                        ':nth-of-type(even)': {
                            backgroundColor: themeConfig.strippedRows.even.backgroundColor,
                        },
                        ':hover': {
                            backgroundColor: importantStyle(themeConfig.strippedRows.hover.backgroundColor || ''),
                            [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                                backgroundColor: 'inherit',
                            },
                            [`.${dataGridClasses['cell--pinnedRight']}`]: {
                                backgroundColor: 'inherit',
                            },
                        },
                        '&.Mui-selected, &.Mui-selected:hover': {
                            backgroundColor: themeConfig.strippedRows.selected.backgroundColor,
                            [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                                backgroundColor: 'inherit',
                            },
                            [`.${dataGridClasses['cell--pinnedRight']}`]: {
                                backgroundColor: 'inherit',
                            },
                        },
                    },
                },

                '&.disableMultipleRowSelection': {
                    [`.${dataGridClasses.columnHeaderCheckbox} .${dataGridClasses.columnHeaderTitleContainer}`]: {
                        display: importantStyle('none'),
                    },
                },
            }),

            panel: {
                '.MuiInputBase-root': {
                    height: '40px',
                },
                '.MuiNativeSelect-select': {
                    minWidth: '50px !important',
                },
            },
            columnSeparator: () => ({
                visibility: 'visible',
                backgroundColor: themeConfig.seperator.border.color,
                width: themeConfig.seperator.border.width,
                right: 0,

                svg: {
                    display: 'none',
                },
                ':before': {
                    content: '""',
                    position: 'absolute',
                    width: themeConfig.seperator.border.width,
                    height: '100%',
                    backgroundColor: themeConfig.seperator.border.color,
                },

                [`&.${dataGridClasses['columnSeparator--sideLeft']}`]: {
                    ':before': {
                        left: 12,
                    },
                },
                [`&.${dataGridClasses['columnSeparator--sideRight']}`]: {
                    ':before': {
                        right: 12,
                    },
                },
            }),
            columnHeaders: {
                [`[role="row"]`]: {
                    [`.${dataGridClasses.filler}`]: {
                        display: 'block',
                        backgroundColor: themeConfig.header.backgroundColor,
                    },
                },
            },
            columnHeader: {
                backgroundColor: themeConfig.header.backgroundColor,
                border: importantStyle('none'),
                fontWeight: themeConfig.header.fontWeight,

                [`&.${dataGridClasses['columnHeader--last']}`]: {
                    [`.${dataGridClasses['columnSeparator--sideRight']}`]: {
                        display: 'none',
                    },
                    [`.${dataGridClasses['columnSeparator--sideLeft']}`]: {
                        display: 'none',
                    },
                },

                [`&.${dataGridClasses['columnHeader--pinnedLeft']},`]: {
                    [`.${dataGridClasses['columnSeparator--sideLeft']},${dataGridClasses['columnSeparator--sideRight']}`]:
                        {
                            opacity: importantStyle('1'),
                            right: 0,
                            ':before': {
                                left: 12,
                            },
                        },
                    [`.${dataGridClasses['columnSeparator--sideRight']}`]: {
                        opacity: importantStyle('1'),
                        right: 0,
                        ':before': {
                            right: importantStyle('0'),
                        },
                    },
                },

                [`&.${dataGridClasses['columnHeader--pinnedRight']}`]: {
                    [`.${dataGridClasses['columnSeparator--sideLeft']}`]: {
                        opacity: importantStyle('1'),
                        left: 0,
                        ':before': {
                            left: 12,
                        },
                    },
                    [`.${dataGridClasses['columnSeparator--sideRight']}`]: {
                        opacity: importantStyle('1'),
                        right: 0,
                        ':before': {
                            right: importantStyle('0'),
                        },
                    },
                },

                [`&.${dataGridClasses['columnHeader--alignLeft']}`]: {
                    [`.${dataGridClasses.menuIcon}`]: {
                        marginRight: '-6px',
                    },
                },
                [`&.${dataGridClasses['columnHeader--alignRight']}`]: {
                    [`.${dataGridClasses.menuIcon}`]: {
                        marginLeft: '-8px',
                    },
                },
            },
            menuIcon: {
                marginRight: -6,
            },
            columnHeaderTitle: {
                fontWeight: themeConfig.header.fontWeight,
                [`.${DesignTypeEnum.Default} &`]: {
                    fontSize: themeConfig.header.fontSize,
                },
            },

            row: () => ({
                backgroundColor: themeConfig.row.default.backgroundColor,
                ':hover': {
                    backgroundColor: themeConfig.row.hover.backgroundColor,
                },
                '&.Mui-selected, &.Mui-selected:hover': {
                    backgroundColor: themeConfig.row.selected.backgroundColor,
                    [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                        backgroundColor: themeConfig.strippedRows.selected.backgroundColor,
                    },
                    [`.${dataGridClasses['cell--pinnedRight']}`]: {
                        backgroundColor: themeConfig.strippedRows.selected.backgroundColor,
                    },
                },

                [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                    backgroundColor: 'inherit',
                    border: 'none',
                    borderRight: importantStyle(
                        `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                    ),

                    boxShadow: '2px 0px 4px -2px rgba(0, 0, 0, 0.21)',
                    [`[role="gridcell"]`]: {
                        border: 'none',
                        borderRight: importantStyle(
                            `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                        ),
                    },
                },
                [`.${dataGridClasses['cell--pinnedRight']}`]: {
                    backgroundColor: 'inherit',
                    border: 'none',
                    borderRight: importantStyle(
                        `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                    ),
                    boxShadow: '-2px 0px 4px -2px rgba(0, 0, 0, 0.21)',
                    [`[role="gridcell"]`]: {
                        border: 'none',
                        borderLeft: importantStyle(
                            `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                        ),
                    },
                },
                [`.${dataGridClasses.cellEmpty}`]: {
                    border: 'none',
                },
            }),
            cell: ({ ownerState, theme }) => {
                const getColumnsLength = (): number => {
                    let result = ownerState?.columns?.length || 0;
                    result -= result - (ownerState?.apiRef?.current?.getVisibleColumns().length || 0);

                    return result;
                };
                return {
                    borderTop: 0,
                    borderBottom: 0,
                    borderWidth: themeConfig.seperator.border.width,
                    borderColor: themeConfig.seperator.border.color,
                    borderRightStyle: 'solid',

                    [`&[role="gridcell"]:nth-of-type(${getColumnsLength() + 1})`]: {
                        border: 'none',
                    },
                    '&--textCenter': {
                        [`.MuiFormControl-root`]: {
                            alignItems: 'center',
                        },
                    },

                    [`.${checkboxClasses.root}`]: {
                        [`&.${checkboxClasses.checked}`]: {
                            color: (theme as Theme).palette.secondary.main,
                        },
                    },
                    [`&.${dataGridClasses.cellCheckbox}`]: {
                        [`.${checkboxClasses.root}`]: {
                            svg: {
                                width: themeConfig.cell.checkbox.width,
                                height: themeConfig.cell.checkbox.height,
                            },
                        },
                    },
                    [`.${generateClass('checkbox')}`]: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: importantStyle('100%'),
                        svg: {
                            width: themeConfig.cell.checkbox.width,
                            height: themeConfig.cell.checkbox.height,
                        },
                        '&.checked': {
                            svg: { color: (theme as Theme).palette.secondary.main },
                        },
                    },

                    [`.${autocompleteClasses.root}`]: {
                        [`.${inputBaseClasses.root}`]: {
                            maxHeight: '34px',
                        },
                    },

                    fontWeight: themeConfig.cell.fontWeight,
                    color: themeConfig.common.color,

                    [`.${DesignTypeEnum.Default} &`]: {
                        fontSize: 'var(--field-font-size)',
                    },
                };
            },

            footerContainer: () => {
                return {
                    fontSize: 'var(--field-font-size)',
                    borderColor: themeConfig.common.border.color,
                    [`& .${tablePaginationClasses.root}`]: {
                        display: 'flex',
                        overflow: 'hidden',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        [`.${tablePaginationClasses.spacer}`]: {
                            display: 'none',
                        },
                        [`.${tablePaginationClasses.displayedRows}`]: {
                            fontSize: 'var(--field-font-size)',
                        },

                        [`.${tablePaginationClasses.actions}`]: {
                            '.MuiButtonBase-root': {
                                '.MuiSvgIcon-root': {
                                    fontSize: 'calc(var(--field-font-size) * 1.5)',
                                },
                            },
                        },
                    },
                };
            },
            menu: {
                '.MuiList-root': {
                    '.MuiMenuItem-root': {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                },
            },
            paper: {
                minWidth: 200,
            },
            panelHeader: {
                [`.${DesignTypeEnum.Default} &`]: {
                    label: {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                    input: {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                },
            },
            panelContent: {
                [`.${DesignTypeEnum.Default} &`]: {
                    span: {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                },
            },
            panelFooter: {
                [`.${DesignTypeEnum.Default} &`]: {
                    '.MuiButton-root ': {
                        fontSize: 'var(--field-font-size)',
                    },
                },
            },
            filterForm: {
                [`.${DesignTypeEnum.Default} &`]: {
                    label: {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                    input: {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                    select: {
                        fontSize: 'var(--field-font-size)',
                        color: themeConfig.common.color,
                    },
                },
            },
            pinnedColumns: {
                [`&.${dataGridClasses.pinnedColumns}`]: { backgroundColor: 'transparent' },
            },
            columnsManagement: ({ theme }) => ({
                '.MuiSwitch-thumb': {
                    color: `${importantStyle((theme as Theme).palette.common.white)}`,
                },
            }),
        },
    },
};
