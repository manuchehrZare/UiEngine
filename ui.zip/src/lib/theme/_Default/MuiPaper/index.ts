import type { Components, Theme } from '@mui/material';
import { constants, generateClass } from '../../..';

export const MuiPaperTheme: Components = {
    MuiPaper: {
        styleOverrides: {
            root: ({ theme }) => ({
                boxShadow: '0 1px 2px var(--shadow-2)',
                color: 'var(--color-text)',
                fontSize: 'var(--field-label-font-size)',

                '&.border-box': {
                    border: `${constants.design.border.paper.borderBox.default.width}px solid ${
                        (theme as Theme).palette.slateGreen[100]
                    }`,
                    boxShadow: 'none',
                    background: 'none',
                },

                [`&.${generateClass('Select-Paper')}`]: {
                    border: `1px solid ${(theme as Theme).palette.grey[400]}`,
                    boxShadow: 'none',
                },
            }),
        },
    },
};
