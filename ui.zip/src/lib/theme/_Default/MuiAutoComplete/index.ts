import type { Components, Theme } from '@mui/material';
import { alpha, filledInputClasses, outlinedInputClasses } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';
import { importantStyle } from '../../../utils';

export const MuiAutocompleteTheme: Components = {
    MuiAutocomplete: {
        styleOverrides: {
            root: {
                [`& .${generateClass('selectedItems-summary')}`]: {
                    paddingRight: '0px',

                    [`&.outlined`]: {
                        paddingLeft: '8px',
                    },

                    [`&.filled`]: {
                        paddingLeft: '6px',
                    },
                },
                [`& .${filledInputClasses.root}`]: {
                    padding: '0px 0px 0px 10px',
                },
                [`.${outlinedInputClasses.root}`]: {
                    padding: importantStyle('0px'),
                },
            },
            input: ({ ownerState, theme }) => ({
                ...(ownerState.readOnly && {
                    color: alpha((theme as Theme).palette.common.black, 0.38),
                }),
            }),
            endAdornment: {
                '& .disablePopupIconRotate': {
                    transform: 'none',
                },
            },
            listbox: {
                maxHeight: '35vh',
            },
            option: {
                minHeight: '36px !important',
            },
        },
    },
};
