import type { Components, Theme } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';

export const MuiGridTheme: Components = {
    MuiGrid: {
        styleOverrides: {
            root: ({ theme }) => ({
                minWidth: 'auto',
                [`&.${generateClass('NavRow')}`]: {
                    width: '100%',
                    [`& .${generateClass('Grid')}`]: {
                        '&:first-of-type': {
                            flexShrink: 1,
                        },
                    },
                },

                [`&.${generateClass('NavItem')}`]: {
                    '.small &': {},
                },

                [`.${generateClass('NavTitle-box')}`]: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'flex-start',
                    paddingRight: '1rem',
                },

                [`.${generateClass('NavBackButton-box')}`]: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'flex-start',

                    paddingRight: '1rem',
                },

                [`.${generateClass('NavTitle-label')}`]: {
                    fontSize: 'var(--field-font-size)',

                    '.small &': {
                        fontSize: 'calc(var(--field-font-size) - 2px)',
                    },
                },

                [`.${generateClass('NavTitle')}`]: {
                    fontSize: 'calc(var(--field-font-size) + 2px)',

                    '.small &': {
                        fontSize: 'var(--field-font-size)',
                    },
                },

                [`.${generateClass('NavTitle-sub')}`]: {
                    lineHeight: 1.5,
                    fontSize: 'calc(var(--field-font-size) + 1px)',

                    '.small &': {
                        fontSize: 'calc(var(--field-font-size) - 1px)',
                    },
                },

                [`&.${generateClass('NavContainer')}`]: {
                    position: 'relative',
                    zIndex: 'auto',
                    width: '100%',

                    '&.sticky-top, &.sticky-bottom': {
                        position: 'sticky',
                        zIndex: 2,
                        backgroundColor: (theme as Theme).palette.common.white,
                    },

                    '&.sticky-top': {
                        top: 0,
                    },

                    '&.sticky-bottom': {
                        bottom: 0,
                    },
                },
            }),
        },
    },
};
