import type { Components, Theme } from '@mui/material';

const config = {
    fontSize: 'var(--field-label-font-size)',
    borderWidth: 1,
};

export const MuiDividerTheme: Components = {
    MuiDivider: {
        styleOverrides: {
            root: ({ theme }) => ({
                borderColor: (theme as Theme).palette.slateGreen[100],
                borderBottomWidth: config.borderWidth,
                fontSize: config.fontSize,
                color: (theme as Theme).palette.primary.main,
            }),
            vertical: {
                borderRightWidth: config.borderWidth,
            },
            withChildren: ({ theme }) => ({
                ':before, :after': {
                    borderColor: (theme as Theme).palette.slateGreen[100],
                    borderTopWidth: config.borderWidth,
                },
            }),
            withChildrenVertical: ({ theme }) => ({
                ':before, :after': {
                    borderColor: (theme as Theme).palette.slateGreen[100],
                    borderLeftWidth: config.borderWidth,
                },
            }),
        },
    },
};
