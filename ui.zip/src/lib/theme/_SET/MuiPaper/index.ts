import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';
import { DesignTypeEnum } from '../../../utils/types/common';
import { constants } from '../../../utils/constants';

export const MuiPaperTheme: Components = {
    MuiPaper: {
        styleOverrides: {
            root: ({ theme }) => ({
                boxShadow: `0px 1px 2px ${alpha((theme as Theme).palette.common.black, 0.25)}`,
                color: 'var(--color-text)',
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,

                [`&.${generateClass('Paper')}`]: {
                    padding: `${(theme as Theme).spacing(2)} ${(theme as Theme).spacing(3)}`,
                    border: `${constants.design.border.paper.common.SET.width}px solid ${
                        (theme as Theme).palette.grey[300]
                    }`,
                },

                [`&.${generateClass('Select-Paper')}`]: {
                    border: `1px solid ${(theme as Theme).palette.grey[400]}`,
                    boxShadow: 'none',
                },

                '&.border-box': {
                    boxShadow: 'none',
                    background: 'none',
                    borderWidth: constants.design.border.paper.borderBox.SET.width,
                },

                '&.custom-picker': {
                    '& .MuiCalendarPicker-root': {
                        '& [role="presentation"]': {
                            fontSize: '0.9rem',
                        },
                        '& .MuiCalendarPicker-viewTransitionContainer': {
                            '& .MuiTypography-caption, & .MuiPickersDay-root': {
                                fontSize: '0.7rem',
                            },
                        },
                    },
                },
            }),
        },
    },
};
