import type { Components } from '@mui/material';
import { DesignTypeEnum } from '../../..';

export const MuiSliderTheme: Components = {
    MuiSlider: {
        defaultProps: {
            color: 'secondary',
        },
        styleOverrides: {
            root: ({ ownerState }) => ({
                padding: '9px 0px',
                '& .MuiSlider-thumb': {
                    ...(ownerState.size === 'small' && {
                        width: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                        height: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                    }),
                    ...(ownerState.size === 'medium' && {
                        width: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 4px)`,
                        height: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 4px)`,
                    }),
                },
            }),
            vertical: {
                padding: '0px 9px',
                '& input[type="range"]': {
                    WebkitAppearance: 'slider-vertical',
                },
            },
            valueLabel: ({ ownerState, theme }: any) => ({
                backgroundColor: theme?.palette[ownerState.color || theme.components.MuiSlider.defaultProps.color].main,
            }),
        },
    },
};
