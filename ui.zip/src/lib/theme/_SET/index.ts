import type { Components } from '@mui/material';
import { MuiAccordionTheme } from './MuiAccordion';
import { MuiAlertTheme } from './MuiAlert';
import { MuiAutocompleteTheme } from './MuiAutocomplete';
import { MuiBreadcrumbsTheme } from './MuiBreadcrumbs';
import { MuiButtonTheme } from './MuiButton';
import { MuiCheckboxTheme } from './MuiCheckbox';
import { MuiChipTheme } from './MuiChip';
import { MuiDataGridTheme } from './MuiDataGrid';
import { MuiDialogTheme } from './MuiDialog';
import { MuiDividerTheme } from './MuiDivider';
import { MuiFieldTheme } from './MuiField';
import { MuiFormTheme } from './MuiForm';
import { MuiGridTheme } from './MuiGrid';
import { MuiIconButtonTheme } from './MuiIconButton';
import { MuiListTheme } from './MuiList';
import { MuiMenuTheme } from './MuiMenu';
import { MuiPaginationTheme } from './MuiPagination';
import { MuiPaperTheme } from './MuiPaper';
import { MuiRadioTheme } from './MuiRadio';
import { MuiRatingTheme } from './MuiRating';
import { MuiSelectTheme } from './MuiSelect';
import { MuiSliderTheme } from './MuiSlider';
import { MuiStepperTheme } from './MuiStepper';
import { MuiSvgIconTheme } from './MuiSvgIcon';
import { MuiSwitchTheme } from './MuiSwitch';
import { MuiTabTheme } from './MuiTab';
import { MuiTooltipTheme } from './MuiTooltip';
import { MuiTreeViewTheme } from './MuiTreeView';

const ComponentsTheme: Components = {
    ...MuiAccordionTheme,
    ...MuiAlertTheme,
    ...MuiAutocompleteTheme,
    ...MuiBreadcrumbsTheme,
    ...MuiButtonTheme,
    ...MuiCheckboxTheme,
    ...MuiChipTheme,
    ...MuiDataGridTheme,
    ...MuiDialogTheme,
    ...MuiDividerTheme,
    ...MuiFieldTheme,
    ...MuiFormTheme,
    ...MuiGridTheme,
    ...MuiIconButtonTheme,
    ...MuiListTheme,
    ...MuiMenuTheme,
    ...MuiPaginationTheme,
    ...MuiPaperTheme,
    ...MuiRadioTheme,
    ...MuiRatingTheme,
    ...MuiSelectTheme,
    ...MuiSliderTheme,
    ...MuiStepperTheme,
    ...MuiSvgIconTheme,
    ...MuiSwitchTheme,
    ...MuiTabTheme,
    ...MuiTooltipTheme,
    ...MuiTreeViewTheme,
};

export default ComponentsTheme;
