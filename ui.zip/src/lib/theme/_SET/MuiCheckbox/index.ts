import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiCheckboxTheme: Components = {
    MuiCheckbox: {
        styleOverrides: {
            root: ({ ownerState, theme }) => {
                const color = ((theme as Theme).palette as any)[
                    ownerState?.color && ownerState.color !== 'default' ? ownerState.color : 'secondary'
                ].main;
                const size = ownerState.size === 'small' ? 16 : 20;
                return {
                    color: color,
                    borderRadius: `var(--field-border-radius-${DesignTypeEnum.SET})`,
                    padding: '0.35px 3.5px !important',

                    '& span': {
                        [`&.icon-${DesignTypeEnum.SET}, &.checked-icon-${DesignTypeEnum.SET}`]: {
                            width: size,
                            height: size,
                        },
                        [`&.icon-${DesignTypeEnum.SET}`]: {
                            border: `1px solid ${(theme as Theme).palette.grey[600]}`,
                            borderRadius: `var(--field-border-radius-${DesignTypeEnum.SET})`,
                            backgroundColor: (theme as Theme).palette.common.white,
                        },
                        [`&.checked-icon-${DesignTypeEnum.SET}`]: {
                            backgroundColor: color,
                            borderRadius: `var(--field-border-radius-${DesignTypeEnum.SET})`,

                            '& .MuiSvgIcon-root': {
                                fontSize: size,
                                color: (theme as Theme).palette.common.white,
                            },
                        },
                    },

                    'input:disabled': {
                        [`& + span.icon-${DesignTypeEnum.SET}`]: {
                            backgroundColor: alpha((theme as Theme).palette.grey[300], 0.3),
                            borderColor: (theme as Theme).palette.grey[500],
                        },
                        [`& + span.checked-icon-${DesignTypeEnum.SET}`]: {
                            backgroundColor: (theme as Theme).palette.grey[400],
                        },
                    },
                };
            },
        },
    },
};
