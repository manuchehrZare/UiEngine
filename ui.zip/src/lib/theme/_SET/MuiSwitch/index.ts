import type { Components, Theme } from '@mui/material';

const themeConfig = {
    padding: 0,
    margin: '0px',
    overflow: 'visible',
    small: {
        width: 30,
        height: 16,
    },
    medium: {
        width: 36,
        height: 20,
    },
    thumb: {
        small: {
            width: 14,
            height: 14,
        },
        medium: {
            width: 18,
            height: 18,
        },
    },
};

export const MuiSwitchTheme: Components = {
    MuiSwitch: {
        styleOverrides: {
            root: ({ theme }) => ({
                width: themeConfig.medium.width,
                height: themeConfig.medium.height,
                padding: themeConfig.padding,
                margin: themeConfig.margin,
                overflow: themeConfig.overflow,
                '& .MuiSwitch-switchBase': {
                    padding: themeConfig.padding,
                    margin: 1,
                    transitionDuration: '300ms',
                    '&.Mui-checked': {
                        transform: 'translateX(16px)',
                        color: (theme as Theme).palette.common.white,
                        margin: 1,
                        '& + .MuiSwitch-track': {
                            backgroundColor: (theme as Theme).palette.secondary.main,
                            opacity: 1,
                            border: 0,
                        },
                        '&.Mui-disabled + .MuiSwitch-track': {
                            opacity: 0.5,
                        },
                    },
                    '&.Mui-focusVisible .MuiSwitch-thumb': {
                        color: (theme as Theme).palette.secondary.main,
                        border: `6px solid ${(theme as Theme).palette.common.white}`,
                    },
                    '&.Mui-disabled .MuiSwitch-thumb': {
                        color: (theme as Theme).palette.grey[500],
                    },
                    '&.Mui-disabled + .MuiSwitch-track': {
                        opacity: 0.8,
                    },
                },
                '& .MuiSwitch-thumb': {
                    boxSizing: 'border-box',
                    width: themeConfig.thumb.medium.width,
                    height: themeConfig.thumb.medium.height,
                },
                '& .MuiSwitch-track': {
                    borderRadius: themeConfig.medium.height / 2,
                    backgroundColor: (theme as Theme).palette.grey[300],
                    opacity: 1,
                    transition: (theme as Theme).transitions.create(['background-color'], {
                        duration: 500,
                    }),
                    height: themeConfig.medium.height,
                },
            }),
            sizeSmall: ({ theme }) => ({
                width: themeConfig.small.width,
                height: themeConfig.small.height,
                padding: themeConfig.padding,
                overflow: themeConfig.overflow,
                marginTop: 2,

                '& .MuiSwitch-switchBase': {
                    '&.Mui-checked': {
                        '& .MuiSwitch-thumb': {
                            marginLeft: '-2px',
                        },
                    },
                },
                '& .MuiSwitch-thumb': {
                    boxSizing: 'border-box',
                    width: themeConfig.thumb.small.width,
                    height: themeConfig.thumb.small.height,
                },
                '& .MuiSwitch-track': {
                    borderRadius: themeConfig.small.height / 2,
                    backgroundColor: (theme as Theme).palette.grey[200],
                    opacity: 1,
                    transition: (theme as Theme).transitions.create(['background-color'], {
                        duration: 500,
                    }),
                    height: themeConfig.small.height,
                },
            }),
        },
    },
};
