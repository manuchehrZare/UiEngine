import type { Components, Theme } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { alpha, generateClass, importantStyle, menuClasses, menuItemClasses } from '../../..';

export const MuiMenuTheme: Components = {
    MuiMenu: {
        styleOverrides: {
            root: {
                '& .breadcrumbs-select': {
                    padding: importantStyle('2px 10px 2px 10px'),
                    fontSize: 'var(--field-label-font-size)',
                },
                [`.${menuClasses.list}`]: {
                    [`.${menuItemClasses.root}`]: { fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})` },
                },
            },
            list: {
                [`.${menuClasses.root}[aria-hidden] &`]: {
                    pointerEvents: 'none',
                },
            },
        },
    },
    MuiMenuItem: {
        styleOverrides: {
            root: ({ theme }) => ({
                [`.${generateClass('Select-MenuList')} &`]: {
                    minHeight: '36px',
                    borderBottom: `1px solid ${(theme as Theme).palette.grey[400]}`,

                    '&:last-child': {
                        borderBottom: 'none',
                    },

                    '&.Mui-disabled': {
                        backgroundColor: (theme as Theme).palette.grey[200],
                        color: (theme as Theme).palette.primary[500],
                    },

                    '&.Mui-selected': {
                        backgroundColor: (theme as Theme).palette.grey[300],
                    },

                    ':hover:not(.Mui-selected)': {
                        backgroundColor: alpha((theme as Theme).palette.green.main, 0.1),
                    },
                },
            }),
        },
    },
};
