import type { Components } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { GlobalFont } from '../../_css_global';
import { generateClass } from '../../../utils/methods/design';
import { importantStyle } from '../../../utils/methods/style';

export const MuiTooltipTheme: Components = {
    MuiTooltip: {
        styleOverrides: {
            tooltip: ({ theme, ownerState }: any) => ({
                [`&.${generateClass('VRKeyboard-tooltip')}`]: {
                    maxWidth: 'none !important',
                    color: theme.palette.common.black,
                    padding: '0',
                    borderRadius: '10px',
                    '.MuiTooltip-arrow': {
                        width: '3em',
                        height: '1.3em',
                        marginTop: '-1.3em',
                    },
                    '.MuiTooltip-arrow::before': {
                        backgroundColor: theme.palette.grey[50],
                        boxShadow: '0 0 2px var(--shadow-4)',
                    },
                    '& .hg-theme-default': {
                        backgroundColor: theme.palette.grey[50],
                        fontFamily: GlobalFont,
                        boxShadow: '0 2px 5px 0 var(--shadow-2)',
                        fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                        '.hg-button': {
                            backgroundColor: theme.palette.common.white,
                        },
                        '.hg-activeButton': {
                            backgroundColor: theme.palette.grey[100],
                        },
                    },
                    '&.numeric': {
                        '.MuiTooltip-arrow': {
                            ...((ownerState?.placement === 'bottom-start' || ownerState?.placement === 'top-start') && {
                                transform: 'translate(30px, 0px) !important',
                            }),
                            ...((ownerState?.placement === 'bottom-end' || ownerState?.placement === 'top-end') && {
                                transform: 'translate(90px, 0px) !important',
                            }),
                            ...((ownerState?.placement === 'top' || ownerState?.placement === 'bottom') && {
                                transform: 'translate(63px, 0px) !important',
                            }),
                            ...(ownerState?.placement === 'top' ||
                            ownerState?.placement === 'top-start' ||
                            ownerState?.placement === 'top-end'
                                ? { marginBottom: '-1.3em' }
                                : { marginTop: '-1.3em' }),
                        },
                    },
                    '&.trLayout': {
                        '.MuiTooltip-arrow': {
                            ...((ownerState?.placement === 'bottom-start' || ownerState?.placement === 'top-start') && {
                                transform: 'translate(30px, 0px) !important',
                            }),
                            ...((ownerState?.placement === 'bottom-end' || ownerState?.placement === 'top-end') && {
                                transform: 'translate(395px, 0px) !important',
                            }),
                            ...((ownerState?.placement === 'top' || ownerState?.placement === 'bottom') && {
                                transform: 'translate(210px, 0px) !important',
                            }),
                            ...((ownerState?.placement === 'left-start' ||
                                ownerState?.placement === 'right-start' ||
                                ownerState?.placement === 'left-end' ||
                                ownerState?.placement === 'right-end') && {
                                transform: 'translate(-25px, 32px) !important',
                            }),
                            ...(ownerState?.placement === 'top' ||
                            ownerState?.placement === 'top-start' ||
                            ownerState?.placement === 'top-end'
                                ? { marginBottom: '-1.3em' }
                                : { marginTop: '-1.3em' }),
                        },
                    },
                    '& .vr-keyboard-btn': {
                        fontWeight: 600,
                    },
                },
                padding: 8,
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) * 0.85)`,
            }),
            popper: ({ ownerState }: any) => ({
                '&[data-popper-placement="bottom"], &[data-popper-placement="bottom-end"], &[data-popper-placement="bottom-start"]':
                    {
                        ...(ownerState?.componentsProps?.popper?.className !== generateClass('VRKeyboard-popper') && {
                            '.MuiTooltip-tooltip': {
                                marginTop: importantStyle('0.71em'),
                            },
                        }),
                    },
                '&[data-popper-placement="top"], &[data-popper-placement="top-end"], &[data-popper-placement="top-start"]':
                    {
                        ...(ownerState?.componentsProps?.popper?.className !== generateClass('VRKeyboard-popper') && {
                            '.MuiTooltip-tooltip': {
                                marginBottom: importantStyle('0.71em'),
                            },
                        }),
                    },
                '&[data-popper-placement="left"], &[data-popper-placement="left-end"], &[data-popper-placement="left-start"]':
                    {
                        ...(ownerState?.componentsProps?.popper?.className !== generateClass('VRKeyboard-popper') && {
                            '.MuiTooltip-tooltip': {
                                marginRight: importantStyle('0.71em'),
                            },
                        }),
                    },
                '&[data-popper-placement="right"], &[data-popper-placement="right-end"], &[data-popper-placement="right-start"]':
                    {
                        ...(ownerState?.componentsProps?.popper?.className !== generateClass('VRKeyboard-popper') && {
                            '.MuiTooltip-tooltip': {
                                marginLeft: importantStyle('0.71em'),
                            },
                        }),
                    },
            }),
        },
    },
};
