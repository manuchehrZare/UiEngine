import type { Components, Theme } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

const tabConfig = {
    item: {
        marginRight: 20,
    },
    scrollButtons: {
        fontSize: '1rem',
        height: '1rem',
    },
};

export const MuiTabTheme: Components = {
    MuiTabs: {
        styleOverrides: {
            root: ({ theme }) => ({
                width: '100%',
                minHeight: 'auto',
                borderBottom: 1,
                borderStyle: 'solid',
                borderColor: (theme as Theme).palette.secondary[100],
            }),
            flexContainer: {
                height: '100%',
            },
            indicator: ({ theme }) => ({
                backgroundColor: (theme as Theme).palette.green.light,
                height: 3.75,
                borderTopLeftRadius: 10,
                borderTopRightRadius: 10,
            }),
            scrollButtons: ({ theme }) => ({
                color: (theme as Theme).palette.primary.main,
                transition: 'width .3s',
                alignItems: 'flex-start',

                '&.is-small': {
                    svg: {
                        height: tabConfig.scrollButtons.height,
                        fontSize: tabConfig.scrollButtons.fontSize,
                    },
                },

                '&.Mui-disabled': {
                    width: 0,
                },
            }),
        },
    },
    MuiTab: {
        styleOverrides: {
            root: ({ theme }) => ({
                minWidth: 0,
                marginRight: tabConfig.item.marginRight,
                color: (theme as Theme).palette.secondary[200],
                fontWeight: 600,
                textTransform: 'none',
                minHeight: 'auto',
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                justifyContent: 'flex-start',
                padding: '0px 4px 6px 4px',

                '&:last-child': {
                    marginRight: 0,
                },
                '&.Mui-selected': {
                    color: (theme as Theme).palette.secondary.main,
                },
                '.is-small &': {
                    paddingBottom: 5,
                    fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 1px)`,
                },
            }),
        },
    },
};
