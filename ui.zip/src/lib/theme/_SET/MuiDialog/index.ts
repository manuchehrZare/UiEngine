import type { Components, Theme } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { generateClass } from '../../../utils/methods/design';

export const MuiDialogTheme: Components = {
    MuiDialogTitle: {
        styleOverrides: {
            root: ({ theme }) => ({
                textAlign: 'center',
                borderBottom: `1px solid ${(theme as Theme).palette.grey[300]}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 'bold',
                position: 'sticky',
                top: 0,
                zIndex: 2,
                background: (theme as Theme).palette.grey[50],
                color: (theme as Theme).palette.green.main,
                padding: '.5rem 1rem',
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 2px)`,
                minHeight: 39.39, // if title === ''

                '.close-icon &': {
                    padding: '.5rem 2rem .5rem 1rem',
                },
                '.drag-icon &': {
                    padding: '.5rem 3.5rem .5rem 1rem',
                },
            }),
        },
    },
    MuiDialogActions: {
        styleOverrides: {
            root: ({ theme }) => ({
                position: 'sticky',
                bottom: 0,
                zIndex: 2,
                background: (theme as Theme).palette.grey[50],
                borderTop: `1px solid ${(theme as Theme).palette.grey[300]}`,
                justifyContent: 'center',

                [`&.${generateClass('Confirm-Modal-Footer')}`]: {
                    [`.${DesignTypeEnum.SET} &`]: {
                        [`.${generateClass('Grid')}`]: {
                            flexDirection: 'row-reverse',
                        },
                    },
                },
            }),
        },
    },
    MuiDialogContent: {
        styleOverrides: {
            root: ({ theme }) => ({
                padding: 0,
                background: (theme as Theme).palette.grey[50],
            }),
        },
    },
    MuiDialog: {
        styleOverrides: {
            root: {
                boxShadow: 'var(--box-shadow-2)',
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            },
            paper: {
                boxShadow: 'var(--box-shadow-2)',
                '& .modal-close-icon': {
                    position: 'absolute',
                    right: 9,
                    top: 9,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 3,

                    svg: {
                        width: `calc(var(--field-height-${DesignTypeEnum.SET}) - 4px) !important`,
                        height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 4px) !important`,
                    },
                },
                '& .modal-drag-icon': {
                    position: 'absolute',
                    right: 30,
                    top: 9,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 3,

                    svg: {
                        width: `calc(var(--field-height-${DesignTypeEnum.SET}) - 4px) !important`,
                        height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 4px) !important`,
                    },
                },
                '& .confirm-drag-icon': {
                    position: 'absolute',
                    right: 7,
                    top: 7,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 3,

                    svg: {
                        width: `calc(var(--field-height-${DesignTypeEnum.SET}) - 4px) !important`,
                        height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 4px) !important`,
                    },
                },
                '& form': {
                    width: '100%',
                    maxHeight: 'calc(100vh - 64px)',
                    display: 'flex',
                    flexDirection: 'column',
                },

                '&.fullHeight': {
                    height: window.innerHeight - 64,
                },
            },
        },
    },
    MuiDrawer: {
        styleOverrides: {},
        defaultProps: {
            PaperProps: {
                sx: {
                    backgroundColor: (theme) => theme.palette.grey[50],
                },
            },
        },
    },
};
