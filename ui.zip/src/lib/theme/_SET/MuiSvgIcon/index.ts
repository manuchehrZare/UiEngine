import type { Components, Theme } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiSvgIconTheme: Components = {
    MuiSvgIcon: {
        styleOverrides: {
            root: ({ theme }) => ({
                '&.select-svg': {
                    '.select-input-base &': {
                        position: 'absolute',
                        right: 20,
                        cursor: 'pointer',
                        width: `var(--field-height-${DesignTypeEnum.SET})`,
                        height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,
                        color: (theme as Theme).palette.common.white,
                        fontSize: `calc(var(--field-font-size-${DesignTypeEnum.SET}) + 1px) !important`,
                        padding: '2px !important',
                        ':hover': {
                            backgroundColor: (theme as Theme).palette.grey[50],
                            color: (theme as Theme).palette.primary.light,
                        },
                    },
                    '.Mui-focused &': {
                        color: (theme as Theme).palette.primary.light,
                    },
                },
            }),
        },
    },
};
