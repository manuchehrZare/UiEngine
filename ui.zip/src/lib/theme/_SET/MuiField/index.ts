import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { InputTypeEnum } from '../../../components/Form/Input/type';
import { constants } from '../../../utils/constants';
import { generateClass } from '../../../utils/methods/design';

export const MuiFieldTheme: Components = {
    MuiInputLabel: {
        styleOverrides: {
            root: ({ ownerState, theme }) => {
                return {
                    cursor: 'text',
                    transform: 'none',
                    position: 'relative',
                    color: (theme as Theme).palette.common.black,
                    flexShrink: 0,
                    fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                    fontWeight: 400,
                    lineHeight: `var(--field-height-${DesignTypeEnum.SET})`,
                    zIndex: 1,

                    ...(ownerState.children && {
                        '&:not(.top)': {
                            paddingRight: '5px',
                        },
                        width: `var(--field-label-width-${DesignTypeEnum.SET})`,
                    }),

                    '&.top': {
                        maxWidth: '100%',
                        width: '100%',
                    },

                    [`&.${constants.classNames.labelEllipsis}`]: {
                        height: `var(--field-height-${DesignTypeEnum.SET})`,

                        '&.top': {
                            position: 'absolute',
                            top: 0,
                        },
                    },

                    [`&:not(.${constants.classNames.labelEllipsis})`]: {
                        whiteSpace: 'pre-line',
                        overflow: 'initial',
                        textOverflow: 'initial',
                        height: 'auto',
                    },

                    '&.Mui-disabled, &.Mui-focused:not(&.Mui-error)': {
                        color: (theme as Theme).palette.common.black,
                    },
                };
            },
        },
    },
    MuiInputBase: {
        styleOverrides: {
            root: ({ ownerState, theme }) => ({
                ...(ownerState.type === InputTypeEnum.File && {
                    'input[type=file]::file-selector-button': { visibility: 'hidden', position: 'absolute' },
                    'input[type=file]': {
                        ...(!ownerState?.value && { opacity: '0' }),
                    },
                }),

                [`&.${generateClass('Mui-InputBase-Capslock')}`]: {
                    ...(ownerState.className?.split(' ')[1] && {
                        pointerEvents: 'none',
                    }),
                },

                border: `1px solid ${(theme as Theme).palette.lightGrey[600]}`,
                borderRadius: `var(--field-border-radius-${DesignTypeEnum.SET})`,
                backgroundColor: (theme as Theme).palette.common.white,
                fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                padding: '0 5px',
                color: (theme as Theme).palette.common.black,

                [`.top.${constants.classNames.labelEllipsis} &`]: {
                    marginTop: `var(--field-height-${DesignTypeEnum.SET})`,
                },

                ...(!ownerState.multiline && {
                    height: `var(--field-height-${DesignTypeEnum.SET})`,
                }),

                ...((ownerState?.readOnly || ownerState?.inputProps?.readOnly) && {
                    borderColor: (theme as Theme).palette.lightGrey[500],
                    backgroundColor: alpha((theme as Theme).palette.grey[100], 0.6),
                }),

                '&.Mui-focused:not(&.Mui-error)': {
                    borderColor: (theme as Theme).palette.secondary.main,
                },

                '&.Mui-disabled': {
                    borderColor: (theme as Theme).palette.lightGrey[400],
                    color: alpha((theme as Theme).palette.common.black, 0.6),
                },

                '&.picker-input': {
                    '& .MuiSvgIcon-root': {
                        color: (theme as Theme).palette.secondary.main,
                        ...(ownerState?.disabled && {
                            color: alpha((theme as Theme).palette.common.black, 0.5),
                        }),
                        ...(ownerState?.inputProps?.readOnly && {
                            color: alpha((theme as Theme).palette.common.black, 0.5),
                        }),
                    },
                    padding: '0 5px',
                },
                ':hover': {
                    '& > .select-svg': {
                        color: `${alpha((theme as Theme).palette.common.black, 0.5)} !important`,
                    },
                },
            }),
            input: ({ ownerState, theme }) => ({
                pointerEvents: 'auto',
                padding: 0,
                height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,

                '.picker-input &': {
                    height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,
                    padding: 0,
                },

                ...(ownerState?.inputProps?.readOnly && {
                    color: (theme as Theme).palette.common.black,
                }),

                '&.Mui-disabled': {
                    WebkitTextFillColor: alpha((theme as Theme).palette.common.black, 0.6),
                },
            }),
            error: ({ theme }) => ({
                borderColor: (theme as Theme).palette.error.main,
            }),
        },
    },
    MuiOutlinedInput: {
        styleOverrides: {
            root: {
                borderRadius: `var(--field-border-radius-${DesignTypeEnum.SET})`,
                padding: 0,

                '.picker-input &': {
                    padding: '0 5px',
                },

                '& > fieldset': {
                    border: 'none',
                },
            },
        },
    },
    MuiInputAdornment: {
        styleOverrides: {
            root: ({ theme }) => ({
                pointerEvents: 'auto',
                height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,
                marginLeft: 4,

                '& > .MuiTypography-root': {
                    fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                    lineHeight: 1,
                },
                '& .MuiButton-root.Mui-disabled': {
                    backgroundColor: `${(theme as Theme).palette.grey[400]} !important`,
                },
                '&:not(.MuiButton-root, .MuiIconButton-root, .icon-button)': {
                    //svgıcon
                    '.Mui-disabled &': {
                        color: `${alpha((theme as Theme).palette.common.black, 0.6)} !important`,
                    },
                },

                '.select-input-base &': {
                    marginRight: 0,

                    '& > .MuiTypography-root': {
                        marginLeft: '5px',
                    },
                },
            }),
            positionEnd: () => ({
                '.MuiIconButton-root, .MuiButton-root, .icon-button': {
                    height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 1.5px)`,
                    minHeight: `calc(var(--field-height-${DesignTypeEnum.SET}) - 1.5px)`,
                    width: `var(--field-height-${DesignTypeEnum.SET})`,
                    boxShadow: 'none',
                    svg: {
                        height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 6px) !important`,
                        width: `calc(var(--field-height-${DesignTypeEnum.SET}) - 6px) !important`,
                    },

                    '.picker-input &': {
                        marginRight: -5,
                    },
                },
                '.MuiIconButton-root, .icon-button': {
                    borderRadius: 0,
                    borderTopRightRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,
                    borderBottomRightRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,

                    '.picker-input &': {
                        marginRight: -5,
                    },
                },

                '.MuiButton-root': {
                    '&.icon-button': {
                        minWidth: `var(--field-height-${DesignTypeEnum.SET})`,
                    },
                },
            }),
            positionStart: {
                '.MuiIconButton-root, .MuiButton-root, .icon-button': {
                    height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 1.5px)`,
                    minHeight: `calc(var(--field-height-${DesignTypeEnum.SET}) - 1.5px)`,
                    width: `var(--field-height-${DesignTypeEnum.SET})`,
                    boxShadow: 'none',
                    svg: {
                        height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 6px) !important`,
                        width: `calc(var(--field-height-${DesignTypeEnum.SET}) - 6px) !important`,
                    },
                },

                '.MuiIconButton-root, .icon-button': {
                    borderRadius: 0,
                    borderTopLeftRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,
                    borderBottomLeftRadius: `calc(var(--field-border-radius-${DesignTypeEnum.SET}) / 2)`,
                },

                '.MuiButton-root': {
                    '&.icon-button': {
                        minWidth: `var(--field-height-${DesignTypeEnum.SET})`,
                    },
                },
            },
        },
    },
};
