import type { Components } from '@mui/material';
import type {} from '@mui/lab/themeAugmentation';

export const MuiMasonryTheme: Components = {
    MuiMasonry: {
        styleOverrides: {
            root: {
                width: 'auto',
            },
        },
    },
};
