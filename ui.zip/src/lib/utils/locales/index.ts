import { set } from 'lodash';
import { useTranslation as usei18nTranslation } from 'react-i18next';
import { i18n, i18nInit, i18nInitialize, languageStorageKey } from '../../locales/i18n';
import localeTR from '../../locales/translations/tr';
import { deepCopy, setLocalStorageItem } from '../methods';
import type { ChangeLanguageOptions, LocalesType } from './type';
import { LocalesEnum } from './type';
//@ts-ignore
import deepKeys from 'deep-keys';

/**
 * @param lng New Language Value
 * @param reload for window.location.reload active param. ( default : true )
 */
export const i18nChangeLanguage = ({ lng, callback, reload }: ChangeLanguageOptions): void => {
    document.documentElement.lang = lng;
    document.documentElement.setAttribute('lang', lng);
    setLocalStorageItem(languageStorageKey, lng);
    const prevLng = i18n.language;
    prevLng !== lng && reload !== false && window.location.reload();
    setTimeout(() => i18n.changeLanguage(lng, callback), 0);
};

const getLocaleData = () => {
    const localeData = deepCopy(localeTR);

    const keyArr = deepKeys(localeData);

    keyArr.forEach((path: any) => {
        set(localeData, path, path.replace('.', ':'));
    });
    return localeData;
};

// eslint-disable-next-line
export const useTranslation = () => {
    const params = usei18nTranslation();
    return { ...params, locale: getLocaleData() };
};

const locale = getLocaleData() as any;

export { i18n, i18nInit, i18nInitialize, languageStorageKey, locale, LocalesEnum };
export type { ChangeLanguageOptions, LocalesType };
