// _Locales
export {
    locale,
    i18n,
    i18nChangeLanguage,
    i18nInit,
    i18nInitialize,
    languageStorageKey,
    useTranslation,
} from './locales';
export type { ChangeLanguageOptions } from './locales';

// Validations
export { validation, ValidationsCompareTypeEnum } from './validations';

/** METHODS */
export { default as manageClassNames } from 'classnames';
export { enqueueSnackbar as message, closeSnackbar as closeMessage } from 'notistack';
export { default as printer } from 'prntr';
export { alpha } from '@mui/material';
export {
    asyncForEach,
    base64Decryption,
    base64Encryption,
    base64ToDataUri,
    cardNumberFormatter,
    cleanDeep,
    confirm,
    currency,
    deepCopy,
    deepKeysAsArray,
    deepKeysAsObject,
    deepmerge,
    excelToJson,
    exportHtmlToPDF,
    exportHtmlToText,
    exportTable,
    exportWord,
    fileDownloader,
    findDeep,
    generateClass,
    getBgColorByClassName,
    getComponentDesignProperty,
    getComputedStyles,
    getCookie,
    getDateFromExcelDate,
    getExcelDateFromDate,
    getFileSize,
    getLocalStorageItem,
    getNow,
    getProviderDesign,
    getProviderTheme,
    getSessionStorageItem,
    groupString,
    hideLoading,
    iban,
    importantStyle,
    isBase64,
    isDataUri,
    isNumeric,
    isParsableToJson,
    isXmlString,
    jsToXml,
    jsonToQueryString,
    millisecondsToTime,
    numberFormat,
    phoneNumberFormatter,
    queryStringToJSON,
    randomColor,
    randomNumber,
    removeCookie,
    removeLocalStorageItem,
    removeProviderDesign,
    removeProviderTheme,
    removeSessionStorageItem,
    replaceTRtoENChars,
    sanitizeHTML,
    scrollToElement,
    scrollToTop,
    setCookie,
    setLocalStorageItem,
    setProviderDesign,
    setProviderTheme,
    setSessionStorageItem,
    showLoading,
    sleep,
    stringHTMLToJSX,
    stripHtmlFromText,
    timeToMilliseconds,
    txtToString,
    xmlToJs,
} from './methods';

/** TYPES */
export type {
    ComputedStyles,
    ExcelToJsonAcceptType,
    ExcelToJsonReturnType,
    ExcelToJsonSheetRangeType,
    ExcelToJsonSheetRowsType,
    GetFlashAnimationCSSOptions,
    IConfirm,
    IExcelToJsonOptions,
    IExcelToJsonSheetCell,
    IExcelToJsonSheetRangeValues,
    IExportTableColumns,
    IExportTableDateOptions,
    IExportTableProps,
    INumberFormatOptions,
    IPhoneNumberFormatterOptions,
    ReplaceTRtoEnCharsConfig,
} from './methods';
export type { FixedSizeArray } from './types/array';
export type { DesignType } from './types/common';
export type { DeepRequired, HelperComponentProps, HelperFormProps } from './types/helper';
export type { IMessageProviderProps, IMessageVariantOverrides, MessageCustomContentProps } from './types/message';
export type { Enumerate, PositiveRange } from './types/number';
export type { Now, Time, TimeReturnValues } from './types/time';

/** ENUMS */
export { DesignTypeEnum } from './types/common';
export { BgColorEnum, FileExtentionsEnum } from './methods';
export { MessageTypeEnum } from './types/message';
export { PrinterTypeEnum } from './types/printer';

/** CONSTANTS */
export { constants } from './constants';
export { FileAcceptValues, FileTypes, mimeTypes } from './methods';
export { sharedIntersectionObserver, sharedMutationObserver, sharedResizeObserver } from './types/observer';
export { sharedEventListener } from './types/listener';
