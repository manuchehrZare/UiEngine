import queryString from 'query-string';

export const queryStringToJSON = (query: string): object => {
    return queryString.parse(query, { parseBooleans: true, arrayFormat: 'comma', parseNumbers: true });
};

export const jsonToQueryString = <T extends object>(data: T): string => {
    return queryString.stringify(data, { arrayFormat: 'comma', skipEmptyString: true, skipNull: false });
};
