import { createConfirmation } from 'react-confirm';
import type { IConfirmMessageModalProps } from './ConfirmMessageModal';
import ConfirmMessageModal from './ConfirmMessageModal';

const reactConfirm = createConfirmation(ConfirmMessageModal);

export interface IConfirm extends Omit<IConfirmMessageModalProps, 'proceed' | 'show'> {}

export const confirm = (options?: IConfirm): Promise<unknown> => {
    return options ? reactConfirm(options as IConfirmMessageModalProps) : reactConfirm({} as IConfirmMessageModalProps);
};
