import { chunk } from 'lodash';

type GroupStringOptions = {
    repeatPattern?: boolean;
    returnArray?: boolean;
    separator?: string;
};
/**
 * Function that partitions a string into segments based on specified grouping rules.
 * @param value The string to be partitioned.
 * @param pattern The grouping pattern - can be a single number or an array of numbers.
 * @param repeatPattern Repeat the entire pattern (true) or only the last element (false).
 * @param separator The separator character between groups (default: space).
 * @returns The grouped string.
 */
export const groupString = (
    value: string,
    pattern: number | number[],
    options?: GroupStringOptions,
): string | string[] => {
    if (!value) return '';

    const defaultOptions: GroupStringOptions = {
        repeatPattern: false,
        separator: ' ',
        returnArray: false,
    };

    const opts = { ...defaultOptions, ...options };

    let groupSizes: number[];
    if (typeof pattern === 'number') {
        groupSizes = [pattern];
    } else if (Array.isArray(pattern)) {
        groupSizes = pattern;
    } else {
        throw new Error('Pattern must be a number or an array of numbers');
    }

    const chars = value.split('');
    let result: string[] = [];

    if (groupSizes.length === 1) {
        const chunkSize = groupSizes[0];
        result = chunk(chars, chunkSize).map((item) => item.join(''));
    } else {
        // group by pattern
        let currentIndex = 0;
        let patternIndex = 0;

        while (currentIndex < chars.length) {
            let currentGroupSize;

            if (patternIndex < groupSizes.length) {
                currentGroupSize = groupSizes[patternIndex];
            } else if (opts.repeatPattern) {
                //if repeatPattern true repeat
                currentGroupSize = groupSizes[patternIndex % groupSizes.length];
            } else {
                // if repeatPattern false, use last element
                currentGroupSize = groupSizes[groupSizes.length - 1];
            }

            const endIndex = Math.min(currentIndex + currentGroupSize, chars.length);

            result.push(chars.slice(currentIndex, endIndex).join(''));

            currentIndex = endIndex;
            patternIndex++;
        }
    }

    return opts.returnArray ? result : result.join(opts.separator);
};
