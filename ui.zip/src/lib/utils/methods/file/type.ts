// See https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types for more about file MIME types.

export enum FileExtentionsEnum {
    CSV = 'csv',
    DOC = 'doc',
    DOCX = 'docx',
    GIF = 'gif',
    HTM = 'htm',
    HTML = 'html',
    JPEG = 'jpeg',
    JPG = 'jpg',
    PDF = 'pdf',
    PNG = 'png',
    PPT = 'ppt',
    PPTX = 'pptx',
    SVG = 'svg',
    TXT = 'txt',
    WEBP = 'webp',
    XLS = 'xls',
    XLSX = 'xlsx',
    XML = 'xml',
}
export const mimeTypes = {
    [FileExtentionsEnum.CSV]: 'text/csv',
    [FileExtentionsEnum.DOCX]: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    [FileExtentionsEnum.DOC]: 'application/msword',
    [FileExtentionsEnum.GIF]: 'image/gif',
    [FileExtentionsEnum.HTML]: 'text/html',
    [FileExtentionsEnum.JPEG]: 'image/jpeg',
    [FileExtentionsEnum.JPG]: 'image/jpeg',
    [FileExtentionsEnum.PDF]: 'application/pdf',
    [FileExtentionsEnum.PNG]: 'image/png',
    [FileExtentionsEnum.PPTX]: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    [FileExtentionsEnum.PPT]: 'application/vnd.ms-powerpoint',
    [FileExtentionsEnum.SVG]: 'image/image/svg+xml',
    [FileExtentionsEnum.TXT]: 'text/plain',
    [FileExtentionsEnum.WEBP]: 'image/webp',
    [FileExtentionsEnum.XLSX]: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    [FileExtentionsEnum.XLS]: 'application/vnd.ms-excel',
    [FileExtentionsEnum.XML]: 'application/xml',
};
interface IFileAcceptValues {
    CSV: `${Extract<FileExtentionsEnum, FileExtentionsEnum.CSV>}`[];
    EXCEL: `${Extract<FileExtentionsEnum, FileExtentionsEnum.XLS | FileExtentionsEnum.XLSX>}`[];
    HTML: `${Extract<FileExtentionsEnum, FileExtentionsEnum.HTML | FileExtentionsEnum.HTM>}`[];
    JPEG: `${Extract<FileExtentionsEnum, FileExtentionsEnum.JPEG | FileExtentionsEnum.JPG>}`[];
    PDF: `${Extract<FileExtentionsEnum, FileExtentionsEnum.PDF>}`[];
    PNG: `${Extract<FileExtentionsEnum, FileExtentionsEnum.PNG>}`[];
    SVG: `${Extract<FileExtentionsEnum, FileExtentionsEnum.SVG>}`[];
    TXT: `${Extract<FileExtentionsEnum, FileExtentionsEnum.TXT>}`[];
    WORD: `${Extract<FileExtentionsEnum, FileExtentionsEnum.DOC | FileExtentionsEnum.DOCX>}`[];
    XML: `${Extract<FileExtentionsEnum, FileExtentionsEnum.XML>}`[];
}

export const FileAcceptValues: IFileAcceptValues = {
    CSV: [FileExtentionsEnum.CSV],
    EXCEL: [FileExtentionsEnum.XLS, FileExtentionsEnum.XLSX],
    HTML: [FileExtentionsEnum.HTML, FileExtentionsEnum.HTM],
    JPEG: [FileExtentionsEnum.JPEG, FileExtentionsEnum.JPG],
    PDF: [FileExtentionsEnum.PDF],
    PNG: [FileExtentionsEnum.PNG],
    SVG: [FileExtentionsEnum.SVG],
    TXT: [FileExtentionsEnum.TXT],
    WORD: [FileExtentionsEnum.DOC, FileExtentionsEnum.DOCX],
    XML: [FileExtentionsEnum.XML],
};

export const FileTypes: Record<keyof IFileAcceptValues, string[]> = {
    CSV: [mimeTypes[FileExtentionsEnum.CSV]],
    HTML: [mimeTypes[FileExtentionsEnum.HTML]],
    EXCEL: [mimeTypes[FileExtentionsEnum.XLS], mimeTypes[FileExtentionsEnum.XLSX]],
    JPEG: [mimeTypes[FileExtentionsEnum.JPEG]],
    PDF: [mimeTypes[FileExtentionsEnum.PDF]],
    PNG: [mimeTypes[FileExtentionsEnum.PNG]],
    SVG: [mimeTypes[FileExtentionsEnum.SVG]],
    TXT: [mimeTypes[FileExtentionsEnum.TXT]],
    WORD: [mimeTypes[FileExtentionsEnum.DOC], mimeTypes[FileExtentionsEnum.DOCX]],
    XML: [mimeTypes[FileExtentionsEnum.XML], 'text/xml', 'application/atom+xml'],
};
