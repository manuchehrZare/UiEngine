import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Packer, Document, TableRow, TableCell, Table, Paragraph, WidthType } from 'docx';
import FileSaver from 'file-saver';
import { FileExtentionsEnum } from '../type';
import { format, fromUnixTime, getUnixTime } from 'date-fns';
import './_Font_SourceSansPro-Regular-normal.js';
import type { DataGridColDef } from '../../../..';

export interface IExportTableDateOptions {
    dataFormat: string;
    dataKeys: string[];
    expectedFormat: string;
}

export interface IExportTableColumns extends Pick<DataGridColDef, 'field' | 'headerName'> {}

export interface IExportTableProps<T extends object> {
    columns: IExportTableColumns[];
    csvSeparator?: string;
    data: T[];
    dateOptions?: IExportTableDateOptions;
    fileExtension: `${Extract<
        FileExtentionsEnum,
        | FileExtentionsEnum.CSV
        | FileExtentionsEnum.DOC
        | FileExtentionsEnum.DOCX
        | FileExtentionsEnum.PDF
        | FileExtentionsEnum.XLS
        | FileExtentionsEnum.XLSX
    >}`;
    fileName: string;
}

export const exportTable = <T extends object>({
    data,
    columns,
    fileName,
    fileExtension,
    csvSeparator,
    dateOptions,
}: IExportTableProps<T>): void => {
    const newData = data.map((item: any) => {
        Object.keys(item).forEach((key) => {
            if (dateOptions?.dataKeys.includes(key) && item[key]) {
                item[key] = format(
                    fromUnixTime(
                        getUnixTime(
                            new Date(
                                Number(
                                    item[key].substring(
                                        String(dateOptions.dataFormat).indexOf('y'),
                                        String(dateOptions.dataFormat).lastIndexOf('y') + 1,
                                    ),
                                ),
                                Number(
                                    item[key].substring(
                                        String(dateOptions.dataFormat).indexOf('M'),
                                        String(dateOptions.dataFormat).lastIndexOf('M') + 1,
                                    ),
                                ) - 1,
                                Number(
                                    item[key].substring(
                                        String(dateOptions.dataFormat).indexOf('d'),
                                        String(dateOptions.dataFormat).lastIndexOf('d') + 1,
                                    ),
                                ),
                            ),
                        ),
                    ),
                    dateOptions.expectedFormat,
                );
            }
            if (fileExtension === FileExtentionsEnum.CSV && item[key]) {
                item[key] = `${item[key]}\u200B`;
            }
        });
        return item;
    });
    const headers: any = columns.map((item) => {
        return item.headerName;
    });
    const sortedKeys = columns.map((item) => {
        return item.field;
    });
    const sortedData = newData.map((item: any) => {
        const obj: any = {};
        for (const key of sortedKeys) {
            obj[key] = item[key];
        }
        return obj;
    });
    const ws = XLSX.utils.book_new();
    XLSX.utils.sheet_add_aoa(ws, [headers]);
    XLSX.utils.sheet_add_json(ws, sortedData, { origin: 'A2', skipHeader: true });
    if (fileExtension === FileExtentionsEnum.CSV) {
        const BOM = '\uFEFF';
        const csvFile = BOM + XLSX.utils.sheet_to_csv(ws, { FS: csvSeparator });
        const csvFinalData = new Blob([csvFile], { type: fileExtension });
        FileSaver.saveAs(csvFinalData, `${fileName}.${fileExtension}`, { autoBom: true });
    } else if (fileExtension === FileExtentionsEnum.XLS || fileExtension === FileExtentionsEnum.XLSX) {
        const wb = { Sheets: { data: ws }, SheetNames: ['data'] };
        const excelBuffer = XLSX.write(wb, { bookType: fileExtension, type: 'array', cellStyles: true });
        const finalData = new Blob([excelBuffer], { type: fileExtension });
        FileSaver.saveAs(finalData, `${fileName}.${fileExtension}`);
    } else if (fileExtension === FileExtentionsEnum.PDF) {
        const doc = new jsPDF();
        autoTable(doc, {
            theme: 'grid',
            headStyles: {
                fillColor: '#FFFFFF',
                lineWidth: 0.1,
                lineColor: '#2c2c2c',
                textColor: '#000',
            },
            bodyStyles: { lineColor: '#2c2c2c', font: 'SourceSansPro-Regular' },
            head: [headers],
            body: data.map((item: any) => {
                return Object.values(item);
            }),
        });
        doc.save(`${fileName}.${fileExtension}`);
    } else if (fileExtension === FileExtentionsEnum.DOC || fileExtension === FileExtentionsEnum.DOCX) {
        const newTestData = data.map((item: any) => {
            return Object.values(item);
        });
        const newArray = [headers, ...newTestData];
        const table = new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
                ...newArray.map((item) => {
                    return new TableRow({
                        children: item.map((itemItem: any) => {
                            return new TableCell({
                                width: { size: 100 / headers.length, type: WidthType.PERCENTAGE },
                                children: itemItem ? [new Paragraph(String(itemItem))] : [new Paragraph('')],
                            });
                        }),
                    });
                }),
            ],
        });
        const doc = new Document({
            sections: [
                {
                    children: [table],
                },
            ],
        });
        Packer.toBlob(doc).then((blob) => {
            FileSaver.saveAs(blob, `${fileName}.${fileExtension}`);
        });
    }
};
