import FileSaver from 'file-saver';
import { FileExtentionsEnum, mimeTypes } from '../type';
import { base64ToDataUri, isDataUri, isXmlString } from '../../../..';

interface IFileDownloaderProps {
    fileName: string;
    source: Blob | string;
    sourceType: `${FileExtentionsEnum}`;
}

export const fileDownloader = async ({ source, sourceType, fileName }: IFileDownloaderProps): Promise<void> => {
    const downloadWithPicker = async (data: Blob | string) => {
        let finalDownload: Blob | null = null;
        if (data instanceof Blob) {
            finalDownload = data;
        } else if (isDataUri(data)) {
            const blobOfDataUri = await fetch(data).then((r) => r.blob());
            finalDownload = blobOfDataUri;
        } else if (isXmlString(data)) {
            finalDownload = new Blob([data], {
                type: (mimeTypes as any)[FileExtentionsEnum.XML],
            });
        } else {
            const dataUri = base64ToDataUri(data, sourceType);
            const blobOfDataUri = await fetch(dataUri).then((r) => r.blob());
            finalDownload = blobOfDataUri;
        }
        if (finalDownload) {
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await (window as any).showSaveFilePicker({
                        startIn: 'downloads',
                        suggestedName: fileName,
                        ...(sourceType && {
                            types: [
                                {
                                    accept: {
                                        [(mimeTypes as any)[
                                            FileExtentionsEnum[
                                                sourceType.toUpperCase() as keyof typeof FileExtentionsEnum
                                            ]
                                        ] || 'application/octet-stream']: [`.${sourceType.toLowerCase()}`],
                                    },
                                },
                            ],
                        }),
                    });
                    const writable = await handle.createWritable();
                    await writable.write(finalDownload);
                    await writable.close();
                } catch (error) {
                    if (error instanceof Error) {
                        switch (error.name) {
                            case 'AbortError':
                                // açılan pencere cancel ile kapatılırsa
                                // eslint-disable-next-line
                                console.error(error);
                                break;
                            case 'SecurityError':
                                // güvenlik hatası (user gesture olmaması gibi)
                                // eslint-disable-next-line
                                console.error(error);
                                FileSaver.saveAs(finalDownload, fileName);
                                break;
                            case 'TypeError':
                                // dosya adı geçersiz olduğunda (başında . olması gibi) veya geçersiz mime type olması
                                // eslint-disable-next-line
                                console.error(error);
                                FileSaver.saveAs(finalDownload, fileName);
                                break;
                            default:
                                // api de başka hata olmadığı yazıyor ancak geliştirme gelmesi durumunda
                                // bu switch patlamasın diye default eklemesi bu şekilde yapıldı
                                // eslint-disable-next-line
                                console.error(error);
                                FileSaver.saveAs(finalDownload, fileName);
                        }
                    } else {
                        // eslint-disable-next-line
                        console.error(error);
                    }
                }
            } else FileSaver.saveAs(finalDownload, fileName);
        }
    };
    await downloadWithPicker(source);
};
