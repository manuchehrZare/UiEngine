import { Buffer } from 'buffer';
import type { AnalyseResult } from 'chardet';
import { analyse, detect } from 'chardet';
import { decode } from 'iconv-lite';

/**
 * Returns decoded base64 data.
 * @param data base64 data to convert.
 * @param encoding Charset of base64 data. It could be one of the ISO family or windows, UTF etc. Default is UTF-8. https://encoding.spec.whatwg.org/
 * @returns T or null
 */
export const base64Decryption = <T>(
    data: string,
    encoding?: string,
): { analyse: AnalyseResult; data: T | null; detectEncoding: string | null } | undefined => {
    if (data && data.length > 0 && data.trim().length > 0) {
        const default_Encoding = 'UTF-8';
        const buffer = Buffer.from(data, 'base64');
        const detectAnalyse = analyse(buffer);
        const detectEncoding =
            detectAnalyse?.find((item) => item.lang === 'tr' || item.confidence === 100)?.name ||
            detect(buffer) ||
            default_Encoding;

        try {
            return {
                data: JSON.parse(decode(buffer, encoding || detectEncoding)),
                analyse: detectAnalyse,
                detectEncoding,
            };
            // eslint-disable-next-line
        } catch (e) {
            return {
                data: String(decode(buffer, encoding || detectEncoding)) as T,
                analyse: detectAnalyse,
                detectEncoding,
            };
        }
    }
    return undefined;
};
