export { base64Decryption, base64Encryption, base64ToDataUri, isBase64 } from './base64';
