import { constants } from '../../..';

/**
 * If the Provider's 'keepMounted' property in loadingProps is set to true, it will run actively.
 * They are used to manage the LoadingModal component in the Provider.
 * LoadingModal must have hidden={true} property.
 */
export const showLoading = (id?: string): void => {
    const loadingEl = document?.getElementById(id || constants.key.PROVIDER_LOADING_ID);
    loadingEl?.removeAttribute('hidden'); // * Loading Activated
};

/**
 * If the Provider's 'keepMounted' property in loadingProps is set to true, it will run actively.
 * They are used to manage the LoadingModal component in the Provider.
 * LoadingModal must have hidden={true} property.
 */
export const hideLoading = (id?: string): void => {
    const loadingEl = document?.getElementById(id || constants.key.PROVIDER_LOADING_ID);
    loadingEl?.setAttribute('hidden', ''); // * Loading Deactivated
};
