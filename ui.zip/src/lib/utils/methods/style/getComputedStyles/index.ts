// Define the type for computed styles, which maps the CSS property names to their string values
export type ComputedStyles = Record<keyof CSSStyleDeclaration, string>;

/**
 * Utility function to get all computed CSS styles of an element as a key-value map.
 * The keys are the CSS property names, and the values are their corresponding computed values.
 *
 * @param element - The DOM element whose computed styles you want to retrieve.
 * @returns A map of computed styles, where each key is a CSS property and each value is the computed value for that property.
 */
export const getComputedStyles = (element: Element): ComputedStyles => {
    const computedStyles = window.getComputedStyle(element);
    const styles: ComputedStyles = {} as ComputedStyles;

    for (let i = 0; i < computedStyles.length; i++) {
        const key = computedStyles[i] as keyof CSSStyleDeclaration; // Ensuring key is valid;
        // Get the value of the current style property and add it to the styles object
        styles[key] = computedStyles.getPropertyValue(key as string);
    }
    return styles;
};
