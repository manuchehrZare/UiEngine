import { randomNumber } from '../../..';
// Export
export { getBgColorByClassName } from './getBgColorByClassName';
export { getComputedStyles } from './getComputedStyles';

export const importantStyle = (styleValue: string): string => `${styleValue} !important`;

export const randomColor = (): string => `#${(randomNumber(0, 0xffffff) << 0).toString(16).padStart(6, '0')}`;

/**
 * TYPES
 */
export type { GetFlashAnimationCSSOptions } from './getBgColorByClassName';
export type { ComputedStyles } from './getComputedStyles';

/**
 * ENUMS
 */
export { BgColorEnum } from './getBgColorByClassName';
