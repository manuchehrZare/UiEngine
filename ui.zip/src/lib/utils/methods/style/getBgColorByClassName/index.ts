import type { Theme, CSSSelectorObjectOrCssVariables } from '../../../../../lib';
import { importantStyle } from '../../../../../lib';
import type { CustomPaletteColorOptions } from '../../../../theme/_palette';

export enum BgColorEnum {
    Error = 'error',
    Info = 'info',
    Primary = 'primary',
    Secondary = 'secondary',
    Success = 'success',
    Warning = 'warning',
}

export type GetFlashAnimationCSSOptions = {
    bgColor: `${BgColorEnum}`;
    className: string;
    colorTone?: keyof CustomPaletteColorOptions;
    flashing?: boolean;
};

/**
 * @param className specific class name that you can use this method css
 * @param bgColor background color by theme colors
 * @param flashing this makes blink to background
 * @default false
 * @param colorTone tone of background color
 * @returns
 * @description colorTone for error 100, others 200
 */
export const getBgColorByClassName = ({
    className,
    bgColor,
    flashing,
    colorTone,
}: GetFlashAnimationCSSOptions): CSSSelectorObjectOrCssVariables<Theme> => {
    const getColorCode = () => {
        if (colorTone) return colorTone;
        switch (bgColor) {
            case BgColorEnum.Error:
                return 100;
            default:
                return 200;
        }
    };

    setTimeout(() => {
        const itemList = document.getElementsByClassName(className);
        if (itemList.length > 0) {
            for (const item of itemList) {
                item.addEventListener('animationiteration', () => {
                    setTimeout(() => {
                        for (const animatedItem of document.getAnimations()) {
                            if ((animatedItem as any).animationName === `${className}Effect`)
                                animatedItem.startTime = 0;
                        }
                    });
                });
            }
        }
    });

    return {
        [`.${className}:not(.Mui-selected)`]: {
            ...(flashing
                ? {
                      animation: `${className}Effect 1s linear 1s infinite alternate`,
                      [`@keyframes ${className}Effect`]: {
                          /*  '0%': {
                              backgroundColor: 'transparent',
                          }, */
                          '100%': {
                              backgroundColor: (theme: Theme) => `${theme.palette[`${bgColor}`][getColorCode()]}`,
                          },
                      },
                  }
                : {
                      backgroundColor: (theme: Theme) =>
                          `${importantStyle(theme.palette[`${bgColor}`][getColorCode()] || '')}`,
                      ':hover': {
                          backgroundColor: (theme: Theme) =>
                              `${importantStyle(theme.palette[`${bgColor}`][getColorCode()] || '')}`,
                      },
                  }),
        },
    };
};
