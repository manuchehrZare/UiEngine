import type { Now, PositiveRange, Time, TimeReturnValues } from '../../..';

/**
 * Returns the current system date/time broken into individual components.
 * No parameters required — always fetches current local system time.
 * @returns {Now} Current time snapshot
 */
export const getNow = (): Now => {
    const now = new Date();
    return {
        years: now.getFullYear(),
        months: now.getMonth() as PositiveRange<1, 12>,
        days: now.getDate() as PositiveRange<1, 32>,
        hours: now.getHours(),
        minutes: now.getMinutes(),
        seconds: now.getSeconds(),
        milliseconds: now.getMilliseconds(),
    };
};

/**
 * Converts a Time object into total milliseconds
 * @param time - Time object to convert
 * @returns total milliseconds
 */
export const timeToMilliseconds = (time: Time): number => {
    return time.hours * 3600000 + time.minutes * 60000 + time.seconds * 1000 + time.milliseconds;
};

/**
 * Converts milliseconds into a Time object (hours, minutes, seconds, milliseconds)
 * @param ms - Total milliseconds to convert
 * @param returnValues - Object indicating which time components should be returned.
 * @default returnValues : { hours: true, milliseconds: true, minutes: true, seconds: true }
 * @returns Time object with selected components
 */
export const millisecondsToTime = (ms: number, returnValues?: TimeReturnValues): Time => {
    const currenReturnValues: TimeReturnValues = {
        hours: true,
        milliseconds: true,
        minutes: true,
        seconds: true,
        ...returnValues,
    };
    const hours = currenReturnValues?.hours ? Math.floor(ms / 3600000) : 0;
    const minutes = currenReturnValues?.minutes
        ? currenReturnValues?.hours
            ? Math.floor((ms % 3600000) / 60000)
            : Math.floor(ms / 60000)
        : 0;
    const seconds = currenReturnValues?.seconds
        ? currenReturnValues?.minutes
            ? Math.floor((ms % 60000) / 1000)
            : Math.floor(ms / 1000)
        : 0;
    const milliseconds = currenReturnValues?.milliseconds
        ? currenReturnValues?.seconds
            ? Math.floor(ms % 1000)
            : Math.floor(ms)
        : 0;
    return { hours, minutes, seconds, milliseconds };
};
