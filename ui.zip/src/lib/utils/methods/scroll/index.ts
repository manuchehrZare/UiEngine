export const scrollToElement = (elementId: string): void => {
    const el = document.getElementById(elementId);
    if (el) {
        el.scrollIntoView({ block: 'start', behavior: 'smooth' });
    } else {
        // eslint-disable-next-line
        console.warn(`Scroll target element is not found: ${elementId}`);
    }
};

export const scrollToTop = (_rootElementId: string = 'root'): void => {
    scrollToElement(_rootElementId);
};
