import type { StorageValueType } from '../../..';
import { constants } from '../../..';

export const getLocalStorageItem = <T>(key: string): StorageValueType<T> => {
    const item: any = window.localStorage.getItem(key);
    try {
        return JSON.parse(item);
        // eslint-disable-next-line
    } catch (e) {
        return item;
    }
};

export const setLocalStorageItem = <T>(key: string, value: T): void => {
    const oldValue = JSON.stringify(getLocalStorageItem<T>(key));
    const newValue = JSON.stringify(value);
    window.localStorage.setItem(key, newValue);
    window.dispatchEvent(new StorageEvent(constants.key.StorageEventName, { key, newValue, oldValue }));
};

export const removeLocalStorageItem = (key: string): void => {
    const oldValue = JSON.stringify(getLocalStorageItem(key));
    window.localStorage.removeItem(key);
    window.dispatchEvent(new StorageEvent(constants.key.StorageEventName, { key, oldValue }));
};

export const getSessionStorageItem = <T>(key: string): StorageValueType<T> => {
    const item: any = window.sessionStorage.getItem(key);
    try {
        return JSON.parse(item);
        // eslint-disable-next-line
    } catch (e) {
        return item;
    }
};

export const setSessionStorageItem = <T>(key: string, value: T): void => {
    const oldValue = JSON.stringify(getSessionStorageItem<T>(key));
    const newValue = JSON.stringify(value);
    window.sessionStorage.setItem(key, newValue);
    window.dispatchEvent(new StorageEvent(constants.key.StorageEventName, { key, newValue, oldValue }));
};

export const removeSessionStorageItem = (key: string): void => {
    const oldValue = JSON.stringify(getLocalStorageItem(key));
    window.sessionStorage.removeItem(key);
    window.dispatchEvent(new StorageEvent(constants.key.StorageEventName, { key, oldValue }));
};
