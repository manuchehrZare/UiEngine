import type { domToReact } from 'html-react-parser';
import { default as parseHTMLString } from 'html-react-parser';
import { isBoolean } from 'lodash';
import { sanitizeHTML } from '../../..';
import type { SanitizeOptions } from '../../../..';

/**
 * Converts an HTML string into JSX, with optional sanitization.
 *
 * @param html - The HTML string to be converted to JSX.
 * @param sanitize - Optional. If `true`, the HTML will be sanitized with default settings.
 * If an object like `{ options?: SanitizeOptions }`, it will be sanitized with the specified DOMPurify options.
 * If `false` or `undefined`, no sanitization is performed.
 * @returns The JSX representation of the HTML string.
 */
export const stringHTMLToJSX = (
    html: string,
    sanitize?: boolean | { options?: SanitizeOptions },
): ReturnType<typeof domToReact> => {
    if (sanitize) {
        if (isBoolean(sanitize)) return parseHTMLString(String(sanitizeHTML(html)));
        return parseHTMLString(String(sanitizeHTML(html, sanitize as SanitizeOptions)));
    }
    return parseHTMLString(html);
};
