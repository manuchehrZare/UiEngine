import * as yup from 'yup';
import type { IFileOptions } from '../type';
import type { FieldValues } from '../../../hooks/useForm';
import { isArray, isNumber } from 'lodash';
import { i18n, locale } from '../../locales';

export const fileValidation = <T extends FieldValues = FieldValues>(
    fieldLabel: string,
    options?: IFileOptions<T>,
    // eslint-disable-next-line
) => {
    const init = yup.mixed().test(
        'isFile',
        options?.messageFormatter?.typeError
            ? options.messageFormatter?.typeError({ fieldLabel })
            : i18n.t(locale.validations.common.typeError, {
                  field: fieldLabel,
                  verb: i18n.t(locale.validations.common.verb.choosing),
              }),
        (value) =>
            !value || value instanceof File || (Array.isArray(value) && value.every((item) => item instanceof File)),
    );

    let yupMethod = options?.required
        ? init.required(
              options?.messageFormatter?.required
                  ? options.messageFormatter?.required({ fieldLabel })
                  : i18n.t(locale.validations.common.required, {
                        field: fieldLabel,
                        verb: i18n.t(locale.validations.common.verb.choosing),
                    }),
          )
        : init;

    if (options?.maxFileSize) {
        yupMethod = yupMethod.test({
            test: function (value) {
                if (!value) return true;
                const bytesToUnit = (bytes: number, type: 'B' | 'KB' | 'MB'): number => {
                    switch (type) {
                        case 'KB':
                            return bytes / 1024;
                        case 'MB':
                            return bytes / (1024 * 1024);
                        case 'B':
                        default:
                            return bytes;
                    }
                };
                const files = Array.isArray(value) ? value : [value];
                const isValid = files.every(
                    (file) =>
                        options?.maxFileSize &&
                        bytesToUnit(file.size, options.maxFileSize.type) <= options.maxFileSize.size,
                );

                if (!isValid) {
                    return this.createError({
                        message: options.messageFormatter?.maxFileSize
                            ? options.messageFormatter?.maxFileSize({
                                  fieldLabel,
                                  maxFileSize: options?.maxFileSize?.size,
                                  type: options?.maxFileSize?.type,
                              })
                            : i18n.t(locale.validations.file.maxFileSize, {
                                  maxFileSize: String(options?.maxFileSize?.size),
                                  type: options?.maxFileSize?.type,
                              }),
                    });
                }
                return true;
            },
        });
    }

    if (options?.max && isNumber(options.max)) {
        yupMethod = yupMethod.test({
            test: function (value) {
                if (!value) return true;

                const files = Array.isArray(value) ? value : [value];
                if (options?.max && files.length > options.max) {
                    return this.createError({
                        message: options.messageFormatter?.max
                            ? options.messageFormatter?.max({
                                  max: options.max,
                                  fieldLabel,
                              })
                            : i18n.t(locale.validations.file.max, { max: options?.max }),
                    });
                }
                return true;
            },
        });
    }
    if (options?.min && isNumber(options.min)) {
        yupMethod = yupMethod.test({
            test: function (value) {
                if (!value) return true;

                const files = Array.isArray(value) ? value : [value];
                if (options?.min && files.length < options.min) {
                    return this.createError({
                        message: options.messageFormatter?.min
                            ? options.messageFormatter?.min({
                                  min: options.min,
                                  fieldLabel,
                              })
                            : i18n.t(locale.validations.file.min, { min: options?.min }),
                    });
                }
                return true;
            },
        });
    }
    if (options?.accept) {
        yupMethod = yupMethod.test({
            test: function (value) {
                if (!value) return true;

                const files = isArray(value) ? value : [value];
                const isValid = files?.every(
                    (file: File) =>
                        (options?.accept as string[])?.includes(file?.type) ||
                        options?.accept?.includes(
                            file.name.split('.').pop()?.toLowerCase() as (typeof options.accept)[number],
                        ),
                );

                if (!isValid) {
                    return this.createError({
                        message: options?.messageFormatter?.accept
                            ? options?.messageFormatter?.accept({
                                  accept: options.accept,
                                  fieldLabel,
                              })
                            : i18n.t(locale.validations.file.accept, {
                                  accept: options?.accept?.map((fileType) => fileType.toLocaleUpperCase()),
                              }),
                    });
                }
                return true;
            },
        });
    }

    return yupMethod;
};
