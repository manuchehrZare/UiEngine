import { capitalize } from 'lodash';
import { LocalesEnum, i18n } from '../../locales';

interface IGetVerbProps {
    fieldLabel: string;
    labelCapitalize?: boolean;
    verb: string;
}

// eslint-disable-next-line
export const getVerb = ({ fieldLabel, verb, labelCapitalize }: IGetVerbProps) => {
    const fieldLabelCapitalize = fieldLabel === fieldLabel.toUpperCase() ? fieldLabel : capitalize(fieldLabel);
    const fieldLabelLowerCase = fieldLabel === fieldLabel.toUpperCase() ? fieldLabel : fieldLabel.toLowerCase();
    switch (i18n.language) {
        case LocalesEnum.TURKISH:
            return {
                field: labelCapitalize ? fieldLabelCapitalize : fieldLabelLowerCase,
                verb,
            };
        case LocalesEnum.ENGLISH:
            return {
                field: fieldLabelLowerCase,
                verb: verb === verb.toUpperCase() ? verb : capitalize(verb),
            };
        default:
            return {
                field: labelCapitalize ? fieldLabelCapitalize : fieldLabelLowerCase,
                verb,
            };
    }
};

/**
 * For Boolean Validation
 */
export const getJustVerbForBoolValidation = ({ verb }: Pick<IGetVerbProps, 'verb'>): string => {
    switch (i18n.language) {
        case LocalesEnum.TURKISH:
            return verb;
        case LocalesEnum.ENGLISH:
            return `${verb}.`;
        default:
            return verb;
    }
};
