import type { FieldValues } from '../../../hooks/useForm';
import { stringValidation } from '../String';
import type { IIBANOptions } from '../type';
import { i18n, locale } from '../../locales';
import { constants } from '../../constants';
import { iban } from '../../methods';

export const ibanValidation = <TFormValues extends FieldValues>(
    options?: IIBANOptions<TFormValues>,
    // eslint-disable-next-line
) => {
    return stringValidation(options?.fieldLabel || i18n.t(locale.labels.iban), {
        ...options,
    }).test({
        test: function (val) {
            if (val) {
                const cleanValue: string = iban(val);
                const countryCode = cleanValue.slice(0, 2);
                const countryFormat = constants.IBANFormats[countryCode as keyof typeof constants.IBANFormats];
                if (countryFormat) {
                    if (cleanValue.length !== countryFormat.length)
                        return this.createError({
                            message: options?.messageFormatter?.IBAN
                                ? options.messageFormatter?.IBAN({ fieldLabel: options?.fieldLabel })
                                : i18n.t(locale.validations.iban.iban, {
                                      country: countryCode,
                                      field: options?.fieldLabel || i18n.t(locale.labels.iban),
                                      value: countryFormat.length,
                                  }),
                        });
                }
            }
            return true;
        },
    });
};
