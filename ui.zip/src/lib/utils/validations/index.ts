import { format } from '../constants/format';
import { i18n, locale } from '../locales';
import type { IStringOptions } from './type';
import { ValidationsCompareTypeEnum } from './type';
import { booleanValidation } from './Boolean';
import { dateValidation } from './Date';
import { numberValidation } from './Number';
import { stringValidation } from './String';
import { constants } from '../constants';
import type { FieldValues } from 'react-hook-form';
import { ibanValidation } from './IBAN';
import { fileValidation } from './File';

export const validation = {
    string: stringValidation,
    number: numberValidation,
    date: dateValidation,
    boolean: booleanValidation,
    // eslint-disable-next-line
    trId: <TFormValues extends FieldValues>(options?: IStringOptions<TFormValues> & { fieldLabel?: string }) => {
        return stringValidation(options?.fieldLabel || i18n.t(locale.labels.tcId), {
            regexp: format.regexp.trId,
            length: constants.format.length.trId,
            ...options,
        });
    },
    iban: ibanValidation,
    file: fileValidation,
    /**
     * registryNo = userCode
     */
    // eslint-disable-next-line
    registryNo: <TFormValues extends FieldValues>(options?: IStringOptions<TFormValues> & { fieldLabel?: string }) => {
        return stringValidation(options?.fieldLabel || i18n.t(locale.labels.registryNo), {
            minLength: constants.format.length.registryNo.min,
            maxLength: constants.format.length.registryNo.max,
            ...options,
        });
    },
    // eslint-disable-next-line
    password: <TFormValues extends FieldValues>(options?: IStringOptions<TFormValues> & { fieldLabel?: string }) => {
        return stringValidation(options?.fieldLabel || i18n.t(locale.labels.password), {
            minLength: constants.format.length.password.min,
            maxLength: constants.format.length.password.max,
            ...options,
        });
    },
};

export { ValidationsCompareTypeEnum };
