import { format, subDays, toDate, isValid, isEqual } from 'date-fns';
import { gt, gte, lt, lte, isString, isUndefined, isDate } from 'lodash';
import * as yup from 'yup';
import type { FieldValues } from '../../..';
import { pickerProps } from '../../..';
import { i18n, locale } from '../../locales';
import type { IDateOptions, ComporeMessageOptions } from '../type';
import { ValidationsCompareTypeEnum } from '../type';
import { getVerb } from '../_helper/method';

// eslint-disable-next-line
export const dateValidation = <T extends FieldValues = FieldValues>(fieldLabel: string, options?: IDateOptions<T>) => {
    const displayFormat = options?.displayFormat || pickerProps.default.datePicker.inputFormat;
    const verb = options?.selectable
        ? i18n.t(locale.validations.common.verb.choosing)
        : i18n.t(locale.validations.common.verb.entry);

    const init = yup
        .date()
        .nullable()
        .typeError(
            options?.messageFormatter?.typeError
                ? options.messageFormatter?.typeError({ fieldLabel })
                : i18n.t(locale.validations.common.typeError, {
                      ...getVerb({ fieldLabel, verb }),
                  }),
        );

    const dateFormat = (val?: Date | null) => {
        return val && format(new Date(val), displayFormat);
    };

    let yupMethod = options?.required
        ? init.required(
              options?.messageFormatter?.required
                  ? options.messageFormatter?.required({ fieldLabel })
                  : i18n.t(locale.validations.common.required, {
                        ...getVerb({ fieldLabel, verb, labelCapitalize: true }),
                    }),
          )
        : init;

    if (options?.minDate) {
        yupMethod = yupMethod.min(
            subDays(toDate(options?.minDate), 1),
            options?.messageFormatter?.minDate
                ? options.messageFormatter?.minDate({ minDate: options.minDate, fieldLabel })
                : i18n.t(locale.validations.common.min, {
                      value: dateFormat(toDate(options?.minDate)),
                      verb,
                  }),
        );
    }

    if (options?.maxDate) {
        yupMethod = yupMethod.max(
            toDate(options?.maxDate),
            options?.messageFormatter?.maxDate
                ? options.messageFormatter?.maxDate({ maxDate: options.maxDate, fieldLabel })
                : i18n.t(locale.validations.common.max, {
                      value: dateFormat(toDate(options?.maxDate)),
                      verb,
                  }),
        );
    }

    if (options?.compare?.length) {
        options?.compare.forEach((compareItem) => {
            /**
             * @param context for getting field name (label) that is compared
             * @description this method return field label value for validation
             */
            const getMessageValue = (context: yup.TestContext): string =>
                (compareItem?.fieldLabel &&
                    getVerb({ fieldLabel: compareItem?.fieldLabel, verb, labelCapitalize: true }).field) ||
                compareItem?.valueFormatter?.(context?.parent[`${compareItem?.fieldName}`]) ||
                dateFormat(context.parent[`${compareItem?.fieldName}`]);

            if (compareItem?.type === ValidationsCompareTypeEnum.LessThan) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        if (isDate(value)) {
                            if (
                                (isUndefined(compareItem.when) ||
                                    compareItem?.when?.({
                                        value,
                                        compareValue: context.parent[`${compareItem?.fieldName}`],
                                        formValues: context?.parent,
                                    })) &&
                                !lt(value, context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(value)
                            ) {
                                const messageValue = i18n.t(locale.validations.compare.lessThan, {
                                    value: getMessageValue(context),
                                });
                                const messageFormatterParams = {
                                    fieldLabel,
                                    compareName: compareItem?.fieldName,
                                    compareValue: dateFormat(context.parent[`${compareItem?.fieldName}`]),
                                    type: compareItem.type,
                                    value: dateFormat(value),
                                };
                                return this.createError({
                                    message: options.messageFormatter?.compare?.({})?.lt
                                        ? isString(options.messageFormatter?.compare({})?.lt)
                                            ? (options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.lt as string)
                                            : (
                                                  options?.messageFormatter?.compare({
                                                      ...messageFormatterParams,
                                                  })?.lt as ComporeMessageOptions<T>[]
                                              ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                              messageValue
                                        : messageValue,
                                });
                            }
                        }
                        return true;
                    },
                });
            }

            if (compareItem?.type === ValidationsCompareTypeEnum.GreaterThan) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        if (isDate(value)) {
                            if (
                                (isUndefined(compareItem.when) ||
                                    compareItem?.when?.({
                                        value,
                                        compareValue: context.parent[`${compareItem?.fieldName}`],
                                        formValues: context?.parent,
                                    })) &&
                                !gt(value, context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(value)
                            ) {
                                const messageValue = i18n.t(locale.validations.compare.greaterThan, {
                                    value: getMessageValue(context),
                                });
                                const messageFormatterParams = {
                                    fieldLabel,
                                    compareName: compareItem?.fieldName,
                                    compareValue: dateFormat(context.parent[`${compareItem?.fieldName}`]),
                                    type: compareItem.type,
                                    value: dateFormat(value),
                                };
                                return this.createError({
                                    message: options.messageFormatter?.compare?.({})?.gt
                                        ? isString(options.messageFormatter?.compare({})?.gt)
                                            ? (options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.gt as string)
                                            : (
                                                  options?.messageFormatter?.compare({
                                                      ...messageFormatterParams,
                                                  })?.gt as ComporeMessageOptions<T>[]
                                              ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                              messageValue
                                        : messageValue,
                                });
                            }
                        }
                        return true;
                    },
                });
            }

            if (compareItem?.type === ValidationsCompareTypeEnum.Equal) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        if (isDate(value)) {
                            if (
                                (isUndefined(compareItem.when) ||
                                    compareItem?.when?.({
                                        value,
                                        compareValue: context.parent[`${compareItem?.fieldName}`],
                                        formValues: context?.parent,
                                    })) &&
                                !isEqual(value as any, context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(value)
                            ) {
                                const messageValue = i18n.t(locale.validations.compare.equal, {
                                    value: getMessageValue(context),
                                });
                                const messageFormatterParams = {
                                    fieldLabel,
                                    compareName: compareItem?.fieldName,
                                    compareValue: dateFormat(context.parent[`${compareItem?.fieldName}`]),
                                    type: compareItem.type,
                                    value: dateFormat(value),
                                };
                                return this.createError({
                                    message: options?.messageFormatter?.compare?.({})?.eq
                                        ? isString(options.messageFormatter?.compare({})?.eq)
                                            ? (options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.eq as string)
                                            : (
                                                  options?.messageFormatter?.compare({
                                                      ...messageFormatterParams,
                                                  })?.eq as ComporeMessageOptions<T>[]
                                              ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                              messageValue
                                        : messageValue,
                                });
                            }
                        }
                        return true;
                    },
                });
            }

            if (compareItem?.type === ValidationsCompareTypeEnum.NotEqual) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        if (isDate(value)) {
                            if (
                                (isUndefined(compareItem.when) ||
                                    compareItem?.when?.({
                                        value,
                                        compareValue: context.parent[`${compareItem?.fieldName}`],
                                        formValues: context?.parent,
                                    })) &&
                                isEqual(value as any, context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(value)
                            ) {
                                const messageValue = i18n.t(locale.validations.compare.notEqual, {
                                    value: getMessageValue(context),
                                });
                                const messageFormatterParams = {
                                    fieldLabel,
                                    compareName: compareItem?.fieldName,
                                    compareValue: dateFormat(context.parent[`${compareItem?.fieldName}`]),
                                    type: compareItem.type,
                                    value: dateFormat(value),
                                };
                                return this.createError({
                                    message: options?.messageFormatter?.compare?.({})?.neq
                                        ? isString(options.messageFormatter?.compare({})?.neq)
                                            ? (options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.neq as string)
                                            : (
                                                  options?.messageFormatter?.compare({
                                                      ...messageFormatterParams,
                                                  })?.neq as ComporeMessageOptions<T>[]
                                              ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                              messageValue
                                        : messageValue,
                                });
                            }
                        }
                        return true;
                    },
                });
            }

            if (compareItem?.type === ValidationsCompareTypeEnum.LessThanOrEqual) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        if (isDate(value)) {
                            if (
                                (isUndefined(compareItem.when) ||
                                    compareItem?.when?.({
                                        value,
                                        compareValue: context.parent[`${compareItem?.fieldName}`],
                                        formValues: context?.parent,
                                    })) &&
                                !lte(value, context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(value)
                            ) {
                                const messageValue = i18n.t(locale.validations.compare.lessThanOrEqual, {
                                    value: getMessageValue(context),
                                });
                                const messageFormatterParams = {
                                    fieldLabel,
                                    compareName: compareItem?.fieldName,
                                    compareValue: dateFormat(context.parent[`${compareItem?.fieldName}`]),
                                    type: compareItem.type,
                                    value: dateFormat(value),
                                };
                                return this.createError({
                                    message: options?.messageFormatter?.compare?.({})?.lte
                                        ? isString(options.messageFormatter?.compare({})?.lte)
                                            ? (options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.lte as string)
                                            : (
                                                  options?.messageFormatter?.compare({
                                                      ...messageFormatterParams,
                                                  })?.lte as ComporeMessageOptions<T>[]
                                              ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                              messageValue
                                        : messageValue,
                                });
                            }
                        }
                        return true;
                    },
                });
            }

            if (compareItem?.type === ValidationsCompareTypeEnum.GreaterThanOrEqual) {
                yupMethod = yupMethod.test({
                    test: function (value, context) {
                        if (isDate(value)) {
                            if (
                                (isUndefined(compareItem.when) ||
                                    compareItem?.when?.({
                                        value,
                                        compareValue: context.parent[`${compareItem?.fieldName}`],
                                        formValues: context?.parent,
                                    })) &&
                                !gte(value, context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(context.parent[`${compareItem?.fieldName}`]) &&
                                isValid(value)
                            ) {
                                const messageValue = i18n.t(locale.validations.compare.greaterThanOrEqual, {
                                    value: getMessageValue(context),
                                });
                                const messageFormatterParams = {
                                    fieldLabel,
                                    compareName: compareItem?.fieldName,
                                    compareValue: dateFormat(context.parent[`${compareItem?.fieldName}`]),
                                    type: compareItem.type,
                                    value: dateFormat(value),
                                };
                                return this.createError({
                                    message: options?.messageFormatter?.compare?.({})?.gte
                                        ? isString(options.messageFormatter?.compare({})?.gte)
                                            ? (options?.messageFormatter?.compare({
                                                  ...messageFormatterParams,
                                              })?.gte as string)
                                            : (
                                                  options?.messageFormatter?.compare({
                                                      ...messageFormatterParams,
                                                  })?.gte as ComporeMessageOptions<T>[]
                                              ).find((item) => item.fieldName === compareItem.fieldName)?.message ||
                                              messageValue
                                        : messageValue,
                                });
                            }
                        }
                        return true;
                    },
                });
            }
        });
    }

    return yupMethod;
};
