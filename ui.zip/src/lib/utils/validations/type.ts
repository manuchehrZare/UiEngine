import type { FieldPathValue, FieldValues } from 'react-hook-form';
import type { IInputProps, Path } from '../..';

export enum ValidationsCompareTypeEnum {
    NotEqual = 'neq',
    Equal = 'eq',
    GreaterThan = 'gt',
    LessThan = 'lt',
    GreaterThanOrEqual = 'gte',
    LessThanOrEqual = 'lte',
}

export type ComporeMessageOptions<TFormValues> = {
    fieldName: Path<TFormValues>;
    message: string;
};

export interface ICompareMessageType<TFormValues> {
    eq?: string | [ComporeMessageOptions<TFormValues>, ...ComporeMessageOptions<TFormValues>[]];
    gt?: string | [ComporeMessageOptions<TFormValues>, ...ComporeMessageOptions<TFormValues>[]];
    gte?: string | [ComporeMessageOptions<TFormValues>, ...ComporeMessageOptions<TFormValues>[]];
    lt?: string | [ComporeMessageOptions<TFormValues>, ...ComporeMessageOptions<TFormValues>[]];
    lte?: string | [ComporeMessageOptions<TFormValues>, ...ComporeMessageOptions<TFormValues>[]];
    neq?: string | [ComporeMessageOptions<TFormValues>, ...ComporeMessageOptions<TFormValues>[]];
}

export interface IMessageParams<TValue = any, TCompareValue = any> {
    compareName?: string;
    compareValue?: TCompareValue;
    fieldLabel?: string;
    type?: `${ValidationsCompareTypeEnum}`;
    value?: TValue;
}

export interface IMessageFormatter {
    length?: (params: Pick<IStringOptions<any>, 'length'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    max?: (params: Pick<INumberOptions<any>, 'max'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    maxDate?: (params: Pick<IDateOptions<any>, 'maxDate'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    maxLength?: (params: Pick<IStringOptions<any>, 'maxLength'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    min?: (params: Pick<INumberOptions<any>, 'min'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    minDate?: (params: Pick<IDateOptions<any>, 'minDate'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    minLength?: (params: Pick<IStringOptions<any>, 'minLength'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    regexp?: (params: Pick<IStringOptions<any>, 'regexp'> & Pick<IMessageParams, 'fieldLabel'>) => string;
    required?: (params: Pick<IMessageParams, 'fieldLabel'>) => string;
    typeError?: (params: Pick<IMessageParams, 'fieldLabel'>) => string;
}
export interface IOptions {
    required?: boolean;
    selectable?: boolean;
}

export interface IBooleanMessageFormatter<TFormValues> extends Pick<IMessageFormatter, 'required' | 'typeError'> {
    compare?: (params: IMessageParams) => Pick<ICompareMessageType<TFormValues>, 'eq' | 'neq'>;
}

export interface IStringMessageFormatter<TFormValues>
    extends Omit<IMessageFormatter, 'max' | 'min' | 'minDate' | 'maxDate'> {
    compare?: (params: IMessageParams) => Pick<ICompareMessageType<TFormValues>, 'eq' | 'neq'>;
}

export interface INumberMessageFormatter<TFormValues>
    extends Omit<IMessageFormatter, 'minDate' | 'maxDate' | 'regexp'> {
    compare?: (params: IMessageParams) => ICompareMessageType<TFormValues>;
}

export interface IDateMessageFormatter<TFormValues>
    extends Pick<IMessageFormatter, 'required' | 'minDate' | 'maxDate' | 'typeError'> {
    compare?: (params: IMessageParams) => ICompareMessageType<TFormValues>;
}

export interface ICompareWhenParams<TFormValues, TValue = any, TCompareValue = any>
    extends Pick<IMessageParams<TValue, TCompareValue>, 'value' | 'compareValue'> {
    formValues?: TFormValues;
}

export interface ICompare<TFormValues extends FieldValues, TValue = any> {
    /**
     * Represents the label of the element being compared.
     */
    fieldLabel?: string;
    /**
     * The name of the element to be compared.
     */
    fieldName: Path<TFormValues>;
    /**
     * Specifies the type of comparison.
     */
    type: `${ValidationsCompareTypeEnum}`;
    /**
     * It is used to format the value of the element being compared.
     */
    valueFormatter?: (value: TValue) => any;
    /**
     * It is used to add a condition to the item being compared.
     */
    when?: (params: ICompareWhenParams<TFormValues, TValue, FieldPathValue<TFormValues, Path<TFormValues>>>) => boolean;
}

export interface IStringCompare<TFormValues extends FieldValues, TValue = any>
    extends Omit<ICompare<TFormValues, TValue>, 'type'> {
    type: `${Extract<
        ValidationsCompareTypeEnum,
        ValidationsCompareTypeEnum.Equal | ValidationsCompareTypeEnum.NotEqual
    >}`;
}

export interface IDateOptions<TFormValues extends FieldValues> extends IOptions {
    compare?: [ICompare<TFormValues, Date>, ...ICompare<TFormValues, Date>[]];
    displayFormat?: string;
    maxDate?: Date;
    messageFormatter?: IDateMessageFormatter<TFormValues>;
    minDate?: Date;
}

export interface IStringOptions<TFormValues extends FieldValues> extends IOptions {
    compare?: [IStringCompare<TFormValues, string>, ...IStringCompare<TFormValues, string>[]];
    length?: number;
    maxLength?: number;
    messageFormatter?: IStringMessageFormatter<TFormValues>;
    minLength?: number;
    regexp?: RegExp;
}

export interface IBooleanOptions<TFormValues extends FieldValues> extends IOptions {
    compare?: [IStringCompare<TFormValues, boolean>, ...IStringCompare<TFormValues, boolean>[]];
    messageFormatter?: IBooleanMessageFormatter<TFormValues>;
}

export interface INumberOptions<TFormValues extends FieldValues> extends IOptions {
    compare?: [ICompare<TFormValues, number>, ...ICompare<TFormValues, number>[]];
    length?: number;
    max?: number;
    maxLength?: number;
    messageFormatter?: INumberMessageFormatter<TFormValues>;
    min?: number;
    minLength?: number;
}

export interface IIBANOptions<TFormValues extends FieldValues>
    extends Pick<IStringOptions<TFormValues>, 'compare' | 'regexp' | 'required'> {
    fieldLabel?: string;
    messageFormatter?: Pick<IMessageFormatter, 'regexp' | 'required'> & {
        IBAN?: (params: Pick<IMessageParams, 'fieldLabel'>) => string;
    };
}

export interface IFileOptions<TFormValues extends FieldValues>
    extends Pick<IOptions, 'required'>,
        Pick<INumberOptions<TFormValues>, 'max' | 'min'> {
    accept?: IInputProps['accept'];
    maxFileSize?: {
        size: number;
        type: 'B' | 'KB' | 'MB';
    };
    messageFormatter?: Pick<IMessageFormatter, 'required' | 'max' | 'min' | 'typeError'> & {
        accept?: (params: { accept?: IInputProps['accept']; fieldLabel: string }) => string;
        maxFileSize?: (params: { fieldLabel: string; maxFileSize?: number; type?: string }) => string;
        required?: (params: { fieldLabel: string }) => string;
    };
    multiple?: boolean;
}
