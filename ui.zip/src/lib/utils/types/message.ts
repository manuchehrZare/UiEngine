export enum MessageTypeEnum {
    default = 'default',
    error = 'error',
    success = 'success',
    warning = 'warning',
    info = 'info',
}

export type {
    SnackbarProviderProps as IMessageProviderProps,
    CustomContentProps as MessageCustomContentProps,
    VariantOverrides as IMessageVariantOverrides,
} from 'notistack';
