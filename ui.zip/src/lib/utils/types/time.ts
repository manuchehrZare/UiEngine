/**
 * Time type representing a breakdown of time into hours, minutes, seconds, and milliseconds
 */
export type Time = {
    hours: number;
    milliseconds: number;
    minutes: number;
    seconds: number;
};

/**
 * Allows configuring which parts of the Time object should be returned (displayed or used)
 */
export type TimeReturnValues = Partial<Record<keyof Time, boolean>>;

/**
 * Time structure for current date and time
 */
export type Now = Time & {
    days: number; // 1-31
    months: number; // 0–11
    years: number;
};
