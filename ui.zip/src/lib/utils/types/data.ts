export interface IErrorMessageItems {
    Key: string;
    Value: string;
}

export interface IResultError {
    Items: IErrorMessageItems[];
    Message: string;
}

export interface IResultDatas<T> {
    Data: T[];
    Error: IResultError;
}

export interface IResultData<T> {
    Data: T;
    Error: IResultError;
}
