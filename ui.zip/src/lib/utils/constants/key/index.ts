export const key = {
    PROVIDER_DESIGN: 'SekerUI-provider-design',
    PROVIDER_THEME: 'SekerUI-provider-theme',
    PROVIDER_LOADING_ID: 'provider-loading',
    SekerUI_LANGUAGE: 'SekerUI-language',
    StorageEventName: 'storage',
};
