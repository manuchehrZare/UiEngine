import { DesignTypeEnum } from '../../types/common';

export const design = {
    defaultType: DesignTypeEnum.Default,
    border: {
        paper: {
            common: {
                SET: {
                    width: 1,
                },
            },
            borderBox: {
                default: {
                    width: 1,
                },
                SET: {
                    width: 1,
                },
            },
        },
    },
    gap: {
        button: {
            default: {
                unit: 1,
                pixel: 10,
            },
            SET: {
                unit: 0.8,
                pixel: 8,
            },
        },
    },
    grid: {
        spacing: {
            common: {
                default: {
                    unit: 1,
                    pixel: 8,
                },
                SET: {
                    unit: 1.5,
                    pixel: 12,
                },
            },
            button: {
                default: {
                    unit: 1,
                    pixel: 8,
                },
                SET: {
                    unit: 1,
                    pixel: 8,
                },
            },
            form: {
                column: {
                    default: {
                        unit: 1,
                        pixel: 8,
                    },
                    SET: {
                        unit: 4.5,
                        pixel: 36,
                    },
                },
                row: {
                    default: {
                        unit: 1,
                        pixel: 8,
                    },
                    SET: {
                        unit: 2,
                        pixel: 16,
                    },
                },
            },
            joinedForm: {
                column: {
                    default: {
                        unit: 0.5,
                        pixel: 4,
                    },
                    SET: {
                        unit: 0.25,
                        pixel: 2,
                    },
                },
            },
        },
    },
    gridItem: {
        sizeType: {
            common: { xs: 12 },
            form: { default: { xs: 12 }, SET: { xs: 12, sm: 6, md: 3, lg: 2.4, xl: 2, xxl: 1.5 } },
        },
    },
};
