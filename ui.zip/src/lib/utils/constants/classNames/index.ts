export const classNames = {
    labelEllipsis: 'label-ellipsis',
};
