// Country-based regex and length information for IBAN formats
export const IBANFormats = {
    TR: { length: 26, regex: /^[A-Z]{2}[0-9]{24}$/ }, // Turkey
    DE: { length: 22, regex: /^[A-Z]{2}[0-9]{20}$/ }, // Germany
    GB: { length: 22, regex: /^[A-Z]{2}[0-9]{20}$/ }, // United Kingdom
    FR: { length: 27, regex: /^[A-Z]{2}[0-9]{25}$/ }, // France
    IT: { length: 27, regex: /^[A-Z]{2}[0-9]{25}$/ }, // Italy
    ES: { length: 24, regex: /^[A-Z]{2}[0-9]{22}$/ }, // Spain
    NL: { length: 18, regex: /^[A-Z]{2}[0-9]{16}$/ }, // Netherlands
    BE: { length: 16, regex: /^[A-Z]{2}[0-9]{14}$/ }, // Belgium
    // Additional country formats can be added here
};
