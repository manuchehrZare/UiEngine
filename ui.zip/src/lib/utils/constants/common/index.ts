export const common = {
    company: {
        NAME: 'Şekerbank A.Ş.',
        WEBSITE_LINK: 'https://www.sekerbank.com.tr',
    },
    library: {
        documentation: 'https://sekerui.seker.net/',
        prefix: 'sekerUI',
        localization: {
            defaultLng: 'tr',
            defaultFallbackLng: ['tr', 'en'],
        },
    },
};
