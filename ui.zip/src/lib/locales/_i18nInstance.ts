import localeTR from './translations/tr';
import localeEN from './translations/en';
import type { LocalesType } from '../utils/locales/type';
import { LocalesEnum } from '../utils/locales/type';
import { getLocalStorageItem } from '../utils/methods';
import { constants } from '../utils/constants';
import { createInstance } from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

export const defaultlocaleData = localeTR; // for keyPaths using
export const languageStorageKey = constants.key.SekerUI_LANGUAGE;

export const i18n = createInstance({
    debug: true,
    resources: {
        [LocalesEnum.TURKISH]: localeTR,
        [LocalesEnum.ENGLISH]: localeEN,
    },
    lng: getLocalStorageItem<LocalesType>(languageStorageKey) || LocalesEnum.TURKISH, // if defined, it triggers the defined language at every render instant
    fallbackLng: [LocalesEnum.TURKISH, LocalesEnum.ENGLISH],
    interpolation: {
        escapeValue: false, // react already safes from xss => https://www.i18next.com/translation-function/interpolation#unescape
    },
    react: {
        useSuspense: false,
    },
});

/**
 * For Custom Initialization
 */
export const i18nInit = async (): Promise<void> => {
    await i18n
        .use(new LanguageDetector(null, { lookupLocalStorage: languageStorageKey }))
        .use(initReactI18next)
        .init({}, () => {
            document.documentElement.setAttribute('lang', String(getLocalStorageItem<LocalesType>(languageStorageKey)));
        });
};
