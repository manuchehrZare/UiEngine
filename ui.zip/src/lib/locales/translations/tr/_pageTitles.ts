export default {
    home: 'Anasayfa',
    notFound: 'Sayfa Bulunamadı!',
    auth: {
        login: 'Giriş',
    },
};
