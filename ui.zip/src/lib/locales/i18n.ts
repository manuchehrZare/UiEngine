/** For Custom Initialization */
import { i18n, i18nInit, languageStorageKey } from './_i18nInstance';

export const i18nInitialize = async (): Promise<void> => {
    await i18nInit();
};

export { i18n, i18nInit, languageStorageKey };
