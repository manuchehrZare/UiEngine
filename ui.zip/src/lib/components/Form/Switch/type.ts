import type { SwitchProps } from '@mui/material';
import type { ICommonFieldProps, IFormCommonControl } from '../commonTypes';

export interface ISwitchProps
    extends Pick<ICommonFieldProps, 'name' | 'helperText' | 'hidden' | 'design'>,
        Pick<
            SwitchProps,
            | 'autoFocus'
            | 'className'
            | 'color'
            | 'disableRipple'
            | 'disableTouchRipple'
            | 'disabled'
            | 'inputRef'
            | 'onChange'
            | 'readOnly'
            | 'ref'
            | 'required'
            | 'size'
            | 'sx'
        >,
        IFormCommonControl<any> {
    label?: string;
    labelPlacement?: 'start' | 'end' | 'top' | 'bottom';
    labelWidth?: number;
}
