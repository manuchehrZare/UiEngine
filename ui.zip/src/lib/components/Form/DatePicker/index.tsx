import Default from './DefaultDatePicker';
import SET from './SETDatePicker';
import type { FC } from 'react';
import { memo } from 'react';
import type { IDatePickerProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const DatePicker: FC<IDatePickerProps> = ({
    design,
    autoFocus = false,
    clearable = false,
    disableCloseOnSelect = false,
    disableWeekends = false,
    fullWidth = true,
    hidden = false,
    labelPlacement = 'top',
    labelEllipsis = true,
    readOnly = false,
    required = false,
    unixTime = false,
    size = 'medium',
    variant = 'outlined',
    ...rest
}: IDatePickerProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: (
            <Default
                variant={variant}
                autoFocus={autoFocus}
                clearable={clearable}
                disableCloseOnSelect={disableCloseOnSelect}
                disableWeekends={disableWeekends}
                fullWidth={fullWidth}
                hidden={hidden}
                labelPlacement={labelPlacement}
                labelEllipsis={labelEllipsis}
                readOnly={readOnly}
                required={required}
                size={size}
                unixTime={unixTime}
                {...rest}
            />
        ),
        [DesignTypeEnum.SET]: (
            <SET
                variant={variant}
                autoFocus={autoFocus}
                clearable={clearable}
                disableCloseOnSelect={disableCloseOnSelect}
                disableWeekends={disableWeekends}
                fullWidth={fullWidth}
                hidden={hidden}
                labelPlacement={labelPlacement}
                labelEllipsis={labelEllipsis}
                readOnly={readOnly}
                required={required}
                size={size}
                unixTime={unixTime}
                {...rest}
            />
        ),
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default memo(DatePicker);
