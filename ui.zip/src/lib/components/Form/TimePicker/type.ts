import type { TimePickerProps, TimePickerSlotsComponents, TimePickerSlotsComponentsProps } from '@mui/x-date-pickers';
import type { TextFieldProps } from '@mui/material';
import type { ICommonFieldProps } from '../commonTypes';

export interface ITimePickerProps
    extends Pick<
            TimePickerProps<any>,
            | 'ampmInClock'
            | 'autoFocus'
            | 'className'
            | 'disableOpenPicker'
            | 'disabled'
            | 'format'
            | 'formatDensity'
            | 'label'
            | 'localeText'
            | 'maxTime'
            | 'minTime'
            | 'minutesStep'
            | 'onClose'
            | 'onOpen'
            | 'onViewChange'
            | 'shouldDisableTime'
            | 'views'
        >,
        Omit<ICommonFieldProps, 'startAdornment' | 'endAdornment'>,
        Pick<TextFieldProps, 'placeholder' | 'sx' | 'onKeyPress' | 'onFocus' | 'onBlur'> {
    analogClock?: boolean;
    clearable?: boolean | undefined;
    clearText?: any;
    disableCloseOnSelect?: boolean | undefined;
    required?: boolean;
    /*
    The props used for each component slot.
    */
    slotProps?: Omit<
        TimePickerSlotsComponentsProps<any>,
        'textField' | 'desktopPaper' | 'openPickerButton' | 'actionBar' | 'inputAdornment'
    >;
    /*
    Overridable component slots.
    */
    slots?: Omit<TimePickerSlotsComponents<any>, 'textField' | 'field' | 'TextField' | 'Field'>;
    unixTime?: boolean;
}

export enum TimeTypeEnum {
    hours = 'hours',
    minutes = 'minutes',
    seconds = 'seconds',
}

export type TimeType = keyof typeof TimeTypeEnum;
