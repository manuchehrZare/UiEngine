import { isNumber } from 'lodash';
import type { DesignType } from '../../../../utils';
import { DesignTypeEnum } from '../../../../utils';

interface ICalculateEditorContentHeight {
    charCounterCount?: boolean;
    design: DesignType | undefined;
    froalaRef: any;
    height: string | number;
    labelRef?: any;
    wordCounterCount?: boolean;
}

export const calculateEditorContentHeight = ({
    height,
    froalaRef,
    charCounterCount,
    wordCounterCount,
    design,
    labelRef,
}: ICalculateEditorContentHeight): string => {
    const heightTypeControl = isNumber(height) ? `${height}px` : height;

    return `calc(
        ${heightTypeControl} - ${
            (froalaRef?.current?.editor?.$tb ? froalaRef?.current?.editor?.$tb[0]?.offsetHeight : 0) +
            (charCounterCount || wordCounterCount
                ? froalaRef?.current?.editor?.$second_tb
                    ? Number(froalaRef?.current?.editor?.$second_tb[0]?.offsetHeight) +
                      (design === DesignTypeEnum.Default ? 3 : 5)
                    : 0
                : 0) +
            (labelRef?.current?.offsetHeight ? labelRef?.current?.offsetHeight : 0) +
            11
        }px)`;
};
