import type { CheckboxProps } from '@mui/material';
import type { ICommonFieldProps, IFormCommonControl } from '../commonTypes';

export interface ICheckboxProps
    extends Pick<ICommonFieldProps, 'name' | 'helperText' | 'hidden' | 'design' | 'fullWidth'>,
        Pick<
            CheckboxProps,
            | 'autoFocus'
            | 'checkedIcon'
            | 'className'
            | 'color'
            | 'disableRipple'
            | 'disableTouchRipple'
            | 'disabled'
            | 'icon'
            | 'inputRef'
            | 'onChange'
            | 'readOnly'
            | 'ref'
            | 'required'
            | 'size'
            | 'sx'
            | 'checked'
        >,
        IFormCommonControl<any> {
    label?: string;
    labelPlacement?: 'start' | 'end' | 'top' | 'bottom';
    labelWidth?: number;
}
