import type { FC } from 'react';
import { useRef, useEffect, useState } from 'react';
import { useController } from 'react-hook-form';
import { Checkbox as MuiCheckbox, FormControl, FormControlLabel, FormHelperText } from '@mui/material';
import { CheckOutlined } from '@mui/icons-material';
import type { ICheckboxProps } from '../type';
import { DesignTypeEnum } from '../../../../utils/types/common';
import { generateClass, manageClassNames } from '../../../../utils';

const Checkbox: FC<ICheckboxProps> = ({
    helperText,
    name,
    disabled,
    required,
    hidden,
    onChange,
    checkedIcon,
    icon,
    label,
    control,
    size,
    readOnly,
    color,
    labelPlacement,
    labelWidth,
    sx,
    deps,
    fullWidth,
    className,
    ...rest
}: ICheckboxProps) => {
    const labelRef: any = useRef(null);
    const [helperTextStyleWidth, setHelperTextStyleWidth] = useState(null);
    const {
        // eslint-disable-next-line
        field: { ref, ...field },
        fieldState: { error },
    } = useController({ name, control, rules: { deps } });

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        if (labelRef) {
            if (labelPlacement === 'top' || labelPlacement === 'bottom' || (labelPlacement === 'end' && labelWidth)) {
                setHelperTextStyleWidth(labelRef.current?.offsetWidth);
            }
        }
        // eslint-disable-next-line react-hooks/refs
    }, [labelRef?.current?.offsetWidth, labelPlacement, labelWidth]);

    return (
        <FormControl
            variant="outlined"
            className={manageClassNames(
                generateClass('Checkbox-formControl'),
                `checbox-labelPlacement-${labelPlacement}`,
                className,
            )}
            error={Boolean(error)}
            disabled={disabled}
            fullWidth={fullWidth}
            size={size}
            hidden={hidden}
            sx={sx}>
            <FormControlLabel
                ref={labelRef}
                disabled={disabled}
                hidden={hidden}
                labelPlacement={labelPlacement}
                label={getLabel()}
                className={manageClassNames(generateClass('Checkbox-label'), `${DesignTypeEnum.SET}`, {
                    [`${labelWidth}`]: Boolean(labelWidth),
                })}
                control={
                    <MuiCheckbox
                        {...field}
                        className={DesignTypeEnum.SET}
                        color={color}
                        size={size}
                        readOnly={readOnly}
                        disabled={disabled}
                        required={required}
                        checked={field.value}
                        icon={icon || <span className={`icon-${DesignTypeEnum.SET}`} />}
                        onChange={(event, checked) => {
                            onChange?.(event, checked);
                            field.onChange(checked);
                        }}
                        checkedIcon={
                            checkedIcon || (
                                <span className={`checked-icon-${DesignTypeEnum.SET}`}>
                                    <CheckOutlined />
                                </span>
                            )
                        }
                        inputProps={{
                            'aria-label': label,
                            role: 'checkbox',
                        }}
                        {...rest}
                    />
                }
                sx={{ pointerEvents: readOnly ? 'none' : 'auto' }}
            />
            {(error?.message || helperText) && (
                <FormHelperText
                    sx={{ width: `${helperTextStyleWidth}px`, margin: labelWidth && '0 !important' }}
                    className={manageClassNames(
                        generateClass('HelperText'),
                        'checkbox',
                        `${DesignTypeEnum.SET}`,
                        `${size}`,
                        { [`${labelWidth}`]: Boolean(labelWidth) },
                    )}>
                    {error?.message || helperText}
                </FormHelperText>
            )}
        </FormControl>
    );
};

export default Checkbox;
