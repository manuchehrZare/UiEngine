import Default from './DefaultCheckbox';
import SET from './SETCheckbox';
import type { FC } from 'react';
import { memo } from 'react';
import type { ICheckboxProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const Checkbox: FC<ICheckboxProps> = ({
    design,
    autoFocus = false,
    color = 'secondary',
    disableRipple = false,
    disabled = false,
    hidden = false,
    labelPlacement = 'end',
    readOnly = false,
    required = false,
    ...rest
}: ICheckboxProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: (
            <Default
                autoFocus={autoFocus}
                color={color}
                disableRipple={disableRipple}
                disabled={disabled}
                hidden={hidden}
                labelPlacement={labelPlacement}
                readOnly={readOnly}
                required={required}
                {...rest}
            />
        ),
        [DesignTypeEnum.SET]: (
            <SET
                autoFocus={autoFocus}
                color={color}
                disableRipple={disableRipple}
                disabled={disabled}
                hidden={hidden}
                labelPlacement={labelPlacement}
                readOnly={readOnly}
                required={required}
                {...rest}
            />
        ),
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default memo(Checkbox);
