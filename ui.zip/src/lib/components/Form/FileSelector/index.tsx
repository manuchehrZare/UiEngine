import { UploadFile } from '@mui/icons-material';
import type { FC } from 'react';
import { Children, memo, useEffect } from 'react';
import { useController } from 'react-hook-form';
import type { IFileSelectorProps } from './type';
import { isArray, omit } from 'lodash';
import { Button, Input, Tooltip, useForm, useTranslation } from '../../..';
import { v4 as uuidv4 } from 'uuid';
import { Box, TextField } from '@mui/material';
import * as yup from 'yup';

const FileSelector: FC<IFileSelectorProps> = ({
    name,
    control,
    onUpdateFile,
    fullWidth = true,
    hidden = false,
    labelEllipsis = true,
    labelPlacement = 'top',
    size = 'medium',
    variant = 'outlined',
    adornmentType = 'endAdornment',
    component = 'Input',
    multiple = false,
    webkitDirectory = false,
    disabled = false,
    ...rest
}: IFileSelectorProps) => {
    const id = uuidv4();
    const { t, locale } = useTranslation();

    const {
        field: { ...field },
        formState: { errors, isSubmitted },
    } = useController({ name, control });

    const {
        control: inputControl,
        setValue: inputSetValue,
        formState: { isSubmitted: isFileSelectorSubmitted, isSubmitting: isFileSelectorSubmitting },
        reset,
        getValues,
        trigger,
        handleSubmit,
    } = useForm({
        defaultValues: {
            [name]: '',
        },
        validationSchema: {
            [name]: yup.string().test(
                'testOfMainValidations',
                () => {
                    const errorMessage = errors[name]?.message;
                    return typeof errorMessage === 'object' ? JSON.stringify(errorMessage) : String(errorMessage);
                },
                () => {
                    const errorMessage = errors[name]?.message;
                    return Boolean(!errorMessage);
                },
            ),
        },
    });

    useEffect(() => {
        // Error returned from the main form
        // The component's useForm hook is triggered again
        // This way the component form dynamically updates itself
        // according to the error as in the validationSchema
        trigger(name);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [errors[name]]);

    useEffect(() => {
        // Main form has been submitted, validation written for fileSelector
        // but that validation should be validated in the main component form
        // There's an error in the main form and it hasn't been validated in the component form yet
        if (isSubmitted && errors[name] && !isFileSelectorSubmitted && !isFileSelectorSubmitting) {
            // An empty handleSubmit for component validation, done to reflect the validation on screen
            handleSubmit(() => ({}))();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [errors[name], isFileSelectorSubmitted, isSubmitted, isFileSelectorSubmitting]);

    const filesOnChange = async (current: HTMLInputElement) => {
        if (current?.files?.length) {
            await field?.onChange(Array.from(current.files));
            onUpdateFile?.(current.files);
            inputSetValue(
                name,
                current.files.length > 1
                    ? `${current.files.length} ${t(locale.labels.selectedFiles)}`
                    : current.files[0].name,
            );
        }
    };
    useEffect(() => {
        !field?.value && getValues(name) && reset();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [field?.value]);

    return (
        <>
            <TextField
                id={id}
                type="file"
                onChange={async (e) => {
                    (e.target as HTMLInputElement)?.files?.length &&
                        (await filesOnChange(e.target as HTMLInputElement));
                }}
                sx={{ display: 'none' }}
                inputProps={{
                    multiple,
                    ...(webkitDirectory && { webkitdirectory: 'true' }),
                    ...(rest?.accept && { accept: rest?.accept?.map((a) => `.${a}`)?.join(',') }),
                    onClick: (e) => {
                        (e.target as HTMLInputElement).value = '';
                    },
                }}
            />
            <Tooltip
                sx={{ ...(component !== 'Input' && { display: 'none' }) }}
                title={
                    isArray(field?.value) && field?.value?.length > 1 ? (
                        <Box component="ul">
                            {Children.toArray(field.value.map((file: File) => <li>{file?.name}</li>))}
                        </Box>
                    ) : (
                        ''
                    )
                }
                placement="bottom-start">
                <Input
                    inputRef={rest?.inputRef}
                    name={name}
                    control={inputControl}
                    readOnly
                    inputProps={{ onClick: () => document?.getElementById(id)?.click(), style: { cursor: 'default' } }}
                    fullWidth={fullWidth}
                    hidden={hidden}
                    labelEllipsis={labelEllipsis}
                    labelPlacement={labelPlacement}
                    size={size}
                    variant={variant}
                    {...omit(rest, ['ButtonProps', 'component', 'accept'])}
                    {...{
                        ...(adornmentType !== 'hidden' && {
                            [`${adornmentType}`]: (
                                <Button
                                    disabled={disabled}
                                    sx={{ ...(adornmentType === 'endAdornment' ? { mr: '-5px' } : { ml: '-9.5px' }) }}
                                    iconButton
                                    icon={<UploadFile />}
                                    onClick={() => document?.getElementById(id)?.click()}
                                />
                            ),
                        }),
                    }}
                />
            </Tooltip>
            {component === 'Button' && (
                <Button
                    disabled={disabled}
                    icon={<UploadFile />}
                    iconButton
                    {...(rest as any)?.ButtonProps}
                    onClick={() => document?.getElementById(id)?.click()}
                />
            )}
        </>
    );
};

export default memo(FileSelector);
