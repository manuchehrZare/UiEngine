import 'filepond-polyfill';
import type { FC } from 'react';
import { memo, useEffect, useRef, useState } from 'react';
import { useController } from 'react-hook-form';
import { FilePond, registerPlugin } from 'react-filepond';
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type';
import FilePondPluginFileValidateSize from 'filepond-plugin-file-validate-size';
import FilePondPluginImagePreview from 'filepond-plugin-image-preview';
import 'filepond/dist/filepond.min.css';
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css';
import type { IUploadDocument, IDocumentDetail, IUploadProps } from './type';
import { FileGenerateTypeEnum, FileInsertLocationEnum } from './type';
import { getLabels } from './labels';
import type { DesignType, IResultData } from '../../..';
import { Box, constants, deepCopy, manageClassNames, useStorage, useTranslation, useWatch } from '../../..';
import type { Theme } from '@mui/material';
import { FormControl, FormHelperText, Typography } from '@mui/material';
import { getUnixTime } from 'date-fns';
import type { FilePondErrorDescription, FilePondFile } from 'filepond';
import MuiUploadSxProps from './style';
import ThemeProvider from '../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

registerPlugin(FilePondPluginFileValidateSize, FilePondPluginFileValidateType, FilePondPluginImagePreview);
/* istanbul ignore next */
const Upload: FC<IUploadProps> = ({
    onChange,
    onRemove,
    onError,
    getPath,
    multiple = false,
    acceptedFileTypes,
    maxSize,
    id,
    path = '',
    label,
    name,
    fileName,
    apiUrl,
    token,
    helperText,
    chunkUploads = false,
    chunkForce = false,
    chunkRetryDelays = [500, 1000, 3000],
    chunkSize = 5000000,
    instantUpload = true,
    itemInsertLocation = 'before',
    control,
    setValue,
    sx,
    design,
    deps,
    allowImagePreview = false,
    required = false,
    labelEllipsis = true,
    variant = 'outlined',
}: IUploadProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const {
        field,
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });
    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);
    const { t, locale } = useTranslation();
    const uploadItemValue: IUploadDocument[] = useWatch({ control, fieldName: name });
    const [removePermission, setRemovePermission] = useState<boolean>(false);
    const uploadRef: any = useRef(null);
    const [isInit, setIsInit] = useState<boolean>(true);

    const getFilePath = (): string => (uploadItemValue?.length && uploadItemValue[0].DocumentPath) || path;

    const generateFile = (file: FilePondFile | IUploadDocument, type: FileGenerateTypeEnum) => ({
        source: type === FileGenerateTypeEnum.LOCAL ? (file as FilePondFile).source : (file as IUploadDocument),
        options: {
            type: 'limbo',
            file: {
                name:
                    type === FileGenerateTypeEnum.LOCAL
                        ? (file as FilePondFile).filename
                        : (file as IUploadDocument).DocumentName,
                size:
                    type === FileGenerateTypeEnum.LOCAL
                        ? (file as FilePondFile).fileSize
                        : (file as IUploadDocument).DocumentSize,
                date:
                    type === FileGenerateTypeEnum.LOCAL
                        ? Number(getUnixTime(new Date()))
                        : (file as IUploadDocument).Date,
            },
        },
    });

    const getLocalFiles = (list: FilePondFile[] | IUploadDocument[], type: FileGenerateTypeEnum): any[] => {
        return list?.length ? list.map((item: any) => generateFile(item, type)) : [];
    };

    const generateFormFileData = (data: IResultData<IDocumentDetail>) => ({
        DMSId: data.Data.Id,
        DocumentName: `${data.Data.FileName}${data.Data.Extension}`,
        DocumentSize: data.Data.Size,
        DocumentPath: data.Data.Path,
        Date: Number(getUnixTime(new Date())),
    });

    /**
     * The component does the deletion via reference. this function works for form data.
     * @param file
     */
    const onFileRemove = (file: FilePondFile) => {
        const oldDocuments: IUploadDocument[] = deepCopy(uploadItemValue) || [];
        const removedFile: IUploadDocument | undefined = oldDocuments.find(
            (a: IUploadDocument) => a.DocumentName === file.filename,
        );
        if (removedFile) {
            const newDocuments: IUploadDocument[] = oldDocuments.filter(
                (a: IUploadDocument) => a.DMSId !== removedFile?.DMSId,
            );
            setValue(name, newDocuments);
            onRemove?.(removedFile);
            setRemovePermission(false);
        }
    };

    /**
     * This function works by checking to show newly added from the same files in the component.
     * @param file
     * @param isSuccess It has been added for the purpose of checking whether it is the same for successfully uploaded files.
     */
    const onLocalFileAdd = (file: any, isSuccess?: boolean) => {
        const refFiles: any[] = getLocalFiles(uploadRef?.current?.getFiles(), FileGenerateTypeEnum.LOCAL);
        if (
            isSuccess &&
            refFiles.findIndex((item: any) => item.options.file.name === file.options.file.name) > -1 &&
            refFiles.filter((item: any) => item.options.file.name === file.options.file.name).length > 1
        ) {
            // Same File Indexes For Remove
            const sameFileIndexes: number[] = refFiles
                .map((item: any, index: number) => (item.options.file.name === file.options.file.name ? index : ''))
                .filter(String) as number[];
            uploadRef?.current?.removeFile(
                uploadRef?.current?.getFile(
                    sameFileIndexes[
                        itemInsertLocation === FileInsertLocationEnum.BEFORE ? sameFileIndexes.length - 1 : 0
                    ],
                ),
            );
        }
    };

    /**
     * For New Form Data
     * @param data
     */
    const onFormFileAdd = (data: IResultData<IDocumentDetail>) => {
        const newFile: IUploadDocument = generateFormFileData(data);
        let newDoc: IUploadDocument[] = [];
        const formDocValue: IUploadDocument[] = control._formValues[name];
        if (formDocValue.findIndex((item: IUploadDocument) => item.DMSId === newFile.DMSId) > -1) {
            // Same Control
            newDoc = [...formDocValue.filter((fItem: IUploadDocument) => fItem.DMSId !== newFile.DMSId), newFile];
        } else {
            // New Add
            newDoc = [...formDocValue, newFile];
        }
        setValue(name, newDoc);
        // For Same Control --> onLocalFileAdd call
        onLocalFileAdd(generateFile(newFile, FileGenerateTypeEnum.FORM), true);
        onChange?.(newFile);
    };

    const getServerInfo = (): any => ({
        revert: (_: any, load: any, err: any) => {
            setRemovePermission(true); // to block onremovefile
            err('Remove Error!');
            load();
        },
        process: {
            url: apiUrl,
            method: 'POST',
            withCredentials: false,
            headers: {
                Authorization: `Bearer ${token}`,
                'X-Path': getFilePath(),
            },
            timeout: Number(import.meta.env.VITE_APP_ABORT_TIME),
            onload: (response: string) => onFormFileAdd(JSON.parse(response)), // It works as soon as it is successfully added.
        },
    });

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        getPath?.(getFilePath());
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (isInit && uploadItemValue.length) {
            uploadRef?.current?.addFiles(getLocalFiles(uploadItemValue, FileGenerateTypeEnum.FORM));
            setIsInit(false);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [uploadItemValue]);

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <FormControl
                className={manageClassNames('upload-form-control', {
                    [constants.classNames.labelEllipsis]: labelEllipsis,
                })}
                variant={variant}
                error={Boolean(error?.message) && validationControl}
                sx={sx}>
                <Box
                    {...(variant === 'outlined' && { component: 'fieldset' })}
                    className={manageClassNames('file-upload-container', {
                        error: Boolean(error?.message),
                        [constants.classNames.labelEllipsis]: labelEllipsis,
                    })}
                    sx={{
                        ...MuiUploadSxProps({
                            design: getComponentDesignProperty(design, storageDesign.newValue),
                            variant,
                        }),
                    }}>
                    {label && (
                        <Typography component="legend" title={getLabel()}>
                            {getLabel()}
                        </Typography>
                    )}
                    <FilePond
                        {...field}
                        id={id}
                        ref={uploadRef}
                        name={fileName || 'file'}
                        acceptedFileTypes={acceptedFileTypes}
                        allowFileSizeValidation
                        instantUpload={instantUpload}
                        checkValidity
                        chunkUploads={chunkUploads}
                        chunkSize={chunkSize}
                        chunkForce={chunkForce}
                        chunkRetryDelays={chunkRetryDelays}
                        {...getLabels(t)}
                        {...(maxSize && { maxFileSize: `${String(maxSize)}KB` })}
                        server={getServerInfo()}
                        allowImagePreview={allowImagePreview}
                        allowMultiple={multiple}
                        maxParallelUploads={20}
                        itemInsertLocationFreedom={false}
                        itemInsertLocation={itemInsertLocation}
                        onremovefile={(_: FilePondErrorDescription | null, file: FilePondFile) =>
                            removePermission && file && onFileRemove(file)
                        }
                        onerror={(err: FilePondErrorDescription, file?: FilePondFile) => onError?.(err, file)}
                        labelIdle={
                            multiple
                                ? `${t(locale.labels.dragAndDropFilesIntoThisArea)} ${t(
                                      locale.labels.or,
                                  )} <span class="filepond--label-action">${t(locale.labels.selectFile)}</span>`
                                : `${t(locale.labels.dragAndDropFileIntoThisArea)} ${t(
                                      locale.labels.or,
                                  )} <span class="filepond--label-action">${t(locale.labels.selectFile)}</span>`
                        }
                    />
                </Box>
                {(error?.message || helperText) && (
                    <FormHelperText className={manageClassNames(generateClass('HelperText'), 'upload')}>
                        {(validationControl && error?.message) || helperText}
                    </FormHelperText>
                )}
            </FormControl>
        </ThemeProvider>
    );
};

export default memo(Upload);
