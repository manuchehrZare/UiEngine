import type { RadioGroupProps } from '@mui/material';
import type { ICommonFieldProps } from '../commonTypes';

export interface IRadioGroupProps
    extends Pick<RadioGroupProps, 'children' | 'row' | 'onChange' | 'sx'>,
        Pick<
            ICommonFieldProps,
            | 'name'
            | 'helperText'
            | 'control'
            | 'design'
            | 'labelPlacement'
            | 'labelWidth'
            | 'labelEllipsis'
            | 'deps'
            | 'fullWidth'
        > {
    label?: string;
}
