import { autocompleteClasses, Autocomplete as MuiAutocomplete, TextField } from '@mui/material';
import { isBoolean, isNumber, isString, omit, uniqBy } from 'lodash';
import { useController } from 'react-hook-form';
import type { IAutocompleteProps } from '../type';
import { KeyboardArrowDown } from '@mui/icons-material';
import { DesignTypeEnum } from '../../../../utils/types/common';
import { generateClass, i18n, locale, manageClassNames, stripHtmlFromText } from '../../../../utils';
import { Box, chipClasses } from '../../../../../lib';
import { renderToString } from 'react-dom/server';
import { useMemo, type JSX, type ReactElement } from 'react';

const Autocomplete = <T,>({
    helperText,
    name,
    autoComplete,
    disabled,
    readOnly,
    required,
    label,
    hidden,
    autoFocus,
    open,
    noOptionsDataText = i18n.t(locale.contents.thereWereNoResults),
    loadingText = i18n.t(locale.contents.loading),
    disableCloseOnSelect,
    options,
    multiple,
    control,
    size,
    fullWidth,
    variant,
    onFocus,
    onKeyPress,
    onBlur,
    onChange,
    className,
    placeholder,
    popupIcon,
    openText = '',
    closeText = '',
    disablePopupIconRotate,
    componentsProps,
    deps,
    ChipProps,
    renderTags,
    showSelectedItemsSummary,
    getOptionDisabled,
    ...rest
}: IAutocompleteProps<T>): JSX.Element => {
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const optionsData = useMemo<T[]>(() => {
        if (options?.data?.length) {
            return options?.dataFormatter ? options.dataFormatter(options.data) : options.data;
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [options?.data, options?.dataFormatter]);

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    const renderInput = (params: any) => {
        return (
            <TextField
                {...params}
                placeholder={placeholder}
                name={field.name}
                inputRef={ref}
                size={size}
                label={getLabel()}
                autoComplete={autoComplete}
                autoFocus={autoFocus}
                variant={variant}
                error={Boolean(error) && validationControl}
                helperText={(validationControl && error?.message) || helperText}
                onFocus={onFocus}
                onBlur={onBlur}
                onKeyPress={onKeyPress}
            />
        );
    };

    return (
        <MuiAutocomplete
            {...field}
            options={uniqBy(
                options?.renderDisplayList
                    ? optionsData.map((item) => {
                          const displayFieldData = options.renderDisplayList
                              ? isString(options.renderDisplayList(item))
                                  ? options?.renderDisplayList(item)
                                  : stripHtmlFromText(renderToString(options?.renderDisplayList(item) as ReactElement))
                              : item[options.displayField];
                          return {
                              ...item,
                              [options.displayField]: displayFieldData,
                          };
                      })
                    : optionsData,
                options?.displayValue || '',
            )}
            {...(options?.renderDisplayList && {
                renderOption: (props, option: T) => {
                    const optionData =
                        optionsData?.find((item) => item[options.displayValue] === option[options.displayValue]) ||
                        option;

                    return (
                        <Box component="li" {...props} key={props.id}>
                            {options?.renderDisplayList?.(optionData)}
                        </Box>
                    );
                },
            })}
            getOptionLabel={(option: any) => {
                if ((isString(option) || isNumber(option) || isBoolean(option)) && optionsData?.length && option) {
                    const item = optionsData.filter((findItem) => findItem[options?.displayValue] === option)[0];
                    return options?.renderDisplayField
                        ? options?.renderDisplayField(item)
                        : item[options?.displayField];
                }
                return option[options?.displayField || ''] || '';
            }}
            clearOnEscape
            disableClearable={optionsData?.length === 0}
            disableCloseOnSelect={multiple ? true : disableCloseOnSelect}
            open={open}
            openText={openText}
            closeText={closeText}
            multiple={optionsData?.length > 0 && multiple} // A check for the existence of options.data has been added, as it shows an empty chip if the initial value is given for the form in multiple use fed with delayed data.
            fullWidth={fullWidth}
            noOptionsText={noOptionsDataText}
            popupIcon={popupIcon || <KeyboardArrowDown />}
            loadingText={loadingText}
            disabled={disabled}
            readOnly={readOnly}
            hidden={hidden}
            size={size}
            ChipProps={{
                variant: 'standard',
                size: 'small',
                className: manageClassNames(autocompleteClasses.tag, {
                    [`${ChipProps?.className}`]: Boolean(ChipProps?.className),
                    [`${chipClasses?.cornered}`]:
                        typeof ChipProps?.cornered !== 'undefined'
                            ? ChipProps.cornered
                            : !(ChipProps?.leftCornered || ChipProps?.rightCornered),
                    [`${chipClasses?.corneredLeft}`]: ChipProps?.leftCornered,
                    [`${chipClasses?.corneredRight}`]: ChipProps?.rightCornered,
                }),
                ...omit(ChipProps, ['className', 'cornered', 'leftCornered', 'rightCornered']),
            }}
            renderTags={
                renderTags
                    ? renderTags
                    : showSelectedItemsSummary
                      ? (tagValue) => {
                            const count = tagValue?.length || 0;
                            return (
                                <Box className={manageClassNames(generateClass('selectedItems-summary'), variant)}>
                                    {typeof showSelectedItemsSummary === 'function'
                                        ? showSelectedItemsSummary(count)
                                        : i18n.t(locale.labels.membersSelected, { count })}
                                </Box>
                            );
                        }
                      : undefined
            }
            componentsProps={{
                paper: {
                    className: manageClassNames(DesignTypeEnum.Default, {
                        [`${className}__paper`]: Boolean(className),
                        [`${componentsProps?.paper?.className}`]: Boolean(componentsProps?.paper?.className),
                    }),
                    ...(componentsProps?.paper ? omit(componentsProps?.paper, ['className']) : {}),
                },
                popupIndicator: {
                    className: manageClassNames({
                        disablePopupIconRotate: disablePopupIconRotate,
                        [`${className}__popupIndicator`]: Boolean(className),
                        [`${componentsProps?.popupIndicator?.className}`]: Boolean(
                            componentsProps?.popupIndicator?.className,
                        ),
                    }),
                    ...(componentsProps?.popupIndicator ? omit(componentsProps?.popupIndicator, ['className']) : {}),
                },
                ...(componentsProps ? omit(componentsProps, ['paper', 'popupIndicator']) : {}),
            }}
            isOptionEqualToValue={(option, value) => {
                const key = options.displayValue;
                return (option?.[key] ?? '') === value;
            }}
            className={manageClassNames(DesignTypeEnum.Default, { [`${className}`]: Boolean(className) })}
            renderInput={(params) => renderInput(params)}
            onChange={(event, newData, reason, details) => {
                const value = Array.isArray(newData)
                    ? newData.map((item) =>
                          typeof item === 'object' && item !== null ? item[options?.displayValue] : item,
                      )
                    : typeof newData === 'object' && newData !== null
                      ? newData[options?.displayValue]
                      : (newData ?? null);

                field.onChange(value);
                onChange?.(event, value, reason, details);
            }}
            getOptionDisabled={getOptionDisabled}
            {...omit(rest, ['design', 'errors', 'labelEllipsis', 'labelPlacement', 'labelWidth', 'onChange'])}
        />
    );
};
export default Autocomplete;
