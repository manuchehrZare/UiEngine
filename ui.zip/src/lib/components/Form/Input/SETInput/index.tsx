import { KeyboardCapslock, Visibility, VisibilityOff } from '@mui/icons-material';
import { Box, FormControl, FormHelperText, InputAdornment, InputBase, InputLabel } from '@mui/material';
import { isBoolean, isNumber, isUndefined } from 'lodash';
import type { FC } from 'react';
import { useEffect, useRef, useState } from 'react';
import { useController } from 'react-hook-form';
import useCapsLockDetector from '../../../../hooks/useCapsLockDetector';
import { constants, generateClass, manageClassNames, useTranslation } from '../../../../utils';
import { DesignTypeEnum } from '../../../../utils/types/common';
import TextMaskCustom from '../MaskInput';
import type { ICapslockDetectorProps, IInputProps } from '../type';
import { InputTypeEnum } from '../type';
import Button from '../../Button/Button';
import Tooltip from '../../../Display/Tooltip';

const Input: FC<IInputProps> = ({
    name,
    control,
    helperText,
    autoComplete,
    startAdornment,
    endAdornment,
    maxLength,
    minLength,
    readOnly,
    mask,
    label,
    labelPlacement,
    labelWidth,
    labelEllipsis,
    required,
    maskLazy,
    sx,
    type,
    placeholder,
    accept,
    maskChar,
    deps,
    passwordVisibility,
    capslockDetector,
    className,
    variant,
    ...rest
}: IInputProps) => {
    const { t, locale } = useTranslation();
    const labelRef: any = useRef(null);
    const [labelStyleWidth, setLabelStyleWidth] = useState(null);
    const [maskView, setMaskView] = useState<boolean>(true);
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const showCapslockStatus =
        capslockDetector &&
        Boolean(rest?.inputRef) &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useCapsLockDetector(rest?.inputRef as React.RefObject<HTMLInputElement | HTMLTextAreaElement>);

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const renderMaskInput = () => {
        if (mask) {
            return {
                inputComponent: TextMaskCustom as any,
                inputProps: {
                    mask,
                    maxLength,
                    minLength,
                    lazy: !placeholder && isUndefined(maskLazy) ? false : maskView,
                    placeholderChar: maskChar,
                },
            };
        }

        return {
            inputProps: {
                maxLength,
                minLength,
            },
        };
    };

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        /*istanbul ignore else*/
        labelRef && setLabelStyleWidth(labelRef?.current?.offsetWidth || null);
    }, [labelRef?.current?.offsetWidth]);

    useEffect(() => {
        isBoolean(showCapslockStatus) &&
            !isBoolean(capslockDetector) &&
            capslockDetector?.onCapslockDetector?.(
                showCapslockStatus,
                capslockDetector?.Tooltip?.title || t(locale.labels.capsLockActive),
            );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [showCapslockStatus]);

    return (
        <FormControl
            variant={variant}
            className={manageClassNames(
                labelPlacement,
                { [constants.classNames.labelEllipsis]: labelEllipsis },
                className,
            )}
            error={Boolean(error) && validationControl}
            sx={sx}>
            <InputLabel
                ref={labelRef}
                className={manageClassNames(labelPlacement, { [constants.classNames.labelEllipsis]: labelEllipsis })}
                htmlFor={name}
                title={typeof getLabel() === 'string' ? `${getLabel()}` : ''}
                sx={{
                    width: labelWidth,
                }}>
                {getLabel()}
            </InputLabel>
            <Box
                sx={{
                    display: type === InputTypeEnum.Hidden ? 'none' : 'flex',
                    flexDirection: 'column',
                    width: `calc(100% - ${
                        labelPlacement === 'top' || (!label && !labelWidth)
                            ? '0px'
                            : labelWidth === 'auto'
                              ? `${String(labelStyleWidth || 0)}px`
                              : labelWidth
                                ? isNumber(labelWidth)
                                    ? `${labelWidth}px`
                                    : labelWidth
                                : `var(--field-label-width-${[DesignTypeEnum.SET]})`
                    })`,
                }}>
                <InputBase
                    {...field}
                    className={manageClassNames(generateClass('Mui-InputBase-Capslock'), {
                        [`capslockDetector`]: capslockDetector,
                    })}
                    name={name}
                    inputRef={ref}
                    fullWidth
                    autoComplete={autoComplete}
                    spellCheck={false}
                    placeholder={placeholder}
                    type={
                        type === 'password'
                            ? showPassword
                                ? undefined
                                : 'password'
                            : type === InputTypeEnum.File
                              ? 'file'
                              : String(type)
                    }
                    {...(type === InputTypeEnum.File
                        ? {
                              componentsProps: {
                                  input: {
                                      accept: accept?.map(/* istanbul ignore next */ (a) => `.${a}`)?.join(','),
                                  },
                              },
                          }
                        : {})}
                    onChange={
                        /* istanbul ignore next */ (e: any) => {
                            const maskReplace: string = mask?.replace(/[a0_*.,-]/g, maskChar);
                            const value = e.target?.value;
                            field.onChange(value);
                            if (placeholder && isUndefined(maskLazy) && value === maskReplace) {
                                setMaskView(true);
                            } else if (placeholder && isUndefined(maskLazy) && value && value !== maskReplace) {
                                setMaskView(false);
                            } else if (!placeholder && isUndefined(maskLazy)) {
                                setMaskView(false);
                            }
                        }
                    }
                    {...{
                        ...(startAdornment
                            ? {
                                  startAdornment: <InputAdornment position="start">{startAdornment}</InputAdornment>,
                              }
                            : {}),
                        ...(endAdornment || passwordVisibility || capslockDetector
                            ? {
                                  endAdornment: (
                                      <InputAdornment position="end">
                                          {type === 'password' && passwordVisibility && (
                                              <Button
                                                  iconButton
                                                  variant="text"
                                                  color="primary"
                                                  onClick={handleClickShowPassword}
                                                  onMouseDown={(e) => e.preventDefault()}
                                                  icon={showPassword ? <VisibilityOff /> : <Visibility />}
                                              />
                                          )}

                                          {showCapslockStatus && (
                                              <Tooltip
                                                  show
                                                  title={t(locale.labels.capsLockActive)}
                                                  placement="bottom-end"
                                                  {...(capslockDetector as ICapslockDetectorProps)?.Tooltip}
                                                  className={manageClassNames(
                                                      generateClass('Detector-Tooltip'),
                                                      DesignTypeEnum.SET,
                                                  )}
                                                  design={DesignTypeEnum.SET}>
                                                  <KeyboardCapslock
                                                      color="primary"
                                                      onMouseDown={(e) => e.preventDefault()}
                                                  />
                                              </Tooltip>
                                          )}
                                          {endAdornment}
                                      </InputAdornment>
                                  ),
                              }
                            : {}),
                        readOnly,
                        ...renderMaskInput(),
                    }}
                    {...rest}
                />
                {(error?.message || helperText) && (
                    <FormHelperText>{(validationControl && error?.message) || helperText}</FormHelperText>
                )}
            </Box>
        </FormControl>
    );
};

export default Input;
