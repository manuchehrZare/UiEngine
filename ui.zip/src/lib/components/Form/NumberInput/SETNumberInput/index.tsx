import type { FC } from 'react';
import { useEffect, useRef, useState } from 'react';
import { useController } from 'react-hook-form';
import { Box, FormControl, FormHelperText, InputAdornment, InputBase, InputLabel } from '@mui/material';
import type { INumberInputProps } from '../type';
import NumberInputBaseComponent from '../NumberInput';
import { DesignTypeEnum } from '../../../../utils/types/common';
import { isNumber, trim } from 'lodash';
import { constants, manageClassNames } from '../../../../utils';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import Button from '../../Button/Button';

const NumberInput: FC<INumberInputProps> = ({
    allowEmptyFormatting,
    allowLeadingZeros,
    allowNegative,
    autoComplete,
    decimalScale,
    decimalSeparator,
    disabled,
    endAdornment,
    fixedDecimalScale,
    format,
    helperText,
    isAllowed,
    label,
    labelPlacement,
    labelWidth,
    labelEllipsis,
    mask,
    maxLength,
    minLength,
    name,
    prefix,
    readOnly,
    removeFormatting,
    required,
    startAdornment,
    suffix,
    thousandSeparator,
    type,
    control, // not defaultProps
    returnValue = 'floatValue', // not defaultProps
    sx,
    onKeyPress,
    onBlur,
    onFocus,
    placeholder,
    textAlign,
    className,
    deps,
    passwordVisibility,
    variant,
}: INumberInputProps) => {
    const labelRef: any = useRef(null);
    const [maskView, setMaskView] = useState<boolean>();
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });
    const [labelStyleWidth, setLabelStyleWidth] = useState(null);

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        /*istanbul ignore else*/
        labelRef && setLabelStyleWidth(labelRef?.current?.offsetWidth || null);
        // eslint-disable-next-line react-hooks/refs
    }, [labelRef?.current?.offsetWidth]);

    return (
        <FormControl
            variant={variant}
            className={manageClassNames(labelPlacement, className, {
                [constants.classNames.labelEllipsis]: labelEllipsis,
            })}
            error={Boolean(error) && validationControl}
            disabled={disabled}
            sx={sx}>
            <InputLabel
                ref={labelRef}
                className={manageClassNames(labelPlacement, {
                    [constants.classNames.labelEllipsis]: labelEllipsis,
                })}
                htmlFor={name}
                title={typeof getLabel() === 'string' ? `${getLabel()}` : ''}
                sx={{
                    width: labelWidth,
                }}>
                {getLabel()}
            </InputLabel>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    width: `calc(100% - ${
                        labelPlacement === 'top' || (!label && !labelWidth)
                            ? '0px'
                            : labelWidth === 'auto'
                              ? `${String(labelStyleWidth || 0)}px`
                              : labelWidth
                                ? isNumber(labelWidth)
                                    ? `${labelWidth}px`
                                    : labelWidth
                                : `var(--field-label-width-${[DesignTypeEnum.SET]})`
                    })`,
                    input: {
                        textAlign: field.value || !placeholder || trim(placeholder).length === 0 ? textAlign : 'left',
                    },
                }}>
                <InputBase
                    {...field}
                    name={name}
                    inputRef={ref}
                    fullWidth
                    disabled={disabled}
                    autoComplete={autoComplete}
                    spellCheck={false}
                    onKeyPress={onKeyPress}
                    onFocus={
                        /* istanbul ignore next */ (e) => {
                            if (!placeholder && allowEmptyFormatting && !field.value) {
                                setMaskView(true);
                            } else if (!placeholder && allowEmptyFormatting && (!field.value || field.value)) {
                                setMaskView(true);
                            }
                            onFocus?.(e);
                        }
                    }
                    onBlur={
                        /* istanbul ignore next */ (e) => {
                            if (placeholder && allowEmptyFormatting && !field.value) {
                                setMaskView(false);
                            } else if (!placeholder && allowEmptyFormatting && !field.value) {
                                setMaskView(false);
                            }
                            onBlur?.(e);
                            field.onBlur();
                        }
                    }
                    {...{
                        ...(startAdornment
                            ? {
                                  startAdornment: <InputAdornment position="start">{startAdornment}</InputAdornment>,
                              }
                            : {}),
                        ...(endAdornment || passwordVisibility
                            ? {
                                  endAdornment: (
                                      <InputAdornment position="end">
                                          {type === 'password' && passwordVisibility && (
                                              <Button
                                                  iconButton
                                                  variant="text"
                                                  color="primary"
                                                  icon={showPassword ? <VisibilityOff /> : <Visibility />}
                                                  onClick={handleClickShowPassword}
                                              />
                                          )}
                                          {endAdornment}
                                      </InputAdornment>
                                  ),
                              }
                            : {}),
                        readOnly,
                        inputComponent: NumberInputBaseComponent as any,
                        inputProps: {
                            type: type === 'password' ? (showPassword ? undefined : 'password') : String(type),
                            allowEmptyFormatting:
                                placeholder && !field.value ? false : !placeholder && !field.value ? true : maskView,
                            allowLeadingZeros,
                            allowNegative,
                            decimalScale,
                            decimalSeparator,
                            fixedDecimalScale,
                            format,
                            isAllowed,
                            mask,
                            maxLength,
                            minLength,
                            prefix,
                            removeFormatting,
                            suffix,
                            thousandSeparator,
                            returnValue, // not defaultProps
                            control, // not defaultProps
                            placeholder,
                        },
                    }}
                />
                {(error?.message || helperText) && (
                    <FormHelperText>{(validationControl && error?.message) || helperText}</FormHelperText>
                )}
            </Box>
        </FormControl>
    );
};

export default NumberInput;
