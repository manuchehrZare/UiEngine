import type {
    DateTimePickerSlotsComponents,
    DateTimePickerProps,
    DateTimePickerSlotsComponentsProps,
} from '@mui/x-date-pickers';
import type { TextFieldProps } from '@mui/material';
import type { ICommonFieldProps } from '../commonTypes';
import { isUndefined } from 'lodash';
import { pickerProps } from '../_helper';
import { DesignTypeEnum, constants, getSessionStorageItem } from '../../../utils';

export interface IDateTimePickerProps
    extends Pick<
            DateTimePickerProps<any>,
            | 'ampmInClock'
            | 'autoFocus'
            | 'className'
            | 'disableHighlightToday'
            | 'disableIgnoringDatePartForTimeValidation'
            | 'disableOpenPicker'
            | 'disablePast'
            | 'disabled'
            | 'displayWeekNumber'
            | 'format'
            | 'formatDensity'
            | 'label'
            | 'loading'
            | 'localeText'
            | 'maxDate'
            | 'maxDateTime'
            | 'maxTime'
            | 'minDate'
            | 'minDateTime'
            | 'minTime'
            | 'minutesStep'
            | 'onClose'
            | 'onMonthChange'
            | 'onOpen'
            | 'onViewChange'
            | 'onYearChange'
            | 'shouldDisableDate'
            | 'shouldDisableTime'
            | 'shouldDisableYear'
            | 'views'
        >,
        Omit<ICommonFieldProps, 'startAdornment' | 'endAdornment'>,
        Pick<TextFieldProps, 'placeholder' | 'sx' | 'onKeyPress' | 'onFocus' | 'onBlur'> {
    analogClock?: boolean;
    clearable?: boolean | undefined;
    clearText?: any;
    disableCloseOnSelect?: boolean;
    required?: boolean;
    showTodayButton?: boolean | undefined;
    /*
    The props used for each component slot.
    */
    slotProps?: Omit<
        DateTimePickerSlotsComponentsProps<any>,
        'textField' | 'desktopPaper' | 'openPickerButton' | 'actionBar' | 'inputAdornment'
    >;
    /*
    Overridable component slots.
    */
    slots?: Omit<DateTimePickerSlotsComponents<any>, 'textField' | 'field' | 'TextField' | 'Field'>;
    todayText?: any;
    unixTime?: boolean;
}

export enum DateTimeTypeEnum {
    day = 'day',
    month = 'month',
    year = 'year',
    hours = 'hours',
    minutes = 'minutes',
    seconds = 'seconds',
}

export type DateTimeType = keyof typeof DateTimeTypeEnum;

export const placeholderFormat = (data: string): string => {
    const dateSeparator =
        getSessionStorageItem(constants.key.PROVIDER_DESIGN) === DesignTypeEnum.SET
            ? pickerProps?.SET?.dateTimePicker?.dateSeparator
            : pickerProps?.default?.dateTimePicker?.dateSeparator;
    const timeSeparator =
        getSessionStorageItem(constants.key.PROVIDER_DESIGN) === DesignTypeEnum.SET
            ? pickerProps?.SET?.dateTimePicker?.timeSeparator
            : pickerProps?.default?.dateTimePicker?.timeSeparator;
    switch (!isUndefined(data)) {
        case data === `dd${dateSeparator}MM${dateSeparator}yyyy HH` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy mm` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy ss` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy HH${timeSeparator}mm` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy HH${timeSeparator}ss` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy mm${timeSeparator}HH` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy mm${timeSeparator}ss` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy ss${timeSeparator}HH` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy ss${timeSeparator}mm` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy HH${timeSeparator}mm${timeSeparator}ss` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy HH${timeSeparator}ss${timeSeparator}mm` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy mm${timeSeparator}HH${timeSeparator}ss` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy mm${timeSeparator}ss${timeSeparator}HH` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy ss${timeSeparator}HH${timeSeparator}mm` ||
            data === `dd${dateSeparator}MM${dateSeparator}yyyy ss${timeSeparator}mm${timeSeparator}HH` ||
            //--
            data === `dd${dateSeparator}yyyy${dateSeparator}MM HH` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM mm` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM ss` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM HH${timeSeparator}mm` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM HH${timeSeparator}ss` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM mm${timeSeparator}HH` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM mm${timeSeparator}ss` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM ss${timeSeparator}HH` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM ss${timeSeparator}mm` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM HH${timeSeparator}mm${timeSeparator}ss` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM HH${timeSeparator}ss${timeSeparator}mm` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM mm${timeSeparator}HH${timeSeparator}ss` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM mm${timeSeparator}ss${timeSeparator}HH` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM ss${timeSeparator}HH${timeSeparator}mm` ||
            data === `dd${dateSeparator}yyyy${dateSeparator}MM ss${timeSeparator}mm${timeSeparator}HH` ||
            //--
            data === `MM${dateSeparator}dd${dateSeparator}yyyy HH` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy mm` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy ss` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy HH${timeSeparator}mm` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy HH${timeSeparator}ss` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy mm${timeSeparator}HH` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy mm${timeSeparator}ss` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy ss${timeSeparator}HH` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy ss${timeSeparator}mm` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy HH${timeSeparator}mm${timeSeparator}ss` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy HH${timeSeparator}ss${timeSeparator}mm` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy mm${timeSeparator}HH${timeSeparator}ss` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy mm${timeSeparator}ss${timeSeparator}HH` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy ss${timeSeparator}HH${timeSeparator}mm` ||
            data === `MM${dateSeparator}dd${dateSeparator}yyyy ss${timeSeparator}mm${timeSeparator}HH` ||
            //--
            data === `MM${dateSeparator}yyyy${dateSeparator}dd HH` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd mm` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd ss` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd HH${timeSeparator}mm` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd HH${timeSeparator}ss` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd mm${timeSeparator}HH` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd mm${timeSeparator}ss` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd ss${timeSeparator}HH` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd ss${timeSeparator}mm` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd HH${timeSeparator}mm${timeSeparator}ss` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd HH${timeSeparator}ss${timeSeparator}mm` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd mm${timeSeparator}HH${timeSeparator}ss` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd mm${timeSeparator}ss${timeSeparator}HH` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd ss${timeSeparator}HH${timeSeparator}mm` ||
            data === `MM${dateSeparator}yyyy${dateSeparator}dd ss${timeSeparator}mm${timeSeparator}HH` ||
            //--
            data === `yyyy${dateSeparator}dd${dateSeparator}MM HH` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM mm` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM ss` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM HH${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM HH${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM mm${timeSeparator}HH` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM mm${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM ss${timeSeparator}HH` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM ss${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM HH${timeSeparator}mm${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM HH${timeSeparator}ss${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM mm${timeSeparator}HH${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM mm${timeSeparator}ss${timeSeparator}HH` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM ss${timeSeparator}HH${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}dd${dateSeparator}MM ss${timeSeparator}mm${timeSeparator}HH` ||
            //--
            data === `yyyy${dateSeparator}MM${dateSeparator}dd HH` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd mm` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd ss` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd HH${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd HH${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd mm${timeSeparator}HH` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd mm${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd ss${timeSeparator}HH` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd ss${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd HH${timeSeparator}mm${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd HH${timeSeparator}ss${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd mm${timeSeparator}HH${timeSeparator}ss` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd mm${timeSeparator}ss${timeSeparator}HH` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd ss${timeSeparator}HH${timeSeparator}mm` ||
            data === `yyyy${dateSeparator}MM${dateSeparator}dd ss${timeSeparator}mm${timeSeparator}HH`:
            return data;
        default:
            return '';
    }
};
