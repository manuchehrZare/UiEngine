import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { useController } from 'react-hook-form';
import type { DateTimeType, IDateTimePickerProps } from '../type';
import { DateTimeTypeEnum, placeholderFormat } from '../type';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker as MuiDateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { fromUnixTime, getUnixTime, isAfter, isDate, isValid } from 'date-fns';
import trLocale from 'date-fns/locale/tr';
import enLocale from 'date-fns/locale/en-US';
import { EventOutlined } from '@mui/icons-material';
import { isNumber, omit } from 'lodash';
import { pickerProps } from '../../_helper';
import { i18n } from '../../../../utils';
import { LocalesEnum } from '../../../../utils/locales';
import { enUS, renderTimeViewClock, trTR } from '@mui/x-date-pickers';
import { TimeTypeEnum } from '../../../..';

const DateTimePicker: FC<IDateTimePickerProps> = ({
    analogClock,
    control,
    deps,
    format,
    helperText,
    label,
    name,
    onBlur,
    onClose,
    onFocus,
    onOpen,
    placeholder,
    required,
    size,
    slotProps,
    slots,
    unixTime,
    views,
    variant,
    ...rest
}: IDateTimePickerProps) => {
    const dateSeparator = pickerProps.default.dateTimePicker.dateSeparator;
    const timeSeparator = pickerProps.default.dateTimePicker.timeSeparator;
    const [viewsFormat, setViewsFormat] = useState<string>(pickerProps.default.dateTimePicker.inputFormat);
    const [open, setOpen] = useState<boolean>(false);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const localeTextObj: any = {
        [LocalesEnum.TURKISH]: trTR.components.MuiLocalizationProvider.defaultProps.localeText,
        [LocalesEnum.ENGLISH]: enUS.components.MuiLocalizationProvider.defaultProps.localeText,
    };

    const getInputDate = (value: any) => {
        if (unixTime) {
            return value ? fromUnixTime(value) : value;
        }
        return value;
    };

    /* istanbul ignore next */
    const toggleOpen = (val?: boolean) => {
        if (val !== undefined) {
            val && !open && onOpen?.();
            !val && open && onClose?.();
            setOpen(val);
        } else {
            !open && onOpen?.();
            open && onClose?.();
            setOpen((prevState) => !prevState);
        }
    };

    const formatter = (val: string, index: number) => {
        if (val === 'HH' || val === 'mm' || val === 'ss') {
            if (views) {
                if (
                    views[index - 1] === DateTimeTypeEnum.day ||
                    views[index - 1] === DateTimeTypeEnum.month ||
                    views[index - 1] === DateTimeTypeEnum.year
                ) {
                    val = ` ${val}`;
                }
                if (
                    views[index + 1] === DateTimeTypeEnum.hours ||
                    views[index + 1] === DateTimeTypeEnum.minutes ||
                    views[index + 1] === DateTimeTypeEnum.seconds
                ) {
                    val = `${val}${timeSeparator}`;
                }
                if (
                    views[index + 1] === DateTimeTypeEnum.day ||
                    views[index + 1] === DateTimeTypeEnum.month ||
                    views[index + 1] === DateTimeTypeEnum.year
                ) {
                    val = `${val} `;
                }
            }
        }
        if (val === 'dd' || val === 'MM' || val === 'yyyy') {
            if (views) {
                if (
                    views[index + 1] === DateTimeTypeEnum.day ||
                    views[index + 1] === DateTimeTypeEnum.month ||
                    views[index + 1] === DateTimeTypeEnum.year
                ) {
                    val = `${val}${dateSeparator}`;
                }
            }
        }
        return val;
    };

    useEffect(() => {
        if (views?.length) {
            const formatArr: any[] = views?.map((item: DateTimeType, index: number) => {
                if (item === DateTimeTypeEnum.day) {
                    return formatter('dd', index);
                }
                if (item === DateTimeTypeEnum.month) {
                    return formatter('MM', index);
                }
                if (item === DateTimeTypeEnum.year) {
                    return formatter('yyyy', index);
                }
                if (item === DateTimeTypeEnum.hours) {
                    return formatter('HH', index);
                }
                if (item === DateTimeTypeEnum.minutes) {
                    return formatter('mm', index);
                }
                if (item === DateTimeTypeEnum.seconds) {
                    return formatter('ss', index);
                }
                return null;
            });
            const formatString = formatArr.join('');
            setViewsFormat(formatString);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [views]);

    const setOpenTo = () => {
        if (views) {
            if (views[0] === DateTimeTypeEnum.year) return DateTimeTypeEnum.year;
            if (views[0] === DateTimeTypeEnum.month) return DateTimeTypeEnum.month;
            if (views[0] === DateTimeTypeEnum.hours) return DateTimeTypeEnum.hours;
            if (views[0] === DateTimeTypeEnum.minutes) return DateTimeTypeEnum.minutes;
            if (views[0] === DateTimeTypeEnum.seconds) return DateTimeTypeEnum.seconds;
            return DateTimeTypeEnum.day;
        }
        return DateTimeTypeEnum.day;
    };

    const minDateControl = (date: any) => {
        return isAfter(isNumber(date) ? fromUnixTime(date) : date, new Date(1900, 1, 1));
    };

    const errorVal = Boolean(error) || (error && field?.value?.length > 0);
    const helperTextVal = validationControl
        ? // eslint-disable-next-line no-constant-binary-expression
          ((error || !minDateControl(field.value)) && field?.value?.length > 0 && '') ||
          error?.message ||
          helperText ||
          ''
        : helperText || '';

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    return (
        <LocalizationProvider
            dateAdapter={AdapterDateFns}
            adapterLocale={i18n.language === LocalesEnum.TURKISH ? trLocale : enLocale}>
            <MuiDateTimePicker
                {...field}
                className="picker-input"
                value={getInputDate(field?.value)}
                inputRef={ref}
                label={getLabel()}
                autoFocus={false}
                open={open}
                ampm={false}
                onOpen={() => toggleOpen()}
                onClose={() => toggleOpen(false)}
                onChange={(date: any, context) => {
                    let d = null;
                    if (isDate(date) && isValid(date) && minDateControl(date)) {
                        d = unixTime ? Number(getUnixTime(new Date(date))) : date;
                    }
                    const inputEmpty = !d && !context.validationError && !open;
                    const pickerChange = open && !context.validationError && d;
                    if (context || pickerChange || inputEmpty) {
                        let resultD = d;
                        if (d === null) {
                            resultD = inputEmpty ? null : NaN;
                        }
                        field.onChange(resultD);
                    }
                }}
                views={views || [DateTimeTypeEnum.day, TimeTypeEnum.hours, TimeTypeEnum.minutes, TimeTypeEnum.seconds]}
                format={
                    views
                        ? viewsFormat
                        : format || `dd${dateSeparator}MM${dateSeparator}yyyy HH${timeSeparator}mm${timeSeparator}ss`
                }
                localeText={{
                    ...localeTextObj[i18n.language],
                }}
                openTo={setOpenTo()}
                timeSteps={{ hours: 1, minutes: 1, seconds: 1 }}
                slots={{
                    openPickerIcon: () => <EventOutlined fontSize={size} />,
                    ...slots,
                }}
                slotProps={{
                    inputAdornment: {
                        position: 'end',
                    },
                    openPickerButton: {
                        onClick: () => toggleOpen(),
                    },
                    textField: {
                        variant: variant,
                        size: size,
                        error: errorVal && validationControl,
                        helperText: helperTextVal,
                        onFocus: onFocus,
                        onBlur: (e) => {
                            field.onBlur();
                            onBlur?.(e);
                        },
                        inputProps: {
                            placeholder: placeholder
                                ? placeholder
                                : placeholderFormat(
                                      views ? viewsFormat : format || pickerProps.SET.datePicker.inputFormat,
                                  ).replace(/[a-zA-Z]/gm, '_'),
                        },
                        fullWidth: true,
                        id: name,
                        autoComplete: 'off',
                        spellCheck: false,
                    },
                    actionBar: {
                        actions: [],
                    },
                    ...slotProps,
                }}
                {...(analogClock && {
                    viewRenderers: {
                        hours: renderTimeViewClock,
                        minutes: renderTimeViewClock,
                        seconds: renderTimeViewClock,
                    },
                })}
                {...omit(rest, ['fullWidth', 'labelPlacement', 'labelWidth', 'labelEllipsis', 'onKeyPress'])}
            />
        </LocalizationProvider>
    );
};

export default DateTimePicker;
