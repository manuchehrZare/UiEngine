import Default from './DefaultDateTimePicker';
import SET from './SETDateTimePicker';
import type { FC } from 'react';
import { memo } from 'react';
import type { IDateTimePickerProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const DateTimePicker: FC<IDateTimePickerProps> = ({
    design,
    autoFocus = false,
    clearable = false,
    disableCloseOnSelect = false,
    fullWidth = true,
    hidden = false,
    labelPlacement = 'top',
    labelEllipsis = true,
    readOnly = false,
    required = false,
    showTodayButton = false,
    unixTime = false,
    size = 'medium',
    variant = 'outlined',
    ...rest
}: IDateTimePickerProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: (
            <Default
                variant={variant}
                autoFocus={autoFocus}
                clearable={clearable}
                disableCloseOnSelect={disableCloseOnSelect}
                fullWidth={fullWidth}
                hidden={hidden}
                labelPlacement={labelPlacement}
                labelEllipsis={labelEllipsis}
                readOnly={readOnly}
                required={required}
                showTodayButton={showTodayButton}
                size={size}
                unixTime={unixTime}
                {...rest}
            />
        ),
        [DesignTypeEnum.SET]: (
            <SET
                variant={variant}
                autoFocus={autoFocus}
                clearable={clearable}
                disableCloseOnSelect={disableCloseOnSelect}
                fullWidth={fullWidth}
                hidden={hidden}
                labelPlacement={labelPlacement}
                labelEllipsis={labelEllipsis}
                readOnly={readOnly}
                required={required}
                showTodayButton={showTodayButton}
                size={size}
                unixTime={unixTime}
                {...rest}
            />
        ),
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default memo(DateTimePicker);
