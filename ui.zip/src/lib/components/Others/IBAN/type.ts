import type { constants } from '../../../utils';
import type { IInputProps } from '../../Form/Input/type';

export enum IBANErrorTypeEnum {
    FullReplace = 'fullReplace',
    InsertText = 'insertText',
    InvalidDefaultValue = 'invalidDefaultValue',
}
export interface IIBANError {
    /**
     * The error code of the current error
     */
    code: `${IBANErrorTypeEnum}`;
    /**
     * Name of the field where the error occurred
     */
    fieldName: string;
    /**
     * The invalid IBAN value that caused the error
     */
    invalidValue: string;
    /**
     * Error message describing the validation failure
     */
    message: string;
}

export interface IIBANDisplayProps {
    /**
     * Length of the account number part to be displayed
     * @default 9
     */
    accountNoLength?: number;

    /**
     * Flag to indicate if the component is in display mode
     * @default false
     */
    input?: false;

    /**
     * Flag to show account number part in bold
     * @default false
     */
    showBoldAccountNo?: boolean;

    /**
     * IBAN value to be displayed
     */
    value: string;
}
export interface IIBANInputProps
    extends Pick<
        IInputProps,
        'name' | 'control' | 'label' | 'sx' | 'inputProps' | 'readOnly' | 'className' | 'variant'
    > {
    /**
     * Sets a fixed country code for IBAN
     * If true, defaults to 'TR'
     * Otherwise accepts any valid IBAN country code
     * @example
     * fixedCountryCode: true // Forces TR
     * fixedCountryCode: 'DE' // Forces German IBAN format
     */
    fixedCountryCode?: true | keyof typeof constants.IBANFormats;
    /**
     * Flag to indicate if the component is in input mode
     * @default true
     */
    input: true;
    /**
     * Callback function triggered when an IBAN validation error occurs
     * @param error - Object containing error details
     * @param fieldName - Name of the field where the error occurred
     */
    onError?: (error: IIBANError) => void;
}

export type IBANProps = IIBANDisplayProps | IIBANInputProps;
