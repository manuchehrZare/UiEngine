import type { TableBodyProps } from '@mui/material';
import type { ITableProps } from '../type';

export interface ITableBodyProps
    extends Pick<
            TableBodyProps,
            | 'children'
            | 'className'
            | 'hidden'
            | 'id'
            | 'key'
            | 'onClick'
            | 'onClickCapture'
            | 'onDoubleClick'
            | 'onDoubleClickCapture'
            | 'onKeyDown'
            | 'onKeyDownCapture'
            | 'onKeyPress'
            | 'onKeyPressCapture'
            | 'onKeyUp'
            | 'onKeyUpCapture'
            | 'onLoad'
            | 'onLoadCapture'
            | 'onLoadStart'
            | 'onLoadStartCapture'
            | 'onMouseDown'
            | 'onMouseDownCapture'
            | 'onMouseEnter'
            | 'onMouseLeave'
            | 'onMouseMove'
            | 'onMouseMoveCapture'
            | 'onMouseOut'
            | 'onMouseOutCapture'
            | 'onMouseOver'
            | 'onMouseOverCapture'
            | 'onMouseUp'
            | 'onMouseUpCapture'
            | 'onScroll'
            | 'onScrollCapture'
            | 'onWheel'
            | 'onWheelCapture'
            | 'sx'
        >,
        Pick<ITableProps, 'ref'> {}
