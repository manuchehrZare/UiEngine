import type { FC, ReactNode } from 'react';
import { memo, useState } from 'react';
import type { Theme } from '@mui/material';
import { Breadcrumbs as MuiBreadcrumbs, Link, Typography, Menu, MenuItem, Chip } from '@mui/material';
import type { IBreadcrumbsItems, IBreadcrumbsProps, ISelectItems, IHomeItems } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import type { DesignType } from '../../..';
import { constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const Breadcrumbs: FC<IBreadcrumbsProps> = ({
    homeItems,
    breadCrumbsItems,
    design,
    className,
    separator = '/',
    maxItems = 5,
    type = 'default',
    underline,
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const [anchorEl, setAnchorEl] = useState<any>(null);
    const [open, setOpen] = useState<any>({});
    /* istanbul ignore next */
    const handleClick = (index: number, event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl({ [index]: event.currentTarget });
        setOpen({ [index]: (prevState: any) => !prevState });
    };

    /* istanbul ignore next */
    const handleClose = async () => {
        await setAnchorEl(null);
        setOpen(false);
    };

    const breadcrumbsType = (data?: ReactNode) => {
        if (type === 'chip') {
            return <Chip key="chip" label={data} />;
        }
        return data;
    };

    const menu = (data: ISelectItems[], index: number) => {
        return (
            <Menu anchorEl={anchorEl?.[index]} open={Boolean(open[index])} onClose={handleClose}>
                {data?.map((listItem: ISelectItems, i: number) => {
                    return (
                        <MenuItem
                            key={`menu-${String(i)}`}
                            className="breadcrumbs-select"
                            onClick={/* istanbul ignore next */ () => handleClose}
                            component={Link}
                            href={listItem?.link}>
                            {listItem.iconLeft}
                            {listItem.text}
                            {listItem.iconRight}
                        </MenuItem>
                    );
                })}
            </Menu>
        );
    };

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiBreadcrumbs
                className={manageClassNames(
                    generateClass('Breadcrumbs'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                aria-label="breadcrumb"
                maxItems={maxItems}
                separator={separator}
                {...rest}>
                {homeItems?.map((item: IHomeItems, i: number) => {
                    if (item?.show === true || item?.show === undefined) {
                        return breadcrumbsType(
                            <Link
                                href={item?.link}
                                underline={item?.link ? underline?.home || 'hover' : 'none'}
                                key={`homeItems-${String(i)}`}>
                                {item?.iconLeft}
                                {item?.text ? item.text : item.icon ? item.icon : null}
                                {item?.iconRight}
                            </Link>,
                        );
                    }
                    return null;
                })}
                {breadCrumbsItems?.map((item: IBreadcrumbsItems, i: number) => {
                    if (item?.link) {
                        return breadcrumbsType(
                            <Link
                                href={`${item.link}`}
                                key={`breadcrumb-${String(i)}`}
                                underline={underline?.breadcrumbs || 'hover'}>
                                {item.iconLeft}
                                {item.text}
                                {item.iconRight}
                            </Link>,
                        );
                    }

                    return breadcrumbsType(
                        <Typography
                            key={`breadcrumb-${String(i)}`}
                            className={manageClassNames({
                                'breadcrumbs-cursor': item?.select,
                                'breadcrumbs-menu': item?.select,
                                'breadcrumbs-text': !item?.select && !item.link,
                            })}
                            onClick={(e: any) => handleClick(i, e)}>
                            {item.iconLeft}
                            {item?.text}
                            {!item.text &&
                                item.select &&
                                (item.menuIcon ? (
                                    item.menuIcon
                                ) : (
                                    <MoreHorizIcon
                                        className={manageClassNames('breadcrumbs-menuIcon')}
                                        sx={{ height: '16px' }}
                                    />
                                ))}
                            {item.iconRight ? (
                                item.iconRight
                            ) : item?.select && item.text ? (
                                <KeyboardArrowRightIcon fontSize="small" className={open[i] ? 'open' : 'close'} />
                            ) : (
                                ''
                            )}
                            {item.select && menu(item?.select, i)}
                        </Typography>,
                    );
                })}
            </MuiBreadcrumbs>
        </ThemeProvider>
    );
};

export default memo(Breadcrumbs);
