export interface IViewProps {
    children: any;
    show: boolean;
}
