import type { FC } from 'react';
import { memo } from 'react';
import type { IViewProps } from './type';

const View: FC<IViewProps> = ({ show = false, children }) => {
    return show ? children : null;
};

export default memo(View);
