import type { IBarChartData, IBarChartDataValuesItem } from './Bar/type';

export const getDataModelForBarChart = (data: IBarChartData[]): any[] => {
    const newDataModel: any[] = [];
    const keys: string[] = Object.keys(data[0]);
    const valueKeys: string[] = Object.keys((data as any)[0][keys[1]][0]);

    data.forEach((dataItem: IBarChartData) => {
        const dataObj: any = {};

        keys.forEach((key: string, index: number) => {
            if (index === 0) dataObj[key] = (dataItem as any)[key];
            else {
                (dataItem as any)[key].forEach((valuesItem: IBarChartDataValuesItem) => {
                    dataObj[(valuesItem as any)[valueKeys[0]]] = (valuesItem as any)[valueKeys[1]];
                });
            }
        });
        newDataModel.push(dataObj);
    });

    return newDataModel;
};
