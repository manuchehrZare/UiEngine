import type { ReactNode } from 'react';
import type { IBarChartData, IBarTooltip } from './Bar/type';
import type { IPieChartData, IPieTooltip } from './Pie/type';
import type { ILegend } from './utils/Legend/type';
import type { ITooltip } from './utils/Tooltip/type';

export interface IChartData {
    name: string;
    value: number;
    valueUI?: ReactNode;
}

export interface IChartMargin {
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}

export interface IChartCommonProps {
    className?: string;
    colors?: string[];
    height?: number | string;
    legend?: boolean | ILegend;
    margin?: IChartMargin;
    tooltip?: boolean | ITooltip;
}

export type ChartDataTypes = IPieChartData[] | IBarChartData[];
export type ChartTooltipTypes = IPieTooltip | IBarTooltip;
