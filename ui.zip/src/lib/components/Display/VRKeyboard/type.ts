import type { TooltipProps } from '@mui/material';
import type { IBoxProps } from '../../..';
import type { JSX } from 'react';

export interface IVRKeyboardProps
    extends Pick<IBoxProps, 'className' | 'sx'>,
        Pick<TooltipProps, 'open' | 'placement'> {
    anchorEl: JSX.Element;
    numPad?: boolean;
}

export enum DisplayButtonsEnum {
    Enter = '{enter}',
    CapsLock = '{lock}',
    Space = '{space}',
    Tab = '{tab}',
    Shift = '{shift}',
    Backspace = '{bksp}',
    Clear = '{clear}',
}

export type DisplayButtonsType = '{enter}' | '{lock}' | '{space}' | '{tab}' | '{shift}' | '{bksp}' | '{clear}';

export enum LayoutNameTypeEnum {
    default = 'default',
    shift = 'shift',
    lock = 'lock',
}
export type LayoutNameType = keyof typeof LayoutNameTypeEnum;
