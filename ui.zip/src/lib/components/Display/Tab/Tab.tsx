import type { FC, SyntheticEvent } from 'react';
import { useState, useEffect, forwardRef } from 'react';
import type { Theme } from '@mui/material';
import { Tabs as MuiTab } from '@mui/material';
import type { ITabProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const Tab: FC<ITabProps> = forwardRef(
    ({ value, children, onChange, small, design, className, sx, ...rest }: ITabProps, ref) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        const [tabValue, setValue] = useState(value);
        const handleChange = (_: SyntheticEvent, newValue: string | number) => {
            setValue(newValue);
            onChange?.(newValue);
        };

        /* istanbul ignore next */
        useEffect(() => {
            tabValue !== value && setValue(value);
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [value]);

        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <MuiTab
                    ref={ref}
                    value={tabValue}
                    onChange={handleChange}
                    variant="scrollable"
                    className={manageClassNames(
                        generateClass('Tab'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                        { 'is-small': small },
                        className,
                    )}
                    TabScrollButtonProps={{
                        className: manageClassNames({ 'is-small': small }),
                    }}
                    sx={{
                        ...(getComponentDesignProperty(design, storageDesign.newValue) === DesignTypeEnum.SET && {
                            mb: 0.5,
                        }),
                        ...sx,
                    }}
                    {...rest}>
                    {children}
                </MuiTab>
            </ThemeProvider>
        );
    },
);

export default Tab;
