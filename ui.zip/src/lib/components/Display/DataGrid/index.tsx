import { CheckBox, CheckBoxOutlineBlank } from '@mui/icons-material';
import type { Theme } from '@mui/material';
import { LinearProgress } from '@mui/material';
import type {
    GridColDef,
    GridColumnVisibilityModel,
    GridPaginationModel,
    GridRowSelectionModel,
} from '@mui/x-data-grid-pro';
import { DataGridPro as MuiDataGrid, gridClasses } from '@mui/x-data-grid-pro';
import { enUS, trTR } from '@mui/x-data-grid-pro/locales';
import { LicenseInfo } from '@mui/x-license';
import { cloneDeep, difference, differenceWith, isEqual, isUndefined, omit } from 'lodash';
import type { FC } from 'react';
import { memo, useCallback, useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { DataGridColumnsPropsType, DesignType } from '../../..';
import { Box, DataGridColumnTypeEnum, constants, manageClassNames, useDataGridApiRef, useStorage } from '../../..';
import { currency, generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';
import { LocalesEnum, useTranslation } from '../../../utils/locales';
import ThemeProvider from '../../App/ThemeProvider';
import {
    generateHiddenColumns,
    generateRowsPerPageOptions,
    getDataIndexes,
    getDefaultHeight,
    getInitialLocalPageSize,
} from './action';
import CustomPagination from './CustomPagination';
import CustomToolbar from './CustomToolbar';
import type {
    DataGridColDef,
    IDataGridEditProps,
    IDataGridFooterAndPaginationProps,
    IDataGridHiddenColumnsProps,
    IDataGridProps,
    IDataGridSelectionProps,
    PageSizeType,
} from './type';
import { rowUniqueKey } from './type';

LicenseInfo.setLicenseKey(
    'b05a7c99036e07c80ba69bc230e624afTz0xMDY3NTEsRT0xNzY5NjQ0Nzk5MDAwLFM9cHJvLExNPXN1YnNjcmlwdGlvbixQVj1pbml0aWFsLEtWPTI=',
);

const DataGrid: FC<IDataGridProps> = ({
    apiRef,
    autoPageSize,
    checkboxSelection,
    columnHeaderHeight,
    columns,
    design,
    hiddenColumns,
    initialState,
    localeText,
    numberPaginationProps,
    onEditChange,
    onHiddenColumnsChange,
    onPaginationModelChange,
    onSelectChange,
    pageSize,
    pageSizeOptions,
    pagination,
    paginationMode,
    pinnedColumns,
    pinnedRows,
    rowHeight,
    rowSelectionModel,
    rows,
    slots,
    sx,
    toolbarProps,
    className,
    density = 'standard',
    editable = false,
    loading = false,
    page = 0,
    selectedCountView = false,
    selectionOnClickable = false,
    sortable = true,
    strippedRows = true,
    numberPagination = false,
    toolbar = true,
    unpinCounterColumn = false,
    disableMultipleRowSelection = false,
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const { t, locale, i18n } = useTranslation();
    const gridId = uuidv4();
    const internalApiRef = apiRef || useDataGridApiRef(); // eslint-disable-line
    // General
    const [isInit, setIsInit] = useState<boolean>(true);
    // Columns Data
    const [columnsData, setColumnsData] = useState<readonly DataGridColDef[]>([]);
    // Rows Data
    const [rowsData, setRowsData] = useState<readonly any[]>([]);
    // Rows BackUp
    const [rowsBackUpData, setRowsBackUpData] = useState<readonly any[]>([]);
    // Page
    const initialLocalPage: number | undefined = page;
    const [localPage, setLocalPage] = useState<number | undefined>(initialLocalPage);
    // PageSize
    const initialLocalPageSize: PageSizeType = getInitialLocalPageSize(
        pageSize,
        pageSizeOptions as (number | { label: string; value: number })[],
    );
    const [localPageSize, setLocalPageSize] = useState<PageSizeType>(initialLocalPageSize);
    const [paginationModel, setPaginationModel] = useState<GridPaginationModel>({
        page: localPage || 0,
        pageSize: localPageSize || 5,
    });
    // Selection
    const initialSelectionModel: any =
        ['number', 'string'].indexOf(typeof rowSelectionModel) > -1 ? [rowSelectionModel] : rowSelectionModel;
    const [localSelectionModel, setLocalSelectionModel] = useState<GridRowSelectionModel>(initialSelectionModel || []);
    // Selectes Rows Data
    const [selectedRowsData, setSelectedRowsData] = useState<readonly any[]>([]);
    // Hidden Columns
    const initialLocalHiddenColumns: GridColumnVisibilityModel = generateHiddenColumns(columns, hiddenColumns || []);
    const [localHiddenColumns, setLocalHiddenColumns] = useState<GridColumnVisibilityModel>(initialLocalHiddenColumns);

    const localeTextObj: any = {
        [LocalesEnum.TURKISH]: trTR.components.MuiDataGrid.defaultProps.localeText,
        [LocalesEnum.ENGLISH]: enUS.components.MuiDataGrid.defaultProps.localeText,
    };

    // pagination ayarlarını düzgün şekilde güncellemek için.
    useEffect(() => {
        // paginationModel durumunu doğrudan güncelleme
        if (localPage !== paginationModel.page || localPageSize !== paginationModel.pageSize) {
            setPaginationModel({
                page: localPage || 0,
                pageSize: localPageSize || 5,
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [localPage, localPageSize]);

    const getFooterAndPaginationProps = (): IDataGridFooterAndPaginationProps => ({
        pagination: pagination,
        ...(paginationMode && { paginationMode: paginationMode }),
        paginationModel: paginationModel,
        onPaginationModelChange: (model, details) => {
            if (model.page !== localPage) {
                setLocalPage(model.page);
            }
            if (model.pageSize !== localPageSize) {
                setLocalPageSize(model.pageSize);
            }
            setPaginationModel(model);
            onPaginationModelChange?.(model, details);
        },
        autoPageSize: !pageSize && pagination && !pageSizeOptions && !autoPageSize ? true : autoPageSize,
        pageSizeOptions: generateRowsPerPageOptions(pageSizeOptions as any, page),
        hideFooterSelectedRowCount: Boolean(!selectedCountView),
        hideFooter: Boolean(!pagination) && Boolean(!pageSizeOptions) && Boolean(!selectedCountView),
        hideFooterPagination: Boolean(!pagination),
    });

    const getAllSelectedRows = (model: GridRowSelectionModel) => {
        const selectedRowsArr: any[] = [];
        const tmpRowsData = cloneDeep(rowsData);
        tmpRowsData.forEach((item: any) => {
            if (model.indexOf(item[`${rowUniqueKey}`]) !== -1) {
                selectedRowsArr.push(item);
            }
        });
        return selectedRowsArr;
    };

    const getSelectedRow = (model: GridRowSelectionModel) => {
        const diff: GridRowSelectionModel = checkboxSelection ? difference(localSelectionModel, model) : model;
        const newModel: GridRowSelectionModel = diff.length > 0 ? diff : model;
        const internalRowId: number | string = newModel[newModel.length - 1];
        const row: any = rowsData.find((item: any) => item[`${rowUniqueKey}`] === internalRowId);
        return row;
    };

    const getSelectionProps = (): IDataGridSelectionProps => ({
        disableRowSelectionOnClick: Boolean(!selectionOnClickable),
        checkboxSelection: checkboxSelection,
        onRowSelectionModelChange: (newSelectionModel) => {
            if (!isEqual(newSelectionModel, localSelectionModel) || disableMultipleRowSelection) {
                setLocalSelectionModel(newSelectionModel);

                const conditionalSelectionModel = disableMultipleRowSelection
                    ? (newSelectionModel as any).splice(-1)
                    : newSelectionModel;

                onSelectChange?.({
                    row: omit(getSelectedRow(conditionalSelectionModel), rowUniqueKey),
                    rows: getAllSelectedRows(conditionalSelectionModel).map((item) => omit(item, rowUniqueKey)),
                    rowId: getSelectedRow(conditionalSelectionModel)?.[`${rowUniqueKey}`],
                    rowIds: getAllSelectedRows(conditionalSelectionModel).map((item) => item[`${rowUniqueKey}`]),
                    index: internalApiRef?.current
                        ?.getSortedRowIds()
                        ?.indexOf(getSelectedRow(conditionalSelectionModel)?.[`${rowUniqueKey}`]),
                    indexes: getAllSelectedRows(conditionalSelectionModel)?.map((item) =>
                        internalApiRef?.current?.getSortedRowIds()?.indexOf(item[`${rowUniqueKey}`]),
                    ),
                });
                setSelectedRowsData(getAllSelectedRows(conditionalSelectionModel));
            }
        },
    });

    const handleEditRowsModelChange = useCallback(
        (newRow: any, oldRow: any) => {
            onEditChange?.({
                newRow: omit(newRow, rowUniqueKey),
                oldRow: omit(oldRow, rowUniqueKey),
                rowId: newRow[`${rowUniqueKey}`],
                index: internalApiRef?.current?.getSortedRowIds()?.indexOf(newRow[`${rowUniqueKey}`]),
            });
            return newRow;
        },
        // eslint-disable-next-line
        [rowsData],
    );

    const getEditProps = (): IDataGridEditProps => ({
        processRowUpdate: handleEditRowsModelChange,
    });

    const handleHiddenColumnsChange = (newModel: GridColumnVisibilityModel) => {
        setLocalHiddenColumns(newModel);
        onHiddenColumnsChange?.(newModel);
    };

    const getHiddenColumnsProps = (): Pick<
        IDataGridHiddenColumnsProps,
        'columnVisibilityModel' | 'onColumnVisibilityModelChange'
    > => ({
        ...(hiddenColumns && { columnVisibilityModel: localHiddenColumns }),
        onColumnVisibilityModelChange: handleHiddenColumnsChange,
    });

    useEffect(() => {
        !isInit && handleHiddenColumnsChange(generateHiddenColumns(columns, hiddenColumns || []));
        isInit && setIsInit(false);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [hiddenColumns]);

    useEffect(() => {
        if (rows && rows?.length > 0) {
            setRowsData(
                rows.map((item, index) => {
                    return { ...item, [`${rowUniqueKey}`]: index };
                }),
            );
        } else setRowsData([]);
        rows && setRowsBackUpData(rows);
    }, [rows]);

    /** For Column Data */
    const updateColumnsData = (paramColumns: readonly DataGridColDef[]): DataGridColumnsPropsType => {
        const newColumns: DataGridColumnsPropsType = [];

        paramColumns.forEach((item) => {
            if (isUndefined(item.editable)) {
                item.editable = editable;
            }
            if (isUndefined(item.sortable)) {
                item.sortable = sortable;
            }
            if (item.type === DataGridColumnTypeEnum.counter) {
                item.type = DataGridColumnTypeEnum.string;
                item.renderCell = (param: any) => {
                    if (param?.rowNode?.type === 'pinnedRow') return '';
                    if (internalApiRef?.current?.getSortedRowIds().length) {
                        return internalApiRef?.current?.getSortedRowIds()?.indexOf(param.id) + 1;
                    }
                    return '';
                };
                item.editable = false;
                item.sortable = false;
            }
            if (item.type === DataGridColumnTypeEnum.currency) {
                item = {
                    type: DataGridColumnTypeEnum.number,
                    align: 'right',
                    valueFormatter: (value: any) => currency(value),
                    sortComparator: (v1: any, v2: any) => Number(v1 || 0) - Number(v2 || 0),
                    ...item,
                };
            }
            if (item.type === DataGridColumnTypeEnum.boolean) {
                item = {
                    renderCell: (params) => {
                        if (typeof params?.value === 'boolean') {
                            return (
                                <Box
                                    className={manageClassNames(generateClass('checkbox'), { checked: params.value })}
                                    {...(params.isEditable && {
                                        onMouseEnter: async () => {
                                            await params.api.startCellEditMode({ id: params.id, field: params.field });
                                        },
                                    })}>
                                    {params?.value ? <CheckBox /> : <CheckBoxOutlineBlank />}
                                </Box>
                            );
                        }
                        return null;
                    },
                    ...item,
                };
            }
            if (item.type === DataGridColumnTypeEnum.number) {
                item = {
                    align: 'center',
                    ...item,
                };
            }
            if (item.type === DataGridColumnTypeEnum.date) {
                item = {
                    align: 'center',
                    ...item,
                };
            }
            if (item.type === DataGridColumnTypeEnum.abbreviation) {
                item = {
                    align: 'center',
                    ...item,
                };
            }
            newColumns.push(item);
        });

        return newColumns;
    };

    /** For Column Data */
    useEffect(() => {
        const columnsTmp = cloneDeep(columns);
        if (columnsTmp.filter((item) => (item as any)?.type === DataGridColumnTypeEnum.counter).length > 0) {
            setColumnsData(updateColumnsData(columnsTmp));
        } else setColumnsData(columnsTmp);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [columns, rowsData]);

    useEffect(() => {
        const diffSelected = differenceWith(selectedRowsData, rows || [], isEqual);
        setLocalSelectionModel(
            differenceWith(localSelectionModel, getDataIndexes(diffSelected, rowsBackUpData), isEqual),
        );
        setSelectedRowsData(differenceWith(selectedRowsData, diffSelected, isEqual));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [rows]);

    useEffect(() => {
        /**
         * Control to remove license (expired or missing) text.
         */
        if (internalApiRef.current) {
            const mainElList = internalApiRef.current?.rootElementRef?.current?.getElementsByClassName(
                gridClasses.main,
            );
            if (mainElList && mainElList?.length > 0) {
                const mainEl = mainElList[0];
                if (mainEl?.childNodes && mainEl?.childNodes.length > 0) {
                    mainEl?.childNodes?.forEach((el: any) => {
                        if (el.className === '') {
                            el.innerText = '';
                            el.hidden = true;
                            el.removeAttribute('style');
                        }
                    });
                }
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [internalApiRef.current]);

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiDataGrid
                apiRef={internalApiRef}
                className={manageClassNames(
                    generateClass('DataGrid'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    gridId,
                    { strippedRows },
                    { disableMultipleRowSelection },
                    className,
                )}
                getRowId={(row) => row[`${rowUniqueKey}`]}
                slotProps={{
                    baseSwitch: {
                        disableRipple: true,
                    },
                    footer: {
                        className: manageClassNames(getComponentDesignProperty(design, storageDesign.newValue)),
                        style: {
                            minHeight:
                                columnHeaderHeight ||
                                getDefaultHeight({ design: getComponentDesignProperty(design, storageDesign.newValue) })
                                    .columnHeaderHeight,
                            height:
                                columnHeaderHeight ||
                                getDefaultHeight({ design: getComponentDesignProperty(design, storageDesign.newValue) })
                                    .columnHeaderHeight,
                        },
                    },
                    cell: {
                        className: manageClassNames(getComponentDesignProperty(design, storageDesign.newValue)),
                    },
                    basePopper: {
                        className: manageClassNames(getComponentDesignProperty(design, storageDesign.newValue)),
                    },
                    loadingOverlay: {
                        style: {
                            color: 'red',
                        },
                    },
                }}
                rows={rowsData}
                columns={columnsData as readonly GridColDef<any>[]}
                {...getFooterAndPaginationProps()}
                {...getSelectionProps()}
                {...getEditProps()}
                localeText={{
                    ...localeTextObj[i18n.language],
                    toolbarExport: t(locale.contents.file),
                    ...localeText,
                    MuiTablePagination: {
                        labelDisplayedRows: ({ from, to, count }) => `${from} - ${to} / ${count}`,
                        ...localeText?.MuiTablePagination,
                        getItemAriaLabel: (type) => {
                            switch (type) {
                                case 'first':
                                    return t(locale.labels.goToFirstPage);
                                case 'last':
                                    return t(locale.labels.goToLastPage);
                                case 'next':
                                    return t(locale.labels.goToNextPage);
                                default:
                                    return t(locale.labels.goToPreviousPage);
                            }
                        },
                    },
                }}
                density={density}
                slots={{
                    ...(toolbar && {
                        toolbar: () => (
                            <CustomToolbar
                                columns={columns as any}
                                setRowsData={setRowsData}
                                toolbarProps={toolbarProps}
                                apiRef={internalApiRef}
                            />
                        ),
                    }),
                    ...(numberPagination &&
                        pagination && {
                            pagination: () => {
                                return <CustomPagination apiRef={internalApiRef} {...numberPaginationProps} />;
                            },
                        }),
                    loadingOverlay: LinearProgress as any,
                    ...slots,
                }}
                {...getHiddenColumnsProps()}
                columnHeaderHeight={
                    columnHeaderHeight ||
                    getDefaultHeight({ design: getComponentDesignProperty(design, storageDesign.newValue) })
                        .columnHeaderHeight
                }
                rowHeight={
                    rowHeight ||
                    getDefaultHeight({ design: getComponentDesignProperty(design, storageDesign.newValue) }).rowHeight
                }
                sx={{
                    ...((sx as any)?.height && { minHeight: (sx as any)?.height }),
                    ...sx,
                }}
                {...(editable && { isCellEditable: () => editable })}
                {...(pinnedRows && {
                    pinnedRows: {
                        bottom: pinnedRows?.bottom?.map((item) => ({ rowId: uuidv4(), ...item })),
                        top: pinnedRows?.top?.map((item) => ({ rowId: uuidv4(), ...item })),
                    },
                })}
                initialState={{
                    pinnedColumns: {
                        left: [
                            (!unpinCounterColumn &&
                                columns.find((item) => (item as any).type === DataGridColumnTypeEnum.counter)?.field) ||
                                '',
                            ...(initialState?.pinnedColumns?.left || []),
                            ...(pinnedColumns?.left || []),
                        ],
                        right: [...(initialState?.pinnedColumns?.right || []), ...(pinnedColumns?.right || [])],
                    },
                    pagination: {
                        paginationModel: { page: initialLocalPage, pageSize: initialLocalPageSize },
                    },
                    ...omit(initialState, ['pinnedColumns']),
                }}
                loading={loading}
                {...rest}
            />
        </ThemeProvider>
    );
};

export default memo(DataGrid);
