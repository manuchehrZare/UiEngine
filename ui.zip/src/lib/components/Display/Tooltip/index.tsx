import type { Theme } from '@mui/material';
import { Tooltip as MuiTooltip } from '@mui/material';
import { isBoolean, isUndefined, omit } from 'lodash';
import type { FC } from 'react';
import { memo } from 'react';
import type { DesignType } from '../../..';
import { Box, constants, manageClassNames, useStorage } from '../../..';
import ThemeProvider from '../../App/ThemeProvider';
import type { ITooltipProps } from './type';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const Tooltip: FC<ITooltipProps> = ({
    children,
    show,
    title,
    design,
    arrow = true,
    keepMounted,
    componentsProps,
    className,
    enterDelay,
    leaveDelay,
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiTooltip
                className={manageClassNames(
                    generateClass('Tooltip-wrapper'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                enterDelay={enterDelay}
                enterNextDelay={enterDelay}
                enterTouchDelay={enterDelay}
                leaveDelay={leaveDelay}
                leaveTouchDelay={leaveDelay}
                arrow={arrow}
                PopperProps={{
                    keepMounted,
                }}
                title={title}
                {...(!isUndefined(show) && isBoolean(show) && { open: show })}
                componentsProps={{
                    tooltip: {
                        className: manageClassNames(
                            generateClass('Tooltip'),
                            getComponentDesignProperty(design, storageDesign.newValue),
                            {
                                [`${componentsProps?.tooltip?.className}`]: Boolean(
                                    componentsProps?.tooltip?.className,
                                ),
                            },
                        ),
                        ...omit(componentsProps?.tooltip, 'className'),
                    },
                    ...omit(componentsProps, 'tooltip'),
                }}
                {...rest}>
                <Box>{children}</Box>
            </MuiTooltip>
        </ThemeProvider>
    );
};

export default memo(Tooltip);
