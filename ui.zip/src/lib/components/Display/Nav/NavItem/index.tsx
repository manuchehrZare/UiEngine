import type { FC } from 'react';
import { forwardRef, memo } from 'react';
import type { INavItemProps } from '../type';
import { getDefaultProps } from './defaultProps';
import type { DesignType } from '../../../..';
import { Grid, constants, manageClassNames, useStorage } from '../../../..';
import { generateClass, getComponentDesignProperty } from '../../../../utils';
import ThemeProvider from '../../../App/ThemeProvider';
import type { Theme } from '@mui/material';
import { getProviderTheme } from '../../../../utils/methods/theme';

const NavItem: FC<INavItemProps> = forwardRef(({ children, className, design, sx, ...rest }: INavItemProps, ref) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <Grid
                ref={ref}
                className={manageClassNames(
                    generateClass('NavItem'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                container
                xs="auto"
                direction="column"
                {...getDefaultProps({ design: getComponentDesignProperty(design, storageDesign.newValue), sx })}
                {...rest}>
                {children}
            </Grid>
        </ThemeProvider>
    );
});

export default memo(NavItem);
