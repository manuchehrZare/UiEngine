import type { PaginationProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';

export interface IPaginationProps extends PaginationProps, ICommonProps {
    className?: string;
}
