import type { Control, FieldPath, FieldPathValue, FieldPathValues, FieldValues } from 'react-hook-form';
import { useWatch as useHookWatch } from 'react-hook-form';

export interface IUseWatchProps<TFields extends FieldValues> {
    control: Control<TFields>;
    defaultValue?: any;
    fieldName: FieldPath<TFields> | FieldPath<TFields>[];
}

export type UseWatchReturnType<TFields extends FieldValues> =
    | FieldPathValue<TFields, any>
    | FieldPathValues<TFields, any>;

const useWatch = <TFields extends FieldValues>({
    control,
    defaultValue,
    fieldName,
}: IUseWatchProps<TFields>): UseWatchReturnType<TFields> => {
    // @ts-ignore
    return useHookWatch<TFields, TFields>({
        control,
        defaultValue,
        // @ts-ignore
        name: fieldName,
    });
};

export default useWatch;
