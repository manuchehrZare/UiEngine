import { useEffect, useState } from 'react';

export type CallbackSuccessType<T> = (value: T) => void;
export type CallbackErrorType = (err?: any) => void;
export interface IUseClipboardReturn<T> {
    copiedValue: T | null;
    copy: (value: T, onSuccess?: CallbackSuccessType<T>, onError?: CallbackErrorType) => any;
    isCopied: boolean;
}
export type UseClipboardReturnType<T> = IUseClipboardReturn<T>;

export type UseClipboardOptions<T> = {
    onError?: CallbackErrorType;
    onSuccess?: CallbackSuccessType<T>;
    successDuration?: number;
};

const useClipboard = <T = any>(options?: UseClipboardOptions<T>): UseClipboardReturnType<T> => {
    const defaultSuccessDuration = 1000;
    const defaultIsCopied = false;
    const defaultCopiedValue = null;
    const [isCopied, setIsCopied] = useState<boolean>(defaultIsCopied);
    const [copiedValue, setCopiedValue] = useState<T | null>(defaultCopiedValue);

    const reset = () => {
        setIsCopied(defaultIsCopied);
        setCopiedValue(defaultCopiedValue);
    };

    const getValidValue = (val: any) => val;

    useEffect(() => {
        const timer = setTimeout(
            () => isCopied && setIsCopied(defaultIsCopied),
            options?.successDuration || defaultSuccessDuration,
        );
        return () => {
            clearTimeout(timer);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isCopied]);

    const copy = (value: T, onSuccess?: CallbackSuccessType<T>, onError?: CallbackErrorType): any => {
        const callbackSuccess = () => {
            onSuccess?.(value);
            options?.onSuccess?.(value);
            setIsCopied(true);
            setCopiedValue(value);
        };

        const callbackError = (err?: any) => {
            onError?.(err);
            options?.onError?.(err);
            reset();
        };

        if (navigator.clipboard !== undefined) {
            // Chrome Based Browsers
            navigator.clipboard.writeText(getValidValue(value)).then(callbackSuccess, callbackError);
        } else if ((window as any).clipboardData) {
            // Internet Explorer
            (window as any).clipboardData.setData('Text', getValidValue(value));
            if ((window as any).clipboardData.getData('Text') === getValidValue(value)) /* success*/ callbackSuccess();
            else callbackError(); // error
        } else {
            // createElement
            const textArea = document.createElement('textarea');
            textArea.value = getValidValue(value);
            // make the textarea out of viewport
            textArea.style.position = 'fixed';
            textArea.style.zIndex = '-1';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            return new Promise((res: any, rej: any) => {
                // here the magic happens
                if (document.execCommand('copy')) {
                    callbackSuccess();
                    res();
                } else {
                    callbackError();
                    rej();
                }
                document.body.removeChild(textArea);
            });
        }
    };
    return { copy, copiedValue, isCopied };
};

export default useClipboard;
