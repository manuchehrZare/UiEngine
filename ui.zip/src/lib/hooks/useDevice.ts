import type { WidthSize } from './useWidth';
import useWidth from './useWidth';

export type UseDeviceReturn = {
    isDesktop: boolean | null;
    isMobile: boolean | null;
    isTablet: boolean | null;
    lg: boolean;
    md: boolean;
    sm: boolean;
    xl: boolean;
    xs: boolean;
};

const useDevice = (): UseDeviceReturn => {
    const width: WidthSize = useWidth();

    const xs = width === 'xs';
    const sm = width === 'sm';
    const md = width === 'md';
    const lg = width === 'lg';
    const xl = width === 'xl';

    const isMobile = width && ['xs', 'sm'].indexOf(width) > -1;
    const isTablet = width && ['md'].indexOf(width) > -1;
    const isDesktop = width && ['lg', 'xl'].indexOf(width) > -1;

    return {
        xs,
        sm,
        md,
        lg,
        xl,
        isMobile,
        isTablet,
        isDesktop,
    };
};

export default useDevice;
