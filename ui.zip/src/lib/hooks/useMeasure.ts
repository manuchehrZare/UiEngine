import { isEqual } from 'lodash';
import type { Ref, RefObject } from 'react';
import { useCallback, useLayoutEffect, useRef, useState } from 'react';
import {
    sharedEventListener,
    sharedIntersectionObserver,
    sharedMutationObserver,
    sharedResizeObserver,
} from '../utils';

// Define a partial version of the DOMRect (removing toJSON) to store element measurements in state
export type MeasureValues = Partial<
    Pick<DOMRect, 'bottom' | 'height' | 'left' | 'right' | 'top' | 'width' | 'x' | 'y'>
>;

export type UseMeasureOptions = {
    /**
     * Optional external dependencies for the effect
     */
    effectDeps?: any[];
};

/**
 * Return type for the `useMeasure` hook.
 * @template T - Type of the target HTML element (defaults to HTMLDivElement).
 */
export type UseMeasureReturnType<T extends HTMLElement = HTMLDivElement> = {
    /**
     * The actual DOM element instance that the ref is attached to.
     * It will be `null` until the element mounts.
     */
    node: T | null;
    /**
     * A React ref that should be attached to the target DOM element.
     */
    ref: Ref<T> | RefObject<T>;
    /**
     * Computed measurement values of the referenced element, updated reactively.
     */
    values: MeasureValues;
};

/**
 * A custom React hook that observes and returns the computed measurement values of a DOM element in real-time.
 *
 * It uses a combination of:
 * - `ResizeObserver` for size changes,
 * - `MutationObserver` for DOM mutations,
 * - Media queries and window events for environmental changes. (resize, scroll, reset, matchMedia-change)
 *
 * The hook returns a `ref` to be attached to a DOM element and the latest computed measurement values for that element.
 *
 * @param options - Contains parameters that will affect Hook's operation.
 * @template T - The type of HTML element being observed (e.g., HTMLDivElement).
 * @returns {UseMeasureReturnType<T>} An object containing the ref and up-to-date computed measurement values.
 */
const useMeasure = <T extends HTMLElement = HTMLDivElement>(options?: UseMeasureOptions): UseMeasureReturnType<T> => {
    // Create a mutable reference to the DOM element we want to measure
    const ref = useRef<T | null>(null);

    // State to store the latest measured values of the element (initially empty)
    const [measure, setMeasure] = useState<MeasureValues>({});

    // Store the previously measured values to avoid unnecessary re-renders
    const prevMeasureRef = useRef<MeasureValues | null>(null);

    // Reference to the current requestAnimationFrame ID to cancel it if needed
    const animationFrameRef = useRef<number | null>(null);

    // Media Query
    const mediaQuery = window.matchMedia('(min-width: 0px)');

    /**
     * Function to calculate and update the element's measurements
     * Only updates state if the new measurements differ from previous
     */
    const calculateMeasure = useCallback(() => {
        if (!ref.current) return;

        // Read the current bounding client rect of the element
        const rect = ref.current.getBoundingClientRect();
        const newMeasure: MeasureValues = {
            bottom: rect.bottom,
            height: rect.height,
            left: rect.left,
            right: rect.right,
            top: rect.top,
            width: rect.width,
            x: rect.x,
            y: rect.y,
        };

        // If the new measure differs from the previous, update state
        if (!isEqual(newMeasure, prevMeasureRef.current)) {
            prevMeasureRef.current = newMeasure;
            setMeasure(newMeasure);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ref.current]);

    /**
     * Handle resize events by scheduling a measure update
     * using requestAnimationFrame for performance
     */
    const rafCalculateMeasure = useCallback(() => {
        if (animationFrameRef.current !== null) return;
        animationFrameRef.current = requestAnimationFrame(() => {
            animationFrameRef.current = null;
            calculateMeasure();
        });
    }, [calculateMeasure]);

    // Cancel any pending animation frame callback
    const cancelProcessForAnimationFrame = useCallback(() => {
        if (animationFrameRef.current !== null) {
            cancelAnimationFrame(animationFrameRef.current);
            animationFrameRef.current = null;
        }
    }, []);

    const intersectionCallback = (entry: IntersectionObserverEntry) => {
        entry.isIntersecting && rafCalculateMeasure(); // Measure if it just appears
    };

    const addListeners = useCallback(() => {
        sharedEventListener.add(mediaQuery, 'change', rafCalculateMeasure);
        sharedEventListener.add(window, 'resize', rafCalculateMeasure);
        sharedEventListener.add(window, 'scroll', rafCalculateMeasure, { capture: false });
        sharedEventListener.add(window, 'reset', rafCalculateMeasure);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const removeListeners = useCallback(() => {
        sharedEventListener.remove(mediaQuery, 'change', rafCalculateMeasure);
        sharedEventListener.remove(window, 'resize', rafCalculateMeasure);
        sharedEventListener.remove(window, 'scroll', rafCalculateMeasure);
        sharedEventListener.remove(window, 'reset', rafCalculateMeasure);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const setRef = useCallback(
        (node: T | null) => {
            ref.current = node;
            if (node) rafCalculateMeasure();
        },
        [rafCalculateMeasure],
    );

    // Effect to start observing the element once it's mounted
    useLayoutEffect(() => {
        // Get the current DOM element from the ref
        const element = ref.current;

        // Exit early if the element is not yet mounted
        // @ts-ignore
        if (!element) return;

        // Observe size changes of the element
        sharedResizeObserver.observe(element, rafCalculateMeasure);

        // Observe changes to element's attributes or children (DOM mutations)
        sharedMutationObserver.observe(element, rafCalculateMeasure);

        sharedIntersectionObserver.observe(element, intersectionCallback);

        // Listeners
        addListeners();

        // Perform an initial measurement on mount
        rafCalculateMeasure();

        // Cleanup function to remove all listeners and observers on unmount
        return () => {
            sharedResizeObserver.unobserve(element, rafCalculateMeasure);
            sharedMutationObserver.unobserve(element, rafCalculateMeasure);
            sharedIntersectionObserver.unobserve(element, intersectionCallback);
            removeListeners();
            cancelProcessForAnimationFrame();
            prevMeasureRef.current = null;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [...(options?.effectDeps || [])]); // Empty dependency array ensures this effect runs only once after mount

    // Return the ref for attaching to the DOM element, and the current measurements
    return { ref: setRef, values: measure, node: ref.current };
};

export default useMeasure;
