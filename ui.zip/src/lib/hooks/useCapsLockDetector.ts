import { useState, useEffect } from 'react';

const useCapsLockDetector = (inputRef: React.RefObject<HTMLInputElement | HTMLTextAreaElement>): boolean => {
    const [capsLockState, setCapsLockState] = useState<boolean>(false);
    const [isInputFocused, setIsInputFocused] = useState<boolean>(false);

    useEffect(() => {
        const ignoredKeys = [
            'Enter',
            'Shift',
            'Escape',
            'Tab',
            'Alt',
            'Control',
            'Delete',
            'ArrowUp',
            'ArrowDown',
            'ArrowLeft',
            'ArrowRight',
            'Backspace',
            'PageUp',
            'PageDown',
            'Home',
            'End',
            'Insert',
            '=',
            'Meta',
            'F1',
            'F2',
            'F3',
            'F4',
            'F5',
            'F6',
            'F7',
            'F8',
            'F9',
            'F10',
            'F11',
            'F12',
        ];

        const inputElement = inputRef.current;

        const handleKeyEvent = (event: KeyboardEvent) => {
            if ((event.type === 'keydown' || event.type === 'keyup') && !ignoredKeys.includes(event.key)) {
                setCapsLockState(event.getModifierState('CapsLock'));
            }
        };

        const handleFocus = () => {
            setIsInputFocused(true);
        };
        const handleBlur = () => {
            setIsInputFocused(false);
        };

        document.addEventListener('keydown', handleKeyEvent);
        document.addEventListener('keyup', handleKeyEvent);

        if (inputElement) {
            inputElement.addEventListener('focus', handleFocus);
            inputElement.addEventListener('blur', handleBlur);
        }

        return () => {
            if (inputElement) {
                inputElement.removeEventListener('focus', handleFocus);
                inputElement.removeEventListener('blur', handleBlur);
            }
            document.removeEventListener('keydown', handleKeyEvent);
            document.removeEventListener('keyup', handleKeyEvent);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isInputFocused]);

    return isInputFocused && capsLockState;
};

export default useCapsLockDetector;
