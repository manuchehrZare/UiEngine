<popupdata type="service">
	<service>UTL_INSTITUTION_LIST_ALL</service>
	    <parameters>
	    	<parameter n="INSTITUTION_OID">Page.pnlCriteria.txtOid</parameter>
	        <parameter n="SHORT_CODE">Page.pnlCriteria.txtShortCode</parameter>
	        <parameter n="TITLE">Page.pnlCriteria.txtTitle</parameter>
	        <parameter n="STOCK_EXCHANGE_CODE">Page.pnlCriteria.txtStockExchangeCode</parameter>
	        <parameter n="COUNTRY_CODE">Page.pnlCriteria.cmbCountryCode</parameter>
			<parameter n="SWIFT_CODE">Page.pnlCriteria.txtSwiftCode</parameter>
			<parameter n="FUNCTION_OID">Page.pnlCriteria.cmbFunction</parameter>
			<parameter n="CUSTOMER_CODE">Page.pnlCriteria.txtCustomerCode</parameter>
			<parameter n="IS_LIST_OPEN">Page.pnlCriteria.txtListOpen</parameter>
	    </parameters>
</popupdata>
