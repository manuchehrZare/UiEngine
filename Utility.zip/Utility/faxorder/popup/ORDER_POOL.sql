<popupdata type="service">
	<service>UTL_ORDER_POOL_LIST</service>
	    <parameters>
	        <parameter n="ORDER_CUST_CODE">Page.pnlCriteria.hndCust</parameter>
	        <parameter n="ORDER_NO">Page.pnlCriteria.txtOrderNo</parameter>
	        <parameter n="ORDER_STATUS">Page.pnlCriteria.cmbOrderStatus</parameter>
	        <parameter n="ORDER_FAX_NO">Page.pnlCriteria.txtFaxNo</parameter>
	        <parameter n="ORDER_CREATE_DATE_BEGIN">Page.pnlCriteria.dtCreateBegin</parameter>
	        <parameter n="ORDER_CREATE_DATE_END">Page.pnlCriteria.dtCreateEnd</parameter>
	        <parameter n="ORG_CODE">Page.pnlCriteria.cmbOrgCode</parameter>
	        <parameter n="ORG_TYPE">Page.pnlCriteria.lblOrgType</parameter>
	        <parameter n="USR_AUTHORIZATION">Page.pnlCriteria.lblHasAuth</parameter>
	        <parameter n="IS_ACTIVE">Page.pnlCriteria.chkActive</parameter>
	    </parameters>
</popupdata>