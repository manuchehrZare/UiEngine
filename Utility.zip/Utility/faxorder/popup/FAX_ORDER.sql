<popupdata type="service">
	<service>UTL_FAX_ORDER_LIST</service>
	    <parameters>
	        <parameter n="ORG_CODE">Page.pnlCriteria.cmbOrg</parameter>
	        <parameter n="CUST_CODE">Page.pnlCriteria.hndCust</parameter>
	        <parameter n="REFERENCE_ID">Page.pnlCriteria.txtReferenceId</parameter>
	        <parameter n="DATE_BEGIN">Page.pnlCriteria.dtDateBegin</parameter>
	        <parameter n="DATE_END">Page.pnlCriteria.dtDateEnd</parameter>
	        <parameter n="ORG_TYPE">Page.pnlCriteria.lblOrgType</parameter>
	    </parameters>
</popupdata>