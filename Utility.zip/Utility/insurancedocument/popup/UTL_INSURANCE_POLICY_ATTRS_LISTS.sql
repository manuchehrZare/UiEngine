<popupdata type="service">
	<service>UTL_INSURANCE_POLICY_DETAIL_LIST</service>
	    <parameters>
	        <parameter n="ITEM_TYPE">Page.txtItemType</parameter>
	    </parameters>
</popupdata>