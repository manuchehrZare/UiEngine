<popupdata type="service">
	<service>UTL_ENCRYPTION_KEY_FILE_LIST</service>
	    <parameters>
	    	<parameter n="KEY_CODE">Page.pnlCriteria.txtKeyFileCode</parameter>
	    </parameters>
</popupdata>