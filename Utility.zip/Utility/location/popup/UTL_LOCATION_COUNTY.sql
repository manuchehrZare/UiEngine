<popupdata type="sql">
    <sql dataSource="BankingDS">
		 SELECT COUNTY.OID,
		 	 	COUNTY_NAME,
		 	 	CITY_NUMBERPLATE,
		 	 	COUNTY_CODE,
				MKK_COUNTY_CODE,
				MB_COUNTY_CODE
		 FROM   INFRA.LOCATION_COUNTY COUNTY,
				INFRA.LOCATION_CITY CITY		 
		 WHERE  COUNTY.STATUS=1 AND CITY.STATUS=1 AND
		 		COUNTY.CITY_OID=CITY.OID AND
		 		CITY_NUMBERPLATE LIKE ? AND
		 		COUNTY_NAME LIKE ?
		 ORDER BY COUNTY_NAME
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">Page.pnlCriteria.cmbCity</parameter>
        <parameter prefix="" suffix="%">Page.pnlCriteria.txtCountyName</parameter>
    </parameters>
</popupdata>

