<popupdata type="sql">
    <sql dataSource="BankingDS">
		 SELECT CITY.OID,
		 	 	CITY_NAME,
		 	 	CITY_PHONE_CODE,
		 	 	CITY_NUMBERPLATE,
		 	 	COUNTRY_CODE
		 FROM   INFRA.LOCATION_CITY CITY,
		 		INFRA.LOCATION_COUNTRY COUNTRY
		 WHERE  CITY.STATUS=1 AND COUNTRY.STATUS=1 AND
		 		CITY.COUNTRY_OID=COUNTRY.OID AND
		 		COUNTRY_CODE LIKE ? AND
		 		CITY_NAME LIKE ? 	
		 ORDER BY COUNTRY_NAME,CITY_NAME
	</sql>
    <parameters>
		<parameter prefix="" suffix="%">Page.pnlCriteria.cmbCountry</parameter>            
		<parameter prefix="" suffix="%">Page.pnlCriteria.txtCityName</parameter>            		
    </parameters>
</popupdata>

