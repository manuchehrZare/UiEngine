<popupdata type="sql">
    <sql dataSource="BankingDS">
		 SELECT OID,
		 	 	COUNTRY_NAME,
		 	 	COUNTRY_PHONE_CODE,
		 	 	COUNTRY_NUMBERPLATE,
		 	 	COUNTRY_NATIONALITY,
		 	 	COUNTRY_CODE,
				COUNTRY_NAME_EN,
		 	 	COUNTRY_CURRENCY_CODE,
	   			COUNTRY_ISO_3166_ALFA_3_CODES,
				COUNTRY_SWIFT_CODE
		 FROM   INFRA.LOCATION_COUNTRY
		 WHERE  STATUS='1'AND 
		 		COUNTRY_NAME LIKE ?
		 ORDER BY COUNTRY_NAME
	</sql>
    <parameters>
        <parameter prefix="" suffix="%">Page.pnlCriteria.txtCountryName</parameter>
    </parameters>
</popupdata>

