<popupdata type="service">
	<service>UTL_OUTER_LIST_DEF_FOR_TRANS_BETWEEN_ENV</service>
	    <parameters>
	        <parameter n="CODE">Page.pnlCriteria.txtTransferCode</parameter>
	        <parameter n="NAME">Page.pnlCriteria.txtTransferName</parameter>
			<parameter n="INSTITUTION">Page.pnlCriteria.cmbInstitution</parameter>
			<parameter n="ENVIRONMENT">Page.pnlCriteria.cmbEnv</parameter>
	    </parameters>
</popupdata>