<popupdata type="service">
	<service>UTL_OUTER_LIST_OUTER_SYSTEM_TRANS_DEF</service>
    <parameters>
    	<parameter n="TRANSFER_CODE">Page.pnlCriteria.txtTransferCode</parameter>    
        <parameter n="TRANSFER_NAME">Page.pnlCriteria.txtTransferName</parameter>    
		<parameter n="TRANSFER_INSTITUTION">Page.pnlCriteria.cmbInstitution</parameter>    
    </parameters>
</popupdata>