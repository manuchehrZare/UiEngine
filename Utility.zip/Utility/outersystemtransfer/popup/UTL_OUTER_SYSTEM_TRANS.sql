<popupdata type="service">
    <service>UTL_OUTER_LIST_OUTER_SYSTEM_RECORDED_TRANSFERS</service>
    <parameters>
		<parameter n="T_DATE">Page.pnlCriteria.dtTDate</parameter>    
		<parameter n="TRANSFER_DEF_OID">Page.pnlCriteria.cmbTransferDefOID</parameter>    
		<parameter n="OPERATION_TYPE">Page.pnlCriteria.txtOperationType</parameter>
    </parameters>
</popupdata>

