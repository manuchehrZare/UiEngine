# Set UI Library

This library has reusable common components developed for SET project development.

## Getting Started

### Installation

Branch name can be specified with the "#" symbol at the end of the remote path in the command.

**Command structure:** `{packageManagementCommand} {installCommand} {remotePath#branchName}`

**Command example:** `pnpm i git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/setui.git#branchName`

**npm**

`npm i git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/setui.git`

`npm i git+ssh://git@bitbucket.cb.sekerbank.com.tr:7999/erp/setui.git`

**pnpm**

`pnpm add git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/setui.git`

`pnpm add git+ssh://git@bitbucket.cb.sekerbank.com.tr:7999/erp/setui.git`

**yarn**

`yarn add git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/setui.git`

`yarn add git+ssh://git@bitbucket.cb.sekerbank.com.tr:7999/erp/setui.git`

## Documentation

Developed using **Seker-UI** components structured according to needs.<br/>
Library components documentation provided with [Storybook](https://storybook.js.org/).

#### Integration

```javascript
// Import
import { SETProvider } from 'set-ui';

const App: FC = () => {
    return (
        <SETProvider projectProps={{ env: ProcessEnvEnum.Alfa, routeProps: { paths: { home: '#', login: '#' } } }}>
            <App />
        </SETProvider>
    );
};
export default App;
```

## Library Information

- [React](https://reactjs.org/)
- [Create React App](https://github.com/facebook/create-react-app)
- [Typescript](https://www.typescriptlang.org/)
- [SekerUI](https://sekerui.seker.net/)
- [i18next](https://www.i18next.com/), [react-i18next](https://react.i18next.com/)
- [ESLint](https://eslint.org/)
- [Storybook](https://storybook.js.org/)

## Browser Support

- Google Chrome
- Mozilla Firefox
- Microsoft Edge
- Safari

## Contributors

- Kurumsal Önyüz YG

##

Developed by the **Şekerbank Software Development** team.<br/>
You can contact us for your suggestions and support requests.
