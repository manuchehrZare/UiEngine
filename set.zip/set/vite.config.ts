import react from '@vitejs/plugin-react';
import { visualizer } from 'rollup-plugin-visualizer';
import { defineConfig, type PluginOption } from 'vite';
import checker from 'vite-plugin-checker';
import commonJs from 'vite-plugin-commonjs';
import { nodePolyfills } from 'vite-plugin-node-polyfills';
import svgr from 'vite-plugin-svgr';

export default defineConfig({
    build: {
        outDir: 'build',
        sourcemap: true,
        lib: {
            entry: 'src/lib/index.ts', // kütüphanenin giriş noktası varsa burayı doğru ayarla
            name: 'SetUI', // UMD global ismi (opsiyonel)
            fileName: (format) => `set-ui.${format}.js`,
        },
    },
    resolve: {
        dedupe: ['react', 'react-dom', 'react-router-dom'], // Önemli: Duplicate önleme
    },
    server: { open: true, port: 8002 },
    preview: { port: 8002 },
    plugins: [
        nodePolyfills(),
        commonJs(),
        react(),
        checker({
            eslint: { lintCommand: 'eslint "./src/**/*.{ts,tsx,jsx}"', useFlatConfig: true },
            typescript: {
                tsconfigPath: 'tsconfig.json',
                buildMode: false,
            },
        }),
        svgr({ include: '**/*.svg', svgrOptions: { icon: false, exportType: 'named' } }),
        visualizer({
            filename: 'stats.html',
            template: 'treemap',
            open: false,
            gzipSize: true,
            brotliSize: true,
        }) as PluginOption,
    ],
});
