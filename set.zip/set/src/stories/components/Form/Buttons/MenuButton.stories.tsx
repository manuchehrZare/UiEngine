import type { Meta, StoryObj } from '@storybook/react-vite';
import { MenuButton } from '../../../../lib';

const StoryConfig: Meta<typeof MenuButton> = {
    title: 'Components/Form/Buttons/MenuButton',
    component: MenuButton,
    parameters: {
        docs: {
            description: {
                component: 'The **MenuButton** Component',
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof MenuButton> = {
    render: (args) => {
        return <MenuButton {...args} />;
    },
};
