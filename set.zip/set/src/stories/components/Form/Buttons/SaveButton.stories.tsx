import type { Meta, StoryObj } from '@storybook/react-vite';
import { SaveButton } from '../../../../lib';
import { FeedOutlined } from '@mui/icons-material';

const iconSelectControl = {
    options: [0, 1],
    mapping: {
        0: undefined,
        1: <FeedOutlined />,
    },
    control: {
        type: 'select',
        labels: {
            0: 'undefined',
            1: 'With Icon Usage',
        },
    },
};

const StoryConfig: Meta<typeof SaveButton> = {
    title: 'Components/Form/Buttons/SaveButton',
    component: SaveButton,
    parameters: {
        docs: {
            description: {
                component: 'The **SaveButton** Component',
            },
        },
    },
    argTypes: {
        sx: {
            control: {
                type: undefined,
            },
        },
        ref: {
            control: {
                type: undefined,
            },
        },
        id: {
            control: {
                type: undefined,
            },
        },
        name: {
            control: {
                type: undefined,
            },
        },
        className: {
            control: {
                type: undefined,
            },
        },
        href: {
            control: {
                type: undefined,
            },
        },
        confirmModalProps: {
            control: {
                type: undefined,
            },
        },
        type: {
            control: {
                type: undefined,
            },
        },
        iconButton: {
            control: {
                type: 'boolean',
            },
            table: {
                type: { summary: 'boolean' },
                defaultValue: { summary: 'false' },
            },
        },
        icon: iconSelectControl as any,
        iconRight: iconSelectControl as any,
        iconLeft: iconSelectControl as any,
    },
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof SaveButton> = {
    render: (args) => {
        return <SaveButton {...args} />;
    },
};

export const Confirm: StoryObj<typeof SaveButton> = {
    render: () => {
        return <SaveButton enableConfirm />;
    },
};

Confirm.parameters = {
    docs: {
        description: {
            story: 'When the **enableConfirm** prop is given, the confirm modal opens.',
        },
    },
};
