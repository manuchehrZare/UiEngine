import type { Meta, StoryObj } from '@storybook/react-vite';
import { ClosePageButton } from '../../../../lib';

const StoryConfig: Meta<typeof ClosePageButton> = {
    title: 'Components/Form/Buttons/ClosePageButton',
    component: ClosePageButton,
    parameters: {
        docs: {
            description: {
                component: 'The **ClosePageButton** Component',
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof ClosePageButton> = {
    render: () => {
        return (
            <ClosePageButton
                // text="Close"
                // link="#"
                onClick={() => {
                    // eslint-disable-next-line no-console
                    console.log('onClick');
                }}
                closePageConfirmModalProps={{
                    onClose: () => {
                        // eslint-disable-next-line no-console
                        console.log('onClose');
                    },
                    onConfirm: (status) => {
                        // eslint-disable-next-line no-console
                        console.log('onConfirm', status);
                    },
                }}
            />
        );
    },
};
