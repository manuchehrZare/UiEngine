import type { Meta, StoryObj } from '@storybook/react-vite';
import { CloseAppButton } from '../../../../lib';
import { PowerSettingsNew } from '@mui/icons-material';
import { useState } from 'react';

const StoryConfig: Meta<typeof CloseAppButton> = {
    title: 'Components/Form/Buttons/CloseAppButton',
    component: CloseAppButton,
    parameters: {
        docs: {
            description: {
                component: 'The **CloseAppButton** Component',
            },
        },
    },
    argTypes: {
        ref: {
            control: {
                type: undefined,
            },
        },
    },
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof CloseAppButton> = {
    render: () => {
        const [closeAppConfirmModalShow, setCloseAppConfirmModalShow] = useState<boolean>(false);

        return (
            <CloseAppButton
                // text="Close"
                iconLeft={<PowerSettingsNew />}
                onClick={() => {
                    setCloseAppConfirmModalShow(true);
                }}
                closeAppConfirmModalProps={{
                    show: closeAppConfirmModalShow,
                    onClose: () => {
                        !closeAppConfirmModalShow && setCloseAppConfirmModalShow(false);
                        // eslint-disable-next-line no-console
                        console.log('onClose');
                    },
                    onConfirm: (status) => {
                        // eslint-disable-next-line no-console
                        console.log('onConfirm', status);
                        setCloseAppConfirmModalShow(false);
                    },
                }}
            />
        );
    },
};
