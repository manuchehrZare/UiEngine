import type { Meta, StoryObj } from '@storybook/react-vite';
import { DeleteButton } from '../../../../lib';

const meta = {
    title: 'Components/Form/Buttons/DeleteButton',
    component: DeleteButton,
    parameters: {
        docs: {
            description: {
                component: `The **DeleteButton** Component
Clicking this button opens a **ConfirmModal**.`,
            },
        },
    },
    argTypes: {
        sx: { control: false },
        ref: { control: false },
        id: { control: false },
        name: { control: false },
        className: { control: false },
        href: { control: false },
        confirmModalProps: { control: false },
    },
    args: {},
} satisfies Meta<typeof DeleteButton>;

export default meta;

type Story = StoryObj<typeof DeleteButton>;

export const Base: Story = {
    render: (args) => <DeleteButton {...args} />,
};
