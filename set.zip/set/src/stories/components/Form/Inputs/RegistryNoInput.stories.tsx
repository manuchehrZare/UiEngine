import type { Meta, StoryObj } from '@storybook/react-vite';
import { RegistryNoInput } from '../../../../lib';
import { useForm } from 'seker-ui';

const meta: Meta<typeof RegistryNoInput> = {
    title: 'Components/Form/Inputs/RegistryNoInput', // case-sensitive
    component: RegistryNoInput,
    parameters: {
        docs: {
            description: {
                component: `
- It uses the **Input** component of **SekerUI** library for the appearance.

- For more information, visit [SekerUI/Form/Input](https://sekerui.seker.net/?path=/docs/components-form-input--base)
        `,
            },
        },
    },
    args: {},
};

export default meta;

type Story = StoryObj<typeof RegistryNoInput>;

export const Base: Story = {
    render: () => {
        const { control } = useForm({
            defaultValues: {
                registryNoInput: '',
            },
        });
        return <RegistryNoInput name="registryNoInput" control={control} />;
    },
};
