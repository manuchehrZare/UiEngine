import type { Meta, StoryObj } from '@storybook/react-vite';
import { PasswordInput } from '../../../../lib';
import { useForm } from 'seker-ui';

// Meta bilgisi ve Docs açıklamaları
const meta: Meta<typeof PasswordInput> = {
    title: 'Components/Form/Inputs/PasswordInput',
    component: PasswordInput,
    parameters: {
        docs: {
            description: {
                component: `
Shows information about the rules the password must have.

- It uses the **Input** component of **SekerUI** library for the appearance.
- For more information, visit [SekerUI/Form/Input](https://sekerui.seker.net/?path=/docs/components-form-input--base)
        `,
            },
        },
    },
    args: {},
};

export default meta;

// Story tipi
type Story = StoryObj<typeof PasswordInput>;

// Base story (Example kısmı)
export const Base: Story = {
    render: () => {
        const { control } = useForm({
            defaultValues: {
                passwordInput: '',
            },
        });
        return <PasswordInput name="passwordInput" control={control} />;
    },
};
