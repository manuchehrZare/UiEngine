import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, Grid, GridItem } from 'seker-ui';
import { Footer } from '../../../lib';

const meta: Meta<typeof Footer> = {
    title: 'Components/App/Footer',
    component: Footer,
    parameters: {
        docs: {
            description: {
                component: `The **Footer** Component \n
Section of the document that appears in the bottom margin which usually includes buttons.`,
            },
        },
    },
    argTypes: {
        children: {
            control: false,
            table: {
                type: {
                    summary: 'ReactNode',
                },
            },
        },
        ref: {
            control: false,
        },
    },
    args: {},
};

export default meta;

type Story = StoryObj<typeof Footer>;

export const Base: Story = {
    render: () => (
        <Footer>
            <Grid>
                <GridItem>
                    <Button text="Kapat" variant="outlined" />
                </GridItem>
            </Grid>
        </Footer>
    ),
};
