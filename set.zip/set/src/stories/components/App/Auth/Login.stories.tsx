import type { Meta, StoryObj } from '@storybook/react-vite';
import { message, setSessionStorageItem } from 'seker-ui';
import { ReactComponent as Logo } from '../../../../assets/images/logo_mini_lightgreen.svg';
import { constants, Login, useTranslation } from '../../../../lib';

const meta: Meta<typeof Login> = {
    title: 'Components/App/Auth/Login',
    component: Login,
    parameters: {
        docs: {
            description: {
                component: `The **Login** Component \n
When pressed, the authentication information is processed and it redirects to the screen to be entered or to the home page where the wanted screen can be selected.
If the login process is successful, the data to return is written to the console.`,
            },
        },
    },
    argTypes: {},
    args: {},
};

export default meta;

type Story = StoryObj<typeof Login>;

export const Base: Story = {
    render: () => {
        const { t, locale } = useTranslation();
        return (
            <Login
                logo={<Logo height="100%" width="100%" />}
                formProps={{ defaultValues: { password: 'Alfa1111' } }}
                navigateProps={{
                    routes: {
                        home: '#',
                    },
                }}
                gridProps={{ height: 'calc(100vh - 80px)' }}
                onSetAuth={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('setAuthData', data);
                    setSessionStorageItem(constants.key.SET_AUTH, data);
                    message({ variant: 'success', message: t(locale.notifications.loginIsSuccessful) });
                }}
                onResetAuth={() => {
                    // eslint-disable-next-line no-console
                    console.log('resetStoreAuth');
                }}
                onResetQuery={() => {
                    // eslint-disable-next-line no-console
                    console.log('resetStoreQuery');
                }}
                onNavigate={(route) => {
                    // eslint-disable-next-line no-console
                    console.log('navigate', route);
                }}
            />
        );
    },
};
