import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button } from 'seker-ui';
import { Logout } from '../../../../lib';

const meta: Meta<typeof Logout> = {
    title: 'Components/App/Auth/Logout',
    component: Logout,
    parameters: {
        docs: {
            description: {
                component: `The **Logout** Component \n
When pressed, the authentication information is reset and it redirects to the login screen.`,
            },
        },
    },
    argTypes: {},
    args: {},
};
export default meta;

export const Base: StoryObj<typeof Logout> = {
    render: () => {
        return (
            <Logout
                component={<Button text="Çıkış Yap" />}
                logoutConfirmModalProps={{
                    onClose: () => {
                        // eslint-disable-next-line no-console
                        console.log('onClose');
                    },
                    onConfirm: (status) => {
                        // eslint-disable-next-line no-console
                        console.log('onConfirm', status);
                    },
                }}
            />
        );
    },
};
