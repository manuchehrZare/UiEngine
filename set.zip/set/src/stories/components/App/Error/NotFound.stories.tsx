import type { Meta, StoryObj } from '@storybook/react-vite';
import { NotFound } from '../../../../lib';

const StoryConfig: Meta<typeof NotFound> = {
    title: 'Components/App/Error/NotFound',
    component: NotFound,
    parameters: {
        docs: {
            description: {
                component: `The **NotFound** Component \n
If the user is not logged in, the information that you will be directed to the login screen is passed and the screen is redirected.\n
It necessarily requires path as props.`,
            },
        },
    },
    argTypes: {
        ref: {
            control: {
                type: null as any,
            },
        },
    },
    args: {
        isLoggedIn: false,
    },
};
export default StoryConfig;

export const Base: StoryObj = {
    render: (args) => (
        <NotFound
            isLoggedIn
            {...args}
            loginLink="#"
            menuButtonProps={{
                link: '#',
            }}
        />
    ),
};
