import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button } from 'seker-ui';
import { useState } from 'react';
import type { CardInquiryModal } from '../../../../../../../lib';
import { UTC005PageContent } from '../../../../../../../lib';

const StoryConfig: Meta<typeof UTC005PageContent> = {
    title: 'Components/Display/PaymentSystems/PageContent/POS/UTC005PageContent',
    component: UTC005PageContent,
    parameters: {
        docs: {
            description: {
                component: 'The **UTC005PageContent** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace('onClick={() => {}}', 'onClick={() => setModalShow(true)}');
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setModalShow}\n    show={modalShow}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof CardInquiryModal> = {
    render: () => {
        return <UTC005PageContent displayType="Page" payloadData={{ transactionOid: '6e0gn2lxud6ahv00' }} />;
    },
};

export const DisplayTypeModal: StoryObj<typeof CardInquiryModal> = {
    render: () => {
        const [modalShow, setModalShow] = useState<boolean>(false);

        return (
            <>
                <Button text="UTC005PageContent show" onClick={() => setModalShow(true)} />
                <UTC005PageContent
                    displayType="Modal"
                    show={modalShow}
                    onClose={() => setModalShow(false)}
                    payloadData={{ transactionOid: '6e0gn2lxud6ahv00' }}
                />
            </>
        );
    },
};
