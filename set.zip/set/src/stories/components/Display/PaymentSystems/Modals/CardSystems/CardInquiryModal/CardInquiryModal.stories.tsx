import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, useForm, useWatch } from 'seker-ui';
import { useState } from 'react';
import { CardInquiryModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof CardInquiryModal> = {
    title: 'Components/Display/PaymentSystems/Modals/CardSystems/CardInquiryModal',
    component: CardInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **CardInquiryModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setCardInquiryModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setCardInquiryModalOpen}\n    show={cardInquiryModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof CardInquiryModal> = {
    render: () => {
        const [cardInquiryModalOpen, setCardInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Card Inquiry Modal" onClick={() => setCardInquiryModalOpen(true)} />
                <CardInquiryModal show={cardInquiryModalOpen} onClose={setCardInquiryModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof CardInquiryModal> = {
    render: () => {
        interface IFormValues {
            cardInquiryModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                cardInquiryModalInput: '',
            },
        });

        const cardInquiryModalInputVal = useWatch({
            control,
            fieldName: 'cardInquiryModalInput',
        });

        return (
            <ModalViewer<SETModalsEnum.CardInquiryModal>
                component="Input"
                modalComponent={SETModalsEnum.CardInquiryModal}
                control={control}
                name="cardInquiryModalInput"
                label={SETModalsEnum.CardInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.CardInquiryModal,
                }}
                modalProps={
                    {
                        formData: {
                            accountNo: cardInquiryModalInputVal,
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('CardInquiryModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
