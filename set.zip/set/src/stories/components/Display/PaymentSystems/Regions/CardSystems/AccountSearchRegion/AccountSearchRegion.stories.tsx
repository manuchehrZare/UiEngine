import type { Meta, StoryObj } from '@storybook/react-vite';
import AccountSearchRegion from '../../../../../../../lib/components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion';
import { useForm, useWatch } from 'seker-ui';
import { CorporationEnum } from '../../../../../../../lib/components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion/type';

const StoryFormatting: Meta<typeof AccountSearchRegion> = {
    title: 'Components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion',
    component: AccountSearchRegion,
    argTypes: {},
    args: {},
};
export default StoryFormatting;

export const Base: StoryObj<typeof AccountSearchRegion> = {
    render: () => {
        const { control, setValue } = useForm<any>({
            defaultValues: {
                corporation: '01',
                customerNo: null,
                customerNameSurname: '',
                cardNo: null,
            },
        });
        const [customerNoVal, cardNoVal] = useWatch({ control, fieldName: ['customerNo', 'cardNo'] });

        return (
            <AccountSearchRegion
                formProps={{ control, setValue }}
                componentProps={{
                    selectProps: { corporation: { name: 'corporation', label: 'corporation' } },
                    inputProps: {
                        customerNameSurname: {
                            name: 'customerNameSurname',
                            label: 'customerNameSurname',
                        },
                    },
                    numberInputProps: {
                        cardNo: {
                            name: 'cardNo',
                            label: 'cardNo',
                            modalProps: {
                                onReturnData: (data: any) => {
                                    setValue('cardNo', Number(data?.accountNo) || null);
                                    setValue('customerNo', data?.custNo || null);
                                    setValue('customerNameSurname', data?.nameSurname || '');
                                },
                                formData: {
                                    accountNo: cardNoVal || '',
                                    corpNo: CorporationEnum.Sekerbank,
                                    custNo: customerNoVal || '',
                                },
                            } as any,
                        },
                        customerNo: {
                            name: 'customerNo',
                            label: 'customerNo',
                            modalProps: {
                                onReturnData: (data: any) => {
                                    setValue('customerNameSurname', data?.nameSurname || '');
                                    setValue('customerNo', data?.custNo || null);
                                    setValue('cardNo', Number(data?.accountNo) || null);
                                },
                                formData: {
                                    accountNo: cardNoVal || '',
                                    corpNo: CorporationEnum.Sekerbank,
                                    custNo: customerNoVal || '',
                                },
                            } as any,
                        },
                    },
                }}
            />
        );
    },
};
