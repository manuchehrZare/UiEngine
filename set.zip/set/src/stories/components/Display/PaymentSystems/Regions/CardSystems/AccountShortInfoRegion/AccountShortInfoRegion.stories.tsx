import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, Grid, GridItem, Input, Nav, Paper, useForm, useWatch } from 'seker-ui';
import { AccountShortInfoRegion, constants } from '../../../../../../../lib';

const StoryConfig: Meta<typeof AccountShortInfoRegion> = {
    title: 'Components/Display/PaymentSystems/Regions/CardSystems/AccountShortInfoRegion',
    component: AccountShortInfoRegion,
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof AccountShortInfoRegion> = {
    render: () => {
        const { control, setValue, getValues, handleSubmit } = useForm<any>({
            defaultValues: {
                productGroup: '',
                product: '',
                expirationDate: '',
                blockCode: '',
                realCard: '',
                realCardNo: '',
                additionalCard: '',
                virtualCard: '',
                primaryType: '',
                accountNo: '',
            },
        });

        const accountNoWatch = useWatch({ control, fieldName: 'accountNo' });

        return (
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Grid spacingType="common">
                            <GridItem xs pt={3}>
                                <Button
                                    fullWidth
                                    text="SetAccountNo"
                                    onClick={() => setValue('accountNo', '5473110144022807')}
                                />
                            </GridItem>
                            <GridItem
                                sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                lg={constants.design.gridItem.sizeType.form.SET.lg * 4}
                                xl={constants.design.gridItem.sizeType.form.SET.xl * 5}
                                xxl={constants.design.gridItem.sizeType.form.SET.xxl * 7}>
                                <Input control={control} name="accountNo" label="Account No" readOnly />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'AccountShortInfoRegion' }} />
                        <Grid pt={0.5} spacingType="common">
                            <GridItem>
                                <AccountShortInfoRegion
                                    formProps={{ control, setValue, getValues, handleSubmit }}
                                    componentProps={{
                                        selectProps: {
                                            product: { name: 'product', label: 'Product' },
                                            productGroup: { name: 'productGroup', label: 'Product Group' },
                                        },
                                        numberInputProps: {
                                            blockCode: { name: 'blockCode', label: 'Block Code' },
                                            expirationDate: { name: 'expirationDate', label: 'Expiration Date' },
                                        },
                                        inputProps: {
                                            realCardNo: { name: 'realCardNo', label: 'Real Card No' },
                                        },
                                        radioProps: {
                                            additionalCard: { label: 'Additional Card' },
                                            realCard: { label: 'Real Card' },
                                            virtualCard: { label: 'Virtual Card' },
                                        },
                                        radioGroupProps: {
                                            primaryType: { name: 'primaryType' },
                                        },
                                    }}
                                    accountNo={accountNoWatch}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        );
    },
};
