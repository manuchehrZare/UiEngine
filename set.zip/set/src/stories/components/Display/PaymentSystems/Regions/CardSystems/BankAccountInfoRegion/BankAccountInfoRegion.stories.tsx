import type { Meta, StoryObj } from '@storybook/react-vite';
import { useForm, useWatch } from 'seker-ui';
import { BankAccountInfoRegion } from '../../../../../../../lib';
import { isNull } from 'lodash';

const StoryConfig: Meta<typeof BankAccountInfoRegion> = {
    title: 'Components/Display/PaymentSystems/Regions/CardSystems/BankAccountInfoRegion',
    component: BankAccountInfoRegion,
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof BankAccountInfoRegion> = {
    render: () => {
        const { control, setValue } = useForm<any>({
            defaultValues: {
                accountNo: null,
                branch: '',
                customerNameSurname: '',
                customerNo: null,
            },
        });
        const [branchVal, customerNoVal] = useWatch({ control, fieldName: ['branch', 'customerNo'] });

        return (
            <BankAccountInfoRegion
                formProps={{ control, setValue }}
                componentProps={{
                    selectProps: { branch: { name: 'branch', label: 'branch' } },
                    inputProps: {
                        customerNameSurname: {
                            name: 'customerNameSurname',
                            label: 'customerNameSurname',
                        },
                    },
                    numberInputProps: {
                        accountNo: {
                            name: 'accountNo',
                            label: 'accountNo',
                            modalProps: {
                                onReturnData: (data: any) => {
                                    setValue('customerNameSurname', data?.custNameTitle || '');
                                    setValue('accountNo', data?.accCode || null);
                                    setValue('customerNo', data?.accCustCode || null);
                                    setValue('branch', !isNull(data?.accOrgCode) ? String(data.accOrgCode) : '');
                                },
                                formData: {
                                    accOrgCode: branchVal || '',
                                    accCustCode: customerNoVal || null,
                                },
                            } as any,
                        },
                        customerNo: {
                            name: 'customerNo',
                            label: 'customerNo',
                            modalProps: {
                                onReturnData: (data: any) => {
                                    setValue('customerNameSurname', data?.nameTitle || '');
                                    setValue('branch', data?.mainBranchCode ? String(data?.mainBranchCode) : '');
                                },
                                formData: {
                                    custCustMainBranchCode: branchVal || '',
                                },
                            } as any,
                        },
                    },
                }}
            />
        );
    },
};
