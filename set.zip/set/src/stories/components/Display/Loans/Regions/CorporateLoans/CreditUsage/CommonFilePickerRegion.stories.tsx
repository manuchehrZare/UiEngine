import type { Meta, StoryObj } from '@storybook/react-vite';
import { CommonFilePickerRegion } from '../../../../../../../lib';
import { useForm } from 'seker-ui';

const StoryConfig: Meta<typeof CommonFilePickerRegion> = {
    title: 'Components/Display/Loans/Regions/CorporateLoans/CreditUsage/CommonFilePickerRegion',
    component: CommonFilePickerRegion,
    parameters: {
        docs: {
            description: {
                component:
                    'The **CommonFilePickerRegion** Component<br/>EBML equivalent: **RG_CCSUTL_COMMON_FILE_PICKER**',
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof CommonFilePickerRegion> = {
    render: () => {
        const { control } = useForm({ defaultValues: { docs: null } });
        return <CommonFilePickerRegion control={control} name="docs" />;
    },
};
