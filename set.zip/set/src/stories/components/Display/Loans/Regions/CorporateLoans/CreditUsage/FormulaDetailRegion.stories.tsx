import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button } from 'seker-ui';
import { useState } from 'react';
import { FormulaDetailRegion, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof FormulaDetailRegion> = {
    title: 'Components/Display/Loans/Regions/CorporateLoans/CreditUsage/FormulaDetailRegion',
    component: FormulaDetailRegion,
    parameters: {
        docs: {
            description: {
                component: 'The **FormulaDetailRegion** Component',
            },

            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setFormulaDetailRegionOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setFormulaDetailRegionOpen}\n    show={formulaDetailRegionOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof FormulaDetailRegion> = {
    render: () => {
        const [formulaDetailRegionOpen, setFormulaDetailRegionOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Formula Detail Region" onClick={() => setFormulaDetailRegionOpen(true)} />
                <FormulaDetailRegion
                    show={formulaDetailRegionOpen}
                    onClose={setFormulaDetailRegionOpen}
                    titleImp="Formül Test Et"
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof FormulaDetailRegion> = {
    render: () => {
        return (
            <ModalViewer<SETModalsEnum.FormulaDetailRegion>
                component="Button"
                modalComponent={SETModalsEnum.FormulaDetailRegion}
                name="formulaDetailRegionModalInput"
                text={`With Button Usage - ${SETModalsEnum.FormulaDetailRegion}`}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.FormulaDetailRegion,
                }}
                modalProps={{
                    varTestOneFormula: true,
                    pnlTable: [{ dataSetDef: 'APPROVE_CHAIR', values: '6' }],
                }}
            />
        );
    },
};
