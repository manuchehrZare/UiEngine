import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, useForm } from 'seker-ui';
import { useState } from 'react';
import { InterlocutorInquiryModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof InterlocutorInquiryModal> = {
    title: 'Components/Display/Loans/Modals/CorporateLoans/CreditUsage/InterlocutorInquiryModal',
    component: InterlocutorInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **InterlocutorInquiryModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setInterlocutorInquiryModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setInterlocutorInquiryModalOpen}\n    show={interlocutorInquiryModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof InterlocutorInquiryModal> = {
    render: () => {
        const [interlocutorInquiryModalOpen, setInterlocutorInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Interlocutor Inquiry Modal" onClick={() => setInterlocutorInquiryModalOpen(true)} />
                <InterlocutorInquiryModal
                    show={interlocutorInquiryModalOpen}
                    onClose={setInterlocutorInquiryModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof InterlocutorInquiryModal> = {
    render: () => {
        interface IFormValues {
            interlocutorInquiryModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                interlocutorInquiryModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.InterlocutorInquiryModal>
                component="Input"
                modalComponent={SETModalsEnum.InterlocutorInquiryModal}
                control={control}
                name="interlocutorInquiryModalInput"
                label={SETModalsEnum.InterlocutorInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.InterlocutorInquiryModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('InterlocutorInquiryModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
