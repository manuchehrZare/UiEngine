import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { ModalViewer, PersonalLoanApplicationInquiryModal, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof PersonalLoanApplicationInquiryModal> = {
    title: 'Components/Display/Loans/Modals/ConsumerLoans/PersonalLoanApplicationInquiryModal',
    component: PersonalLoanApplicationInquiryModal,
    parameters: {
        docs: {
            description: {
                component:
                    'The **PersonalLoanApplicationInquiryModal** Component<br/>EBML equivalent: **PP_CONS_APPLICATION_SEARCH**',
            },
            transformSource: (source: any, storyContext: any) => {
                let baseCode = storyContext?.parameters.storySource.source;
                baseCode = baseCode.replace('args', '');
                let sourceCode: string = source;
                sourceCode = sourceCode.replace(
                    'onClick={() => {}}',
                    'onClick={() => setPersonalLoanApplicationInquiryModalOpen(true)}',
                );
                sourceCode = sourceCode.replace(
                    'onClose={function noRefCheck() {}}',
                    'onClose={setPersonalLoanApplicationInquiryModalOpen}\n    show={personalLoanApplicationInquiryModalOpen}',
                );
                const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                    if (!codeRow.includes('/>')) {
                        return `\t${String(codeRow)}\n`;
                    }
                    return `\t${String(codeRow)}\n`;
                });
                return baseCode.replace(/return\b[^>]*>(.*?);/g, `return (\n${String(newSourceCode?.join(''))}\n);`);
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof PersonalLoanApplicationInquiryModal> = {
    render: () => {
        const [personalLoanApplicationInquiryModalOpen, setPersonalLoanApplicationInquiryModalOpen] =
            useState<boolean>(false);

        return (
            <>
                <Button
                    text="Personal Loan Application Inquiry Modal"
                    onClick={() => setPersonalLoanApplicationInquiryModalOpen(true)}
                />
                <PersonalLoanApplicationInquiryModal
                    show={personalLoanApplicationInquiryModalOpen}
                    onClose={setPersonalLoanApplicationInquiryModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof PersonalLoanApplicationInquiryModal> = {
    render: () => {
        interface IFormValues {
            personalLoanApplicationInquiryModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                personalLoanApplicationInquiryModalInput: '',
            },
        });
        const [personalLoanApplicationInquiryModalInputWatch] = useWatch({
            control,
            fieldName: ['personalLoanApplicationInquiryModalInput'],
        });
        return (
            <ModalViewer<SETModalsEnum.PersonalLoanApplicationInquiryModal>
                component="NumberInput"
                modalComponent={SETModalsEnum.PersonalLoanApplicationInquiryModal}
                control={control}
                name="personalLoanApplicationInquiryModalInput"
                label={SETModalsEnum.PersonalLoanApplicationInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.PersonalLoanApplicationInquiryModal,
                }}
                modalProps={
                    {
                        formData: {
                            applicationNo: personalLoanApplicationInquiryModalInputWatch,
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('PersonalLoanApplicationInquiryModal---onReturnData', data);
                            setValue('personalLoanApplicationInquiryModalInput', String(data?.applicationNo));
                        },
                    } as any
                }
            />
        );
    },
};
