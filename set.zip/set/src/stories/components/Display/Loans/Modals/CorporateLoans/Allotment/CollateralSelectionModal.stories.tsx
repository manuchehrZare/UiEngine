import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { CollateralSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof CollateralSelectionModal> = {
    title: 'Components/Display/Loans/Modals/CorporateLoans/Allotment/CollateralSelectionModal',
    component: CollateralSelectionModal,
    parameters: {
        docs: {
            description: {
                component: 'The **CollateralSelectionModal** Component<br/>EBML equivalent: **PP_CCS_COLLATERAL**',
            },

            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setCollateralSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setCollateralSelectionModalOpen}\n    show={collateralSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof CollateralSelectionModal> = {
    render: () => {
        const [CollateralSelectionModalOpen, setCollateralSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Collateral Choice Modal" onClick={() => setCollateralSelectionModalOpen(true)} />
                <CollateralSelectionModal
                    show={CollateralSelectionModalOpen}
                    onClose={setCollateralSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof CollateralSelectionModal> = {
    render: () => {
        interface IFormValues {
            collateralSelectionModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                collateralSelectionModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.CollateralSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.CollateralSelectionModal}
                control={control}
                name="collateralSelectionModalInput"
                label={SETModalsEnum.CollateralSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.CollateralSelectionModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('CollateralSelectionModal---onReturnData', data);
                            setValue('collateralSelectionModalInput', String(data.collateralNo));
                        },
                    } as any
                }
            />
        );
    },
};
