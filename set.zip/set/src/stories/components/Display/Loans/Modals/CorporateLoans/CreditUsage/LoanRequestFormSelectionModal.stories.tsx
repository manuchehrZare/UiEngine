import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, useForm } from 'seker-ui';
import { useState } from 'react';
import { LoanRequestFormSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof LoanRequestFormSelectionModal> = {
    title: 'Components/Display/Loans/Modals/CorporateLoans/CreditUsage/LoanRequestFormSelectionModal',
    component: LoanRequestFormSelectionModal,
    parameters: {
        docs: {
            description: {
                component: 'The **LoanRequestFormSelectionModal** Component',
            },

            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setLoanRequestFormSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setLoanRequestFormSelectionModalOpen}\n    show={loanRequestFormSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof LoanRequestFormSelectionModal> = {
    render: () => {
        const [loanRequestFormSelectionModalOpen, setLoanRequestFormSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button
                    text="Loan Request Form Selection Modal"
                    onClick={() => setLoanRequestFormSelectionModalOpen(true)}
                />
                <LoanRequestFormSelectionModal
                    show={loanRequestFormSelectionModalOpen}
                    onClose={setLoanRequestFormSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof LoanRequestFormSelectionModal> = {
    render: () => {
        interface IFormValues {
            loanRequestFormSelectionModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                loanRequestFormSelectionModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.LoanRequestFormSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.LoanRequestFormSelectionModal}
                control={control}
                name="loanRequestFormSelectionModalInput"
                label={SETModalsEnum.LoanRequestFormSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.LoanRequestFormSelectionModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('LoanRequestFormSelectionModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
