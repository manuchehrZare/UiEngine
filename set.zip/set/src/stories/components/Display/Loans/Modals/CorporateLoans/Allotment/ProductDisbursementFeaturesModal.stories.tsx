import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, useForm } from 'seker-ui';
import { useState } from 'react';
import { ModalViewer, ProductDisbursementFeaturesModal, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof ProductDisbursementFeaturesModal> = {
    title: 'Components/Display/Loans/Modals/CorporateLoans/Allotment/ProductDisbursementFeaturesModal',
    component: ProductDisbursementFeaturesModal,
    parameters: {
        docs: {
            description: {
                component:
                    'The **ProductDisbursementFeaturesModal** Component<br/>EBML equivalent: **PP_CCS_LIM_PRODUCT_USAGE_TEMPLET_FOR_CREDIT**',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setProductDisbursementFeaturesModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setProductDisbursementFeaturesModalOpen}\n    show={productDisbursementFeaturesModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof ProductDisbursementFeaturesModal> = {
    render: () => {
        const [productDisbursementFeaturesModalOpen, setProductDisbursementFeaturesModalOpen] =
            useState<boolean>(false);

        return (
            <>
                <Button
                    text="Product Disbursement Features Modal"
                    onClick={() => setProductDisbursementFeaturesModalOpen(true)}
                />
                <ProductDisbursementFeaturesModal
                    show={productDisbursementFeaturesModalOpen}
                    onClose={setProductDisbursementFeaturesModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof ProductDisbursementFeaturesModal> = {
    render: () => {
        interface IFormValues {
            productDisbursementFeaturesModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                productDisbursementFeaturesModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.ProductDisbursementFeaturesModal>
                component="Input"
                modalComponent={SETModalsEnum.ProductDisbursementFeaturesModal}
                control={control}
                name="productDisbursementFeaturesModalInput"
                label={SETModalsEnum.ProductDisbursementFeaturesModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.ProductDisbursementFeaturesModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('ProductDisbursementFeaturesModal---onReturnData', data);
                            setValue('productDisbursementFeaturesModalInput', String(data.detailName));
                        },
                    } as any
                }
            />
        );
    },
};
