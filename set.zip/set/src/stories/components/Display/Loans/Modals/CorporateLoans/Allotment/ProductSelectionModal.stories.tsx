import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, useForm } from 'seker-ui';
import { useState } from 'react';
import { ProductSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof ProductSelectionModal> = {
    title: 'Components/Display/Loans/Modals/CorporateLoans/Allotment/ProductSelectionModal',
    component: ProductSelectionModal,
    parameters: {
        docs: {
            description: {
                component: 'The **ProductSelectionModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setProductSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setProductSelectionModalOpen}\n    show={productSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof ProductSelectionModal> = {
    render: () => {
        const [productSelectionModalOpen, setProductSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Product Selection Modal" onClick={() => setProductSelectionModalOpen(true)} />
                <ProductSelectionModal show={productSelectionModalOpen} onClose={setProductSelectionModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof ProductSelectionModal> = {
    render: () => {
        interface IFormValues {
            productSelectionModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                productSelectionModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.ProductSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.ProductSelectionModal}
                control={control}
                name="productSelectionModalInput"
                label={SETModalsEnum.ProductSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.ProductSelectionModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('ProductSelectionModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
