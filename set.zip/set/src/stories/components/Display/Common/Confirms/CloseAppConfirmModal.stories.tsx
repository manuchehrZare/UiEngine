import { PowerSettingsNew } from '@mui/icons-material';

import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button } from 'seker-ui';
import { CloseAppConfirmModal } from '../../../../../lib';

const StoryConfig: Meta<typeof CloseAppConfirmModal> = {
    title: 'Components/Display/Common/Confirms/CloseAppConfirmModal',
    component: CloseAppConfirmModal,
    parameters: {
        docs: {
            description: {
                component: 'The **CloseAppConfirmModal** Component',
            },
        },
    },
    argTypes: {
        cancelText: {
            control: false,
            table: {
                defaultValue: { summary: '"Vazgeç"' },
                type: { summary: 'string' },
            },
        },
        okText: {
            control: false,
            table: {
                defaultValue: { summary: '"Kapat"' },
                type: { summary: 'string' },
            },
        },
        onClose: {
            control: false,
            table: {
                type: { summary: '() => void' },
            },
        },
        onConfirm: {
            control: false,
            table: {
                type: { summary: 'object' },
                description: '(status: boolean) => void',
            },
        },
        show: {
            control: false,
            table: {
                defaultValue: { summary: 'false' },
                type: { summary: 'boolean' },
            },
        },
        body: {
            table: {
                type: { summary: 'string' },
            },
        },
        title: {
            table: {
                type: { summary: 'string' },
            },
        },
    },
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof CloseAppConfirmModal> = {
    render: () => {
        const [closeAppConfirmModalShow, setCloseAppConfirmModalShow] = useState<boolean>(false);

        return (
            <>
                <Button
                    iconLeft={<PowerSettingsNew />}
                    text="Kapat"
                    variant="outlined"
                    color="error"
                    onClick={() => setCloseAppConfirmModalShow(true)}
                />
                <CloseAppConfirmModal
                    show={closeAppConfirmModalShow}
                    onClose={() => {
                        !closeAppConfirmModalShow && setCloseAppConfirmModalShow(false);
                        // eslint-disable-next-line no-console
                        console.log('onClose');
                    }}
                    onConfirm={(status) => {
                        // eslint-disable-next-line no-console
                        console.log('onConfirm', status);
                        setCloseAppConfirmModalShow(false);
                    }}
                />
            </>
        );
    },
};
