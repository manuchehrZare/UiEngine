import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button } from 'seker-ui';
import { LossOfChangeConfirmModal } from '../../../../../lib';

const StoryConfig: Meta<typeof LossOfChangeConfirmModal> = {
    title: 'Components/Display/Common/Confirms/LossOfChangeConfirmModal',
    component: LossOfChangeConfirmModal,
    parameters: {
        docs: {
            description: {
                component: `The **LossOfChangeConfirmModal** Component.`,
            },
        },
    },
    argTypes: {
        cancelText: {
            control: false,
            table: {
                defaultValue: { summary: '"Hayır"' },
                type: { summary: 'string' },
            },
        },
        okText: {
            control: false,
            table: {
                defaultValue: { summary: '"Evet"' },
                type: { summary: 'string' },
            },
        },
        onClose: {
            control: false,
            table: {
                type: { summary: '() => void' },
            },
        },
        onConfirm: {
            control: false,
            table: {
                type: { summary: 'object' },
                description: '(status: boolean) => void',
            },
        },
        show: {
            control: false,
            table: {
                defaultValue: { summary: 'false' },
                type: { summary: 'boolean' },
            },
        },
        body: {
            table: {
                type: { summary: 'string' },
            },
        },
    },
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof LossOfChangeConfirmModal> = {
    render: () => {
        const [LossOfChangeConfirmModalShow, setLossOfChangeConfirmModalShow] = useState<boolean>(false);

        return (
            <>
                <Button text="Yeni" variant="outlined" onClick={() => setLossOfChangeConfirmModalShow(true)} />
                <LossOfChangeConfirmModal
                    show={LossOfChangeConfirmModalShow}
                    onClose={() => {
                        !LossOfChangeConfirmModalShow && setLossOfChangeConfirmModalShow(false);
                        // eslint-disable-next-line no-console
                        console.log('onClose');
                    }}
                    onConfirm={(status) => {
                        // eslint-disable-next-line no-console
                        console.log('onConfirm', status);
                        setLossOfChangeConfirmModalShow(false);
                    }}
                />
            </>
        );
    },
};
