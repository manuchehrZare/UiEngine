import { PowerSettingsNew } from '@mui/icons-material';
import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button } from 'seker-ui';
import { LogoutConfirmModal } from '../../../../../lib';

const StoryConfig: Meta<typeof LogoutConfirmModal> = {
    title: 'Components/Display/Common/Confirms/LogoutConfirmModal',
    component: LogoutConfirmModal,
    parameters: {
        docs: {
            description: {
                component: `The **LogoutConfirmModal** Component. \n 
There is a logout button on the modal and when pressed, 
the authentication information is reset and it redirects to the login screen.`,
            },
        },
    },
    argTypes: {
        cancelText: {
            control: false,
            table: {
                defaultValue: { summary: '"Vazgeç"' },
                type: { summary: 'string' },
            },
        },
        okText: {
            control: false,
            table: {
                defaultValue: { summary: '"Çıkış Yap"' },
                type: { summary: 'string' },
            },
        },
        onClose: {
            control: false,
            table: {
                type: { summary: '() => void' },
            },
        },
        onConfirm: {
            control: false,
            table: {
                type: { summary: 'object' },
                description: '(status: boolean) => void',
            },
        },
        show: {
            control: false,
            table: {
                defaultValue: { summary: 'false' },
                type: { summary: 'boolean' },
            },
        },
        body: {
            table: {
                type: { summary: 'string' },
            },
        },
    },
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof LogoutConfirmModal> = {
    render: () => {
        const [LogoutConfirmModalShow, setLogoutConfirmModalShow] = useState<boolean>(false);

        return (
            <>
                <Button
                    iconLeft={<PowerSettingsNew />}
                    text="Çıkış Yap"
                    variant="outlined"
                    onClick={() => setLogoutConfirmModalShow(true)}
                />
                <LogoutConfirmModal
                    show={LogoutConfirmModalShow}
                    onClose={() => {
                        !LogoutConfirmModalShow && setLogoutConfirmModalShow(false);
                        // eslint-disable-next-line no-console
                        console.log('onClose');
                    }}
                    onConfirm={(status) => {
                        // eslint-disable-next-line no-console
                        console.log('onConfirm', status);
                        setLogoutConfirmModalShow(false);
                    }}
                />
            </>
        );
    },
};
