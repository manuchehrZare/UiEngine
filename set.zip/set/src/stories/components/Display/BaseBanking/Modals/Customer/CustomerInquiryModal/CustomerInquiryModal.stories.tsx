import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { CustomerInquiryModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof CustomerInquiryModal> = {
    title: 'Components/Display/BaseBanking/Modals/Customer/CustomerInquiryModal',
    component: CustomerInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **CustomerInquiryModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setCustomerInquiryModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setCustomerInquiryModalOpen}\n    show={customerInquiryModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof CustomerInquiryModal> = {
    render: () => {
        const [customerInquiryModalOpen, setCustomerInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Customer Inquiry Modal" onClick={() => setCustomerInquiryModalOpen(true)} />
                <CustomerInquiryModal show={customerInquiryModalOpen} onClose={setCustomerInquiryModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof CustomerInquiryModal> = {
    render: () => {
        interface IFormValues {
            customerInquiryModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                customerInquiryModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                component="NumberInput"
                modalComponent={SETModalsEnum.CustomerInquiryModal}
                control={control}
                name="customerInquiryModalInput"
                label={SETModalsEnum.CustomerInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.CustomerInquiryModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any): any => {
                            // eslint-disable-next-line no-console
                            console.log('CustomerInquiryModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
