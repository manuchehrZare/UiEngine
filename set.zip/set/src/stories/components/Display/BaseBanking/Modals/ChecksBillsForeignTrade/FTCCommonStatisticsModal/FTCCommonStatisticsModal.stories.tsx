import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { FTCCommonStatisticsModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const meta = {
    title: 'Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/FTCCommonStatisticsModal',
    component: FTCCommonStatisticsModal,
    tags: ['autodocs'],
    parameters: {
        docs: {
            description: {
                component: 'The **FTCCommonStatisticsModal** Component',
            },
            // SB9: transformSource -> docs.source.transform
            source: {
                transform: (source: string) => {
                    let sourceCode = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setFTCCommonStatisticsModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setFTCCommonStatisticsModalOpen}\n    show={ftcCommonStatisticsModalOpen}',
                    );
                    const newSourceCode = sourceCode
                        ?.split('\n')
                        .map((row) => `\t${String(row)}\n`)
                        .join('');
                    return `\n${newSourceCode}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
} satisfies Meta<typeof FTCCommonStatisticsModal>;

export default meta;

type Story = StoryObj<typeof FTCCommonStatisticsModal>;

export const Base: Story = {
    render: () => {
        const [ftcCommonStatisticsModalOpen, setFTCCommonStatisticsModalOpen] = useState(false);

        return (
            <>
                <Button text="FTCCommonStatistics Modal" onClick={() => setFTCCommonStatisticsModalOpen(true)} />
                <FTCCommonStatisticsModal
                    show={ftcCommonStatisticsModalOpen}
                    onClose={setFTCCommonStatisticsModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: Story = {
    render: () => {
        interface IFormValues {
            input: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: { input: '' },
        });

        return (
            <ModalViewer<SETModalsEnum>
                component="Input"
                modalComponent={SETModalsEnum.FTCCommonStatisticsModal}
                control={control}
                name="input"
                label={SETModalsEnum.FTCCommonStatisticsModal}
                adornmentButtonProps={{ tooltip: SETModalsEnum.FTCCommonStatisticsModal }}
                modalProps={
                    {
                        onReturnData: (data: unknown) => {
                            // eslint-disable-next-line no-console
                            console.log('FTCCommonStatisticsModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
