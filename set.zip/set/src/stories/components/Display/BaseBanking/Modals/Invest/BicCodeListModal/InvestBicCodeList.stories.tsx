import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { InvestBicCodeListModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof InvestBicCodeListModal> = {
    title: 'Components/Display/BaseBanking/Modals/Invest/InvestBicCodeListModal',
    component: InvestBicCodeListModal,
    parameters: {
        docs: {
            description: {
                component: 'The **InvestBicCodeListModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setInvestBicCodeListModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setInvestBicCodeListModalOpen}\n    show={investBicCodeListModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof InvestBicCodeListModal> = {
    render: () => {
        const [investBicCodeListModalOpen, setInvestBicCodeListModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Invest Bic Code List Modal" onClick={() => setInvestBicCodeListModalOpen(true)} />
                <InvestBicCodeListModal show={investBicCodeListModalOpen} onClose={setInvestBicCodeListModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof InvestBicCodeListModal> = {
    render: () => {
        interface IFormValues {
            investBicCodeListModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                investBicCodeListModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.InvestBicCodeModal>
                component="Input"
                modalComponent={SETModalsEnum.InvestBicCodeModal}
                control={control}
                name="investBicCodeListModalInput"
                label={SETModalsEnum.InvestBicCodeModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.InvestBicCodeModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any): any => {
                            // eslint-disable-next-line no-console
                            console.log('InvestBicCodeListModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
