import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { ChecksBillsForeignTradeBicCodeListModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const meta = {
    title: 'Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/ChecksBillsForeignTradeBicCodeListModal',
    component: ChecksBillsForeignTradeBicCodeListModal,
    tags: ['autodocs'],
    parameters: {
        docs: {
            description: {
                component: 'The **ChecksBillsForeignTradeBicCodeListModal** Component',
            },
            // SB9: transformSource buraya taşındı
            source: {
                transform: (source: string /*, context */) => {
                    let sourceCode = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setChecksBillsForeignTradeBicCodeListModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setChecksBillsForeignTradeBicCodeListModalOpen}\n    show={checksBillsForeignTradeBicCodeListModalOpen}',
                    );
                    const newSourceCode = sourceCode
                        ?.split('\n')
                        .map((row) => `\t${String(row)}\n`)
                        .join('');
                    return `\n${newSourceCode}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
} satisfies Meta<typeof ChecksBillsForeignTradeBicCodeListModal>;

export default meta;

type Story = StoryObj<typeof ChecksBillsForeignTradeBicCodeListModal>;

// --- Base story (object story + render)
export const Base: Story = {
    render: () => {
        const [checksBillsForeignTradeBicCodeListModalOpen, setChecksBillsForeignTradeBicCodeListModalOpen] =
            useState(false);

        return (
            <>
                <Button
                    text="Checks Bills Foreign Trade Bic Code List Modal"
                    onClick={() => setChecksBillsForeignTradeBicCodeListModalOpen(true)}
                />
                <ChecksBillsForeignTradeBicCodeListModal
                    show={checksBillsForeignTradeBicCodeListModalOpen}
                    onClose={setChecksBillsForeignTradeBicCodeListModalOpen}
                />
            </>
        );
    },
};

// --- ModalViewer usage (generic düzeltildi)
export const ModalViewerUsage: Story = {
    render: () => {
        interface IFormValues {
            checksBillsForeignTradeBicCodeListModalInput: string;
        }

        const { control } = useForm<IFormValues>({
            defaultValues: { checksBillsForeignTradeBicCodeListModalInput: '' },
        });

        return (
            <ModalViewer<SETModalsEnum>
                component="Input"
                modalComponent={SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}
                control={control}
                name="checksBillsForeignTradeBicCodeListModalInput"
                label={SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal,
                }}
                modalProps={{
                    onClose: (data: unknown) => {
                        // eslint-disable-next-line no-console
                        console.log('ChecksBillsForeignTradeBicCodeListModal---onReturnData', data);
                    },
                }}
            />
        );
    },
};
