import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { ModalViewer, NostroAccountListModal, SETModalsEnum } from '../../../../../../../lib';

const meta = {
    title: 'Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/NostroAccountListModal',
    component: NostroAccountListModal,
    tags: ['autodocs'],
    parameters: {
        docs: {
            description: {
                component: 'The **NostroAccountListModal** Component<br/>EBML equivalent: **PP_FTB_NOSTRO_LIST**',
            },
            // SB9: transformSource -> docs.source.transform
            source: {
                transform: (source: string) => {
                    let sourceCode = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setNostroAccountListModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setNostroAccountListModalOpen}\n    show={nostroAccountListModalOpen}',
                    );
                    const newSourceCode = sourceCode
                        ?.split('\n')
                        .map((row) => `\t${String(row)}\n`)
                        .join('');
                    return `\n${newSourceCode}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
} satisfies Meta<typeof NostroAccountListModal>;

export default meta;

type Story = StoryObj<typeof NostroAccountListModal>;

export const Base: Story = {
    render: () => {
        const [nostroAccountListModalOpen, setNostroAccountListModalOpen] = useState(false);

        return (
            <>
                <Button text="Nostro Account List Modal" onClick={() => setNostroAccountListModalOpen(true)} />
                <NostroAccountListModal show={nostroAccountListModalOpen} onClose={setNostroAccountListModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: Story = {
    render: () => {
        interface IFormValues {
            nostroAccountListModalInput: string;
        }

        const { control, setValue } = useForm<IFormValues>({
            defaultValues: { nostroAccountListModalInput: '' },
        });

        // RHF standard API: tek alan izle
        const nostroAccountListModalInputWatch = useWatch({
            control,
            fieldName: ['nostroAccountListModalInput'],
        });

        return (
            <ModalViewer<SETModalsEnum>
                component="Input"
                modalComponent={SETModalsEnum.NostroAccountListModal}
                control={control}
                name="nostroAccountListModalInput"
                label={SETModalsEnum.NostroAccountListModal}
                adornmentButtonProps={{ tooltip: SETModalsEnum.NostroAccountListModal }}
                modalProps={
                    {
                        formData: {
                            customerCode: nostroAccountListModalInputWatch && String(nostroAccountListModalInputWatch),
                        },
                        onReturnData: (data: unknown) => {
                            // eslint-disable-next-line no-console
                            console.log('NostroAccountListModal---onReturnData', data);
                            // data?.customerCode varsa input’a geri bas
                            const code = (data as { customerCode?: string })?.customerCode;
                            if (code !== null) setValue('nostroAccountListModalInput', String(code));
                        },
                    } as any
                }
            />
        );
    },
};
