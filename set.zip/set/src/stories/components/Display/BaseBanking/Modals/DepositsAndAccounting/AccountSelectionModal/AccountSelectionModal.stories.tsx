import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { AccountSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const meta = {
    title: 'Components/Display/BaseBanking/Modals/DepositAccountInquiry/AccountSelectionModal',
    component: AccountSelectionModal,
    parameters: {
        docs: {
            description: {
                component: 'The **AccountSelectionModal** Component',
            },
            // SB9: transformSource -> docs.source.transform
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setAccountSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setAccountSelectionModalOpen}\n    show={accountSelectionModal}',
                    );
                    const newSourceCode = sourceCode
                        ?.split('\n')
                        .map((codeRow: any) => `\t${String(codeRow)}\n`)
                        .join('');
                    return `\n${String(newSourceCode)}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
} satisfies Meta<typeof AccountSelectionModal>;

export default meta;

type Story = StoryObj<typeof AccountSelectionModal>;

export const Base: Story = {
    render: () => {
        const [accountSelectionModal, setAccountSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="DepositAccountInquiry Modal" onClick={() => setAccountSelectionModalOpen(true)} />
                <AccountSelectionModal show={accountSelectionModal} onClose={setAccountSelectionModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: Story = {
    render: () => {
        interface IFormValues {
            accountSelectionModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                accountSelectionModalInput: '',
            },
        });

        const accountSelectionModalInputVal = useWatch({
            control,
            fieldName: 'accountSelectionModalInput', // mevcut kullanımı korudum
        });

        return (
            <ModalViewer<SETModalsEnum.AccountSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.AccountSelectionModal}
                control={control}
                name="accountSelectionModalInput"
                label={SETModalsEnum.AccountSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.AccountSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            accCode: accountSelectionModalInputVal,
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('AccountSelectionModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
