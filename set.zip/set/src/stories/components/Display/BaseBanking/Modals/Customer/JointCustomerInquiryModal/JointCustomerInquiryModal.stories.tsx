import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { JointCustomerInquiryModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof JointCustomerInquiryModal> = {
    title: 'Components/Display/BaseBanking/Modals/Customer/JointCustomerInquiryModal',
    component: JointCustomerInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **JointCustomerInquiryModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setJointCustomerInquiryModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setJointCustomerInquiryModalOpen}\n    show={jointCustomerInquiryModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof JointCustomerInquiryModal> = {
    render: () => {
        const [jointCustomerInquiryModalOpen, setJointCustomerInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Joint Customer Inquiry Modal" onClick={() => setJointCustomerInquiryModalOpen(true)} />
                <JointCustomerInquiryModal
                    show={jointCustomerInquiryModalOpen}
                    onClose={setJointCustomerInquiryModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof JointCustomerInquiryModal> = {
    render: () => {
        interface IFormValues {
            jointCustomerInquiryModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                jointCustomerInquiryModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.JointCustomerInquiryModal>
                component="NumberInput"
                modalComponent={SETModalsEnum.JointCustomerInquiryModal}
                control={control}
                name="jointCustomerInquiryModalInput"
                label={SETModalsEnum.JointCustomerInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.JointCustomerInquiryModal,
                }}
                modalProps={
                    {
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('JointCustomerInquiryModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
