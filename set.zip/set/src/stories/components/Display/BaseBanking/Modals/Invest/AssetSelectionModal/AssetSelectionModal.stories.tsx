import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { AssetSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof AssetSelectionModal> = {
    title: 'Components/Display/BaseBanking/Modals/Invest/AssetSelectionModal',
    component: AssetSelectionModal,
    parameters: {
        docs: {
            description: {
                component: 'The **AssetSelectionModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setAssetSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setAssetSelectionModalOpen}\n    show={assetSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof AssetSelectionModal> = {
    render: () => {
        const [assetSelectionModalOpen, setAssetSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Asset Selection Modal" onClick={() => setAssetSelectionModalOpen(true)} />
                <AssetSelectionModal show={assetSelectionModalOpen} onClose={setAssetSelectionModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof AssetSelectionModal> = {
    render: () => {
        interface IFormValues {
            assetSelectionModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                assetSelectionModalInput: '',
            },
        });

        const assetSelectionModalInputVal = useWatch({
            control,
            fieldName: 'assetSelectionModalInput',
        });

        return (
            <ModalViewer<SETModalsEnum.AssetSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.AssetSelectionModal}
                control={control}
                name="assetSelectionModalInput"
                label={SETModalsEnum.AssetSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.AssetSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            shortDescription: assetSelectionModalInputVal,
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('AssetSelectionModal---onReturnData', data);
                        },
                    } as any
                }
                sx={{
                    input: {
                        textTransform: 'uppercase',
                    },
                }}
            />
        );
    },
};
