import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { DepositAccountInquiryModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const StoryConfig: Meta<typeof DepositAccountInquiryModal> = {
    title: 'Components/Display/BaseBanking/Modals/DepositAccountInquiry/DepositAccountInquiryModal',
    component: DepositAccountInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **DepositAccountInquiryModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setDepositAccountInquiryModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setDepositAccountInquiryModalOpen}\n    show={depositAccountInquiryModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof DepositAccountInquiryModal> = {
    render: () => {
        const [depositAccountInquiryModalOpen, setDepositAccountInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="DepositAccountInquiry Modal" onClick={() => setDepositAccountInquiryModalOpen(true)} />
                <DepositAccountInquiryModal
                    show={depositAccountInquiryModalOpen}
                    onClose={setDepositAccountInquiryModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof DepositAccountInquiryModal> = {
    render: () => {
        interface IFormValues {
            depositAccountInquiryModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                depositAccountInquiryModalInput: '',
            },
        });

        const depositAccountInquiryModalInputVal = useWatch({
            control,
            fieldName: 'depositAccountInquiryModalInput',
        });

        return (
            <ModalViewer<SETModalsEnum.DepositAccountInquiryModal>
                component="Input"
                modalComponent={SETModalsEnum.DepositAccountInquiryModal}
                control={control}
                name="depositAccountInquiryModalInput"
                label={SETModalsEnum.DepositAccountInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.DepositAccountInquiryModal,
                }}
                modalProps={
                    {
                        formData: {
                            accCode: depositAccountInquiryModalInputVal,
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('DepositAccountInquiryModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
