import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { FilesModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

const meta = {
    title: 'Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/FilesModal',
    component: FilesModal,
    tags: ['autodocs'],
    parameters: {
        docs: {
            description: { component: 'The **FilesModal** Component' },
            // SB9: transformSource -> docs.source.transform
            source: {
                transform: (source: string) => {
                    let sourceCode = source;
                    sourceCode = sourceCode.replace('onClick={() => {}}', 'onClick={() => setFilesModalOpen(true)}');
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setFilesModalOpen}\n    show={filesModalOpen}',
                    );
                    const newSourceCode = sourceCode
                        ?.split('\n')
                        .map((row) => `\t${String(row)}\n`)
                        .join('');
                    return `\n${newSourceCode}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
} satisfies Meta<typeof FilesModal>;

export default meta;

type Story = StoryObj<typeof FilesModal>;

export const Base: Story = {
    render: () => {
        const [filesModalOpen, setFilesModalOpen] = useState(false);
        return (
            <>
                <Button text="Files Modal" onClick={() => setFilesModalOpen(true)} />
                <FilesModal show={filesModalOpen} onClose={setFilesModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: Story = {
    render: () => {
        interface IFormValues {
            filesModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: { filesModalInput: '' },
        });

        const filesModalInputVal = useWatch({
            control: control as any,
            fieldName: 'filesModalInput', // RHF standard API
        });

        return (
            <ModalViewer<SETModalsEnum>
                component="Input"
                modalComponent={SETModalsEnum.FilesModal}
                control={control}
                name="filesModalInput"
                label={SETModalsEnum.FilesModal}
                adornmentButtonProps={{ tooltip: SETModalsEnum.FilesModal }}
                modalProps={
                    {
                        formData: { fileNo: filesModalInputVal },
                        onReturnData: (data: unknown) => {
                            // eslint-disable-next-line no-console
                            console.log('FilesModal---onReturnData', data);
                        },
                    } as any
                }
            />
        );
    },
};
