import type { Meta, StoryObj } from '@storybook/react-vite';
import { useForm } from 'seker-ui';
import { CustomerInfoRegion } from '../../../../../../../lib';
import type { IFormValues } from '../../../../../../../pages/Components/Display/BaseBanking/Regions/Customer/CustomerInfoRegion/type';

const StoryConfig: Meta<typeof CustomerInfoRegion> = {
    title: 'Components/Display/BaseBanking/Regions/Customer/CustomerInfoRegion',
    component: CustomerInfoRegion,
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof CustomerInfoRegion> = {
    render: () => {
        const { control, setValue, reset } = useForm<IFormValues>({
            defaultValues: {
                activeStatus: '',
                beginDate: null,
                birthday: null,
                country: '',
                customerCode: '',
                customerStatus: '',
                customerType: '',
                endDate: null,
                endUser: '',
                individualCorporate: null,
                individualFarmer: null,
                individualIndividual: null,
                infoNote: '',
                infoNoteExists: false,
                isFollowed: null,
                isInBlockGroup: null,
                mainBranchCode: '',
                name: '',
                nationality: null,
                nonActive: false,
                oid: '',
                passiveToActiveDate: null,
                passiveToActiveUser: '',
                photoExists: false,
                potential: false,
                potentialDate: null,
                potentialSource: '',
                potentialTargetDate: null,
                potentialUser: '',
                secondName: '',
                sharedCustomer: false,
                signatureExists: false,
                surname: '',
                taxNo: null,
                tcId: null,
                title: '',
                updateDate: null,
                userCreated: '',
                userUpdated: '',
            },
        });

        return (
            <CustomerInfoRegion<IFormValues>
                formProps={{ control, setValue, reset }}
                componentProps={{
                    inputProps: {
                        customerStatus: {
                            name: 'customerStatus',
                        },
                        endUser: {
                            name: 'endUser',
                        },
                        name: {
                            name: 'name',
                        },
                        passiveToActiveUser: {
                            name: 'passiveToActiveUser',
                        },
                        potentialUser: {
                            name: 'potentialUser',
                        },
                        secondName: {
                            name: 'secondName',
                        },
                        surname: {
                            name: 'surname',
                        },
                        title: {
                            name: 'title',
                        },
                        userCreated: {
                            name: 'userCreated',
                        },
                        userUpdated: {
                            name: 'userUpdated',
                        },
                    },
                    checkboxProps: {
                        nonActive: {
                            name: 'nonActive',
                        },
                        potential: {
                            name: 'potential',
                        },
                        sharedCustomer: {
                            name: 'sharedCustomer',
                        },
                    },
                    datePickerProps: {
                        beginDate: {
                            name: 'beginDate',
                        },
                        birthday: {
                            name: 'birthday',
                        },
                        endDate: {
                            name: 'endDate',
                        },
                        passiveToActiveDate: {
                            name: 'passiveToActiveDate',
                        },
                        potentialDate: {
                            name: 'potentialDate',
                        },
                        potentialTargetDate: {
                            name: 'potentialTargetDate',
                        },
                        updateDate: {
                            name: 'updateDate',
                        },
                    },
                    numberInputProps: {
                        customerCode: {
                            name: 'customerCode',
                        },
                        taxNo: {
                            name: 'taxNo',
                        },
                        tcId: {
                            name: 'tcId',
                        },
                    },
                    selectProps: {
                        activeStatus: {
                            name: 'activeStatus',
                        },
                        country: {
                            name: 'country',
                        },
                        individualCorporate: {
                            name: 'individualCorporate',
                        },
                        individualFarmer: {
                            name: 'individualFarmer',
                        },
                        individualIndividual: {
                            name: 'individualIndividual',
                        },
                        mainBranchCode: {
                            name: 'mainBranchCode',
                        },
                        nationality: {
                            name: 'nationality',
                        },
                        potentialSource: {
                            name: 'potentialSource',
                        },
                    },
                }}
            />
        );
    },
};
