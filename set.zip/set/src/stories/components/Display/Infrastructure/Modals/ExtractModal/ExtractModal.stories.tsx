import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, Select, useForm, useWatch } from 'seker-ui';
import { ExtractModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof ExtractModal> = {
    title: 'Components/Display/Infrastructure/Modals/ExtractModal',
    component: ExtractModal,
    parameters: {
        docs: {
            description: {
                component: 'The **ExtractModal** Component',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace('onClick={() => {}}', 'onClick={() => setExtractModalOpen(true)}');
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setExtractModalOpen}\n    show={extractModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof ExtractModal> = {
    render: () => {
        const [extractModalOpen, setExtractModalOpen] = useState<boolean>(false);

        const { control, setValue } = useForm({ defaultValues: { bankStatementOid: '' } });
        const bankStatementOidVal = useWatch({
            control,
            fieldName: 'bankStatementOid',
        });

        return (
            <>
                <Select
                    name="bankStatementOid"
                    control={control}
                    setValue={setValue}
                    options={{
                        data: [
                            { name: 'PDF EXTRACT', value: '6e1jt5lomp748k00' },
                            { name: 'HTML EXTRACT', value: '3r11kkk4ds5yiv00' },
                        ],
                        displayField: 'name',
                        displayValue: 'value',
                    }}
                />
                <Button text="Open Extract Modal" onClick={() => setExtractModalOpen(true)} fullWidth sx={{ mt: 1 }} />
                <ExtractModal
                    bankStatementOid={bankStatementOidVal}
                    show={extractModalOpen}
                    onClose={setExtractModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof ExtractModal> = {
    render: () => {
        return (
            <ModalViewer<SETModalsEnum.ExtractModal>
                component="Button"
                modalComponent={SETModalsEnum.ExtractModal}
                text="Open Extract Modal With ModalViewer"
                fullWidth
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.ExtractModal,
                }}
                modalProps={{
                    bankStatementOid: '6e1jt5lomp748k00',
                }}
            />
        );
    },
};
