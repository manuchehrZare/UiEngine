import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { EprocProcessSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof EprocProcessSelectionModal> = {
    title: 'Components/Display/Infrastructure/Modals/EprocProcessSelectionModal',
    component: EprocProcessSelectionModal,
    parameters: {
        docs: {
            description: {
                component:
                    'The **EprocProcessSelectionModal** Component<br/>EBML equivalent: **PP_PROCESS_INSTANCE_CHOOSER**',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setEprocProcessSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setEprocProcessSelectionModalOpen}\n    show={eprocProcessSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof EprocProcessSelectionModal> = {
    render: () => {
        const [eprocProcessSelectionModalOpen, setEprocProcessSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Eproc Process Selection Modal" onClick={() => setEprocProcessSelectionModalOpen(true)} />
                <EprocProcessSelectionModal
                    show={eprocProcessSelectionModalOpen}
                    onClose={setEprocProcessSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof EprocProcessSelectionModal> = {
    render: () => {
        interface IFormValues {
            eprocProcessSelectionModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                eprocProcessSelectionModalInput: '',
            },
        });
        const [eprocProcessSelectionModalInputWatch] = useWatch({
            control,
            fieldName: ['eprocProcessSelectionModalInput'],
        });
        return (
            <ModalViewer<SETModalsEnum.EprocProcessSelectionModal>
                component="NumberInput"
                modalComponent={SETModalsEnum.EprocProcessSelectionModal}
                control={control}
                name="eprocProcessSelectionModalInput"
                label={SETModalsEnum.EprocProcessSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.EprocProcessSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            eprocReferenceId:
                                eprocProcessSelectionModalInputWatch && Number(eprocProcessSelectionModalInputWatch),
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('EprocProcessSelectionModal---onReturnData', data);
                            setValue('eprocProcessSelectionModalInput', String(data?.referenceId));
                        },
                    } as any
                }
            />
        );
    },
};
