import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { InstitutionSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof InstitutionSelectionModal> = {
    title: 'Components/Display/Infrastructure/Modals/InstitutionSelectionModal',
    component: InstitutionSelectionModal,
    parameters: {
        docs: {
            description: {
                component: 'The **InstitutionSelectionModal** Component',
            },
            source: {
                transform: (source: any, storyContext: any) => {
                    let baseCode = storyContext?.parameters.storySource.source;
                    baseCode = baseCode.replace('args', '');
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setInstitutionSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setInstitutionSelectionModalOpen}\n    show={institutionSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return baseCode.replace(
                        /return\b[^>]*>(.*?);/g,
                        `return (\n${String(newSourceCode?.join(''))}\n);`,
                    );
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof InstitutionSelectionModal> = {
    render: () => {
        const [institutionSelectionModalOpen, setInstitutionSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="InstitutionSelectionModal Modal" onClick={() => setInstitutionSelectionModalOpen(true)} />
                <InstitutionSelectionModal
                    show={institutionSelectionModalOpen}
                    onClose={setInstitutionSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof InstitutionSelectionModal> = {
    render: () => {
        interface IFormValues {
            institutionSelectionModalInput: string;
        }
        const { control } = useForm<IFormValues>({
            defaultValues: {
                institutionSelectionModalInput: '',
            },
        });

        const institutionSelectionModalInputVal = useWatch({
            control,
            fieldName: 'institutionSelectionModalInput',
        });

        return (
            <ModalViewer<SETModalsEnum.InstitutionSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.InstitutionSelectionModal}
                control={control}
                name="institutionSelectionModalInput"
                label={SETModalsEnum.InstitutionSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.InstitutionSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            title: institutionSelectionModalInputVal,
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('InstitutionSelectionModal---onReturnData', data);
                        },
                    } as any
                }
                sx={{
                    input: {
                        textTransform: 'uppercase',
                    },
                }}
            />
        );
    },
};
