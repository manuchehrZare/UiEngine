import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { BpmProcessDefinitionSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof BpmProcessDefinitionSelectionModal> = {
    title: 'Components/Display/Infrastructure/Modals/BpmProcessDefinitionSelectionModal',
    component: BpmProcessDefinitionSelectionModal,
    parameters: {
        docs: {
            description: {
                component:
                    'The **BpmProcessDefinitionSelectionModal** Component<br/>EBML equivalent: **PP_BPM_CORE_PROCESS_NAME_SEARCH**',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setBpmProcessDefinitionSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setBpmProcessDefinitionSelectionModalOpen}\n    show={bpmProcessDefinitionSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof BpmProcessDefinitionSelectionModal> = {
    render: () => {
        const [bpmProcessDefinitionSelectionModalOpen, setBpmProcessDefinitionSelectionModalOpen] =
            useState<boolean>(false);

        return (
            <>
                <Button
                    text="Bpm Process Definition Selection Modal"
                    onClick={() => setBpmProcessDefinitionSelectionModalOpen(true)}
                />
                <BpmProcessDefinitionSelectionModal
                    show={bpmProcessDefinitionSelectionModalOpen}
                    onClose={setBpmProcessDefinitionSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof BpmProcessDefinitionSelectionModal> = {
    render: () => {
        interface IFormValues {
            bpmProcessDefinitionSelectionModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                bpmProcessDefinitionSelectionModalInput: '',
            },
        });
        const [bpmProcessDefinitionSelectionModalInputWatch] = useWatch({
            control,
            fieldName: ['bpmProcessDefinitionSelectionModalInput'],
        });
        return (
            <ModalViewer<SETModalsEnum.BpmProcessDefinitionSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.BpmProcessDefinitionSelectionModal}
                control={control}
                name="bpmProcessDefinitionSelectionModalInput"
                label={SETModalsEnum.BpmProcessDefinitionSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.BpmProcessDefinitionSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            processDefinitionName: String(bpmProcessDefinitionSelectionModalInputWatch),
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('BpmProcessDefinitionSelectionModal---onReturnData', data);
                            setValue('bpmProcessDefinitionSelectionModalInput', String(data.processDefinitionName));
                        },
                    } as any
                }
            />
        );
    },
};
