import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { ModalViewer, SETModalsEnum, UnitInquiryModal } from '../../../../../../lib';

const StoryConfig: Meta<typeof UnitInquiryModal> = {
    title: 'Components/Display/Infrastructure/Modals/UnitInquiryModal',
    component: UnitInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **UnitInquiryModal** Component<br/>EBML equivalent: **PP_ORGANISATION**',
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof UnitInquiryModal> = {
    render: () => {
        const [unitInquiryModalOpen, setUnitInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Unit Inquiry Modal" onClick={() => setUnitInquiryModalOpen(true)} />
                <UnitInquiryModal show={unitInquiryModalOpen} onClose={setUnitInquiryModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof UnitInquiryModal> = {
    render: () => {
        interface IFormValues {
            unitInquiryModalInput: string;
        }

        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                unitInquiryModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.UnitInquiryModal>
                component="Input"
                modalComponent={SETModalsEnum.UnitInquiryModal}
                control={control}
                name="unitInquiryModalInput"
                label={SETModalsEnum.UnitInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.UnitInquiryModal,
                }}
                modalProps={
                    {
                        formData: {},
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('UnitInquiryModal---onReturnData', data);
                            setValue('unitInquiryModalInput', String(data?.organizationCode));
                        },
                    } as any
                }
            />
        );
    },
};
