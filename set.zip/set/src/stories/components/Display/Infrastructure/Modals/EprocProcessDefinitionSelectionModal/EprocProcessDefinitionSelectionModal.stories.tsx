import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { EprocProcessDefinitionSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof EprocProcessDefinitionSelectionModal> = {
    title: 'Components/Display/Infrastructure/Modals/EprocProcessDefinitionSelectionModal',
    component: EprocProcessDefinitionSelectionModal,
    parameters: {
        docs: {
            description: {
                component:
                    'The **EprocProcessDefinitionSelectionModal** Component<br/>EBML equivalent: **PP_EPROC_PROCESS**',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setEprocProcessDefinitionSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setEprocProcessDefinitionSelectionModalOpen}\n    show={eprocProcessDefinitionSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof EprocProcessDefinitionSelectionModal> = {
    render: () => {
        const [eprocProcessDefinitionSelectionModalOpen, setEprocProcessDefinitionSelectionModalOpen] =
            useState<boolean>(false);

        return (
            <>
                <Button
                    text="Eproc Process Definition Selection Modal"
                    onClick={() => setEprocProcessDefinitionSelectionModalOpen(true)}
                />
                <EprocProcessDefinitionSelectionModal
                    show={eprocProcessDefinitionSelectionModalOpen}
                    onClose={setEprocProcessDefinitionSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof EprocProcessDefinitionSelectionModal> = {
    render: () => {
        interface IFormValues {
            eprocProcessDefinitionSelectionModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                eprocProcessDefinitionSelectionModalInput: '',
            },
        });
        const [eprocProcessDefinitionSelectionModalInputWatch] = useWatch({
            control,
            fieldName: ['eprocProcessDefinitionSelectionModalInput'],
        });
        return (
            <ModalViewer<SETModalsEnum.EprocProcessDefinitionSelectionModal>
                component="Input"
                modalComponent={SETModalsEnum.EprocProcessDefinitionSelectionModal}
                control={control}
                name="eprocProcessDefinitionSelectionModalInput"
                label={SETModalsEnum.EprocProcessDefinitionSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.EprocProcessDefinitionSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            eprocProcessId: String(eprocProcessDefinitionSelectionModalInputWatch),
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('EprocProcessDefinitionSelectionModal---onReturnData', data);
                            setValue('eprocProcessDefinitionSelectionModalInput', String(data?.eprocProcessId));
                        },
                    } as any
                }
            />
        );
    },
};
