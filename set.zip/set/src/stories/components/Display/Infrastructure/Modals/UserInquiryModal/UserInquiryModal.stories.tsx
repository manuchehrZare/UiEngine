import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { ModalViewer, SETModalsEnum, UserInquiryModal } from '../../../../../../lib';

const StoryConfig: Meta<typeof UserInquiryModal> = {
    title: 'Components/Display/Infrastructure/Modals/UserInquiryModal',
    component: UserInquiryModal,
    parameters: {
        docs: {
            description: {
                component: 'The **UserInquiryModal** Component<br/>EBML equivalent: **PP_USER**',
            },

            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setUserInquiryModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setUserInquiryModalOpen}\n    show={userInquiryModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
        argTypes: {},
        args: {},
    },
};
export default StoryConfig;

export const Base: StoryObj<typeof UserInquiryModal> = {
    render: () => {
        const [userInquiryModalOpen, setUserInquiryModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="User Inquiry Modal" onClick={() => setUserInquiryModalOpen(true)} />
                <UserInquiryModal show={userInquiryModalOpen} onClose={setUserInquiryModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof UserInquiryModal> = {
    render: () => {
        interface IFormValues {
            userInquiryModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                userInquiryModalInput: '',
            },
        });
        const [userInquiryModalInputWatch] = useWatch({
            control,
            fieldName: ['userInquiryModalInput'],
        });
        return (
            <ModalViewer<SETModalsEnum.UserInquiryModal>
                component="Input"
                modalComponent={SETModalsEnum.UserInquiryModal}
                control={control}
                name="userInquiryModalInput"
                label={SETModalsEnum.UserInquiryModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.UserInquiryModal,
                }}
                modalProps={
                    {
                        formData: {
                            txtUserName: userInquiryModalInputWatch && String(userInquiryModalInputWatch),
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('UserInquiryModal---onReturnData', data);
                            setValue('userInquiryModalInput', String(data?.userName));
                        },
                    } as any
                }
            />
        );
    },
};
