import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm } from 'seker-ui';
import { DocumentTypesModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof DocumentTypesModal> = {
    title: 'Components/Display/Infrastructure/Modals/DocumentTypesModal',
    component: DocumentTypesModal,
    parameters: {
        docs: {
            description: {
                component: 'The **DocumentTypesModal** Component<br/>EBML equivalent: **PP_DMS_STRUCT_LIST_TYPES**',
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof DocumentTypesModal> = {
    render: () => {
        const [documentTypesModalOpen, setDocumentTypesModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Document Types Modal" onClick={() => setDocumentTypesModalOpen(true)} />
                <DocumentTypesModal show={documentTypesModalOpen} onClose={setDocumentTypesModalOpen} />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof DocumentTypesModal> = {
    render: () => {
        interface IFormValues {
            documentTypesModalInput: string;
        }

        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                documentTypesModalInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.DocumentTypesModal>
                component="Input"
                modalComponent={SETModalsEnum.DocumentTypesModal}
                control={control}
                name="documentTypesModalInput"
                label={SETModalsEnum.DocumentTypesModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.DocumentTypesModal,
                }}
                modalProps={
                    {
                        formData: {},
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('DocumentTypesModal---onReturnData', data);
                            setValue('documentTypesModalInput', String(data?.itemType));
                        },
                    } as any
                }
            />
        );
    },
};
