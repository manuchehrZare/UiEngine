import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { Button, useForm, useWatch } from 'seker-ui';
import { BpmProcessSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const StoryConfig: Meta<typeof BpmProcessSelectionModal> = {
    title: 'Components/Display/Infrastructure/Modals/BpmProcessSelectionModal',
    component: BpmProcessSelectionModal,
    parameters: {
        docs: {
            description: {
                component:
                    'The **BpmProcessSelectionModal** Component<br/>EBML equivalent: **PP_BPM_CORE_PROCESS_INSTANCE_SEARCH**',
            },
            source: {
                transform: (source: any) => {
                    let sourceCode: string = source;
                    sourceCode = sourceCode.replace(
                        'onClick={() => {}}',
                        'onClick={() => setBpmProcessSelectionModalOpen(true)}',
                    );
                    sourceCode = sourceCode.replace(
                        'onClose={function noRefCheck() {}}',
                        'onClose={setBpmProcessSelectionModalOpen}\n    show={bpmProcessSelectionModalOpen}',
                    );
                    const newSourceCode = sourceCode?.split('\n').map((codeRow: any) => {
                        if (!codeRow.includes('/>')) {
                            return `\t${String(codeRow)}\n`;
                        }
                        return `\t${String(codeRow)}\n`;
                    });
                    return `\n${String(newSourceCode?.join(''))}\n`;
                },
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof BpmProcessSelectionModal> = {
    render: () => {
        const [bpmProcessSelectionModalOpen, setBpmProcessSelectionModalOpen] = useState<boolean>(false);

        return (
            <>
                <Button text="Bpm Process Selection Modal" onClick={() => setBpmProcessSelectionModalOpen(true)} />
                <BpmProcessSelectionModal
                    show={bpmProcessSelectionModalOpen}
                    onClose={setBpmProcessSelectionModalOpen}
                />
            </>
        );
    },
};

export const ModalViewerUsage: StoryObj<typeof BpmProcessSelectionModal> = {
    render: () => {
        interface IFormValues {
            bpmrocessSelectionModalInput: string;
        }
        const { control, setValue } = useForm<IFormValues>({
            defaultValues: {
                bpmrocessSelectionModalInput: '',
            },
        });
        const [bpmrocessSelectionModalInputWatch] = useWatch({
            control,
            fieldName: ['bpmrocessSelectionModalInput'],
        });
        return (
            <ModalViewer<SETModalsEnum.BpmProcessSelectionModal>
                component="NumberInput"
                modalComponent={SETModalsEnum.BpmProcessSelectionModal}
                control={control}
                name="bpmrocessSelectionModalInput"
                label={SETModalsEnum.BpmProcessSelectionModal}
                adornmentButtonProps={{
                    tooltip: SETModalsEnum.BpmProcessSelectionModal,
                }}
                modalProps={
                    {
                        formData: {
                            referenceId: bpmrocessSelectionModalInputWatch && Number(bpmrocessSelectionModalInputWatch),
                        },
                        onReturnData: (data: any) => {
                            // eslint-disable-next-line no-console
                            console.log('BpmProcessSelectionModal---onReturnData', data);
                            setValue('bpmrocessSelectionModalInput', String(data?.referenceId));
                        },
                    } as any
                }
            />
        );
    },
};
