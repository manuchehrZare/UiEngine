import type { Meta, StoryObj } from '@storybook/react-vite';
import { ModalViewer, SETModalsEnum } from '../../../lib';
import { useForm } from 'seker-ui';

const meta: Meta<typeof ModalViewer> = {
    title: 'Components/Others/ModalViewer',
    component: ModalViewer,
    parameters: {
        docs: {
            description: {
                component: `
It is an input component that provides the display and data exchange of **modal components commonly** used in the **SET** project.

- With the modal type information given to the component generically, the "**modalProps**" property exhibits type safe behavior in accordance with that modal type.
- Information about which element was opened as a result of clicking is shared with the "**eventOwnerEl**" props defined in the **SETModalCommonProps** type, which will be available to all modals.

For more information:

- **SETModalCommonProps**, **SETModalType** and **SETModalsEnum**: [Types/Modals](../?path=/docs/utils-types-modals--page)
- **Input** component: [SekerUI/Form/Input](https://sekerui.seker.net/?path=/docs/components-form-input--base)
- **NumberInput** component: [SekerUI/Form/NumberInput](https://sekerui.seker.net/?path=/docs/components-form-numberinput--base)
- **Button** component: [SekerUI/Form/Button](https://sekerui.seker.net/?path=/docs/components-form-button-button--base)
        `,
            },
        },
    },
    args: {},
};

export default meta;

type Story = StoryObj<typeof ModalViewer>;

export const Base: Story = {
    render: () => {
        const { control } = useForm<{ modalViewerInput: string }>({
            defaultValues: {
                modalViewerInput: '',
            },
        });

        return (
            <ModalViewer<SETModalsEnum.UserInquiryModal>
                component="Input" // 'Input' | 'NumberInput' | 'Button' | 'CardNumber'
                control={control}
                modalComponent={SETModalsEnum.UserInquiryModal} // SETModalType
                name="modalViewerInput"
                label="Label Text"
                adornmentButtonProps={{
                    tooltip: 'Tooltip Text',
                }}
                modalProps={{
                    onClose: (showValue) => {
                        // eslint-disable-next-line no-console
                        console.log('onClose', showValue);
                    },
                }}
            />
        );
    },
};
