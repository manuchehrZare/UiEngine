import type { Meta, StoryObj } from '@storybook/react-vite';
import { Box, Select, useForm, useWatch } from 'seker-ui';
import { DmsDocumentViewer } from '../../../lib';

const StoryConfig: Meta<typeof DmsDocumentViewer> = {
    title: 'Components/Others/DmsDocumentViewer',
    component: DmsDocumentViewer,
    parameters: {
        docs: {
            description: {
                component: 'The **DmsDocumentViewer** Component',
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<typeof DmsDocumentViewer> = {
    render: () => {
        const { control, setValue } = useForm({ defaultValues: { payloadData: 'pdf' } });
        const payloadDataVal = useWatch({
            control,
            fieldName: 'payloadData',
        });

        const pdfPayloadData = {
            docVersion: '',
            docVersionPiid: '',
            docHttpUrl: '{A0F4A38B-0000-CB2E-B04C-4DB6F2D24D91}',
            piid: '',
            restrictionNeeded: '0',
        };

        const htmlPayloadData = {
            docVersion: '',
            docVersionPiid: '',
            docHttpUrl: 'ece1be33-5751-4366-9d04-886914152f49',
            piid: '',
            restrictionNeeded: '0',
        };

        return (
            <>
                <Select
                    name="payloadData"
                    control={control}
                    setValue={setValue}
                    displayEmpty={false}
                    options={{
                        data: [
                            {
                                name: 'PDF Document',
                                value: 'pdf',
                            },
                            {
                                name: 'HTML Document',
                                value: 'html',
                            },
                        ],
                        displayField: 'name',
                        displayValue: 'value',
                    }}
                />
                <Box mt={1}>
                    <DmsDocumentViewer
                        payloadData={payloadDataVal === 'pdf' ? pdfPayloadData : htmlPayloadData}
                        outerHeight={500}
                    />
                </Box>
            </>
        );
    },
};
