import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, message, MessageTypeEnum } from 'seker-ui';
import type { ResponseError } from '../../../../lib';
import { ErrorMessageContent } from '../../../../lib';

const StoryConfig: Meta<typeof ErrorMessageContent> = {
    title: 'Components/Utils/Message/ErrorMessageContent',
    component: ErrorMessageContent,
    parameters: {
        docs: {
            description: {
                component: `The **ErrorMessageContent** Component\n
Gets triggered by the message component, designed to display error messages. If there is no response data or not suitable for the responseError model, a message without details will be displayed.`,
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

// eslint-disable-next-line react-refresh/only-export-components
export const Base: StoryObj<typeof ErrorMessageContent> = {
    render: () => {
        const str = 'Hello World!';
        return (
            <Button
                sx={{ mr: 1 }}
                text="Error"
                onClick={() => {
                    message({
                        variant: MessageTypeEnum.error, // MessageTypeEnum is located in and can be imported from sekerui library.
                        message: str,
                        persist: true,
                        error: {
                            message: str,
                            name: 'Error',
                            isAxiosError: true,
                            toJSON: null,
                        },
                    } as any);
                }}
            />
        );
    },
};
// eslint-disable-next-line react-refresh/only-export-components
export const WithDetail: StoryObj<any> = {
    render: () => {
        const str = 'Hello World!';

        const errorResponse = {
            config: {
                path: '/custom/path',
                url: '/custom/error/path',
                headers: {
                    'x-request-id': 'xyz123xyz123xyz123',
                },
            },
        };

        return (
            <Button
                sx={{ mr: 1 }}
                text="ErrorMessageContent"
                onClick={() => {
                    message({
                        variant: MessageTypeEnum.error, // MessageTypeEnum is located in and can be imported from sekerui library.
                        message: str,
                        persist: true,
                        error: {
                            message: str,
                            name: 'Error',
                            isAxiosError: true,
                            toJSON: null,
                            config: errorResponse.config as any,
                            response: {
                                data: {
                                    error: 'Custom Error',
                                    errorCode: 0,
                                    message: str,
                                    path: errorResponse.config.path,
                                    status: 400,
                                    timestamp: 'Custom Error TimeStamp',
                                    trace: 'Custom Error Trace',
                                } as ResponseError,
                            },
                        } as any,
                    } as any);
                }}
            />
        );
    },
};

WithDetail.parameters = {
    docs: {
        description: {
            story: `If the error returned as a result of the error to be obtained from the services ( the response error of the nova backend ) is suitable for the ResponseError model, a detailed message will be displayed. \n
For more detailed information on the structure of the model : <a href="../?path=/docs/utils-types-services--page" target="_blank"> ResponseError </a>`,
        },
    },
};
