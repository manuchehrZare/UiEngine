import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, Grid, GridItem, Nav, Paper, PdfViewer } from 'seker-ui';
import { GenericSetCallerEnum, useJReportAxios } from '../../lib';

const StoryConfig: Meta<any> = {
    title: 'Hooks/useJReportAxios',
    parameters: {
        docs: {
            source: {
                type: 'code',
            },
            description: {
                component: `The **useJReportAxios** Hooks\n
- It uses defined **useAxios** hook for requests.\n
- This hook created for only jasper report services.\n
- If it get an error calls a error service for reason of error. To determine endpoint of error service use **config.coreService** parameter.\n
- By default useJReportAxios works manually, to change it use **options** parameter.\n`,
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<any> = {
    render: () => {
        interface IJReportScreensWithProcessAndScreenActionDataParameters {
            COMPONENT_GROUP_OID?: string;
            COMPONENT_OID?: string;
            DATA_CODE?: string;
            PROCESS_BEGIN_DATE?: string;
            PROCESS_END_DATE?: string;
            PROCESS_GROUP_OID?: string;
            PROCESS_ID?: string;
            PROCESS_OPERATION_TYPE?: string;
            SCREEN_ACTION_OID?: string;
            SCREEN_BEGIN_DATE?: string;
            SCREEN_CODE?: string;
            SCREEN_END_DATE?: string;
            SCREEN_OPERATION_TYPE?: string;
            USER_SORT_KEY?: string;
        }

        interface IJReportScreensWithProcessAndScreenActionReportParameters {
            USER_FULL_NAME: string;
        }

        const [{ response }, jReportCall] = useJReportAxios<
            IJReportScreensWithProcessAndScreenActionReportParameters,
            IJReportScreensWithProcessAndScreenActionDataParameters
        >({ coreService: GenericSetCallerEnum.ADMIN_MENU_REPORT_SCREENS_WITH_PROCESS_AND_SCREEN_ACTION });

        return (
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'useJasperReport' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem xs="auto">
                                        <Button
                                            text="Call jReport - Success"
                                            onClick={() =>
                                                jReportCall({
                                                    data: {
                                                        reportId: 'screensWithProcessAndScreenAction',
                                                        dataParameters: {
                                                            COMPONENT_GROUP_OID: '',
                                                            COMPONENT_OID: '',
                                                            DATA_CODE: '',
                                                            PROCESS_BEGIN_DATE: '20230801',
                                                            PROCESS_END_DATE: '20230830',
                                                            PROCESS_GROUP_OID: '',
                                                            PROCESS_ID: '',
                                                            PROCESS_OPERATION_TYPE: 'U',
                                                            SCREEN_ACTION_OID: '',
                                                            SCREEN_BEGIN_DATE: '',
                                                            SCREEN_CODE: '',
                                                            SCREEN_END_DATE: '',
                                                            SCREEN_OPERATION_TYPE: '',
                                                            USER_SORT_KEY: 'screenCode',
                                                        },
                                                        reportParameters: { USER_FULL_NAME: 'SERDAR DEMİROĞLU' },
                                                    },
                                                })
                                            }
                                        />
                                    </GridItem>
                                    <GridItem xs="auto">
                                        <Button
                                            text="Call jReport - Error"
                                            color="error"
                                            onClick={() =>
                                                jReportCall({
                                                    data: {
                                                        reportId: 'screensWithProcessAndScreenAction',
                                                        dataParameters: {
                                                            COMPONENT_GROUP_OID: '',
                                                            COMPONENT_OID: '',
                                                            DATA_CODE: '',
                                                            PROCESS_BEGIN_DATE: '20240304',
                                                            PROCESS_END_DATE: '20240304',
                                                            PROCESS_GROUP_OID: '',
                                                            PROCESS_ID: '',
                                                            PROCESS_OPERATION_TYPE: 'I',
                                                            SCREEN_ACTION_OID: '',
                                                            SCREEN_BEGIN_DATE: '',
                                                            SCREEN_CODE: '',
                                                            SCREEN_END_DATE: '',
                                                            SCREEN_OPERATION_TYPE: '',
                                                            USER_SORT_KEY: 'screenCode',
                                                        },
                                                        reportParameters: { USER_FULL_NAME: 'SERDAR DEMİROĞLUA' },
                                                    },
                                                })
                                            }
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Grid>
                            <GridItem height={350}>
                                <PdfViewer source={response?.data?.pdfContent} />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        );
    },
};
