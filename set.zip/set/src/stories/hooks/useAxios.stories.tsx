import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button, Grid, GridItem } from 'seker-ui';
import { useAxios } from '../../lib';

const StoryConfig: Meta<any> = {
    title: 'Hooks/useAxios',
    parameters: {
        docs: {
            source: {
                type: 'code',
            },
            description: {
                component: `The **useAxios** Hooks\n
- It uses defined axios interceptors for requests.\n
- By default, it works based on the existence of authentication data. To disable this feature, the **disableAuthControl (default = false)** parameter must be given a value of **true**.\n
- If a request is to be executed directly without being manual, the **disableAuthControl (default = false)** parameter must be given the value **true**.`,
            },
        },
    },
    argTypes: {},
    args: {},
};
export default StoryConfig;

export const Base: StoryObj<any> = {
    render: () => {
        const [{ data }] = useAxios({
            url: 'https://jsonplaceholder.typicode.com/users?id=1',
            disableAuthControl: true, // default 'false'
        });
        return <>{JSON.stringify(data)}</>;
    },
};

export const Manual: StoryObj<any> = {
    render: () => {
        const [{ data, loading }, executeRequest] = useAxios(
            {
                url: 'https://jsonplaceholder.typicode.com/users?id=2',
            },
            { manual: true },
        );
        const handleClick = async () => {
            await executeRequest();
        };
        return (
            <Grid spacingType="common">
                <GridItem>
                    <Button disabled={loading} text="Request" onClick={() => handleClick()} />
                </GridItem>
                <GridItem>{JSON.stringify(data)}</GridItem>
            </Grid>
        );
    },
};

export const DisableLoadingView: StoryObj<any> = {
    render: () => {
        const [{ data, loading }, executeRequest] = useAxios(
            {
                url: 'https://jsonplaceholder.typicode.com/users?id=3',
                disableLoadingView: true,
            },
            { manual: true },
        );
        const handleClick = async () => {
            await executeRequest();
        };
        return (
            <Grid spacingType="common">
                <GridItem>
                    <Button disabled={loading} text="Request" onClick={() => handleClick()} />
                </GridItem>
                <GridItem>{JSON.stringify(data)}</GridItem>
            </Grid>
        );
    },
};

Manual.parameters = {
    docs: {
        description: {
            story: `- **manual (default = false) :** The request is invoked manually.`,
        },
    },
};

DisableLoadingView.parameters = {
    docs: {
        description: {
            story: `- **disableLoadingView (default = false) :** It disables the loading element, which is displayed by default until the request is completed.`,
        },
    },
};
