import type { ChangeLanguageOptions } from 'seker-ui';
import { i18nChangeLanguage as i18nChangeLanguageSekerUI } from 'seker-ui';
import { i18nChangeLanguage } from '../lib';

export const changeAppLanguage = ({ callback, ...rest }: ChangeLanguageOptions): void => {
    i18nChangeLanguage({
        ...rest,
        callback: () => {
            i18nChangeLanguageSekerUI({ lng: rest.lng, reload: false });
            callback?.();
        },
    });
};
