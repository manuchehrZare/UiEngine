import type { DOMAttributes } from 'react';
import { isWebview } from '../../../../lib';

export const getSortedAlphabetList = (alphabets: string[]): string[] => {
    const alphabet = {
        lower: 'abcçdefgğhıijklmnoöpqrsştuüvwxyz',
        upper: 'ABCÇDEFGĞHIİJKLMNOÖPQRSŞTUÜVWXYZ',
    };
    const arr: string[] = [];
    alphabet.upper.split('').forEach((char) => {
        if (alphabets.join('').toUpperCase().includes(char)) arr.push(char);
    });
    return arr;
};

/**
 * It has been added so that the link does not appear in the lower left corner of the browser in the shell desktop application.
 * @returns Hover event that removes the 'href' from element.
 */
export const removeHrefFromLinkForShell = (): Pick<DOMAttributes<any>, 'onMouseOverCapture'> => {
    if (isWebview()) {
        return {
            onMouseOverCapture: (e) => {
                e.currentTarget.hasAttribute('href') && e.currentTarget.removeAttribute('href');
            },
        };
    }
    return {};
};
