import { merge } from 'lodash';
import { constants as setUIConstants } from '../../lib';
import { common } from './common';
import { key } from './key';

export const constants = merge(setUIConstants, { common, key });
