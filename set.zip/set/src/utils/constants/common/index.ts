export const common = {
    layout: {
        FOOTER_HEIGHT: 32,
        HEADER_HEIGHT: 32,
        SIDEBAR_WIDTH: 100,
    },
};
