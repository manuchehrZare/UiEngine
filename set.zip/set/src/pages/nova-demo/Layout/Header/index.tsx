import type { FC, JSX } from 'react';
import { Header } from '../../../../App';

const LayoutHeaderPage: FC = (): JSX.Element => {
    return <Header />;
};

export default LayoutHeaderPage;
