import type { FC, JSX } from 'react';
import Footer from '../../../Components/App/Footer';

const LayoutFooterPage: FC = (): JSX.Element => {
    return <Footer />;
};

export default LayoutFooterPage;
