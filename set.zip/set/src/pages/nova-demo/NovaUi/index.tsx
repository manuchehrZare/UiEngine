import { CheckCircle, Close, Error, Info, Warning } from '@mui/icons-material';
import type { FC, JSX } from 'react';
import type { Theme } from 'seker-ui';
import { Box, Button, Grid, GridItem, Label, MessageTypeEnum, View } from 'seker-ui';
import { Layout } from '../../../App';
import { GridTitle } from '../components';
import { v4 as uuidv4 } from 'uuid';

interface INotificationItem {
    description: string;
    title: string;
    type: `${MessageTypeEnum}`;
}

const NovaUi: FC = (): JSX.Element => {
    // const { t, locale } = useTranslation();

    const getColor = (type: `${MessageTypeEnum}`, theme: Theme): string => {
        switch (type) {
            case MessageTypeEnum.success:
                return theme.palette.secondary.main;
            case MessageTypeEnum.error:
                return theme.palette.error.main;
            case MessageTypeEnum.info:
                return theme.palette.info.light;
            case MessageTypeEnum.warning:
                return theme.palette.warning.main;
            default:
                return theme.palette.primary.main;
        }
    };

    const getIcon = (type: `${MessageTypeEnum}`) => {
        switch (type) {
            case MessageTypeEnum.success:
                return <CheckCircle color="secondary" />;
            case MessageTypeEnum.error:
                return <Error color="error" />;
            case MessageTypeEnum.info:
                return <Info color="info" sx={{ color: (theme) => theme.palette.info.light }} />;
            case MessageTypeEnum.warning:
                return <Warning color="warning" />;
            default:
                return null;
        }
    };

    const notifications: INotificationItem[] = [
        {
            type: 'default',
            title: 'nova generic ui page',
            description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        },
    ];
    return (
        <Layout title="Notifications">
            <GridTitle title="Notifications" />
            <Grid py={2} spacing={1}>
                {notifications.map((item) => {
                    const notyIcon = getIcon(item.type);
                    return (
                        <GridItem key={uuidv4()}>
                            <Box p={1.5} border={1} borderColor={(theme) => theme.palette.grey[300]} borderRadius={2}>
                                <Grid spacing={1}>
                                    <View show={Boolean(notyIcon)}>
                                        <GridItem xs={false}>{notyIcon}</GridItem>
                                    </View>
                                    <GridItem xs>
                                        <Grid spacing={1}>
                                            <GridItem>
                                                <Label
                                                    text={item.title}
                                                    color={(theme) => getColor(item.type, theme)}
                                                />
                                            </GridItem>
                                            <GridItem fontSize={11}>{item.description}</GridItem>
                                        </Grid>
                                    </GridItem>
                                    <GridItem xs={false}>
                                        <Button variant="text" color="primary" iconButton icon={<Close />} rounded />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </GridItem>
                    );
                })}
            </Grid>
        </Layout>
    );
};

export default NovaUi;
