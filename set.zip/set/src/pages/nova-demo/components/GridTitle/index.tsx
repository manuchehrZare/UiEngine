import { OpenInBrowser, Search } from '@mui/icons-material';
import type { ReactElement, Ref } from 'react';
import { forwardRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Autocomplete,
    Button,
    DesignTypeEnum,
    Grid,
    GridItem,
    importantStyle,
    NavContainer,
    NavItem,
    NavRow,
    NavTitle,
    Tooltip,
    useForm,
    useWatch,
    View,
} from 'seker-ui';
import { isWebview, ShellProcessTypeEnum, shellTrigger } from '../../../../lib';
import { KeyboardEventCodeEnum, useTranslation } from '../../../../lib/utils';
import type { IGridTitleProps, ISearchFormValues } from './type';

const GridTitleBase = <TSearchData,>({ searchProps, title, ...rest }: IGridTitleProps<TSearchData>, ref: Ref<any>) => {
    const { t, locale } = useTranslation();
    const navigate = useNavigate();

    const { control, handleSubmit, reset } = useForm<ISearchFormValues>({
        defaultValues: { search: '' },
    });
    const searchWatch = useWatch({ control, fieldName: 'search' });

    const onSubmit = ({ search }: ISearchFormValues) => {
        if (search && searchProps?.show) {
            const foundItem = searchProps?.options?.data?.find(
                (item) => item[searchProps?.options.displayValue] === search,
            );
            foundItem && searchProps?.onOpenScreenClick(foundItem);
        }
        reset();
    };

    return (
        <Grid
            ref={ref}
            position="sticky"
            top={0}
            bgcolor={(theme) => theme.palette.common.white}
            zIndex={(theme) => theme.zIndex.appBar}
            boxShadow={(theme) => `0px 0px 0px 2px ${theme.palette.common.white}`}
            {...rest}>
            <GridItem>
                <NavContainer design={DesignTypeEnum.Default}>
                    <NavRow px={0} width="100%" design={DesignTypeEnum.Default}>
                        <NavItem py={1} design={DesignTypeEnum.Default}>
                            <NavTitle
                                design={DesignTypeEnum.Default}
                                sx={{
                                    '.sekerUI-NavTitle': {
                                        fontSize: importantStyle('32px'),
                                        color: (theme) => theme.palette.primary.main,
                                    },
                                    '.sekerUI-NavBackButton-box': { pr: 1 },
                                }}
                                title={title}
                                backButtonProps={{
                                    show: true,
                                    color: 'secondary',
                                    sx: {
                                        svg: {
                                            height: importantStyle('22px'),
                                            width: importantStyle('22px'),
                                        },
                                    },
                                    onClick: () => {
                                        if (isWebview()) {
                                            shellTrigger({ processType: ShellProcessTypeEnum.Sidebar, data: null });
                                        } else {
                                            navigate(-1);
                                        }
                                    },
                                }}
                            />
                        </NavItem>
                        <View show={Boolean(searchProps?.show)}>
                            <NavItem design={DesignTypeEnum.Default} py={1} ml="auto" width={importantStyle('326px')}>
                                <Grid>
                                    <GridItem xs>
                                        <Autocomplete<TSearchData>
                                            design={DesignTypeEnum.Default}
                                            control={control}
                                            name="search"
                                            size="small"
                                            disabled={searchProps?.options.data.length === 0}
                                            placeholder={`Search...`}
                                            options={
                                                searchProps?.options ?? {
                                                    data: [] as TSearchData[],
                                                    displayField: '' as keyof TSearchData,
                                                    displayValue: '' as keyof TSearchData,
                                                }
                                            }
                                            popupIcon={<Search />}
                                            disablePopupIconRotate
                                            componentsProps={{
                                                paper: {
                                                    sx: { fontSize: 12 },
                                                },
                                            }}
                                            sx={{
                                                '.MuiAutocomplete-inputRoot': {
                                                    borderTopRightRadius: 0,
                                                    borderBottomRightRadius: 0,
                                                },
                                                fieldset: {
                                                    borderRight: 'none',
                                                },
                                            }}
                                            onKeyPress={(e) => {
                                                if (e.key === KeyboardEventCodeEnum.Enter) {
                                                    handleSubmit(onSubmit)();
                                                }
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem xs={false}>
                                        <Tooltip title={t(locale.buttons.openScreen)}>
                                            <Button
                                                design={DesignTypeEnum.Default}
                                                iconButton
                                                icon={<OpenInBrowser />}
                                                disabled={searchWatch === null}
                                                onClick={handleSubmit(onSubmit)}
                                                sx={{
                                                    borderTopLeftRadius: 0,
                                                    borderBottomLeftRadius: 0,
                                                    p: importantStyle('8.75px'),
                                                    marginTop: '0.5px',
                                                }}
                                            />
                                        </Tooltip>
                                    </GridItem>
                                </Grid>
                            </NavItem>
                        </View>
                    </NavRow>
                </NavContainer>
            </GridItem>
        </Grid>
    );
};

const GridTitle = forwardRef(GridTitleBase) as <TSearchData>(
    props: IGridTitleProps<TSearchData> & { ref?: Ref<any> },
) => ReactElement;
export default GridTitle;
