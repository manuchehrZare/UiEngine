import type { IAutocompleteProps, IGridProps } from 'seker-ui';

export interface ISearchProps<TSearchData> extends Pick<IAutocompleteProps<TSearchData>, 'options'> {
    onOpenScreenClick: (selectedItem: TSearchData) => void;
    show: boolean;
}

export interface IGridTitleProps<TSearchData> extends IGridProps {
    searchProps?: ISearchProps<TSearchData>;
    title: string;
}

export interface ISearchFormValues {
    search: string;
}
