import type { FC } from 'react';
import { memo, useEffect, useState } from 'react';
import type { IButtonGroupProps } from 'seker-ui';
import { Button, ButtonGroup, importantStyle } from 'seker-ui';
import { v4 as uuidv4 } from 'uuid';
import { getSortedAlphabetList } from '../../../../utils/constants/methods/common';

interface IAlphabetButtons extends Pick<IButtonGroupProps, 'className'> {
    alphabets: string[];
    buttonIdFormatter?: (char: string) => string;
    onClick: (data: { char: string; index: number }) => void;
}

const AlphabetButtons: FC<IAlphabetButtons> = ({ alphabets, buttonIdFormatter, className, onClick }) => {
    const [alphabetList, setAlphabetList] = useState<string[]>([]);

    useEffect(() => {
        setAlphabetList(getSortedAlphabetList(alphabets));
    }, [alphabets]);

    return (
        <ButtonGroup className={className} sx={{ display: 'inline-block' }}>
            {alphabetList.map((char, index) => (
                <Button
                    key={uuidv4()}
                    id={buttonIdFormatter ? buttonIdFormatter(char) : char}
                    variant="outlined"
                    color="primary"
                    text={char}
                    sx={{
                        height: 24,
                        width: 24,
                        minWidth: importantStyle('24px'),
                        fontSize: 12,
                        fontWeight: 700,
                        px: '4px',

                        '&.MuiButton-outlinedPrimary': {
                            px: '3px',
                        },

                        '&.active': {
                            border: 'none',
                            backgroundColor: (theme) => theme.palette.secondary.main,
                            color: (theme) => theme.palette.common.white,
                        },
                    }}
                    onClick={() => {
                        onClick && onClick({ char, index });
                    }}
                />
            ))}
        </ButtonGroup>
    );
};

export default memo(AlphabetButtons);
