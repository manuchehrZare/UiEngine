import { groupBy, keys, sortBy, sortedLastIndex, sum, toInteger } from 'lodash';
import type { FC, JSX } from 'react';
import { memo, useEffect, useState } from 'react';
import { Divider, Grid, GridItem, Label, scrollToElement, useMeasure, View } from 'seker-ui';
import type { IMenuItem } from '../../../lib';
import { Layout } from '../../../App';
import { AlphabetButtons, GridTitle, Group, Menu } from '../components';
import { v4 as uuidv4 } from 'uuid';
import { useNavigate } from 'react-router-dom';
import type { LayoutMeasures } from '../../../App/Layout/type';
import { SetMenu } from '../../../App/_root/set-menu';
import { getSortedAlphabetList } from '../../../utils/constants/methods/common';

const MenuList: FC = (): JSX.Element => {
    const gridTitleMeasure = useMeasure();
    const alphabetsMeasure = useMeasure();
    const navigate = useNavigate();
    const lastAlphabetGroupItemMeasure = useMeasure();
    const [menuList, setMenuList] = useState<IMenuItem[]>([]);
    const [layoutMeasures, setLayoutMeasures] = useState<LayoutMeasures | null>(null);
    const [alphabetsScrollTopValuesList, setAlphabetsScrollTopValuesList] = useState<number[]>([]);

    const getGroupId = (char: string) => `group-${char}`;
    const getButtonId = (char: string) => `button-${char}`;
    const getAlphabets = (data: IMenuItem[]) => {
        return getSortedAlphabetList(keys(groupBy(data, (e) => e.menuName[0].toUpperCase())));
    };

    const navigatePage = (item: IMenuItem) => {
        navigate('/nova-ui?screen-code=ADM001', { replace: true });
    };

    const getFlattenMenuList = (menuData: IMenuItem[]): IMenuItem[] => {
        const arr: IMenuItem[] = [];
        menuData.forEach((item) => {
            if (item.children && item.children.length > 0) {
                arr.push(...getFlattenMenuList(item.children));
            } else {
                arr.push(item);
            }
        });
        return arr;
    };

    const getMenuList = (menuData: IMenuItem[], parentItem?: IMenuItem): IMenuItem[] => {
        const arr: IMenuItem[] = [];
        menuData.forEach((item) => {
            if (item.children && item.children.length > 0) {
                item.children = getMenuList(item.children, item);
            }
            // The logout process can be done with the logout button in the sidebar menu.
            if (item?.screenName !== 'BANKING_EXIT') {
                arr.push(item);
            } else if (parentItem && parentItem?.children?.length === 1) {
                // Fake solution for ScreenCodeEnum.Logout control
                parentItem.screenName = 'BANKING_EXIT';
            }
        });
        return arr;
    };

    const setActiveCharButton = (char: string) => {
        const alphabetButtonGroup = document.getElementsByClassName('menu-alphabet-buttons')[0];
        if (alphabetButtonGroup) {
            const alphabetButtons = Array.from(alphabetButtonGroup.getElementsByTagName('button'));
            if (alphabetButtons.length > 0) {
                alphabetButtons.forEach((button) => {
                    if (button.id === getButtonId(char)) {
                        button.classList.add('active');
                    } else {
                        button.classList.remove('active');
                    }
                });
            }
        }
    };

    const getAlphabetsScrollTopValues = () => {
        const arr: number[] = [];
        getAlphabets(menuList).forEach((char: any) => {
            arr.push(
                toInteger(
                    sum([
                        document?.getElementById(getGroupId(char))?.getBoundingClientRect().y,
                        -1 *
                            sum([
                                gridTitleMeasure?.values?.height,
                                alphabetsMeasure?.values?.height,
                                layoutMeasures?.header.height,
                            ]),
                    ]),
                ),
            );
        });
        return arr;
    };

    useEffect(() => {
        setMenuList(getMenuList(SetMenu.data));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (
            menuList.length > 0 &&
            gridTitleMeasure?.values?.height &&
            alphabetsMeasure?.values?.height &&
            alphabetsScrollTopValuesList.length === 0
        ) {
            setAlphabetsScrollTopValuesList(getAlphabetsScrollTopValues());
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [menuList, gridTitleMeasure, alphabetsMeasure, layoutMeasures]);

    useEffect(() => {
        if (menuList.length > 0 && alphabetsScrollTopValuesList.length > 0) {
            setActiveCharButton(getAlphabets(menuList)[0]);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [menuList, alphabetsScrollTopValuesList]);

    return (
        <Layout
            title="Menu"
            onMeasureChange={(measures) => setLayoutMeasures(measures)}
            onContentScrollChange={(scrollValues) => {
                const arr = sortBy([...alphabetsScrollTopValuesList, scrollValues.scrollTop]);
                const char = getAlphabets(menuList)[sortedLastIndex(arr, scrollValues.scrollTop) - 2];
                setActiveCharButton(char);
            }}>
            <GridTitle
                ref={gridTitleMeasure.ref}
                title="Menu List"
                searchProps={{
                    show: true,
                    options: {
                        data:
                            menuList.length > 0
                                ? getFlattenMenuList(menuList).map((item) => ({
                                      ...item,
                                      tmpDisplayField: `${item?.menuName}${
                                          item?.screenCode ? ` (${item?.screenCode})` : ''
                                      }`,
                                      tmpDisplayValue: `${item?.menuName}${
                                          item?.screenCode ? ` (${item?.screenCode})` : ''
                                      }`,
                                  }))
                                : [],
                        displayField: 'tmpDisplayField',
                        displayValue: 'tmpDisplayValue',
                    },
                    onOpenScreenClick: (selectedItem) => {
                        menuList.length > 0 &&
                            (() => {
                                const foundItem = getFlattenMenuList(menuList).find(
                                    (item) =>
                                        selectedItem.menuName.includes(item.menuName) &&
                                        item.screenCode === selectedItem.screenCode &&
                                        item.screenName === selectedItem.screenName &&
                                        item.menuKey === selectedItem.menuKey,
                                );
                                if (foundItem) {
                                    navigatePage(foundItem);
                                }
                            })();
                    },
                }}
            />
            <View show>
                <Grid
                    ref={alphabetsMeasure.ref}
                    position="sticky"
                    top={gridTitleMeasure.values.height}
                    bgcolor={(theme) => theme.palette.common.white}
                    zIndex={(theme) => theme.zIndex.appBar}>
                    <GridItem textAlign="center" py={2}>
                        <AlphabetButtons
                            className="menu-alphabet-buttons"
                            alphabets={getAlphabets(menuList)}
                            buttonIdFormatter={getButtonId}
                            onClick={({ char }) => {
                                scrollToElement(getGroupId(char));
                            }}
                        />
                    </GridItem>
                    <GridItem>
                        <Divider />
                    </GridItem>
                </Grid>
                <Grid
                    mb={`calc(100vh - ${sum([
                        gridTitleMeasure?.values.height,
                        alphabetsMeasure?.values.height,
                        layoutMeasures?.footer.height,
                        layoutMeasures?.header.height,
                        lastAlphabetGroupItemMeasure?.values.height,
                    ])}px)`}>
                    {getAlphabets(menuList).map((char: any, index: any) => {
                        return (
                            <GridItem
                                key={uuidv4()}
                                {...(index === getAlphabets(menuList).length - 1 && {
                                    ref: lastAlphabetGroupItemMeasure.ref,
                                })}
                                sx={{
                                    scrollMarginTop: `${sum([
                                        gridTitleMeasure.values.height,
                                        alphabetsMeasure.values.height,
                                    ])}px`,
                                }}
                                position="relative"
                                id={getGroupId(char)}>
                                <Group title={char}>
                                    <Menu
                                        data={groupBy(menuList, (e) => e.menuName[0].toUpperCase())[char]}
                                        onClick={(item) => {
                                            navigatePage(item);
                                        }}
                                    />
                                </Group>
                                <View show={index !== getAlphabets(menuList).length - 1}>
                                    <Divider />
                                </View>
                            </GridItem>
                        );
                    })}
                </Grid>
            </View>
            <View show={Boolean(menuList.length === 0)}>
                <Grid p={2} spacing={1}>
                    <GridItem>
                        <Label text="" align="center" color={(theme) => theme.palette.error.main} />
                    </GridItem>
                </Grid>
            </View>
        </Layout>
    );
};

export default memo(MenuList);
