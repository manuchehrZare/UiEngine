import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../../App';
import { DmsDocumentViewer } from '../../../../lib';

const DmsDocumentViewerPage: FC = (): JSX.Element => {
    const htmlPayloadData = {
        docVersion: '',
        docVersionPiid: '',
        docHttpUrl: '/slide/files/Ortak/ekstreler/136/2011/01/03/1_13600011_2011-01-03.html',
        piid: '',
        restrictionNeeded: '0',
    };

    const pdfPayloadData = {
        docVersion: '',
        docVersionPiid: '',
        docHttpUrl: '{A0F4A38B-0000-CB2E-B04C-4DB6F2D24D91}',
        piid: '',
        restrictionNeeded: '0',
    };

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'DmsDocumentViewer - HTML' }} />
                        <Box pt={0.5}>
                            <DmsDocumentViewer payloadData={htmlPayloadData} />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'DmsDocumentViewer - PDF' }} />
                        <Box pt={0.5}>
                            <DmsDocumentViewer payloadData={pdfPayloadData} />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};
export default DmsDocumentViewerPage;
