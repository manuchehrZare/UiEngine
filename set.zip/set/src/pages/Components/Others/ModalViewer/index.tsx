import type { FC } from 'react';
import { Button, Grid, GridItem, Nav, Paper, Select, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../App';
import type { SETModalsType } from '../../../../lib';
import { ModalViewer, SETModalsEnum } from '../../../../lib';

interface IFormValues {
    customerInquiryModalInput: string;
    modalViewerCardNumberInput: number | null;
    modalViewerInput: string;
    SETModalSelect: SETModalsType;
}

const ModalViewerPage: FC = () => {
    const { control, setValue, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            customerInquiryModalInput: '',
            modalViewerCardNumberInput: null,
            modalViewerInput: '',
            SETModalSelect: SETModalsEnum.UserInquiryModal,
        },
    });
    const [SETModalSelectWatch, modalViewerInputWatch, customerInquiryModalInputWatch] = useWatch({
        control,
        fieldName: ['SETModalSelect', 'modalViewerInput', 'customerInquiryModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('SETModalSelectWatch', SETModalSelectWatch);
    // eslint-disable-next-line no-console
    console.log('modalViewerInputWatch', modalViewerInputWatch);
    // eslint-disable-next-line no-console
    console.log('customerInquiryModalInputWatch', customerInquiryModalInputWatch);

    const SETModalList =
        Object.keys(SETModalsEnum).length > 0
            ? Object.keys(SETModalsEnum).map((item) => ({
                  name: item,
              }))
            : [];

    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('ModalViewer - formData :', formData);
    };

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Grid spacingType="button">
                        <GridItem xs="auto">
                            <Button text="Send" onClick={handleSubmit(onSubmit)} />
                        </GridItem>
                        <GridItem xs="auto">
                            <Button
                                text="Reset"
                                onClick={() => {
                                    reset();
                                }}
                            />
                        </GridItem>
                    </Grid>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <Select
                                    control={control}
                                    name="SETModalSelect"
                                    label="SETModalSelect"
                                    setValue={setValue}
                                    options={{
                                        data: SETModalList,
                                        displayField: 'name',
                                        displayValue: 'name',
                                    }}
                                />
                            </GridItem>
                            <GridItem>
                                {/* <ModalViewer<SETModalsEnum.UserInquiryModal> */}
                                <ModalViewer<typeof SETModalSelectWatch>
                                    component="NumberInput"
                                    // modalComponent={SETModalsEnum.UserInquiryModal}
                                    modalComponent={SETModalSelectWatch}
                                    control={control}
                                    name="modalViewerInput"
                                    label="Modal Viewer Input"
                                    adornmentButtonProps={{
                                        disabled: false,
                                        // show: false,
                                        tooltip: SETModalSelectWatch,
                                    }}
                                    modalProps={{
                                        onClose: (modalShow: boolean) => {
                                            // eslint-disable-next-line no-console
                                            console.log('onClose', modalShow);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - With CardNumber Component' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.CardInquiryModal>
                                    component="CardNumber"
                                    modalComponent={SETModalsEnum.CardInquiryModal}
                                    control={control}
                                    name="modalViewerCardNumberInput"
                                    label="Modal Viewer CardNumber Input"
                                    adornmentButtonProps={{
                                        tooltip: 'Kart Sorgulama',
                                    }}
                                    modalProps={{
                                        onReturnData: (returnData) => {
                                            setValue('modalViewerCardNumberInput', Number(returnData?.accountNo));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ModalViewerPage;
