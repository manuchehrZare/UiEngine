import type { FC } from 'react';
import { Children } from 'react';
import { Button, DesignTypeEnum, Grid, GridItem, Paper } from 'seker-ui';
import { ClosePageButton, Footer, MenuButton, Layout as SETLayout } from '../../../../lib';
import { useTranslation } from '../../../../lib/utils';
import { Layout } from '../../../../App';
import { v4 as uuidv4 } from 'uuid';

const FooterPage: FC = () => {
    const { t, locale } = useTranslation();

    return (
        <Layout>
            <Grid px={1}>
                <GridItem>
                    <SETLayout>
                        <Grid spacingType="common">
                            {Children.toArray(
                                [0, 1, 2, 3, 4, 5].map(() => (
                                    <GridItem key={uuidv4()}>
                                        <Paper>
                                            <Grid>
                                                <GridItem>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate
                                                    voluptatum earum autem, excepturi, velit voluptates fugit, officia
                                                    provident nemo error debitis itaque dolorem mollitia eveniet quam
                                                    vitae sed quia nobis? Expedita soluta enim, pariatur rem consequatur
                                                    in eveniet tenetur fuga minima harum doloremque iste, fugiat
                                                    cupiditate eius deserunt, consectetur veritatis labore officiis?
                                                    Quam consequatur nemo commodi illum nesciunt mollitia saepe.
                                                    Explicabo dolores vel harum rerum ea iusto illum ipsum obcaecati ex,
                                                    labore placeat numquam animi exercitationem itaque repudiandae
                                                    praesentium. Tenetur et praesentium eligendi officia incidunt
                                                    voluptatibus. Explicabo ipsa reiciendis esse! Cum suscipit atque
                                                    quidem dolore exercitationem deserunt mollitia nam ducimus, quod ea
                                                    error saepe cupiditate beatae sapiente corporis dolores quaerat nisi
                                                    officia est. Quam ratione laboriosam non accusantium dolor! Minima.
                                                    Deserunt officia ullam dolor doloribus magni itaque molestias
                                                    perferendis quas nobis. Provident inventore a at perspiciatis fuga
                                                    explicabo necessitatibus dignissimos rem. Incidunt commodi labore
                                                    error eligendi est dicta at ut?
                                                </GridItem>
                                            </Grid>
                                        </Paper>
                                    </GridItem>
                                )),
                            )}
                        </Grid>
                        <Footer>
                            <Grid spacingType="button">
                                <GridItem xs sm="auto">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        text={t(locale.buttons.save)}
                                        fullWidth
                                        disabled
                                    />
                                </GridItem>
                                <GridItem xs sm="auto">
                                    <Button
                                        design={DesignTypeEnum.SET}
                                        text={t(locale.buttons.cleanUp)}
                                        variant="outlined"
                                        fullWidth
                                    />
                                </GridItem>
                                <GridItem xs sm="auto" ml={{ md: 'auto' }}>
                                    <ClosePageButton fullWidth />
                                </GridItem>
                                <GridItem xs sm="auto">
                                    <MenuButton link="#" fullWidth />
                                </GridItem>
                            </Grid>
                        </Footer>
                    </SETLayout>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default FooterPage;
