import type { FC } from 'react';
import { Button, Grid, GridItem } from 'seker-ui';
import { Layout } from '../../../../../App';
import { Logout, useTranslation } from '../../../../../lib';

const LogoutPage: FC = () => {
    const { t, locale } = useTranslation();

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Logout
                        component={<Button text={t(locale.buttons.logout)} />}
                        logoutConfirmModalProps={{
                            onClose: () => {
                                // eslint-disable-next-line no-console
                                console.log('onClose');
                            },
                            onConfirm: (status) => {
                                // eslint-disable-next-line no-console
                                console.log('onConfirm', status);
                            },
                        }}
                    />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default LogoutPage;
