import type { FC } from 'react';
import { Grid, GridItem, message, setSessionStorageItem } from 'seker-ui';
import { Layout } from '../../../../../App';
import { Login, constants } from '../../../../../lib';
import { ReactComponent as Logo } from '../../../../../assets/images/logo_mini_lightgreen.svg';

const LoginPage: FC = () => {
    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Login
                        logo={<Logo height="100%" width="100%" />}
                        // formProps={{ defaultValues: { password: 'Alfa1111' } }}
                        navigateProps={{
                            routes: {
                                home: '#',
                            },
                        }}
                        gridProps={{ height: window.innerHeight - 80 }}
                        onSetAuth={(data) => {
                            // eslint-disable-next-line no-console
                            console.log('setAuthData', data);
                            setSessionStorageItem(constants.key.SET_AUTH, data);
                            message({ variant: 'success', message: 'setAuthData' });
                        }}
                        onResetAuth={() => {
                            // eslint-disable-next-line no-console
                            console.log('resetStoreAuth');
                            message({ variant: 'error', message: 'resetStoreAuth' });
                        }}
                        onResetQuery={() => {
                            // eslint-disable-next-line no-console
                            console.log('resetStoreQuery');
                            message({ variant: 'info', message: 'resetStoreQuery' });
                        }}
                        onNavigate={(route) => {
                            // eslint-disable-next-line no-console
                            console.log('navigate', route);
                            message({ variant: 'info', message: `navigate : ${route}` });
                        }}
                    />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default LoginPage;
