import type { FC } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Label } from 'seker-ui';
import { Layout } from '../../../../../App';
import { NotFound, useTranslation, Layout as SETLayout } from '../../../../../lib';

const NotFoundPage: FC = () => {
    const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
    const { t, locale } = useTranslation();

    return (
        <Layout>
            <Grid mb={1} spacingType="common" alignItems="center">
                <GridItem xs={false}>
                    <Button
                        text={isLoggedIn ? t(locale.buttons.logout) : t(locale.buttons.login)}
                        onClick={() => setIsLoggedIn(!isLoggedIn)}
                    />
                </GridItem>
                <GridItem xs={false}>
                    <Label text={`isLoggedIn : ${isLoggedIn}`} />
                </GridItem>
            </Grid>
            <SETLayout>
                <NotFound
                    // text="Bulunamadı!"
                    isLoggedIn={isLoggedIn}
                    loginLink=""
                    // labelProps={{ align: 'left' }}
                    menuButtonProps={{
                        link: '/',
                        // text: 'Menü Listesine Dön',
                    }}
                    // previousButtonProps={{ text: 'Önceki' }}
                />
            </SETLayout>
        </Layout>
    );
};

export default NotFoundPage;
