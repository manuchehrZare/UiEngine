import { PowerSettingsNew } from '@mui/icons-material';
import type { FC } from 'react';
import { useState } from 'react';
import { Grid, GridItem } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { CloseAppButton } from '../../../../../../lib';

const CloseAppButtonPage: FC = () => {
    const [closeAppConfirmModalShow, setCloseAppConfirmModalShow] = useState<boolean>(false);
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <CloseAppButton
                        // text="Close"
                        iconLeft={<PowerSettingsNew />}
                        onClick={() => {
                            setCloseAppConfirmModalShow(true);
                        }}
                        closeAppConfirmModalProps={{
                            show: closeAppConfirmModalShow,
                            onClose: () => {
                                !closeAppConfirmModalShow && setCloseAppConfirmModalShow(false);
                                // eslint-disable-next-line no-console
                                console.log('onClose');
                            },
                            onConfirm: (status) => {
                                // eslint-disable-next-line no-console
                                console.log('onConfirm', status);
                                setCloseAppConfirmModalShow(false);
                            },
                        }}
                    />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CloseAppButtonPage;
