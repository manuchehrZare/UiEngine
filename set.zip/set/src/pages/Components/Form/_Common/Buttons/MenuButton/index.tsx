import type { FC } from 'react';
import { Grid, GridItem } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { MenuButton } from '../../../../../../lib';

const MenuButtonPage: FC = () => {
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <MenuButton link="#" />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default MenuButtonPage;
