import type { FC } from 'react';
import { useState } from 'react';
import { Grid, GridItem, Input, Label, MessageTypeEnum, Paper, message, useForm, validation } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { HttpStatusCodeEnum, SaveButton, useAxios } from '../../../../../../lib';

const SaveButtonPage: FC = () => {
    const [confirmModalShow, setConfirmModalShow] = useState<boolean>(false);

    const { handleSubmit, control } = useForm({
        defaultValues: {
            name: '',
        },
        validationSchema: {
            name: validation.string('name', { required: true }),
        },
    });

    const [, postsRequest] = useAxios(
        {
            url: 'https://jsonplaceholder.typicode.com/posts?userId=1',
        },
        { manual: true },
    );

    const onSubmit = () => {
        setConfirmModalShow(true);
    };

    return (
        <Layout>
            <Paper>
                <Grid spacingType="common">
                    <GridItem xs={4}>
                        <Label text="Default" />
                        <Grid>
                            <GridItem>
                                <SaveButton />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem xs={4}>
                        <Label text="Confirm Modal" />
                        <Grid>
                            <GridItem>
                                <SaveButton enableConfirm />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem xs={4}>
                        <Label text="Confirm Modal Show" />
                        <Grid spacingType="common">
                            <GridItem>
                                <Input control={control} name="name" label="Name" />
                            </GridItem>
                            <GridItem>
                                <SaveButton
                                    onClick={() => handleSubmit(onSubmit)()}
                                    enableConfirm
                                    confirmModalProps={{
                                        show: confirmModalShow,
                                        onClose: () => {
                                            setConfirmModalShow(false);
                                        },
                                        onConfirm: async (status) => {
                                            if (status) {
                                                const response = await postsRequest();
                                                if (response.status === HttpStatusCodeEnum.Ok) {
                                                    message({ variant: MessageTypeEnum.success, message: 'Success' });
                                                }
                                            }
                                            setConfirmModalShow(false);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                </Grid>
            </Paper>
        </Layout>
    );
};

export default SaveButtonPage;
