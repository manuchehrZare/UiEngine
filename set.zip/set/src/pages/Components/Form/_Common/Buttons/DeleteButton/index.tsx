import type { FC } from 'react';
import { useState } from 'react';
import { Grid, GridItem, Label, Paper } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { DeleteButton } from '../../../../../../lib';
import DeleteOutline from '@mui/icons-material/DeleteOutline';

const DeleteButtonPage: FC = () => {
    const [confirmModalShow, setConfirmModalShow] = useState(false);
    return (
        <Layout>
            <Paper>
                <Grid spacingType="common">
                    <GridItem xs={4}>
                        <Label text="Default" />
                        <Grid>
                            <GridItem>
                                <DeleteButton
                                    confirmModalProps={{
                                        onConfirm: (status) => {
                                            // eslint-disable-next-line no-console
                                            console.log('onConfirm', status);
                                        },
                                        onClose: () => {
                                            // eslint-disable-next-line no-console
                                            console.log('onClose');
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem xs={4}>
                        <Label text="With Icon" />
                        <Grid>
                            <GridItem>
                                <DeleteButton
                                    confirmModalProps={{
                                        onConfirm: (status) => {
                                            // eslint-disable-next-line no-console
                                            console.log('onConfirm', status);
                                        },
                                    }}
                                    iconLeft={<DeleteOutline />}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem xs={4}>
                        <Label text="IconButton" />
                        <Grid>
                            <GridItem>
                                <DeleteButton
                                    confirmModalProps={{
                                        show: confirmModalShow,
                                        onClose: () => {
                                            setConfirmModalShow(false);
                                        },
                                        onConfirm: (status) => {
                                            // eslint-disable-next-line no-console
                                            console.log('onConfirm', status);
                                            setConfirmModalShow(false);
                                        },
                                    }}
                                    onClick={() => {
                                        setConfirmModalShow(true);
                                    }}
                                    iconButton
                                    icon={<DeleteOutline />}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                </Grid>
            </Paper>
        </Layout>
    );
};

export default DeleteButtonPage;
