import type { FC } from 'react';
import { Grid, GridItem } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ClosePageButton } from '../../../../../../lib';

const ClosePageButtonPage: FC = () => {
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <ClosePageButton
                        // text="Close"
                        // link="#"
                        onClick={() => {
                            // eslint-disable-next-line no-console
                            console.log('onClick');
                        }}
                        closePageConfirmModalProps={{
                            onClose: () => {
                                // eslint-disable-next-line no-console
                                console.log('onClose');
                            },
                            onConfirm: (status) => {
                                // eslint-disable-next-line no-console
                                console.log('onConfirm', status);
                            },
                        }}
                    />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ClosePageButtonPage;
