import type { FC } from 'react';
import { Layout } from '../../../../../../App';
import { RegistryNoInput } from '../../../../../../lib';
import { Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';

interface IFormValues {
    registryNoInput: string;
}

const RegistryNoInputPage: FC = () => {
    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            registryNoInput: '',
        },
    });
    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('formData', formData);
    };
    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'RegistryNoInput' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <RegistryNoInput name="registryNoInput" control={control} label="Registry No" />
                            </GridItem>
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem xs="auto">
                                        <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                                    </GridItem>
                                    <GridItem xs="auto">
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default RegistryNoInputPage;
