import type { FC } from 'react';
import { Layout } from '../../../../../../App';
import { PasswordInput } from '../../../../../../lib';
import { Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';

interface IFormValues {
    passwordInput: string;
}

const PasswordInputPage: FC = () => {
    const { control, handleSubmit, reset } = useForm<IFormValues>({
        defaultValues: {
            passwordInput: '',
        },
    });
    const onSubmit = (formData: IFormValues) => {
        // eslint-disable-next-line no-console
        console.log('formData', formData);
    };
    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PasswordInput' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <PasswordInput name="passwordInput" control={control} label="Password" />
                            </GridItem>
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem xs="auto">
                                        <Button text="Submit" onClick={handleSubmit(onSubmit)} />
                                    </GridItem>
                                    <GridItem xs="auto">
                                        <Button text="Reset" onClick={() => reset()} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default PasswordInputPage;
