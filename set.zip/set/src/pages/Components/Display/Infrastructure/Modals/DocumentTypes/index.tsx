import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../../../App';
import { DocumentTypesModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';

const DocumentTypesPage: FC = (): JSX.Element => {
    const [documentTypesModalShow, setDocumentTypesModalShow] = useState<boolean>(false);
    const [eventOwnerEl, setEventOwnerEl] = useState<'input' | 'button'>();

    const { control, setValue } = useForm({
        defaultValues: {
            documentTypesInput: '',
        },
    });

    return (
        <>
            <Layout>
                <Grid spacingType="common">
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav navTitleProps={{ title: 'DocumentTypesModal eventOwnerEl="input"' }} />
                                <Button
                                    text="Open DocumentTypesModal"
                                    fullWidth
                                    onClick={() => {
                                        setDocumentTypesModalShow(true);
                                        setEventOwnerEl('input');
                                    }}
                                />
                            </Box>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav
                                    navTitleProps={{
                                        title: 'DocumentTypesModal eventOwnerEl="button"',
                                    }}
                                />
                                <Button
                                    text="Open DocumentTypesModal"
                                    fullWidth
                                    onClick={() => {
                                        setDocumentTypesModalShow(true);
                                        setEventOwnerEl('button');
                                    }}
                                />
                            </Box>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'DocumentTypesModal - ModalViewer' }} />
                            <Grid spacingType="form">
                                <GridItem>
                                    <ModalViewer<SETModalsEnum.DocumentTypesModal>
                                        component="Input"
                                        modalComponent={SETModalsEnum.DocumentTypesModal}
                                        control={control}
                                        name="documentTypesInput"
                                        label={SETModalsEnum.DocumentTypesModal}
                                        adornmentButtonProps={{
                                            tooltip: SETModalsEnum.DocumentTypesModal,
                                        }}
                                        modalProps={{
                                            formData: {},
                                            onReturnData: (data: any) => {
                                                setValue('documentTypesInput', data?.itemType);
                                                // eslint-disable-next-line no-console
                                                console.log('DocumentTypes---onReturnData', data);
                                            },
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </Layout>
            <DocumentTypesModal
                show={documentTypesModalShow}
                onClose={setDocumentTypesModalShow}
                eventOwnerEl={eventOwnerEl}
            />
        </>
    );
};

export default DocumentTypesPage;
