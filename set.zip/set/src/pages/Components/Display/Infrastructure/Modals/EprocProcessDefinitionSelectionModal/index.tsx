import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ModalViewer, SETModalsEnum, EprocProcessDefinitionSelectionModal } from '../../../../../../lib';

interface IFormValues {
    eprocProcessDefinitionSelectionModalInput: string;
}

const EprocProcessDefinitionSelectionModalPage: FC = (): JSX.Element => {
    const [eprocProcessDefinitionSelectionModalOpen, setEprocProcessDefinitionSelectionModalOpen] =
        useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            eprocProcessDefinitionSelectionModalInput: '',
        },
    });
    const [eprocProcessDefinitionSelectionModalInputWatch] = useWatch({
        control,
        fieldName: ['eprocProcessDefinitionSelectionModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('eprocProcessDefinitionSelectionModalInputWatch', eprocProcessDefinitionSelectionModalInputWatch);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav
                                navTitleProps={{ title: 'EprocProcessDefinitionSelectionModal eventOwnerEl="input"' }}
                            />
                            <Button
                                text="Open EprocProcessDefinitionSelectionModal"
                                onClick={() => {
                                    setEprocProcessDefinitionSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav
                                navTitleProps={{ title: 'EprocProcessDefinitionSelectionModal eventOwnerEl="button"' }}
                            />
                            <Button
                                text="Open EprocProcessDefinitionSelectionModal"
                                onClick={() => {
                                    setEprocProcessDefinitionSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'EprocProcessDefinitionSelectionModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.EprocProcessDefinitionSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.EprocProcessDefinitionSelectionModal}
                                    control={control}
                                    name="eprocProcessDefinitionSelectionModalInput"
                                    label={SETModalsEnum.EprocProcessDefinitionSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.EprocProcessDefinitionSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('EprocProcessDefinitionSelectionModal---onReturnData', data);
                                            setValue(
                                                'eprocProcessDefinitionSelectionModalInput',
                                                String(data.eprocProcessId),
                                            );
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <EprocProcessDefinitionSelectionModal
                show={eprocProcessDefinitionSelectionModalOpen}
                onClose={setEprocProcessDefinitionSelectionModalOpen}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('EprocProcessDefinitionSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default EprocProcessDefinitionSelectionModalPage;
