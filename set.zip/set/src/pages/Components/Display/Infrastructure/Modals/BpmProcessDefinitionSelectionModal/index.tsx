import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ModalViewer, BpmProcessDefinitionSelectionModal, SETModalsEnum } from '../../../../../../lib';

interface IFormValues {
    bpmProcessDefinitionSelectionModalInput: string;
}

const BpmProcessDefinitionSelectionModalPage: FC = (): JSX.Element => {
    const [bpmProcessDefinitionSelectionModalOpen, setBpmProcessDefinitionSelectionModalOpen] =
        useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            bpmProcessDefinitionSelectionModalInput: '',
        },
    });
    const [bpmProcessDefinitionSelectionModalInputWatch] = useWatch({
        control,
        fieldName: ['bpmProcessDefinitionSelectionModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('bpmProcessDefinitionSelectionModalInputWatch', bpmProcessDefinitionSelectionModalInputWatch);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'BpmProcessDefinitionSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open BpmProcessDefinitionSelectionModal"
                                onClick={() => {
                                    setBpmProcessDefinitionSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav
                                navTitleProps={{ title: 'BpmProcessDefinitionSelectionModal eventOwnerEl="button"' }}
                            />
                            <Button
                                text="Open BpmProcessDefinitionSelectionModal"
                                onClick={() => {
                                    setBpmProcessDefinitionSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'BpmProcessDefinitionSelectionModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.BpmProcessDefinitionSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.BpmProcessDefinitionSelectionModal}
                                    control={control}
                                    name="bpmProcessDefinitionSelectionModalInput"
                                    label={SETModalsEnum.BpmProcessDefinitionSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.BpmProcessDefinitionSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('BpmProcessDefinitionSelectionModal---onReturnData', data);
                                            setValue(
                                                'bpmProcessDefinitionSelectionModalInput',
                                                String(data.processDefinitionName),
                                            );
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <BpmProcessDefinitionSelectionModal
                show={bpmProcessDefinitionSelectionModalOpen}
                onClose={setBpmProcessDefinitionSelectionModalOpen}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BpmProcessDefinitionSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default BpmProcessDefinitionSelectionModalPage;
