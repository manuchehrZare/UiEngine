import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ModalViewer, SETModalsEnum, EprocProcessSelectionModal } from '../../../../../../lib';

interface IFormValues {
    eprocProcessSelectionModalInput: string;
}

const EprocProcessSelectionModalPage: FC = (): JSX.Element => {
    const [eprocProcessSelectionModalOpen, setEprocProcessSelectionModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            eprocProcessSelectionModalInput: '',
        },
    });
    const [eprocProcessSelectionModalInputWatch] = useWatch({
        control,
        fieldName: ['eprocProcessSelectionModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('eprocProcessSelectionModalInputWatch', eprocProcessSelectionModalInputWatch);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'EprocProcessSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open EprocProcessSelectionModal"
                                onClick={() => {
                                    setEprocProcessSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'EprocProcessSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open EprocProcessSelectionModal"
                                onClick={() => {
                                    setEprocProcessSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'EprocProcessSelectionModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.EprocProcessSelectionModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.EprocProcessSelectionModal}
                                    control={control}
                                    name="eprocProcessSelectionModalInput"
                                    label={SETModalsEnum.EprocProcessSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.EprocProcessSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('BpmProcessSelectionModal---onReturnData', data);
                                            setValue('eprocProcessSelectionModalInput', String(data?.referenceId));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <EprocProcessSelectionModal
                show={eprocProcessSelectionModalOpen}
                onClose={setEprocProcessSelectionModalOpen}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BpmProcessSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default EprocProcessSelectionModalPage;
