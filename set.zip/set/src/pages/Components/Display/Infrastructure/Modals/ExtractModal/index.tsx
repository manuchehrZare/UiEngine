import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, Select, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ExtractModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

const ExtractModalPage: FC = (): JSX.Element => {
    const [showModal, setShowModal] = useState<boolean>(false);
    const { control, setValue } = useForm({ defaultValues: { bankStatementOid: '', bankStatementOidModalViewer: '' } });
    const [bankStatementOidVal, bankStatementOidModalViewerVal] = useWatch({
        control,
        fieldName: ['bankStatementOid', 'bankStatementOidModalViewer'],
    });

    return (
        <>
            <Layout>
                <Grid spacingType="common">
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav navTitleProps={{ title: 'Extract Modal' }} />
                                <Grid spacingType="common">
                                    <GridItem xs={6}>
                                        <Select
                                            name="bankStatementOid"
                                            control={control}
                                            setValue={setValue}
                                            options={{
                                                data: [
                                                    { name: 'PDF EXTRACT', value: '6e1jt5lomp748k00' },
                                                    { name: 'HTML EXTRACT', value: '3r11kkk4ds5yiv00' },
                                                ],
                                                displayField: 'name',
                                                displayValue: 'value',
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <Button text="Open ExtractModal" onClick={() => setShowModal(true)} />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav navTitleProps={{ title: 'Extract Modal With ModalViewer' }} />
                                <Grid spacingType="common">
                                    <GridItem xs={6}>
                                        <Select
                                            name="bankStatementOidModalViewer"
                                            control={control}
                                            setValue={setValue}
                                            options={{
                                                data: [
                                                    { name: 'PDF EXTRACT', value: '6e1jt5lomp748k00' },
                                                    { name: 'PDF2 EXTRACT', value: '6e0uc7lpi85k5600' },
                                                    { name: 'PDF3 EXTRACT', value: '6d0feylp8dhpxz00' },
                                                    { name: 'HTML EXTRACT', value: '3r11kkk4ds5yiv00' },
                                                    { name: 'HTML2 EXTRACT', value: '6d1zmbl8359r1b00' },
                                                    { name: 'HTML3 EXTRACT', value: '6e0v5gl835k4ho00' },
                                                    { name: 'HTML4 EXTRACT', value: '7205vsh7lxt6op00' },
                                                    { name: 'HTML5 EXTRACT', value: '3s0129k6vw94pt00' },
                                                    { name: 'HTML6 EXTRACT', value: '3r11kkk4ds5yiv00' },
                                                    { name: 'HTML7 EXTRACT', value: '21070wjvdomxx300' },
                                                    { name: 'HTML8 EXTRACT', value: '3s1d11k35xat8400' },
                                                    { name: 'HTML9 EXTRACT', value: '3s1d11k35xazce00' },
                                                    { name: 'HTML10 EXTRACT', value: '3r1ecck35xb54p00' },
                                                ],
                                                displayField: 'name',
                                                displayValue: 'value',
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <ModalViewer<SETModalsEnum.ExtractModal>
                                            component="Button"
                                            modalComponent={SETModalsEnum.ExtractModal}
                                            modalProps={{ bankStatementOid: bankStatementOidModalViewerVal }}
                                            text="Extract Modal With ModalViewer"
                                        />
                                    </GridItem>
                                </Grid>
                            </Box>
                        </Paper>
                    </GridItem>
                </Grid>
            </Layout>
            <ExtractModal show={showModal} onClose={setShowModal} bankStatementOid={bankStatementOidVal} />
        </>
    );
};
export default ExtractModalPage;
