import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ModalViewer, SETModalsEnum, BpmProcessSelectionModal } from '../../../../../../lib';

interface IFormValues {
    bpmProcessSelectionModalInput: string;
}

const BpmProcessSelectionModalPage: FC = (): JSX.Element => {
    const [bpmProcessSelectionModalOpen, setBpmProcessSelectionModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            bpmProcessSelectionModalInput: '',
        },
    });
    const [bpmProcessSelectionModalInputWatch] = useWatch({
        control,
        fieldName: ['bpmProcessSelectionModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('bpmProcessSelectionModalInputWatch', bpmProcessSelectionModalInputWatch);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'BpmProcessSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open BpmProcessSelectionModal"
                                onClick={() => {
                                    setBpmProcessSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'BpmProcessSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open BpmProcessSelectionModal"
                                onClick={() => {
                                    setBpmProcessSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'BpmProcessSelectionModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.BpmProcessSelectionModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.BpmProcessSelectionModal}
                                    control={control}
                                    name="bpmProcessSelectionModalInput"
                                    label={SETModalsEnum.BpmProcessSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.BpmProcessSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('BpmProcessSelectionModal---onReturnData', data);
                                            setValue('bpmProcessSelectionModalInput', String(data?.referenceId));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <BpmProcessSelectionModal
                show={bpmProcessSelectionModalOpen}
                onClose={setBpmProcessSelectionModalOpen}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BpmProcessSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default BpmProcessSelectionModalPage;
