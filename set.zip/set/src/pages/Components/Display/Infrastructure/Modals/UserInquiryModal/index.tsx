import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ModalViewer, SETModalsEnum, UserInquiryModal } from '../../../../../../lib';

interface IFormValues {
    userInquiryModalInput: string;
}

const UserInquiryModalPage: FC = (): JSX.Element => {
    const [userInquiryModalOpen, setUserInquiryModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            userInquiryModalInput: '',
        },
    });
    const [userInquiryModalInputWatch] = useWatch({
        control,
        fieldName: ['userInquiryModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('userInquiryModalInputWatch', userInquiryModalInputWatch);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'UserInquiryModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open UserInquiryModal"
                                onClick={() => {
                                    setUserInquiryModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'UserInquiryModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open UserInquiryModal"
                                onClick={() => {
                                    setUserInquiryModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'UserInquiryModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.UserInquiryModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.UserInquiryModal}
                                    control={control}
                                    name="userInquiryModalInput"
                                    label={SETModalsEnum.UserInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.UserInquiryModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('UserInquiryModal---onReturnData', data);
                                            setValue('userInquiryModalInput', String(data?.userName));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <UserInquiryModal
                show={userInquiryModalOpen}
                onClose={setUserInquiryModalOpen}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BpmProcessSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default UserInquiryModalPage;
