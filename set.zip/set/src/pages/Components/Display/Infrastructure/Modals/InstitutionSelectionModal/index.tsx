import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { InstitutionSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../lib';

interface IFormValues {
    institutionSelectionModalInput: string;
}

const InstitutionSelectionModalPage: FC = (): JSX.Element => {
    const [institutionSelectionModalOpen, setInstitutionSelectionModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            institutionSelectionModalInput: '',
        },
    });

    const institutionSelectionModalInputVal = useWatch({
        control,
        fieldName: 'institutionSelectionModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'InstitutionSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open InstitutionSelectionModal"
                                onClick={() => {
                                    setInstitutionSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'InstitutionSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open InstitutionSelectionModal"
                                onClick={() => {
                                    setInstitutionSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.InstitutionSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.InstitutionSelectionModal}
                                    control={control}
                                    name="institutionSelectionModalInput"
                                    label={SETModalsEnum.InstitutionSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.InstitutionSelectionModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            title: institutionSelectionModalInputVal,
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('InstitutionSelectionModal---onReturnData', data);
                                            setValue('institutionSelectionModalInput', data.title);
                                        },
                                    }}
                                    sx={{
                                        input: {
                                            textTransform: 'uppercase',
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.InstitutionSelectionModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.InstitutionSelectionModal}
                                    name="institutionSelectionModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.InstitutionSelectionModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.InstitutionSelectionModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            title: institutionSelectionModalInputVal,
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('InstitutionSelectionModal---onReturnData', data);
                                            setValue('institutionSelectionModalInput', data.title);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <InstitutionSelectionModal
                show={institutionSelectionModalOpen}
                onClose={setInstitutionSelectionModalOpen}
                formData={{
                    title: institutionSelectionModalInputVal,
                    functionOid: '1234567890123469',
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('Files onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default InstitutionSelectionModalPage;
