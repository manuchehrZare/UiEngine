import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../../../App';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { ModalViewer, SETModalsEnum, UnitInquiryModal } from '../../../../../../lib';

const UnitInquiryPage: FC = (): JSX.Element => {
    const [openUnitInquiryModal, setOpenUnitInquiryModal] = useState<boolean>(false);
    const [eventOwnerEl, setEventOwnerEl] = useState<'button' | 'input'>();

    const { control, setValue } = useForm({
        defaultValues: {
            unitInquiryModalInput: '',
        },
    });

    return (
        <>
            <Layout>
                <Grid spacingType="common">
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav navTitleProps={{ title: 'UnitInquiryModal eventOwnerEl="input"' }} />
                                <Button
                                    text="Open UnitInquiryModal"
                                    onClick={() => {
                                        setOpenUnitInquiryModal(true);
                                        setEventOwnerEl('input');
                                    }}
                                />
                            </Box>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav navTitleProps={{ title: 'UnitInquiryModal eventOwnerEl="button"' }} />
                                <Button
                                    text="Open UnitInquiryModal"
                                    onClick={() => {
                                        setOpenUnitInquiryModal(true);
                                        setEventOwnerEl('button');
                                    }}
                                />
                            </Box>
                        </Paper>
                    </GridItem>
                    <GridItem xs={6}>
                        <Paper>
                            <Box p={1}>
                                <Nav navTitleProps={{ title: 'UnitInquiryModal - ModalViewer' }} />
                                <ModalViewer<SETModalsEnum.UnitInquiryModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.UnitInquiryModal}
                                    control={control}
                                    name="unitInquiryModalInput"
                                    label={SETModalsEnum.UnitInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.UnitInquiryModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('BpmProcessSelectionModal---onReturnData', data);
                                            setValue('unitInquiryModalInput', String(data?.organizationCode));
                                        },
                                    }}
                                    allowLeadingZeros
                                    returnValue="formattedValue"
                                />
                            </Box>
                        </Paper>
                    </GridItem>
                </Grid>
            </Layout>
            <UnitInquiryModal
                show={openUnitInquiryModal}
                onClose={setOpenUnitInquiryModal}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('data', data);
                }}
                eventOwnerEl={eventOwnerEl}
            />
        </>
    );
};

export default UnitInquiryPage;
