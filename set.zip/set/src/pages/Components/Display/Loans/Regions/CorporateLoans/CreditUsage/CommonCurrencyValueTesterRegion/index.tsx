import type { FC } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { CommonCurrencyValueTesterRegion, constants } from '../../../../../../../../lib';

interface IQueryFormValues {
    currencyType: string;
    exchange?: number;
}

const CommonCurrencyValueTesterRegionPage: FC = () => {
    const { control, setValue, resetField, reset, getValues } = useForm<IQueryFormValues>({
        defaultValues: { exchange: 0, currencyType: '' },
    });

    const [commonCurrencyValueTesterModalShow, setCommonCurrencyValueTesterModalShow] = useState<boolean>(false);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs>
                    <Paper>
                        <Nav navTitleProps={{ title: 'CommonCurrencyValueTesterRegion' }} />
                        <Grid>
                            <GridItem
                                md={constants.design.gridItem.sizeType.form.SET.md * 4}
                                lg={constants.design.gridItem.sizeType.form.SET.lg * 5}
                                xl={constants.design.gridItem.sizeType.form.SET.xl * 6}
                                xxl={constants.design.gridItem.sizeType.form.SET.xxl * 8}>
                                <Grid
                                    spacingType="form"
                                    columns={{
                                        md: constants.design.gridItem.sizeType.form.SET.md * 2,
                                        lg: constants.design.gridItem.sizeType.form.SET.lg * 2.5,
                                        xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                        xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                                    }}>
                                    <CommonCurrencyValueTesterRegion
                                        displayType="Region"
                                        formProps={{ control, setValue, resetField, reset, getValues }}
                                        componentProps={{
                                            selectProps: { currencyType: { name: 'currencyType' } },
                                            numberInputProps: { exchange: { name: 'exchange', readOnly: true } },
                                        }}
                                    />
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs>
                    <Paper>
                        <Nav navTitleProps={{ title: 'CommonCurrencyValueTesterRegion' }} />
                        <Button
                            sx={{ mt: 2 }}
                            text="Open CommonCurrencyValueTesterRegion"
                            onClick={() => {
                                setCommonCurrencyValueTesterModalShow(true);
                            }}
                        />
                    </Paper>
                </GridItem>
            </Grid>
            <CommonCurrencyValueTesterRegion
                show={commonCurrencyValueTesterModalShow}
                onClose={setCommonCurrencyValueTesterModalShow}
                displayType="Modal"
                componentProps={{ numberInputProps: { exchange: { readOnly: true } } }}
            />
        </Layout>
    );
};

export default CommonCurrencyValueTesterRegionPage;
