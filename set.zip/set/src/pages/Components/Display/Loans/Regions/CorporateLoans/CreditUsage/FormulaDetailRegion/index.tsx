import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { ModalViewer, SETModalsEnum, FormulaDetailRegion } from '../../../../../../../../lib';

const FormulaDetailRegionPage: FC = () => {
    const [formulaDetailRegionModalShow, setFormulaDetailRegionShow] = useState<boolean>(false);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'FormulaDetailRegion' }} />
                            <Button
                                text="Open FormulaDetailRegion"
                                onClick={() => {
                                    setFormulaDetailRegionShow(true);
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.FormulaDetailRegion>
                                    component="Button"
                                    modalComponent={SETModalsEnum.FormulaDetailRegion}
                                    name="formulaDetailRegionModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.FormulaDetailRegion}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.FormulaDetailRegion,
                                    }}
                                    modalProps={{
                                        varTestOneFormula: false,
                                        pnlTable: [{ dataSetDef: 'APPROVE_CHAIR', values: '6' }],
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <FormulaDetailRegion
                show={formulaDetailRegionModalShow}
                onClose={setFormulaDetailRegionShow}
                titleImp="Formül Detay"
            />
        </Layout>
    );
};

export default FormulaDetailRegionPage;
