import type { FC } from 'react';
import { Box, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { CommonFilePickerRegion } from '../../../../../../../../lib';

const CommonFilePickerRegionPage: FC = () => {
    const { control } = useForm({ defaultValues: { docs: null } });
    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CommonFilePickerRegion' }} />
                            <CommonFilePickerRegion control={control} name="docs" />
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default CommonFilePickerRegionPage;
