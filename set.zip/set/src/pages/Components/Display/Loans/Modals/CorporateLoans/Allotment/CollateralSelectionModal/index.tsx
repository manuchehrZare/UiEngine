import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { ModalViewer, CollateralSelectionModal, SETModalsEnum } from '../../../../../../../../lib';

interface IFormValues {
    collateralSelectionModalInput: string;
}

const CollateralSelectionModalPage: FC = () => {
    const [collateralSelectionModalModalShow, setCollateralSelectionModalShow] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control } = useForm<IFormValues>({
        defaultValues: {
            collateralSelectionModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CollateralSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open CollateralSelectionModal"
                                onClick={() => {
                                    setCollateralSelectionModalShow(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CollateralSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open CollateralSelectionModal"
                                onClick={() => {
                                    setCollateralSelectionModalShow(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.CollateralSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.CollateralSelectionModal}
                                    control={control}
                                    name="collateralSelectionModalInput"
                                    label={SETModalsEnum.CollateralSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.CollateralSelectionModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            collateralNo: 'T103',
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('CollateralSelectionModal---onReturnData', data);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.CollateralSelectionModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.CollateralSelectionModal}
                                    name="collateralSelectionModalModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.CollateralSelectionModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.CollateralSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('CollateralSelectionModal---onReturnData', data);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <CollateralSelectionModal
                show={collateralSelectionModalModalShow}
                onClose={setCollateralSelectionModalShow}
                eventOwnerEl={eventOwnerType}
                formData={{
                    collateralNo: 'T103',
                }}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('CollateralSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};

export default CollateralSelectionModalPage;
