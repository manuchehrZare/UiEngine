import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { ModalViewer, ProductSelectionModal, SETModalsEnum } from '../../../../../../../../lib';

interface IFormValues {
    productSelectionModalInput: string;
}

const ProductSelectionModalPage: FC = () => {
    const [productSelectionModalShow, setProductSelectionModalShow] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            productSelectionModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'ProductSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open ProductSelectionModal"
                                onClick={() => {
                                    setProductSelectionModalShow(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'ProductSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open ProductSelectionModal"
                                onClick={() => {
                                    setProductSelectionModalShow(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.ProductSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.ProductSelectionModal}
                                    control={control}
                                    name="productSelectionModalInput"
                                    label={SETModalsEnum.ProductSelectionModal}
                                    readOnly
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.ProductSelectionModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            mainGroupCode: '08',
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('ProductSelectionModal---onReturnData', data);
                                            setValue('productSelectionModalInput', String(data.productName));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.ProductSelectionModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.ProductSelectionModal}
                                    name="productSelectionModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.ProductSelectionModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.ProductSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('ProductSelectionModal---onReturnData', data);
                                            setValue('productSelectionModalInput', String(data.productName));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <ProductSelectionModal
                show={productSelectionModalShow}
                onClose={setProductSelectionModalShow}
                formData={{
                    mainGroupCode: '08',
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('ProductSelectionModal onReturnData', data);
                    setValue('productSelectionModalInput', String(data.productName));
                }}
            />
        </Layout>
    );
};

export default ProductSelectionModalPage;
