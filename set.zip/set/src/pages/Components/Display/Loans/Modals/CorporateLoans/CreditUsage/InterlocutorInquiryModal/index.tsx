import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { ModalViewer, InterlocutorInquiryModal, SETModalsEnum } from '../../../../../../../../lib';

interface IFormValues {
    interlocutorInquiryModalInput: string;
}

const InterlocutorInquiryModalPage: FC = () => {
    const [interlocutorInquiryModalShow, setInterlocutorInquiryModalShow] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            interlocutorInquiryModalInput: '',
        },
    });

    const interlocutorInquiryModalInputVal = useWatch({
        control,
        fieldName: 'interlocutorInquiryModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'InterlocutorInquiryModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open InterlocutorInquiryModal"
                                onClick={() => {
                                    setInterlocutorInquiryModalShow(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'InterlocutorInquiryModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open InterlocutorInquiryModal"
                                onClick={() => {
                                    setInterlocutorInquiryModalShow(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.InterlocutorInquiryModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.InterlocutorInquiryModal}
                                    control={control}
                                    name="interlocutorInquiryModalInput"
                                    label={SETModalsEnum.InterlocutorInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.InterlocutorInquiryModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            draweeName: interlocutorInquiryModalInputVal,
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('InterlocutorInquiryModal---onReturnData', data);
                                            setValue('interlocutorInquiryModalInput', data?.name);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.InterlocutorInquiryModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.InterlocutorInquiryModal}
                                    name="interlocutorInquiryModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.InterlocutorInquiryModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.InterlocutorInquiryModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('InterlocutorInquiryModal---onReturnData', data);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <InterlocutorInquiryModal
                show={interlocutorInquiryModalShow}
                onClose={setInterlocutorInquiryModalShow}
                /*  formData={{
                    draweeName: '',
                }} */
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('InterlocutorInquiryModal onReturnData', data);
                }}
            />
        </Layout>
    );
};

export default InterlocutorInquiryModalPage;
