import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { ModalViewer, PersonalLoanApplicationInquiryModal, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    personalLoanApplicationInquiryInput: number | null;
}

const PersonalLoanApplicationInquiryModalPage: FC = (): JSX.Element => {
    const [personalLoanapplicationModalShow, setPersonalLoanapplicationModalShow] = useState<boolean>(false);
    const [eventOwnerEl, setEventOwnerEl] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            personalLoanApplicationInquiryInput: null,
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav
                                navTitleProps={{ title: 'PersonalLoanApplicationInquiryModal eventOwnerEl="input"' }}
                            />
                            <Button
                                text="Open PersonalLoanApplicationInquiryModal"
                                onClick={() => {
                                    setPersonalLoanapplicationModalShow(() => {
                                        setEventOwnerEl('input');
                                        return true;
                                    });
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav
                                navTitleProps={{ title: 'PersonalLoanApplicationInquiryModal eventOwnerEl="button"' }}
                            />
                            <Button
                                text="Open PersonalLoanApplicationInquiryModal"
                                onClick={() => {
                                    setPersonalLoanapplicationModalShow(() => {
                                        setEventOwnerEl('button');
                                        return true;
                                    });
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'PersonalLoanApplicationInquiryModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.PersonalLoanApplicationInquiryModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.PersonalLoanApplicationInquiryModal}
                                    control={control}
                                    name="personalLoanApplicationInquiryInput"
                                    label={SETModalsEnum.PersonalLoanApplicationInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.PersonalLoanApplicationInquiryModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            setValue('personalLoanApplicationInquiryInput', data?.applicationNo);
                                            // eslint-disable-next-line no-console
                                            console.log('data', data);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <PersonalLoanApplicationInquiryModal
                show={personalLoanapplicationModalShow}
                onClose={setPersonalLoanapplicationModalShow}
                eventOwnerEl={eventOwnerEl}
            />
        </Layout>
    );
};
export default PersonalLoanApplicationInquiryModalPage;
