import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import { ModalViewer, ProductDisbursementFeaturesModal, SETModalsEnum } from '../../../../../../../../lib';

interface IFormValues {
    productDisbursementFeaturesModalInput: string;
}

const ProductDisbursementFeaturesModalPage: FC = () => {
    const [productDisbursementFeaturesModalShow, setProductDisbursementFeaturesModalShow] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            productDisbursementFeaturesModalInput: '',
        },
    });

    const productDisbursementFeaturesInputVal = useWatch({
        control,
        fieldName: 'productDisbursementFeaturesModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'ProductDisbursementFeaturesModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open ProductDisbursementFeaturesModal"
                                onClick={() => {
                                    setProductDisbursementFeaturesModalShow(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'ProductDisbursementFeaturesModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open ProductDisbursementFeaturesModal"
                                onClick={() => {
                                    setProductDisbursementFeaturesModalShow(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.ProductDisbursementFeaturesModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.ProductDisbursementFeaturesModal}
                                    control={control}
                                    name="productDisbursementFeaturesModalInput"
                                    label={SETModalsEnum.ProductDisbursementFeaturesModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.ProductDisbursementFeaturesModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            templeteName: productDisbursementFeaturesInputVal,
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('ProductDisbursementFeaturesModal---onReturnData', data);
                                            setValue('productDisbursementFeaturesModalInput', String(data.detailName));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.ProductDisbursementFeaturesModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.ProductDisbursementFeaturesModal}
                                    name="productDisbursementFeaturesModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.ProductDisbursementFeaturesModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.ProductDisbursementFeaturesModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('ProductDisbursementFeaturesModal---onReturnData', data);
                                            setValue('productDisbursementFeaturesModalInput', String(data.detailName));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <ProductDisbursementFeaturesModal
                show={productDisbursementFeaturesModalShow}
                onClose={setProductDisbursementFeaturesModalShow}
                componentProps={{
                    inputProps: { templeteName: { readOnly: true } },
                }}
                formData={{
                    templeteName: 'YURT DIŞI AVANS TEMİNAT MEKTUBU',
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('ProductDisbursementFeaturesModal onReturnData', data);
                }}
            />
        </Layout>
    );
};

export default ProductDisbursementFeaturesModalPage;
