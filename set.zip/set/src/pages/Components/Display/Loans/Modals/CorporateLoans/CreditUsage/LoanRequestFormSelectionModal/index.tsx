import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../../App';
import {
    ModalViewer,
    LoanRequestFormSelectionModal,
    SETModalsEnum,
    getGlobalsData,
    GlobalsItemEnum,
} from '../../../../../../../../lib';

interface IFormValues {
    loanRequestFormSelectionModalInput: string;
}

const LoanRequestFormSelectionModalPage: FC = () => {
    const [loanRequestFormSelectionModalShow, setLoanRequestFormSelectionModalShow] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            loanRequestFormSelectionModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'LoanRequestFormSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open LoanRequestFormSelectionModal"
                                onClick={() => {
                                    setLoanRequestFormSelectionModalShow(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'LoanRequestFormSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open LoanRequestFormSelectionModal"
                                onClick={() => {
                                    setLoanRequestFormSelectionModalShow(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.LoanRequestFormSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.LoanRequestFormSelectionModal}
                                    control={control}
                                    name="loanRequestFormSelectionModalInput"
                                    label={SETModalsEnum.LoanRequestFormSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.LoanRequestFormSelectionModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            creatorOrgCode:
                                                getGlobalsData({ key: GlobalsItemEnum.AccountingBranchCode }) || '',
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('LoanRequestFormSelectionModal---onReturnData', data);
                                            setValue('loanRequestFormSelectionModalInput', data?.creditNo || '');
                                        },
                                        statesList: { stateListVar: '1,2,3,4,5,6' },
                                        usageVariables: { recordType: 'U', RECORD_TYPE_2: 'U', isETender: '1' },
                                        /*  creditState: CreditStateEnum.ActiveState, */
                                        componentProps: { selectProps: { usageType: { disabled: true } } },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.LoanRequestFormSelectionModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.LoanRequestFormSelectionModal}
                                    name="loanRequestFormSelectionModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.LoanRequestFormSelectionModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.LoanRequestFormSelectionModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('LoanRequestFormSelectionModal---onReturnData', data);
                                        },
                                        componentProps: { inputProps: { usagePatternOid: { readOnly: true } } },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <LoanRequestFormSelectionModal
                show={loanRequestFormSelectionModalShow}
                onClose={setLoanRequestFormSelectionModalShow}
                formData={{
                    creatorOrgCode: getGlobalsData({ key: GlobalsItemEnum.AccountingBranchCode }) || '',
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('LoanRequestFormSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};

export default LoanRequestFormSelectionModalPage;
