import type { FC, JSX } from 'react';
import { BankAccountInfoRegion } from '../../../../../../../lib';
import { Grid, GridItem, Nav, Paper, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { isNull } from 'lodash';

interface IFormValues {
    accountNo: number | null;
    branch: string;
    customerNameSurname: string;
    customerNo: number | null;
}

const BankAccountInfoRegionPage: FC = (): JSX.Element => {
    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            accountNo: null,
            branch: '',
            customerNameSurname: '',
            customerNo: null,
        },
    });
    const [branchVal, customerNoVal] = useWatch({ control, fieldName: ['branch', 'customerNo'] });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'BankAccountInfoRegion' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <BankAccountInfoRegion<IFormValues>
                                    formProps={{ control, setValue }}
                                    componentProps={{
                                        selectProps: { branch: { name: 'branch', label: 'Branch' } },
                                        inputProps: {
                                            customerNameSurname: {
                                                name: 'customerNameSurname',
                                                label: 'Customer Name Surname',
                                            },
                                        },
                                        numberInputProps: {
                                            accountNo: {
                                                name: 'accountNo',
                                                label: 'Account No',
                                                modalProps: {
                                                    onReturnData: (data: any) => {
                                                        setValue('customerNameSurname', data?.custNameTitle || '');
                                                        setValue('accountNo', data?.accCode || null);
                                                        setValue('customerNo', data?.accCustCode || null);
                                                        setValue(
                                                            'branch',
                                                            !isNull(data?.accOrgCode) ? String(data.accOrgCode) : '',
                                                        );
                                                    },
                                                    formData: {
                                                        accOrgCode: branchVal || '',
                                                        accCustCode: customerNoVal || null,
                                                    },
                                                },
                                            },
                                            customerNo: {
                                                name: 'customerNo',
                                                label: 'Customer No',
                                                modalProps: {
                                                    onReturnData: (data: any) => {
                                                        setValue('customerNameSurname', data?.nameTitle || '');
                                                        setValue(
                                                            'branch',
                                                            data?.mainBranchCode ? String(data?.mainBranchCode) : '',
                                                        );
                                                    },
                                                    formData: {
                                                        custCustMainBranchCode: branchVal || '',
                                                    },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default BankAccountInfoRegionPage;
