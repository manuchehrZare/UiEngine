import type { FC, JSX } from 'react';
import { Grid, GridItem, Nav, Paper, useForm, useWatch, validation } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import AccountSearchRegion from '../../../../../../../lib/components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion';
import { toString } from 'lodash';
import type { IAccountFirstRegionFormValues } from '../../../../../../../lib/components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion/type';
import { CorporationEnum } from '../../../../../../../lib/components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion/type';
import { useTranslation } from '../../../../../../../lib';

interface IFormValues {
    cardNo: number | null;
    corporation: string;
    customerNameSurname: string;
    customerNo: number | null;
}

const AccountSearchRegionPage: FC = (): JSX.Element => {
    const { t, locale } = useTranslation();
    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            corporation: '01',
            customerNo: null,
            customerNameSurname: '',
            cardNo: null,
        },
        validationSchema: {
            cardNo: validation.number(t(locale.labels.cardNo)).test({
                test: function (val, context) {
                    const { customerNo } = context.parent as IAccountFirstRegionFormValues;

                    if (customerNo && val && toString(val)?.length < 16) {
                        return this.createError({
                            message: t(locale.notifications.minimumCharactersEnter, {
                                value: `${t(locale.labels.cardNo)}`,
                                count: 16,
                            }),
                        });
                    } else if (!customerNo && val && toString(val)?.length < 16) {
                        return this.createError({
                            message: t(locale.notifications.minimumCharactersOrRequiredArea, {
                                value1: `${t(locale.labels.cardNo)}`,
                                value2: `${t(locale.labels.customerNo)}`,
                                count: 16,
                            }),
                        });
                    }
                    return true;
                },
            }),
        },
    });

    const [customerNoVal, cardNoVal] = useWatch({ control, fieldName: ['customerNo', 'cardNo'] });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'AccountSearchRegion' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <AccountSearchRegion<IFormValues>
                                    formProps={{ control, setValue }}
                                    componentProps={{
                                        selectProps: { corporation: { name: 'corporation', label: 'corporation' } },
                                        inputProps: {
                                            customerNameSurname: {
                                                name: 'customerNameSurname',
                                                label: 'customerNameSurname',
                                            },
                                        },
                                        numberInputProps: {
                                            cardNo: {
                                                name: 'cardNo',
                                                label: 'cardNo',
                                                modalProps: {
                                                    onReturnData: (data: any) => {
                                                        setValue('cardNo', Number(data?.accountNo) || null);
                                                        setValue('customerNo', data?.custNo || null);
                                                        setValue('customerNameSurname', data?.nameSurname || '');
                                                    },
                                                    formData: {
                                                        accountNo: toString(cardNoVal) || '',
                                                        corpNo: CorporationEnum.Sekerbank,
                                                        custNo: toString(customerNoVal) || '',
                                                    },
                                                },
                                            },
                                            customerNo: {
                                                name: 'customerNo',
                                                label: 'customerNo',
                                                modalProps: {
                                                    onReturnData: (data: any) => {
                                                        setValue('customerNameSurname', data?.nameSurname || '');
                                                        setValue('customerNo', data?.custNo || null);
                                                        setValue('cardNo', Number(data?.accountNo) || null);
                                                    },
                                                    formData: {
                                                        accountNo: toString(cardNoVal),
                                                        corpNo: CorporationEnum.Sekerbank,
                                                        custNo: toString(customerNoVal),
                                                    },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default AccountSearchRegionPage;
