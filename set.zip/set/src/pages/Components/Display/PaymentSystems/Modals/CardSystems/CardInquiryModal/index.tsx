import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm, useWatch, validation } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { ModalViewer, CardInquiryModal, SETModalsEnum, useTranslation } from '../../../../../../../lib';

interface IFormValues {
    cardInquiryModalInput: string;
}

const CardInquiryModalPage: FC = () => {
    const [cardInquiryModalShow, setCardInquiryModalShow] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();
    const { t, locale } = useTranslation();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            cardInquiryModalInput: '',
        },
        validationSchema: {
            cardInquiryModalInput: validation.number(t(locale.labels.cardNo), {
                minLength: 16,
                messageFormatter: {
                    minLength: () => t(locale.notifications.missingOrIncorrectCardNo),
                },
            }),
        },
    });

    const cardInquiryInputVal = useWatch({
        control,
        fieldName: 'cardInquiryModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CardInquiryModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open CardInquiryModal"
                                onClick={() => {
                                    setCardInquiryModalShow(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CardInquiryModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open CardInquiryModal"
                                onClick={() => {
                                    setCardInquiryModalShow(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.CardInquiryModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.CardInquiryModal}
                                    control={control}
                                    name="cardInquiryModalInput"
                                    maxLength={16}
                                    label={SETModalsEnum.CardInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.CardInquiryModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            accountNo: cardInquiryInputVal,
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('CardInquiryModal---onReturnData', data);
                                            setValue('cardInquiryModalInput', data?.accountNo);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.CardInquiryModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.CardInquiryModal}
                                    name="cardInquiryModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.CardInquiryModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.CardInquiryModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            accountNo: cardInquiryInputVal,
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('CardInquiryModal---onReturnData', data);
                                            setValue('cardInquiryModalInput', data?.accountNo);
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <CardInquiryModal
                show={cardInquiryModalShow}
                onClose={setCardInquiryModalShow}
                /*   componentProps={{
                    inputProps: { templeteName: { readOnly: true } },
                }}  */
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    setValue('cardInquiryModalInput', data?.accountNo);
                    // eslint-disable-next-line no-console
                    console.log('CardInquiryModal onReturnData', data);
                }}
            />
        </Layout>
    );
};

export default CardInquiryModalPage;
