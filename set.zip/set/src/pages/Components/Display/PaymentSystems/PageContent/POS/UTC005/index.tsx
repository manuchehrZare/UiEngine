import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { UTC005PageContent } from '../../../../../../../lib';

const UTC005Page: FC = (): JSX.Element => {
    const [modalShow, setModalShow] = useState<boolean>(false);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'UTC005PageContent' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <Button text="UTC005PageContent show" onClick={() => setModalShow(true)} />
                            </GridItem>
                            <GridItem>
                                <UTC005PageContent
                                    displayType="Modal"
                                    show={modalShow}
                                    onClose={() => setModalShow(false)}
                                    payloadData={{
                                        termTranOid: '6d1rqgm00yhbgt00',
                                        // transactionOid: '6e0gn2lxud6ahv00',
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UTC005Page;
