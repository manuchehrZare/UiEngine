import type { FC } from 'react';
import { Layout } from '../../../../../../App';
import { PasswordInformations } from '../../../../../../lib';

const PasswordInformationsPage: FC = () => {
    return (
        <Layout>
            <PasswordInformations />
        </Layout>
    );
};

export default PasswordInformationsPage;
