import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Paper, Nav } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { ContinueProcessConfirmModal } from '../../../../../../lib';

const ContinueProcessConfirmModalPage: FC = () => {
    const [continueProcessConfirmModalShow, setContinueProcessConfirmModalShow] = useState<boolean>(false);

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ContinueProcessConfirmModal' }} />
                        <Box p={1}>
                            <Button
                                text="Open ContinueProcessConfirmModal"
                                onClick={() => setContinueProcessConfirmModalShow(true)}
                            />
                        </Box>
                        <ContinueProcessConfirmModal
                            show={continueProcessConfirmModalShow}
                            onConfirm={(status) => {
                                if (status) {
                                    // eslint-disable-next-line no-console
                                    console.log('status', status);
                                    setContinueProcessConfirmModalShow(false);
                                } else {
                                    // eslint-disable-next-line no-console
                                    console.log('status', status);
                                    setContinueProcessConfirmModalShow(false);
                                }
                            }}
                        />
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ContinueProcessConfirmModalPage;
