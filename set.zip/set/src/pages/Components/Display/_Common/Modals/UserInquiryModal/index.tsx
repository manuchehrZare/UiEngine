import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Layout } from '../../../../../../App';
import { Box, Grid, GridItem, Paper, Button, Nav } from 'seker-ui';
import { UserInquiryModal } from '../../../../../../lib';

const UserInquiryModalPage: FC = (): JSX.Element => {
    const [userInquiryModalShow, setUserInquiryModalShow] = useState<boolean>(false);

    return (
        <>
            <Layout>
                <Grid spacingType="common">
                    <GridItem xs={6}>
                        <Paper>
                            <Nav navTitleProps={{ title: 'UserInquiryModal' }} />
                            <Box p={1}>
                                <Button text="Open UserInquiryModal" onClick={() => setUserInquiryModalShow(true)} />
                            </Box>
                        </Paper>
                    </GridItem>
                </Grid>
            </Layout>
            <UserInquiryModal
                eventOwnerEl="button"
                show={userInquiryModalShow}
                onClose={setUserInquiryModalShow}
                onReturnData={(returnData) => {
                    // eslint-disable-next-line no-console
                    console.log('returnData', returnData);
                }}
            />
        </>
    );
};

export default UserInquiryModalPage;
