import type { FC } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Paper, Nav } from 'seker-ui';
import { Layout } from '../../../../../../App';
import { LossOfChangeConfirmModal } from '../../../../../../lib';

const LossOfChangeConfirmModalPage: FC = () => {
    const [lossOfChangeConfirmModalShow, setLossOfChangeConfirmModalShow] = useState<boolean>(false);

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'LossOfChangeConfirmModal' }} />
                        <Box p={1}>
                            <Button
                                text="Open LossOfChangeConfirmModal"
                                onClick={() => setLossOfChangeConfirmModalShow(true)}
                            />
                        </Box>
                        <LossOfChangeConfirmModal
                            show={lossOfChangeConfirmModalShow}
                            onConfirm={(status) => {
                                if (status) {
                                    // eslint-disable-next-line no-console
                                    console.log('status', status);
                                    setLossOfChangeConfirmModalShow(false);
                                } else {
                                    setLossOfChangeConfirmModalShow(false);
                                }
                            }}
                        />
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default LossOfChangeConfirmModalPage;
