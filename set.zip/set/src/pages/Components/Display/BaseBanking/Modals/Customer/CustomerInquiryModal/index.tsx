import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import {
    CustomerInquiryModal,
    GlobalsItemEnum,
    ModalViewer,
    SETModalsEnum,
    getGlobalsData,
} from '../../../../../../../lib';

interface IFormValues {
    customerInquiryModalInput: string;
}

const CustomerInquiryModalPage: FC = (): JSX.Element => {
    const [customerInquiryModalOpen, setCustomerInquiryModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            customerInquiryModalInput: '',
        },
    });

    // const customerInquiryModalInputVal = useWatch({
    //     control,
    //     fieldName: 'customerInquiryModalInput',
    // });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CustomerInquiryModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open CustomerInquiryModal"
                                onClick={() => {
                                    setCustomerInquiryModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'CustomerInquiryModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open CustomerInquiryModal"
                                onClick={() => {
                                    setCustomerInquiryModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.CustomerInquiryModal}
                                    control={control}
                                    name="customerInquiryModalInput"
                                    label={SETModalsEnum.CustomerInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.CustomerInquiryModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            //showCorporateBranchCombo: '1',
                                            custCustMainBranchCode: String(
                                                getGlobalsData({
                                                    key: GlobalsItemEnum.OrganizationCode,
                                                }),
                                            ),
                                        },
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('CustomerInquiryModal---onReturnData', data);
                                            setValue('customerInquiryModalInput', String(data.customerCode));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.CustomerInquiryModal}
                                    name="customerInquiryModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.CustomerInquiryModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.CustomerInquiryModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                custCustMainBranchCode: getGlobalsData({
                                                    key: GlobalsItemEnum.OrganizationCode,
                                                }) as any,
                                                // showCorporateBranchCombo: '1',
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('CustomerInquiryModal---onReturnData', data);
                                                setValue('customerInquiryModalInput', String(data.customerCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <CustomerInquiryModal
                show={customerInquiryModalOpen}
                onClose={setCustomerInquiryModalOpen}
                formData={{
                    custCustCustomerType: '1',
                    custCustActiveStatus: 'A',
                    custCustCustomerCode: '35246231',
                }}
                componentProps={{
                    selectProps: { custCustActiveStatus: { readOnly: true } },
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('CustomerInquiry onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default CustomerInquiryModalPage;
