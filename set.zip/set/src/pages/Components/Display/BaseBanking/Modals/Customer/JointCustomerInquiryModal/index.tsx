import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import {
    /* GlobalsItemEnum, */
    JointCustomerInquiryModal,
    ModalViewer,
    SETModalsEnum,
    /* getGlobalsData, */
} from '../../../../../../../lib';

interface IFormValues {
    jointCustomerInquiryModalInput: string;
}

const JointCustomerInquiryModalPage: FC = (): JSX.Element => {
    const [jointCustomerInquiryModalOpen, setJointCustomerInquiryModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            jointCustomerInquiryModalInput: '',
        },
    });

    // const jointCustomerInquiryModalInputVal = useWatch({
    //     control,
    //     fieldName: 'jointCustomerInquiryModalInput',
    // });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'JointCustomerInquiryModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open JointCustomerInquiryModal"
                                onClick={() => {
                                    setJointCustomerInquiryModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'JointCustomerInquiryModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open JointCustomerInquiryModal"
                                onClick={() => {
                                    setJointCustomerInquiryModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.JointCustomerInquiryModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.JointCustomerInquiryModal}
                                    control={control}
                                    name="jointCustomerInquiryModalInput"
                                    label={SETModalsEnum.JointCustomerInquiryModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.JointCustomerInquiryModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                // custCustCustomerCode: jointCustomerInquiryModalInputVal,
                                                // showCorporateBranchCombo: '1',
                                                /* custCustMainBranchCode:
                                                getGlobalsData({ key: GlobalsItemEnum.ChargedOrganizationCode }) || '', */
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('JointCustomerInquiryModal---onReturnData', data);
                                                setValue('jointCustomerInquiryModalInput', String(data.customerCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.JointCustomerInquiryModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.JointCustomerInquiryModal}
                                    name="jointCustomerInquiryModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.JointCustomerInquiryModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.JointCustomerInquiryModal,
                                    }}
                                    modalProps={
                                        {
                                            // formData: {
                                            //     custCustCustomerCode: jointCustomerInquiryModalInputWatch,
                                            // },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('JointCustomerInquiryModal---onReturnData', data);
                                                setValue('jointCustomerInquiryModalInput', String(data?.customerCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <JointCustomerInquiryModal
                show={jointCustomerInquiryModalOpen}
                onClose={setJointCustomerInquiryModalOpen}
                formData={{
                    custCustActiveStatus: 'A',
                    custCustCustomerCode: '35246231',
                    // custCustBirthdayStart: 1701254784,
                }}
                componentProps={{
                    selectProps: { custCustActiveStatus: { readOnly: true } },
                    pickerProps: { datePicker: { custCustBirthdayStart: { disabled: true } } },
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('JointCustomerInquiry onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default JointCustomerInquiryModalPage;
