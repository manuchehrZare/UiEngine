import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { FilesModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    filesModalInput: string;
}

const FilesModalPage: FC = (): JSX.Element => {
    const [filesModalOpen, setFilesModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            filesModalInput: '',
        },
    });

    const filesModalInputVal = useWatch({
        control,
        fieldName: 'filesModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'FilesModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open FilesModal"
                                onClick={() => {
                                    setFilesModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'FilesModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open FilesModal"
                                onClick={() => {
                                    setFilesModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.FilesModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.FilesModal}
                                    control={control}
                                    name="filesModalInput"
                                    label={SETModalsEnum.FilesModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.FilesModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                fileNo: filesModalInputVal,
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('FilesModal---onReturnData', data);
                                                setValue('filesModalInput', data.fileNo ? String(data.fileNo) : '');
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.FilesModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.FilesModal}
                                    name="filesModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.FilesModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.FilesModal,
                                    }}
                                    modalProps={
                                        {
                                            /*  componentProps: { selectProps: { productType: { readOnly: false } } }, */
                                            // formData: {
                                            //     custCustCustomerCode: filesModalInputWatch,
                                            // },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('FilesModal---onReturnData', data);
                                                setValue('filesModalInput', data.fileNo ? String(data.fileNo) : '');
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <FilesModal
                show={filesModalOpen}
                onClose={setFilesModalOpen}
                formData={{
                    fileNo: '016IAVL23.000630',
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('Files onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default FilesModalPage;
