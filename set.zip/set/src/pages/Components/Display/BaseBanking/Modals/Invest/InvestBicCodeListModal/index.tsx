import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useWatch, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import InvestBicCodeListModal from '../../../../../../../lib/components/Display/BaseBanking/Modals/Invest/InvestBicCodeListModal';
import { ModalViewer, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    investBicCodeListModalInput: string;
}

const InvestBicCodeListModalPage: FC = (): JSX.Element => {
    const [bicCodeListModalOpen, setBicCodeListModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            investBicCodeListModalInput: '',
        },
    });

    const investBicCodeListModalInputVal = useWatch({
        control,
        fieldName: 'investBicCodeListModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'InvestBicCodeListModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open InvestBicCodeListModal"
                                onClick={() => {
                                    setBicCodeListModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'InvestBicCodeModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open InvestBicCodeModal"
                                onClick={() => {
                                    setBicCodeListModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.InvestBicCodeModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.InvestBicCodeModal}
                                    control={control}
                                    name="investBicCodeListModalInput"
                                    label={SETModalsEnum.InvestBicCodeModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.InvestBicCodeModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                bicCode: investBicCodeListModalInputVal,
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('InvestBicCodeListModal---onReturnData', data);
                                                setValue('investBicCodeListModalInput', String(data.bicCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.InvestBicCodeModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.InvestBicCodeModal}
                                    name="investBicCodeListModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.InvestBicCodeModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.InvestBicCodeModal,
                                    }}
                                    modalProps={
                                        {
                                            // formData: {
                                            //     bicCode: 'BKCHHKHHXXX',
                                            // },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('InvestBicCodeModal---onReturnData', data);
                                                setValue('investBicCodeListModalInput', String(data?.bicCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <InvestBicCodeListModal
                show={bicCodeListModalOpen}
                onClose={setBicCodeListModalOpen}
                formData={{ bicCode: 'IRVTUS3NXXX', currencyType: '02sajbxe1w3jyb91' }}
                componentProps={{}}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BicCodeListModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default InvestBicCodeListModalPage;
