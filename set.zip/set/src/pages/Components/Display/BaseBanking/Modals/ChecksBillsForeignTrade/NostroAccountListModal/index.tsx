import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { ModalViewer, NostroAccountListModal, SETModalsEnum } from '../../../../../../../lib';
import { Layout } from '../../../../../../../App';

interface IFormValues {
    nostroAccountListModalInput: string;
    nostroAccountListModalInput2: string;
}

const NostroAccountListModalPage: FC = (): JSX.Element => {
    const [nostroAccountListModalOpen, setNostroAccountListModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            nostroAccountListModalInput: '',
            nostroAccountListModalInput2: '',
        },
    });
    const [nostroAccountListModalInputWatch] = useWatch({
        control,
        fieldName: ['nostroAccountListModalInput'],
    });

    // eslint-disable-next-line no-console
    console.log('nostroAccountListModalInputWatch', nostroAccountListModalInputWatch);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'NostroAccountListModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open NostroAccountListModal"
                                onClick={() => {
                                    setNostroAccountListModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'NostroAccountListModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open NostroAccountListModal"
                                onClick={() => {
                                    setNostroAccountListModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'NostroAccountListModal - ModalViewer' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.NostroAccountListModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.NostroAccountListModal}
                                    control={control}
                                    name="nostroAccountListModalInput"
                                    label={SETModalsEnum.NostroAccountListModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.NostroAccountListModal,
                                    }}
                                    modalProps={
                                        {
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('NostroAccountListModal---onReturnData', data);
                                                setValue('nostroAccountListModalInput', String(data?.customerCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.NostroAccountListModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.NostroAccountListModal}
                                    name="nostroAccountListModalInput2"
                                    text={`With Button Usage - ${SETModalsEnum.NostroAccountListModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.NostroAccountListModal,
                                    }}
                                    modalProps={{
                                        onReturnData: (data: any) => {
                                            // eslint-disable-next-line no-console
                                            console.log('NostroAccountListModal---onReturnData', data);
                                            setValue('nostroAccountListModalInput2', String(data?.customerCode));
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <NostroAccountListModal
                show={nostroAccountListModalOpen}
                onClose={setNostroAccountListModalOpen}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('NostroAccountListModalOpen onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default NostroAccountListModalPage;
