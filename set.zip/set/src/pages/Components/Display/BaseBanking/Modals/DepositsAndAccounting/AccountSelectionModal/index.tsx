import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, NumberInputReturnValueEnum } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { AccountSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    accountSelectionModalInput: string;
}

const AccountSelectionModalPage: FC = (): JSX.Element => {
    const [accountSelectionModalOpen, setAccountSelectionModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            accountSelectionModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'AccountSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open AccountSelectionModal"
                                onClick={() => {
                                    setAccountSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'AccountSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open AccountSelectionModal"
                                onClick={() => {
                                    setAccountSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.AccountSelectionModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.AccountSelectionModal}
                                    control={control}
                                    name="accountSelectionModalInput"
                                    label={SETModalsEnum.AccountSelectionModal}
                                    allowLeadingZeros
                                    returnValue={NumberInputReturnValueEnum.formattedValue}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.AccountSelectionModal,
                                    }}
                                    modalProps={
                                        {
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('AccountSelectionModal---onReturnData', data);
                                                setValue('accountSelectionModalInput', String(data.accCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.AccountSelectionModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.AccountSelectionModal}
                                    name="accountSelectionModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.AccountSelectionModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.AccountSelectionModal,
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <AccountSelectionModal
                show={accountSelectionModalOpen}
                onClose={setAccountSelectionModalOpen}
                eventOwnerEl={eventOwnerType}
                componentProps={{
                    selectProps: { currencyCode: { readOnly: true } },
                }}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('AccountSelectionModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default AccountSelectionModalPage;
