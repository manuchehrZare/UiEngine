import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, useWatch } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { AssetSelectionModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    assetSelectionModalInput: string;
}

const AssetSelectionModalPage: FC = (): JSX.Element => {
    const [assetSelectionModalOpen, setAssetSelectionModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            assetSelectionModalInput: '',
        },
    });

    const assetSelectionModalInputVal = useWatch({
        control,
        fieldName: 'assetSelectionModalInput',
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'AssetSelectionModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open AssetSelectionModal"
                                onClick={() => {
                                    setAssetSelectionModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'AssetSelectionModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open AssetSelectionModal"
                                onClick={() => {
                                    setAssetSelectionModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.AssetSelectionModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.AssetSelectionModal}
                                    control={control}
                                    name="assetSelectionModalInput"
                                    label={SETModalsEnum.AssetSelectionModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.AssetSelectionModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                shortDescription: assetSelectionModalInputVal,
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('AssetSelectionModal---onReturnData', data);
                                                setValue('assetSelectionModalInput', data.shortDescription);
                                            },
                                        } as any
                                    }
                                    sx={{
                                        input: {
                                            textTransform: 'uppercase',
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.AssetSelectionModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.AssetSelectionModal}
                                    name="assetSelectionModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.AssetSelectionModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.AssetSelectionModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                assetGroupDefOid: assetSelectionModalInputVal,
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('AssetSelectionModal---onReturnData', data);
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <AssetSelectionModal
                show={assetSelectionModalOpen}
                onClose={setAssetSelectionModalOpen}
                formData={{
                    shortDescription: assetSelectionModalInputVal,
                }}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('AssetSelection onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default AssetSelectionModalPage;
