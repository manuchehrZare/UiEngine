import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Box, Button, Grid, GridItem, Nav, Paper, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { FTCCommonStatisticsModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    ftcCommonStatisticsModalInput: string;
}

const FTCCommonStatisticsPage: FC = (): JSX.Element => {
    const [ftcCommonStatisticsModalOpen, setFtcCommonStatisticsModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            ftcCommonStatisticsModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'FTCCommonStatisticsModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open FTCCommonStatisticsModal"
                                onClick={() => {
                                    setFtcCommonStatisticsModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'FTCCommonStatisticsModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open FTCCommonStatisticsModal"
                                onClick={() => {
                                    setFtcCommonStatisticsModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.FTCCommonStatisticsModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.FTCCommonStatisticsModal}
                                    control={control}
                                    name="ftcCommonStatisticsModalInput"
                                    label={SETModalsEnum.FTCCommonStatisticsModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.FTCCommonStatisticsModal,
                                    }}
                                    modalProps={
                                        {
                                            /* formData: { statisticCode: ftcCommonStatisticsModalInput, statisticCodeInit:  }, */

                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('ftcCommonStatisticsModalInput---onReturnData', data);
                                                setValue('ftcCommonStatisticsModalInput', String(data?.code));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.FTCCommonStatisticsModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.FTCCommonStatisticsModal}
                                    name="ftcCommonStatisticsModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.FTCCommonStatisticsModal}`}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.FTCCommonStatisticsModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: { statisticCode: 'T0303' },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('FTCCommonStatisticsModal---onReturnData', data);
                                                setValue('ftcCommonStatisticsModalInput', String(data?.code));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <FTCCommonStatisticsModal
                show={ftcCommonStatisticsModalOpen}
                onClose={setFtcCommonStatisticsModalOpen}
                formData={{ statisticCode: 'T0303' }}
                componentProps={{}}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BicCodeListModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default FTCCommonStatisticsPage;
