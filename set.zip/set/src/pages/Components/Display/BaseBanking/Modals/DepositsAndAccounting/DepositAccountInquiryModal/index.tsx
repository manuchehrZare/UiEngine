import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm, NumberInputReturnValueEnum } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { DepositAccountInquiryModal, ModalViewer, SETModalsEnum } from '../../../../../../../lib';

interface IFormValues {
    depositAccountInquiryModalInput: string;
}

const DepositAccountInquiryModalPage: FC = (): JSX.Element => {
    const [depositAccountInquiryModalOpen, setDepositAccountInquiryModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            depositAccountInquiryModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'DepositAccountInquiryModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open DepositAccountInquiryModal"
                                onClick={() => {
                                    setDepositAccountInquiryModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'DepositAccountInquiryModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open DepositAccountInquiryModal"
                                onClick={() => {
                                    setDepositAccountInquiryModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.DepositAccountInquiryModal>
                                    component="NumberInput"
                                    modalComponent={SETModalsEnum.DepositAccountInquiryModal}
                                    control={control}
                                    name="depositAccountInquiryModalInput"
                                    label={SETModalsEnum.DepositAccountInquiryModal}
                                    allowLeadingZeros
                                    returnValue={NumberInputReturnValueEnum.formattedValue}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.DepositAccountInquiryModal,
                                    }}
                                    modalProps={
                                        {
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('DepositAccountInquiryModal---onReturnData', data);
                                                setValue('depositAccountInquiryModalInput', String(data.accCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.DepositAccountInquiryModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.DepositAccountInquiryModal}
                                    name="depositAccountInquiryModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.DepositAccountInquiryModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.DepositAccountInquiryModal,
                                    }}
                                    modalProps={{
                                        formData: {
                                            ammountFirst: 10,
                                            ammountLast: 11,
                                        },
                                    }}
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <DepositAccountInquiryModal
                show={depositAccountInquiryModalOpen}
                onClose={setDepositAccountInquiryModalOpen}
                eventOwnerEl={eventOwnerType}
                formData={{
                    accCode: '006005332',
                    orgCode: '006',
                }}
                componentProps={{
                    selectProps: { currencyCode: { readOnly: true } },
                }}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('DepositAccountInquiryModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default DepositAccountInquiryModalPage;
