import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Paper, Box, Nav, useForm } from 'seker-ui';
import { Layout } from '../../../../../../../App';
import { ModalViewer, SETModalsEnum, ChecksBillsForeignTradeBicCodeListModal } from '../../../../../../../lib';

interface IFormValues {
    checksBillsBicCodeListModalInput: string;
}

const ChecksBillsForeignTradeBicCodeListModalPage: FC = (): JSX.Element => {
    const [bicCodeListModalOpen, setBicCodeListModalOpen] = useState<boolean>(false);
    const [eventOwnerType, setEventOwnerType] = useState<'input' | 'button'>();

    const { control, setValue } = useForm<IFormValues>({
        defaultValues: {
            checksBillsBicCodeListModalInput: '',
        },
    });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'ChecksBillsBicCodeListModal eventOwnerEl="input"' }} />
                            <Button
                                text="Open ChecksBillsBicCodeListModal"
                                onClick={() => {
                                    setBicCodeListModalOpen(true);
                                    setEventOwnerType('input');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Box p={1}>
                            <Nav navTitleProps={{ title: 'ChecksBillsBicCodeListModal eventOwnerEl="button"' }} />
                            <Button
                                text="Open ChecksBillsBicCodeListModal"
                                onClick={() => {
                                    setBicCodeListModalOpen(true);
                                    setEventOwnerType('button');
                                }}
                            />
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Input or NumberInput' }} />
                        <Grid spacingType="form">
                            <GridItem>
                                <ModalViewer<SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal>
                                    component="Input"
                                    modalComponent={SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}
                                    control={control}
                                    name="checksBillsBicCodeListModalInput"
                                    label={SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal,
                                    }}
                                    modalProps={
                                        {
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('ChecksBillsBicCodeListModal---onReturnData', data);
                                                setValue('checksBillsBicCodeListModalInput', String(data.bicCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem xs={6}>
                    <Paper>
                        <Nav navTitleProps={{ title: 'ModalViewer - Button' }} />
                        <Grid spacingType="form">
                            <GridItem mt={2}>
                                <ModalViewer<SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal>
                                    component="Button"
                                    modalComponent={SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}
                                    name="checksBillsBicCodeListModalInput"
                                    text={`With Button Usage - ${SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}`}
                                    onClick={() => {
                                        // eslint-disable-next-line no-console
                                        console.log('Button Click Running');
                                    }}
                                    adornmentButtonProps={{
                                        tooltip: SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal,
                                    }}
                                    modalProps={
                                        {
                                            formData: {
                                                bicCode: 'BMAFAFKAXXX',
                                            },
                                            onReturnData: (data: any) => {
                                                // eslint-disable-next-line no-console
                                                console.log('ChecksBillsBicCodeListModal---onReturnData', data);
                                                setValue('checksBillsBicCodeListModalInput', String(data?.bicCode));
                                            },
                                        } as any
                                    }
                                />
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
            <ChecksBillsForeignTradeBicCodeListModal
                show={bicCodeListModalOpen}
                onClose={setBicCodeListModalOpen}
                formData={{ bicCode: 'BMAFAFKAXXX' }}
                componentProps={{}}
                eventOwnerEl={eventOwnerType}
                onReturnData={(data) => {
                    // eslint-disable-next-line no-console
                    console.log('BicCodeListModal onReturnData', data);
                }}
            />
        </Layout>
    );
};
export default ChecksBillsForeignTradeBicCodeListModalPage;
