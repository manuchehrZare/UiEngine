import type { FC } from 'react';
import { Children } from 'react';
import { DesignTypeEnum, Grid, GridItem, Label, Paper, typographyClasses } from 'seker-ui';
import {
    AppsOutlined,
    LibraryAddOutlined,
    SettingsOutlined,
    StorageRounded,
    WebAssetOutlined,
    WebhookOutlined,
} from '@mui/icons-material';
import { Link } from 'react-router-dom';
import { MenuGroupEnum } from '../../App/_root/data';
import { kebabCase } from 'lodash';
import { Layout } from '../../App';

const Home: FC = () => {
    const boxes = [
        {
            title: 'App',
            group: MenuGroupEnum.App,
            icon: <AppsOutlined fontSize="large" />,
        },
        {
            title: 'Form',
            group: MenuGroupEnum.Form,
            icon: <StorageRounded fontSize="large" />,
        },
        {
            title: 'Display',
            group: MenuGroupEnum.Display,
            icon: <WebAssetOutlined fontSize="large" />,
        },
        {
            title: 'Others',
            group: MenuGroupEnum.Others,
            icon: <LibraryAddOutlined fontSize="large" />,
        },
        {
            title: 'Hooks',
            group: MenuGroupEnum.Hooks,
            icon: <WebhookOutlined fontSize="large" />,
        },
        {
            title: 'Utils',
            group: MenuGroupEnum.Utils,
            icon: <SettingsOutlined fontSize="large" />,
        },
    ];

    return (
        <Layout showSidebar={false}>
            <Grid spacingType="common">
                <GridItem>
                    <Label align="center" text="Şekerbank React UI Library" />
                </GridItem>
                <GridItem pb={2}>
                    <Grid spacingType="common">
                        {Children.toArray(
                            boxes.map((item, index) => (
                                <GridItem key={`${String(index)}`} md={6} lg>
                                    <Link to={kebabCase(item.group)}>
                                        <Paper
                                            sx={{
                                                p: 5,
                                                textAlign: 'center',
                                                ':hover': {
                                                    borderColor: (theme) => theme.palette.green.main,
                                                    color: (theme) => theme.palette.green.main,

                                                    '.sekerUI-Label': {
                                                        [`.${typographyClasses.root}`]: {
                                                            color: (theme) => theme.palette.green.main,
                                                        },
                                                    },
                                                },
                                            }}>
                                            {item.icon}
                                            <Label design={DesignTypeEnum.Default} text={item.title} align="center" />
                                        </Paper>
                                    </Link>
                                </GridItem>
                            )),
                        )}
                    </Grid>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default Home;
