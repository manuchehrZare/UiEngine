import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { shellListener } from '../../../lib';

const ShellListenerPage: FC = (): JSX.Element => {
    shellListener((data) => {
        // eslint-disable-next-line no-console
        console.log('shellListenerData', data);
    });
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'shellListener' }} />
                        <Box p={1} px={3}>
                            <pre>
                                {`
shellListener((data) => {
    // Data from webview can be used in this field
});
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ShellListenerPage;
