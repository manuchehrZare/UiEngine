import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { stringDateToUnixtime } from '../../../lib';

const StringDateToUnixTimePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('yyyyMMdd', stringDateToUnixtime('20200625'));
    // eslint-disable-next-line no-console
    console.log('yyyyMM', stringDateToUnixtime('202006'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'stringDateToUnixtime' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log(stringDateToUnixtime('20200625'));
                                // output: 1593032400
                                `}
                            </pre>
                            <pre>
                                {`
                                console.log(stringDateToUnixtime('202006'));
                                // output: 1590958800
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StringDateToUnixTimePage;
