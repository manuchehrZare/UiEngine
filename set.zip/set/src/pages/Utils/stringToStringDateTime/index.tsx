import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { stringToStringDateTime } from '../../../lib';

const StringToStringDateTimePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('dd.mm.yyyy hh:mm', stringToStringDateTime('030520152003'));
    // eslint-disable-next-line no-console
    console.log('dd.mm.yyyy hh:mm:ss', stringToStringDateTime('03052015200315'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'stringToStringDateTime' }} />
                        <Box p={1}>
                            <pre>
                                {`
                               console.log(stringToStringDateTime('030520152003'));
                               // output: "03.05.2015 20:03"
                                `}
                            </pre>
                            <pre>
                                {`
                               console.log(stringToStringDateTime('03052015200315'));
                               // output: "03.05.2015 20:03:15"
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StringToStringDateTimePage;
