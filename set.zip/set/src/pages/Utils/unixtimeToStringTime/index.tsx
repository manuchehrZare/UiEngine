import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { unixtimeToStringTime } from '../../../lib';

const UnixtimeToStringTimePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('HHmmss', unixtimeToStringTime(1593032400));
    // eslint-disable-next-line no-console
    console.log('HHmm', unixtimeToStringTime(1691476200, 'HHmm'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'unixtimeToStringTime' }} />
                        <Box p={1}>
                            <pre>
                                {`
                            console.log(unixtimeToStringTime(1593032400));
                            // output: "145600"
                            `}
                            </pre>
                            <pre>
                                {`
                            console.log(unixtimeToStringTime(1691476200, 'HHmm'));
                            // output: "0930"
                            `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UnixtimeToStringTimePage;
