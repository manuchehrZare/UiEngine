import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../lib';
import {
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getReferenceData,
    useAxios,
} from '../../../lib';

const GetReferenceDataPage: FC = (): JSX.Element => {
    const [{ data: referenceDatas }] = useAxios<ReferenceDataResponse, ReferenceDataRequest>(
        {
            ...constants.api.endpoints.nova.gateway.referenceData.POST,
            data: {
                requestList: generateReferenceDataRequestList({
                    nameList: [
                        ReferenceDataEnum.PRM_CUST_CUSTTYPE,
                        ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                    ],
                }),
            },
        },
        { manual: false },
    );

    // eslint-disable-next-line no-console
    console.log(
        'getReferenceData',
        getReferenceData({ referenceDatas, referenceDataName: ReferenceDataEnum.PRM_CUST_CUSTTYPE }),
    );
    // eslint-disable-next-line no-console
    console.log(
        'getReferenceData filter',
        getReferenceData({
            referenceDatas,
            referenceDataName: ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
            filterValue: '1',
        }),
    );

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'getReferenceData' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log( getReferenceData({ referenceDatas, referenceDataName: ReferenceDataEnum.PRM_CUST_CUSTTYPE }));
                                // output: [
                                    {
                                        "filter": "",
                                        "key": "1",
                                        "value": "Gerçek Müşteri"
                                    },
                                    {
                                        "filter": "",
                                        "key": "2",
                                        "value": "Tüzel Müşteri"
                                    }
                                ]
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'getReferenceData Filter' }} />
                        <Box p={1}>
                            <pre>
                                {`console.log(
                                    getReferenceData({
                                        referenceDatas,
                                        referenceDataName: ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                                        filterValue: '1',
                                    })
                                )
                                // output: [
                                    {
                                        "filter": "1",
                                        "key": "367",
                                        "value": "ACIPAYAM"
                                    },     
                                    {
                                        "filter": "1",
                                        "key": "285",
                                        "value": "AĞRI"
                                    },
                                    {
                                        "filter": "1",
                                        "key": "303",
                                        "value": "AKÇAABAT"
                                    },
                                    ...
                                ]
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default GetReferenceDataPage;
