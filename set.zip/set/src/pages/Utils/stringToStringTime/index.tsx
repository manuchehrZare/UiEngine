import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { stringToStringTime } from '../../../lib';

const StringToStringTimePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('hh:mm:ss', stringToStringTime('162157'));
    // eslint-disable-next-line no-console
    console.log('hh:mm', stringToStringTime('1621'));
    // eslint-disable-next-line no-console
    console.log('hh', stringToStringTime('16'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'stringToStringTime' }} />
                        <Box p={1}>
                            <pre>
                                {`
                               console.log(stringToStringTime('162157'));
                               // output: "16:21:57"
                                `}
                            </pre>
                            <pre>
                                {`
                               console.log(stringToStringTime('1621'));
                               // output: "16:21"
                                `}
                            </pre>
                            <pre>
                                {`
                               console.log(stringToStringTime('16'));
                               // output: "16"
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StringToStringTimePage;
