import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { getGenericSetCaller } from '../../../lib';

const GetGenericSetCallerPage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log(getGenericSetCaller('test_endpoint', 'GET'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'getGenericSetCaller' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log(getGenericSetCaller('test_endpoint', 'GET'));
                                // output: {url: '/nova/gateway/genericSetCaller/test_endpoint', method: 'GET'}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default GetGenericSetCallerPage;
