import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { unixtimeToStringDate } from '../../../lib';

const UnixtimeToStringDatePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('yyyyMM', unixtimeToStringDate(1243803600, 'yyyyMM'));
    // eslint-disable-next-line no-console
    console.log('yyyyMMdd', unixtimeToStringDate(1593032400));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'unixtimeToStringDate' }} />
                        <Box p={1}>
                            <pre>
                                {`
                            console.log(unixtimeToStringDate(1593032400));
                            // output: "20200625"
                            `}
                            </pre>
                            <pre>
                                {`
                            console.log(unixtimeToStringDate(1243803600, 'yyyyMM'));
                            // output: "200906"
                            `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UnixtimeToStringDatePage;
