import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { stringTimeToUnixtime } from '../../../lib';

const StringTimeToUnixtimePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log(stringTimeToUnixtime('145600'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'stringTimeToUnixtime' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log(stringTimeToUnixtime('145600'));
                                // output: 1593032400
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StringTimeToUnixtimePage;
