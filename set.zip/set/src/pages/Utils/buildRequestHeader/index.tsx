import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { buildRequestHeader } from '../../../lib';

const BuildRequestHeaderPage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log(buildRequestHeader());

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'buildRequestHeader' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log(buildRequestHeader());
                                // Return Request Header Params
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default BuildRequestHeaderPage;
