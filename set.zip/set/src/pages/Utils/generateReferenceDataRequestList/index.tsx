import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { generateReferenceDataRequestList } from '../../../lib';

const GenerateReferenceDataRequestListPage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('generateReferenceDataRequestList', generateReferenceDataRequestList({ nameList: ['PRM_1', 'PRM_2'] }));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'generateReferenceDataRequestList' }} />
                        <Box p={1} px={5}>
                            <pre>
                                {`
console.log(generateReferenceDataRequestList({ nameList: ['PRM_1', 'PRM_2'] }));
// Return requestList for ReferenceData service
${JSON.stringify(generateReferenceDataRequestList({ nameList: ['PRM_1', 'PRM_2'] }), null, 4)}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default GenerateReferenceDataRequestListPage;
