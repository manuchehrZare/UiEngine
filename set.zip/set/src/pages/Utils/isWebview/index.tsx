import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { isWebview } from '../../../lib';

const IsWebviewPage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('isWebview', isWebview());

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'isWebview' }} />
                        <Box p={1} px={3}>
                            <pre>
                                {`
if (isWebview()) {
    // Webview
} else {
    // Not Webview
}
// output: true | false
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default IsWebviewPage;
