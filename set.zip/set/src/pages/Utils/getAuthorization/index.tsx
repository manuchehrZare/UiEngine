import { HttpStatusCode } from 'axios';
import useAxios from 'axios-hooks';
import type { FC, JSX } from 'react';
import { useEffect } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import type { AuthenticateResponse } from '../../../lib';
import { constants, getAuthorization } from '../../../lib';

const GetAuthorizationPage: FC = (): JSX.Element => {
    const [, authenticateRequest] = useAxios<AuthenticateResponse>(
        {
            url: 'https://run.mocky.io/v3/9f8e686a-873e-4da4-939d-3e6eeafe0790',
        },
        { manual: true },
    );

    const callAuthenticateRequest = async () => {
        const authenticateResponse = await authenticateRequest();

        if (authenticateResponse.status === HttpStatusCode.Ok) {
            // eslint-disable-next-line no-console
            console.log('getAuthorization : ', getAuthorization(authenticateResponse.data.token));
        }
    };

    useEffect(() => {
        callAuthenticateRequest();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'getAuthorization' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log(getAuthorization());
                                // output: It returns the token value in the storage with the ${constants.key.SET_AUTH} key.

                                console.log(
                                    getAuthorization(authenticateResponse.data.token),
                                );
                                // output: Bearer ...Token...
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default GetAuthorizationPage;
