import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { stringToStringDate } from '../../../lib';

const StringToStringDatePage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('dd.mm.yyyy', stringToStringDate('20230330'));
    // eslint-disable-next-line no-console
    console.log('mm.yyyy', stringToStringDate('202303'));
    // eslint-disable-next-line no-console
    console.log('yyyy', stringToStringDate('2023'));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'stringToStringDate' }} />
                        <Box p={1}>
                            <pre>
                                {`
                                console.log(stringToStringDate('20230330'));
                                // output: "30.03.2023"
                                `}
                            </pre>
                            <pre>
                                {`
                                console.log(stringToStringDate('202303'));
                                // output: "03.2023"
                                `}
                            </pre>
                            <pre>
                                {`
                                console.log(stringToStringDate('2023'));
                                // output: "2023"
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default StringToStringDatePage;
