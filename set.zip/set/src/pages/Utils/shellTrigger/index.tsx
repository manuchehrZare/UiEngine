import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import { ShellProcessTypeEnum, shellTrigger } from '../../../lib';

const ShellTriggerPage: FC = (): JSX.Element => {
    // eslint-disable-next-line no-console
    console.log('shellTrigger', shellTrigger({ processType: ShellProcessTypeEnum.Screen, data: 'shell' }));

    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'shellListener' }} />
                        <Box p={1} px={3}>
                            <pre>
                                {`
console.log('shellTrigger', shellTrigger({ processType: ShellProcessTypeEnum.Screen, data: 'shell' }));
// output: 
{
    "processType": 3,
    "data": "shell"
}
                                `}
                            </pre>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default ShellTriggerPage;
