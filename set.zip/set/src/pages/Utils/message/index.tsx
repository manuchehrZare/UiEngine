import type { FC, JSX } from 'react';
import { Box, Button, Grid, GridItem, message, MessageTypeEnum, Nav, Paper } from 'seker-ui';
import { Layout } from '../../../App';
import type { ResponseError } from '../../../lib';
import { constants } from '../../../lib';

const Message: FC = (): JSX.Element => {
    const str = '<b>SET-Nova :</b> Hello World! <br /> Custom message';
    const oneLineText =
        '/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText/CustomMessageContent/OneLineText';
    const paragraph =
        'Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero officiis veritatis consectetur quo rerum nam deleniti eligendi repellendus dolores tenetur adipisci similique in, minima quam modi ea nobis rem provident? Accusantium, esse possimus! Labore doloribus voluptatem quae illum tempore molestias, impedit neque magni aliquam rem! Sapiente, illo? Exercitationem possimus totam suscipit, eligendi non cumque nisi fugiat, obcaecati, labore quasi sit.';
    const errorResponse = {
        config: {
            [`${constants.key.path}`]: '/custom/path',
            url: '/custom/error/path/custom/error/path/custom/error/path',
            headers: {
                [`${constants.key.x_requestId}`]: 'xyz123xyz123xyz123',
            },
        },
    };
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'Message', subTitle: 'This method uses from SekerUI Library' }} />
                        <Box p={1}>
                            <Grid spacingType="button">
                                <GridItem xs={false}>
                                    <Button
                                        text="Default"
                                        onClick={() => {
                                            message({ variant: MessageTypeEnum.default, message: str });
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="Success"
                                        onClick={() => {
                                            message({ variant: MessageTypeEnum.success, message: str });
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="Info"
                                        onClick={() => {
                                            message({ variant: MessageTypeEnum.info, message: str });
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="Error"
                                        onClick={() => {
                                            message({
                                                variant: MessageTypeEnum.error,
                                                message: str,
                                                persist: true,
                                                error: {
                                                    message: str,
                                                    name: 'Error',
                                                    isAxiosError: true,
                                                    toJSON: null,
                                                },
                                            } as any);
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="ErrorMessageContent"
                                        onClick={() => {
                                            message({
                                                variant: MessageTypeEnum.error,
                                                message: str,
                                                persist: true,
                                                error: {
                                                    message: str,
                                                    name: 'Error',
                                                    isAxiosError: true,
                                                    toJSON: null,
                                                    config: errorResponse.config as any,
                                                    response: {
                                                        data: {
                                                            error: 'Custom Error',
                                                            errorCode: 0,
                                                            message: str,
                                                            path: errorResponse.config.path,
                                                            status: 400,
                                                            timestamp: 'Custom Error TimeStamp',
                                                            trace: 'Custom Error Trace',
                                                        } as ResponseError,
                                                    },
                                                } as any,
                                            } as any);
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="Warning"
                                        onClick={() => {
                                            message({ variant: MessageTypeEnum.warning, message: str });
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="Example Paragraph"
                                        onClick={() => {
                                            message({ variant: MessageTypeEnum.error, message: paragraph });
                                        }}
                                    />
                                </GridItem>
                                <GridItem xs={false}>
                                    <Button
                                        text="Example 1 Line Text"
                                        onClick={() => {
                                            message({ variant: MessageTypeEnum.error, message: oneLineText });
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Box>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default Message;
