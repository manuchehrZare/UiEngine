import type { FC } from 'react';
import { Layout } from '../../../App';
import { Button, Grid, GridItem, Nav, Paper, PdfViewer } from 'seker-ui';
import { GenericSetCallerEnum, useJReportAxios } from '../../../lib';

interface IJReportScreensWithProcessAndScreenActionDataParameters {
    COMPONENT_GROUP_OID?: string;
    COMPONENT_OID?: string;
    DATA_CODE?: string;
    PROCESS_BEGIN_DATE?: string;
    PROCESS_END_DATE?: string;
    PROCESS_GROUP_OID?: string;
    PROCESS_ID?: string;
    PROCESS_OPERATION_TYPE?: string;
    SCREEN_ACTION_OID?: string;
    SCREEN_BEGIN_DATE?: string;
    SCREEN_CODE?: string;
    SCREEN_END_DATE?: string;
    SCREEN_OPERATION_TYPE?: string;
    USER_SORT_KEY?: string;
}

interface IJReportScreensWithProcessAndScreenActionReportParameters {
    USER_FULL_NAME: string;
}

interface IJReportUsersWithProfileDataParameters {
    ALL_USERS: string;
    ORG_UNIT_OID?: string;
    ORGANIZATION_OID?: string;
    PROFILE_ASSIGNMENT_TYPE: string;
    PROFILE_OID?: string;
    TITLE_OID?: string;
    USER_ACTIVE: string;
    USER_LOGIN: string;
    USER_SORT_KEY: string;
    USER_STATUS: string;
}
interface IJReportUsersWithProfilReportParameters {
    USER_FULL_NAME: string;
}

const UseJReportAxiosPage: FC = () => {
    const [
        { response: adminMenuReportScreensWithProcessAndScreenActionResponse },
        adminMenuReportScreensWithProcessAndScreenActionCall,
    ] = useJReportAxios<
        IJReportScreensWithProcessAndScreenActionReportParameters,
        IJReportScreensWithProcessAndScreenActionDataParameters
    >({ coreService: GenericSetCallerEnum.ADMIN_MENU_REPORT_SCREENS_WITH_PROCESS_AND_SCREEN_ACTION });

    const [{ response: usersWithProfileResponse }, usersWithProfileCall] = useJReportAxios<
        IJReportUsersWithProfilReportParameters,
        IJReportUsersWithProfileDataParameters
    >({ coreService: GenericSetCallerEnum.ADMIN_USR_REPORT_USERS_WITH_PROFILE });

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'screensWithProcessAndScreenAction' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem xs="auto">
                                        <Button
                                            text="Call jReport - Success"
                                            onClick={() =>
                                                adminMenuReportScreensWithProcessAndScreenActionCall({
                                                    data: {
                                                        reportId: 'screensWithProcessAndScreenAction',
                                                        dataParameters: {
                                                            COMPONENT_GROUP_OID: '',
                                                            COMPONENT_OID: '',
                                                            DATA_CODE: '',
                                                            PROCESS_BEGIN_DATE: '20230801',
                                                            PROCESS_END_DATE: '20230830',
                                                            PROCESS_GROUP_OID: '',
                                                            PROCESS_ID: '',
                                                            PROCESS_OPERATION_TYPE: 'U',
                                                            SCREEN_ACTION_OID: '',
                                                            SCREEN_BEGIN_DATE: '',
                                                            SCREEN_CODE: '',
                                                            SCREEN_END_DATE: '',
                                                            SCREEN_OPERATION_TYPE: '',
                                                            USER_SORT_KEY: 'screenCode',
                                                        },
                                                        reportParameters: { USER_FULL_NAME: 'SERDAR DEMİROĞLU' },
                                                    },
                                                })
                                            }
                                        />
                                    </GridItem>
                                    <GridItem xs="auto">
                                        <Button
                                            text="Call jReport - Error"
                                            color="error"
                                            onClick={() =>
                                                adminMenuReportScreensWithProcessAndScreenActionCall({
                                                    data: {
                                                        reportId: 'screensWithProcessAndScreenAction',
                                                        dataParameters: {
                                                            COMPONENT_GROUP_OID: '',
                                                            COMPONENT_OID: '',
                                                            DATA_CODE: '',
                                                            PROCESS_BEGIN_DATE: '20240304',
                                                            PROCESS_END_DATE: '20240304',
                                                            PROCESS_GROUP_OID: '',
                                                            PROCESS_ID: '',
                                                            PROCESS_OPERATION_TYPE: 'I',
                                                            SCREEN_ACTION_OID: '',
                                                            SCREEN_BEGIN_DATE: '',
                                                            SCREEN_CODE: '',
                                                            SCREEN_END_DATE: '',
                                                            SCREEN_OPERATION_TYPE: '',
                                                            USER_SORT_KEY: 'screenCode',
                                                        },
                                                        reportParameters: { USER_FULL_NAME: 'SERDAR DEMİROĞLUA' },
                                                    },
                                                })
                                            }
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem>
                                <Grid>
                                    <GridItem height={500}>
                                        <PdfViewer
                                            source={
                                                adminMenuReportScreensWithProcessAndScreenActionResponse?.data
                                                    ?.pdfContent
                                            }
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'usersWithProfile' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem xs="auto">
                                        <Button
                                            text="Call jReport - Success"
                                            onClick={() =>
                                                usersWithProfileCall({
                                                    data: {
                                                        reportParameters: {
                                                            USER_FULL_NAME: 'SERDAR DEMİROĞLU',
                                                        },
                                                        dataParameters: {
                                                            ALL_USERS: 'false',
                                                            PROFILE_ASSIGNMENT_TYPE: '',
                                                            USER_ACTIVE: '1',
                                                            USER_LOGIN: '1',
                                                            USER_SORT_KEY: 'organizationCode',
                                                            USER_STATUS: '',
                                                            ORG_UNIT_OID: '',
                                                            ORGANIZATION_OID: '01wcxce6z1qxjq2h',
                                                            PROFILE_OID: '',
                                                            TITLE_OID: '',
                                                        },
                                                        reportId: 'usersWithProfile',
                                                    },
                                                })
                                            }
                                        />
                                    </GridItem>
                                    <GridItem xs="auto">
                                        <Button
                                            text="Call jReport - Error"
                                            color="error"
                                            onClick={() =>
                                                usersWithProfileCall({
                                                    data: {
                                                        reportParameters: {
                                                            USER_FULL_NAME: 'SERDAR DEMİROĞLU',
                                                        },
                                                        dataParameters: {
                                                            ALL_USERS: 'false',
                                                            PROFILE_ASSIGNMENT_TYPE: '',
                                                            USER_ACTIVE: '1',
                                                            USER_LOGIN: '1',
                                                            USER_SORT_KEY: 'organizationCode',
                                                            USER_STATUS: '',
                                                            ORG_UNIT_OID: '',
                                                            ORGANIZATION_OID: '01wcxce6z1qxjq2h',
                                                            PROFILE_OID: '',
                                                            TITLE_OID: '',
                                                        },
                                                        reportId: 'usersWithProfileasd',
                                                    },
                                                })
                                            }
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <GridItem>
                                <Grid>
                                    <GridItem height={500}>
                                        <PdfViewer source={usersWithProfileResponse?.data?.pdfContent} />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseJReportAxiosPage;
