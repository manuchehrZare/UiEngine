import type { FC } from 'react';
import { useEffect } from 'react';
import { Layout } from '../../../App';
import { Button, Grid, GridItem, Label, Nav, Paper, View } from 'seker-ui';
import type { AxiosRequestConfig } from '../../../lib';
import { useAxios } from '../../../lib';
import { format as prettyFormat } from 'pretty-format';

const UseAxiosPage: FC = () => {
    const [{ data: usersData, loading: usersLoading }] = useAxios({
        url: 'https://jsonplaceholder.typicode.com/users?id=1',
        disableAuthControl: true,
        disableLoadingView: true,
    });

    const [{ data: todosData, loading: todosLoading }, todosRequest] = useAxios(
        {
            url: 'https://jsonplaceholder.typicode.com/todos?userId=1',
            disableLoadingView: true,
        },
        { manual: true },
    );

    const [{ data: postsData, loading: postsLoading }, postsRequest] = useAxios(
        {
            url: 'https://jsonplaceholder.typicode.com/posts?userId=1',
            disableLoadingView: true,
        },
        { manual: true },
    );

    const handleClick = async (options?: Pick<AxiosRequestConfig, 'disableAuthControl' | 'disableLoadingView'>) => {
        await todosRequest(options);
    };

    useEffect(() => {
        todosRequest();
        const timeOut = setTimeout(() => {
            postsRequest();
        }, 2000);
        return () => {
            clearTimeout(timeOut);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Layout>
            <Grid spacingType="common">
                <GridItem>
                    <Paper>
                        <Nav navTitleProps={{ title: 'DisableLoading' }} />
                        <Grid spacingType="common">
                            <GridItem>
                                <Grid spacingType="button">
                                    <GridItem xs="auto">
                                        <Button
                                            disabled={usersLoading || todosLoading || postsLoading}
                                            text="DisableLoading : false - Todos"
                                            onClick={() => handleClick({ disableLoadingView: false })}
                                        />
                                    </GridItem>
                                    <GridItem xs="auto">
                                        <Button
                                            disabled={usersLoading || todosLoading || postsLoading}
                                            text="DisableLoading : true - Todos"
                                            onClick={() => handleClick({ disableLoadingView: true })}
                                        />
                                    </GridItem>
                                </Grid>
                            </GridItem>
                            <View show={Boolean(usersData) && !usersLoading}>
                                <GridItem>
                                    <Label text="Users" color={(theme) => theme.palette.common.black} />
                                    <Grid>
                                        <GridItem>
                                            {prettyFormat(usersData, { printBasicPrototype: false, indent: 4 })}
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </View>
                            <View show={Boolean(todosData) && !todosLoading}>
                                <GridItem>
                                    <Label text="Todos" color={(theme) => theme.palette.common.black} />
                                    <Grid>
                                        <GridItem>
                                            {prettyFormat(todosData, { printBasicPrototype: false, indent: 4 })}
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </View>
                            <View show={Boolean(postsData) && !postsLoading}>
                                <GridItem>
                                    <Label text="Posts" color={(theme) => theme.palette.common.black} />
                                    <Grid>
                                        <GridItem>
                                            {prettyFormat(postsData, { printBasicPrototype: false, indent: 4 })}
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </View>
                        </Grid>
                    </Paper>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default UseAxiosPage;
