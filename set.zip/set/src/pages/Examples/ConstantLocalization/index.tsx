import type { FC } from 'react';
import { Grid, GridItem } from 'seker-ui';
import { Layout } from '../../../App';
import { translations } from '../../../lib/utils/constants/translations';

const ConstantLocalizationPage: FC = () => {
    return (
        <Layout>
            <Grid>
                <GridItem>{translations.api.timeoutErrorMessage}</GridItem>
                <GridItem>{translations.app.title}</GridItem>
            </Grid>
        </Layout>
    );
};

export default ConstantLocalizationPage;
