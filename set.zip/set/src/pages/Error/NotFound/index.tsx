import type { FC } from 'react';
import { Grid, GridItem, Label } from 'seker-ui';
import { Layout } from '../../../App';
import { useTranslation } from '../../../lib';

const NotFound: FC = () => {
    const { t, locale } = useTranslation();
    return (
        <Layout>
            <Grid>
                <GridItem>
                    <Label
                        text={t(locale.common.screenNotFound)}
                        align="center"
                        color={(theme) => theme.palette.error.main}
                    />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NotFound;
