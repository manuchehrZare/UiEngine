import type { ReactNode } from 'react';
import type { IBoxProps, ICustomScrollValues, MeasureValues } from 'seker-ui';

export interface ILayout {
    children: any;
    showSidebar?: boolean;
}
export type LayoutMeasures = {
    content: MeasureValues;
    footer: MeasureValues;
    header: MeasureValues;
    sidebar: MeasureValues;
};

export type LayoutProps = Pick<IBoxProps, 'sx'> & {
    children: ReactNode;
    onContentScrollChange?: (values: ICustomScrollValues) => void;
    onMeasureChange?: (measure: LayoutMeasures) => void;
    showFooter?: boolean;
    showHeader?: boolean;
    showSidebar?: boolean;
    title?: string;
};

export const initialLayoutMeasure: LayoutMeasures = { content: {}, footer: {}, header: {}, sidebar: {} };
