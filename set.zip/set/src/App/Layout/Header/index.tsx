import type { FC } from 'react';
import { memo } from 'react';
import { Box, TabItem, Tab, DesignTypeEnum, useForm, Select, getLocalStorageItem, Typography } from 'seker-ui';

import { menu } from '../../_root/data';
import { capitalize, kebabCase } from 'lodash';
import { languageStorageKey, useTranslation } from '../../../lib';
import { changeAppLanguage } from '../../../utils';
import { useLocation, useNavigate } from 'react-router-dom';

const Header: FC = () => {
    const { t, locale, i18n } = useTranslation();
    const navigate = useNavigate();
    const location = useLocation();

    const { control, setValue } = useForm({
        defaultValues: {
            language: getLocalStorageItem<string>(languageStorageKey) || '',
        },
    });

    const redirect = (slug: string) => {
        navigate(`/${slug}`);
    };

    return (
        <Box
            component="header"
            sx={{
                position: 'fixed',
                left: 0,
                top: 0,
                height: 48,
                width: '100%',
                borderBottom: (theme) => `1px solid ${theme.palette.grey[300]}`,
                zIndex: (theme) => theme.zIndex.appBar,
                // background: 'white',
            }}>
            <Box height="100%" sx={{ pl: 2, pr: 2, display: 'flex', alignItems: 'center', width: '100%' }}>
                <Box flexShrink={0} sx={{ minWidth: 200, cursor: 'pointer' }} onClick={() => redirect('')}>
                    <Typography variant="h5">{import.meta.env.VITE_APP_NAME}</Typography>
                </Box>
                <Tab
                    design={DesignTypeEnum.Default}
                    value={location.pathname.split('/')[1]}
                    onChange={(val) => redirect(val)}
                    sx={{ height: '100%' }}>
                    <TabItem text="Home" value="" />
                    {Object.keys(menu).map((item, index) => (
                        <TabItem key={`${item}-${String(index)}`} text={capitalize(item)} value={kebabCase(item)} />
                    ))}
                </Tab>
                <Box ml="auto" flexShrink={0}>
                    <Select
                        name="language"
                        control={control}
                        label={t(locale.labels.language)}
                        labelPlacement="start"
                        setValue={setValue}
                        labelWidth={60}
                        options={{
                            data: i18n.languages?.map((lang) => ({
                                name: t((locale.languages as any)[lang]),
                                value: lang,
                            })),
                            displayField: 'name',
                            displayValue: 'value',
                        }}
                        onChange={(e) => changeAppLanguage({ lng: e })}
                    />
                </Box>
            </Box>
        </Box>
    );
};

export default memo(Header);
