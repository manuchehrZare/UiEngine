import { type JSX, memo, useEffect, type FC } from 'react';
import type { LayoutProps } from './type';
import { Box, CustomScrollbar, useMeasure, useTitle, View } from 'seker-ui';
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';
import { ReactComponent as Logo } from '../../assets/images/logo_mini_lightgrey.svg';
import { constants } from '../../utils/constants';

const Layout: FC<LayoutProps> = ({
    children,
    title,
    sx,
    onMeasureChange,
    onContentScrollChange,
    showFooter = true,
    showHeader = true,
    showSidebar = true,
}): JSX.Element => {
    const sidebarMeasure = useMeasure();
    const headerMeasure = useMeasure();
    const footerMeasure = useMeasure();
    const contentMeasure = useMeasure();

    useEffect(() => {
        onMeasureChange &&
            onMeasureChange({
                content: contentMeasure.values,
                footer: footerMeasure.values || constants.common.layout.FOOTER_HEIGHT,
                header: headerMeasure.values || constants.common.layout.HEADER_HEIGHT,
                sidebar: sidebarMeasure.values || constants.common.layout.SIDEBAR_WIDTH,
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [sidebarMeasure.values, footerMeasure.values, headerMeasure.values, contentMeasure.values]);

    useTitle(`${import.meta.env.VITE_APP_TITLE}${title ? ` | ${title}` : ''}`);
    return (
        <>
            <View show={showHeader}>
                <Header ref={headerMeasure.ref} />
            </View>
            <View show={showSidebar}>
                <Sidebar
                    ref={sidebarMeasure.ref}
                    layoutMeasures={{
                        content: contentMeasure.values,
                        footer: footerMeasure.values || constants.common.layout.FOOTER_HEIGHT,
                        header: headerMeasure.values || constants.common.layout.HEADER_HEIGHT,
                        sidebar: sidebarMeasure.values || constants.common.layout.SIDEBAR_WIDTH,
                    }}
                />
            </View>
            <Box
                ref={contentMeasure.ref}
                className="content"
                component="div"
                sx={{
                    position: 'relative',
                    ...(sidebarMeasure?.node && {
                        width: `calc(100% - ${sidebarMeasure.values.width || constants.common.layout.SIDEBAR_WIDTH}px)`,
                        left: sidebarMeasure.values.width || constants.common.layout.SIDEBAR_WIDTH,
                    }),
                    ...(headerMeasure?.node && {
                        top: headerMeasure.values.height || constants.common.layout.HEADER_HEIGHT,
                    }),
                    backgroundColor: (theme) => theme.palette.common.white,
                    ...sx,
                }}>
                <View show>
                    <Box
                        width={{ xs: '40%', md: 'auto' }}
                        sx={{
                            position: 'fixed',
                            left: `calc(50% + ${constants.common.layout.SIDEBAR_WIDTH / 2}px)`,
                            top: '50%',
                            translate: '-50% -50%',
                            zIndex: 0,
                        }}>
                        <Logo width="100%" />
                    </Box>
                </View>
                <CustomScrollbar
                    className="content-scroll"
                    thickness={8}
                    onUpdate={(values) => {
                        onContentScrollChange && onContentScrollChange(values);
                    }}
                    viewProps={{
                        sx: {
                            ...((showFooter || showHeader || showSidebar) && {
                                px: constants.design.padding.layout.x.unit,
                            }),
                        },
                    }}
                    height={
                        headerMeasure?.node && footerMeasure?.node
                            ? `calc(100vh - ${(headerMeasure?.values?.height ?? constants.common.layout.HEADER_HEIGHT) + (footerMeasure?.values?.height ?? constants.common.layout.FOOTER_HEIGHT)}px)`
                            : '100vh'
                    }>
                    {children}
                </CustomScrollbar>
            </Box>
            <View show={showFooter}>
                <Footer ref={footerMeasure.ref} />
            </View>
        </>
    );
};

export { Footer, Header, Sidebar };
export default memo(Layout);
