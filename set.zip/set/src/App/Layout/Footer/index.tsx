import { format } from 'date-fns';
import type { FC, JSX } from 'react';
import { forwardRef, Fragment, memo } from 'react';
import type { IBoxProps } from 'seker-ui';
import { Box, Divider, Grid, GridItem, pickerProps, useNow, View } from 'seker-ui';
import { getGlobalsData, GlobalsItemEnum } from '../../../lib';
import { v4 as uuidv4 } from 'uuid';
import { constants } from '../../../utils/constants';

interface IFooterProps extends Pick<IBoxProps, 'ref'> {}

const Footer: FC<IFooterProps> = forwardRef((props: IFooterProps, ref): JSX.Element => {
    const { days, hours, milliseconds, minutes, months, seconds, years } = useNow();
    const formattedNow = () =>
        format(
            new Date(years, months, days, hours, minutes, seconds, milliseconds),
            pickerProps.SET.dateTimePicker.inputFormat.replace(':ss', ''),
        );
    const footerGlobalKeys = [
        GlobalsItemEnum.ChargedOrgUnitCode,
        GlobalsItemEnum.Version,
        GlobalsItemEnum.UserName,
        GlobalsItemEnum.OrganizationCode,
        GlobalsItemEnum.UserFullName,
        GlobalsItemEnum.EnvironmentType,
    ];

    return (
        <Box
            ref={ref}
            component="footer"
            position="fixed"
            display="flex"
            alignItems="center"
            px={2}
            bottom={0}
            width="100%"
            height={constants.common.layout.FOOTER_HEIGHT}
            bgcolor={(theme) => theme.palette.secondary.main}
            sx={{ color: (theme) => theme.palette.common.white }}
            zIndex={(theme) => theme.zIndex.appBar}
            {...props}>
            <View show>
                <Grid spacing={0.75} width="100%">
                    {footerGlobalKeys.map((footerGlobalKey) => {
                        return (
                            <Fragment key={uuidv4()}>
                                <View show={!(footerGlobalKey === GlobalsItemEnum.Version)}>
                                    <GridItem xs={false}>
                                        {footerGlobalKey === GlobalsItemEnum.Version
                                            ? 'V1'
                                            : getGlobalsData({ key: footerGlobalKey })}
                                    </GridItem>
                                </View>
                                <View show>
                                    <GridItem xs={false}>
                                        <Divider orientation="vertical" />
                                    </GridItem>
                                </View>
                            </Fragment>
                        );
                    })}
                    <GridItem xs={false} ml="auto">
                        {formattedNow()}
                    </GridItem>
                </Grid>
            </View>
        </Box>
    );
});

export default memo(Footer);
