import type { FC } from 'react';
import { memo } from 'react';
import { Box, CustomScrollbar, MenuItem, MenuList } from 'seker-ui';
import { camelCase, kebabCase, toLower, toUpper } from 'lodash';
import { useLocation, useNavigate } from 'react-router-dom';
import { menuData } from '../../_root/data';

const Sidebar: FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const redirect = (slug: string, type: string) => {
        navigate(`/${type}/${slug}`);
    };
    return (
        <Box
            component="aside"
            sx={{
                position: 'fixed',
                left: 0,
                top: 48,
                height: 'calc(100vh - 48px)',
                width: 216,
                borderRight: (theme) => `1px solid ${theme.palette.grey[300]}`,
            }}>
            <CustomScrollbar height="100%" thickness={4}>
                <MenuList dense>
                    {menuData
                        .filter((item) => toUpper(item.group) === toUpper(location.pathname.split('/')[1]))
                        .map((item) => (
                            <MenuItem
                                disabled={!item.element}
                                onClick={() => redirect(kebabCase(item.text), toLower(item.group))}
                                key={camelCase(item.text)}>
                                {item.text}
                            </MenuItem>
                        ))}
                </MenuList>
            </CustomScrollbar>
        </Box>
    );
};

export default memo(Sidebar);
