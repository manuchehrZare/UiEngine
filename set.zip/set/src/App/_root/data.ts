/** Components Import */
// * App Components
import FooterPage from '../../pages/Components/App/Footer';
import LoginPage from '../../pages/Components/App/Auth/Login';
import LogoutPage from '../../pages/Components/App/Auth/Logout';
import NotFoundPage from '../../pages/Components/App/Error/NotFound';
// * Form Components
// ** Buttons
import CloseAppButtonPage from '../../pages/Components/Form/_Common/Buttons/CloseAppButton';
import ClosePageButtonPage from '../../pages/Components/Form/_Common/Buttons/ClosePageButton';
import DeleteButtonPage from '../../pages/Components/Form/_Common/Buttons/DeleteButton';
import MenuButtonPage from '../../pages/Components/Form/_Common/Buttons/MenuButton';
import SaveButtonPage from '../../pages/Components/Form/_Common/Buttons/SaveButton';
// ** Inputs
import PasswordInputInputPage from '../../pages/Components/Form/_Common/Inputs/PasswordInput';
import RegistryNoInputInputPage from '../../pages/Components/Form/_Common/Inputs/RegistryNoInput';
// * Other Components
import ModalViewerPage from '../../pages/Components/Others/ModalViewer';
import DmsDocumentViewerPage from '../../pages/Components/Others/DmsDocumentViewer';
// * Display Components
// ** Modals
// *** Infrastructure
import BpmProcessDefinitionSelectionModalPage from '../../pages/Components/Display/Infrastructure/Modals/BpmProcessDefinitionSelectionModal';
import BpmProcessSelectionModalPage from '../../pages/Components/Display/Infrastructure/Modals/BpmProcessSelectionModal';
import DocumentTypesPage from '../../pages/Components/Display/Infrastructure/Modals/DocumentTypes';
import EprocProcessDefinitionSelectionModalPage from '../../pages/Components/Display/Infrastructure/Modals/EprocProcessDefinitionSelectionModal';
import EprocProcessSelectionModalPage from '../../pages/Components/Display/Infrastructure/Modals/EprocProcessSelectionModal';
import ExtractModalPage from '../../pages/Components/Display/Infrastructure/Modals/ExtractModal';
import InstitutionSelectionModalPage from '../../pages/Components/Display/Infrastructure/Modals/InstitutionSelectionModal';
import UnitInquiryModalPage from '../../pages/Components/Display/Infrastructure/Modals/UnitInquiryModal';
import UserInquiryModalPage from '../../pages/Components/Display/Infrastructure/Modals/UserInquiryModal';
// *** Basebanking
import AccountSelectionModalPage from '../../pages/Components/Display/BaseBanking/Modals/DepositsAndAccounting/AccountSelectionModal';
import AssetSelectionModalPage from '../../pages/Components/Display/BaseBanking/Modals/Invest/AssetSelectionModal';
import ChecksBillsForeignTradeBicCodeListModalPage from '../../pages/Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/ChecksBillsForeignTradeBicCodeListModal';
import CustomerInquiryModalPage from '../../pages/Components/Display/BaseBanking/Modals/Customer/CustomerInquiryModal';
import DepositAccountInquiryModalPage from '../../pages/Components/Display/BaseBanking/Modals/DepositsAndAccounting/DepositAccountInquiryModal';
import FTCCommonStatisticsModalPage from '../../pages/Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/FTCCommonStatisticsModal';
import FilesModalPage from '../../pages/Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/FilesModal';
import InvestBicCodeListModalPage from '../../pages/Components/Display/BaseBanking/Modals/Invest/InvestBicCodeListModal';
import JointCustomerInquiryModalPage from '../../pages/Components/Display/BaseBanking/Modals/Customer/JointCustomerInquiryModal';
import NostroAccountListModalPage from '../../pages/Components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/NostroAccountListModal';
// *** Loans
import CollateralSelectionModalPage from '../../pages/Components/Display/Loans/Modals/CorporateLoans/Allotment/CollateralSelectionModal';
import InterlocutorInquiryModalPage from '../../pages/Components/Display/Loans/Modals/CorporateLoans/CreditUsage/InterlocutorInquiryModal';
import LoanRequestFormSelectionModalPage from '../../pages/Components/Display/Loans/Modals/CorporateLoans/CreditUsage/LoanRequestFormSelectionModal';
import PersonalLoanApplicationInquiryModalPage from '../../pages/Components/Display/Loans/Modals/ConsumerLoans/PersonalLoanApplicationInquiryModal';
import ProductDisbursementFeaturesModalPage from '../../pages/Components/Display/Loans/Modals/CorporateLoans/Allotment/ProductDisbursementFeaturesModal';
import ProductSelectionPage from '../../pages/Components/Display/Loans/Modals/CorporateLoans/Allotment/ProductSelectionModal';
// *** PaymentSystems
import CardInquiryModalPage from '../../pages/Components/Display/PaymentSystems/Modals/CardSystems/CardInquiryModal';
// ** PageContent
// *** PaymentSystems
import UTC005Page from '../../pages/Components/Display/PaymentSystems/PageContent/POS/UTC005';
// ** Regions
// *** Basebanking
import CustomerInfoRegionPage from '../../pages/Components/Display/BaseBanking/Regions/Customer/CustomerInfoRegion';
//
// *** PaymentSystems
import AccountShortInfoRegionPage from '../../pages/Components/Display/PaymentSystems/Regions/CardSystems/AccountShortInfoRegion';
import AccountSearchRegionPage from '../../pages/Components/Display/PaymentSystems/Regions/CardSystems/AccountSearchRegion';
import BankAccountInfoRegionPage from '../../pages/Components/Display/PaymentSystems/Regions/CardSystems/BankAccountInfoRegion';
// *** Loans
import CommonCurrencyValueRegionPage from '../../pages/Components/Display/Loans/Regions/CorporateLoans/CreditUsage/CommonCurrencyValueRegion';
import CommonCurrencyValueTesterRegionPage from '../../pages/Components/Display/Loans/Regions/CorporateLoans/CreditUsage/CommonCurrencyValueTesterRegion';
import CommonFilePickerRegionPage from '../../pages/Components/Display/Loans/Regions/CorporateLoans/CreditUsage/CommonFilePicker';
import FormulaDetailRegionPage from '../../pages/Components/Display/Loans/Regions/CorporateLoans/CreditUsage/FormulaDetailRegion';

// ** Confirms
import ContinueProcessConfirmModalPage from '../../pages/Components/Display/_Common/Modals/ContinueProcessConfirmModal';
import LossOfChangeConfirmModalPage from '../../pages/Components/Display/_Common/Modals/LossOfChangeConfirmModal';
// ** Papers
import PasswordInformationsPage from '../../pages/Components/Display/_Common/Papers/PasswordInformations';
//
/** Hooks Import */
import UseAxiosPage from '../../pages/Hooks/useAxios';
import UseJReportAxiosPage from '../../pages/Hooks/useJReportAxios';
/** Utils Import */
import BuildRequestHeaderPage from '../../pages/Utils/buildRequestHeader';
import GenerateReferenceDataRequestListPage from '../../pages/Utils/generateReferenceDataRequestList';
import GetAuthorizationPage from '../../pages/Utils/getAuthorization';
import GetGenericSetCallerPage from '../../pages/Utils/getGenericSetCaller';
import GetGlobalsDataPage from '../../pages/Utils/getGlobalsData';
import GetReferenceDataPage from '../../pages/Utils/getReferenceData';
import GetXUserNamePage from '../../pages/Utils/getXUserName';
import IsWebviewPage from '../../pages/Utils/isWebview';
import MessagePage from '../../pages/Utils/message';
import ShellListenerPage from '../../pages/Utils/shellListener';
import ShellTriggerPage from '../../pages/Utils/shellTrigger';
import StringDateToUnixtimePage from '../../pages/Utils/stringDateToUnixtime';
import StringTimeToUnixtimePage from '../../pages/Utils/stringTimeToUnixtime';
import StringToStringDatePage from '../../pages/Utils/stringToStringDate';
import StringToStringDateTimePage from '../../pages/Utils/stringToStringDateTime';
import StringToStringTimePage from '../../pages/Utils/stringToStringTime';
import UnixtimeToStringDatePage from '../../pages/Utils/unixtimeToStringDate';
import UnixtimeToStringTimePage from '../../pages/Utils/unixtimeToStringTime';
// Others Import
import ConstantLocalizationPage from '../../pages/Examples/ConstantLocalization';

export enum MenuGroupEnum {
    App = 'App',
    Display = 'Display',
    Form = 'Form',
    Others = 'Others',
    Hooks = 'Hooks',
    Utils = 'Utils',
    Examples = 'Examples',
}

export interface IMenuData {
    element: any;
    group: `${MenuGroupEnum}`;
    text: string;
}

interface IMenu {
    app: IMenuData[];
    display: IMenuData[];
    examples: IMenuData[];
    form: IMenuData[];
    hooks: IMenuData[];
    others: IMenuData[];
    utils: IMenuData[];
}

export const menu: IMenu = {
    app: [
        { text: 'Footer', group: MenuGroupEnum.App, element: FooterPage },
        { text: 'Login', group: MenuGroupEnum.App, element: LoginPage },
        { text: 'Logout', group: MenuGroupEnum.App, element: LogoutPage },
        { text: 'NotFound', group: MenuGroupEnum.App, element: NotFoundPage },
    ],
    form: [
        { text: 'CloseAppButton', group: MenuGroupEnum.Form, element: CloseAppButtonPage },
        { text: 'ClosePageButton', group: MenuGroupEnum.Form, element: ClosePageButtonPage },
        { text: 'DeleteButton', group: MenuGroupEnum.Form, element: DeleteButtonPage },
        { text: 'MenuButton', group: MenuGroupEnum.Form, element: MenuButtonPage },
        { text: 'PasswordInput', group: MenuGroupEnum.Form, element: PasswordInputInputPage },
        { text: 'RegistryNoInput', group: MenuGroupEnum.Form, element: RegistryNoInputInputPage },
        { text: 'SaveButton', group: MenuGroupEnum.Form, element: SaveButtonPage },
    ],
    display: [
        // MODALS
        {
            text: 'AccountSelectionModal',
            group: MenuGroupEnum.Display,
            element: AccountSelectionModalPage,
        },
        {
            text: 'AssetSelectionModal',
            group: MenuGroupEnum.Display,
            element: AssetSelectionModalPage,
        },
        {
            text: 'BpmProcessDefinitionSelectionModal',
            group: MenuGroupEnum.Display,
            element: BpmProcessDefinitionSelectionModalPage,
        },
        {
            text: 'BpmProcessSelectionModal',
            group: MenuGroupEnum.Display,
            element: BpmProcessSelectionModalPage,
        },
        {
            text: 'CardInquiryModal',
            group: MenuGroupEnum.Display,
            element: CardInquiryModalPage,
        },
        {
            text: 'ChecksBillsForeignTradeBicCodeListModal',
            group: MenuGroupEnum.Display,
            element: ChecksBillsForeignTradeBicCodeListModalPage,
        },
        {
            text: 'CollateralSelectionModal',
            group: MenuGroupEnum.Display,
            element: CollateralSelectionModalPage,
        },
        { text: 'ContinueProcessConfirmModal', group: MenuGroupEnum.Display, element: ContinueProcessConfirmModalPage },
        { text: 'CustomerInquiryModal', group: MenuGroupEnum.Display, element: CustomerInquiryModalPage },
        {
            text: 'DepositAccountInquiryModal',
            group: MenuGroupEnum.Display,
            element: DepositAccountInquiryModalPage,
        },
        {
            text: 'DocumentTypesModal',
            group: MenuGroupEnum.Display,
            element: DocumentTypesPage,
        },
        {
            text: 'EprocProcessDefinitionSelectionModal',
            group: MenuGroupEnum.Display,
            element: EprocProcessDefinitionSelectionModalPage,
        },
        {
            text: 'EprocProcessSelectionModal',
            group: MenuGroupEnum.Display,
            element: EprocProcessSelectionModalPage,
        },
        { text: 'ExtractModal', group: MenuGroupEnum.Display, element: ExtractModalPage },
        { text: 'FilesModal', group: MenuGroupEnum.Display, element: FilesModalPage },
        {
            text: 'FTCCommonStatisticsModal',
            group: MenuGroupEnum.Display,
            element: FTCCommonStatisticsModalPage,
        },
        {
            text: 'InstitutionSelectionModal',
            group: MenuGroupEnum.Display,
            element: InstitutionSelectionModalPage,
        },
        {
            text: 'InterlocutorInquiryModal',
            group: MenuGroupEnum.Display,
            element: InterlocutorInquiryModalPage,
        },
        { text: 'InvestBicCodeListModal', group: MenuGroupEnum.Display, element: InvestBicCodeListModalPage },
        { text: 'JointCustomerInquiryModal', group: MenuGroupEnum.Display, element: JointCustomerInquiryModalPage },
        {
            text: 'LoanRequestFormSelectionModal',
            group: MenuGroupEnum.Display,
            element: LoanRequestFormSelectionModalPage,
        },
        { text: 'LossOfChangeConfirmModal', group: MenuGroupEnum.Display, element: LossOfChangeConfirmModalPage },
        {
            text: 'NostroAccountListModal',
            group: MenuGroupEnum.Display,
            element: NostroAccountListModalPage,
        },
        {
            text: 'PersonalLoanApplicationInquiryModal',
            group: MenuGroupEnum.Display,
            element: PersonalLoanApplicationInquiryModalPage,
        },
        {
            text: 'ProductDisbursementFeaturesModal',
            group: MenuGroupEnum.Display,
            element: ProductDisbursementFeaturesModalPage,
        },
        {
            text: 'ProductSelectionModal',
            group: MenuGroupEnum.Display,
            element: ProductSelectionPage,
        },
        {
            text: 'UnitInquiryModal',
            group: MenuGroupEnum.Display,
            element: UnitInquiryModalPage,
        },
        {
            text: 'UserInquiryModal',
            group: MenuGroupEnum.Display,
            element: UserInquiryModalPage,
        },
        // REGIONS
        {
            text: 'AccountSearchRegion',
            group: MenuGroupEnum.Display,
            element: AccountSearchRegionPage,
        },
        {
            text: 'AccountShortInfoRegion',
            group: MenuGroupEnum.Display,
            element: AccountShortInfoRegionPage,
        },
        {
            text: 'BankAccountInfoRegion',
            group: MenuGroupEnum.Display,
            element: BankAccountInfoRegionPage,
        },
        {
            text: 'CommonFilePickerRegion',
            group: MenuGroupEnum.Display,
            element: CommonFilePickerRegionPage,
        },
        {
            text: 'CommonCurrencyValueRegion',
            group: MenuGroupEnum.Display,
            element: CommonCurrencyValueRegionPage,
        },
        {
            text: 'CommonCurrencyValueTesterRegion',
            group: MenuGroupEnum.Display,
            element: CommonCurrencyValueTesterRegionPage,
        },
        {
            text: 'CustomerInfoRegion',
            group: MenuGroupEnum.Display,
            element: CustomerInfoRegionPage,
        },
        {
            text: 'FormulaDetailRegion',
            group: MenuGroupEnum.Display,
            element: FormulaDetailRegionPage,
        },
        // PAGE CONTENTS
        {
            text: 'UTC005PageContent',
            group: MenuGroupEnum.Display,
            element: UTC005Page,
        },
    ],
    others: [
        { text: 'DmsDocumentViewer', group: MenuGroupEnum.Others, element: DmsDocumentViewerPage },
        { text: 'ModalViewer', group: MenuGroupEnum.Others, element: ModalViewerPage },
        { text: 'PasswordInformations', group: MenuGroupEnum.Others, element: PasswordInformationsPage },
    ],
    hooks: [
        { text: 'useAxios', group: MenuGroupEnum.Hooks, element: UseAxiosPage },
        { text: 'useJReportAxios', group: MenuGroupEnum.Hooks, element: UseJReportAxiosPage },
    ],
    utils: [
        { text: 'buildRequestHeader', group: MenuGroupEnum.Utils, element: BuildRequestHeaderPage },
        {
            text: 'generateReferenceDataRequestList',
            group: MenuGroupEnum.Utils,
            element: GenerateReferenceDataRequestListPage,
        },
        { text: 'getAuthorization', group: MenuGroupEnum.Utils, element: GetAuthorizationPage },
        { text: 'getGenericSetCaller', group: MenuGroupEnum.Utils, element: GetGenericSetCallerPage },
        { text: 'getGlobalsData', group: MenuGroupEnum.Utils, element: GetGlobalsDataPage },
        { text: 'getReferenceData', group: MenuGroupEnum.Utils, element: GetReferenceDataPage },
        { text: 'getXUserName', group: MenuGroupEnum.Utils, element: GetXUserNamePage },
        { text: 'isWebview', group: MenuGroupEnum.Utils, element: IsWebviewPage },
        { text: 'message', group: MenuGroupEnum.Utils, element: MessagePage },
        { text: 'shellListener', group: MenuGroupEnum.Utils, element: ShellListenerPage },
        { text: 'shellTrigger', group: MenuGroupEnum.Utils, element: ShellTriggerPage },
        { text: 'stringDateToUnixTime', group: MenuGroupEnum.Utils, element: StringDateToUnixtimePage },
        { text: 'stringTimeToUnixtime', group: MenuGroupEnum.Utils, element: StringTimeToUnixtimePage },
        { text: 'stringToStringDate', group: MenuGroupEnum.Utils, element: StringToStringDatePage },
        { text: 'stringToStringDateTime', group: MenuGroupEnum.Utils, element: StringToStringDateTimePage },
        { text: 'stringToStringTime', group: MenuGroupEnum.Utils, element: StringToStringTimePage },
        { text: 'unixtimeToStringDate', group: MenuGroupEnum.Utils, element: UnixtimeToStringDatePage },
        { text: 'unixtimeToStringTime', group: MenuGroupEnum.Utils, element: UnixtimeToStringTimePage },
    ],
    examples: [{ text: 'ConstantLocalization', group: MenuGroupEnum.Examples, element: ConstantLocalizationPage }],
};

export const menuData: IMenuData[] = [
    ...menu.app,
    ...menu.display,
    ...menu.form,
    ...menu.hooks,
    ...menu.utils,
    ...menu.others,
    ...menu.examples,
];
