import '@fontsource/source-sans-pro';
import type { FC } from 'react';
import { ProcessEnvEnum, SETProvider } from '../lib';
import Root from './_root';
import { theme } from 'seker-ui';

const App: FC = () => {
    return (
        <SETProvider
            globalStyles={{ body: { backgroundColor: theme.palette.grey[50] } }}
            projectProps={{ env: ProcessEnvEnum.Alfa, routeProps: { paths: { home: '#', login: '#' } } }}>
            <Root />
        </SETProvider>
    );
};

export { default as Layout, Header, Sidebar } from './Layout';
export default App;
