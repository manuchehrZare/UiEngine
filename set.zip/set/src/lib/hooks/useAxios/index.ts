/* eslint-disable react-hooks/exhaustive-deps */
import type { Options, UseAxiosResult } from 'axios-hooks';
import useAxiosHook, { configure } from 'axios-hooks';
import { useStorage } from 'seker-ui';
import { useEffect } from 'react';
import type { AxiosRequestConfig } from '../../utils/services';
import { axios } from '../../utils/services';
import type { AuthenticateType } from '../../utils/types';
import { constants } from '../../utils/constants';
export type { RefetchFunction } from 'axios-hooks';

export type UseAxios = <TResponse = any, TBody = any, TError = any>(
    config: AxiosRequestConfig<TBody> | string,
    options?: Options,
) => UseAxiosResult<TResponse, TBody, TError>;

configure({ cache: false, axios });

export const useAxios: UseAxios = (config, options) => {
    const authStorageValue = useStorage<AuthenticateType>({ key: constants.key.SET_AUTH, source: 'session' });

    const [responseValues, reFetch, afterFunc] = useAxiosHook(config, {
        ...options,
        manual: true,
    });

    /**
     * After Re-Login; Runs the request on the page it is on when the manual is "false" and no authentication check is required.
     */
    useEffect(() => {
        if (typeof config !== 'string' && config?.disableAuthControl && !options?.manual) {
            reFetch();
        }
    }, [(config as any)?.disableAuthControl, options?.manual]);

    /**
     * After Re-Login; When the guid is "false" and authentication check is required, it runs the request on the page it's on.
     */
    useEffect(() => {
        if (
            authStorageValue.newValue?.token &&
            !options?.manual &&
            typeof config !== 'string' &&
            !config?.disableAuthControl
        ) {
            reFetch();
        }
    }, [authStorageValue.newValue?.token, (config as any)?.disableAuthControl, options?.manual]);

    return [responseValues, reFetch, afterFunc];
};
