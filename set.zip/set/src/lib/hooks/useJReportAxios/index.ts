/* eslint-disable react-hooks/exhaustive-deps */
import type { AxiosRequestConfig } from 'axios';
import type { Options, UseAxiosResult } from 'axios-hooks';
import type { JReportCallRequest, JReportCallResponse } from '../../utils';
import { HttpStatusCodeEnum, constants, useTranslation } from '../../utils';
import { useAxios } from '../useAxios';
import { useEffect } from 'react';
import { getGenericSetCaller } from '../..';
import { MessageTypeEnum, message } from 'seker-ui';

export type UseJReportAxios = <TReportParams, TDataParams>(
    config?: AxiosRequestConfig<JReportCallRequest<TReportParams, TDataParams>> & { coreService?: string },
    options?: Options,
) => UseAxiosResult<JReportCallResponse, JReportCallRequest<TReportParams, TDataParams>, any>;

export const useJReportAxios: UseJReportAxios = (config, options) => {
    const { t, locale } = useTranslation();

    const [jReportResponse, jReportReFetch, jReportAfterFunc] = useAxios(
        { ...constants.api.endpoints.nova.gateway.jReportCall.POST, ...config },
        { manual: true, ...options },
    );

    // eslint-disable-next-line
    const dataParams = config?.data?.dataParameters;

    const [{ response: coreServiceResponse }, coreServiceCall] = useAxios<any, typeof dataParams>(
        getGenericSetCaller(config?.coreService || ''),
        { manual: true },
    );

    useEffect(() => {
        if (
            jReportResponse?.response?.status === HttpStatusCodeEnum.Ok &&
            !jReportResponse?.data?.pdfContent &&
            config?.coreService
        ) {
            coreServiceCall({
                data: JSON.parse(String(jReportResponse?.response?.config?.data))?.dataParameters,
            });
        }
    }, [jReportResponse?.response]);

    useEffect(() => {
        if (coreServiceResponse?.status === HttpStatusCodeEnum.Ok) {
            message({ message: t(locale.notifications.noSearchedData), variant: MessageTypeEnum.info });
        }
    }, [coreServiceResponse]);

    return [jReportResponse, jReportReFetch, jReportAfterFunc];
};
