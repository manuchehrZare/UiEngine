export default {
    home: 'Home',
    notFound: 'Page not found!',
};
