export default {
    auth: {
        password: {
            requirements: {
                previous: 'Must be different from your previous 5 passwords.',
                length: 'Must be a minimum of 8 characters and a maximum of 16 characters.',
                lowercase: 'There must be at least one lowercase letter.',
                uppercase: 'There must be at least one uppercase letter.',
                digit: 'There must be at least one digit.',
                turkish: 'Turkish characters should not be used.',
                space: 'Space characters should not be used.',
            },
        },
    },
    areYouSureToContinueProcess: 'Are you sure to continue process?',
    areYouSureYouWantToCloseTheApplication: 'Are you sure you want to close the application?',
    areYouSureYouWantToLogOutOfTheApplication: 'Are you sure you want to exit the application?',
    areYouSureYouWantToSave: 'Are you sure you want to save?',
    doYouWantToContinue: 'You will lose the changes you have made! Do you want to continue?',
    doYouWantToDelete: 'Do you want to continue the deletion?',
    warning: 'Warning',
};
