export default {
    enterAddresseeNameTitle: 'Enter Addressee Name/Title.',
    enterLoanNoOidCustomerNoOrBranch:
        'At least one of the following fields must be entered: Credit Number, Credit Oid, Customer Number or Branch!',
};
