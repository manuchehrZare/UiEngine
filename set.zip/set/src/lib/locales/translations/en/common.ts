export default {
    or: 'or',
    screenNotFound: 'The screen you are looking for does not exist.',
    sekerbankInformationTechnologies: 'Şekerbank Information Technologies',
    welcome: 'Welcome',
};
