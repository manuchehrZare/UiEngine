import buttons from './_buttons';
import common from './common';
import contentTitles from './_contentTitles';
import contents from './_contents';
import labels from './_labels';
import languages from './_languages';
import notifications from './_notifications';
import pageTitles from './_pageTitles';
import validations from './_validations';

export default {
    buttons,
    common,
    contentTitles,
    contents,
    labels,
    languages,
    notifications,
    pageTitles,
    validations,
};
