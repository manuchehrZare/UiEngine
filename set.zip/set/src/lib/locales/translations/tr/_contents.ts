export default {
    auth: {
        password: {
            requirements: {
                previous: 'Önceki 5 şifrenizden farklı olmalıdır.',
                length: 'En az 8, en fazla 16 karakter olmalıdır.',
                lowercase: 'En az bir küçük harf bulunmalıdır.',
                uppercase: 'En az bir büyük harf bulunmalıdır.',
                digit: 'En az bir rakam bulunmalıdır.',
                turkish: 'Türkçe karakter kullanılmamalıdır.',
                space: 'Boşluk karakteri kullanılmamalıdır.',
            },
        },
    },
    areYouSureToContinueProcess: 'İşleme devam etmek istediğinize emin misiniz?',
    areYouSureYouWantToCloseTheApplication: 'Uygulamayı kapatmak istediğinize emin misiniz?',
    areYouSureYouWantToLogOutOfTheApplication: 'Uygulamadan çıkış yapmak istediğinize emin misiniz?',
    areYouSureYouWantToSave: 'Kaydetmek istediğinize emin misiniz?',
    doYouWantToContinue: 'Yaptığınız değişiklikleri kaybedeceksiniz! Devam etmek istiyor musunuz?',
    doYouWantToDelete: 'Silme işlemine devam etmek istiyor musunuz?',
    warning: 'Uyarı',
};
