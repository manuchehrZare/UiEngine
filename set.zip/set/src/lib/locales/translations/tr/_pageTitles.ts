export default {
    home: 'Anasayfa',
    notFound: 'Sayfa Bulunamadı!',
};
