export default {
    enterAddresseeNameTitle: 'Muhatap Adı/Ünvanı Giriniz.',
    enterLoanNoOidCustomerNoOrBranch: 'Kredi No, Kredi Oid, Müşteri No veya Şube alanlarından en az biri girilmelidir!',
};
