export default {
    or: 'veya',
    screenNotFound: 'Aradığınız ekran bulunmamaktadır.',
    sekerbankInformationTechnologies: 'Şekerbank Enformasyon Teknolojileri',
    welcome: 'Hoşgeldiniz',
};
