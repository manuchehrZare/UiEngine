import { i18nInit } from './_i18nInstance';
import { i18nInit as i18nInitSekerUI } from 'seker-ui';

export const i18nInitialize = async (): Promise<void> => {
    await i18nInitSekerUI();
    await i18nInit();
};
