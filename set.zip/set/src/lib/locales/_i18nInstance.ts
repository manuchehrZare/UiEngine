import { createInstance } from 'i18next';

import localeTR from './translations/tr';

import localeEN from './translations/en';

import { getLocalStorageItem, i18n as i18nSekerUI } from 'seker-ui';

import { LocalesEnum } from '../utils/types/locales';

import { constants } from '../utils/constants';

import LanguageDetector from 'i18next-browser-languagedetector';

import { initReactI18next } from 'react-i18next';

import { merge } from 'lodash';

export const languageStorageKey = constants.key.SETUI_LANGUAGE;

export const defaultlocaleData = localeTR; // for keyPaths using

export const i18n = createInstance({
    debug: true,

    resources: merge(i18nSekerUI.options.resources, {
        [LocalesEnum.TURKISH]: localeTR,

        [LocalesEnum.ENGLISH]: localeEN,
    }),

    lng: getLocalStorageItem<string>(languageStorageKey) || LocalesEnum.TURKISH, // if defined, it triggers the defined language at every render instant

    fallbackLng: [LocalesEnum.TURKISH, LocalesEnum.ENGLISH],

    interpolation: {
        escapeValue: false, // react already safes from xss => https://www.i18next.com/translation-function/interpolation#unescape
    },

    react: {
        useSuspense: false,
    },
});

export const i18nInit = async (): Promise<void> => {
    await i18n

        .use(new LanguageDetector(null, { lookupLocalStorage: languageStorageKey }))

        .use(initReactI18next)

        .init({}, () => {
            document.documentElement.setAttribute('lang', String(getLocalStorageItem<string>(languageStorageKey)));
        });
};
