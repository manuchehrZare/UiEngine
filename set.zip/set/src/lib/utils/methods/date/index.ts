import { format, fromUnixTime, getUnixTime } from 'date-fns';
import { pickerProps } from 'seker-ui';

/**
 * Returns string date according to necessary string date type depending on the entered date value as "dd.mm.yyyy", "mm.yyyy" or "yyyy".
 * @param stringDate
 */
export const stringToStringDate = (stringDate: string): string => {
    return stringDate
        ? stringDate.length === 4
            ? stringDate.substring(0, 4)
            : stringDate.length === 6
              ? `${stringDate.substring(4, 6)}${pickerProps.SET.datePicker.dateSeparator}${stringDate.substring(0, 4)}`
              : `${stringDate.substring(6, 8)}${pickerProps.SET.datePicker.dateSeparator}${stringDate.substring(4, 6)}${pickerProps.SET.datePicker.dateSeparator}${stringDate.substring(0, 4)}`
        : '';
};

/**
 * Returns string time according to necessary string time type depending on the entered time value as "hh:mm:ss", "hh:mm" or "hh".
 * @param stringTime
 */
export const stringToStringTime = (stringTime: string): string => {
    return stringTime
        ? stringTime.length === 2
            ? stringTime.substring(0, 2)
            : stringTime.length === 4
              ? `${stringTime.substring(0, 2)}${pickerProps.SET.timePicker.timeSeparator}${stringTime.substring(2, 4)}`
              : `${stringTime.substring(0, 2)}${pickerProps.SET.timePicker.timeSeparator}${stringTime.substring(2, 4)}${pickerProps.SET.timePicker.timeSeparator}${stringTime.substring(4, 6)}`
        : '';
};

/**
 * Returns string date and time according to necessary string date and time type depending on the entered date and time value as "dd.mm.yyyy hh:mm" or "dd.mm.yyyy hh:mm:ss".
 * @param stringDateTime
 */
export const stringToStringDateTime = (stringDateTime: string): string => {
    return stringDateTime
        ? stringDateTime.length === 12
            ? `${stringDateTime.substring(0, 2)}${pickerProps.SET.dateTimePicker.dateSeparator}${stringDateTime.substring(2, 4)}${pickerProps.SET.dateTimePicker.dateSeparator}${stringDateTime.substring(4, 8)} ${stringDateTime.substring(8, 10)}${pickerProps.SET.dateTimePicker.timeSeparator}${stringDateTime.substring(10, 12)}`
            : `${stringDateTime.substring(0, 2)}${pickerProps.SET.dateTimePicker.dateSeparator}${stringDateTime.substring(2, 4)}${pickerProps.SET.dateTimePicker.dateSeparator}${stringDateTime.substring(4, 8)} ${stringDateTime.substring(8, 10)}${pickerProps.SET.dateTimePicker.timeSeparator}${stringDateTime.substring(10, 12)}${pickerProps.SET.dateTimePicker.timeSeparator}${stringDateTime.substring(12, 14)}`
        : '';
};

/**
 * Returns string date type as the given date format according to given unixtime.
 * @param unixtime
 * Keeps the information of what type the date format is to be returned such as: "yyyyMMdd" or "yyyyMM", default value is: "yyyyMMdd"
 * @param dateFormat
 */
export const unixtimeToStringDate = (unixtime: number, dateFormat?: string): string => {
    return unixtime ? format(fromUnixTime(unixtime), dateFormat || 'yyyyMMdd') : '';
};

/**
 * Returns unixtime according to given string date type as "yyyymmdd" or "yyyymm".
 * @param stringDate
 */
export const stringDateToUnixtime = (stringDate: string): number => {
    return stringDate.length === 6
        ? getUnixTime(new Date(Number(stringDate.substring(0, 4)), Number(stringDate.substring(4, 6)) - 1))
        : getUnixTime(
              new Date(
                  Number(stringDate.substring(0, 4)),
                  Number(stringDate.substring(4, 6)) - 1,
                  Number(stringDate.substring(6, 8)),
              ),
          );
};

/**
 * Returns string time type as the given time format according to given unixtime.
 * @param unixtime
 * Keeps the information of what type the time format is to be returned such as: "HHmmss" or "HHmm", default value is: "HHmmss"
 * @param timeFormat
 */
export const unixtimeToStringTime = (unixtime: number, timeFormat?: string): string => {
    return unixtime ? format(fromUnixTime(unixtime), timeFormat || 'HHmmss') : '';
};

/**
 * Returns unixtime according to given string time type as "hhmmss".
 * @param stringTime
 */
export const stringTimeToUnixtime = (stringTime: string): number => {
    return getUnixTime(
        new Date(
            1970,
            0,
            1,
            Number(stringTime.substring(0, 2)),
            Number(stringTime.substring(2, 4)),
            Number(stringTime.substring(4, 6)),
        ),
    );
};
