import { isEmpty, isUndefined } from 'lodash';
import { getSessionStorageItem, queryStringToJSON } from 'seker-ui';
import type {
    AuthenticateType,
    GenerateGlobalsDataByMenuKeyOptions,
    GenerateReferenceDataOptions,
    GetGlobalsDataOptions,
    GlobalsItemType,
    ReferenceDataRequestListItem,
} from '../../..';
import { constants, GlobalsItemEnum, LocalesEnum } from '../../..';
import type { GenerateGlobalsDataByBranchSelectionOptions } from '../../types/common';

/**
 * - When no parameters given, it returns all the global values as an array.
 * - By default, it finds the element in the relevant index of the key you gave it as a parameter and returns its value to you.
 */
export function getGlobalsData(): GlobalsItemType[];
export function getGlobalsData(options?: GetGlobalsDataOptions): string | null;
// eslint-disable-next-line
export function getGlobalsData(options?: GetGlobalsDataOptions) {
    const authStorageValue = getSessionStorageItem<AuthenticateType>(constants.key.SET_AUTH);
    if (isUndefined(options) || (options && isEmpty(options))) {
        return authStorageValue?.globals;
    }
    // ELSE
    const globalsData = options?.sourceData || authStorageValue?.globals;
    if (globalsData && globalsData.length > 0 && globalsData.find((item) => item.name === options?.key)) {
        return globalsData.find((item) => item.name === options?.key)?.value;
    }
    return null;
}

/**
 * - Takes token parameter and converts that token to bearer token.
 * - If no parameter is given, the information of the logged in person takes place in the storage. It reads the token information from there and returns it as a bearer token.
 * @param token
 */
// eslint-disable-next-line
export const getAuthorization = (token?: string) => {
    let tokenValue = token;
    if (!tokenValue) {
        const authStorageValue = getSessionStorageItem<AuthenticateType>(constants.key.SET_AUTH);
        tokenValue = authStorageValue?.token;
    }
    return tokenValue ? `Bearer ${tokenValue}` : tokenValue;
};

/**
 * - Allows reading userName information from globals data.
 * @param sourceGlobalsData
 * @returns data of the globalsItemEnum.userName key
 */
// eslint-disable-next-line
export const getXUserName = (sourceGlobalsData?: GlobalsItemType[]) => {
    return getGlobalsData({ key: GlobalsItemEnum.UserName, sourceData: sourceGlobalsData });
};

/**
 * - Generates the data of the requestList parameter in the request body for ReferenceData services.
 * @param options
 */
export const generateReferenceDataRequestList = (
    options: GenerateReferenceDataOptions,
): ReferenceDataRequestListItem[] => {
    const requestList: ReferenceDataRequestListItem[] = [];
    if (options.nameList.length) {
        options.nameList.forEach((item) => {
            requestList.push({ language: options?.language || LocalesEnum.TURKISH, name: item });
        });
    }
    return requestList;
};

export const getLoginNavigateRoute = (options: {
    homeRoute: string;
    locationSearch: string;
    resetQuery: () => void;
}): string => {
    if (options.locationSearch) {
        const queryParams = queryStringToJSON(options.locationSearch);
        if (!isEmpty(queryParams)) {
            options?.resetQuery?.();
            const refKey = constants.key.LINK_REF.replace(constants.format.regexp.symbol, '');
            if ((queryParams as any)[refKey]) return (queryParams as any)[refKey];
        }
    }
    return options.homeRoute;
};

/**
 * It generates new "globals" data for the user according to the menuKey value of the opened screen.
 */
export const generateGlobalsDataByMenuKey = (options: GenerateGlobalsDataByMenuKeyOptions): GlobalsItemType[] => {
    const globalsData = options.globals || getGlobalsData();
    let newGlobalsData = globalsData;
    if (newGlobalsData) {
        newGlobalsData = newGlobalsData.filter((item) => item.name !== GlobalsItemEnum.MenuKey);
        if (options.menuKey) {
            newGlobalsData.push({ name: GlobalsItemEnum.MenuKey, value: options.menuKey });
        }
    }
    return newGlobalsData;
};

/**
 * It generates new "globals" data for the user according to the branch selection value of the opened screen.
 */
export const generateGlobalsDataByBranchSelection = (
    options: GenerateGlobalsDataByBranchSelectionOptions,
): GlobalsItemType[] => {
    const globalsData = options.globals || getGlobalsData();
    let newGlobalsData = globalsData;
    if (newGlobalsData) {
        newGlobalsData = newGlobalsData.filter(
            (item) =>
                item.name !== GlobalsItemEnum.ChargedOrganizationCode &&
                item.name !== GlobalsItemEnum.ChargedOrganizationOID,
        );
        if (options.selectedBranch) {
            newGlobalsData.push({
                name: GlobalsItemEnum.ChargedOrganizationCode,
                value: options.selectedBranch.value.replace(/\D+/g, ''),
            });
            newGlobalsData.push({
                name: GlobalsItemEnum.ChargedOrganizationOID,
                value: options.selectedBranch.key,
            });
        }
    }
    return newGlobalsData;
};
