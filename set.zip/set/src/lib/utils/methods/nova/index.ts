import type { AxiosRequestConfig, Method, ReferenceDataResponse, ReferenceDataResultListItemsListItem } from '../..';
import { constants } from '../..';

/**
 * Returns genericSetCaller service endpoint and its method.
 * @param endpoint - generic service endpoint as parameter
 * @param method - HTTP method
 * @returns - { url: string; method: Method }
 */
export const getGenericSetCaller = (
    endpoint: string,
    method?: Method,
): Required<Pick<AxiosRequestConfig, 'url' | 'method'>> => {
    return {
        url: `${constants.api.endpoints.nova.gateway.genericSetCaller.POST.url}/${endpoint}`,
        method: method || constants.api.endpoints.nova.gateway.genericSetCaller.POST.method,
    };
};

export interface IGetReferenceDataProps {
    filterValue?: string;
    referenceDataName: string;
    referenceDatas: ReferenceDataResponse | undefined;
}

export const getReferenceData = ({
    referenceDatas,
    filterValue,
    referenceDataName,
}: IGetReferenceDataProps): ReferenceDataResultListItemsListItem[] => {
    if (referenceDatas) {
        const refData = referenceDatas?.resultList?.find((item) => item?.name === referenceDataName)?.items || [];
        return filterValue
            ? refData.filter((i: ReferenceDataResultListItemsListItem) => i.filter === filterValue)
            : refData;
    }
    return [];
};
