import { v4 as uuidv4 } from 'uuid';
import type {
    AxiosRequestConfig,
    AxiosResponse,
    BuildRequestHeaderReturnType,
    ProcessEnvType,
    RequestHeaderParams,
} from '../../..';
import { axios, getAuthorization, getXUserName } from '../../..';
import { constants } from '../../constants';
import type { AuthenticateType } from '../../types';
import { ProcessEnvEnum } from '../../types';
import { getSessionStorageItem } from 'seker-ui';
import type { ProviderProjectProps } from '../../../components/App/Provider/type';

export const buildRequestHeader = (headerParams?: Partial<RequestHeaderParams>): BuildRequestHeaderReturnType => {
    const authStorageValue = getSessionStorageItem<AuthenticateType>(constants.key.SET_AUTH);
    const storageProjectProps = getSessionStorageItem<ProviderProjectProps>(constants.key.SETUI_Provider_ProjectProps);
    return {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-cache',
        'x-originating-source': window.location.pathname,
        'x-request-id': uuidv4(),
        ...(authStorageValue
            ? {
                  ...([storageProjectProps?.routeProps?.paths?.login].some(
                      (path) => path !== window.location.pathname,
                  ) && {
                      Authorization: getAuthorization(),
                  }),
                  ...(getXUserName() && { 'x-username': getXUserName() || '' }),
              }
            : {}),
        ...storageProjectProps?.serviceProps?.headers,
        ...headerParams,
    };
};

/**
 * Returns baseURL information for services.
 * @param options  - { env?: ProcessEnvType; url?: string }
 * @description options
 * - env : It allows to obtain the baseURL information of Nova that is compatible with the specified environment.
 * - url : Allows the specified url to be used as the baseURL. Recommended for "localhost" url use.
 * @returns
 */
export const getRequestBaseURL = (options?: { env?: ProcessEnvType; url?: string }): string => {
    const storageProjectProps = getSessionStorageItem<ProviderProjectProps>(constants.key.SETUI_Provider_ProjectProps);
    return (
        options?.url ||
        storageProjectProps?.serviceProps?.baseURL ||
        constants.api.baseURL.nova[options?.env || storageProjectProps?.env || ProcessEnvEnum.Alfa]
    );
};

export const axiosFetcher = async <TResponse, TRequest = unknown>(
    requestConfig: AxiosRequestConfig<TRequest>,
): Promise<TResponse> => {
    const response: AxiosResponse<TResponse> = await axios(requestConfig);
    return response.data;
};
