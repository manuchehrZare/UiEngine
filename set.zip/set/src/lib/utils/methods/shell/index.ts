import { UAParser } from 'ua-parser-js';
import type { ShellListenerData, ShellTriggerParams } from '../..';

/**
 *   - Checks whether the conversion project works with the webview of the .Net platform used in the shell application.
 */
export const isWebview = (): boolean => {
    const parser = new UAParser();
    // * .NET Webview uses the "Edge" browser
    return Boolean(parser.getBrowser().name === 'Edge' && (window as any)?.chrome?.webview);
};

/**
 *   - The method used to send data to the shell application and trigger process.
 *   - It implements this method with the webview trigger (postMessage) event of the .Net platform.
 * @param params
 *   - ShellTriggerEnum definitions can be used for processType
 */
export const shellTrigger = <T>(params: ShellTriggerParams<T>): void => {
    const newParams = { ...params, processType: Number(params.processType) };
    // eslint-disable-next-line no-console
    import.meta.env.NODE_ENV === 'development' && console.log('shellTrigger', newParams);
    if (isWebview()) {
        (window as any)?.chrome?.webview?.postMessage(newParams);
    }
};

/**
 *   - If the application is running on the shell platform, it allows us to obtain data from the shell.
 *   - It is the method that listens to the shell.
 *   - It implements this method with the webview listener (addEventListener('message')) event of the .Net platform.
 * @param params
 *   - callback: It allows to make special processing for each application.
 */
export const shellListener = (callback: (data?: ShellListenerData) => void): void => {
    if (isWebview()) {
        /**
         * .NET WebView uses the "Edge" browser. When WebView is used, Edge browser has the value of "chrome.webview" in the Window object.
         * It can be tested only when used with WebView.
         */
        (window as any)?.chrome?.webview?.addEventListener('message', (e: any) => {
            // eslint-disable-next-line no-console
            import.meta.env.NODE_ENV === 'development' && console.log('shellListener', e.data);
            if (e.data && (e.data as ShellListenerData).isNova) {
                callback(e.data);
            }
        });
    }
};
