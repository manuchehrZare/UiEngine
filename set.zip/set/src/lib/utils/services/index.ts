import type { AxiosError, AxiosRequestConfig, AxiosResponse, Method } from 'axios';
import Axios, { HttpStatusCode as HttpStatusCodeEnum } from 'axios';
import {
    closeMessage,
    getSessionStorageItem,
    hideLoading,
    isParsableToJson,
    message,
    MessageTypeEnum,
    removeSessionStorageItem,
    setSessionStorageItem,
    showLoading,
    sleep,
} from 'seker-ui';
import type { QueryType, ResponseError } from '..';
import {
    ShellProcessTypeEnum,
    buildRequestHeader,
    constants,
    getRequestBaseURL,
    i18n,
    isWebview,
    locale,
    shellTrigger,
} from '..';
import { translations as setUITranslationsConstants } from '../constants/translations';
import { merge } from 'lodash';
import type { ProviderProjectProps } from '../..';
import { v4 as uuidv4 } from 'uuid';
// @ts-ignore
import JSONBig from 'json-bigint-fixes';

const JSONbigNative = JSONBig({ useNativeBigInt: true });

// For once navigationToLoginPage message display control.
let activeMessageToLoginPage: boolean = false;

const axios = Axios.create({
    timeout: Number(constants.api.config.timeout),
    timeoutErrorMessage: setUITranslationsConstants.api.timeoutErrorMessage,
});

axios.defaults.transformResponse = [
    (data) => {
        if (typeof data === 'string' && data && isParsableToJson(data)) {
            try {
                data = JSONbigNative.parse(data);
            } catch (e) {
                console.error(e); //eslint-disable-line
            }
        }
        return data;
    },
];

// request interceptor
axios.interceptors.request.use(
    async (config) => {
        !config?.disableLoadingView && showLoading();
        config = merge(config, {
            baseURL: getRequestBaseURL({ url: config.baseURL }),
            headers: buildRequestHeader(config.headers),
        } as typeof config);
        return config;
    },
    (error: AxiosError) => {
        hideLoading();
        return Promise.reject(error);
    },
);

// response interceptor
axios.interceptors.response.use(
    (response) => {
        hideLoading();
        return response;
    },
    (error: AxiosError<ResponseError>) => {
        hideLoading();
        // * It was decided that there was no need to notify the user when the request was cancelled.
        if (Axios.isCancel(error) === true) {
            // * console.error was used in development mode to disable both the notification screen and the default error handling error screen.
            // eslint-disable-next-line no-console
            return console.error(error);
        }
        if ((error as AxiosError)?.response) {
            if ((error as AxiosError)?.response?.status === HttpStatusCodeEnum.Unauthorized) {
                const messageToLoginPageKey = uuidv4();
                const storageProjectProps = getSessionStorageItem<ProviderProjectProps>(
                    constants.key.SETUI_Provider_ProjectProps,
                );

                const navigateLogin = () => {
                    if (isWebview()) {
                        // * For Shell
                        shellTrigger({
                            processType: ShellProcessTypeEnum.Unauthorized,
                            data: storageProjectProps?.routeProps.paths.login,
                        });
                    }
                    // * Not Shell
                    // * Ref Page Control For Redirect after Login
                    else if (
                        storageProjectProps?.routeProps &&
                        !window.location.pathname.includes(storageProjectProps?.routeProps.paths.login)
                    ) {
                        setSessionStorageItem<QueryType>(constants.key.SET_QUERY, { ref: window.location.pathname });
                    } else {
                        removeSessionStorageItem(constants.key.SET_QUERY);
                    }
                    removeSessionStorageItem(constants.key.SET_AUTH);
                };

                message({
                    message:
                        ((error as AxiosError)?.response?.data as AxiosError<ResponseError>)?.message ||
                        ((error as AxiosError)?.response?.data as any)?.error ||
                        (error as AxiosError)?.message,
                    variant: MessageTypeEnum.error,
                    persist: true,
                    error: error,
                } as any);
                if (
                    storageProjectProps?.routeProps &&
                    window.location.pathname !== storageProjectProps.routeProps.paths.login
                ) {
                    !activeMessageToLoginPage &&
                        message({
                            key: messageToLoginPageKey,
                            message: i18n.t(locale.notifications.navigateToLoginPage),
                            variant: MessageTypeEnum.info,
                            onEnter: () => {
                                showLoading();
                                activeMessageToLoginPage = true;
                            },
                            onExit: () => {
                                hideLoading();
                                activeMessageToLoginPage = false;
                            },
                        });
                }
                sleep(constants.app.delay.LOGIN_REDIRECT_DELAY).then(() => {
                    closeMessage(messageToLoginPageKey);
                    navigateLogin();
                });
            } else {
                message({
                    message:
                        ((error as AxiosError)?.response?.data as AxiosError<ResponseError>)?.message ||
                        ((error as AxiosError)?.response?.data as any)?.error ||
                        (error as AxiosError)?.response?.statusText,
                    variant: MessageTypeEnum.error,
                    persist: true,
                    error: error,
                } as any);
            }
        } else {
            message({
                message: (error as AxiosError)?.message,
                variant: MessageTypeEnum.error,
                persist: true,
                error: error,
            } as any);
        }
        return Promise.reject(error);
    },
);

export type { AxiosResponse, AxiosError, AxiosRequestConfig, Method };
export { axios, HttpStatusCodeEnum };
