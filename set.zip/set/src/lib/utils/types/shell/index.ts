import type { Enumerate } from 'seker-ui';
import type { AppType, AuthenticateType, ScreenType } from '../nova';

/**
 * Related to the data to be obtained from the shellListener method.
 */
export type ShellListenerData = AppType &
    Partial<Pick<AuthenticateType, 'loginUserName'>> & {
        auth?: AuthenticateType;
    } & {
        screen: ScreenType;
    };

/**
 * Associated with in-app shutdown processes. It can be used to close the application or the tab that is currently open.
 */
export enum ShellExitTypeEnum {
    Application = 0, // For Application Close
    Page = 1, // For Active Page(Tab) Close
    SessionTimeout = 2, // For SessionTimeout
}

/**
 * Relates to processes triggered by the shelltrigger method.
 */
export enum ShellProcessTypeEnum {
    Login = '1', // For Login
    Sidebar = '2', // For General Sidebar Trigger
    Screen = '3', // For Open Page Trigger
    Exit = '4', // Tab and window close
    Unauthorized = '5', // Session Expire - 401
    Settings = '6', // Settings
    Confirm = '7', // Confirm
}

/**
 * The type definition of the approval or rejection information to be sent for closing the application or the tab that is actively open.
 */
export type ShellExitDataType = {
    status: boolean;
    type: Enumerate<3>; // ShellExitTypeEnum
};

export type ShellProcessType = `${ShellProcessTypeEnum}`;

export type ShellTriggerParams<T> = {
    data: T;
    processType: ShellProcessType;
};
