import type { IInputProps } from 'seker-ui';

export enum SETModalsEnum {
    AccountSelectionModal = 'AccountSelectionModal',
    AssetSelectionModal = 'AssetSelectionModal',
    BpmProcessDefinitionSelectionModal = 'BpmProcessDefinitionSelectionModal',
    BpmProcessSelectionModal = 'BpmProcessSelectionModal',
    CardInquiryModal = 'CardInquiryModal',
    ChecksBillsForeignTradeBicCodeListModal = 'ChecksBillsForeignTradeBicCodeListModal',
    CollateralSelectionModal = 'CollateralSelectionModal',
    CustomerInquiryModal = 'CustomerInquiryModal',
    DepositAccountInquiryModal = 'DepositAccountInquiryModal',
    DocumentTypesModal = 'DocumentTypesModal',
    EprocProcessDefinitionSelectionModal = 'EprocProcessDefinitionSelectionModal',
    EprocProcessSelectionModal = 'EprocProcessSelectionModal',
    ExtractModal = 'ExtractModal',
    FilesModal = 'FilesModal',
    InstitutionSelectionModal = 'InstitutionSelectionModal',
    InterlocutorInquiryModal = 'InterlocutorInquiryModal',
    InvestBicCodeModal = 'InvestBicCodeListModal',
    JointCustomerInquiryModal = 'JointCustomerInquiryModal',
    LoanRequestFormSelectionModal = 'LoanRequestFormSelectionModal',
    NostroAccountListModal = 'NostroAccountListModal',
    PersonalLoanApplicationInquiryModal = 'PersonalLoanApplicationInquiryModal',
    ProductDisbursementFeaturesModal = 'ProductDisbursementFeaturesModal',
    ProductSelectionModal = 'ProductSelectionModal',
    UnitInquiryModal = 'UnitInquiryModal',
    UserInquiryModal = 'UserInquiryModal',
    FTCCommonStatisticsModal = 'FTCCommonStatisticsModal',
    FormulaDetailRegion = 'FormulaDetailRegion',
}

export type SETModalsType = `${SETModalsEnum}`;

export type SETModalsCommonProps = {
    eventOwnerEl?: 'button' | 'input';
    inputProps?: Pick<IInputProps, 'control' | 'name'>;
};
