/**
 * Associated with the language options to be used in the project.
 */
export enum LocalesEnum {
    TURKISH = 'tr',
    ENGLISH = 'en',
}

export type LocalesType = `${LocalesEnum}`;
