export type QueryType = {
    ref: string | null;
};
