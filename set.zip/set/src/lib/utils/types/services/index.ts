import type { RawAxiosRequestHeaders } from 'axios';

/**
 * The type definition of the information to be added to the header of the request in service calls.
 */
export type RequestHeaderParams = RawAxiosRequestHeaders & {
    'x-originating-source': string;
    'x-request-id': string;
    'x-username': string;
};

export type BuildRequestHeaderReturnType = Omit<RequestHeaderParams, 'x-username'> &
    Partial<Pick<RequestHeaderParams, 'x-username'>>;

/**
 * The type definition of the error that services can return in the common architecture.
 */
export type ResponseError = {
    error: string;
    errorCode?: number;
    message: string;
    path: string;
    status: number;
    timestamp: string;
    trace?: string;
};

/**
 * The type definition is for services other than Nova.
 */
export type OtherResponseError = {
    code: string;
    detail: string;
    message: string;
};
/**
 * The enum definition is for services other than Nova.
 */
export enum OtherReturnCodeEnum {
    SUCCESS = '0',
    ERROR = '1',
}
/**
 * The type definition is for services other than Nova.
 */
export type OtherResponseModel<T = any> = {
    data: T | null;
    error: OtherResponseError | null;
    returnCode: '0' | '1';
    timestamp: string;
};

interface AxiosRequestConfigOverrides {
    /**
     * Use when manual is 'false' and no auth checking is needed.
     * @default false
     */
    disableAuthControl?: boolean;
    /**
     * It disables the loading element, which is displayed by default until the request is completed.
     * @default false
     */
    disableLoadingView?: boolean;
}

declare module 'axios' {
    interface AxiosRequestConfig extends AxiosRequestConfigOverrides {}
}
