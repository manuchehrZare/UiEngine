import type { IMenuItem } from '../../../../_common';

export interface IAuthorizeRequest {
    username: string;
}

export interface IAuthorizeResponse {
    data: IMenuItem[];
}
