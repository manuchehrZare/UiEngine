import type { HelperGlobalsProps } from '../../../../../../..';

/**
 * Related to the status value in the response of the "/nova/gateway/authentication/authenticate" service.
 */
export enum AuthenticateStatusEnum {
    OK = 'OK',
}

export type AuthenticateRequest = {
    password: string;
    userName: string;
};

/**
 * - The model of the data returned from the "/nova/gateway/authentication/authenticate" service.
 * - Points to the login user's information.
 */
export type AuthenticateResponse = HelperGlobalsProps & {
    status: `${AuthenticateStatusEnum}`;
    token: string;
};
