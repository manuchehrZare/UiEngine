export interface IAdminOrgOrganizationUnitListForComboRequest {
    orgCode: number | null;
    orgOid: string;
    orgUnitListType: string;
}
export interface IOrgUnitListItem {
    '0': string;
    '1': string;
}
export interface IAdminOrgOrganizationUnitListForComboResponse {
    orgUnitList: IOrgUnitListItem[];
}
