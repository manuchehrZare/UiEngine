export interface IGetAsProdProductListForComboRequest {
    listType: string;
    productGroupOid: string;
    productMainGroupOid: string;
}

export interface IProdProductList {
    0: string;
    1: string;
}

export interface IGetAsProdProductListForComboResponse {
    productList: IProdProductList[];
}
