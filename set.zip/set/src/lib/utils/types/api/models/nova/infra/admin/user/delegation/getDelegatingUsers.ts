import type { GlobalsObjectType } from '../../../../../../../../..';

export enum DelegationUserListTypeEnum {
    Zero = '0',
}
export type GetDelegatingUsersRequest = {
    delegatedUserOid: string;
    listType: `${DelegationUserListTypeEnum}`;
    referenceDate: string;
    usrDelegatingUserOid: string;
};

export enum PasswordExpiredEnum {
    Expired = '1',
    NotExpired = '0',
}

export type DelegatingUsersItem = Pick<GlobalsObjectType, 'userName' | 'userFullName'> & {
    userOid: string;
};

export type GetDelegatingUsersResponse = {
    delegatingUsers: DelegatingUsersItem[];
    passwordExpired: `${PasswordExpiredEnum}`;
};
