export interface ICoreDataItem {
    countryCode: string;
    customerCode: string;
    functionOid: string;
    oid: string;
    shortCode: string;
    stockExchangeCode: string;
    swiftCode: string;
    title: string;
}

export interface IFinmanSwapListInstitutionResponse {
    coreData: ICoreDataItem[];
}

export interface IFinmanSwapListInstitutionRequest {
    countryCode: string;
    customerCode: string;
    functionOid: string;
    shortCode: string;
    stockExchangeCode: string;
    swiftCode: string;
    title: string;
}
