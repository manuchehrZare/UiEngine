export interface IConsAdminListProductsRequest {
    loansType: string;
    productGroupOid: string;
}

export interface IProductListItem {
    '0': string;
    '1': string;
}

export interface IConsAdminListProductsResponse {
    productList: IProductListItem[];
}
