export type ChangePasswordRequest = {
    userNewPassword: string;
    userNewPassword2: string;
    userOid: string;
    userOldPassword: string;
};

export type ChangePasswordResponse = {
    coreInfoMessageId: string;
    referenceId: 0;
};
