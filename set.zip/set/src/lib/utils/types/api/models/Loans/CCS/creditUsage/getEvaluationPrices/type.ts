export interface IGetEvaluationPricesRequest {
    currencyCode: string;
}
export interface IGetEvaluationPricesResponse {
    evaluationBuyRateofex: number;
}
