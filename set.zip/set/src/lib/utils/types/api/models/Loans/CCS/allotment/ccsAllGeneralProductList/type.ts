export interface IGetCcsAllGeneralProductListRequest {
    groupCode: string;
    mainGroupCode: string;
    oid: string;
}

export interface IGetCcsAllGeneralProductListCoreData {
    groupCode: string | null;
    groupName: string | null;
    mainGroupCode: string | null;
    mainGroupName: string | null;
    oid: string | null;
    productCode: string | null;
    productName: string | null;
    productType: string | null;
}

export interface IGetCcsAllGeneralProductListResponse {
    coreData: IGetCcsAllGeneralProductListCoreData[];
}
