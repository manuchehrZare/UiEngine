export interface IBpmCoreProcessDefinitionNameSearchRequest {
    processDefinitionLabel: string;
    processDefinitionName: string;
    processGroupOid: string;
}

export interface ICoreData {
    checkActive: number;
    checkAmount: number;
    checkAuthorize: number;
    checkBlackList: number;
    checkTime: number;
    processDefinitionLabel: string;
    processDefinitionName: number;
    processDefinitionOid: string;
    processGroupName: string;
    processGroupOid: string;
}

export interface IBpmCoreProcessDefinitionNameSearchResponse {
    coreData: ICoreData[];
}
