import type { ListTypeEnum } from '../../../../../../../../components/Display/Loans/Modals/CorporateLoans/Allotment/ProductDisbursementFeaturesModal/type';

export interface IGetAsProductProductGroupListForComboRequest {
    listType: ListTypeEnum;
    productMainGroupOid: string;
}

export interface IProductGroupList {
    0: string;
    1: string;
}

export interface IGetAsProductProductGroupListForComboResponse {
    productGroupList: IProductGroupList[];
}
