import type { ListTypeEnum } from '../../../../../../../../components/Display/Loans/Modals/CorporateLoans/Allotment/ProductSelectionModal/type';

export interface IGetCcsAsProductGroupListComboRequest {
    listType: ListTypeEnum;
    productMainGroupCode: string;
}

export interface ICcsAsProductGroupListComboList {
    0: string;
    1: string;
}

export interface IGetCcsAsProductGroupListComboResponse {
    productGroupList: ICcsAsProductGroupListComboList[];
}
