export type JReportCallRequest<TReportParams = any, TDataParams = any> = {
    dataParameters: TDataParams;
    reportId: string;
    reportParameters: TReportParams;
};

export type JReportCallResponse = {
    error?: { message: string }; // 'JsonNull'
    pdfContent?: string; //base64
};
