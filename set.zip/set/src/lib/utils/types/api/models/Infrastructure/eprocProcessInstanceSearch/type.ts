export interface IEprocProcessInstanceSearchRequest {
    eprocCustomerNo: string;
    eprocEnd1: string;
    eprocEnd2: string;
    eprocProcessId: string;
    eprocProcessOrganization: string;
    eprocReferenceId: string;
    eprocStart1: string;
    eprocStart2: string;
    eprocStatus: string;
    requestSource: string;
    requestType: string;
}

export interface ICoreData {
    oid: string;
    processName: string;
    referenceId: number;
    status: number;
    user: string;
}

export interface IEprocProcessInstanceSearchResponse {
    coreData: ICoreData[];
}
