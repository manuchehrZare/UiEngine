export interface IEprocProcessDefinitionSearchRequest {
    eprocGroupOid: string;
    eprocProcessId: string;
    eprocProcessName: string;
}

export interface ICoreData {
    eprocAmountCheck: number;
    eprocApprovement: number;
    eprocApproverMessage: number;
    eprocAuthorizationCheck: number;
    eprocBlackList: number;
    eprocDocumentCheck: number;
    eprocGroupOid: string;
    eprocIsActive: number;
    eprocIsEproc: number;
    eprocProcessId: number;
    eprocProcessName: string;
    eprocProcessOid: string;
    eprocReturnToMaker: number;
    eprocTimeCheck: number;
}

export interface IEprocProcessDefinitionSearchResponse {
    coreData: ICoreData[];
}
