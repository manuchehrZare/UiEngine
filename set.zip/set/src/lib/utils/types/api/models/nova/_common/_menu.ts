/**
 * The type of the menuKey parameter of the screen to be opened from the menu.
 */
export type MenuKeyType = string | null;

export interface IMenuItem {
    children?: IMenuItem[] | null;
    menuKey?: MenuKeyType;
    menuName: string;
    screenCode?: string;
    screenDescription?: string | null;
    screenName?: string;
}
