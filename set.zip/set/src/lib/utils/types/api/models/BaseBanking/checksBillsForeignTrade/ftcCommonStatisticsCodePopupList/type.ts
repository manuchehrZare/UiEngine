export interface IFtcCommonStatisticsCodePopupListRequest {
    bfxDiscriminator: string;
    bfxState: string;
    discriminator: string;
    statisticCode: string;
    statisticName: string;
}

export interface ICoreData {
    bfxState: string;
    code: string;
    discriminator: string;
    name: string;
    oid: string;
}

export interface IFtcCommonStatisticsCodePopupListResponse {
    coreData: ICoreData[];
}
