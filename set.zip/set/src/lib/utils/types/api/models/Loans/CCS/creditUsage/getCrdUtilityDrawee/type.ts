export interface IGetCrdUtilityDraweeResponse {
    approveType: string;
    draweeAddress: string;
    mainGroup: string;
    mainOid: string;
    name: string;
    oid: string;
    subGroup: string;
    subOid: string;
    taxNo: string;
    tcId: string;
}
export interface IGetCrdUtilityDraweeRequest {
    draweeName: string;
    draweeOid: string;
    mainGroupOid: string;
    subGroupOid: string;
    tc: string;
    vkn: string;
}
