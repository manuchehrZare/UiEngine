export interface IFinmanCommonListBankCoreData {
    account: number | null;
    adres1: string;
    bank: string;
    bicCode: string;
    city: string;
    corres: number | null;
    counter: number | null;
    counterCorresAccNo: number | null;
    countrycode: string;
    currencyCode: string;
    currencyOid: string;
    customerCode: number | null;
    oid: string;
    shortName: string;
    treasureCorres: number | null;
}

export interface IFinmanCommonListBankDefinitionResponse {
    coreData: IFinmanCommonListBankCoreData[];
}

export interface IFinmanCommonListBankDefinitionRequest {
    bank: string;
    bicCode: string;
    corres: string;
    corresType: string;
    counter: string;
    currencyOid: string;
    treasureCorres: string;
    type: string;
}
