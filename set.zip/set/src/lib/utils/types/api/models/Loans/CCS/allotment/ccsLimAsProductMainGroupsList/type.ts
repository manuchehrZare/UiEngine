import type { ListTypeEnum } from '../../../../../../../../components/Display/Loans/Modals/CorporateLoans/Allotment/ProductDisbursementFeaturesModal/type';

export interface IGetCcsLimAsProductMainGroupsListRequest {
    listType: ListTypeEnum;
}

export interface IProductMainGroupList {
    0: string;
    1: string;
}

export interface IGetCcsLimAsProductMainGroupsListResponse {
    productMainGroupList: IProductMainGroupList[];
}
