import type { IGetTotalDatasetAndValuesOfUsageDataSet } from '../crdCreditUsageControl/type';

export interface IEvaluateFormulasWithDataSetDefRequest {
    dataSetDef: IGetTotalDatasetAndValuesOfUsageDataSet[];
    formulaList: IFormulaListItem[];
    oneFormula: boolean;
}

export interface IFormulaListItem {
    approveChairs: string;
    arlApproveChair: string;
    creditStatus: string;
    creditStopReason: string;
    customerRiskCode: string;
    exceptionAdvisePeriod: string;
    exceptionFixPeriod: string;
    formula: string;
    oid: string;
    processType: string;
    state: string;
}

export interface IEvaluateFormulasWithDataSetDefResponse {
    approveChairs: string;
    arlApproveChair: string;
    creditStatus: string;
    creditStopReason: string;
    customerRiskCode: string;
    detail: string;
    exceptionAdvisePeriod: string;
    exceptionFixPeriod: string;
    processType: string;
    successfulFormul: string;
}
