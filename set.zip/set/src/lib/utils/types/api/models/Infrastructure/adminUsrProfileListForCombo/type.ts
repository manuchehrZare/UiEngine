export interface IAdminUsrProfileListForComboRequest {
    usrListType: string;
}
export interface IUsrProfilesListItem {
    '0': string;
    '1': string;
}
export interface IAdminUsrProfileListForComboResponse {
    usrProfilesList: IUsrProfilesListItem[];
}
