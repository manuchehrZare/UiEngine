export interface ICoreDataItem {
    accCode: number | null | ' ';
    assetClearingDay: number;
    assetDefOid: string;
    assetGroupDefOid: string;
    assetMainGroupDefOid: string;
    cashClearingDay: number;
    couponCalculationMethod: string;
    couponCurrencyOid: string;
    couponInterestType: string;
    currencyOid: string;
    description: string;
    indexCurrencyOid: string;
    isinCode: string;
    issueCurrencyPrice: number;
    issueDate: number;
    issueInstOid: string;
    issuePrice: number;
    issueType: string;
    mainFisDefOid: string;
    maturityCurrencyPrice: number;
    maturityDate: number;
    maturityDayDifference: number;
    maturityFundRate: number;
    maturityStatus: number;
    maturityStopageRate: number;
    maturityType: number;
    maxTradableAmount: number;
    minTradableAmount: number;
    oid: string;
    priceDay: number;
    reescontMethod: string | null;
    registrationGroupCode: number;
    registrationType: number;
    repoAssetMatchRate: number | null;
    securityWithCoupon: number;
    shortDescription: string;
    state: string;
    stockExchangeOid: string | null;
    strepType: string;
    tahvilBono: string;
    tlrefEndexRateDayCount: number;
    yearlyCouponCount: number;
    yearlyCouponRate: number;
}

export interface IFisFiscommonListFisDefResponse {
    coreData: ICoreDataItem[];
}

export interface IFisFiscommonListFisDefRequest {
    assetGroupDefOid: string;
    checkPDate: string;
    currencyOid: string;
    executeQuery: string;
    isinCode: string;
    listPassiveAssets: string;
    maturityDate: string;
    maturityDateOperator: string;
    shortDescription: string;
}
