export interface ICustListBranchForKksComboRquest {}

export interface ICustListBranchForKksComboCoreData {
    0: string | number;
    1: string;
}

export interface ICustListBranchForKksComboResponse {
    coreData?: ICustListBranchForKksComboCoreData[];
}
