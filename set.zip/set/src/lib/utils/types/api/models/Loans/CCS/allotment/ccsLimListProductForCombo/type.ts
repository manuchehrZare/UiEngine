export interface IGetCcsLimListProductForComboRequest {
    groupCode: string;
    mainGroup: string;
}

export interface IGetCcsLimListProductForComboResponseList {
    0: string;
    1: string;
}

export interface IGetCcsLimListProductForComboResponse {
    coreData: IGetCcsLimListProductForComboResponseList[];
}
