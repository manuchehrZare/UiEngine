export interface IGetTCMBRatesRequest {
    currencyCode: string;
}
export interface IGetTCMBRatesResponse {
    buyPrice: number;
    evaluationPrice: number;
}
