import type { ListTypeEnum } from '../../../../../../../components/Display/PaymentSystems/Modals/CardSystems/CardInquiryModal/type';

export interface IProdProductGroupListForComboRequest {
    listType: ListTypeEnum;
    productMainGroupCode: string;
}

export interface IProductGroupList {
    0: string;
    1: string;
}

export interface IProdProductGroupListForComboResponse {
    productGroupList: IProductGroupList[];
}
