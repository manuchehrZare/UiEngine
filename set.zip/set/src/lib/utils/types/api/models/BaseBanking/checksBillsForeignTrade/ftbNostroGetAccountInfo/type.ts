export interface IFtbNostroGetAccountInfoRequest {
    accountOid: string;
    bicCode: string;
    city: string;
    counterAccountNo: string;
    countryCode: string;
    currencyCode: string;
    customerCode: string;
}
export interface IFtbNostroGetAccountInfoCoreDataItem {
    accountNo: string;
    balance: string;
    bankTitle: string;
    bicCode: string;
    city: string;
    counterAccountNo: string;
    countryCode: string;
    currencyCode: string;
    customerCode: string;
    endOfDay: string;
    endOfDayAvailable: string;
    intraDay: string;
    intraDayAvailable: string;
    intraDayUsageCredit: string;
    intraDayUsageDebit: string;
    nostroAccountOid: string;
}
export interface IFtbNostroGetAccountInfoResponse {
    coreData: IFtbNostroGetAccountInfoCoreDataItem[];
}
