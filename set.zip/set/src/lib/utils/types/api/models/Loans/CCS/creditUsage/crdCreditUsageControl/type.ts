export interface IGetTotalDatasetAndValuesOfUsageRequest {
    dataSet: IGetTotalDatasetAndValuesOfUsageDataSet[];
    processId: string;
    usageOid: string;
}

export interface IGetTotalDatasetAndValuesOfUsageDataSet {
    dataSetDef: string;
    values?: string;
}

export interface IGetTotalDatasetAndValuesOfUsageResponse {
    dataSet: IGetTotalDatasetAndValuesOfUsageDataSet[];
}
