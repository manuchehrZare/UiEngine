import type { LocalesType } from '../../../../../../..';

/**
 * name is associated with the referenceDataEnum definition included in each transformation project
 * */
export type ReferenceDataRequestListItem = {
    language: LocalesType;
    name: string; // ReferenceDataEnum
};

export type ReferenceDataResultListItemsListItem = {
    filter: string;
    key: string;
    value: string;
};

export type ReferenceDataResultListItem = {
    isChanged: boolean;
    items: ReferenceDataResultListItemsListItem[];
    language: LocalesType;
    name: string; // ReferenceDataEnum
    version: number;
};

export type ReferenceDataRequest = {
    requestList: ReferenceDataRequestListItem[];
};

export type ReferenceDataResponse = {
    resultList: ReferenceDataResultListItem[];
};
