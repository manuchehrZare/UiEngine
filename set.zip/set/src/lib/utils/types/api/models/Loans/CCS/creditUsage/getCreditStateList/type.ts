export interface ICreditStateCoreData {
    bir1: string;
    code: string;
    filterKey: string;
    name: string;
    sifir0: string;
}
export interface IGetCreditStateListRequest {
    statesList: string;
}
export interface IGetCreditStateListResponse {
    coreData: ICreditStateCoreData[];
}
