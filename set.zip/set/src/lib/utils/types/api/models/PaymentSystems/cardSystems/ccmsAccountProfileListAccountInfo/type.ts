export interface IPpCcmsCardSearchRequest {
    accountNo?: number;
    branchCode?: string;
    corpNo?: string;
    custCustBirthPlace?: string;
    custCustBirthYear?: number;
    custCustCustomerType?: string;
    custCustName?: string;
    custCustSecondName?: string;
    custCustSurname?: string;
    custIndvFatherName?: string;
    custIndvTcId?: number;
    custNo?: number;
    isVirtualCard?: boolean;
}
export interface IPpCardSearchItem {
    accountNo: string;
    accountOid: number;
    accountStatus: string;
    birthDate: number;
    birthPlace: string;
    blockReclassCode: string;
    branchCode: number;
    cardBrand: number;
    cashLimit: number;
    corpNo: number;
    creditLimit: number;
    currExpireYearMonth: number;
    custNo: number;
    doubtCard: string;
    embossName: string;
    nameSurname: string;
    primaryType: string;
    productCode: number;
    productGroupCode: number;
    productMainGroupCode: number;
}

export interface IPpCcmsCardSearchResponse {
    coreData: IPpCardSearchItem[];
}
