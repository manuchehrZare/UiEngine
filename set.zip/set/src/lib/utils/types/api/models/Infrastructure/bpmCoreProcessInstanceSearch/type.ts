export interface IBpmCoreProcessInstanceSearchRequest {
    customerNo: string;
    endDate1: number | null;
    endDate2: number | null;
    processDefinitionName: string;
    processStatus: string;
    referenceId: string;
    startDate1: number | null;
    startDate2: number | null;
}

export interface ICoreData {
    customerCode: number;
    end: number;
    makerName: string;
    processDefinitionLabel: string;
    processId: number;
    processStatus: string;
    processStatusCode: number;
    referenceId: number;
    start: number;
    version: number;
}

export interface IBpmCoreProcessInstanceSearchResponse {
    coreData: ICoreData[];
}
