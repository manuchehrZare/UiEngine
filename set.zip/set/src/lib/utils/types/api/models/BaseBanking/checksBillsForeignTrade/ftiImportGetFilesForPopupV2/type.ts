export interface IFtiImportGetFilesForPopupV2Request {
    branchCode: string;
    currencyCode: string;
    customerCode: string;
    fileNo: string;
    productType: string;
    state: string;
}

export interface ICoreData {
    amount: string;
    branchCode: string;
    currencyCode: string;
    customerCode: string;
    customerGroupOid: string;
    customerOid: string;
    customerTitle: string;
    descriptionOpen: string;
    fileNo: string;
    oid: string;
    productType: string;
    state: string;
}

export interface IFtiImportGetFilesForPopupV2Response {
    coreData: ICoreData[];
}
