import type { IMenuItem } from '../../../../_common';

export interface IFavouritesItem extends IMenuItem {}

export interface IGetFavouritesRequest {
    username: string;
}

export interface IGetFavouritesResponse {
    favoritesObject: string | null;
}
