export interface IDmsStructListTypesRequest {
    itemType?: string;
}

export interface ICoreData {
    itemType: string;
    itemTypeDesc: string;
}

export interface IDmsStructListTypesResponse {
    coreData: ICoreData[];
}
