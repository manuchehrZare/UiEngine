export interface ISetChargedOrganizationRequest {
    orgOid: string;
}

export interface ISetChargedOrganizationResponse {}
