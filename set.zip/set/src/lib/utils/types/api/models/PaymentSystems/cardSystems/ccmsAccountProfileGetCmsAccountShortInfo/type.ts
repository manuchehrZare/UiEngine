export interface ICcmsAccountProfileGetCmsAccountShortInfoRequest {
    accountNo: string;
}

export interface ICcmsAccountProfileGetCmsAccountShortInfoResponse {
    availableAmount: number;
    availableCashAmount: number;
    blockReclassCode: string;
    branchCode: string;
    cashLimit: string;
    creditLimit: string;
    currExpireYearMonth: string;
    currExpireYearMonthWithDay: string;
    fcForwardTotalBal840: number;
    fcForwardTotalBal949: number;
    fcForwardTotalBal978: number;
    fcNewCashBal840?: number;
    fcNewCashBal949?: number;
    fcNewCashBal978?: number;
    nextStatementDate?: number;
    primaryType: string;
    productCode: string;
    productGroupCode: string;
    realAccountNo: string;
    stmtCurrCode: number;
}
