export interface IConsApplicationPopupListRequest {
    applicationNo: string;
    branchCode: string;
    channelCode: string;
    currencyCode: string;
    customerCode: string;
    ignoredStatusCode: string;
    isKdsException: string;
    malikCustCode: string;
    productCode: string;
    productGroupCode: string;
    productMainGroupCode: string;
    statusCode: string;
    statusCodeList: string;
}

export interface ICoreData {
    applicationNo: number;
    applicationOid: string;
    branchCode: string;
    currencyCode: string;
    customerNo: number;
    customerOid: string;
    customerTitle: string;
    customerType: number;
    owner: string;
    productCode: string;
    productGroupCode: string;
    productGroupName: string;
    productName: string;
    productTypeCode: string;
    statusCode: number | string;
}

export interface IConsApplicationPopupListResponse {
    coreData: ICoreData[];
}
