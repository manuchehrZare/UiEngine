export interface IListDraweeGrRegionToComboResponse {
    coreData: IListDraweeGrRegionToComboCoreData[];
}
export interface IListDraweeGrRegionToComboCoreData {
    0: string;
    1: string;
}
export interface IListDraweeGrRegionToComboRequest {
    parentOid: string;
}
