export interface IParameterItem {
    name: string;
    value: string;
}

export interface IRunQueryRequest {
    limit?: number;
    offset?: number;
    parameters: IParameterItem[];
    popupName: string;
}

export interface IRunQueryResponse<T> {
    hasNext: boolean;
    resultList: T[];
}

export enum RunQueryPopupNamesEnum {
    PP_ORGANISATION = 'PP_ORGANISATION',
    PP_USER = 'PP_USER',
}
