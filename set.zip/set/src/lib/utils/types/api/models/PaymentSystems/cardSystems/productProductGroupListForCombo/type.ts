export interface IProductGroupListForComboRequest {
    listType?: string;
    productGroupActive?: string;
    productGroupCode?: string;
    productMainGroupCode?: string;
    productMainGroupCodeOid?: string;
}

export interface IProductGroupListForComboItem {
    0: string;
    1: string;
}

export interface IProductGroupListForComboResponse {
    productGroupList: IProductGroupListForComboItem[];
}
