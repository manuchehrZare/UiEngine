export interface IIdcLoadBankStatementRequest {
    bankStatementOid: string;
}

export interface IIdcLoadBankStatementResponse {
    bankStatement: string;
    fileExtension: string;
    orgFileName: string;
    url: string;
}
