export interface IEprocDefinitionGetProcessGroupsForcomboSpecialRequest {}

export interface IProcessGroupTable {
    0: string;
    1: string;
}

export interface IEprocDefinitionGetProcessGroupsForcomboSpecialResponse {
    processGroupTable: IProcessGroupTable[];
}
