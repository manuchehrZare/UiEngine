export interface IDepTimedepGetTimedepAccountsRequest {
    accCode?: string;
    ammountFirst?: string;
    ammountLast?: string;
    currencyCode?: string;
    custCode?: string;
    orgCode?: string;
    productCode?: string;
    status?: string;
    timeFirst?: string;
    timeLast?: string;
}

export interface IDepTimedepGetTimedepAccountsCoreData {
    accCode: number | null;
    amount: number | null;
    channelCode: string | null;
    createDate: number | null;
    currAccCode: number | null;
    currAccOidInt: string | null;
    currencyCode: string | null;
    custCode: number | null;
    custTitle: string | null;
    internAmount: number | null;
    intRate: number | null;
    isBlocked: number | null;
    isPaid: number | null;
    netInterestAmount: number | null;
    netIntRate: number | null;
    netReturnAmount: number | null;
    oid: string | null;
    orgCode: number | null;
    orgMarginedIntRate: number | null;
    orgPoolRate: number | null;
    originalAmount: number | null;
    poolIntRate: number | null;
    productCode: string | null;
    productReferenceNo: number | null;
    purpose: string | null;
    referenceIntRate: number | null;
    returnType: number | null;
    status: number | null;
    stopageRate: number | null;
    term: number | null;
    termEnd: number | null;
    termStart: number | null;
    termType: string | null;
    totalInterestAmount: number | null;
    useBalance: number | null;
}

export interface IDepTimedepGetTimedepAccountsResponse {
    coreData?: IDepTimedepGetTimedepAccountsCoreData[];
}
