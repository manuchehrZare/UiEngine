export interface IUtcListMessageTranOidRequired {
    termTranOid?: string;
    transactionOid: string;
}
export interface IUtcListMessageTermTranOidRequired {
    termTranOid: string;
    transactionOid?: string;
}

export type IUtcListMessageRequest = IUtcListMessageTranOidRequired | IUtcListMessageTermTranOidRequired;

export interface IUtcListMessageCoreData {
    coreDataReactValues?: IReactValues;
    direction: string;
    messageBitMap1: string;
    messageBitMap2: string;
    messageDate: Date;
    messageOid: string;
    messageType: string;
    sequence: number;
}

export interface IValueData {
    field?: string;
    fieldDescription?: string;
    fieldLength?: string;
    fieldValue?: string;
}

export interface IReactValues {
    coreData?: IValueData[];
}
export interface IUtcListMessageResponse {
    coreData: IUtcListMessageCoreData[];
}
