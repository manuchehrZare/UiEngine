export interface IFtcCommonGetSwiftCodeForPopupV1Request {
    bank: string;
    bicCode: string;
    countryCode: string;
}

export interface IFtcCommonGetSwiftCodeForPopupV1Response {
    coreData: IFtcCommonGetSwiftCodeCoreData[];
}

export interface IFtcCommonGetSwiftCodeCoreData {
    address: number;
    bank: string;
    bicCode: string;
    branchName: string;
    city: string;
    country: string;
    countryCode: string;
    oid: string;
}
