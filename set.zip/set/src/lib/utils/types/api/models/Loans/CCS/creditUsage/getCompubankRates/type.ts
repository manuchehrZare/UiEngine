export interface IGetCompubankRatesRequest {
    currencyCode: string;
}
export interface IGetCompubankRatesResponse {
    buyPrice: number;
    sellPrice: number;
}
