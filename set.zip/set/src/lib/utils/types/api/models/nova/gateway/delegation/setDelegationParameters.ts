import type { AuthenticateResponse } from '../../../../../../..';

export type SetDelegationParametersRequest = {
    delegatingUserOid: string;
};

export type SetDelegationParametersResponse = Pick<AuthenticateResponse, 'token' | 'globals'>;
