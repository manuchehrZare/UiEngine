export enum ChangeConfirmedEnum {
    NO = 'no',
    YES = 'yes',
}

export enum ForgottenPasswordResponseSuccessEnum {
    SUCCESS = '1',
    FAIL = '0',
}

export type ForgottenPasswordRequest = {
    changeConfirmed: `${ChangeConfirmedEnum}`;
    usrUserName: string;
};

export type ForgottenPasswordResponse = {
    confirmationMessage?: string;
    coreInfoMessageId?: string;
    success?: `${ForgottenPasswordResponseSuccessEnum}`;
};
