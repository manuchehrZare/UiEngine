export interface ICcsCollateralListRequest {
    collateralCreditType: string;
    collateralNo: string;
    collateralType: string;
    custCode: string;
    orgCode: string;
    state: string;
    verification: string;
}

export interface ICcsCollateralListCoreData {
    collateralAmount: string | null;
    collateralCreditType: string | null;
    collateralExplanation: string | null;
    collateralNo: string | null;
    collateralOid: string | null;
    collateralType: string | null;
    currCode: string | null;
    custCode: string | null;
    entryDate: string | null;
    gksVersion: string | null;
    orgCode: string | null;
    state: string | null;
    ttksVersion: string | null;
    verification: string | null;
}

export interface ICcsCollateralListResponse {
    coreData: ICcsCollateralListCoreData[];
}
