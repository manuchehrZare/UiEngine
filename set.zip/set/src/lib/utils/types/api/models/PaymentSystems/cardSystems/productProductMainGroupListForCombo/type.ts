export interface IProductMainGroupListForComboRequest {
    listType?: string;
}

export interface IProductMainGroupListForComboItem {
    0: string;
    1: string;
}

export interface IProductMainGroupListForComboResponse {
    productMainGroupList: IProductMainGroupListForComboItem[];
}
