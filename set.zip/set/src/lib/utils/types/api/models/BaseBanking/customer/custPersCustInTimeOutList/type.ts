export interface ICustPersCustInTimeOutListRequest {
    custCustCustomerCode?: string;
    custCustCustomerOid?: string;
}

export interface ICustPersCustInTimeOutListResponse {
    inTimeOutList: number;
}
