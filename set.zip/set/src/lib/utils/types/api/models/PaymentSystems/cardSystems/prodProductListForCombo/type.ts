import type { ListTypeEnum } from '../../../../../../../components/Display/PaymentSystems/Modals/CardSystems/CardInquiryModal/type';

export interface IProdProductListForComboRequest {
    listType: `${ListTypeEnum}`;
    productActive?: string;
    productGroupCode?: string;
    productGroupOid?: string;
    productMainGroupCode?: string;
    productMainGroupCodeOid?: string;
}

export interface IProductList {
    0: string;
    1: string;
}

export interface IProdProductListForComboResponse {
    productList: IProductList[];
}
