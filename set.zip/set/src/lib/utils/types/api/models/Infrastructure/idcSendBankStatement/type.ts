export interface IIdcSendBankStatementRequest {
    bankStatementOid: string;
    from: string;
    message: string;
    subject: string;
    to: string;
}

export interface IIdcSendBankStatementResponse {
    isMailSend: true;
}
