import type { IMenuItem } from '../../api/models/nova/_common';

/**
 * Model of displayed display information to be included in status management.
 */
export type ScreenType = IMenuItem | null;

export const initialScreenValue: ScreenType = null;
