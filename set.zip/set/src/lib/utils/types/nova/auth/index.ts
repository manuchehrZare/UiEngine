import type { AuthenticateResponse } from '../../../..';

/**
 * The model of the login user's information to be included in the state management.
 */
export type AuthenticateType = AuthenticateResponse & { loginUserName: string };

export const initialAuthValue: AuthenticateType | null = null;
