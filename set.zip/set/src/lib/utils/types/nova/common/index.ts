import type { GlobalsItemType } from '..';

export type { GetGlobalsDataOptions, GlobalsItemType, GlobalsObjectType } from './globals';
export { GlobalsItemEnum } from './globals';

/**
 * When globals information is wanted to be given to any component as props, this type can be extended for that component.
 */
export type HelperGlobalsProps = {
    globals: GlobalsItemType[];
};
