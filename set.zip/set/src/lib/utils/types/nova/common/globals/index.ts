import type { MenuKeyType } from '../../..';

/**
 * - Related to the globals information of the person logged in into the set project.
 * - It is related to the name parameter of "GlobalsItemType".
 */
export enum GlobalsItemEnum {
    AccountingBranchCode = 'accountingBranchCode',
    AccountingBranchOid = 'accountingBranchOid',
    AccountingTypeCode = 'accountingTypeCode',
    ChannelCode = 'channelCode',
    ChannelName = 'channelName',
    ChargedOrgUnitCode = 'chargedOrgUnitCode',
    ChargedOrgUnitOID = 'chargedOrgUnitOID',
    ChargedOrganizationCode = 'chargedOrganizationCode',
    ChargedOrganizationOID = 'chargedOrganizationOID',
    ChargedOrganizationType = 'chargedOrganizationType',
    ChargedOtherOrganizationCode = 'chargedOtherOrganizationCode',
    ChargedOtherOrganizationOID = 'chargedOtherOrganizationOID',
    DefaultAccountType = 'defaultAccountType',
    DefaultCountryCode = 'defaultCountryCode',
    DefaultCurrencyCode = 'defaultCurrencyCode',
    DelegatingUserOID = 'delegatingUserOID',
    EmailAddress = 'emailAddress',
    EnvironmentType = 'environmentType',
    InfoMessage = '$infomessage',
    LoginMIS = 'loginMIS',
    MenuKey = '$menuKey',
    OrgUnitCode = 'orgUnitCode',
    OrgUnitOID = 'orgUnitOID',
    OrganizationCode = 'organizationCode',
    OrganizationOID = 'organizationOID',
    OrganizationType = 'organizationType',
    Pagename = '$pagename',
    ParentOrgCode = 'parentOrgCode',
    ParentOrgOID = 'parentOrgOID',
    ParentOrgType = 'parentOrgType',
    PosOrganizationCode = 'posOrganizationCode',
    ProfileOID = 'profileOID',
    SessionHostAddress = 'sessionHostAddress',
    UserFullName = 'userFullName',
    UserName = 'userName',
    UserOID = 'userOID',
    Version = 'version',
}

/**
 * Type definition that can be used to create a new object with global data.
 */
export type GlobalsObjectType = Record<`${Exclude<GlobalsItemEnum, GlobalsItemEnum.MenuKey>}`, string> &
    Partial<Record<`${GlobalsItemEnum.MenuKey}`, MenuKeyType>>;

export type GlobalsItemType = {
    name: `${GlobalsItemEnum}`;
    value: string;
};

/**
 * - For getGlobalsData methods
 * - key : Associated with the key informations that belongs to global data.
 * - sourceData : It is the source globals array information. If defined requested global key is searched in this source, if not by default, the globals array is sourced from storage.
 */
export type GetGlobalsDataOptions = {
    key: `${GlobalsItemEnum}`;
    sourceData?: GlobalsItemType[];
};
