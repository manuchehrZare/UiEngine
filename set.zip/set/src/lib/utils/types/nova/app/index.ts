/**
 * Associated with the settings in the shell application running.
 */
export type AppSettings = {
    detailLog: boolean;
    signalRConsole: boolean;
};

export type AppInformation = {
    settings: AppSettings;
    version: string;
};

export type AppData = {
    sidebar: -1 | string;
};

/**
 * The model of the shell application's information to be included in state management.
 */
export type AppType = {
    app: AppInformation | null;
    data: AppData | null;
    isNova: boolean;
};

export const initialAppValue: AppType = {
    app: null,
    data: null,
    isNova: false,
};
