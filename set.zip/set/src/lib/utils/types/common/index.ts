import type { AxiosRequestConfig } from 'axios';
import type { LocalesType } from '../locales';
import type { IButtonProps, IModalProps } from 'seker-ui';
import type { MenuKeyType } from '../api/models/nova/_common';
import type { GlobalsItemType } from '../nova';
import type { ReferenceDataResultListItemsListItem } from '../api/models/nova/gateway/referenceData';

/**
 * HelperApiProps Usage
 *
 * enum ModalApiEnum {
 *   a,
 *   b,
 * }
 *
 * const test: HelperApiProps<typeof ModalApiEnum> = {
 *   apiProps: {
 *       a: {method: '', url: ''},
 *       b: {method: '', url: ''},
 *   },
 * };
 *
 */
export interface HelperApiProps<TEnum> {
    apiProps: {
        [Property in keyof TEnum]: Required<Pick<AxiosRequestConfig, 'url' | 'method'>>;
    };
}
/** Associated with the environmental information of the transformation projects. */
export enum ProcessEnvEnum {
    Alfa = 'alfa',
    Beta = 'beta',
    Dev = 'development',
    Prod = 'production',
}

export type ProcessEnvType = `${ProcessEnvEnum}`;

/**
 * - nameList : Keeps the key information of the reference data in the form of an array.
 * - language : Keeps the information in which language the reference data will be returned. Default value is "tr".
 */
export type GenerateReferenceDataOptions = {
    language?: LocalesType;
    nameList: string[];
};

/**
 * - menuKey : Represents the menuKey value of the screen.
 * - globals : Represents "globals" data that can be used as a source.
 */
export type GenerateGlobalsDataByMenuKeyOptions = {
    globals?: GlobalsItemType[];
    menuKey: MenuKeyType;
};

/**
 * - selectedBranchData : Represents the selected branch value of the screen.
 * - globals : Represents "globals" data that can be used as a source.
 */
export type GenerateGlobalsDataByBranchSelectionOptions = {
    globals?: GlobalsItemType[];
    selectedBranch: ReferenceDataResultListItemsListItem | null;
};

export interface IAdornmentButtonProps extends Pick<IButtonProps, 'disabled'> {
    /**
     * If true, the button that opens the modal will be visible.
     */
    show?: boolean;
    /**
     * Allows tooltip to be given to the button.
     */
    tooltip?: string;
}
export interface IHelperModalProps extends Omit<IModalProps, 'design' | 'onClose' | 'children' | 'className'> {
    /**
     * Contains props of button added as adornment to open modal.
     */
    adornmentButtonProps?: IAdornmentButtonProps;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose?: (data: boolean) => void;
}

export enum KeyboardEventCodeEnum {
    Enter = 'Enter',
    NumpadEnter = 'NumpadEnter',
}

export enum YesNoDataEnum {
    YesValue = '1',
    NoValue = '0',
}

export enum ActivityStatusDataEnum {
    Active = 'A',
    Inactive = 'I',
    New = 'Y',
    Lost = 'K',
}

export enum ClosenessStatusDataEnum {
    Close = '0',
    NotClose = '1',
}

export enum PotentialDataEnum {
    PotentialCustomer = '1',
    RegisteredCustomer = '0',
}

export enum RealCustomerDataEnum {
    RealCustomer = 1,
    NotRealCustomer = 0,
}

export enum CountryNameEnum {
    TR = 'TR',
    KK = 'KK',
}

export enum ShowCorporateBranchComboEnum {
    Unselected = '0',
    Selected = '1',
}

export enum TimeOutListEnum {
    NotTimeot = 0,
    Timeout = 1,
}

export enum DocumentTypeEnum {
    HTML = 'html',
    PDF = 'pdf',
}
