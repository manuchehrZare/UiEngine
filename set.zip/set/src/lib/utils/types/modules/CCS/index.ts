/**
 * Associated with the project names of the CCS team.
 */
export enum CCSModulesEnum {
    ARL = 'ARL',
    Collateral = 'collateral',
    CreditUsage = 'creditUsage',
    Exim = 'exim',
    Limit = 'limit',
    Proposal = 'proposal',
    Utility = 'utility',
}
