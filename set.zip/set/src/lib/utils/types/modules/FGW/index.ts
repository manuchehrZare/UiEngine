/**
 * Associated with the project names of the FGW team.
 */
export enum FGWModulesEnum {
    KKBGW = 'KKBGW',
}
