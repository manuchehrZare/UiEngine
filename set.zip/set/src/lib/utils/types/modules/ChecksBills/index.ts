/**
 * Associated with the project names of the checksBills team.
 */
export enum ChecksBillsModulesEnum {
    Bills = 'bills',
    Checks = 'checks',
}
