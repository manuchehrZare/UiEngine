/**
 * Associated with the project names of the payment systems team.
 */
export enum PaymentSystemsModulesEnum {
    PayFirmPayments = 'payFirmPayments',
}
