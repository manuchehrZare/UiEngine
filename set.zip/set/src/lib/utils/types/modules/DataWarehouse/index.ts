/**
 * Associated with the project names of the DataWarehouse team.
 */
export enum DataWarehouseModulesEnum {
    LegalReport = 'legalReport',
}
