/**
 * Associated with the project names of the loans team.
 */
export enum LoansModulesEnum {
    ConsumerLoans = 'consumerLoans',
}
