/**
 * Associated with the project names of the foreign trade team.
 */
export enum ForeignTradeModulesEnum {
    FTRImport = 'FTRImport',
    FTRSwift = 'FTRSwift',
    FTRTrade = 'FTRTrade',
}
