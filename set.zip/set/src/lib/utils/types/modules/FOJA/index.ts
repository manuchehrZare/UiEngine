/**
 * Associated with the project names of the FOJA team.
 */
export enum FOJAModulesEnum {
    BPM = 'BPM',
    DMS = 'DMS',
    MOP = 'MOP',
}
