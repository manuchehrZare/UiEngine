/**
 * Associated with the project names of the infrastructure team.
 */
export enum InfrastructureModulesEnum {
    Administration = 'administration',
    Batch = 'batch',
    DigitalApprove = 'digitalApprove',
    IDC = 'IDC',
    Product = 'product',
    Utility = 'utility',
}
