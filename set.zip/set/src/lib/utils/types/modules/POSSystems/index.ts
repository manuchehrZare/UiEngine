/**
 * Associated with the project names of the POS systems team.
 */
export enum POSSystemsModulesEnum {
    POS = 'POS',
    UTC = 'UTC',
}
