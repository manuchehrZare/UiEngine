/**
 * Associated with the project names of the card payment systems team.
 */
export enum CardPaymentSystemsModulesEnum {
    AMS = 'AMS',
    Application = 'application',
    CMS = 'CMS',
    CardCore = 'cardCore',
    CommercialCard = 'commercialCard',
    DebitCardAMS = 'debitCardAMS',
    DebitCardSMS = 'debitCardSMS',
    InterChange = 'interChange',
    LKS = 'LKS',
    SekerBonus = 'sekerBonus',
    SekerCompany = 'sekerCompany',
    Switch = 'switch',
}
