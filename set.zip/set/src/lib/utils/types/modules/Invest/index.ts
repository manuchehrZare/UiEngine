/**
 * Associated with the project names of the invest team.
 */
export enum InvestModulesEnum {
    BranchForeignExchangeScreen = 'branchForeignExchangeScreen',
    FinmanMoneyMarket = 'finmanMoneyMarket',
    FinmanSwap = 'finmanSwap',
    FisFistrade = 'fisFistrade',
    FisRepo = 'fisRepo',
    Invest = 'invest',
}
