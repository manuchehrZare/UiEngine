/**
 * Associated with the common names of all projects.
 */
export enum ModulesEnum {
    ATMSystems = 'ATMSystems',
    BlackList = 'blackList',
    Block = 'block',
    CCS = 'CCS',
    CardPaymentSystems = 'cardPaymentSystems',
    ChecksBills = 'checksBills',
    Customer = 'customer',
    DataWarehouse = 'dataWarehouse',
    Deposit = 'deposit',
    EFT = 'EFT',
    FGW = 'FGW',
    FOJA = 'FOJA',
    ForeignTrade = 'foreignTrade',
    Infrastructure = 'infrastructure',
    Invest = 'invest',
    Loans = 'loans',
    POSSystems = 'POSSystems',
    PaymentSystems = 'paymentSystems',
    ProductPackage = 'productPackage',
    RiskMonitoring = 'riskMonitoring',
}

export { CCSModulesEnum } from './CCS';
export { CardPaymentSystemsModulesEnum } from './CardPaymentSystems';
export { ChecksBillsModulesEnum } from './ChecksBills';
export { DataWarehouseModulesEnum } from './DataWarehouse';
export { FGWModulesEnum } from './FGW';
export { FOJAModulesEnum } from './FOJA';
export { ForeignTradeModulesEnum } from './ForeignTrade';
export { InfrastructureModulesEnum } from './Infrastructure';
export { InvestModulesEnum } from './Invest';
export { LoansModulesEnum } from './Loans';
export { POSSystemsModulesEnum } from './POSSystems';
export { PaymentSystemsModulesEnum } from './PaymentSystems';
