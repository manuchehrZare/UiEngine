import { merge } from 'lodash';
import { constants as sekerUIConstants } from 'seker-ui';
import { api } from './api';
import { app } from './app';
import { common } from './common';
import { design } from './design';
import { key } from './key';
import { environments } from './environments';

export const constants = merge(sekerUIConstants, { api, app, common, design, key, environments });
