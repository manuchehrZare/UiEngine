export const common = {
    library: {
        documentation: '',
        localization: {
            defaultLng: 'tr',
            defaultFallbackLng: ['tr', 'en'],
        },
    },
};
