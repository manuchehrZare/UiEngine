import { theme } from 'seker-ui';

export const design = {
    backgroundColor: {
        body: theme.palette.grey[200],
    },
    className: {
        contentLayout: 'set-content-layout',
        contentLayoutBox: 'set-content-layout-box',
        contentLayoutCustomScrollbar: 'set-content-layout-custom-scrollbar',
        footer: 'set-content-footer',
    },
    message: {
        minWidth: 350,
        maxWidth: 375,
        borderRadius: 5,
    },
    padding: {
        common: {
            unit: 1.5,
            pixel: 12,
        },
        layout: {
            x: {
                unit: { xs: 1.5, sm: 4, md: 8, lg: 9, xl: 9.5, xxl: 9.5 },
                pixel: { xs: 12, sm: 32, md: 64, lg: 72, xl: 76, xxl: 76 },
            },
            y: {
                unit: 1.5,
                pixel: 12,
            },
        },
        paper: {
            x: {
                unit: 3,
                pixel: 24,
            },
            y: {
                unit: 2,
                pixel: 16,
            },
        },
    },
};
