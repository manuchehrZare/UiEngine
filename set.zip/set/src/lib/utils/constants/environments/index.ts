import { loans } from './loans';
import { paymentSystems } from './paymentSystems';
import { baseBanking } from './baseBanking';

export const environments = {
    baseBanking,
    loans,
    paymentSystems,
};
