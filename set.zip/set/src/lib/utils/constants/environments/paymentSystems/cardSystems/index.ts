export const cardSystems = {
    ams: {
        alfa: 'https://ams-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://ams-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://ams-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://ams-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    cms: {
        alfa: 'https://cms-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://cms-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://cms-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://cms-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    interChange: {
        alfa: 'https://interchange-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://interchange-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://interchange-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://interchange-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    switch: {
        alfa: 'https://switch-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://switch-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://switch-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://switch-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
};
