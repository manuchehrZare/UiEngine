export const posAndAtm = {
    pos: {
        alfa: 'https://pos-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://pos-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://pos-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://pos-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    atm: {
        alfa: 'https://atm-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://atm-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://atm-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://atm-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
};
