import { cardSystems } from './cardSystems';
import { posAndAtm } from './posAndAtm';

export const paymentSystems = {
    cardSystems,
    cashManagement: {
        alfa: 'https://pay-firmpayments-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://pay-firmpayments-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://pay-firmpayments-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://pay-firmpayments-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    posAndAtm,
};
