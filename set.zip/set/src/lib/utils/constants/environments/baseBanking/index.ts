export const baseBanking = {
    customer: {
        alfa: 'https://customer-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://customer-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://customer-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://customer-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
};
