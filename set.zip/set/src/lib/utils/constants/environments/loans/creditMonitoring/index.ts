export const creditMonitoring = {
    arl: {
        alfa: 'https://ccsarl-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://ccsarl-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://ccsarl-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://ccsarl-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    riskMonitoring: {
        alfa: 'https://riskmonitoring-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://riskmonitoring-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://riskmonitoring-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://riskmonitoring-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
};
