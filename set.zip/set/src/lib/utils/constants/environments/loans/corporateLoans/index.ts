export const corporateLoans = {
    collateral: {
        alfa: 'https://ccs-collateral-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://ccs-collateral-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://ccs-collateral-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://ccs-collateral-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    creditUsage: {
        alfa: 'https://ccscredit-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://ccscredit-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://ccscredit-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://ccscredit-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    proposal: {
        alfa: 'https://ccs-proposal-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://ccs-proposal-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://ccs-proposal-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://ccs-proposal-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
};
