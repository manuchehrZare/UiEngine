import { corporateLoans } from './corporateLoans';
import { creditMonitoring } from './creditMonitoring';

export const loans = {
    consumerLoans: {
        alfa: 'https://consumerloans-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        beta: 'https://consumerloans-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        development: 'https://consumerloans-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
        production: 'https://consumerloans-ui-set-alfa.apps.nprdocp.sekerbank.com.tr',
    },
    corporateLoans,
    creditMonitoring,
};
