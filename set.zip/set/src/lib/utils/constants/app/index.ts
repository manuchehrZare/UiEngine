export const app = {
    shortTitle: 'SET',
    delay: {
        CLOSING_LOADING_DELAY: 750,
        LOGIN_REDIRECT_DELAY: 5000,
    },
};
