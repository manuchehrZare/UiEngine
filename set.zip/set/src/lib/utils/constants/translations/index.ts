import { i18n, locale } from '../../locales';

export const translations = {
    api: {
        timeoutErrorMessage: i18n.t(locale.notifications.timeoutPleaseTryAgain),
    },
    app: {
        title: i18n.t(locale.common.sekerbankInformationTechnologies),
    },
    notifications: {
        navigateToLoginPage: i18n.t(locale.notifications.navigateToLoginPage),
        noSearchedData: i18n.t(locale.notifications.noSearchedData),
        screenNotFound: i18n.t(locale.notifications.screenNotFound),
    },
};
