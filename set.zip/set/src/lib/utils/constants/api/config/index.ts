export const config = {
    timeout: 940000,
};
