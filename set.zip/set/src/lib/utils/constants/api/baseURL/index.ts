export const baseURL = {
    nova: {
        alfa: 'https://nova-gateway-nova-set-alfa.nprd.ocp.sekerbank.com.tr',
        beta: 'https://nova-gateway-nova-set-alfa.nprd.ocp.sekerbank.com.tr',
        development: 'https://nova-gateway-nova-set-alfa.nprd.ocp.sekerbank.com.tr',
        production: 'https://nova-gateway-nova-set-prod.ocp.sekerbank.com.tr',
    },
};
