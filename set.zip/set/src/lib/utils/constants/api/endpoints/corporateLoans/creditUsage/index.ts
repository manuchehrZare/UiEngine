import { credit } from './credit';
import { utility } from './utility';

export const creditUsage = {
    credit,
    utility,
};
