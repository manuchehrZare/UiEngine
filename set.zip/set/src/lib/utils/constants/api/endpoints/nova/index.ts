import { gateway } from './gateway';
import { infra } from './infra';

export const nova = {
    gateway,
    infra,
};
