export const credit = {
    credit: {
        getCreditStateList: {
            POST: {
                url: '/nova-ccs-ccscredit/credit/credit/getCreditStateList',
                method: 'POST',
            },
        },
    },
    crdCreditUsage: {
        usageListForPopup: {
            POST: {
                url: '/nova-ccs-ccscredit/credit/crdCreditUsage/usageListForPopup',
                method: 'POST',
            },
        },
    },
    crdCreditUsageControl: {
        getTotalDatasetAndValuesOfUsage: {
            POST: {
                url: '/nova-ccs-ccscredit/credit/crdCreditUsageControl/getTotalDatasetAndValuesOfUsage',
                method: 'POST',
            },
        },
    },
};
