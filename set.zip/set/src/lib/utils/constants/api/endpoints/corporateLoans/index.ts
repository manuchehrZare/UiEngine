import { creditUsage } from './creditUsage';

export const corporateLoans = { creditUsage };
