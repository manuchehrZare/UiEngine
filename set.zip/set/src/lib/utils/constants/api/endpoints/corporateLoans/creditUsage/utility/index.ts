export const utility = {
    utilityDraweeGRDef: {
        listDraweeGrRegionToCombo: {
            POST: {
                url: '/nova-ccs-ccscredit/utility/utilityDraweeGRDef/listDraweeGrRegionToCombo',
                method: 'POST',
            },
        },
    },
    crdUtilityDrawee: {
        getCrdUtilityDrawee: {
            POST: {
                url: '/nova-ccs-ccscredit/utility/crdUtilityDrawee/getCrdUtilityDrawee',
                method: 'POST',
            },
        },
    },
};
