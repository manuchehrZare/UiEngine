import { nova } from './nova';
import { corporateLoans } from './corporateLoans';

export const endpoints = { nova, corporateLoans };
