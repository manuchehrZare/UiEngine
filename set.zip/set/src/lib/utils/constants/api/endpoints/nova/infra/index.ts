export const infra = {
    admin: {
        user: {
            authorization: {
                authorize: {
                    POST: {
                        url: '/nova-infra-admin/user/authorization/authorize',
                        method: 'POST',
                    },
                },
            },
            delegation: {
                getDelegatingUsers: {
                    POST: {
                        url: '/nova-infra-admin/user/delegation/getDelegatingUsers',
                        method: 'POST',
                    },
                },
            },
            password: {
                changePassword: {
                    POST: {
                        url: '/nova-infra-admin/user/password/changePassword',
                        method: 'POST',
                    },
                },
                forgottenPassword: {
                    POST: {
                        url: '/nova-infra-admin/user/password/forgottenPassword',
                        method: 'POST',
                    },
                },
            },
            setChargedOrganization: {
                url: '/nova-infra-admin/user/setChargedOrganization',
                method: 'POST',
            },
        },
    },
    core: {
        popup: {
            runQuery: {
                POST: {
                    url: '/nova-infra-core/popup/run-query',
                    method: 'POST',
                },
            },
        },
    },
    utility: {
        user: {
            userMenuFavorites: {
                getFavourites: {
                    POST: {
                        url: '/nova-infra-utility/user/userMenuFavorites/getFavorites',
                        method: 'POST',
                    },
                },
            },
        },
    },
};
