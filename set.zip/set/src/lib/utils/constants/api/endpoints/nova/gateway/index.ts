export const gateway = {
    authentication: {
        authenticate: {
            POST: {
                url: '/nova/gateway/authentication/authenticate',
                method: 'POST',
            },
        },
    },
    delegation: {
        setDelegationParameters: {
            POST: {
                url: '/nova/gateway/delegation/setDelegationParameters',
                method: 'POST',
            },
        },
    },
    genericSetCaller: {
        POST: {
            url: '/nova/gateway/genericSetCaller',
            method: 'POST',
        },
    },
    jReportCall: {
        POST: {
            url: '/nova/gateway/jReportCall',
            method: 'POST',
        },
    },
    referenceData: {
        POST: {
            url: '/nova/gateway/referenceData',
            method: 'POST',
        },
    },
};
