import { baseURL } from './baseURL';
import { config } from './config';
import { endpoints } from './endpoints';

export const api = { baseURL, config, endpoints };
