export const key = {
    LINK_REF: '?ref=',
    SETUI_LANGUAGE: 'SETUI-language',
    SETUI_Provider_ProjectProps: 'SETUI-provider-projectProps',
    SET_APP: 'SET_APP',
    SET_AUTH: 'SET_AUTH',
    SET_QUERY: 'SET_QUERY',
    SET_SCREEN: 'SET_SCREEN',
    path: 'path',
    x_requestId: 'x-request-id',
};
