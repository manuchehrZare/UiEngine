import { useTranslation as usei18nTranslation } from 'react-i18next';
import type { ChangeLanguageOptions } from 'seker-ui';
import { deepCopy, deepKeysAsArray, setLocalStorageItem } from 'seker-ui';
import { set } from 'lodash';
import { defaultlocaleData, i18n, i18nInit, languageStorageKey } from '../../locales/_i18nInstance';

/**
 * @param lng New Language Value
 * @param reload for window.location.reload active param. ( default : true )
 * @param callback method to work after language change.
 */
export const i18nChangeLanguage = ({ lng, callback, reload }: ChangeLanguageOptions): void => {
    document.documentElement.lang = lng;
    document.documentElement.setAttribute('lang', lng);
    setLocalStorageItem(languageStorageKey, lng);
    const prevLng = i18n.language;
    prevLng !== lng && reload !== false && window.location.reload();
    setTimeout(() => {
        i18n.changeLanguage(lng, callback);
    }, 0);
};

const getLocaleData = () => {
    const localeData = deepCopy(defaultlocaleData);
    const keyArr = deepKeysAsArray(localeData);

    keyArr.forEach((path) => {
        set(localeData, path, path.replace('.', ':'));
    });
    return localeData;
};

// eslint-disable-next-line
export const useTranslation = () => {
    const params = usei18nTranslation();
    return { ...params, locale: getLocaleData() };
};

const locale = getLocaleData();
export { i18n, i18nInit, locale };
