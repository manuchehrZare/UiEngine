/**
 * Common
 */

export const Common = {};
