import { Common } from './common';
import { BaseBanking } from './units/BaseBanking';
import { DigitalBanking } from './units/DigitalBanking';
import { Loans } from './units/Loans';
import { PaymentSystems } from './units/PaymentSystems';
import { Infrastructure } from './units/Infrastructure';

export const SETModals = {
    ...Common,
    ...BaseBanking,
    ...DigitalBanking,
    ...Loans,
    ...PaymentSystems,
    ...Infrastructure,
};
