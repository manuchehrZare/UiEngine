/**
 * Infrastructure Unit
 */
import { default as BpmProcessDefinitionSelectionModal } from '../../../components/Display/Infrastructure/Modals/BpmProcessDefinitionSelectionModal';
import { default as BpmProcessSelectionModal } from '../../../components/Display/Infrastructure/Modals/BpmProcessSelectionModal';
import { default as DocumentTypesModal } from '../../../components/Display/Infrastructure/Modals/DocumentTypesModal';
import { default as EprocProcessDefinitionSelectionModal } from '../../../components/Display/Infrastructure/Modals/EprocProcessDefinitionSelectionModal';
import { default as EprocProcessSelectionModal } from '../../../components/Display/Infrastructure/Modals/EprocProcessSelectionModal';
import { default as ExtractModal } from '../../../components/Display/Infrastructure/Modals/ExtractModal';
import { default as InstitutionSelectionModal } from '../../../components/Display/Infrastructure/Modals/InstitutionSelectionModal';
import { default as UnitInquiryModal } from '../../../components/Display/Infrastructure/Modals/UnitInquiryModal';
import { default as UserInquiryModal } from '../../../components/Display/Infrastructure/Modals/UserInquiryModal';

export const Infrastructure = {
    BpmProcessDefinitionSelectionModal,
    BpmProcessSelectionModal,
    DocumentTypesModal,
    EprocProcessDefinitionSelectionModal,
    EprocProcessSelectionModal,
    ExtractModal,
    InstitutionSelectionModal,
    UnitInquiryModal,
    UserInquiryModal,
};
