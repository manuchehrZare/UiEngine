/**
 * Loans Unit
 */
import { default as CollateralSelectionModal } from '../../../components/Display/Loans/Modals/CorporateLoans/Allotment/CollateralSelectionModal';
import { default as ProductDisbursementFeaturesModal } from '../../../components/Display/Loans/Modals/CorporateLoans/Allotment/ProductDisbursementFeaturesModal';
import { default as ProductSelectionModal } from '../../../components/Display/Loans/Modals/CorporateLoans/Allotment/ProductSelectionModal';
import { default as PersonalLoanApplicationInquiryModal } from '../../../components/Display/Loans/Modals/ConsumerLoans/PersonalLoanApplicationInquiryModal';
import { default as InterlocutorInquiryModal } from '../../../components/Display/Loans/Modals/CorporateLoans/CreditUsage/InterlocutorInquiryModal';
import { default as LoanRequestFormSelectionModal } from '../../../components/Display/Loans/Modals/CorporateLoans/CreditUsage/LoanRequestFormSelectionModal';
import { default as FormulaDetailRegion } from '../../../components/Display/Loans/Regions/CorporateLoans/CreditUsage/FormulaDetailRegion';

export const Loans = {
    CollateralSelectionModal,
    InterlocutorInquiryModal,
    LoanRequestFormSelectionModal,
    PersonalLoanApplicationInquiryModal,
    ProductDisbursementFeaturesModal,
    ProductSelectionModal,
    FormulaDetailRegion,
};
