/**
 * BaseBanking Unit
 */
import { default as AccountSelectionModal } from '../../../components/Display/BaseBanking/Modals/DepositsAndAccounting/AccountSelectionModal';
import { default as AssetSelectionModal } from '../../../components/Display/BaseBanking/Modals/Invest/AssetSelectionModal';
import { default as ChecksBillsForeignTradeBicCodeListModal } from '../../../components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/ChecksBillsForeignTradeBicCodeListModal';
import { default as CustomerInquiryModal } from '../../../components/Display/BaseBanking/Modals/Customer/CustomerInquiryModal';
import { default as DepositAccountInquiryModal } from '../../../components/Display/BaseBanking/Modals/DepositsAndAccounting/DepositAccountInquiryModal';
import { default as FilesModal } from '../../../components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/FilesModal';
import { default as InvestBicCodeListModal } from '../../../components/Display/BaseBanking/Modals/Invest/InvestBicCodeListModal';
import { default as JointCustomerInquiryModal } from '../../../components/Display/BaseBanking/Modals/Customer/JointCustomerInquiryModal';
import { default as NostroAccountListModal } from '../../../components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/NostroAccountListModal';
import { default as FTCCommonStatisticsModal } from '../../../components/Display/BaseBanking/Modals/ChecksBillsForeignTrade/FTCCommonStatisticsModal';

export const BaseBanking = {
    AccountSelectionModal,
    AssetSelectionModal,
    ChecksBillsForeignTradeBicCodeListModal,
    CustomerInquiryModal,
    DepositAccountInquiryModal,
    FilesModal,
    InvestBicCodeListModal,
    JointCustomerInquiryModal,
    NostroAccountListModal,
    FTCCommonStatisticsModal,
};
