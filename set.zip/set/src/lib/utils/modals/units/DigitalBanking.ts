/**
 * DigitalBanking Unit
 */
export const DigitalBanking = {};
