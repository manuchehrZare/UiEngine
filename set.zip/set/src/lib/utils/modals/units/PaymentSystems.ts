/**
 * PaymentSystems Unit
 */
import CardInquiryModal from '../../../components/Display/PaymentSystems/Modals/CardSystems/CardInquiryModal';

export const PaymentSystems = {
    CardInquiryModal,
};
