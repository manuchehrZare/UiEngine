/* eslint-disable react-hooks/exhaustive-deps */
import type { JSX, PropsWithChildren } from 'react';
import { useEffect, useState } from 'react';
import type { IModalViewerProps } from './type';
import { Button, CardNumber, Input, MessageTypeEnum, NumberInput, Tooltip, message } from 'seker-ui';
import { MoreHoriz } from '@mui/icons-material';
import type { SETModalsCommonProps, SETModalsType } from '../../..';
import { KeyboardEventCodeEnum, SETModals, useTranslation } from '../../..';
import { generateClass } from 'seker-ui/bundle/lib/utils';
import { omit } from 'lodash';

type ModalValues = SETModalsCommonProps & {
    show: boolean;
};

const ModalViewer = <T extends SETModalsType>({
    component,
    modalComponent,
    adornmentButtonProps,
    modalProps,
    ...rest
}: PropsWithChildren<IModalViewerProps<T>>): JSX.Element => {
    const { t, locale } = useTranslation();
    const initModalValues: ModalValues = { show: false };
    const [modalValues, setModalValues] = useState<ModalValues>(initModalValues);

    const handleClose = (showValue: boolean) => {
        setModalValues({ ...initModalValues, show: showValue });
        modalProps?.onClose && modalProps?.onClose(showValue);
    };

    // eslint-disable-next-line
    const handleButtonOnClick = (_: any) => {
        setModalValues({ show: true, eventOwnerEl: 'button' });
    };

    const getComponent = () => {
        switch (component) {
            case 'Button': {
                return Button;
            }
            case 'Input': {
                return Input;
            }
            case 'NumberInput': {
                return NumberInput;
            }
            case 'CardNumber': {
                return CardNumber;
            }
            default: {
                return Input;
            }
        }
    };

    useEffect(() => {
        modalValues.show === true && setModalValues(initModalValues);
    }, [modalComponent, component]);

    const DynamicModalComponent = SETModals[modalComponent];
    const Component = getComponent();
    return (
        <>
            {/* @ts-ignore */}
            <Component
                {...(component !== 'Button' && { control: (rest as any).control, name: rest.name })}
                {...(component !== 'Button' &&
                    adornmentButtonProps?.show !== false && {
                        endAdornment: (
                            <Tooltip title={adornmentButtonProps?.tooltip || ''} sx={{ mr: '-5px' }}>
                                <Button
                                    iconButton
                                    icon={<MoreHoriz />}
                                    disabled={adornmentButtonProps?.disabled}
                                    onClick={handleButtonOnClick}
                                />
                            </Tooltip>
                        ),
                        onKeyPress: async (e: any) => {
                            if (e.key === KeyboardEventCodeEnum.Enter) {
                                setModalValues({
                                    show: true,
                                    eventOwnerEl: e.target.className.includes(generateClass('Button'))
                                        ? 'button'
                                        : 'input',
                                });
                            }
                        },
                    })}
                {...(component === 'Button' && {
                    onClick: (e) => {
                        handleButtonOnClick(e);

                        (rest as any).onClick && (rest as any).onClick(e);
                    },
                })}
                {...(component === 'Button' ? omit(rest, ['onClick']) : rest)}
                {...(component === 'CardNumber' && { component: 'NumberInput' })}
            />
            {DynamicModalComponent ? (
                /** @ts-ignore */
                <DynamicModalComponent
                    {...modalProps}
                    eventOwnerEl={modalValues.eventOwnerEl}
                    {...(component !== 'Button' && { inputProps: { control: (rest as any).control, name: rest.name } })}
                    show={modalValues.show}
                    onClose={handleClose}
                />
            ) : (
                message({ variant: MessageTypeEnum.error, message: t(locale.notifications.componentNotImported) })
            )}
        </>
    );
};

export default ModalViewer;
