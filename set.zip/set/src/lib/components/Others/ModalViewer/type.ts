import type { IButtonProps, ICardNumberInputProps, IInputProps, INumberInputProps } from 'seker-ui';
import type { ComponentProps } from 'react';
import type { IHelperModalProps, SETModals, SETModalsType } from '../../..';

export interface IModalViewerCommonProps<T extends SETModalsType>
    extends Pick<IHelperModalProps, 'adornmentButtonProps'> {
    modalComponent: SETModalsType;
    modalProps?: Omit<ComponentProps<(typeof SETModals)[T]>, 'show' | 'eventOwnerEl' | 'onClose' | 'inputProps'> &
        Partial<Pick<ComponentProps<(typeof SETModals)[T]>, 'onClose'>>;
}

export interface IInputComponentProps extends Omit<IInputProps, 'endAdornment' | 'onKeyPress'> {
    component: 'Input';
}

export interface INumberInputComponentProps extends Omit<INumberInputProps, 'endAdornment' | 'onKeyPress'> {
    component: 'NumberInput';
}

export interface IButtonComponentProps extends IButtonProps {
    component: 'Button';
}

export interface ICardNumberComponentProps
    extends Omit<ICardNumberInputProps, 'component' | 'endAdornment' | 'onKeyPress'> {
    component: 'CardNumber';
}

export type IModalViewerProps<T extends SETModalsType> = IModalViewerCommonProps<T> &
    (IInputComponentProps | INumberInputComponentProps | IButtonComponentProps | ICardNumberComponentProps);
