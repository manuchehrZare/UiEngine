/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { IDmsDocumentViewerProps, IRichEditorFormValues } from './type';
import { DocumentTypeEnum, GenericSetCallerEnum, HttpStatusCodeEnum, getGenericSetCaller } from '../../../utils';
import type {
    IDmsDocGetDocContentRequest,
    IDmsDocGetDocContentResponse,
} from '../../../utils/types/api/models/Infrastructure/dmsDocGetDocContent/type';
import { useAxios } from '../../../hooks/useAxios';
import { Box, PdfViewer, RichEditor, View, base64Decryption, useForm } from 'seker-ui';

const DmsDocumentViewer: FC<IDmsDocumentViewerProps> = ({
    charset,
    onError,
    onReturnData,
    outerHeight,
    payloadData,
    pdfViewerProps,
    richEditorProps,
}): JSX.Element => {
    const [documentType, setDocumentType] = useState<string>();
    const [pdfData, setPdfData] = useState<string>();
    const { control, setValue } = useForm<IRichEditorFormValues>({ defaultValues: { richEditor: '' } });

    const [{ error: dmsDocGetDocContentError }, dmsDocGetDocContentCall] = useAxios<
        IDmsDocGetDocContentResponse,
        IDmsDocGetDocContentRequest
    >(getGenericSetCaller(GenericSetCallerEnum.DMS_DOC_GET_DOC_CONTENT), { manual: true });

    const getDmsDocGetDocContent = async () => {
        const response = await dmsDocGetDocContentCall({
            data: payloadData,
        });

        if (response?.status === HttpStatusCodeEnum.Ok) {
            onReturnData?.(response);
            const docType = response?.data?.localFileName?.split('.')?.[1];
            setDocumentType(docType);

            if (docType === DocumentTypeEnum.HTML) {
                setValue('richEditor', base64Decryption(response?.data?.content, charset)?.data as string);
            } else if (docType === DocumentTypeEnum.PDF) {
                setPdfData(response?.data?.content);
            }
        }
    };

    useEffect(() => {
        payloadData && getDmsDocGetDocContent();
    }, [payloadData]);

    useEffect(() => {
        dmsDocGetDocContentError && onError?.(dmsDocGetDocContentError);
    }, [dmsDocGetDocContentError]);

    return (
        <Box height={outerHeight}>
            <View show={documentType === DocumentTypeEnum.PDF}>
                <PdfViewer source={pdfData} {...pdfViewerProps} />
            </View>
            <View show={documentType === DocumentTypeEnum.HTML}>
                <RichEditor
                    name="richEditor"
                    control={control}
                    height={outerHeight || '100%'}
                    sx={{
                        '.fr-view': {
                            padding: '0px !important',
                        },
                        '.fr-element p:first-of-type': {
                            display: 'none',
                        },
                        '.fr-element table:nth-of-type(1)': {
                            margin: 'auto',
                        },
                    }}
                    toolbar={false}
                    disabled
                    {...richEditorProps}
                />
            </View>
        </Box>
    );
};

export default DmsDocumentViewer;
