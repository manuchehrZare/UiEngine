import type { AxiosError, AxiosResponse } from 'axios';
import type {
    IDmsDocGetDocContentRequest,
    IDmsDocGetDocContentResponse,
} from '../../../utils/types/api/models/Infrastructure/dmsDocGetDocContent/type';
import type { HelperComponentProps, IRichEditorProps, IPDFViewerProps } from 'seker-ui';

export interface IDmsDocumentViewerProps extends Pick<HelperComponentProps, 'outerHeight'> {
    charset?: string;
    onError?: (error: AxiosError<any, IDmsDocGetDocContentRequest> | null) => void;
    onReturnData?: (data: AxiosResponse<IDmsDocGetDocContentResponse, any>) => void;
    payloadData: IDmsDocGetDocContentRequest;
    pdfViewerProps?: Pick<IPDFViewerProps, 'className' | 'design' | 'height' | 'id' | 'width'>;
    richEditorProps?: Pick<
        IRichEditorProps,
        'charCounterCount' | 'fontFamilyList' | 'fontSizeList' | 'height' | 'label' | 'placeholder' | 'sx' | 'toolbar'
    >;
}

export interface IRichEditorFormValues {
    richEditor: string;
}
