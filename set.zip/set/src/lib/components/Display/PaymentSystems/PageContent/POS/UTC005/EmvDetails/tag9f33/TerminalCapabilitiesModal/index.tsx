import type { FC, JSX } from 'react';
import { Grid, GridItem, useForm, Checkbox, Paper, Nav, Modal, ModalTitle, ModalBody } from 'seker-ui';
import type { ITerminalCapabilitiesModalProps, ITerminalCapabilitiesModalFormValues } from '../../type';
import { constants, useTranslation } from '../../../../../../../../../utils';

const TerminalCapabilitiesModal: FC<ITerminalCapabilitiesModalProps> = ({ show, onClose }): JSX.Element => {
    const { t, locale } = useTranslation();
    const { control, reset } = useForm<ITerminalCapabilitiesModalFormValues>({
        defaultValues: {
            rfu: false,
            manuelKeyEntry: false,
            magneticStripe: false,
            icWithContacts: false,
            plaintextPinForOfflineIccVerification: false,
            enchiperedPinForOfflineIccVerification: false,
            signaturePaper: false,
            enchiperedPinForOfflineVerify: false,
            noCvm: false,
            offlineStaticDataAuth: false,
            offlineDynamicDataAuth: false,
            cardCapture: false,
            combinedDdaGeneration: false,
        },
    });

    const closeModal = () => {
        onClose?.(false);
        reset();
    };

    return (
        <Modal maxWidth="sm" show={Boolean(show)} onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.termCapabilities)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="form" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 1`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="manuelKeyEntry"
                                        label={t(locale.labels.manKeyEntry)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="magneticStripe"
                                        label={t(locale.labels.magStripe)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="icWithContacts"
                                        label={t(locale.labels.icWithContact)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 2`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="plaintextPinForOfflineIccVerification"
                                        label={t(locale.labels.plaintextPinOffIccVer)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="enchiperedPinForOfflineIccVerification"
                                        label={t(locale.labels.enchtextPinOnIccVer)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="signaturePaper"
                                        label={t(locale.labels.signature)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="enchiperedPinForOfflineVerify"
                                        label={t(locale.labels.enchPinOffIccVer)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="noCvm" label={t(locale.labels.noCvm)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 3`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="offlineStaticDataAuth"
                                        label={t(locale.labels.offStaticDataAuth)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineDynamicDataAuth"
                                        label={t(locale.labels.offDynamicDataAuth)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="cardCapture"
                                        label={t(locale.labels.cardCapture)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="combinedDdaGeneration"
                                        label={t(locale.labels.combinedDdaAcGen)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default TerminalCapabilitiesModal;
