import type { FC } from 'react';
import { useState } from 'react';
import { Button, Grid, GridItem, Label, Table, TableBody, TableCell, TableFooter, TableHead, TableRow } from 'seker-ui';
import { useTranslation } from '../../../../../../../../utils';
import TerminalCapabilitiesModal from './TerminalCapabilitiesModal';
import { ArticleOutlined } from '@mui/icons-material';

const Tag9f33: FC = () => {
    const { t, locale } = useTranslation();
    const [termCapabilitiesOpen, setTermCapabilitiesOpen] = useState<boolean>(false);

    return (
        <>
            <Grid spacingType="common">
                <GridItem>
                    <Label text={t(locale.labels.termCapabilities)} />
                </GridItem>
                <GridItem>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell> </TableCell>
                                <TableCell>8.</TableCell>
                                <TableCell>7.</TableCell>
                                <TableCell>6.</TableCell>
                                <TableCell>5.</TableCell>
                                <TableCell>4.</TableCell>
                                <TableCell>3.</TableCell>
                                <TableCell>2.</TableCell>
                                <TableCell>1.</TableCell>
                                <TableCell>Bit</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            <TableRow>
                                <TableCell>Byte 4</TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                            </TableRow>
                            <TableRow>
                                <TableCell>Byte 5</TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                            </TableRow>
                        </TableBody>
                        <TableFooter>
                            <TableRow>
                                <TableCell>Byte 6</TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                                <TableCell> </TableCell>
                            </TableRow>
                        </TableFooter>
                    </Table>
                </GridItem>
                <GridItem xs md="auto" ml={{ sm: 'auto' }}>
                    <Button
                        text={t(locale.buttons.detail)}
                        iconLeft={<ArticleOutlined />}
                        variant="contained"
                        fullWidth
                        onClick={() => setTermCapabilitiesOpen(true)}
                    />
                </GridItem>
            </Grid>
            <TerminalCapabilitiesModal show={termCapabilitiesOpen} onClose={setTermCapabilitiesOpen} />
        </>
    );
};

export default Tag9f33;
