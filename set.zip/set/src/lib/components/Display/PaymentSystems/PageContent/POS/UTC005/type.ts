import type { FieldValues, HelperComponentProps, HelperFormProps, IButtonProps, IInputProps } from 'seker-ui';
import type { Dispatch, SetStateAction } from 'react';
import type {
    IUtcListMessageCoreData,
    IUtcListMessageRequest,
    IValueData,
} from '../../../../../../utils/types/api/models/PaymentSystems/POS/utcListMessage/type';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../../utils';

export interface IUTC005PageContentFormValues {
    messageBitMap1: string;
    messageBitMap2: string;
}

export interface IMessageDetailProps {
    messageDetailData: IValueData[];
}

export interface IMessageListProps<T extends FieldValues> extends HelperFormProps<T, 'reset'> {
    responseCodeTableData: IUtcListMessageCoreData[];
    setMessageDetailData: Dispatch<SetStateAction<IValueData[]>>;
}

type IInputType = Partial<
    Record<
        `${keyof Pick<IUTC005PageContentFormValues, 'messageBitMap1' | 'messageBitMap2'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonType {
    emvDetailButton?: Pick<IButtonProps, 'disabled'>;
}

interface IUTC005PageContentComponentProps {
    buttonProps?: IButtonType;
    inputProps?: IInputType;
}

interface IModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IUTC005PageContentComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IUTC005PageContentFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData: IUtcListMessageRequest;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

interface IPageProps
    extends Pick<IModalProps, 'formData' | 'payloadData' | 'componentProps'>,
        Pick<HelperComponentProps, 'outerHeight'> {
    insideModal?: boolean;
}

interface IModalContentProps extends IModalProps {
    displayType: 'Modal';
}

interface IPageContentProps extends IPageProps {
    displayType: 'Page';
}

export type IUTC005PageContentProps = IModalContentProps | IPageContentProps;
