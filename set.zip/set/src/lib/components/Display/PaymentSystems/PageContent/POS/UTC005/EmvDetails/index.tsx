import type { FC, JSX } from 'react';
import { useState } from 'react';
import { Grid, GridItem, Modal, ModalBody, ModalTitle, Paper, Tab, TabItem, useForm, View } from 'seker-ui';
import Tag82 from './tag82';
import Tag95 from './tag95';
import Tag9f10 from './tag9f10';
import Tag9f33 from './tag9f33';
import Tag9f34 from './tag9f34';
import type { IEmvDetailsProps, IQueryFormValues } from './type';
import { ActiveTabEnum } from './type';
import { constants, useTranslation } from '../../../../../../../utils';

const EmvDetailsModal: FC<IEmvDetailsProps> = ({ onClose, show }): JSX.Element => {
    const { t, locale } = useTranslation();
    const [activeTab, setActiveTab] = useState(ActiveTabEnum.tag82);
    const { control, setValue } = useForm<IQueryFormValues>({
        defaultValues: {
            conditionCode: '',
            cvmCode: '',
            result: '',
        },
    });

    const closeModal = () => {
        onClose?.(false);
    };

    return (
        <Modal maxWidth="sm" show={show} onClose={closeModal}>
            <ModalTitle />
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem sm={constants.design.gridItem.sizeType.form.SET.sm * 2}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 2,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 2,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 2,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 2,
                                        }}
                                        spacingType="form">
                                        <GridItem>
                                            <Tab value={activeTab} onChange={(val) => setActiveTab(val)}>
                                                <TabItem
                                                    text={t(locale.contentTitles.tag82)}
                                                    value={ActiveTabEnum.tag82}
                                                />
                                                <TabItem
                                                    text={t(locale.contentTitles.tag95)}
                                                    value={ActiveTabEnum.tag95}
                                                />
                                                <TabItem
                                                    text={t(locale.contentTitles.tag9f10)}
                                                    value={ActiveTabEnum.tag9f10}
                                                />
                                                <TabItem
                                                    text={t(locale.contentTitles.tag9f33)}
                                                    value={ActiveTabEnum.tag9f33}
                                                />
                                                <TabItem
                                                    text={t(locale.contentTitles.tag9f34)}
                                                    value={ActiveTabEnum.tag9f34}
                                                />
                                            </Tab>
                                            <View show={activeTab === ActiveTabEnum.tag82}>
                                                <Tag82 />
                                            </View>
                                            <View show={activeTab === ActiveTabEnum.tag95}>
                                                <Tag95 />
                                            </View>
                                            <View show={activeTab === ActiveTabEnum.tag9f10}>
                                                <Tag9f10 />
                                            </View>
                                            <View show={activeTab === ActiveTabEnum.tag9f33}>
                                                <Tag9f33 />
                                            </View>
                                            <View show={activeTab === ActiveTabEnum.tag9f34}>
                                                <Tag9f34 formProps={{ control, setValue }} />
                                            </View>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};
export default EmvDetailsModal;
