import type { FC, JSX } from 'react';
import { Grid, GridItem, useForm, Checkbox, Paper, Nav, Modal, ModalTitle, ModalBody } from 'seker-ui';
import type {
    IApplicationInterchangeProfileModalFormValues,
    IApplicationInterchangeProfileModalProps,
} from '../../type';
import { constants, useTranslation } from '../../../../../../../../../utils';

const ApplicationInterchangeProfileModal: FC<IApplicationInterchangeProfileModalProps> = ({
    show,
    onClose,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const { control, reset } = useForm<IApplicationInterchangeProfileModalFormValues>({
        defaultValues: {
            rfu: false,
            offlineStaticDataAuthisSupported: false,
            offlineDynamicDataAuthisSupported: false,
            cardholderVerificationSupported: false,
            terminalRiskManagementPerformed: false,
            issuerAuthSupported: false,
            combinedDdaGenerateAcSupported: false,
        },
    });

    const closeModal = () => {
        onClose?.(false);
        reset();
    };

    return (
        <Modal maxWidth="sm" show={Boolean(show)} onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.appInterchangeProfile)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Nav navTitleProps={{ title: `${t(locale.contentTitles.byte)} 1` }} />
                            <Grid>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineStaticDataAuthisSupported"
                                        label={t(locale.labels.offStaticDataAuthSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineDynamicDataAuthisSupported"
                                        label={t(locale.labels.offDynamicDataAuthSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="cardholderVerificationSupported"
                                        label={t(locale.labels.cardholderVerSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="terminalRiskManagementPerformed"
                                        label={t(locale.labels.termRiskManPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerAuthSupported"
                                        label={t(locale.labels.issAuthSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="combinedDdaGenerateAcSupported"
                                        label={t(locale.labels.combinedDdaGenAcSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 2`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="RFU" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default ApplicationInterchangeProfileModal;
