import type { FC, JSX } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import type { IMessageDetailProps } from '../type';
import { useTranslation } from '../../../../../../../utils';

const MessageDetail: FC<IMessageDetailProps> = ({ messageDetailData }): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.number),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'field',
            headerName: t(locale.contentTitles.field),
            headerAlign: 'center',
            flex: 0.5,
            minWidth: 100,
            align: 'center',
        },
        {
            field: 'fieldDescription',
            headerName: t(locale.contentTitles.fieldDescription),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'fieldLength',
            headerName: t(locale.contentTitles.length),
            headerAlign: 'center',
            flex: 0.5,
            minWidth: 100,
            align: 'center',
        },
        {
            field: 'fieldValue',
            headerName: t(locale.contentTitles.fieldValue),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
        },
    ];

    return <DataGrid columns={columns} rows={messageDetailData} />;
};

export default MessageDetail;
