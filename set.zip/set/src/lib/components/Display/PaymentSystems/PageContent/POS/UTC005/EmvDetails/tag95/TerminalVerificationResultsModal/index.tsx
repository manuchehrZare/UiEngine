import type { FC, JSX } from 'react';
import { Grid, GridItem, useForm, Checkbox, Paper, Nav, Modal, ModalTitle, ModalBody } from 'seker-ui';
import { useTranslation, constants } from '../../../../../../../../../utils';
import type { ITerminalVerificationResultModalProps, ITerminalVerificationResultsModalFormValues } from '../../type';

const TerminalVerificationResultModal: FC<ITerminalVerificationResultModalProps> = ({ show, onClose }): JSX.Element => {
    const { t, locale } = useTranslation();
    const { control, reset } = useForm<ITerminalVerificationResultsModalFormValues>({
        defaultValues: {
            offlineDataAuthenticationWasNotPerformed: false,
            offlineStaticDataAuthenticationFailed: false,
            iccDataMissing: false,
            cardAppearsOnTerminalExceptionFile: false,
            offlineDynamicDataAuthenticationFailed: false,
            combinedDDAACGenerationFailed: false,
            rfu: false,
            iccAndTerminalHaveDiffAppVers: false,
            expiredApp: false,
            appNotYetEffective: false,
            requestedActionsNotAvaibleForCardProduct: false,
            newCard: false,
            cardholderVerificationNotSuccessfull: false,
            unrecognisedCVM: false,
            pinTryLimitExceeded: false,
            pinEntryRequiredButPinpadNotWorking: false,
            pinEntryRequiredPinpadPresentButPinWasntEntered: false,
            onlinePinEntered: false,
            transactionExceedsFloorLimits: false,
            lowerConsecutiveOfflineLimitExceeded: false,
            upperConsecutiveOfflineLimitExceeded: false,
            transactionSelectedRandomlyOnlineProcessing: false,
            merchantsForcedTransactionOnline: false,
            defaultTdolUsed: false,
            issuerAuthWasntUnsuccessful: false,
            issuerScriptProcessFailedBeforeFinalGnr: false,
            issuerScriptProcessFailedAfterFinalGnr: false,
        },
    });

    const closeModal = () => {
        onClose?.(false);
        reset();
    };

    return (
        <Modal maxWidth="md" show={Boolean(show)} onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.terminalVerificationResult)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 2}>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 1`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="offStaticDataAuthSup"
                                        label={t(locale.labels.offStaticDataAuthSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offDynamicDataAuthSup"
                                        label={t(locale.labels.offDynamicDataAuthSup)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineDataAuthenticationWasNotPerformed"
                                        label={t(locale.labels.offDataAuthNotPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineStaticDataAuthenticationFailed"
                                        label={t(locale.labels.offStaticDataAuthFailed)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="iccDataMissing"
                                        label={t(locale.labels.iccDataMiss)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="cardAppearsOnTerminalExceptionFile"
                                        label={t(locale.labels.cardAppTermExceptionFile)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineDynamicDataAuthenticationFailed"
                                        label={t(locale.labels.offDynamicDataAuthFailed)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="combinedDDAACGenerationFailed"
                                        label={t(locale.labels.combinedDdaGenFailed)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 2}>
                        <Paper sx={{ height: { md: '260px' } }}>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 2`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="iccAndTerminalHaveDiffAppVers"
                                        label={t(locale.labels.iccTermDiffAppVers)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="expiredApp"
                                        label={t(locale.labels.expApp)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="appNotYetEffective"
                                        label={t(locale.labels.appNotYetEffective)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="requestedActionsNotAvaibleForCardProduct"
                                        label={t(locale.labels.reqActNotAvailableCardProduct)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="newCard"
                                        label={t(locale.labels.newCard)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 2}>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 3`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="cardholderVerificationNotSuccessfull"
                                        label={t(locale.labels.cardholderVerNotSuc)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="unrecognisedCVM"
                                        label={t(locale.labels.unrecognisedCvm)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="pinTryLimitExceeded"
                                        label={t(locale.labels.pinTryLimitExceeded)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="pinEntryRequiredButPinpadNotWorking"
                                        label={t(locale.labels.pinEntryReqPinpadNotPreNotWork)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="pinEntryRequiredPinpadPresentButPinWasntEntered"
                                        label={t(locale.labels.pinEntryReqPinpadPinWasNotEntered)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="onlinePinEntered"
                                        label={t(locale.labels.onlinePinEntered)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 2}>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 4`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="transactionExceedsFloorLimits"
                                        label={t(locale.labels.tranExcFloorLimit)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="lowerConsecutiveOfflineLimitExceeded"
                                        label={t(locale.labels.lowConsOffLimExc)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="upperConsecutiveOfflineLimitExceeded"
                                        label={t(locale.labels.upConsOffLimExc)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="transactionSelectedRandomlyOnlineProcessing"
                                        label={t(locale.labels.tranSelRandomOnlineProc)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="merchantsForcedTransactionOnline"
                                        label={t(locale.labels.mercForcedTranOnline)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 2}>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 5`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="defaultTdolUsed"
                                        label={t(locale.labels.defaultTdolUsed)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerAuthWasntUnsuccessful"
                                        label={t(locale.labels.issAuthUnsuccessful)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerScriptProcessFailedBeforeFinalGnr"
                                        label={t(locale.labels.issScriptProcBefGnr)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerScriptProcessFailedAfterFinalGnr"
                                        label={t(locale.labels.issScriptProcAfterGnr)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default TerminalVerificationResultModal;
