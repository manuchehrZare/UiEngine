/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, useDataGridApiRef } from 'seker-ui';
import type { IMessageListProps, IUTC005PageContentFormValues } from '../type';
import { useTranslation } from '../../../../../../../utils';
import type { IUtcListMessageCoreData } from '../../../../../../../utils/types/api/models/PaymentSystems/POS/utcListMessage/type';

const MessageList: FC<IMessageListProps<IUTC005PageContentFormValues>> = ({
    responseCodeTableData,
    formProps: { reset },
    setMessageDetailData,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const apiRef = useDataGridApiRef();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.number),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'messageType',
            headerName: t(locale.contentTitles.messageType),
            headerAlign: 'center',
            flex: 1,
            minWidth: 100,
            align: 'center',
        },
        {
            field: 'row',
            headerName: t(locale.contentTitles.row),
            headerAlign: 'center',
            flex: 0.5,
            minWidth: 50,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'messageDate',
            headerName: t(locale.contentTitles.messageDate),
            headerAlign: 'center',
            flex: 1,
            minWidth: 100,
            align: 'center',
        },
    ];

    useEffect(() => {
        if (responseCodeTableData?.length) {
            apiRef?.current?.selectRow(0, true, true);
            reset({
                messageBitMap1: String(responseCodeTableData[0].messageBitMap1),
                messageBitMap2: String(responseCodeTableData[0].messageBitMap2),
            });
            setMessageDetailData(responseCodeTableData[0]?.coreDataReactValues?.coreData || []);
        }
    }, [responseCodeTableData]);

    return (
        <DataGrid
            apiRef={apiRef}
            columns={columns}
            rows={responseCodeTableData}
            selectionOnClickable
            onRowClick={({ row }: { row: IUtcListMessageCoreData }) => {
                reset({
                    messageBitMap1: String(row?.messageBitMap1),
                    messageBitMap2: String(row?.messageBitMap2),
                });
                row?.coreDataReactValues?.coreData && setMessageDetailData(row?.coreDataReactValues?.coreData);
            }}
        />
    );
};
export default MessageList;
