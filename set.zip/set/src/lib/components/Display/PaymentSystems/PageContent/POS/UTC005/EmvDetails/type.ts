import type { FieldValues, HelperFormProps } from 'seker-ui';

export interface IEmvDetailsProps {
    onClose: (data: boolean) => void;
    show: boolean;
}

export interface IQueryFormValues {
    conditionCode: string;
    cvmCode: string;
    result: string;
}

export enum ActiveTabEnum {
    tag82 = 1,
    tag95 = 2,
    tag9f10 = 3,
    tag9f34 = 4,
    tag9f33 = 5,
}

export interface ITag9f34Props<T extends FieldValues> extends HelperFormProps<T, 'control' | 'setValue'> {}

export interface ICardVerificationResultsModalFormValues {
    acc: boolean;
    arqc: boolean;
    dynamicDataAuthPerformed: boolean;
    issuerAuthFailed: boolean;
    issuerAuthFailedLastOnlineTransaction: boolean;
    issuerAuthNotPerformed: boolean;
    lastOnlineTransactionNotComplete: boolean;
    newCard: boolean;
    notRequested: boolean;
    numberIssuerScriptCommands: boolean;
    offlineDynamicDataAuthTermUnableOnline: boolean;
    offlinePinVerificationFailed: boolean;
    offlinePinVerificationSupportedAndNotPerformed: boolean;
    offlineStaticDataAuthTermUnableOnline: boolean;
    pinTryLimitExceeded: boolean;
    pinTryLimitExceededPrevTrans: boolean;
    rfu: boolean;
    scriptFailureLastTrans: boolean;
    tc: boolean;
    unableToGoOnline: boolean;
    velocityCheckingCountersExceeded: boolean;
}

export interface ICardVerificationResultsModalProps {
    onClose: (data: boolean) => void;
    show: boolean;
}

export interface ITerminalCapabilitiesModalFormValues {
    cardCapture: boolean;
    combinedDdaGeneration: boolean;
    enchiperedPinForOfflineIccVerification: boolean;
    enchiperedPinForOfflineVerify: boolean;
    icWithContacts: boolean;
    magneticStripe: boolean;
    manuelKeyEntry: boolean;
    noCvm: boolean;
    offlineDynamicDataAuth: boolean;
    offlineStaticDataAuth: boolean;
    plaintextPinForOfflineIccVerification: boolean;
    rfu: boolean;
    signaturePaper: boolean;
}

export interface ITerminalCapabilitiesModalProps {
    onClose: (data: boolean) => void;
    show: boolean;
}

export interface IApplicationInterchangeProfileModalFormValues {
    cardholderVerificationSupported: boolean;
    combinedDdaGenerateAcSupported: boolean;
    issuerAuthSupported: boolean;
    offlineDynamicDataAuthisSupported: boolean;
    offlineStaticDataAuthisSupported: boolean;
    rfu: boolean;
    terminalRiskManagementPerformed: boolean;
}

export interface IApplicationInterchangeProfileModalProps {
    onClose: (data: boolean) => void;
    show: boolean;
}

export interface ITerminalVerificationResultsModalFormValues {
    appNotYetEffective: boolean;
    cardAppearsOnTerminalExceptionFile: boolean;
    cardholderVerificationNotSuccessfull: boolean;
    combinedDDAACGenerationFailed: boolean;
    defaultTdolUsed: boolean;
    expiredApp: boolean;
    iccAndTerminalHaveDiffAppVers: boolean;
    iccDataMissing: boolean;
    issuerAuthWasntUnsuccessful: boolean;
    issuerScriptProcessFailedAfterFinalGnr: boolean;
    issuerScriptProcessFailedBeforeFinalGnr: boolean;
    lowerConsecutiveOfflineLimitExceeded: boolean;
    merchantsForcedTransactionOnline: boolean;
    newCard: boolean;
    offlineDataAuthenticationWasNotPerformed: boolean;
    offlineDynamicDataAuthenticationFailed: boolean;
    offlineStaticDataAuthenticationFailed: boolean;
    onlinePinEntered: boolean;
    pinEntryRequiredButPinpadNotWorking: boolean;
    pinEntryRequiredPinpadPresentButPinWasntEntered: boolean;
    pinTryLimitExceeded: boolean;
    requestedActionsNotAvaibleForCardProduct: boolean;
    rfu: boolean;
    transactionExceedsFloorLimits: boolean;
    transactionSelectedRandomlyOnlineProcessing: boolean;
    unrecognisedCVM: boolean;
    upperConsecutiveOfflineLimitExceeded: boolean;
}

export interface ITerminalVerificationResultModalProps {
    onClose: (data: boolean) => void;
    show: boolean;
}
