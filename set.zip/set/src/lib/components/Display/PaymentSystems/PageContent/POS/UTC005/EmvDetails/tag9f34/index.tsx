import type { FC } from 'react';
import { Grid, GridItem, Label, Select } from 'seker-ui';
import { useTranslation } from '../../../../../../../../utils';
import type { IQueryFormValues, ITag9f34Props } from '../type';

const Tag9f34: FC<ITag9f34Props<IQueryFormValues>> = ({ formProps: { control, setValue } }) => {
    const { t, locale } = useTranslation();

    return (
        <Grid spacingType="common">
            <GridItem>
                <Label text={t(locale.labels.cardholderVerificationResult)} />
            </GridItem>
            <GridItem>
                <Select
                    name="cvmCode"
                    label={t(locale.labels.cvmCode)}
                    control={control}
                    options={{ data: [], displayField: 'name', displayValue: 'value' }}
                    setValue={setValue}
                    disabled
                />
            </GridItem>
            <GridItem>
                <Select
                    name="conditionCode"
                    label={t(locale.labels.conditionCode)}
                    control={control}
                    options={{ data: [], displayField: 'name', displayValue: 'value' }}
                    setValue={setValue}
                    disabled
                />
            </GridItem>
            <GridItem>
                <Select
                    name="result"
                    label={t(locale.labels.result)}
                    control={control}
                    options={{ data: [], displayField: 'name', displayValue: 'value' }}
                    setValue={setValue}
                    disabled
                />
            </GridItem>
        </Grid>
    );
};

export default Tag9f34;
