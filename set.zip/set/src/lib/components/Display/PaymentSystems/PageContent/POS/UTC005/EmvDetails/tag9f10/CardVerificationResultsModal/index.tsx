import type { FC, JSX } from 'react';
import {
    Grid,
    GridItem,
    useForm,
    Checkbox,
    Paper,
    Nav,
    NumberInput,
    Label,
    Modal,
    ModalBody,
    ModalTitle,
} from 'seker-ui';
import type { ICardVerificationResultsModalProps, ICardVerificationResultsModalFormValues } from '../../type';
import { constants, useTranslation } from '../../../../../../../../../utils';

const CardVerificationResultsModal: FC<ICardVerificationResultsModalProps> = ({ show, onClose }): JSX.Element => {
    const { t, locale } = useTranslation();
    const { control, reset } = useForm<ICardVerificationResultsModalFormValues>({
        defaultValues: {
            acc: false,
            tc: false,
            notRequested: false,
            arqc: false,
            issuerAuthFailed: false,
            offlinePinVerificationSupportedAndNotPerformed: false,
            offlinePinVerificationFailed: false,
            unableToGoOnline: false,
            lastOnlineTransactionNotComplete: false,
            pinTryLimitExceeded: false,
            velocityCheckingCountersExceeded: false,
            newCard: false,
            issuerAuthFailedLastOnlineTransaction: false,
            issuerAuthNotPerformed: false,
            pinTryLimitExceededPrevTrans: false,
            offlineStaticDataAuthTermUnableOnline: false,
            numberIssuerScriptCommands: false,
            scriptFailureLastTrans: false,
            offlineDynamicDataAuthTermUnableOnline: false,
            dynamicDataAuthPerformed: false,
            rfu: false,
        },
    });

    const closeModal = () => {
        onClose?.(false);
        reset();
    };

    return (
        <Modal maxWidth="sm" show={Boolean(show)} onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.cardVerificationResult)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 5`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox name="acc" label={t(locale.labels.acc)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="acc" label={t(locale.labels.acc)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="tc" label={t(locale.labels.tc)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="tc" label={t(locale.labels.tc)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="notRequested"
                                        label={t(locale.labels.notRequested)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="arqc" label={t(locale.labels.arqc)} control={control} readOnly />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerAuthFailed"
                                        label={t(locale.labels.issAuthFailed)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlinePinVerificationSupportedAndNotPerformed"
                                        label={t(locale.labels.offPinVerSupNotPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlinePinVerificationFailed"
                                        label={t(locale.labels.offPinVerFailed)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="unableToGoOnline"
                                        label={t(locale.labels.unableToGoOnline)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 6`,
                                }}
                            />
                            <Grid>
                                <GridItem>
                                    <Checkbox
                                        name="lastOnlineTransactionNotComplete"
                                        label={t(locale.labels.onlineTranNotComplete)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="pinTryLimitExceeded"
                                        label={t(locale.labels.pinTryLimExc)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="velocityCheckingCountersExceeded"
                                        label={t(locale.labels.velocityCheckCountersExceeded)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="newCard"
                                        label={t(locale.labels.newCard)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerAuthFailedLastOnlineTransaction"
                                        label={t(locale.labels.issAuthFailedLastOnlineTran)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="issuerAuthNotPerformed"
                                        label={t(locale.labels.issAuthNotPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="pinTryLimitExceededPrevTrans"
                                        label={t(locale.labels.pinTryLimExcPrevTran)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineStaticDataAuthTermUnableOnline"
                                        label={t(locale.labels.offStaticDataAuthNotPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Nav
                                navTitleProps={{
                                    title: `${t(locale.contentTitles.byte)} 7`,
                                }}
                            />
                            <Grid>
                                <GridItem pt={0.3}>
                                    <Grid spacing={0.5}>
                                        <GridItem xs={0.75}>
                                            <NumberInput
                                                control={control}
                                                name="numberIssuerScriptCommands"
                                                labelPlacement="start"
                                                labelWidth={0}
                                                readOnly
                                            />
                                        </GridItem>
                                        <GridItem xs sm="auto">
                                            <Label
                                                text={t(locale.labels.numIssScriptCom)}
                                                color={(theme) => theme.palette.common.black}
                                                fontWeight={400}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="scriptFailureLastTrans"
                                        label={t(locale.labels.scriptFailLastTran)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="offlineDynamicDataAuthTermUnableOnline"
                                        label={t(locale.labels.offDynamicDataAuthNotPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox
                                        name="dynamicDataAuthPerformed"
                                        label={t(locale.labels.dynamicDataAuthPerf)}
                                        control={control}
                                        readOnly
                                    />
                                </GridItem>
                                <GridItem>
                                    <Checkbox name="rfu" label={t(locale.labels.rfu)} control={control} readOnly />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default CardVerificationResultsModal;
