/* eslint-disable react-hooks/exhaustive-deps */
import { ArticleOutlined } from '@mui/icons-material';
import { sum } from 'lodash';
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import {
    Button,
    Grid,
    GridItem,
    Input,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    useMeasure,
} from 'seker-ui';
import { useAxios } from '../../../../../../hooks/useAxios';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../utils';
import type {
    IUtcListMessageCoreData,
    IUtcListMessageRequest,
    IUtcListMessageResponse,
    IValueData,
} from '../../../../../../utils/types/api/models/PaymentSystems/POS/utcListMessage/type';
import type { IUTC005PageContentFormValues, IUTC005PageContentProps } from '../UTC005/type';
import EmvDetailsModal from './EmvDetails';
import MessageDetail from './MessageDetail';
import MessageList from './MessageList';

const UTC005: FC<IUTC005PageContentProps> = (props: IUTC005PageContentProps): JSX.Element => {
    const { t, locale } = useTranslation();
    const navTitle1Measure = useMeasure();
    const navTitle2Measure = useMeasure();
    const modalTitleMeasure = useMeasure();
    const detailFormMeasure = useMeasure();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [emvDetailsOpen, setEmvDetailsOpen] = useState<boolean>(false);
    const [responseCodeData, setResponseCodeData] = useState<IUtcListMessageCoreData[]>([]);
    const [messageDetailData, setMessageDetailData] = useState<IValueData[]>([]);

    const { control, reset } = useForm<IUTC005PageContentFormValues>({
        defaultValues: {
            messageBitMap2: '',
            messageBitMap1: '',
        },
    });

    const [
        { data: utcListMessageData, error: utcListMessageError, loading: utcListMessageLoading },
        utcListMessageCall,
    ] = useAxios<IUtcListMessageResponse, IUtcListMessageRequest>(
        getGenericSetCaller(GenericSetCallerEnum.UTC_LIST_MESSAGE),
        { manual: true },
    );

    const closeModal = () => {
        if (props.displayType === 'Modal' && props.onClose) {
            props.onClose(false);
            setModalShow(false);
            reset();
            setResponseCodeData([]);
            setMessageDetailData([]);
        }
    };

    const onResponseCodeList = async () => {
        const response = await utcListMessageCall({
            data: {
                ...props?.payloadData,
            },
        });
        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data;
            if (responseData?.coreData?.length) {
                setResponseCodeData(responseData?.coreData);
                reset({
                    messageBitMap1: String(responseData?.coreData[0].messageBitMap1),
                    messageBitMap2: String(responseData?.coreData[0].messageBitMap2),
                });
            } else {
                props.displayType === 'Modal' && props.show && closeModal();
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noUTCMessageDetail) });
            }
        }
    };

    useEffect(() => {
        ((props.displayType === 'Modal' && props?.show) || props.displayType === 'Page') && onResponseCodeList();
    }, [props.displayType, props.displayType === 'Modal' && props?.show]);

    useEffect(() => {
        modalShow && props.formData && reset(props.formData);
    }, [props.formData, modalShow]);

    useEffect(() => {
        if (
            props.displayType === 'Modal' &&
            props?.show &&
            !utcListMessageError &&
            utcListMessageData?.coreData?.length &&
            !utcListMessageLoading
        ) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [utcListMessageLoading]);

    useEffect(() => {
        if (utcListMessageError) {
            props.displayType === 'Modal' && props.show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.utcMessageDetail),
                }),
            });
        }
    }, [utcListMessageError]);

    const renderContent = () => {
        return (
            <Grid spacingType="form">
                <GridItem md={4}>
                    <Label text={t(locale.contentTitles.messageList)} ref={navTitle1Measure.ref} />
                    <Grid pt={0.5}>
                        <GridItem
                            height={{
                                xs: 250,
                                md:
                                    window.innerHeight -
                                    sum([
                                        navTitle1Measure?.values?.height,
                                        constants.design.padding.paper.y.pixel * 2,
                                        constants.design.border.paper.common.SET.width * 2,
                                        ...(props.displayType === 'Modal'
                                            ? [
                                                  modalTitleMeasure.values.height,
                                                  constants.design.padding.common.pixel * 2,
                                                  64,
                                              ]
                                            : [props.outerHeight]),
                                        4,
                                    ]),
                            }}>
                            <MessageList
                                responseCodeTableData={responseCodeData}
                                formProps={{ reset }}
                                setMessageDetailData={setMessageDetailData}
                            />
                        </GridItem>
                    </Grid>
                </GridItem>
                <GridItem md={8}>
                    <Label ref={navTitle2Measure.ref} text={t(locale.contentTitles.messageDetail)} />
                    <Grid>
                        <GridItem>
                            <Grid spacingType="form">
                                <GridItem
                                    ref={detailFormMeasure.ref}
                                    xs
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 3}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Grid
                                        spacingType="form"
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                                        }}>
                                        <GridItem>
                                            <Input
                                                name="messageBitMap1"
                                                label={`${t(locale.labels.bitMap)}1`}
                                                control={control}
                                                disabled
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Input
                                                name="messageBitMap2"
                                                label={`${t(locale.labels.bitMap)}2`}
                                                control={control}
                                                disabled
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.emvDetail)}
                                                iconLeft={<ArticleOutlined />}
                                                variant="contained"
                                                fullWidth
                                                onClick={() => setEmvDetailsOpen(true)}
                                                disabled
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem
                                    height={{
                                        xs: 400,
                                        md:
                                            window.innerHeight -
                                            sum([
                                                navTitle2Measure?.values?.height,
                                                detailFormMeasure?.values?.height,
                                                constants.design.padding.paper.y.pixel * 2,
                                                constants.design.border.paper.common.SET.width * 2,
                                                -constants.design.grid.spacing.form.row.SET.pixel,
                                                ...(props.displayType === 'Modal'
                                                    ? [
                                                          modalTitleMeasure.values.height,
                                                          constants.design.padding.common.pixel * 2,
                                                          64,
                                                      ]
                                                    : [props.outerHeight]),
                                            ]),
                                    }}>
                                    <MessageDetail messageDetailData={messageDetailData} />
                                </GridItem>
                            </Grid>
                        </GridItem>
                    </Grid>
                </GridItem>
                <EmvDetailsModal show={emvDetailsOpen} onClose={setEmvDetailsOpen} />
            </Grid>
        );
    };

    if (props.displayType === 'Modal') {
        return (
            <Modal
                fullWidth
                show={modalShow}
                onClose={() => {
                    props.show && modalShow && closeModal();
                }}
                fullHeight>
                <ModalTitle ref={modalTitleMeasure.ref}>{t(locale.contentTitles.utcMessageDetail)}</ModalTitle>
                <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                    <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                        <GridItem>
                            <Paper>{renderContent()}</Paper>
                        </GridItem>
                    </Grid>
                </ModalBody>
            </Modal>
        );
    }
    return renderContent();
};

export default UTC005;
