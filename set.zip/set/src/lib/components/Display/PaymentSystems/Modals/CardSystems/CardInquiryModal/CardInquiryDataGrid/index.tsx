import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { CardNumber, DataGrid, DataGridColumnTypeEnum, NumberFormat } from 'seker-ui';
import type { IPpCardSearchItem } from '../../../../../../..';
import { ReferenceDataEnum, stringToStringDate, useTranslation } from '../../../../../../..';
import type { ICardInquiryDataGridProps } from '../type';
import { isEqual } from 'lodash';

const PpCcmsCardSearchDataGrid: FC<ICardInquiryDataGridProps> = ({
    data,
    onReturnData,
    closeModal,
    referenceDatas,
    prodProductGroupListForComboData,
    prodProductListForComboData,
}) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'accountNo',
            headerName: t(locale.contentTitles.cardNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            renderCell: (params): any => {
                return <CardNumber component="NumberFormat" value={String(params.value)} />;
            },
        },
        {
            field: 'custNo',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'embossName',
            headerName: t(locale.contentTitles.embossName),
            headerAlign: 'center',
            minWidth: 150,
        },
        {
            field: 'productGroupCode',
            headerName: t(locale.contentTitles.productGroup),
            headerAlign: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return (
                    prodProductGroupListForComboData?.productGroupList.find((item) =>
                        isEqual(item[0], String(value)),
                    )?.[1] || ''
                );
            },
        },
        {
            field: 'productCode',
            headerName: t(locale.contentTitles.product),
            headerAlign: 'center',
            minWidth: 175,
            valueFormatter: (value) => {
                return (
                    prodProductListForComboData?.productList.find((item) => isEqual(item[0], String(value)))?.[1] || ''
                );
            },
        },
        {
            field: 'primaryType',
            headerName: t(locale.contentTitles.primaryType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 175,
        },
        {
            field: 'currExpireYearMonth',
            headerName: t(locale.contentTitles.currExpireYearMonth),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return value ? stringToStringDate(`${value}`) : '';
            },
        },
        {
            field: 'creditLimit',
            headerName: t(locale.contentTitles.creditLimit),
            headerAlign: 'center',
            align: 'right',
            minWidth: 150,
            renderCell: (params): any => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'cashLimit',
            headerName: t(locale.contentTitles.cashLimit),
            headerAlign: 'center',
            align: 'right',
            minWidth: 150,
            renderCell: (params): any => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'blockReclassCode',
            headerName: t(locale.contentTitles.blockReclassCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 100,
        },
        {
            field: 'birthDate',
            headerName: t(locale.contentTitles.birthday),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return value ? stringToStringDate(`${value}`) : '';
            },
        },
        {
            field: 'birthPlace',
            headerName: t(locale.contentTitles.birthPlace),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_UTL_LOCATION_CITY)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'branchCode',
            headerName: t(locale.contentTitles.branchCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'accountStatus',
            headerName: t(locale.contentTitles.accountStatus),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'doubtCard',
            headerName: t(locale.contentTitles.doubtCard),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'nameSurname',
            headerName: t(locale.contentTitles.nameSurname),
            headerAlign: 'center',
            minWidth: 150,
        },
    ];

    return (
        <DataGrid
            onRowDoubleClick={({ row }: { row: IPpCardSearchItem }) => {
                onReturnData?.(row);
                closeModal();
            }}
            columns={columns}
            rows={data || []}
            selectionOnClickable
        />
    );
};

export default PpCcmsCardSearchDataGrid;
