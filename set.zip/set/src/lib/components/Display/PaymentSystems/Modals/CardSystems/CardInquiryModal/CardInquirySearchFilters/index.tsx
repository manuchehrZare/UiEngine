import type { FC, JSX } from 'react';
import { Grid, GridItem, Input, Select, NumberInput, Checkbox, NumberInputReturnValueEnum, CardNumber } from 'seker-ui';
import {
    ClosenessStatusDataEnum,
    ModalViewer,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    useTranslation,
} from '../../../../../../..';
import type { ICardInquirySearchFiltersProps, ICardInquiryModalFormValues } from '../type';
import { isNull } from 'lodash';

const PpCcmsCardSearchFilters: FC<ICardInquirySearchFiltersProps<ICardInquiryModalFormValues>> = ({
    formProps: { control, setValue },
    referenceDatas,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 3,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Select
                    name="corpNo"
                    control={control}
                    setValue={setValue}
                    displayEmpty
                    options={{
                        data:
                            referenceDatas?.resultList?.find(
                                (item) => item.name === ReferenceDataEnum.PRM_CCC_CORPORATION,
                            )?.items || [],
                        displayField: 'value',
                        displayValue: 'key',
                    }}
                    label={t(locale.labels.corpNo)}
                    {...componentProps?.selectProps?.corpNo}
                />
            </GridItem>
            <GridItem sizeType="form">
                <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                    component="NumberInput"
                    modalComponent={SETModalsEnum.CustomerInquiryModal}
                    control={control}
                    name="custNo"
                    label={t(locale.labels.customerNo)}
                    adornmentButtonProps={{
                        tooltip: t(locale.contentTitles.customerInquiry),
                        disabled: false,
                    }}
                    decimalScale={0}
                    modalProps={{
                        onReturnData: (data: any) => {
                            setValue('custNo', String(data?.customerCode));
                            setValue('branchCode', !isNull(data?.mainBranchCode) ? String(data?.mainBranchCode) : '');
                            setValue('custCustName', data?.name || '');
                            setValue('custCustSurname', data?.surname || '');
                            setValue('custIndvFatherName', data?.fatherName || '');
                            setValue('custIndvTcId', data?.tcId || null);
                        },
                        formData: {
                            custCustActive: ClosenessStatusDataEnum.NotClose,
                        },
                    }}
                    {...componentProps?.inputProps?.custNo}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    control={control}
                    name="custCustName"
                    label={t(locale.labels.customerName)}
                    {...componentProps?.inputProps?.custCustName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    control={control}
                    name="custCustSecondName"
                    label={t(locale.labels.secondName)}
                    {...componentProps?.inputProps?.custCustSecondName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    control={control}
                    name="custCustSurname"
                    label={t(locale.labels.surname)}
                    {...componentProps?.inputProps?.custCustSurname}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    control={control}
                    name="custIndvFatherName"
                    label={t(locale.labels.fatherName)}
                    {...componentProps?.inputProps?.custIndvFatherName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <CardNumber
                    component="NumberInput"
                    name="accountNo"
                    label={t(locale.labels.cardNo)}
                    control={control}
                    returnValue={NumberInputReturnValueEnum.value}
                    {...componentProps?.numberInputProps?.accountNo}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    control={control}
                    name="branchCode"
                    label={t(locale.labels.branchCode)}
                    allowLeadingZeros
                    returnValue="formattedValue"
                    {...componentProps?.numberInputProps?.branchCode}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    control={control}
                    name="custCustBirthYear"
                    label={t(locale.labels.birthYear)}
                    {...componentProps?.numberInputProps?.custCustBirthYear}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput control={control} name="custIndvTcId" label={t(locale.labels.tcIdNo)} decimalScale={0} />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="custCustBirthPlace"
                    control={control}
                    setValue={setValue}
                    displayEmpty
                    options={{
                        data:
                            referenceDatas?.resultList?.find(
                                (item) => item.name === ReferenceDataEnum.PRM_UTL_LOCATION_CITY,
                            )?.items || [],
                        displayField: 'value',
                        displayValue: 'key',
                    }}
                    label={t(locale.labels.birthPlace)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Checkbox
                    label={t(locale.labels.virtualCard)}
                    name="isVirtualCard"
                    control={control}
                    sx={{ pt: { sm: 2.4 } }}
                />
            </GridItem>
        </Grid>
    );
};

export default PpCcmsCardSearchFilters;
