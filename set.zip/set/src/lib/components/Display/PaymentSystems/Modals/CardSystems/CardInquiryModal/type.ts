import type {
    FieldValues,
    HelperFormProps,
    IButtonProps,
    ICheckboxProps,
    IInputProps,
    INumberInputProps,
    ISelectProps,
} from 'seker-ui';
import type {
    IHelperModalProps,
    IPpCardSearchItem,
    IPpCcmsCardSearchResponse,
    IProdProductGroupListForComboResponse,
    IProdProductListForComboResponse,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../..';

export interface ICardInquiryModalFormValues {
    accountNo: string;
    branchCode: string;
    corpNo: string;
    custCustBirthPlace: string;
    custCustBirthYear: number | null;
    custCustCustomerType: string;
    custCustName: string;
    custCustSecondName: string;
    custCustSurname: string;
    custIndvFatherName: string;
    custIndvTcId: number | null;
    custNo: string;
    isVirtualCard: boolean;
}

type IInputType = Partial<
    Record<
        `${keyof Pick<ICardInquiryModalFormValues, 'custNo' | 'custCustName' | 'custCustSecondName' | 'custCustSurname' | 'custIndvFatherName'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<ICardInquiryModalFormValues, 'corpNo' | 'custCustBirthPlace'>}`]?: Pick<
        ISelectProps<ICardInquiryModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

type INumberInputType = Partial<
    Record<
        `${keyof Pick<ICardInquiryModalFormValues, 'accountNo' | 'branchCode' | 'custCustBirthYear' | 'custIndvTcId'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

type ICheckboxType = Partial<
    Record<`${keyof Pick<ICardInquiryModalFormValues, 'isVirtualCard'>}`, Pick<ICheckboxProps, 'disabled' | 'readOnly'>>
>;

export interface ICardInquiryModalComponentProps {
    buttonProps?: IButtonComponentProps;
    checkboxProps?: ICheckboxType;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface ICardInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: ICardInquiryModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<ICardInquiryModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IPpCardSearchItem) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IPpCcmsCardSearchResponse>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface ICardInquiryDataGridProps extends Pick<ICardInquiryModalProps, 'onReturnData'> {
    closeModal: () => void;
    data: IPpCardSearchItem[];
    prodProductGroupListForComboData?: IProdProductGroupListForComboResponse;
    prodProductListForComboData?: IProdProductListForComboResponse;
    referenceDatas?: ReferenceDataResponse;
}

export interface ICardInquirySearchFiltersProps<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'setValue'> {
    componentProps?: ICardInquiryModalComponentProps;
    referenceDatas?: ReferenceDataResponse;
}

export enum ListTypeEnum {
    GroupList = '1',
    ProductList = '2',
}

export enum ProductGroupEnum {
    ProductMainGroup = '01',
}
export enum FormValuesControlEnum {
    CorporationCode = '01',
    CustomerType = '1',
    IsVirtualCard = 'S',
}
