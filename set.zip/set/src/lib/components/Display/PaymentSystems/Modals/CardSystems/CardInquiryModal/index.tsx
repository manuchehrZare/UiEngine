/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import CardInquirySearchFilters from './CardInquirySearchFilters';
import CardInquiryDataGrid from './CardInquiryDataGrid';
import type { ICardInquiryModalProps, ICardInquiryModalFormValues } from './type';
import { FormValuesControlEnum, ListTypeEnum, ProductGroupEnum } from './type';
import type {
    IPpCardSearchItem,
    IPpCcmsCardSearchRequest,
    IPpCcmsCardSearchResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
    IProdProductGroupListForComboRequest,
    IProdProductGroupListForComboResponse,
    IProdProductListForComboRequest,
    IProdProductListForComboResponse,
} from '../../../../../..';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useAxios,
    useTranslation,
} from '../../../../../..';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';

const PpCcmsCardSearch: FC<ICardInquiryModalProps> = ({
    onClose,
    show,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    formData,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [pCardSearchItems, setPpCardSearchItems] = useState<IPpCardSearchItem[]>([]);

    const { control, setValue, handleSubmit, reset, getValues } = useForm<ICardInquiryModalFormValues>({
        defaultValues: {
            corpNo: FormValuesControlEnum.CorporationCode,
            accountNo: '',
            custNo: '',
            custCustName: '',
            custCustSecondName: '',
            custCustSurname: '',
            custIndvFatherName: '',
            custCustBirthYear: null,
            custIndvTcId: null,
            branchCode: '',
            custCustCustomerType: FormValuesControlEnum.CustomerType,
            custCustBirthPlace: '',
            isVirtualCard: false,
        },
        validationSchema: {
            accountNo: validation.string(t(locale.labels.cardNo)).test({
                test: (val) => {
                    return val?.length === 16 || !val ? true : false;
                },
                message: t(locale.notifications.missingOrIncorrectCardNo),
            }),
        },
    });

    const isVirtualCardVal = useWatch({ control, fieldName: 'isVirtualCard' });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ error: ccmsCardSearchError }, ccmsCardSearchRequest] = useAxios<
        IPpCcmsCardSearchResponse,
        IPpCcmsCardSearchRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCMS_ACCOUNT_PROFILE_LIST_ACCOUNT_INFO), {
        manual: true,
    });

    const [{ data: prodProductGroupListForComboData, error: prodProductGroupListForComboError }] = useAxios<
        IProdProductGroupListForComboResponse,
        IProdProductGroupListForComboRequest
    >({
        ...getGenericSetCaller(GenericSetCallerEnum.PRODUCT_PRODUCT_GROUP_LIST_FOR_COMBO),
        data: {
            listType: ListTypeEnum.GroupList,
            productMainGroupCode: ProductGroupEnum.ProductMainGroup,
        },
    });

    const [{ data: prodProductListForComboData, error: prodProductListForComboError }] = useAxios<
        IProdProductListForComboResponse,
        IProdProductListForComboRequest
    >({
        ...getGenericSetCaller(GenericSetCallerEnum.PROD_PRODUCT_LIST_FOR_COMBO),
        data: {
            listType: ListTypeEnum.ProductList,
            productMainGroupCode: ProductGroupEnum.ProductMainGroup,
        },
    });

    const [{ data: referenceDatas, loading: referenceDatasLoading, error: referenceDatasError }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>({
            ...constants.api.endpoints.nova.gateway.referenceData.POST,
            data: {
                requestList: generateReferenceDataRequestList({
                    nameList: [ReferenceDataEnum.PRM_CCC_CORPORATION, ReferenceDataEnum.PRM_UTL_LOCATION_CITY],
                }),
            },
        });

    const resetModal = () => {
        reset();
        setPpCardSearchItems([]);
    };

    const closeModal = () => {
        onClose?.(false);
        setModalShow(false);
        resetModal();
    };

    const handleOnReturnData = (data: IPpCardSearchItem) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): ICardInquiryModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { accountNo: modalViewerInputWatch && modalViewerInputWatch }),
        ...formData,
    });

    const onSubmit = async (formValues: ICardInquiryModalFormValues) => {
        const response = await ccmsCardSearchRequest({
            data: {
                ...formValues,
                accountNo: formValues?.accountNo ? Number(formValues?.accountNo) : undefined,
                custCustBirthYear: formValues?.custCustBirthYear ? Number(formValues?.custCustBirthYear) : undefined,
                custIndvTcId: formValues?.custIndvTcId ? Number(formValues?.custIndvTcId) : undefined,
                custNo: formValues?.custNo ? Number(formValues?.custNo) : undefined,
            },
        });
        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData?.length) {
                if (isVirtualCardVal) {
                    const primaryTypeData = responseData?.filter(
                        (val) => val?.primaryType === FormValuesControlEnum.IsVirtualCard,
                    );
                    setPpCardSearchItems(primaryTypeData);
                } else {
                    setPpCardSearchItems(responseData);
                }
            } else {
                setPpCardSearchItems([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await ccmsCardSearchRequest({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    accountNo: formData?.accountNo
                        ? Number(formData?.accountNo)
                        : Number(modalViewerInputWatch) || undefined,
                    custCustBirthYear: formData?.custCustBirthYear ? Number(formData?.custCustBirthYear) : undefined,
                    custIndvTcId: formData?.custIndvTcId ? Number(formData?.custIndvTcId) : undefined,
                    custNo: formData?.custNo ? Number(formData?.custNo) : undefined,
                },
            });

            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData.coreData[0]);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (ccmsCardSearchError || prodProductGroupListForComboError || prodProductListForComboError) {
            show && !modalShow && closeModal();
        }
    }, [ccmsCardSearchError, prodProductGroupListForComboError, prodProductListForComboError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.cardQuery),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.cardQuery)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <CardInquirySearchFilters
                                        referenceDatas={referenceDatas}
                                        formProps={{ control, setValue }}
                                    />
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                variant="outlined"
                                                fullWidth
                                                onClick={resetModal}
                                                iconLeft={<CleaningServices />}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={400}>
                                    <CardInquiryDataGrid
                                        onReturnData={onReturnData}
                                        data={pCardSearchItems}
                                        closeModal={closeModal}
                                        referenceDatas={referenceDatas}
                                        prodProductGroupListForComboData={prodProductGroupListForComboData}
                                        prodProductListForComboData={prodProductListForComboData}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default PpCcmsCardSearch;
