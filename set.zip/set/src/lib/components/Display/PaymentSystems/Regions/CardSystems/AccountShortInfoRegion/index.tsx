/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, type JSX } from 'react';
import type { FieldValues, Path } from 'seker-ui';
import {
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    NumberFormat,
    Radio,
    RadioGroup,
    Select,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    message,
} from 'seker-ui';
import type { IProdProductListForComboRequest, IProdProductListForComboResponse } from '../../../../../../../lib/utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../../lib/utils';
import type { IAccountShortInfoRegion } from './type';
import { GroupRealAdditionEnum } from './type';
import useAxios from 'axios-hooks';
import type {
    IProductGroupListForComboRequest,
    IProductGroupListForComboResponse,
} from '../../../../../../utils/types/api/models/PaymentSystems/cardSystems/productProductGroupListForCombo/type';
import type {
    IProductMainGroupListForComboRequest,
    IProductMainGroupListForComboResponse,
} from '../../../../../../utils/types/api/models/PaymentSystems/cardSystems/productProductMainGroupListForCombo/type';
import { ListTypeEnum, ProductGroupEnum } from '../../../Modals/CardSystems/CardInquiryModal/type';
import type {
    ICcmsAccountProfileGetCmsAccountShortInfoRequest,
    ICcmsAccountProfileGetCmsAccountShortInfoResponse,
} from '../../../../../../utils/types/api/models/PaymentSystems/cardSystems/ccmsAccountProfileGetCmsAccountShortInfo/type';
import { isEmpty } from 'lodash';

const AccountShortInfoRegion = <T extends FieldValues>({
    formProps: { control, setValue },
    componentProps,
    accountNo,
}: IAccountShortInfoRegion<T>): JSX.Element => {
    const { t, locale } = useTranslation();

    const [{ data: productMainGroupListForComboData }] = useAxios<
        IProductMainGroupListForComboResponse,
        IProductMainGroupListForComboRequest
    >({
        ...getGenericSetCaller(GenericSetCallerEnum.PRODUCT_PRODUCT_MAIN_GROUP_LIST_FOR_COMBO),
        data: { listType: ListTypeEnum.GroupList },
    });

    const [{ data: productGroupListForComboData }, productGroupListForComboRequest] = useAxios<
        IProductGroupListForComboResponse,
        IProductGroupListForComboRequest
    >(getGenericSetCaller(GenericSetCallerEnum.PRODUCT_PRODUCT_GROUP_LIST_FOR_COMBO), { manual: true });

    const [{ data: productListForComboData }, productListForComboRequest] = useAxios<
        IProdProductListForComboResponse,
        IProdProductListForComboRequest
    >(getGenericSetCaller(GenericSetCallerEnum.PROD_PRODUCT_LIST_FOR_COMBO), { manual: true });

    const [{ data: ccmsAccountProfileGetCmsAccountShortInfoData }, ccmsAccountProfileGetCmsAccountShortInfoRequest] =
        useAxios<ICcmsAccountProfileGetCmsAccountShortInfoResponse, ICcmsAccountProfileGetCmsAccountShortInfoRequest>(
            getGenericSetCaller(GenericSetCallerEnum.CCMS_ACCOUNT_PROFILE_GET_CMS_ACCOUNT_SHORT_INFO),
            { manual: true },
        );

    useEffect(() => {
        if (productMainGroupListForComboData?.productMainGroupList.length) {
            productGroupListForComboRequest({
                data: {
                    listType: '1',
                    productMainGroupCode: productMainGroupListForComboData?.productMainGroupList?.find(
                        (item) => item[0] === ProductGroupEnum.ProductMainGroup,
                    )?.[0],
                },
            });
        }
    }, [productMainGroupListForComboData]);

    const getShortInfoDatas = async () => {
        const response = await ccmsAccountProfileGetCmsAccountShortInfoRequest({
            data: {
                accountNo,
            },
        });
        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data;
            if (!isEmpty(responseData)) {
                setValue(
                    componentProps.numberInputProps.expirationDate.name as Path<T>,
                    `${responseData?.currExpireYearMonth?.substring(0, 2)}/${responseData?.currExpireYearMonth?.substring(2, 4)}` as any,
                );
                setValue(
                    componentProps.numberInputProps.blockCode.name as Path<T>,
                    `${responseData.blockReclassCode.substring(0, 1)}/${responseData?.blockReclassCode?.substring(1, 2)}` as any,
                );
                setValue(componentProps.inputProps.realCardNo.name as Path<T>, responseData.realAccountNo as any);
                setValue(componentProps.radioGroupProps.primaryType.name as Path<T>, responseData.primaryType as any);
                productGroupListForComboRequest({
                    data: {
                        listType: '1',
                        productMainGroupCode: productMainGroupListForComboData?.productMainGroupList?.find(
                            (item) => item[0] === ProductGroupEnum.ProductMainGroup,
                        )?.[0],
                    },
                });
                productListForComboRequest({
                    data: {
                        listType: '1',
                        productGroupCode: responseData?.productGroupCode,
                        productMainGroupCode: productMainGroupListForComboData?.productMainGroupList?.find(
                            (item) => item[0] === ProductGroupEnum.ProductMainGroup,
                        )?.[0],
                    },
                });
                setValue(componentProps.selectProps.productGroup.name as Path<T>, responseData.productGroupCode as any);
                setValue(componentProps.selectProps.product.name as Path<T>, responseData.productCode as any);
            }
        } else {
            message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
        }
    };

    useEffect(() => {
        if (accountNo) {
            getShortInfoDatas();
        }
    }, [accountNo]);

    return (
        <Grid spacingType="form">
            <GridItem
                lg={constants.design.gridItem.sizeType.form.SET.lg * 5}
                xl={constants.design.gridItem.sizeType.form.SET.xl * 3}
                xxl={constants.design.gridItem.sizeType.form.SET.xxl * 4}>
                <Grid
                    spacingType="form"
                    columns={{
                        lg: constants.design.gridItem.sizeType.form.SET.lg * 5,
                        xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                        xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                    }}>
                    <GridItem sizeType="form">
                        <Select
                            control={control}
                            setValue={setValue}
                            displayEmpty
                            options={{
                                data: productGroupListForComboData?.productGroupList || [],
                                displayField: 1,
                                displayValue: 0,
                                renderDisplayField: (params) => `${params?.[0]} - ${params?.[1]}`,
                                renderDisplayList: (params) => `${params?.[0]} - ${params?.[1]}`,
                            }}
                            readOnly
                            {...componentProps.selectProps.productGroup}
                            name={componentProps.selectProps.productGroup.name as Path<T>}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Select
                            control={control}
                            setValue={setValue}
                            displayEmpty
                            options={{
                                data: productListForComboData?.productList || [],
                                displayField: 1,
                                displayValue: 0,
                                renderDisplayField: (params) => `${params?.[0]} - ${params?.[1]}`,
                                renderDisplayList: (params) => `${params?.[0]} - ${params?.[1]}`,
                            }}
                            readOnly
                            {...componentProps.selectProps?.product}
                            name={componentProps.selectProps.product.name as Path<T>}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Input
                            control={control}
                            readOnly
                            {...componentProps.numberInputProps.expirationDate}
                            name={componentProps.numberInputProps.expirationDate.name as Path<T>}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Input
                            control={control}
                            readOnly
                            {...componentProps.numberInputProps.blockCode}
                            name={componentProps.numberInputProps.blockCode.name as Path<T>}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Input
                            control={control}
                            readOnly
                            {...componentProps.inputProps.realCardNo}
                            name={componentProps.inputProps.realCardNo.name as Path<T>}
                        />
                    </GridItem>
                    <GridItem
                        xs
                        sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                        md={constants.design.gridItem.sizeType.form.SET.md * 3}
                        lg={constants.design.gridItem.sizeType.form.SET.lg * 2}
                        xl={constants.design.gridItem.sizeType.form.SET.xl}
                        xxl={constants.design.gridItem.sizeType.form.SET.xxl * 2}>
                        <RadioGroup
                            sx={{ pt: { sm: 2.5 } }}
                            row
                            control={control}
                            {...componentProps.radioGroupProps.primaryType}
                            name={componentProps.radioGroupProps.primaryType.name as Path<T>}>
                            <Radio
                                disabled
                                value={GroupRealAdditionEnum.RealCard}
                                {...componentProps.radioProps.realCard}
                            />
                            <Radio
                                disabled
                                value={GroupRealAdditionEnum.AdditionalCard}
                                {...componentProps.radioProps.additionalCard}
                            />
                            <Radio
                                disabled
                                value={GroupRealAdditionEnum.VirtualCard}
                                {...componentProps.radioProps.virtualCard}
                            />
                        </RadioGroup>
                    </GridItem>
                </Grid>
            </GridItem>
            <GridItem
                xs
                lg={constants.design.gridItem.sizeType.form.SET.lg * 5}
                xl={constants.design.gridItem.sizeType.form.SET.xl * 3}
                xxl={constants.design.gridItem.sizeType.form.SET.xxl * 4}>
                <Table noBorder>
                    <TableHead>
                        <TableRow>
                            <TableCell> </TableCell>
                            <TableCell width="20%" align="center">
                                {t(locale.contentTitles.limit)}
                            </TableCell>
                            <TableCell width="20%" align="center">
                                {t(locale.contentTitles.tlBalance)}
                            </TableCell>
                            <TableCell width="20%" align="center">
                                {t(locale.contentTitles.usdBalance)}
                            </TableCell>
                            <TableCell width="20%" align="center">
                                {t(locale.contentTitles.availableLimit)}
                            </TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <TableRow sx={{ borderBottom: 'none' }}>
                            <TableCell variant="head">{t(locale.contentTitles.credit)}</TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.creditLimit || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.fcForwardTotalBal949 || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.fcForwardTotalBal840 || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.availableAmount || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell variant="head">{t(locale.contentTitles.cash)}</TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.cashLimit || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.fcNewCashBal949 || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.fcNewCashBal840 || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                            <TableCell align="center">
                                <NumberFormat
                                    value={ccmsAccountProfileGetCmsAccountShortInfoData?.availableCashAmount || 0}
                                    thousandSeparator="."
                                    decimalSeparator=","
                                    decimalScale={2}
                                    fixedDecimalScale
                                />
                            </TableCell>
                        </TableRow>
                    </TableBody>
                </Table>
            </GridItem>
        </Grid>
    );
};

export default AccountShortInfoRegion;
