import type {
    FieldValues,
    INumberInputProps,
    ISelectProps,
    IInputProps,
    IRadioGroupProps,
    IRadioProps,
    HelperFormProps,
} from 'seker-ui';

export enum GroupRealAdditionEnum {
    RealCard = 'A',
    AdditionalCard = 'E',
    VirtualCard = 'S',
}

export interface IAccountShortInfoRegionFormValues {
    additionalCard: string;
    blockCode: string;
    expirationDate: string;
    primaryType: string;
    product: string;
    productGroup: string;
    realCard: string;
    realCardNo: string;
    virtualCard: string;
}

type INumberInputType<T> = Record<
    `${keyof Pick<IAccountShortInfoRegionFormValues, 'expirationDate' | 'blockCode'>}`,
    Pick<INumberInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type ISelectType<T> = {
    [Property in `${keyof Pick<IAccountShortInfoRegionFormValues, 'product' | 'productGroup'>}`]: Pick<
        ISelectProps<IAccountShortInfoRegionFormValues[Property]>,
        'disabled' | 'readOnly' | 'label'
    > & { name: keyof T };
};
type IRadioType = Record<
    `${keyof Pick<IAccountShortInfoRegionFormValues, 'realCard' | 'additionalCard' | 'virtualCard'>}`,
    Pick<IRadioProps, 'disabled' | 'label'>
>;

type IInputType<T> = Record<
    `${keyof Pick<IAccountShortInfoRegionFormValues, 'realCardNo'>}`,
    Pick<IInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type IRadioGroupType<T> = Record<
    `${keyof Pick<IAccountShortInfoRegionFormValues, 'primaryType'>}`,
    Pick<IRadioGroupProps, 'label'> & {
        name: keyof T;
    }
>;

export interface IAccountShortInfoRegionComponentProps<T> {
    inputProps: IInputType<T>;
    numberInputProps: INumberInputType<T>;
    radioGroupProps: IRadioGroupType<T>;
    radioProps: IRadioType;
    selectProps: ISelectType<T>;
}

export interface IAccountShortInfoRegion<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'setValue' | 'getValues' | 'handleSubmit'> {
    accountNo: string;
    componentProps: IAccountShortInfoRegionComponentProps<T>;
}
