import type { FieldValues, HelperFormProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { SETModalsEnum } from '../../../../../../utils';
import type { IModalViewerProps } from '../../../../../Others/ModalViewer/type';
export interface IAccountFirstRegionFormValues {
    cardNo: number | null;
    corporation: string;
    customerNameSurname: string;
    customerNo: number | null;
}

type ISelectType<T> = {
    [Property in `${keyof Pick<IAccountFirstRegionFormValues, 'corporation'>}`]: Pick<
        ISelectProps<IAccountFirstRegionFormValues[Property]>,
        'disabled' | 'readOnly' | 'label'
    > & { name: keyof T };
};

type IInputType<T> = Record<
    `${keyof Pick<IAccountFirstRegionFormValues, 'customerNameSurname'>}`,
    Pick<IInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type INumberInputType<T> = Record<
    `${keyof Pick<IAccountFirstRegionFormValues, 'customerNo' | 'cardNo'>}`,
    Pick<IModalViewerProps<SETModalsEnum.CardInquiryModal>, 'adornmentButtonProps' | 'disabled' | 'modalProps' | 'sx'> &
        Pick<INumberInputProps, 'readOnly' | 'label'> & { name: keyof T }
>;

export interface IAccountFirstRegion<T extends FieldValues> extends HelperFormProps<T, 'control' | 'setValue'> {
    componentProps: IAccountFirstRegionComponentProps<T>;
}

export interface IAccountFirstRegionComponentProps<T> {
    inputProps: IInputType<T>;
    numberInputProps: INumberInputType<T>;
    selectProps: ISelectType<T>;
}
export enum CorporationEnum {
    Sekerbank = '01',
}
