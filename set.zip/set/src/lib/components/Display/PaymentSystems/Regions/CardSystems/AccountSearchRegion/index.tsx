import type { FieldValues } from 'seker-ui';
import { Grid, GridItem, Input, Select } from 'seker-ui';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../..';
import {
    ModalViewer,
    ReferenceDataEnum,
    SETModalsEnum,
    generateReferenceDataRequestList,
    useAxios,
    useTranslation,
    constants,
} from '../../../../../..';
import type { IAccountFirstRegion } from './type';
import type { JSX } from 'react';

const AccountSearchRegion = <T extends FieldValues>({
    formProps: { control, setValue },
    componentProps,
}: IAccountFirstRegion<T>): JSX.Element => {
    const { t, locale } = useTranslation();

    const [{ data: referenceDatas }] = useAxios<ReferenceDataResponse, ReferenceDataRequest>({
        ...constants.api.endpoints.nova.gateway.referenceData.POST,
        data: {
            requestList: generateReferenceDataRequestList({
                nameList: [ReferenceDataEnum.PRM_CCC_CORPORATION],
            }),
        },
    });

    return (
        <Grid spacingType="form">
            <GridItem sizeType="form">
                <Select
                    control={control}
                    setValue={setValue}
                    options={{
                        data:
                            referenceDatas?.resultList?.find(
                                (item) => item.name === ReferenceDataEnum.PRM_CCC_CORPORATION,
                            )?.items || [],
                        displayField: 'value',
                        displayValue: 'key',
                    }}
                    {...componentProps?.selectProps?.corporation}
                    name={componentProps.selectProps?.corporation?.name as any}
                    label={componentProps.selectProps.corporation.label || t(locale.labels.corporation)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <ModalViewer<SETModalsEnum.CardInquiryModal>
                    component="NumberInput"
                    modalComponent={SETModalsEnum.CardInquiryModal}
                    control={control}
                    deps="cardNo"
                    adornmentButtonProps={{
                        tooltip: t(locale.labels.cardQuery),
                    }}
                    {...componentProps?.numberInputProps?.customerNo}
                    name={componentProps.numberInputProps.customerNo?.name as any}
                    label={componentProps.numberInputProps.customerNo.label || t(locale.labels.cardNo)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <ModalViewer<SETModalsEnum.CardInquiryModal>
                    component="CardNumber"
                    modalComponent={SETModalsEnum.CardInquiryModal}
                    control={control}
                    deps="customerNo"
                    adornmentButtonProps={{
                        tooltip: t(locale.labels.cardQuery),
                    }}
                    {...componentProps?.numberInputProps?.cardNo}
                    name={componentProps.numberInputProps.cardNo?.name as any}
                    label={componentProps.numberInputProps.cardNo.label || t(locale.labels.customerNo)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    control={control}
                    readOnly
                    {...componentProps?.inputProps?.customerNameSurname}
                    name={componentProps.inputProps?.customerNameSurname.name as any}
                    label={componentProps.inputProps.customerNameSurname.label || t(locale.labels.customerNameSurname)}
                />
            </GridItem>
        </Grid>
    );
};

export default AccountSearchRegion;
