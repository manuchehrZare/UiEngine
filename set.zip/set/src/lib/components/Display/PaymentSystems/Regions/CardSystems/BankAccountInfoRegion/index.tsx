import type { FieldValues } from 'seker-ui';
import { Grid, GridItem, Input, NumberInputReturnValueEnum, Select } from 'seker-ui';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../..';
import {
    ModalViewer,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    generateReferenceDataRequestList,
    useAxios,
    useTranslation,
} from '../../../../../..';
import type { IBankAccountInfoRegion } from './type';
import type { JSX } from 'react';

const BankAccountInfoRegion = <T extends FieldValues>({
    formProps: { control, setValue },
    componentProps,
}: IBankAccountInfoRegion<T>): JSX.Element => {
    const { t, locale } = useTranslation();

    const [{ data: referenceDatas }] = useAxios<ReferenceDataResponse, ReferenceDataRequest>({
        ...constants.api.endpoints.nova.gateway.referenceData.POST,
        data: {
            requestList: generateReferenceDataRequestList({
                nameList: [ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE],
            }),
        },
    });

    return (
        <Grid spacingType="form">
            <GridItem sizeType="form">
                <Select
                    control={control}
                    setValue={setValue}
                    displayEmpty
                    options={{
                        data:
                            referenceDatas?.resultList
                                ?.find((item) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE)
                                ?.items?.sort((a, b) => {
                                    return Number(a.key) - Number(b.key);
                                }) || [],
                        displayField: 'value',
                        displayValue: 'key',
                        renderDisplayList: (params) => `${params.key} - ${params.value}`,
                        renderDisplayField: (params) => `${params.key} - ${params.value}`,
                    }}
                    {...componentProps?.selectProps?.branch}
                    name={componentProps.selectProps?.branch?.name as any}
                    label={componentProps.selectProps.branch.label || t(locale.labels.branch)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                    component="NumberInput"
                    modalComponent={SETModalsEnum.CustomerInquiryModal}
                    control={control}
                    adornmentButtonProps={{
                        tooltip: t(locale.labels.customerNo),
                    }}
                    {...componentProps?.numberInputProps?.customerNo}
                    name={componentProps.numberInputProps?.customerNo?.name as any}
                    label={componentProps.numberInputProps.customerNo.label || t(locale.labels.customerNo)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    control={control}
                    {...componentProps?.inputProps?.customerNameSurname}
                    name={componentProps.inputProps.customerNameSurname.name as any}
                    label={componentProps.inputProps.customerNameSurname.label || t(locale.labels.customerNameSurname)}
                />
            </GridItem>
            <GridItem sizeType="form">
                <ModalViewer<SETModalsEnum.AccountSelectionModal>
                    component="NumberInput"
                    modalComponent={SETModalsEnum.AccountSelectionModal}
                    control={control}
                    allowLeadingZeros
                    returnValue={NumberInputReturnValueEnum.formattedValue}
                    adornmentButtonProps={{
                        tooltip: SETModalsEnum.AccountSelectionModal,
                    }}
                    {...componentProps?.numberInputProps?.accountNo}
                    name={componentProps.numberInputProps?.accountNo?.name as any}
                    label={componentProps.numberInputProps.accountNo.label || t(locale.labels.accountNo)}
                />
            </GridItem>
        </Grid>
    );
};

export default BankAccountInfoRegion;
