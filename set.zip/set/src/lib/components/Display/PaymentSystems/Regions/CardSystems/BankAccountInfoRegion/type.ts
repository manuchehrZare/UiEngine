import type { FieldValues, HelperFormProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IModalViewerProps } from '../../../../../Others/ModalViewer/type';
import type { SETModalsEnum } from '../../../../../..';

export interface IBankAccountInfoRegionFormValues {
    accountNo: number | null;
    branch: string;
    customerNameSurname: string;
    customerNo: number | null;
}

type INumberInputCommonType<
    J,
    T extends SETModalsEnum.AccountSelectionModal | SETModalsEnum.CustomerInquiryModal,
    K,
> = {
    [Property in keyof K]: Pick<IModalViewerProps<T>, 'adornmentButtonProps' | 'disabled' | 'modalProps' | 'sx'> &
        Pick<INumberInputProps, 'readOnly' | 'label'> & {
            name: keyof J;
        };
};

type INumberInputType<T> = INumberInputCommonType<
    T,
    SETModalsEnum.AccountSelectionModal,
    Pick<IBankAccountInfoRegionFormValues, 'accountNo'>
> &
    INumberInputCommonType<T, SETModalsEnum.CustomerInquiryModal, Pick<IBankAccountInfoRegionFormValues, 'customerNo'>>;

type IInputType<T> = Record<
    `${keyof Pick<IBankAccountInfoRegionFormValues, 'customerNameSurname'>}`,
    Pick<IInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type ISelectType<T> = {
    [Property in `${keyof Pick<IBankAccountInfoRegionFormValues, 'branch'>}`]: Pick<
        ISelectProps<IBankAccountInfoRegionFormValues[Property]>,
        'disabled' | 'readOnly' | 'label'
    > & { name: keyof T };
};

export interface IBankAccountInfoRegionComponentProps<T> {
    inputProps: IInputType<T>;
    numberInputProps: INumberInputType<T>;
    selectProps: ISelectType<T>;
}

export interface IBankAccountInfoRegion<T extends FieldValues> extends HelperFormProps<T, 'control' | 'setValue'> {
    componentProps: IBankAccountInfoRegionComponentProps<T>;
}
