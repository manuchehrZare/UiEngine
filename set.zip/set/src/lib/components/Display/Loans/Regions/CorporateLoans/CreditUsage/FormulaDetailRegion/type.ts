import type { Dispatch, SetStateAction } from 'react';
import type { IButtonProps, IInputProps } from 'seker-ui';
import type {
    IFormulaListItem,
    IGetTotalDatasetAndValuesOfUsageDataSet,
    IHelperModalProps,
    SETModalsCommonProps,
} from '../../../../../../..';

export interface IFormulaDetailRegionFormValues {
    approveChairs: string;
    arlApproveChair: string;
    creditNo: string;
    creditStatus: string;
    creditStopReason: string;
    customerRiskCode: string;
    detail: string;
    exceptionAdvisePeriod: string;
    exceptionFixPeriod: string;
    processType: string;
    successfulFormul: string;
}

type IInputType = Partial<
    Record<`${keyof IFormulaDetailRegionFormValues}`, Pick<IInputProps, 'disabled' | 'readOnly'>>
>;

interface IButtonComponentProps {
    closeButton?: Pick<IButtonProps, 'disabled'>;
    evaluateButton?: Pick<IButtonProps, 'disabled'>;
    getInformationFromCreditButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IFormulaDetailRegionComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps: IInputType;
}

export interface IIFormulaDetailRegionProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    componentProps?: IFormulaDetailRegionComponentProps;
    creditState?: string;
    formData?: Partial<IFormulaDetailRegionFormValues>;
    lblFrmResutlVisible?: boolean;
    onClose: (modalShow: boolean) => void;
    pnlTable?: IGetTotalDatasetAndValuesOfUsageDataSet[];
    setEditableGridExp?: (data: Dispatch<SetStateAction<boolean>>) => void;
    setEvulationButtonVisibleExp?: (data: Dispatch<SetStateAction<boolean>>) => void;
    setGetInformationFromCreditButtonDisabledExp?: (data: Dispatch<SetStateAction<boolean>>) => void;
    setNotSearchByCreditExp?: (data: Dispatch<SetStateAction<boolean>>) => void;
    show: boolean;
    tblFormulaList?: IFormulaListItem[];
    titleImp?: string;
    varTestOneFormula?: boolean;
}

export enum CorporationEnum {
    Sekerbank = '01',
}
export enum UsageControlEnum {
    ProcessId = '105480',
}
