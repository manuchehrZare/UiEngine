import type { FieldValues } from 'seker-ui';
import type { CommonCurrencyValueProps } from './type';
import { RegionEnum } from './type';
import CommonCurrencyValueDisplayModal from './DisplayModal';
import CommonCurrencyValueDisplayRegion from './DisplayRegion';
import type { JSX } from 'react';

/**  When this component is used as a region, it returns a GridItem to manage the size of the form elements more easily. */
const CommonCurrencyValueRegion = <T extends FieldValues>(props: CommonCurrencyValueProps<T>): JSX.Element => {
    const priceType = props.serviceType ? props.serviceType : RegionEnum.EveluationBuyPrice;

    if (props.displayType === 'Modal') {
        return (
            <CommonCurrencyValueDisplayModal
                show={props.show}
                onClose={props.onClose}
                componentProps={props.componentProps}
                serviceType={priceType}
                onReturnData={props.onReturnData}
                formData={props.formData}
            />
        );
    }

    return (
        <CommonCurrencyValueDisplayRegion
            componentProps={props.componentProps}
            formProps={props.formProps}
            serviceType={priceType}
        />
    );
};

export default CommonCurrencyValueRegion;
