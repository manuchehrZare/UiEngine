/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, type JSX } from 'react';
import type { IRegionProps } from './type';
import type { FieldValues } from 'seker-ui';
import { GridItem, NumberInput, Select, useWatch } from 'seker-ui';
import { RegionEnum } from '../type';
import type {
    IGetCompubankRatesRequest,
    IGetCompubankRatesResponse,
    IGetEvaluationPricesRequest,
    IGetEvaluationPricesResponse,
    IGetTCMBRatesRequest,
    IGetTCMBRatesResponse,
    ReferenceDataResponse,
    ReferenceDataRequest,
} from '../../../../../../../../utils';
import {
    GenericSetCallerEnum,
    getGenericSetCaller,
    HttpStatusCodeEnum,
    useTranslation,
    ReferenceDataEnum,
    generateReferenceDataRequestList,
    constants,
} from '../../../../../../../../utils';
import { useAxios } from '../../../../../../../../hooks/useAxios';

const CommonCurrencyValueDisplayRegion = <T extends FieldValues>({
    componentProps,
    formProps,
    serviceType,
}: IRegionProps<T>): JSX.Element => {
    const { t, locale } = useTranslation();
    const [currencyTypeVal] = useWatch({
        control: formProps.control,
        fieldName: [componentProps?.selectProps?.currencyType?.name as string],
    } as any);

    const [{ data: referenceDatas }] = useAxios<ReferenceDataResponse, ReferenceDataRequest>({
        ...constants.api.endpoints.nova.gateway.referenceData.POST,
        data: {
            requestList: generateReferenceDataRequestList({
                nameList: [ReferenceDataEnum.PRM_CURRENCY_CODE],
            }),
        },
    });

    const [{ error: getEvaluationPricesError }, getEvaluationPricesCall] = useAxios<
        IGetEvaluationPricesResponse,
        IGetEvaluationPricesRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCSUTIL_COMMON_GET_EVALUATION_PRICES), { manual: true });

    const [{ error: getCompubankRatesError }, getCompubankRatesCall] = useAxios<
        IGetCompubankRatesResponse,
        IGetCompubankRatesRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCSUTIL_COMMON_GET_COMPUBANK_RATES), { manual: true });

    const [{ error: getTCMBRatesError }, getTCMBRatesCall] = useAxios<IGetTCMBRatesResponse, IGetTCMBRatesRequest>(
        getGenericSetCaller(GenericSetCallerEnum.CCSUTIL_COMMON_GET_TCMB_RATES),
        { manual: true },
    );

    const getDatas = async () => {
        if (serviceType === RegionEnum.EveluationBuyPrice) {
            const responseEvaluationPrices = await getEvaluationPricesCall({
                data: {
                    currencyCode: formProps.getValues(componentProps?.selectProps?.currencyType?.name as any),
                },
            });
            if (responseEvaluationPrices?.status === HttpStatusCodeEnum.Ok) {
                responseEvaluationPrices?.data &&
                    formProps.reset((values) => ({
                        ...values,
                        exchange: responseEvaluationPrices?.data?.evaluationBuyRateofex,
                    }));
            }
        } else if (serviceType === RegionEnum.COMPUBANKBuyPrice || serviceType === RegionEnum.COMPUBANKSellPrice) {
            const responseCompubankRates = await getCompubankRatesCall({
                data: { currencyCode: componentProps?.selectProps?.currencyType?.name as any },
            });
            if (responseCompubankRates?.status === HttpStatusCodeEnum.Ok) {
                responseCompubankRates?.data &&
                    formProps.reset((values) => ({
                        ...values,
                        exchange:
                            serviceType === RegionEnum.COMPUBANKBuyPrice
                                ? responseCompubankRates?.data?.buyPrice
                                : responseCompubankRates?.data?.sellPrice,
                    }));
            }
        } else {
            const responseTCMBRates = await getTCMBRatesCall({
                data: { currencyCode: componentProps?.selectProps?.currencyType?.name as any },
            });
            if (responseTCMBRates?.status === HttpStatusCodeEnum.Ok) {
                responseTCMBRates?.data &&
                    formProps.reset((values) => ({
                        ...values,
                        exchange:
                            serviceType === RegionEnum.TCMBBuyPrice
                                ? responseTCMBRates?.data?.buyPrice
                                : responseTCMBRates?.data?.evaluationPrice,
                    }));
            }
        }
    };

    useEffect(() => {
        currencyTypeVal ? getDatas() : formProps.reset();
    }, [currencyTypeVal]);

    useEffect(() => {
        if (getCompubankRatesError || getEvaluationPricesError || getTCMBRatesError) {
            formProps.resetField(componentProps?.numberInputProps?.exchange.name as any);
        }
    }, [getCompubankRatesError, getEvaluationPricesError, getTCMBRatesError]);

    return (
        <>
            <GridItem sizeType="form">
                <Select
                    control={formProps?.control}
                    setValue={formProps?.setValue}
                    name={componentProps?.selectProps?.currencyType?.name as string}
                    label={componentProps?.selectProps?.currencyType?.label || t(locale.labels.currencyType)}
                    options={{
                        data:
                            referenceDatas?.resultList?.find(
                                (item) => item?.name === ReferenceDataEnum.PRM_CURRENCY_CODE,
                            )?.items || [],
                        displayField: 'value',
                        displayValue: 'key',
                    }}
                    disabled={componentProps?.selectProps?.currencyType?.disabled}
                    readOnly={componentProps?.selectProps?.currencyType?.readOnly}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    name={componentProps?.numberInputProps?.exchange.name as string}
                    label={componentProps?.numberInputProps?.exchange.label || t(locale.labels.exchange)}
                    control={formProps.control}
                    allowNegative
                    decimalScale={6}
                    decimalSeparator=","
                    thousandSeparator="."
                    fixedDecimalScale
                    textAlign="right"
                    disabled={componentProps?.numberInputProps?.exchange.disabled}
                    readOnly={componentProps?.numberInputProps?.exchange.readOnly}
                />
            </GridItem>
        </>
    );
};

export default CommonCurrencyValueDisplayRegion;
