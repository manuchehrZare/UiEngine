/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect } from 'react';
import { Grid, GridItem, Modal, ModalBody, ModalTitle, NumberInput, Paper, Select, useForm, useWatch } from 'seker-ui';
import type {
    IGetCompubankRatesRequest,
    IGetCompubankRatesResponse,
    IGetEvaluationPricesRequest,
    IGetEvaluationPricesResponse,
    IGetTCMBRatesRequest,
    IGetTCMBRatesResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
} from '../../../../../../../../utils';
import {
    constants,
    generateReferenceDataRequestList,
    GenericSetCallerEnum,
    getGenericSetCaller,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    useTranslation,
} from '../../../../../../../../utils';
import type { IQueryFormValues } from '../type';
import { RegionEnum } from '../type';
import { useAxios } from '../../../../../../../../hooks/useAxios';
import type { IModalProps } from './type';

const CommonCurrencyValueTesterDisplayModal: FC<IModalProps> = ({
    onClose,
    show,
    formData,
    serviceType,
    onReturnData,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const { control, setValue, reset, resetField, getValues, handleSubmit } = useForm<IQueryFormValues>({
        defaultValues: { exchange: 0, currencyType: '' },
    });

    const [exchangeVal, currencyTypeVal] = useWatch({ control, fieldName: ['exchange', 'currencyType'] });

    const [{ data: referenceDatas }] = useAxios<ReferenceDataResponse, ReferenceDataRequest>({
        ...constants.api.endpoints.nova.gateway.referenceData.POST,
        data: {
            requestList: generateReferenceDataRequestList({
                nameList: [ReferenceDataEnum.PRM_CURRENCY_CODE],
            }),
        },
    });

    const [{ error: getEvaluationPricesError }, getEvaluationPricesCall] = useAxios<
        IGetEvaluationPricesResponse,
        IGetEvaluationPricesRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCSUTIL_COMMON_GET_EVALUATION_PRICES), { manual: true });

    const [{ error: getCompubankRatesError }, getCompubankRatesCall] = useAxios<
        IGetCompubankRatesResponse,
        IGetCompubankRatesRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCSUTIL_COMMON_GET_COMPUBANK_RATES), { manual: true });

    const [{ error: getTCMBRatesError }, getTCMBRatesCall] = useAxios<IGetTCMBRatesResponse, IGetTCMBRatesRequest>(
        getGenericSetCaller(GenericSetCallerEnum.CCSUTIL_COMMON_GET_TCMB_RATES),
        { manual: true },
    );

    const onSubmit = async (formDatas: IQueryFormValues) => {
        if (serviceType === RegionEnum.EveluationBuyPrice) {
            const responseEvaluationPrices = await getEvaluationPricesCall({
                data: { currencyCode: formDatas.currencyType },
            });
            if (responseEvaluationPrices?.status === HttpStatusCodeEnum.Ok) {
                responseEvaluationPrices?.data &&
                    reset((values) => ({
                        ...values,
                        exchange: responseEvaluationPrices?.data?.evaluationBuyRateofex,
                    }));
            }
        } else if (serviceType === RegionEnum.COMPUBANKBuyPrice || serviceType === RegionEnum.COMPUBANKSellPrice) {
            const responseCompubankRates = await getCompubankRatesCall({
                data: { currencyCode: formDatas.currencyType },
            });
            if (responseCompubankRates?.status === HttpStatusCodeEnum.Ok) {
                responseCompubankRates?.data &&
                    reset((values) => ({
                        ...values,
                        exchange:
                            serviceType === RegionEnum.COMPUBANKBuyPrice
                                ? responseCompubankRates?.data?.buyPrice
                                : responseCompubankRates?.data?.sellPrice,
                    }));
            }
        } else {
            const responseTCMBRates = await getTCMBRatesCall({
                data: { currencyCode: formDatas.currencyType },
            });
            if (responseTCMBRates?.status === HttpStatusCodeEnum.Ok) {
                responseTCMBRates?.data &&
                    reset((values) => ({
                        ...values,
                        exchange:
                            serviceType === RegionEnum.TCMBBuyPrice
                                ? responseTCMBRates?.data?.buyPrice
                                : responseTCMBRates?.data?.evaluationPrice,
                    }));
            }
        }
    };

    const closeModal = () => {
        onClose(false);
    };

    useEffect(() => {
        if (formData) {
            reset({
                ...getValues(),
                ...formData,
            });
        }
    }, [formData]);

    useEffect(() => {
        onReturnData?.({ currencyType: currencyTypeVal, exchange: exchangeVal });
    }, [exchangeVal]);

    useEffect(() => {
        currencyTypeVal ? handleSubmit(onSubmit)() : reset();
        onReturnData?.({ currencyType: currencyTypeVal, exchange: exchangeVal });
    }, [currencyTypeVal]);

    useEffect(() => {
        if (getCompubankRatesError || getEvaluationPricesError || getTCMBRatesError) {
            resetField('exchange');
        }
    }, [getCompubankRatesError, getEvaluationPricesError, getTCMBRatesError]);

    return (
        <Modal maxWidth="sm" show={show} onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.commonCurrencyValue)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid
                                spacingType="form"
                                columns={{
                                    xs: constants.design.gridItem.sizeType.form.SET.xs,
                                    sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                    md: constants.design.gridItem.sizeType.form.SET.md * 2,
                                    lg: constants.design.gridItem.sizeType.form.SET.lg * 2,
                                    xl: constants.design.gridItem.sizeType.form.SET.xl * 2,
                                    xxl: constants.design.gridItem.sizeType.form.SET.xxl * 2,
                                }}>
                                <GridItem sizeType="form">
                                    <Select
                                        control={control}
                                        setValue={setValue}
                                        name="currencyType"
                                        label={t(locale.labels.currencyType)}
                                        options={{
                                            data:
                                                referenceDatas?.resultList?.find(
                                                    (item) => item?.name === ReferenceDataEnum.PRM_CURRENCY_CODE,
                                                )?.items || [],
                                            displayField: 'value',
                                            displayValue: 'key',
                                        }}
                                        disabled={componentProps?.selectProps?.currencyType?.disabled}
                                        readOnly={componentProps?.selectProps?.currencyType?.readOnly}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <NumberInput
                                        name="exchange"
                                        label={t(locale.labels.exchange)}
                                        control={control}
                                        allowNegative
                                        decimalScale={6}
                                        decimalSeparator=","
                                        thousandSeparator="."
                                        fixedDecimalScale
                                        textAlign="right"
                                        disabled={componentProps?.numberInputProps?.exchange.disabled}
                                        readOnly={componentProps?.numberInputProps?.exchange.readOnly}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default CommonCurrencyValueTesterDisplayModal;
