import type { FC } from 'react';
import type { IFileSelectorInputProps } from 'seker-ui';
import { FileSelector } from 'seker-ui';

export interface ICommonFilePickerRegionProps extends Omit<IFileSelectorInputProps, 'component'> {}

// RG_CCSUTL_COMMON_FILE_PICKER
const CommonFilePickerRegion: FC<ICommonFilePickerRegionProps> = (props) => (
    <FileSelector component="Input" {...props} />
);
export default CommonFilePickerRegion;
