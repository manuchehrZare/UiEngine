/* eslint-disable react-hooks/exhaustive-deps */
import type { DataGridColumnsPropsType } from 'seker-ui';
import {
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Input,
    message,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    Paper,
    useForm,
} from 'seker-ui';
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { IFormulaDetailRegionFormValues, IIFormulaDetailRegionProps } from './type';
import { UsageControlEnum } from './type';
import { FindInPage, Search } from '@mui/icons-material';
import type {
    IEvaluateFormulasWithDataSetDefRequest,
    IEvaluateFormulasWithDataSetDefResponse,
    IGetTotalDatasetAndValuesOfUsageDataSet,
    IGetTotalDatasetAndValuesOfUsageRequest,
    IGetTotalDatasetAndValuesOfUsageResponse,
} from '../../../../../../..';
import {
    constants,
    GenericSetCallerEnum,
    getGenericSetCaller,
    HttpStatusCodeEnum,
    ModalViewer,
    SETModalsEnum,
    useAxios,
    useTranslation,
} from '../../../../../../..';
import {
    CreditStateEnum,
    RecordTypeEnum,
} from '../../../../Modals/CorporateLoans/CreditUsage/LoanRequestFormSelectionModal/type';
import { isUndefined } from 'lodash';

// RG_CCSUTL_FORMUL_TEST
const FormulaDetailRegion: FC<IIFormulaDetailRegionProps> = ({
    componentProps,
    formData,
    lblFrmResutlVisible,
    onClose,
    pnlTable,
    setEditableGridExp,
    setEvulationButtonVisibleExp,
    setGetInformationFromCreditButtonDisabledExp,
    setNotSearchByCreditExp,
    show,
    tblFormulaList,
    titleImp,
    varTestOneFormula,
}) => {
    const { t, locale } = useTranslation();

    const [notSearchByCredit, setNotSearchByCredit] = useState<boolean>(true);
    const [getInformationFromCreditButtonDisabled, setGetInformationFromCreditButtonDisabled] = useState<boolean>(true);
    const [totalDatasetAndValuesOfUsageDataSet, setTotalDatasetAndValuesOfUsageDataSet] = useState<
        IGetTotalDatasetAndValuesOfUsageDataSet[]
    >(pnlTable || []);
    const [editableGrid, setEditableGrid] = useState<boolean>(true);
    const [evulationButtonVisible, setEvulationButtonVisible] = useState<boolean>(false);
    const [usageOid, setUsageOid] = useState<string>('');

    const { control, setValue, reset, getValues } = useForm<IFormulaDetailRegionFormValues>({
        defaultValues: {
            approveChairs: '',
            arlApproveChair: '',
            creditNo: '',
            creditStatus: '',
            creditStopReason: '',
            customerRiskCode: '',
            detail: '',
            exceptionAdvisePeriod: '',
            exceptionFixPeriod: '',
            processType: '',
            successfulFormul: '',
        },
    });

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'dataSetDef',
            headerName: t(locale.contentTitles.dataSet),
            headerAlign: 'center',
            align: 'center',
            minWidth: 160,
            flex: 1,
        },
        {
            field: 'values',
            headerName: t(locale.contentTitles.values),
            headerAlign: 'center',
            minWidth: 160,
            align: 'center',
            flex: 1,
            editable: editableGrid,
            valueFormatter: (value) => String(value)?.replace(/'/g, ''),
        },
    ];

    const [, getUsageControlList] = useAxios<
        IGetTotalDatasetAndValuesOfUsageResponse,
        IGetTotalDatasetAndValuesOfUsageRequest
    >(
        constants.api.endpoints.corporateLoans.creditUsage.credit.crdCreditUsageControl.getTotalDatasetAndValuesOfUsage
            .POST,
        { manual: true },
    );

    const [, getEvaluateFormulasWithDataSetDef] = useAxios<
        IEvaluateFormulasWithDataSetDefResponse,
        IEvaluateFormulasWithDataSetDefRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCS_UTL_EVALUATE_FORMULAS_WITH_DATA_SET_DEF), { manual: true });

    const closeModal = () => {
        setUsageOid('');
        reset();
        setNotSearchByCredit(true);
        setTotalDatasetAndValuesOfUsageDataSet([]);
        onClose?.(false);
    };

    useEffect(() => {
        if (usageOid && usageOid !== null) {
            setGetInformationFromCreditButtonDisabled(false);
        }
    }, [usageOid]);

    const actGetUsageControlList = async () => {
        const response = await getUsageControlList({
            data: {
                dataSet: totalDatasetAndValuesOfUsageDataSet,
                processId: UsageControlEnum.ProcessId,
                usageOid: usageOid,
            },
        });
        if (response.status === HttpStatusCodeEnum.Ok) {
            setTotalDatasetAndValuesOfUsageDataSet(response.data.dataSet);
            setEditableGrid(false);
        } else {
            pnlTable?.length && setTotalDatasetAndValuesOfUsageDataSet(pnlTable);
            message({
                variant: MessageTypeEnum.info,
                message: t(locale.notifications.noSearchedData),
            });
        }
    };

    const evtSearch = () => {
        setNotSearchByCredit(false);
    };

    const evtEvaluate = async () => {
        const response = await getEvaluateFormulasWithDataSetDef({
            data: {
                dataSetDef: totalDatasetAndValuesOfUsageDataSet || [],
                formulaList: tblFormulaList || [],
                oneFormula: varTestOneFormula || false,
            },
        });

        if (response?.status === HttpStatusCodeEnum.Ok) {
            if (response?.data) {
                setValue('approveChairs', response?.data?.approveChairs);
                setValue('arlApproveChair', response?.data?.arlApproveChair);
                setValue('creditStatus', response?.data?.creditStatus);
                setValue('creditStopReason', response?.data?.creditStopReason);
                setValue('customerRiskCode', response?.data?.customerRiskCode);
                setValue('detail', response?.data?.detail);
                setValue('exceptionAdvisePeriod', response?.data?.exceptionAdvisePeriod);
                setValue('exceptionFixPeriod', response?.data?.exceptionFixPeriod);
                setValue('processType', response?.data?.processType);
                setValue('successfulFormul', response?.data?.successfulFormul);
            } else {
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    useEffect(() => {
        if (formData) {
            reset({
                ...getValues(),
                ...formData,
            });
        }
    }, [formData]);

    useEffect(() => {
        setNotSearchByCreditExp?.(setNotSearchByCredit);
        setGetInformationFromCreditButtonDisabledExp?.(setGetInformationFromCreditButtonDisabled);
        setEditableGridExp?.(setEditableGrid);
        setEvulationButtonVisibleExp?.(setEvulationButtonVisible);
    }, []);

    return (
        <Modal show={Boolean(show)} onClose={closeModal}>
            <ModalTitle>{titleImp?.length ? titleImp : t(locale.contentTitles.batchStatusInfo)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit, width: { lg: 684 } }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem hidden={!isUndefined(varTestOneFormula) ? varTestOneFormula : true}>
                        <Paper>
                            <Grid
                                columns={{
                                    xs: constants.design.gridItem.sizeType.form.SET.xs,
                                    sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                    md: constants.design.gridItem.sizeType.form.SET.md * 2,
                                    lg: constants.design.gridItem.sizeType.form.SET.lg * 2,
                                    xl: constants.design.gridItem.sizeType.form.SET.xl * 2,
                                    xxl: constants.design.gridItem.sizeType.form.SET.xxl * 2,
                                }}
                                spacingType="form">
                                <GridItem sizeType="form">
                                    <ModalViewer<SETModalsEnum.LoanRequestFormSelectionModal>
                                        component="Input"
                                        modalComponent={SETModalsEnum.LoanRequestFormSelectionModal}
                                        control={control}
                                        name="creditNo"
                                        label={t(locale.labels.disbursementNo)}
                                        adornmentButtonProps={{
                                            tooltip: t(locale.contentTitles.disbursementNo),
                                            disabled: notSearchByCredit ? notSearchByCredit : true,
                                        }}
                                        modalProps={{
                                            onReturnData: (data: any) => {
                                                setValue('creditNo', data?.creditNo);
                                                setUsageOid(data?.oid);
                                            },
                                            formData: {
                                                state: CreditStateEnum.ActiveState,
                                            },
                                            usageVariables: { recordType: RecordTypeEnum?.Disbursement },
                                        }}
                                        disabled={notSearchByCredit ? notSearchByCredit : true}
                                        {...componentProps?.inputProps?.creditNo}
                                    />
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button">
                                        <GridItem mt={{ md: 2.25 }}>
                                            <Button
                                                text={t(locale.buttons.getInformationFromCredit)}
                                                iconLeft={<FindInPage />}
                                                fullWidth
                                                onClick={() => actGetUsageControlList()}
                                                disabled={
                                                    getInformationFromCreditButtonDisabled
                                                        ? getInformationFromCreditButtonDisabled
                                                        : true
                                                }
                                                {...componentProps?.buttonProps?.getInformationFromCreditButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="common">
                                <GridItem height={300}>
                                    <DataGrid
                                        columns={columns}
                                        rows={
                                            pnlTable?.length
                                                ? pnlTable || []
                                                : totalDatasetAndValuesOfUsageDataSet || []
                                        }
                                        onEditChange={(params) => {
                                            if (params.newRow?.values === undefined) {
                                                return;
                                            }
                                            const newList = totalDatasetAndValuesOfUsageDataSet.map((item) => {
                                                return item?.dataSetDef === params?.newRow?.dataSetDef
                                                    ? params?.newRow
                                                    : item;
                                            });
                                            setTotalDatasetAndValuesOfUsageDataSet(newList);
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid
                                columns={{
                                    xs: constants.design.gridItem.sizeType.form.SET.xs,
                                    sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                    md: constants.design.gridItem.sizeType.form.SET.md * 2,
                                    lg: constants.design.gridItem.sizeType.form.SET.lg * 2,
                                    xl: constants.design.gridItem.sizeType.form.SET.xl * 2,
                                    xxl: constants.design.gridItem.sizeType.form.SET.xxl * 2,
                                }}
                                spacingType="form">
                                <GridItem sizeType="form" hidden={lblFrmResutlVisible}>
                                    <Input
                                        name="successfulFormul"
                                        label={t(locale.labels.calculatedFormula)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.successfulFormul}
                                    />
                                </GridItem>
                                <GridItem sizeType="form" hidden={!lblFrmResutlVisible}>
                                    <Input
                                        name="successfulFormul"
                                        label={t(locale.labels.formulaResult)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.successfulFormul}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        multiline
                                        rows={2}
                                        name="detail"
                                        label={t(locale.labels.detail)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.detail}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="approveChairs"
                                        label={t(locale.labels.usageApprovalProfile)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.approveChairs}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="exceptionFixPeriod"
                                        label={t(locale.labels.differenceNotificationPeriod)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.exceptionFixPeriod}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="exceptionAdvisePeriod"
                                        label={t(locale.labels.differenceNotificationPeriod)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.exceptionAdvisePeriod}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="customerRiskCode"
                                        label={t(locale.labels.customerRiskCode)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.customerRiskCode}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="creditStatus"
                                        label={t(locale.labels.statusCode)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.creditStatus}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="creditStopReason"
                                        label={t(locale.labels.reasonForCreditSuspension)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.creditStopReason}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="processType"
                                        label={t(locale.labels.duration)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.processType}
                                    />
                                </GridItem>
                                <GridItem sizeType="form">
                                    <Input
                                        name="arlApproveChair"
                                        label={t(locale.labels.toaApprovalAuthority)}
                                        control={control}
                                        readOnly
                                        {...componentProps?.inputProps?.arlApproveChair}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
            <ModalFooter>
                <Grid spacingType="button" width="100%">
                    <GridItem
                        sm="auto"
                        ml={{ sm: 'auto' }}
                        hidden={!isUndefined(varTestOneFormula) ? varTestOneFormula : true}>
                        <Button
                            text={t(locale.buttons.inquire)}
                            iconLeft={<Search />}
                            fullWidth
                            onClick={evtSearch}
                            {...componentProps?.buttonProps?.inquiryButton}
                        />
                    </GridItem>
                    <GridItem
                        sm="auto"
                        hidden={evulationButtonVisible}
                        ml={{ ...(varTestOneFormula !== false && { sm: 'auto' }) }}>
                        <Button
                            text={t(locale.buttons.evaluate)}
                            fullWidth
                            iconLeft={<FindInPage />}
                            variant={varTestOneFormula !== false ? 'contained' : 'outlined'}
                            onClick={evtEvaluate}
                            {...componentProps?.buttonProps?.evaluateButton}
                        />
                    </GridItem>
                </Grid>
            </ModalFooter>
        </Modal>
    );
};

export default FormulaDetailRegion;
