import type { ISelectProps, INumberInputProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../../../../utils';
import type { IQueryFormValues, RegionEnum } from '../type';

type INumberInputModalType = Record<
    keyof Pick<IQueryFormValues, 'exchange'>,
    Pick<INumberInputProps, 'disabled' | 'readOnly' | 'label'>
>;

type ISelectModalType = {
    [Property in keyof Pick<IQueryFormValues, 'currencyType'>]?: Pick<
        ISelectProps<IQueryFormValues[Property]>,
        'disabled' | 'readOnly' | 'label'
    >;
};

export interface ICommonCurrencyValueTesterComponentModalProps {
    numberInputProps?: INumberInputModalType;
    selectProps?: ISelectModalType;
}

export interface IModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose' | 'payloadData'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: ICommonCurrencyValueTesterComponentModalProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: Partial<IQueryFormValues>) => Promise<void> | void;
    /**
     * Allows the modal to receive data from outside to determine which service use.
     *
     */
    serviceType?: `${RegionEnum}`;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}
