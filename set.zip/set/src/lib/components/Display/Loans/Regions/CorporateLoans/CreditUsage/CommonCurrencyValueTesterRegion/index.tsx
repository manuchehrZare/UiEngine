import type { FieldValues } from 'seker-ui';
import type { CommonCurrencyValueTesterProps } from './type';
import { RegionEnum } from './type';
import CommonCurrencyValueTesterDisplayModal from './DisplayModal';
import CommonCurrencyValueTesterDisplayRegion from './DisplayRegion';
import type { JSX } from 'react';

const CommonCurrencyValueTesterRegion = <T extends FieldValues>(
    props: CommonCurrencyValueTesterProps<T>,
): JSX.Element => {
    const priceType = props.serviceType ? props.serviceType : RegionEnum.EveluationBuyPrice;

    if (props.displayType === 'Modal') {
        return (
            <CommonCurrencyValueTesterDisplayModal
                show={props.show}
                onClose={props.onClose}
                componentProps={props.componentProps}
                serviceType={priceType}
                onReturnData={props.onReturnData}
                formData={props.formData}
            />
        );
    }

    return (
        <CommonCurrencyValueTesterDisplayRegion
            componentProps={props.componentProps}
            formProps={props.formProps}
            serviceType={priceType}
        />
    );
};

export default CommonCurrencyValueTesterRegion;
