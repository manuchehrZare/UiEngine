import type { FieldValues } from 'seker-ui';
import type { IModalProps } from './DisplayModal/type';
import type { IRegionProps } from './DisplayRegion/type';

export enum RegionEnum {
    TCMBBuyPrice = '0',
    TCMBEvaluationPrice = '1',
    EveluationBuyPrice = '2',
    COMPUBANKSellPrice = '3',
    COMPUBANKBuyPrice = '4',
}

export interface IQueryFormValues {
    currencyType: string;
    exchange?: number;
}

interface IRegionContentProps<T extends FieldValues> extends IRegionProps<T> {
    displayType: 'Region';
}

export interface IModalContentProps extends IModalProps {
    displayType: 'Modal';
}

export type CommonCurrencyValueTesterProps<T extends FieldValues> = IModalContentProps | IRegionContentProps<T>;
