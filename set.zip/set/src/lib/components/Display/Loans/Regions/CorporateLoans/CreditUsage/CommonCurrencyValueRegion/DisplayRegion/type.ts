import type { FieldValues, HelperFormProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IQueryFormValues, RegionEnum } from '../type';

type INumberInputType<T> = Record<
    keyof Pick<IQueryFormValues, 'exchange'>,
    Pick<INumberInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type ISelectType<T> = {
    [Property in keyof Pick<IQueryFormValues, 'currencyType'>]?: Pick<
        ISelectProps<IQueryFormValues[Property]>,
        'disabled' | 'readOnly' | 'label'
    > & { name: keyof T };
};

export interface ICommonCurrencyValueComponentRegionProps<T> {
    numberInputProps?: INumberInputType<T>;
    selectProps?: ISelectType<T>;
}

export interface IRegionProps<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'setValue' | 'resetField' | 'reset' | 'getValues'> {
    componentProps: ICommonCurrencyValueComponentRegionProps<T>;
    serviceType?: `${RegionEnum}`;
}
