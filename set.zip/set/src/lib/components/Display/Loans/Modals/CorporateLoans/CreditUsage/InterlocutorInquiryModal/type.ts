import type {
    FieldValues,
    HelperFormProps,
    IButtonProps,
    IInputProps,
    INumberInputProps,
    ISelectProps,
} from 'seker-ui';
import type {
    IGetCrdUtilityDraweeRequest,
    IGetCrdUtilityDraweeResponse,
    IHelperModalProps,
    SETModalsCommonProps,
} from '../../../../../../..';

type ISelectType = {
    [Property in `${keyof Pick<IInterlocutorInquiryModalFormValues, 'mainGroupOid' | 'subGroupOid'>}`]?: Pick<
        ISelectProps<IInterlocutorInquiryModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<IInterlocutorInquiryModalFormValues, 'draweeName'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type INumberInputType = Partial<
    Record<
        `${keyof Pick<IInterlocutorInquiryModalFormValues, 'tc' | 'vkn'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IInterlocutorInquiryModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface IInterlocutorInquiryModalFormValues {
    draweeName: string;
    mainGroupOid: string;
    subGroupOid: string;
    tc: number | null;
    vkn: number | null;
}

export interface IInterlocutorInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IInterlocutorInquiryModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IInterlocutorInquiryModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IGetCrdUtilityDraweeResponse) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IGetCrdUtilityDraweeRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IInterlocutorDataGridProps {
    closeModal: () => void;
    data: IGetCrdUtilityDraweeResponse[];
    onReturnData?: (data: IGetCrdUtilityDraweeResponse) => void;
}

export interface IInterlocutorInquiryProps<T extends FieldValues> extends HelperFormProps<T, 'control' | 'setValue'> {
    componentProps?: IInterlocutorInquiryModalComponentProps;
}
