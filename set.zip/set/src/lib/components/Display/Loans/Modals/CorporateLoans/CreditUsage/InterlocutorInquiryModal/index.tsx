/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import InquiryCriterias from './InquiryCriterias';
import InterlocutorDataGrid from './InterlocutorDataGrid';
import type { IInterlocutorInquiryModalProps, IInterlocutorInquiryModalFormValues } from './type';
import type { IGetCrdUtilityDraweeRequest, IGetCrdUtilityDraweeResponse } from '../../../../../../..';
import { HttpStatusCodeEnum, constants, useAxios, useTranslation } from '../../../../../../..';
import { isNull } from 'lodash';

const InterlocutorInquiryModal: FC<IInterlocutorInquiryModalProps> = ({
    show,
    onClose,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    formData,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const [interlocutorDataGridData, setInterlocutorDataGridData] = useState<IGetCrdUtilityDraweeResponse[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [mainGroupOidMustEnter, setMainGroupOidMustEnter] = useState<boolean>();

    const { control, setValue, reset, handleSubmit, getValues } = useForm<IInterlocutorInquiryModalFormValues>({
        defaultValues: {
            draweeName: '',
            mainGroupOid: '',
            subGroupOid: '',
            tc: null,
            vkn: null,
        },
        validationSchema: {
            draweeName: validation.string(t(locale.labels.interlocutorNameTitle), {
                required: mainGroupOidMustEnter,
                messageFormatter: {
                    required: () => t(locale.validations.enterAddresseeNameTitle),
                },
            }),
        },
    });
    const [mainGroupOidVal, tCVal, vKNVal] = useWatch({ control, fieldName: ['mainGroupOid', 'tc', 'vkn'] });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const resetModal = () => {
        reset();
        setInterlocutorDataGridData([]);
    };

    const closeModal = () => {
        onClose?.(false);
        setModalShow(false);
        resetModal();
    };
    const handleOnReturnData = (data: IGetCrdUtilityDraweeResponse) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IInterlocutorInquiryModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { draweeName: modalViewerInputWatch && modalViewerInputWatch }),
        ...formData,
    });

    const [{ error: getAsUtilityDraweeError }, getAsUtilityDraweeCall] = useAxios<
        IGetCrdUtilityDraweeResponse[],
        IGetCrdUtilityDraweeRequest
    >(constants.api.endpoints.corporateLoans.creditUsage.utility.crdUtilityDrawee.getCrdUtilityDrawee.POST, {
        manual: true,
    });

    const onSubmit = async (formValues: IInterlocutorInquiryModalFormValues) => {
        if (!isNull(formValues?.tc) && !isNull(formValues?.vkn)) {
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.makeAnInquiryWithYourTcOrTaxIdentityNumber),
            });
        } else {
            const response = await getAsUtilityDraweeCall({
                data: {
                    ...formValues,
                    draweeName: formValues?.draweeName?.toLocaleUpperCase('tr') || '',
                    draweeOid: payloadData?.draweeOid || '',
                    vkn: formValues.vkn ? String(formValues?.vkn) : '',
                    tc: formValues.tc ? String(formValues?.tc) : '',
                },
            });

            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.length > 0) {
                    setInterlocutorDataGridData(responseData);
                } else {
                    setInterlocutorDataGridData([]);
                    message({
                        variant: MessageTypeEnum.info,
                        message: t(locale.notifications.noSearchedData),
                    });
                }
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            setModalShow(false);
            const response = await getAsUtilityDraweeCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    vkn: formData?.vkn ? String(formData?.vkn) : '',
                    tc: formData?.tc ? String(formData?.tc) : '',
                    draweeOid: payloadData?.draweeOid || '',
                    draweeName: formData?.draweeName?.toLocaleUpperCase('tr') || '',
                },
            });
            if ((response.status = HttpStatusCodeEnum.Ok)) {
                const responseData = response?.data;
                if (responseData) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        setModalShow(true);
                        setInterlocutorDataGridData(responseData);
                    }
                } else {
                    setModalShow(true);
                    setInterlocutorDataGridData([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else setModalShow(true);
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (getAsUtilityDraweeError && eventOwnerEl === 'input') {
            setModalShow(false);
            onClose?.(false);
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.interlocutorInquiry),
                }),
            });
        }
    }, [getAsUtilityDraweeError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        setMainGroupOidMustEnter(!mainGroupOidVal?.length && isNull(tCVal) && isNull(vKNVal));
    }, [mainGroupOidVal, tCVal, vKNVal]);

    return (
        <Modal maxWidth="md" show={modalShow} onClose={() => show && modalShow && closeModal()}>
            <ModalTitle>{t(locale.contentTitles.interlocutorInquiry)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.inquiryCriterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <InquiryCriterias formProps={{ control, setValue }} />
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm="auto" md={12} ml={{ sm: 'auto' }}>
                                            <Button
                                                onClick={handleSubmit(onSubmit)}
                                                text={t(locale.buttons.inquire)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm="auto" md={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                onClick={resetModal}
                                                variant="outlined"
                                                fullWidth
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={300}>
                                    <InterlocutorDataGrid
                                        data={interlocutorDataGridData}
                                        onReturnData={onReturnData}
                                        closeModal={closeModal}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default InterlocutorInquiryModal;
