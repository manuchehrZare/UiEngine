/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect } from 'react';
import { Grid, GridItem, Input, Select, useIsFirstRender, useWatch } from 'seker-ui';
import type {
    IIProductDisbursementFeaturesModalInquiryCriteriasProps,
    IProductDisbursementFeaturesModalFormValues,
} from '../type';
import { ListTypeEnum } from '../type';
import {
    GenericSetCallerEnum,
    ReferenceDataEnum,
    constants,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../../../utils';
import { useAxios } from '../../../../../../../..';
import type {
    IGetCcsLimAsProductMainGroupsListRequest,
    IGetCcsLimAsProductMainGroupsListResponse,
} from '../../../../../../../../utils/types/api/models/Loans/CCS/allotment/ccsLimAsProductMainGroupsList/type';
import type {
    IGetAsProdProductListForComboRequest,
    IGetAsProdProductListForComboResponse,
} from '../../../../../../../../utils/types/api/models/Loans/CCS/allotment/productGroupListForCombo/type';
import type {
    IGetAsProductProductGroupListForComboRequest,
    IGetAsProductProductGroupListForComboResponse,
} from '../../../../../../../../utils/types/api/models/Loans/CCS/allotment/productProductGroupListForCombo/type';

const InquiryCriterias: FC<
    IIProductDisbursementFeaturesModalInquiryCriteriasProps<IProductDisbursementFeaturesModalFormValues>
> = ({ show, formProps: { control, setValue }, referenceDatas, componentProps }) => {
    const { t, locale } = useTranslation();
    const isFirstRender = useIsFirstRender();

    const [productMainGroupVal, productGroupVal] = useWatch({
        control,
        fieldName: ['productMainGroupOid', 'productGroupOid'],
    });

    const [{ data: getCcsLimAsProductMainGroupsData }] = useAxios<
        IGetCcsLimAsProductMainGroupsListResponse,
        IGetCcsLimAsProductMainGroupsListRequest
    >(
        {
            ...getGenericSetCaller(GenericSetCallerEnum.CCS_LIM_PRODUCT_MAIN_GROUPS_LIST),
            data: {
                listType: ListTypeEnum.OidName,
            },
        },
        { manual: false },
    );

    const [{ data: getAsProductGroupListComboData }, getAsProductGroupListComboCall] = useAxios<
        IGetAsProductProductGroupListForComboResponse,
        IGetAsProductProductGroupListForComboRequest
    >(
        {
            ...getGenericSetCaller(GenericSetCallerEnum.PRODUCT_PRODUCT_GROUP_LIST_FOR_COMBO),
            data: {
                listType: ListTypeEnum.OidName,
                productMainGroupOid: productMainGroupVal,
            },
        },
        { manual: true },
    );

    const [{ data: getAsProdProductListComboData }, getAsProdProductListComboCall] = useAxios<
        IGetAsProdProductListForComboResponse,
        IGetAsProdProductListForComboRequest
    >(
        {
            ...getGenericSetCaller(GenericSetCallerEnum.PROD_PRODUCT_LIST_FOR_COMBO),
            data: {
                listType: '0',
                productMainGroupOid: productMainGroupVal,
                productGroupOid: productGroupVal,
            },
        },
        { manual: true },
    );

    useEffect(() => {
        if (show && !isFirstRender) {
            getAsProductGroupListComboCall();
        }
    }, [productMainGroupVal]);

    useEffect(() => {
        if (show && !isFirstRender) {
            getAsProdProductListComboCall();
        }
    }, [productGroupVal]);

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 3,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Select
                    label={t(locale.labels.productMainGroup)}
                    name="productMainGroupOid"
                    control={control}
                    setValue={setValue}
                    options={{
                        data: getCcsLimAsProductMainGroupsData?.productMainGroupList || [],
                        displayField: 1,
                        displayValue: 0,
                    }}
                    onChange={() => {
                        setValue('productGroupOid', '');
                    }}
                    {...componentProps?.selectProps?.productMainGroupOid}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    label={t(locale.labels.productGroup)}
                    name="productGroupOid"
                    control={control}
                    setValue={setValue}
                    options={{
                        data: getAsProductGroupListComboData?.productGroupList || [],
                        displayField: 1,
                        displayValue: 0,
                    }}
                    onChange={() => {
                        setValue('productOid', '');
                    }}
                    {...componentProps?.selectProps?.productGroupOid}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    label={t(locale.labels.product)}
                    name="productOid"
                    control={control}
                    setValue={setValue}
                    options={{
                        data: getAsProdProductListComboData?.productList || [],
                        displayField: 1,
                        displayValue: 0,
                    }}
                    {...componentProps?.selectProps?.productOid}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    label={t(locale.labels.disbursementType)}
                    name="usageType"
                    control={control}
                    setValue={setValue}
                    options={{
                        data:
                            referenceDatas?.resultList?.find(
                                (item) => item?.name === ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE,
                            )?.items || [],
                        displayField: 'value',
                        displayValue: 'key',
                        renderDisplayField: (params) => `${params.key} - ${params.value}`,
                        renderDisplayList: (params) => `${params.key} - ${params.value}`,
                    }}
                    {...componentProps?.selectProps?.usageType}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    label={t(locale.labels.disbursementProduct)}
                    name="templeteName"
                    control={control}
                    readOnly
                    {...componentProps?.inputProps?.templeteName}
                />
            </GridItem>
        </Grid>
    );
};

export default InquiryCriterias;
