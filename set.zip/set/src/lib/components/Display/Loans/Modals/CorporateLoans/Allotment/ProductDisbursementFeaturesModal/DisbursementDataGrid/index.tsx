import { isEqual } from 'lodash';
import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem, NumberFormat } from 'seker-ui';
import type { IIProductDisbursementFeaturesModaDataGridProps } from '../type';
import { ListTypeEnum } from '../type';
import { ReferenceDataEnum, useTranslation } from '../../../../../../../../utils';
import type { IProductUsageTempletListCoreData } from '../../../../../../../../utils/types/api/models/Loans/CCS/allotment/ccsLimProductUsageTempletForCredit/type';

const DisbursementDataGrid: FC<IIProductDisbursementFeaturesModaDataGridProps> = ({
    data,
    onReturnData,
    referenceDatas,
}) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'detailName',
            headerName: t(locale.contentTitles.disbursementProduct),
            headerAlign: 'center',
            minWidth: 200,
        },
        {
            field: 'productProperties',
            headerName: t(locale.contentTitles.productFeature),
            headerAlign: 'center',
            minWidth: 120,
            align: 'center',
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_PRODUCT_PROPERTIES)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'usageType',
            headerName: t(locale.contentTitles.disbursementType),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'maturityStart',
            headerName: t(locale.contentTitles.minTerm),
            headerAlign: 'center',
            minWidth: 110,
            align: 'center',
        },
        {
            field: 'maturityEnd',
            headerName: t(locale.contentTitles.maxTerm),
            headerAlign: 'center',
            minWidth: 110,
            align: 'center',
        },
        {
            field: 'maturityPeriodType',
            headerName: t(locale.contentTitles.termPeriod),
            headerAlign: 'center',
            minWidth: 130,
            align: 'center',
            valueFormatter: () => '',
        },
        {
            field: 'amountMin',
            headerName: t(locale.contentTitles.minAmount),
            headerAlign: 'center',
            minWidth: 130,
            align: 'right',
            renderCell: (params) => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'singleCustProductLimit',
            headerName: t(locale.contentTitles.maxAmount),
            headerAlign: 'center',
            minWidth: 150,
            align: 'right',
            renderCell: (params) => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'amountRangeCurrCode',
            headerName: t(locale.contentTitles.amountRange),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
        },
        {
            field: 'crfValidityDuration',
            headerName: t(locale.contentTitles.ktfValidityPeriodDay),
            headerAlign: 'center',
            minWidth: 180,
            align: 'center',
        },
        {
            field: 'interestType',
            headerName: t(locale.contentTitles.interestType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_CRD_INT_INTEREST_TYPE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'indexType',
            headerName: t(locale.contentTitles.interestTable),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_CRD_INT_INDEX_TYPE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'indexOid',
            headerName: t(locale.contentTitles.indexPool),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_INVESTCORE_INVCMN_INDEX_LIST)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'spread',
            headerName: t(locale.contentTitles.interestDifference),
            headerAlign: 'center',
            minWidth: 130,
            align: 'right',
            renderCell: (params) => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'isValueDate',
            headerName: t(locale.contentTitles.isFixed),
            headerAlign: 'center',
            minWidth: 130,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === ListTypeEnum.CodeName) return true;
                if (value === ListTypeEnum.OidName) return false;
                return value;
            },
        },
        {
            field: 'priceMaturityStart',
            headerName: t(locale.contentTitles.minPricingTerm),
            headerAlign: 'center',
            align: 'center',
            minWidth: 160,
        },
        {
            field: 'priceMaturityEnd',
            headerName: t(locale.contentTitles.maxPricingTerm),
            headerAlign: 'center',
            align: 'center',
            minWidth: 160,
        },
        {
            field: 'accrualDatePeriod',
            headerName: t(locale.contentTitles.interestAccrualPeriod),
            headerAlign: 'center',
            align: 'center',
            minWidth: 200,
        },
        {
            field: 'accrualDatePeriodType',
            headerName: t(locale.contentTitles.interestAccrualPeriodType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 200,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_PERIOD_TYPE_ACCRUAL)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'variablePeriod',
            headerName: t(locale.contentTitles.variablePeriod),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'variablePeriodType',
            headerName: t(locale.contentTitles.variablePeriodType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_PERIOD_TYPE_VARIABLE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'paymentType',
            headerName: t(locale.contentTitles.paymentType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_CRD_CRD_INSTALLMENT_TYPE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'installmentCountStart',
            headerName: t(locale.contentTitles.minInstallmentCount),
            headerAlign: 'center',
            align: 'center',
            minWidth: 140,
        },
        {
            field: 'installmentCountEnd',
            headerName: t(locale.contentTitles.maxInstallmentNo),
            headerAlign: 'center',
            minWidth: 140,
            align: 'center',
        },
        {
            field: 'installmentPeriodStart',
            headerName: t(locale.contentTitles.minInstallmentPeriod),
            headerAlign: 'center',
            minWidth: 140,
            align: 'center',
        },
        {
            field: 'installmentPeriodEnd',
            headerName: t(locale.contentTitles.maxInstallmentPeriod),
            headerAlign: 'center',
            align: 'center',
            minWidth: 140,
        },
        {
            field: 'installmentPeriodType',
            headerName: t(locale.contentTitles.installmentPeriod),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_NPERIOD_TYPE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'nperiodStart',
            headerName: t(locale.contentTitles.minNGracePeriod),
            headerAlign: 'center',
            align: 'center',
            minWidth: 160,
        },
        {
            field: 'nperiodEnd',
            headerName: t(locale.contentTitles.maxNGracePeriod),
            headerAlign: 'center',
            align: 'center',
            minWidth: 160,
        },
        {
            field: 'nperiodType',
            headerName: t(locale.contentTitles.nGracePeriodType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 170,
            valueFormatter: (value) => {
                return value
                    ? referenceDatas?.resultList
                          ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_PERIOD_TYPE)
                          ?.items?.find((item) => isEqual(item.key, String(value)))?.value
                    : '';
            },
        },
        {
            field: 'mainGroupCode',
            headerName: t(locale.contentTitles.productMainGroup),
            headerAlign: 'center',
            align: 'center',
            minWidth: 140,
        },
        {
            field: 'groupCode',
            headerName: t(locale.contentTitles.productGroup),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
        },
        {
            field: 'productCode',
            headerName: t(locale.contentTitles.product),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
        },
        {
            field: 'cashNonCash',
            headerName: t(locale.contentTitles.productType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
        },
        {
            field: 'usageTempletCode',
            headerName: t(locale.contentTitles.guaranteeCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 140,
        },
        {
            field: 'valueDateInst',
            headerName: t(locale.contentTitles.fixedInstallment),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
        },
        {
            field: 'pricingModel',
            headerName: t(locale.contentTitles.includedInProductPricingModel),
            headerAlign: 'center',
            minWidth: 200,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === ListTypeEnum.CodeName) return true;
                if (value === ListTypeEnum.OidName) return false;
                return value;
            },
        },
    ];

    return (
        <Grid>
            <GridItem pt={0.5} height={370}>
                <DataGrid
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={({ row }: { row: IProductUsageTempletListCoreData }) => {
                        onReturnData?.(row);
                    }}
                />
            </GridItem>
        </Grid>
    );
};

export default DisbursementDataGrid;
