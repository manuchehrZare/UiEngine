import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem, useWatch } from 'seker-ui';
import type { IProductDataGridProps, IProductSelectionModalFormValues } from '../type';
import { ProductTypeEnum } from '../type';
import type { IGetCcsAllGeneralProductListCoreData } from '../../../../../../../..';
import { ReferenceDataEnum, useTranslation } from '../../../../../../../..';
import { isEqual } from 'lodash';

const ProductDataGrid: FC<IProductDataGridProps<IProductSelectionModalFormValues>> = ({
    formProps: { control },
    data,
    onReturnData,
    closeModal,
    referenceDatas,
}) => {
    const { t, locale } = useTranslation();

    const ProductTypeData = [
        {
            key: t(locale.labels.cash_2),
            value: ProductTypeEnum.Cash,
        },
        {
            key: t(locale.labels.nonCash_2),
            value: ProductTypeEnum.NonCash,
        },
    ];

    const productMainGroupVal = useWatch({
        control,
        fieldName: 'mainGroupCode',
    });

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'productCode',
            headerName: t(locale.contentTitles.productNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 110,
            flex: 1,
        },
        {
            field: 'productName',
            headerName: t(locale.contentTitles.productName),
            headerAlign: 'center',
            minWidth: 250,
            flex: 1,
        },
        {
            field: 'cashNonCash',
            headerName: t(locale.contentTitles.productType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
            flex: 1,
            valueFormatter: (value) => {
                const productTypeCash = ProductTypeData?.find((item) => isEqual(item.value, value));
                return productTypeCash ? productTypeCash.key : '';
            },
        },
        {
            field: 'mainGroupCode',
            headerName: t(locale.contentTitles.mainGroupCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            flex: 1,
        },
        {
            field: 'mainGrpCode',
            headerName: t(locale.contentTitles.mainGroupName),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            flex: 1,
            valueOptions: () =>
                referenceDatas?.resultList?.find(
                    (item) => item?.name === ReferenceDataEnum.PRM_PROD_PRODUCT_MAIN_GROUPS_WITH_CODE,
                )?.items || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => value?.value,
            type: 'singleSelect',
        },
        {
            field: 'groupCode',
            headerName: t(locale.contentTitles.groupCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
            flex: 1,
        },
        {
            field: 'grpCode',
            headerName: t(locale.contentTitles.groupName),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
            valueOptions: () =>
                referenceDatas?.resultList
                    ?.find((item) => item?.name === ReferenceDataEnum.PRM_PROD_PRODUCT_GROUPS_WITH_CODE)
                    ?.items?.filter((value) => value.filter === productMainGroupVal) || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => value?.value,
            type: 'singleSelect',
        },
    ];

    return (
        <Grid>
            <GridItem height={350}>
                <DataGrid
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={({ row }: { row: IGetCcsAllGeneralProductListCoreData }) => {
                        onReturnData?.(row);
                        closeModal();
                    }}
                />
            </GridItem>
        </Grid>
    );
};

export default ProductDataGrid;
