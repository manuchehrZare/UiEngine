import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import type { IInterlocutorDataGridProps } from '../type';
import type { IGetCrdUtilityDraweeResponse } from '../../../../../../../..';
import { useTranslation } from '../../../../../../../..';

const InterlocutorDataGrid: FC<IInterlocutorDataGridProps> = ({ closeModal, data, onReturnData }) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },

        {
            field: 'mainGroup',
            headerName: t(locale.contentTitles.mainGroupName),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
        {
            field: 'subGroup',
            headerName: t(locale.contentTitles.subGroupName),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
        {
            field: 'name',
            headerName: t(locale.contentTitles.interlocutorNameTitle),
            headerAlign: 'center',
            minWidth: 260,
            flex: 1,
        },
        {
            field: 'tcId',
            headerName: t(locale.contentTitles.tcIdNo2),
            headerAlign: 'center',
            minWidth: 180,
            align: 'center',
            flex: 1,
        },
        {
            field: 'taxNo',
            headerName: t(locale.contentTitles.taxIdNo2),
            headerAlign: 'center',
            minWidth: 180,
            flex: 1,
            align: 'center',
        },
        {
            field: 'oid',
        },
    ];

    return (
        <DataGrid
            columns={columns}
            hiddenColumns={['oid']}
            rows={data || []}
            onRowDoubleClick={({ row }: { row: IGetCrdUtilityDraweeResponse }) => {
                onReturnData?.(row);
                closeModal();
            }}
        />
    );
};

export default InterlocutorDataGrid;
