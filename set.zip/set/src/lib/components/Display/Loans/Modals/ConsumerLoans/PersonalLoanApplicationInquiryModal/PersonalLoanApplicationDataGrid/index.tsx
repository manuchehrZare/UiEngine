import type { FC, JSX } from 'react';
import type { IPersonalLoanApplicationDataGridProps } from '../type';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import { ReferenceDataEnum, useTranslation } from '../../../../../../../utils';

const PersonalLoanApplicationDataGrid: FC<IPersonalLoanApplicationDataGridProps> = ({
    data,
    closeModal,
    onReturnData,
    referenceDatas,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'customerNo',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            minWidth: 120,
            align: 'center',
            flex: 1,
        },
        {
            field: 'customerTitle',
            headerName: t(locale.contentTitles.customerTitle),
            headerAlign: 'center',
            minWidth: 150,
            flex: 1,
        },
        {
            field: 'applicationNo',
            headerName: t(locale.contentTitles.applicationNumber),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
        },
        {
            field: 'statusCode',
            headerName: t(locale.contentTitles.statusCode),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
            valueOptions: () =>
                referenceDatas?.resultList?.find(
                    (item: any) => item?.name === ReferenceDataEnum.PRM_CONS_APPLICATION_STATUS_CODES,
                )?.items || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => value?.value,
            type: 'singleSelect',
        },
        {
            field: 'branchCode',
            headerName: t(locale.contentTitles.branchCode),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
            valueOptions: () =>
                referenceDatas?.resultList?.find(
                    (item: any) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                )?.items || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => `${value?.key} - ${value?.value}`,
            type: 'singleSelect',
        },
        {
            field: 'customerType',
            headerName: t(locale.contentTitles.customerType),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
            valueOptions: () =>
                referenceDatas?.resultList?.find((item: any) => item?.name === ReferenceDataEnum.PRM_CUST_CUSTTYPE)
                    ?.items || [],
            getOptionValue: (value: any) => Number(value?.key),
            getOptionLabel: (value: any) => value?.value,
            type: 'singleSelect',
        },
        {
            field: 'productTypeCode',
            headerName: t(locale.contentTitles.loanType),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
            valueOptions: () =>
                referenceDatas?.resultList?.find(
                    (item: any) => item?.name === ReferenceDataEnum.PRM_CONS_PRODUCT_MAIN_GROUP_DEF,
                )?.items || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => `${value?.key} - ${value?.value}`,
            type: 'singleSelect',
        },
        {
            field: 'productGroupCode',
            headerName: t(locale.contentTitles.productGroupCode),
            headerAlign: 'center',
            minWidth: 200,
            align: 'center',
            flex: 1,
        },
        {
            field: 'productGroupName',
            headerName: t(locale.contentTitles.productGroupName),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
        {
            field: 'productCode',
            headerName: t(locale.contentTitles.loanProduct),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
        },
        {
            field: 'productName',
            headerName: t(locale.contentTitles.loanProductName),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            minWidth: 120,
            align: 'center',
            flex: 1,
        },
        {
            field: 'owner',
            headerName: t(locale.contentTitles.ownerNumber),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            flex: 1,
        },
        {
            field: 'ownerName',
            headerName: t(locale.contentTitles.ownerNameSurname),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
    ];

    return (
        <DataGrid
            rows={data}
            columns={columns}
            selectionOnClickable
            disableMultipleRowSelection
            onRowDoubleClick={(params) => {
                onReturnData?.(params?.row);
                closeModal();
            }}
        />
    );
};

export default PersonalLoanApplicationDataGrid;
