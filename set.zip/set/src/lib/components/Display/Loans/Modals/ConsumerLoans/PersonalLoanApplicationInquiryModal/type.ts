import type { IButtonProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, ReferenceDataResponse, SETModalsCommonProps } from '../../../../../../utils';
import type {
    IConsApplicationPopupListRequest,
    ICoreData,
} from '../../../../../../utils/types/api/models/Loans/ConsumerLoans/consApplicationPopupList/type';

export interface IPersonalLoanApplicationInquiryModalQueryFormValues {
    applicationNo: string;
    branchCode: string;
    channelCode: string;
    currencyCode: string;
    customerCode: string;
    malikCustCode: string;
    productCode: string;
    productGroupCode: string;
    productMainGroupCode: string;
    statusCode: string;
}

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

type NumberInputType = Partial<
    Record<
        `${keyof Pick<
            IPersonalLoanApplicationInquiryModalQueryFormValues,
            'customerCode' | 'malikCustCode' | 'applicationNo'
        >}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

type SelectType = {
    [Property in `${keyof Pick<
        IPersonalLoanApplicationInquiryModalQueryFormValues,
        | 'branchCode'
        | 'channelCode'
        | 'currencyCode'
        | 'productCode'
        | 'productGroupCode'
        | 'productMainGroupCode'
        | 'statusCode'
    >}`]?: Pick<ISelectProps<IPersonalLoanApplicationInquiryModalQueryFormValues[Property]>, 'disabled' | 'readOnly'>;
};

export interface IPersonalLoanApplicationInquiryModalComponentProps {
    buttonProps?: IButtonComponentProps;
    numberInputProps?: NumberInputType;
    selectProps?: SelectType;
}

export interface IPersonalLoanApplicationInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IPersonalLoanApplicationInquiryModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IPersonalLoanApplicationInquiryModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IConsApplicationPopupListRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IPersonalLoanApplicationDataGridProps
    extends Pick<IPersonalLoanApplicationInquiryModalProps, 'onReturnData'> {
    closeModal: () => void;
    data: ICoreData[];
    referenceDatas?: ReferenceDataResponse;
}

export enum PersonalLoanApplicationInquiryModalQueryFormDefaultValues {
    PRODUCT_MAIN_GROUP_CODE = '02',
}
