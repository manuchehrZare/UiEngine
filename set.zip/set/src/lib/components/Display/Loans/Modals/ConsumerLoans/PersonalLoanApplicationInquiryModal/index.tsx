/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type {
    IPersonalLoanApplicationInquiryModalProps,
    IPersonalLoanApplicationInquiryModalQueryFormValues,
} from './type';
import { PersonalLoanApplicationInquiryModalQueryFormDefaultValues } from './type';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    NumberInput,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
} from 'seker-ui';
import { useAxios } from '../../../../../../hooks/useAxios';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    ReferenceDataEnum,
    generateReferenceDataRequestList,
    constants,
    useTranslation,
    GenericSetCallerEnum,
    getGenericSetCaller,
    HttpStatusCodeEnum,
    SETModalsEnum,
} from '../../../../../../utils';
import type {
    IConsApplicationPopupListRequest,
    IConsApplicationPopupListResponse,
    ICoreData,
} from '../../../../../../utils/types/api/models/Loans/ConsumerLoans/consApplicationPopupList/type';
import PersonalLoanApplicationDataGrid from './PersonalLoanApplicationDataGrid';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import ModalViewer from '../../../../../Others/ModalViewer';
import type {
    IConsAdminListProductsRequest,
    IConsAdminListProductsResponse,
} from '../../../../../../utils/types/api/models/Loans/ConsumerLoans/consAdminListProducts/type';

const PersonalLoanApplicationInquiryModal: FC<IPersonalLoanApplicationInquiryModalProps> = ({
    show,
    onClose,
    eventOwnerEl,
    inputProps,
    formData,
    payloadData,
    onReturnData,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [personalLoanApplicationDataGrid, setPersonalLoanApplicationDataGrid] = useState<ICoreData[]>([]);

    const { control, reset, getValues, handleSubmit, setValue } =
        useForm<IPersonalLoanApplicationInquiryModalQueryFormValues>({
            defaultValues: {
                applicationNo: '',
                branchCode: '',
                channelCode: '',
                currencyCode: '',
                customerCode: '',
                malikCustCode: '',
                productCode: '',
                productGroupCode: '',
                productMainGroupCode: PersonalLoanApplicationInquiryModalQueryFormDefaultValues.PRODUCT_MAIN_GROUP_CODE,
                statusCode: '',
            },
        });

    const [customerCodeVal, malikCustCodeVal, productMainGroupCodeVal, productGroupCodeVal] = useWatch({
        control,
        fieldName: ['customerCode', 'malikCustCode', 'productMainGroupCode', 'productGroupCode'],
    });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const resetModal = () => {
        reset();
    };

    const closeModal = () => {
        onClose?.(false);
        resetModal();
        setModalShow(false);
        setPersonalLoanApplicationDataGrid([]);
    };

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IPersonalLoanApplicationInquiryModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name && { applicationNo: modalViewerInputWatch && modalViewerInputWatch }),
        ...formData,
    });

    const [{ data: referenceDatas, loading: referenceDatasLoading, error: referenceDatasError }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_CONS_APPLICATION_STATUS_CODES,
                            ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_EPROC_CHANNELS_WITH_CODE,
                            ReferenceDataEnum.PRM_CONS_PRODUCT_MAIN_GROUP_DEF,
                            ReferenceDataEnum.PRM_PROD_PRODUCT_GROUPS_WITH_CODE,
                            ReferenceDataEnum.PRM_CONS_CURRENCY_CODE_FILTERED,
                            ReferenceDataEnum.PRM_CUST_CUSTTYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: consApplicationPopupListError }, consApplicationPopupListCall] = useAxios<
        IConsApplicationPopupListResponse,
        IConsApplicationPopupListRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CONS_APPLICATION_POPUP_LIST), { manual: true });

    const [{ data: consAdminListProductsData }, consAdminListProductsCall] = useAxios<
        IConsAdminListProductsResponse,
        IConsAdminListProductsRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CONS_ADMIN_LIST_PRODUCTS), { manual: true });

    const onSubmit = async (formValues: IPersonalLoanApplicationInquiryModalQueryFormValues) => {
        const response = await consApplicationPopupListCall({
            data: { ...formValues, isKdsException: '', ignoredStatusCode: '', statusCodeList: '' },
        });

        if ((response.status = HttpStatusCodeEnum.Ok)) {
            const responseData = response?.data?.coreData;
            if (responseData) {
                setPersonalLoanApplicationDataGrid(responseData);
            } else {
                setPersonalLoanApplicationDataGrid([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            setModalShow(false);
            const response = await consApplicationPopupListCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    isKdsException: '',
                    ignoredStatusCode: '',
                    statusCodeList: '',
                },
            });
            if (response?.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length && formData?.applicationNo) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        setModalShow(true);
                        setPersonalLoanApplicationDataGrid(responseData);
                    }
                } else {
                    setModalShow(true);
                    setPersonalLoanApplicationDataGrid([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (consApplicationPopupListError) {
            show && !modalShow && closeModal();
        }
    }, [consApplicationPopupListError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.personalLoanApplicationInquiry),
                }),
            });
        }
    }, [referenceDatasError]);

    useEffect(() => {
        productMainGroupCodeVal &&
            productGroupCodeVal &&
            consAdminListProductsCall({
                data: {
                    productGroupOid: productGroupCodeVal,
                    loansType: productMainGroupCodeVal,
                },
            });
    }, [productGroupCodeVal]);

    return (
        <Modal maxWidth="lg" show={modalShow} onClose={() => show && modalShow && closeModal()}>
            <ModalTitle>{t(locale.contentTitles.personalLoanApplicationInquiry)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="customerCode"
                                                label={t(locale.labels.customerNumber)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.customerInquiry),
                                                    disabled:
                                                        componentProps?.numberInputProps?.customerCode?.disabled ||
                                                        componentProps?.numberInputProps?.customerCode?.readOnly,
                                                }}
                                                modalProps={{
                                                    formData: {
                                                        custCustCustomerCode: customerCodeVal,
                                                        custCustActive: '1',
                                                    },
                                                    onReturnData: (data) =>
                                                        setValue('customerCode', String(data?.customerCode)),
                                                }}
                                                allowLeadingZeros
                                                {...componentProps?.numberInputProps?.customerCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="applicationNo"
                                                control={control}
                                                label={t(locale.labels.applicationNumber)}
                                                allowLeadingZeros
                                                {...componentProps?.numberInputProps?.applicationNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="statusCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.statusCode)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_CONS_APPLICATION_STATUS_CODES,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: ({ key, value }) => `${key} - ${value}`,
                                                    renderDisplayList: ({ key, value }) => `${key} - ${value}`,
                                                }}
                                                {...componentProps?.selectProps?.statusCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="branchCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.branchCode)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: ({ key, value }) => `${key} - ${value}`,
                                                    renderDisplayList: ({ key, value }) => `${key} - ${value}`,
                                                }}
                                                {...componentProps?.selectProps?.branchCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="channelCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.channelCode)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_EPROC_CHANNELS_WITH_CODE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: ({ key, value }) => `${key} - ${value}`,
                                                    renderDisplayList: ({ key, value }) => `${key} - ${value}`,
                                                }}
                                                {...componentProps?.selectProps?.channelCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="productMainGroupCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.loanType)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_CONS_PRODUCT_MAIN_GROUP_DEF,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: ({ key, value }) => `${key} - ${value}`,
                                                    renderDisplayList: ({ key, value }) => `${key} - ${value}`,
                                                }}
                                                onChange={() => {
                                                    setValue('productGroupCode', '');
                                                    setValue('productCode', '');
                                                }}
                                                {...componentProps?.selectProps?.productMainGroupCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="productGroupCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.loanProductGroup)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_PROD_PRODUCT_GROUPS_WITH_CODE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: ({ key, value }) => `${key} - ${value}`,
                                                    renderDisplayList: ({ key, value }) => `${key} - ${value}`,
                                                    dataFormatter: (data) =>
                                                        productMainGroupCodeVal
                                                            ? data.filter(
                                                                  (item) => item?.filter === productMainGroupCodeVal,
                                                              )
                                                            : [],
                                                }}
                                                onChange={() => setValue('productCode', '')}
                                                {...componentProps?.selectProps?.productGroupCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="productCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.loanProduct)}
                                                options={{
                                                    data: consAdminListProductsData?.productList || [],
                                                    displayField: '1',
                                                    displayValue: '0',
                                                    renderDisplayField: (params) => `${params[0]} - ${params[1]}`,
                                                    renderDisplayList: (params) => `${params[0]} - ${params[1]}`,
                                                    dataFormatter: (data) =>
                                                        (productMainGroupCodeVal && productGroupCodeVal && data) || [],
                                                }}
                                                {...componentProps?.selectProps?.productCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="currencyCode"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.currencyType)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_CONS_CURRENCY_CODE_FILTERED,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: ({ key, value }) => `${key} - ${value}`,
                                                    renderDisplayList: ({ key, value }) => `${key} - ${value}`,
                                                }}
                                                {...componentProps?.selectProps?.currencyCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="malikCustCode"
                                                label={t(locale.labels.ownerCustomerNumber)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.customerInquiry),
                                                    disabled:
                                                        componentProps?.numberInputProps?.malikCustCode?.disabled ||
                                                        componentProps?.numberInputProps?.malikCustCode?.readOnly,
                                                }}
                                                modalProps={{
                                                    formData: {
                                                        custCustCustomerCode: malikCustCodeVal,
                                                        custCustActive: '1',
                                                    },
                                                    onReturnData: (data) =>
                                                        setValue('malikCustCode', String(data?.customerCode)),
                                                }}
                                                allowLeadingZeros
                                                {...componentProps?.numberInputProps?.malikCustCode}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                fullWidth
                                                onClick={handleSubmit(onSubmit)}
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                variant="outlined"
                                                iconLeft={<CleaningServices />}
                                                fullWidth
                                                onClick={() => resetModal()}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={300}>
                                    <PersonalLoanApplicationDataGrid
                                        data={personalLoanApplicationDataGrid}
                                        closeModal={closeModal}
                                        onReturnData={onReturnData}
                                        referenceDatas={referenceDatas}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default PersonalLoanApplicationInquiryModal;
