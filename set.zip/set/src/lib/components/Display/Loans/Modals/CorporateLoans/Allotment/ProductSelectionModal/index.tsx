/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import {
    Button,
    Grid,
    GridItem,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    validation,
} from 'seker-ui';
import ProductDataGrid from './ProductDataGrid';
import InquiryCriterias from './InquiryCriterias';
import type { IProductSelectionModalProps, IProductSelectionModalFormValues } from './type';
import type {
    IGetCcsAllGeneralProductListCoreData,
    IGetCcsAllGeneralProductListRequest,
    IGetCcsAllGeneralProductListResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
} from '../../../../../../..';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useAxios,
    useTranslation,
    generateReferenceDataRequestList,
    ReferenceDataEnum,
} from '../../../../../../..';

const ProductSelectionModal: FC<IProductSelectionModalProps> = ({
    show,
    onClose,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    formData,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const [productDataGridData, setProductDataGridData] = useState<IGetCcsAllGeneralProductListCoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, setValue, reset, handleSubmit, getValues } = useForm<IProductSelectionModalFormValues>({
        defaultValues: {
            mainGroupCode: '',
            groupCode: '',
            oid: '',
        },
        validationSchema: {
            mainGroupCode: validation.string(t(locale.labels.productMainGroup), { required: true, selectable: true }),
        },
    });

    const [{ data: referenceData, loading: referenceDatasLoading, error: referenceDatasError }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_PROD_PRODUCT_MAIN_GROUPS_WITH_CODE,
                            ReferenceDataEnum.PRM_PROD_PRODUCT_GROUPS_WITH_CODE,
                            ReferenceDataEnum.PRM_CCS_COLLATERAL_TYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: getAsGeneralProductError }, getAsGeneralProductCall] = useAxios<
        IGetCcsAllGeneralProductListResponse,
        IGetCcsAllGeneralProductListRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCS_ALL_GENERAL_PRODUCT_LIST), { manual: true });

    const resetModal = () => {
        reset();
        setProductDataGridData([]);
    };

    const closeModal = () => {
        onClose?.(false);
        setModalShow(false);
        resetModal();
    };

    const handleOnReturnData = (data: IGetCcsAllGeneralProductListCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IProductSelectionModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name && {
                mainGroupCode: formData?.mainGroupCode || '',
            }),
        ...formData,
    });

    const onSubmit = async (formValues: IProductSelectionModalFormValues) => {
        const response = await getAsGeneralProductCall({
            data: formValues,
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            if (response?.data?.coreData?.length) {
                setProductDataGridData(response.data.coreData);
            } else {
                setProductDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            if (formData?.mainGroupCode) {
                const response = await getAsGeneralProductCall({
                    data: {
                        ...getInitFormValues(),
                        ...payloadData,
                        mainGroupCode: formData?.mainGroupCode ? formData.mainGroupCode : '',
                    },
                });
                if (response.status === HttpStatusCodeEnum.Ok) {
                    const responseData = response?.data?.coreData;
                    if (responseData?.length) {
                        setProductDataGridData(responseData);
                        referenceDataCall();
                    } else {
                        referenceDataCall();
                        setProductDataGridData([]);
                        message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                    }
                }
            } else {
                show && closeModal();
                message({ variant: MessageTypeEnum.error, message: t(locale.notifications.productMainGroupRequired) });
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (getAsGeneralProductError) {
            show && !modalShow && closeModal();
        }
    }, [getAsGeneralProductError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceData?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceData]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.productSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.productChoice)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.inquiryCriterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <InquiryCriterias formProps={{ control, setValue, getValues }} show={show} />
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                onClick={handleSubmit(onSubmit)}
                                                text={t(locale.buttons.inquire)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <ProductDataGrid
                                formProps={{ control }}
                                data={productDataGridData}
                                onReturnData={(data) => {
                                    handleOnReturnData(data);
                                    closeModal();
                                }}
                                closeModal={closeModal}
                                referenceDatas={referenceData}
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default ProductSelectionModal;
