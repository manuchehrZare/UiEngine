import type {
    FieldValues,
    HelperFormProps,
    IButtonProps,
    IInputProps,
    INumberInputProps,
    ISelectProps,
} from 'seker-ui';
import type {
    ICoreDataCreditUsageListForPopup,
    ICreditStateCoreData,
    ICreditUsageListForPopupResponse,
    IHelperModalProps,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../../..';
import type { Dispatch, SetStateAction } from 'react';

type IInputType = Partial<
    Record<
        `${keyof Pick<ILoanRequestFormSelectionModalFormValues, 'creditNo' | 'nameTitle' | 'productOid' | 'draweeOid' | 'usagePatternOid'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type INumberInputType = Partial<
    Record<
        `${keyof Pick<ILoanRequestFormSelectionModalFormValues, 'customerCode' | 'minAmount' | 'maxAmount'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;
type ISelectType = {
    [Property in `${keyof Pick<ILoanRequestFormSelectionModalFormValues, 'customerOrgCode' | 'creatorOrgCode' | 'productType' | 'state' | 'usageType'>}`]?: Pick<
        ISelectProps<ILoanRequestFormSelectionModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface ILoanRequestFormSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface ILoanRequestFormSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: ILoanRequestFormSelectionModalComponentProps;
    creditState?: string;
    /**
     * Allows the modal to receive data from outside.
     */
    formData?: Partial<ILoanRequestFormSelectionModalFormValues>;
    isDisabled?: IFormElementsDisabledState;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreDataCreditUsageListForPopup) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<ILoanRequestFormSelectionModalFormValues>;
    show: boolean;
    statesList?: StateListVariable;
    usageVariables?: Partial<UsageVariables>;
}

export interface IFormElementsDisabledState {
    branchDisable: string;
    credit: string;
    customer: string;
    product: string;
    usage: string;
}
export interface ILoanRequestFormSelectionModalFormValues {
    creatorOrgCode: string;
    creditNo: string;
    creditOid: string;
    customerCode: number | null;
    customerOrgCode: string;
    draweeOid: string;
    maxAmount: string;
    minAmount: string;
    nameTitle: string;
    productOid: string;
    productType: string;
    state: string | undefined;
    usagePatternOid: string;
    usageType: string;
}

export interface IModalOidInfo {
    draweeOid: string;
    productOid: string;
    usagePatternOid: string;
}

export interface IInquiryCriteriasProps<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'setValue'>,
        Pick<ILoanRequestFormSelectionModalProps, 'show'> {
    componentProps?: ILoanRequestFormSelectionModalComponentProps;
    creditState?: string;
    creditUsageListForPopupData: ICreditUsageListForPopupResponse | undefined;
    isDisabled?: IFormElementsDisabledState;
    referenceDatas?: ReferenceDataResponse;
    setOid: Dispatch<SetStateAction<IModalOidInfo>>;
    statesListVar: ICreditStateCoreData[];
    usageVariables?: Partial<UsageVariables>;
}

export interface IRequestDataGridProps extends Pick<ILoanRequestFormSelectionModalProps, 'onReturnData'> {
    closeModal: () => void;
    data?: ICoreDataCreditUsageListForPopup[];
    referenceDatas?: ReferenceDataResponse;
    usageVariables?: Partial<UsageVariables>;
}

export enum ProductTypeEnum {
    Cash = '0',
    NonCash = '1',
}

export enum ProductMainGroupEnum {
    CashCredits = '08',
    NonCashCredits = '09',
}

export enum AmountEnum {
    MinAmount = '0',
    MaxAmount = '999999999999',
}

export enum ListTypeEnum {
    OidName = '0',
    CodeName = '1',
}

export interface UsageVariables {
    creditOid: string;
    isETender: string;
    isInjunction: string;
    isKkdfFarmDef: string;
    isPrinciple: string;
    isRebuild: string;
    isReprint: string;
    otherCredit: string;
    pricingModel: string;
    processId: string;
    PRODUCT_PROPERTIES_2: string;
    PRODUCT_PROPERTIES_3: string;
    PRODUCT_PROPERTIES_4: string;
    PRODUCT_PROPERTIES_5: string;
    PRODUCT_PROPERTIES_6: string;
    productProperties: string;
    RECORD_TYPE_2: string;
    recordType: string;
    scopeCodeNotNull: string;
    txtUsageType: string;
    usageAccountOid: string;
    usageType: string;
    yenidenYapilandirma: string;
}

export interface StateListVariable {
    stateListVar: string;
}

export enum QueryFormDefaultValuesEnum {
    IsGM = '10',
}
export enum DisabledValueEnum {
    NonDisabled = '1',
}

export enum RecordTypeEnum {
    Collecteral = 'E',
    Current = 'C',
    Demanded = 'R',
    Disbursement = 'U',
}

export enum CreditStateEnum {
    ActiveState = '2',
}
