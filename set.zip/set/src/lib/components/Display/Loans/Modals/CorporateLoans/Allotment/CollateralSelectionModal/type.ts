import type { IButtonProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../../../utils';
import type {
    ICcsCollateralListCoreData,
    ICcsCollateralListRequest,
} from '../../../../../../../utils/types/api/models/Loans/CCS/allotment/ccsCollateralList';

type ISelectType = {
    [Property in `${keyof Pick<
        ICollateralSelectionModalFormValues,
        'collateralType' | 'orgCode' | 'state' | 'verification' | 'collateralCreditType'
    >}`]?: Pick<ISelectProps<ICollateralSelectionModalFormValues[Property]>, 'disabled' | 'readOnly'>;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<ICollateralSelectionModalFormValues, 'collateralNo' | 'customerTitle'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type INumberInputType = Partial<
    Record<
        `${keyof Pick<ICollateralSelectionModalFormValues, 'custCode'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface ICollateralSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<ICollateralSelectionModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICcsCollateralListCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<ICcsCollateralListRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface ICollateralSelectionModalFormValues {
    collateralCreditType: string;
    collateralNo: string;
    collateralType: string;
    custCode: string;
    customerTitle: string;
    orgCode: string;
    state: string;
    verification: string;
}

export enum VerificationEnum {
    verification = 1,
    nonVerification = 0,
}

export enum CreditTypeEnum {
    corporate = 1,
    individual = 0,
}

export enum StateEnum {
    active = 1,
    pasive = 0,
}
