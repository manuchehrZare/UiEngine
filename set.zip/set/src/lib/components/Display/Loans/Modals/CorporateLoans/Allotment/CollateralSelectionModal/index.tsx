/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control, DataGridColumnsPropsType } from 'seker-ui';
import {
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Input,
    message,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    numberFormat,
    Paper,
    Select,
    useForm,
    useWatch,
} from 'seker-ui';
import { CleaningServices, Search } from '@mui/icons-material';
import type { ICollateralSelectionModalFormValues, ICollateralSelectionModalProps } from './type';
import { CreditTypeEnum, StateEnum, VerificationEnum } from './type';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../../utils';
import {
    ClosenessStatusDataEnum,
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    getReferenceData,
    useTranslation,
} from '../../../../../../../utils';
import { isEqual, omit } from 'lodash';
import { ModalViewer, useAxios } from '../../../../../../..';
import type {
    ICcsCollateralListCoreData,
    ICcsCollateralListRequest,
    ICcsCollateralListResponse,
} from '../../../../../../../utils/types/api/models/Loans/CCS/allotment/ccsCollateralList';

// EBML equivalent: PP_CCS_COLLATERAL
const CollateralSelectionModal: FC<ICollateralSelectionModalProps> = ({
    show,
    onClose,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    formData,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [dataGridData, setDataGridData] = useState<ICcsCollateralListCoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { handleSubmit, control, setValue, reset, getValues } = useForm<ICollateralSelectionModalFormValues>({
        defaultValues: {
            collateralCreditType: '',
            collateralNo: '',
            collateralType: '',
            custCode: '',
            customerTitle: '',
            orgCode: '',
            state: '',
            verification: '',
        },
    });

    const StateData = [
        {
            name: t(locale.contentTitles.active),
            value: StateEnum.active,
        },
        {
            name: t(locale.contentTitles.passive),
            value: StateEnum.pasive,
        },
    ];

    const CreditTypeData = [
        {
            name: t(locale.contentTitles.individual),
            value: CreditTypeEnum.individual,
        },
        {
            name: t(locale.contentTitles.corporate),
            value: CreditTypeEnum.corporate,
        },
    ];

    const VerificationData = [
        {
            name: t(locale.contentTitles.done),
            value: VerificationEnum.verification,
        },
        {
            name: t(locale.contentTitles.notDone),
            value: VerificationEnum.nonVerification,
        },
    ];

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_CCS_COLLATERAL_TYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'custCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            width: 120,
        },
        {
            field: 'collateralNo',
            headerName: t(locale.contentTitles.collateralNo),
            headerAlign: 'center',
            align: 'center',
            width: 120,
        },
        {
            field: 'collateralType',
            headerName: t(locale.contentTitles.collateralType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_CCS_COLLATERAL_TYPE,
                    }).find((item) => isEqual(item?.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'collateralExplanation',
            headerName: t(locale.contentTitles.collateralExplanation),
            headerAlign: 'center',
            width: 150,
        },
        {
            field: 'gksVersion',
            headerName: t(locale.contentTitles.gksVersion),
            headerAlign: 'center',
            align: 'center',
            width: 130,
        },
        {
            field: 'ttksVersion',
            headerName: t(locale.contentTitles.ttksVersion),
            headerAlign: 'center',
            align: 'center',
            width: 130,
        },
        {
            field: 'orgCode',
            headerName: t(locale.contentTitles.branch),
            headerAlign: 'center',
            align: 'center',
            width: 130,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE,
                    }).find((item) => isEqual(item?.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'collateralAmount',
            headerName: t(locale.contentTitles.collateralAmount),
            headerAlign: 'center',
            align: 'right',
            width: 130,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    thousandSeparator: '.',
                    decimalSeparator: ',',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'currCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            width: 120,
        },
        {
            field: 'state',
            headerName: t(locale.contentTitles.status),
            headerAlign: 'center',
            align: 'center',
            valueFormatter: (value) => {
                return StateData.find((item) => item.value === value)?.name || '';
            },
        },
        {
            field: 'verification',
            headerName: t(locale.contentTitles.onSiteInspection),
            headerAlign: 'center',
            align: 'center',
            width: 140,
            valueFormatter: (value) => {
                return VerificationData.find((item) => item.value === value)?.name || '';
            },
        },
    ];

    const resetModal = () => {
        reset();
        setDataGridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICcsCollateralListCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): ICollateralSelectionModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { collateralNo: modalViewerInputWatch }),
        ...formData,
    });

    const [{ error: ccsCollateralListError }, ccsCollateralListCall] = useAxios<
        ICcsCollateralListResponse,
        ICcsCollateralListRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCS_COLLATERAL_LIST), { manual: true });

    const onSubmit = async (formValues: ICollateralSelectionModalFormValues) => {
        const response = await ccsCollateralListCall({
            data: {
                ...omit(formValues, ['customerTitle']),
            },
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData?.length) {
                setDataGridData(responseData);
            } else {
                setDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await ccsCollateralListCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData.coreData[0]);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (ccsCollateralListError) {
            show && !modalShow && closeModal();
            setDataGridData([]);
        }
    }, [ccsCollateralListError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.colletralSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.colletralSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Input
                                                name="collateralNo"
                                                control={control}
                                                label={t(locale.labels.collateralNo)}
                                                {...componentProps?.inputProps?.collateralNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="collateralType"
                                                label={t(locale.labels.collateralType)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    data: getReferenceData({
                                                        referenceDatas,
                                                        referenceDataName: ReferenceDataEnum.PRM_CCS_COLLATERAL_TYPE,
                                                    }),
                                                }}
                                                {...componentProps?.selectProps?.collateralType}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                control={control}
                                                setValue={setValue}
                                                name="orgCode"
                                                label={t(locale.labels.branch)}
                                                options={{
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName:
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE,
                                                        }).sort((a, b) => {
                                                            return Number(a.key) - Number(b.key);
                                                        }) || [],
                                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                                }}
                                                {...componentProps?.selectProps?.orgCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="state"
                                                control={control}
                                                setValue={setValue}
                                                label={t(locale.labels.collateralStatus)}
                                                options={{
                                                    data: StateData,
                                                    displayField: 'name',
                                                    displayValue: 'value',
                                                }}
                                                {...componentProps?.selectProps?.state}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="verification"
                                                label={t(locale.labels.onSiteInspection)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data: VerificationData,
                                                    displayField: 'name',
                                                    displayValue: 'value',
                                                }}
                                                {...componentProps?.selectProps?.verification}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="collateralCreditType"
                                                label={t(locale.labels.creditType)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data: CreditTypeData,
                                                    displayField: 'name',
                                                    displayValue: 'value',
                                                }}
                                                {...componentProps?.selectProps?.collateralCreditType}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                control={control}
                                                name="custCode"
                                                label={t(locale.labels.customerNo)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.customerCode),
                                                }}
                                                decimalScale={0}
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                modalProps={{
                                                    formData: { custCustActive: ClosenessStatusDataEnum.NotClose },
                                                    onReturnData: (data: any) => {
                                                        setValue('customerTitle', data?.nameTitle || '');
                                                        setValue('custCode', String(data?.customerCode));
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.custCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                label={t(locale.labels.customerName)}
                                                name="customerTitle"
                                                control={control}
                                                readOnly
                                                {...componentProps?.inputProps?.customerTitle}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<Search />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem md={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                fullWidth
                                                onClick={() => resetModal()}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={300}>
                                    <DataGrid
                                        columns={columns}
                                        rows={dataGridData || []}
                                        onRowDoubleClick={({ row }: { row: ICcsCollateralListCoreData }) => {
                                            handleOnReturnData(row);
                                            closeModal();
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default CollateralSelectionModal;
