import type { FieldValues, HelperFormProps, IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type {
    IGetAsCCSLimProductUsageTempletForCreditRequest,
    IProductUsageTempletListCoreData,
} from '../../../../../../../utils/types/api/models/Loans/CCS/allotment/ccsLimProductUsageTempletForCredit/type';
import type { IHelperModalProps, ReferenceDataResponse, SETModalsCommonProps } from '../../../../../../../utils';

type ISelectType = {
    [Property in `${keyof Pick<
        IProductDisbursementFeaturesModalFormValues,
        'usageType' | 'productOid' | 'productGroupOid' | 'productMainGroupOid'
    >}`]?: Pick<ISelectProps<IProductDisbursementFeaturesModalFormValues[Property]>, 'disabled' | 'readOnly'>;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<IProductDisbursementFeaturesModalFormValues, 'templeteName'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IProductDisbursementFeaturesModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IProductDisbursementFeaturesModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IProductUsageTempletListCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IGetAsCCSLimProductUsageTempletForCreditRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IProductDisbursementFeaturesModalFormValues {
    productGroupOid: string;
    productMainGroupOid: string;
    productOid: string;
    templeteName: string;
    usageType: string;
}

export interface IIProductDisbursementFeaturesModalInquiryCriteriasProps<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'setValue'> {
    componentProps?: IComponentProps;
    referenceDatas?: ReferenceDataResponse;
    show: boolean;
}

export enum ListTypeEnum {
    OidName = 0,
    CodeName = 1,
}

export interface IIProductDisbursementFeaturesModaDataGridProps {
    data: IProductUsageTempletListCoreData[];
    onReturnData?: (data: IProductUsageTempletListCoreData) => void;
    referenceDatas?: ReferenceDataResponse;
}
