import type { FieldValues, HelperFormProps, IButtonProps, ISelectProps } from 'seker-ui';
import type {
    IGetCcsAllGeneralProductListCoreData,
    IHelperModalProps,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../../..';

type ISelectType = {
    [Property in `${keyof Pick<IProductSelectionModalFormValues, 'mainGroupCode' | 'groupCode' | 'oid'>}`]?: Pick<
        ISelectProps<IProductSelectionModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

interface IButtonComponentProps {
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    selectProps?: ISelectType;
}

export interface IInquiryCriteriasProps<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'getValues' | 'setValue'> {
    componentProps?: IComponentProps;
    show: boolean;
}

export interface IProductSelectionModalFormValues {
    groupCode: string;
    mainGroupCode: string;
    oid: string;
}

export interface IProductSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IProductSelectionModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IGetCcsAllGeneralProductListCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IProductSelectionModalFormValues>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IProductDataGridProps<T extends FieldValues>
    extends HelperFormProps<T, 'control'>,
        Pick<IProductSelectionModalProps, 'onReturnData'> {
    closeModal: () => void;
    data: IGetCcsAllGeneralProductListCoreData[];
    referenceDatas?: ReferenceDataResponse;
}

export enum ProductTypeEnum {
    Cash = 0,
    NonCash = 1,
}

export enum ListTypeEnum {
    OidName = 0,
    CodeName = 1,
}
