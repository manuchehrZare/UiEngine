import { isEqual } from 'lodash';
import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, NumberFormat } from 'seker-ui';
import type { ICoreDataCreditUsageListForPopup } from '../../../../../../../..';
import { ReferenceDataEnum, stringToStringDate, useTranslation } from '../../../../../../../..';
import type { IRequestDataGridProps } from '../type';
import { RecordTypeEnum, ProductTypeEnum } from '../type';

const RequestDataGrid: FC<IRequestDataGridProps> = ({
    data,
    onReturnData,
    closeModal,
    usageVariables,
    referenceDatas,
}) => {
    const { t, locale } = useTranslation();

    const ProductTypeData = [
        {
            key: t(locale.labels.cash_2),
            value: ProductTypeEnum.Cash,
        },
        {
            key: t(locale.labels.nonCash_2),
            value: ProductTypeEnum.NonCash,
        },
    ];

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'creditNo',
            headerName:
                usageVariables?.recordType === RecordTypeEnum.Current
                    ? t(locale.contentTitles.ktfNo)
                    : t(locale.contentTitles.disbursementNo),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
        },
        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.customerCode),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
        },
        {
            field: 'customerTitle',
            headerName: t(locale.contentTitles.customerName),
            headerAlign: 'center',
            minWidth: 275,
        },
        {
            field: 'customerOrgCode',
            headerName: t(locale.contentTitles.customerBranch),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                const branch = referenceDatas?.resultList
                    ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE)
                    ?.items?.find((item) => isEqual(item.key, value));
                return branch ? `${branch.key} - ${branch.value}` : '';
            },
        },
        {
            field: 'creatorOrgCode',
            headerName: t(locale.contentTitles.creditBranch),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                const branch = referenceDatas?.resultList
                    ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE)
                    ?.items?.find((item) => isEqual(item.key, value));
                return branch ? `${branch.key} - ${branch.value}` : '';
            },
        },
        {
            field: 'scopeCode',
            headerName: t(locale.contentTitles.scopeCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'amount',
            headerName: t(locale.contentTitles.amount),
            headerAlign: 'center',
            align: 'right',
            minWidth: 150,
            renderCell: (params) => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'maturityDate',
            headerName: t(locale.contentTitles.loanTerm),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return value ? stringToStringDate(`${value}`) : '';
            },
        },
        {
            field: 'cashNonCash',
            headerName: t(locale.contentTitles.productType),
            headerAlign: 'center',
            minWidth: 150,
            align: 'center',
            valueFormatter: (value) => {
                return ProductTypeData.find((item) => isEqual(item.value, String(value)))?.key || '';
            },
        },
        {
            field: 'productOid',
            headerName: t(locale.contentTitles.productName),
            headerAlign: 'center',
            minWidth: 225,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_PRODUCT_TYPE)
                        ?.items?.find((item) => isEqual(item.key, value))?.value || ''
                );
            },
        },
        {
            field: 'isInjunction',
            headerName: t(locale.contentTitles.interimInjunction),
            headerAlign: 'center',
            minWidth: 120,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'state',
            headerName: t(locale.contentTitles.creditStatus),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_CRD_CRD_USAGE_STATE)
                        ?.items?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'series',
            headerName: t(locale.contentTitles.sequence),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'serieNo',
            headerName: t(locale.contentTitles.sequenceNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'referenceId',
            headerName: t(locale.contentTitles.referenceNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'contractAmount',
            headerName: t(locale.contentTitles.commitmentAmount),
            headerAlign: 'center',
            align: 'right',
            minWidth: 150,
            renderCell: (params) => {
                return (
                    <NumberFormat
                        value={params?.value || '0'}
                        decimalSeparator=","
                        decimalScale={2}
                        fixedDecimalScale
                        thousandSeparator="."
                    />
                );
            },
        },
        {
            field: 'contractCurrCode',
            headerName: t(locale.contentTitles.commitmentCurrencyType),
            headerAlign: 'center',
            minWidth: 150,
        },
        {
            field: 'appDate',
            headerName: t(locale.contentTitles.disbursementDate),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return value ? stringToStringDate(`${value}`) : '';
            },
        },
        {
            field: 'iban',
            headerName: t(locale.contentTitles.ibanNumber),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'isSentHti',
            headerName: t(locale.contentTitles.accountFollowUp),
            headerAlign: 'center',
            minWidth: 175,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'letterPrintOrgCode',
            headerName: t(locale.contentTitles.letterPrintingBranch),
            headerAlign: 'center',
            align: 'center',
            minWidth: 175,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE)
                        ?.items?.find((item) => isEqual(item.key, value))?.value || ''
                );
            },
        },
        {
            field: 'draweeName',
            headerName: t(locale.contentTitles.addresseeName),
            headerAlign: 'center',
            minWidth: 175,
        },
        {
            field: 'usageType',
            headerName: t(locale.contentTitles.disbursementType),
            headerAlign: 'center',
            minWidth: 150,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE)
                        ?.items?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'templateName',
            headerName: t(locale.contentTitles.disbursementProduct),
            headerAlign: 'center',
            minWidth: 225,
        },
        {
            field: 'isETender',
            headerName: t(locale.contentTitles.isETender),
            headerAlign: 'center',
            minWidth: 120,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'isKkdfFarmDef',
            headerName: t(locale.contentTitles.kkdfDefinedAgriculturalLoan),
            headerAlign: 'center',
            minWidth: 175,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'valueDateInst',
            headerName: t(locale.contentTitles.fixedInstallment),
            headerAlign: 'center',
            minWidth: 120,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'oid',
        },
    ];

    return (
        <DataGrid
            columns={columns}
            hiddenColumns={['oid']}
            rows={data || []}
            onRowDoubleClick={({ row }: { row: ICoreDataCreditUsageListForPopup }) => {
                onReturnData?.(row);
                closeModal();
            }}
        />
    );
};

export default RequestDataGrid;
