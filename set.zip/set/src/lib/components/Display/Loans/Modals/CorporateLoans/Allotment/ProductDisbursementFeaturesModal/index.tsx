/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    useWatch,
} from 'seker-ui';
import DisbursementDataGrid from './DisbursementDataGrid';
import { CleaningServices, ManageSearchOutlined } from '@mui/icons-material';
import type {
    IProductDisbursementFeaturesModalFormValues,
    IProductDisbursementFeaturesModalProps,
} from '../ProductDisbursementFeaturesModal/type';
import { useAxios } from '../../../../../../..';
import InquiryCriterias from './InquiryCriterias';
import type {
    IGetAsCCSLimProductUsageTempletForCreditRequest,
    IGetAsCCSLimProductUsageTempletForCreditResponse,
    IProductUsageTempletListCoreData,
} from '../../../../../../../utils/types/api/models/Loans/CCS/allotment/ccsLimProductUsageTempletForCredit/type';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../../utils';

// EBML equivalent: PP_CCS_LIM_PRODUCT_USAGE_TEMPLET_FOR_CREDIT
const ProductDisbursementFeaturesModal: FC<IProductDisbursementFeaturesModalProps> = ({
    show,
    onClose,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    formData,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const [disbursementDataGridData, setDisbursementDataGridData] = useState<IProductUsageTempletListCoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { handleSubmit, control, setValue, reset, getValues } = useForm<IProductDisbursementFeaturesModalFormValues>({
        defaultValues: {
            productGroupOid: '',
            productMainGroupOid: '',
            productOid: '',
            templeteName: '',
            usageType: '',
        },
    });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, loading: referenceDatasLoading, error: referenceDatasError }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_CCS_CRD_CRD_INSTALLMENT_TYPE,
                            ReferenceDataEnum.PRM_CCS_CRD_INT_INDEX_TYPE,
                            ReferenceDataEnum.PRM_CCS_CRD_INT_INTEREST_TYPE,
                            ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE,
                            ReferenceDataEnum.PRM_CCS_NPERIOD_TYPE,
                            ReferenceDataEnum.PRM_CCS_PERIOD_TYPE,
                            ReferenceDataEnum.PRM_CCS_PERIOD_TYPE_ACCRUAL,
                            ReferenceDataEnum.PRM_CCS_PERIOD_TYPE_VARIABLE,
                            ReferenceDataEnum.PRM_CCS_PRODUCT_PROPERTIES,
                            ReferenceDataEnum.PRM_INVESTCORE_INVCMN_INDEX_LIST,
                            ReferenceDataEnum.PRM_CCS_UTL_PRODUCT_TYPE,
                            ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [, getAsCCSLimProductUsageTempletFoeCreditCall] = useAxios<
        IGetAsCCSLimProductUsageTempletForCreditResponse,
        IGetAsCCSLimProductUsageTempletForCreditRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CCS_LIM_PRODUCT_USAGE_TEMPLET_FOR_CREDIT), { manual: true });

    const resetModal = () => {
        reset();
        setDisbursementDataGridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: IProductUsageTempletListCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IProductDisbursementFeaturesModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { templeteName: modalViewerInputWatch }),
        ...formData,
    });

    const onSubmit = async (formValues: IProductDisbursementFeaturesModalFormValues) => {
        const response = await getAsCCSLimProductUsageTempletFoeCreditCall({
            data: {
                ...formValues,
                allotmentOid: '',
                productProperties: '',
                productState: '',
                usageTempletOid: '',
                screenProductOid: '',
            },
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData?.length) {
                setDisbursementDataGridData(responseData);
            } else {
                setDisbursementDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await getAsCCSLimProductUsageTempletFoeCreditCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    allotmentOid: '',
                    productProperties: '',
                    productState: '',
                    usageTempletOid: '',
                    screenProductOid: '',
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData.coreData[0]);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.productDisbursementFeatures),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.productDisbursementFeatures)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.inquiryCriterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <InquiryCriterias
                                        show={show}
                                        formProps={{ control, setValue }}
                                        referenceDatas={referenceDatas}
                                    />
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12}>
                                            <Button
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<ManageSearchOutlined />}
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                fullWidth
                                                onClick={() => resetModal()}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <DisbursementDataGrid
                                data={disbursementDataGridData}
                                referenceDatas={referenceDatas}
                                onReturnData={(data) => {
                                    handleOnReturnData(data);
                                    closeModal();
                                }}
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default ProductDisbursementFeaturesModal;
