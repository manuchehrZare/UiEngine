/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/rules-of-hooks */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import RequestDataGrid from './RequestDataGrid';
import InquiryCriterias from './InquiryCriterias';
import type {
    ILoanRequestFormSelectionModalProps,
    ILoanRequestFormSelectionModalFormValues,
    IModalOidInfo,
} from './type';
import { AmountEnum, QueryFormDefaultValuesEnum, DisabledValueEnum, RecordTypeEnum } from './type';
import { isEmpty, isNull } from 'lodash';
import type {
    ICreditStateCoreData,
    ICoreDataCreditUsageListForPopup,
    ICreditUsageListForPopupResponse,
    ICreditUsageListForPopupRequest,
    IGetCreditStateListResponse,
    IGetCreditStateListRequest,
    ReferenceDataResponse,
    ReferenceDataRequest,
} from '../../../../../../..';
import {
    useTranslation,
    getGlobalsData,
    GlobalsItemEnum,
    useAxios,
    constants,
    HttpStatusCodeEnum,
    generateReferenceDataRequestList,
    ReferenceDataEnum,
} from '../../../../../../..';
const LoanRequestFormSelectionModal: FC<ILoanRequestFormSelectionModalProps> = ({
    show,
    onClose,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    formData,
    componentProps,
    statesList,
    creditState,
    isDisabled,
    usageVariables,
}) => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [oid, setOid] = useState<IModalOidInfo>({ draweeOid: '', productOid: '', usagePatternOid: '' });
    const [statesListVar, setStatesListVar] = useState<ICreditStateCoreData[]>([]);
    const [creditNoVal, setCreditNoVal] = useState<string>();
    const [isOneOfCriteriasNotEmpty, setIsOneOfCriteriasNotEmpty] = useState<boolean>(true);
    const [talepDataGridData, setTalepDataGridData] = useState<ICoreDataCreditUsageListForPopup[]>([]);

    const { control, setValue, reset, getValues, handleSubmit } = useForm<ILoanRequestFormSelectionModalFormValues>({
        defaultValues: {
            creatorOrgCode: formData?.creatorOrgCode || '',
            creditNo: '',
            creditOid: '',
            customerCode: null,
            customerOrgCode: '',
            draweeOid: '',
            maxAmount: AmountEnum.MaxAmount,
            minAmount: AmountEnum.MinAmount,
            nameTitle: '',
            productOid: '',
            productType: '',
            state: creditState ? creditState : '',
            usagePatternOid: '',
            usageType: '',
        },
        validationSchema: {
            state: validation.string(t(locale.labels.creditStatus), {
                required: !isEmpty(statesList?.stateListVar) && isEmpty(creditNoVal),
                selectable: true,
            }),
            creditNo: validation.string(
                usageVariables?.recordType === RecordTypeEnum.Current
                    ? t(locale.labels.ktfNo)
                    : t(locale.labels.creditStatus),
                {
                    required: !isOneOfCriteriasNotEmpty,
                    messageFormatter: {
                        required: () => t(locale.validations.enterLoanNoOidCustomerNoOrBranch),
                    },
                },
            ),
        },
    });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_CCS_CRD_CRD_USAGE_STATE,
                            ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE,
                            ReferenceDataEnum.PRM_CCS_PRODUCT_TYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [
        { data: creditUsageListForPopupData, error: creditUsageListForPopupCallError },
        creditUsageListForPopupCall,
    ] = useAxios<ICreditUsageListForPopupResponse, ICreditUsageListForPopupRequest>(
        constants.api.endpoints.corporateLoans.creditUsage.credit.crdCreditUsage.usageListForPopup.POST,
        {
            manual: true,
        },
    );

    const [{ error: getCreditStateListCallError }, getCreditStateListCall] = useAxios<
        IGetCreditStateListResponse,
        IGetCreditStateListRequest
    >(constants.api.endpoints.corporateLoans.creditUsage.credit.credit.getCreditStateList.POST, {
        manual: true,
    });

    const getCreditStateList = async (paramStatesList: string) => {
        const response = await getCreditStateListCall({
            data: {
                statesList: paramStatesList,
            },
        });
        if (response?.status === HttpStatusCodeEnum.Ok) {
            if (response?.data?.coreData?.length) {
                setStatesListVar(response?.data?.coreData);
            }
        }
    };

    const resetModal = () => {
        reset({
            ...control._defaultValues,
            customerCode: isDisabled?.customer === DisabledValueEnum.NonDisabled ? getValues('customerCode') : null,
            creatorOrgCode:
                getGlobalsData({ key: GlobalsItemEnum.ChargedOrganizationType }) === QueryFormDefaultValuesEnum.IsGM
                    ? ''
                    : getValues('creatorOrgCode'),
            productType: isDisabled?.product === DisabledValueEnum.NonDisabled ? getValues('productType') : '',
            state: isDisabled?.credit === DisabledValueEnum.NonDisabled ? getValues('state') : '',
            usageType: isDisabled?.usage === DisabledValueEnum.NonDisabled ? getValues('usageType') : '',
        });
        setTalepDataGridData([]);
        getCreditStateList(statesList?.stateListVar || '');
    };

    const closeModal = () => {
        onClose?.(false);
        reset();
        setTalepDataGridData([]);
        setModalShow(false);
    };

    const handleOnReturnData = (data: ICoreDataCreditUsageListForPopup) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): ILoanRequestFormSelectionModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { creditNo: modalViewerInputWatch && modalViewerInputWatch }),
        ...formData,
    });

    useEffect(() => {
        if (!isEmpty(statesList?.stateListVar)) {
            getCreditStateList(statesList?.stateListVar || '');
        }
    }, []);

    const onSubmit = async (formValues: ILoanRequestFormSelectionModalFormValues) => {
        const response = await creditUsageListForPopupCall({
            data: {
                ...formValues,
                ...usageVariables,
                creditNo: formValues?.creditNo?.toLocaleUpperCase('tr-TR'),
                customerCode: !isNull(formValues.customerCode) ? String(formValues.customerCode) : '',
                productOid: oid.productOid,
                isInjunction: usageVariables?.isInjunction ? usageVariables.processId : '',
                draweeOid: oid.draweeOid,
                usagePatternOid: oid.usagePatternOid,
            },
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData) {
                setTalepDataGridData(response?.data?.coreData);
            } else {
                setTalepDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await creditUsageListForPopupCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    customerCode: !isNull(getValues('customerCode')) ? String(getValues('customerCode')) : '',
                    recordType: RecordTypeEnum.Disbursement,
                    RECORD_TYPE_2: RecordTypeEnum.Disbursement,
                    ...usageVariables,
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData[0]);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (creditUsageListForPopupCallError || getCreditStateListCallError) {
            show && !modalShow && closeModal();
        }
    }, [creditUsageListForPopupCallError, getCreditStateListCallError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.loanApplicationFormSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    useEffect(() => {
        setCreditNoVal(getValues('creditNo'));
    }, [getValues('creditNo')]);

    useEffect(() => {
        setIsOneOfCriteriasNotEmpty(
            !isEmpty(getValues('creatorOrgCode')) ||
                !isEmpty(getValues('creditNo')) ||
                !isEmpty(getValues('customerCode')) ||
                !isEmpty(getValues('customerOrgCode')),
        );
    }, [getValues('creatorOrgCode'), getValues('creditNo'), getValues('customerCode'), getValues('customerOrgCode')]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.loanApplicationFormSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Label text={t(locale.contentTitles.inquiryCriterias)} />
                                    <InquiryCriterias
                                        creditState={creditState}
                                        referenceDatas={referenceDatas}
                                        formProps={{ control, setValue }}
                                        setOid={setOid}
                                        isDisabled={isDisabled}
                                        statesListVar={statesListVar}
                                        componentProps={componentProps}
                                        usageVariables={usageVariables}
                                        creditUsageListForPopupData={creditUsageListForPopupData}
                                        show={show}
                                    />
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 5.3 }}>
                                        <GridItem sm="auto" md={12} ml={{ sm: 'auto' }}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm="auto" md={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                onClick={resetModal}
                                                variant="outlined"
                                                fullWidth
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={300}>
                                    <RequestDataGrid
                                        data={talepDataGridData}
                                        closeModal={closeModal}
                                        onReturnData={onReturnData}
                                        referenceDatas={referenceDatas}
                                        usageVariables={usageVariables}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};
export default LoanRequestFormSelectionModal;
