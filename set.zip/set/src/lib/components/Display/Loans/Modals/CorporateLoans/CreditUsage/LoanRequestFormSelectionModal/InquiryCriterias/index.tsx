import type { FC } from 'react';
import { useEffect, useState } from 'react';
import {
    Button,
    Grid,
    GridItem,
    Input,
    NumberInput,
    NumberInputReturnValueEnum,
    Select,
    Tooltip,
    useWatch,
} from 'seker-ui';
import type { ILoanRequestFormSelectionModalFormValues, IInquiryCriteriasProps, IModalOidInfo } from '../type';
import {
    ProductTypeEnum,
    DisabledValueEnum,
    QueryFormDefaultValuesEnum,
    RecordTypeEnum,
    ProductMainGroupEnum,
} from '../type';
import type { ICustPersCustListAllRequest, ICustPersCustListAllResponse } from '../../../../../../../..';
import {
    ClosenessStatusDataEnum,
    CustPersCustListAllData,
    CustomerInquiryModal,
    GenericSetCallerEnum,
    GlobalsItemEnum,
    HttpStatusCodeEnum,
    KeyboardEventCodeEnum,
    ModalViewer,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    getGenericSetCaller,
    getGlobalsData,
    useAxios,
    useTranslation,
} from '../../../../../../../..';
import { MoreHoriz } from '@mui/icons-material';
import { toString } from 'lodash';

const InquiryCriterias: FC<IInquiryCriteriasProps<ILoanRequestFormSelectionModalFormValues>> = ({
    creditState,
    referenceDatas,
    formProps: { control, setValue },
    statesListVar,
    usageVariables,
    componentProps,
    setOid,
    isDisabled,
    show,
}) => {
    const { t, locale } = useTranslation();
    const [customerInquiryModalOpen, setCustomerInquiryModalOpen] = useState<boolean>(false);

    const ProductTypeData = [
        {
            key: t(locale.labels.cash_2),
            value: ProductTypeEnum.Cash,
        },
        {
            key: t(locale.labels.nonCash_2),
            value: ProductTypeEnum.NonCash,
        },
    ];

    const [customerOrgCodeVal, productTypeVal, customerCodeVal] = useWatch({
        control,
        fieldName: ['customerOrgCode', 'productType', 'customerCode'],
    });

    const [, custPersCustListAllCall] = useAxios<ICustPersCustListAllResponse, ICustPersCustListAllRequest>(
        getGenericSetCaller(GenericSetCallerEnum.CUST_PERS_CUST_LIST_ALL),
        { manual: true },
    );

    const customerServiceOnKeyPressCall = async (e: any) => {
        if (e.key === KeyboardEventCodeEnum.Enter) {
            const response = await custPersCustListAllCall({
                data: {
                    ...CustPersCustListAllData,
                    custCustCustomerCode: customerCodeVal,
                    custCustActive: ClosenessStatusDataEnum.NotClose,
                    custCustMainBranchCode: customerOrgCodeVal,
                },
            });
            const responseData = response?.data?.coreData;
            if (response?.status === HttpStatusCodeEnum.Ok && responseData?.length) {
                setValue(
                    'customerOrgCode',
                    (referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE)
                        ?.items?.filter((params) => params.key === toString(responseData?.[0]?.mainBranchCode))
                        ?.length &&
                        toString(responseData?.[0]?.mainBranchCode)) ||
                        '',
                );
                setValue('nameTitle', responseData?.[0]?.nameTitle || '');
                setValue('customerCode', responseData?.[0]?.customerCode || null);
            } else if (!responseData?.length || responseData?.length > 1) {
                setCustomerInquiryModalOpen(true);
                setValue('nameTitle', '');
            }
        }
    };
    const customerServiceCall = async () => {
        const response = await custPersCustListAllCall({
            data: {
                ...CustPersCustListAllData,
                custCustCustomerCode: customerCodeVal || '',
                custCustActive: ClosenessStatusDataEnum.NotClose,
                custCustMainBranchCode: customerOrgCodeVal || '',
            },
        });
        const responseData = response?.data?.coreData;
        if (response?.status === HttpStatusCodeEnum.Ok && responseData?.length) {
            setValue(
                'customerOrgCode',
                (referenceDatas?.resultList
                    ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE)
                    ?.items?.filter((params) => params.key === toString(responseData?.[0]?.mainBranchCode))?.length &&
                    toString(responseData?.[0]?.mainBranchCode)) ||
                    '',
            );
            setValue('nameTitle', responseData?.[0]?.nameTitle || '');
            setValue('customerCode', responseData?.[0]?.customerCode || null);
        } else if (!responseData?.length || responseData?.length > 1) {
            setCustomerInquiryModalOpen(true);
            setValue('nameTitle', '');
        }
    };

    useEffect(() => {
        if (show && customerCodeVal) {
            customerServiceCall();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [show]);

    return (
        <>
            <Grid
                pt={0.5}
                columns={{
                    xs: constants.design.gridItem.sizeType.form.SET.xs,
                    sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                    md: constants.design.gridItem.sizeType.form.SET.md * 3,
                    lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                    xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                    xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                }}
                spacingType="form">
                <GridItem sizeType="form">
                    <Input
                        control={control}
                        name="creditNo"
                        label={
                            usageVariables?.recordType === RecordTypeEnum.Current
                                ? t(locale.labels.ktfNo)
                                : t(locale.labels.disbursementNo)
                        }
                        sx={{
                            input: {
                                textTransform: 'uppercase',
                            },
                        }}
                        {...componentProps?.inputProps?.creditNo}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <NumberInput
                        control={control}
                        name="customerCode"
                        label={t(locale.labels.customerNumber)}
                        decimalScale={0}
                        endAdornment={
                            <Tooltip title={t(locale.contentTitles.customerInquiry)} sx={{ mr: '-5px' }}>
                                <Button
                                    iconButton
                                    icon={<MoreHoriz />}
                                    onClick={() => setCustomerInquiryModalOpen(true)}
                                />
                            </Tooltip>
                        }
                        disabled={isDisabled?.customer === DisabledValueEnum.NonDisabled ? true : false}
                        {...componentProps?.numberInputProps?.customerCode}
                        onKeyPress={customerServiceOnKeyPressCall}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <Input
                        control={control}
                        name="nameTitle"
                        label={t(locale.labels.customerName)}
                        disabled
                        {...componentProps?.inputProps?.nameTitle}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <Select
                        name="customerOrgCode"
                        label={t(locale.labels.customerBranch)}
                        options={{
                            data:
                                referenceDatas?.resultList
                                    ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE)
                                    ?.items?.sort((a, b) => {
                                        return Number(a.key) - Number(b.key);
                                    }) || [],
                            displayField: 'value',
                            displayValue: 'key',
                            renderDisplayList: (params) => `${params.key} - ${params.value}`,
                            renderDisplayField: (params) => `${params.key} - ${params.value}`,
                        }}
                        control={control}
                        setValue={setValue}
                        {...componentProps?.selectProps?.customerOrgCode}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <Select
                        name="creatorOrgCode"
                        label={t(locale.labels.creditBranch)}
                        control={control}
                        setValue={setValue}
                        disabled={
                            getGlobalsData({ key: GlobalsItemEnum.ChargedOrganizationType }) ===
                            QueryFormDefaultValuesEnum.IsGM
                                ? false
                                : true
                        }
                        options={{
                            data:
                                referenceDatas?.resultList
                                    ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE)
                                    ?.items?.sort((a, b) => {
                                        return Number(a.key) - Number(b.key);
                                    }) || [],
                            displayField: 'value',
                            displayValue: 'key',
                            renderDisplayList: (params) => `${params.key} - ${params.value}`,
                            renderDisplayField: (params) => `${params.key} - ${params.value}`,
                        }}
                        {...componentProps?.selectProps?.creatorOrgCode}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <Select
                        name="productType"
                        label={t(locale.labels.productType)}
                        options={{
                            data: ProductTypeData || [],
                            displayField: 'key',
                            displayValue: 'value',
                        }}
                        control={control}
                        setValue={setValue}
                        {...componentProps?.selectProps?.productType}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <ModalViewer<SETModalsEnum.ProductSelectionModal>
                        component="Input"
                        modalComponent={SETModalsEnum.ProductSelectionModal}
                        control={control}
                        name="productOid"
                        label={t(locale.labels.product)}
                        readOnly
                        adornmentButtonProps={{
                            tooltip: t(locale.labels.product),
                        }}
                        modalProps={{
                            formData: {
                                mainGroupCode: productTypeVal
                                    ? productTypeVal === ProductTypeEnum.Cash
                                        ? ProductMainGroupEnum.CashCredits
                                        : ProductMainGroupEnum.NonCashCredits
                                    : '',
                            },
                            onReturnData: (data: any) => {
                                setValue(
                                    'productType',
                                    data?.mainGroupCode === ProductMainGroupEnum.CashCredits
                                        ? ProductTypeEnum.Cash
                                        : ProductTypeEnum.NonCash || '',
                                );
                                setValue('productOid', data?.productName || '');
                                setOid((val: IModalOidInfo) => {
                                    return { ...val, productOid: data?.oid || '' };
                                });
                            },
                        }}
                        {...componentProps?.inputProps?.productOid}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <Grid spacingType="joinedForm">
                        <GridItem xs>
                            <NumberInput
                                name="minAmount"
                                label={t(locale.labels.amount)}
                                textAlign="right"
                                control={control}
                                allowLeadingZeros
                                thousandSeparator="."
                                decimalSeparator=","
                                returnValue={NumberInputReturnValueEnum.formattedValue}
                                {...componentProps?.numberInputProps?.minAmount}
                            />
                        </GridItem>
                        <GridItem xs={6}>
                            <NumberInput
                                name="maxAmount"
                                control={control}
                                thousandSeparator="."
                                decimalSeparator=","
                                textAlign="right"
                                allowLeadingZeros
                                returnValue={NumberInputReturnValueEnum.formattedValue}
                                {...componentProps?.numberInputProps?.maxAmount}
                            />
                        </GridItem>
                    </Grid>
                </GridItem>
                <GridItem sizeType="form">
                    <Select<any>
                        name="state"
                        label={t(locale.labels.creditStatus)}
                        options={{
                            data:
                                statesListVar?.length > 0
                                    ? statesListVar
                                    : referenceDatas?.resultList?.find(
                                          (item) => item?.name === ReferenceDataEnum.PRM_CCS_CRD_CRD_USAGE_STATE,
                                      )?.items || [],
                            displayField: statesListVar?.length > 0 ? '1' : 'value',
                            displayValue: statesListVar?.length > 0 ? '0' : 'key',
                        }}
                        control={control}
                        disabled={
                            !!creditState || (isDisabled?.credit === DisabledValueEnum.NonDisabled ? true : false)
                        }
                        setValue={setValue}
                        {...componentProps?.selectProps?.state}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <ModalViewer<SETModalsEnum.InterlocutorInquiryModal>
                        component="Input"
                        modalComponent={SETModalsEnum.InterlocutorInquiryModal}
                        control={control}
                        name="draweeOid"
                        label={t(locale.labels.interlocutor)}
                        adornmentButtonProps={{
                            tooltip: t(locale.labels.interlocutor),
                        }}
                        modalProps={{
                            onReturnData: (data: any) => {
                                setOid((val: IModalOidInfo) => {
                                    return { ...val, draweeOid: data?.oid || '' };
                                });
                            },
                        }}
                        {...componentProps?.inputProps?.draweeOid}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <ModalViewer<SETModalsEnum.ProductDisbursementFeaturesModal>
                        component="Input"
                        modalComponent={SETModalsEnum.ProductDisbursementFeaturesModal}
                        control={control}
                        name="usagePatternOid"
                        label={t(locale.labels.disbursementProduct)}
                        adornmentButtonProps={{
                            tooltip: t(locale.labels.disbursementProduct),
                        }}
                        modalProps={{
                            onReturnData: (data: any) => {
                                setValue('usagePatternOid', data?.detailName || '');
                                setOid((val: IModalOidInfo) => {
                                    return { ...val, usagePatternOid: data?.oid || '' };
                                });
                            },
                        }}
                        {...componentProps?.inputProps?.usagePatternOid}
                    />
                </GridItem>
                <GridItem sizeType="form">
                    <Select
                        name="usageType"
                        label={t(locale.labels.disbursementType)}
                        options={{
                            data:
                                referenceDatas?.resultList?.find(
                                    (item) => item?.name === ReferenceDataEnum.PRM_CCS_CREDIT_USAGE_TYPE,
                                )?.items || [],
                            displayField: 'value',
                            displayValue: 'key',
                        }}
                        control={control}
                        setValue={setValue}
                        {...componentProps?.selectProps?.usageType}
                    />
                </GridItem>
            </Grid>
            <CustomerInquiryModal
                show={customerInquiryModalOpen}
                onClose={setCustomerInquiryModalOpen}
                formData={{
                    custCustActive: ClosenessStatusDataEnum.NotClose,
                    custCustMainBranchCode: customerOrgCodeVal,
                    custCustCustomerCode: customerCodeVal,
                }}
                onReturnData={(data) => {
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE)
                        ?.items?.filter((params) => toString(params.key) === toString(data?.mainBranchCode))?.length &&
                        setValue('customerOrgCode', toString(data?.mainBranchCode) || '');
                    setValue('nameTitle', data?.nameTitle || '');
                    setValue('customerCode', data?.customerCode || null);
                }}
            />
        </>
    );
};

export default InquiryCriterias;
