/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect } from 'react';
import { Grid, GridItem, Select, useIsFirstRender, useWatch } from 'seker-ui';
import type { IInquiryCriteriasProps, IProductSelectionModalFormValues } from '../type';
import { ListTypeEnum } from '../type';
import {
    GenericSetCallerEnum,
    constants,
    getGenericSetCaller,
    useAxios,
    useTranslation,
} from '../../../../../../../..';
import type {
    IGetCcsAsProductGroupListComboRequest,
    IGetCcsAsProductGroupListComboResponse,
    IGetCcsLimAsProductMainGroupsListRequest,
    IGetCcsLimAsProductMainGroupsListResponse,
    IGetCcsLimListProductForComboRequest,
    IGetCcsLimListProductForComboResponse,
} from '../../../../../../../../utils/types';

const InquiryCriterias: FC<IInquiryCriteriasProps<IProductSelectionModalFormValues>> = ({
    formProps: { control, setValue, getValues },
    show,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const isFirstRender = useIsFirstRender();

    const [productMainGroupVal, productGroupVal] = useWatch({
        control,
        fieldName: ['mainGroupCode', 'groupCode'],
    });

    const [{ data: getCcsLimAsProductMainGroupsData }, ccsLimProductMainGroupsListCall] = useAxios<
        IGetCcsLimAsProductMainGroupsListResponse,
        IGetCcsLimAsProductMainGroupsListRequest
    >(
        {
            ...getGenericSetCaller(GenericSetCallerEnum.CCS_LIM_PRODUCT_MAIN_GROUPS_LIST),
            data: {
                listType: ListTypeEnum.CodeName,
            },
        },
        { manual: true },
    );

    const [{ data: ccsAsProductGroupListComboData }, ccsAsProductGroupListComboCall] = useAxios<
        IGetCcsAsProductGroupListComboResponse,
        IGetCcsAsProductGroupListComboRequest
    >(
        {
            ...getGenericSetCaller(GenericSetCallerEnum.PRODUCT_PRODUCT_GROUP_LIST_FOR_COMBO),
            data: {
                listType: ListTypeEnum.CodeName,
                productMainGroupCode: productMainGroupVal,
            },
        },
        { manual: true },
    );

    const [{ data: ccsLimListProductForComboData }, ccsLimListProductForComboCall] = useAxios<
        IGetCcsLimListProductForComboResponse,
        IGetCcsLimListProductForComboRequest
    >(
        {
            ...getGenericSetCaller(GenericSetCallerEnum.CCS_LIM_LIST_PRODUCT_FOR_COMBO),
            data: { groupCode: productGroupVal, mainGroup: productMainGroupVal },
        },
        { manual: true },
    );

    useEffect(() => {
        if (show) {
            (!isFirstRender || getValues('mainGroupCode')?.length) && ccsAsProductGroupListComboCall();
        }
    }, [productMainGroupVal]);

    useEffect(() => {
        if (show && !isFirstRender) {
            ccsLimListProductForComboCall();
        }
    }, [productGroupVal]);

    useEffect(() => {
        if (show) {
            ccsLimProductMainGroupsListCall();
        }
    }, [productGroupVal]);

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 3,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Select
                    name="mainGroupCode"
                    label={t(locale.labels.productMainGroup)}
                    options={{
                        data: getCcsLimAsProductMainGroupsData?.productMainGroupList || [],
                        displayField: 1,
                        displayValue: 0,
                        renderDisplayField: (params) => `${params[0]}-${params[1]}`,
                        renderDisplayList: (params) => `${params[0]}-${params[1]}`,
                    }}
                    control={control}
                    setValue={setValue}
                    onChange={() => {
                        setValue('groupCode', '');
                        setValue('oid', '');
                    }}
                    {...componentProps?.selectProps?.mainGroupCode}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="groupCode"
                    label={t(locale.labels.productGroup)}
                    options={{
                        data: productMainGroupVal ? ccsAsProductGroupListComboData?.productGroupList || [] : [],
                        displayField: 1,
                        displayValue: 0,
                        renderDisplayField: (params) => `${params[0]}-${params[1]}`,
                        renderDisplayList: (params) => `${params[0]}-${params[1]}`,
                    }}
                    control={control}
                    setValue={setValue}
                    onChange={() => {
                        setValue('oid', '');
                    }}
                    {...componentProps?.selectProps?.groupCode}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="oid"
                    label={t(locale.labels.product)}
                    options={{
                        data:
                            productMainGroupVal && productGroupVal ? ccsLimListProductForComboData?.coreData || [] : [],
                        displayField: 1,
                        displayValue: 0,
                    }}
                    control={control}
                    setValue={setValue}
                    {...componentProps?.selectProps?.oid}
                />
            </GridItem>
        </Grid>
    );
};

export default InquiryCriterias;
