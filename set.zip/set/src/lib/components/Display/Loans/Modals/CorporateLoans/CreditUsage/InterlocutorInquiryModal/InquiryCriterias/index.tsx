import type { FC } from 'react';
import { useEffect } from 'react';
import { Grid, GridItem, Input, NumberInput, Select, useIsFirstRender, useWatch } from 'seker-ui';
import type { IInterlocutorInquiryModalFormValues, IInterlocutorInquiryProps } from '../type';
import type { IListDraweeGrRegionToComboRequest, IListDraweeGrRegionToComboResponse } from '../../../../../../../..';
import { constants, useAxios, useTranslation } from '../../../../../../../..';

const InquiryCriterias: FC<IInterlocutorInquiryProps<IInterlocutorInquiryModalFormValues>> = ({
    formProps: { control, setValue },
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const isFirstRender = useIsFirstRender();
    const mainGroupOidVal = useWatch({ control, fieldName: 'mainGroupOid' });

    const [{ data: getCcsCrdAsUtlDraweeGrData }] = useAxios<
        IListDraweeGrRegionToComboResponse,
        IListDraweeGrRegionToComboRequest
    >({
        ...constants.api.endpoints.corporateLoans.creditUsage.utility.utilityDraweeGRDef.listDraweeGrRegionToCombo.POST,
        data: {
            parentOid: '',
        },
    });

    const [{ data: getCcsCrdAsUtlDraweeGrSubData }, getCcsCrdAsUtlDraweeGrSubRequest] = useAxios<
        IListDraweeGrRegionToComboResponse,
        IListDraweeGrRegionToComboRequest
    >(constants.api.endpoints.corporateLoans.creditUsage.utility.utilityDraweeGRDef.listDraweeGrRegionToCombo.POST, {
        manual: true,
    });

    useEffect(() => {
        if (!isFirstRender) {
            getCcsCrdAsUtlDraweeGrSubRequest({
                data: {
                    parentOid: mainGroupOidVal,
                },
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [mainGroupOidVal]);

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 3,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Select
                    label={t(locale.labels.mainGroupName)}
                    name="mainGroupOid"
                    control={control}
                    setValue={setValue}
                    options={{
                        data: getCcsCrdAsUtlDraweeGrData?.coreData || [],
                        displayField: 1,
                        displayValue: 0,
                    }}
                    {...componentProps?.selectProps?.mainGroupOid}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    label={t(locale.labels.subGroupName)}
                    name="subGroupOid"
                    control={control}
                    setValue={setValue}
                    options={{
                        data: mainGroupOidVal ? getCcsCrdAsUtlDraweeGrSubData?.coreData || [] : [],
                        displayField: 1,
                        displayValue: 0,
                    }}
                    {...componentProps?.selectProps?.subGroupOid}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    label={t(locale.labels.interlocutorNameTitle)}
                    name="draweeName"
                    control={control}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.draweeName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    label={t(locale.labels.tcIdNo)}
                    name="tc"
                    maxLength={11}
                    control={control}
                    decimalScale={0}
                    {...componentProps?.numberInputProps?.tc}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    label={t(locale.labels.taxIdNo)}
                    name="vkn"
                    maxLength={10}
                    control={control}
                    decimalScale={0}
                    {...componentProps?.numberInputProps?.vkn}
                />
            </GridItem>
        </Grid>
    );
};

export default InquiryCriterias;
