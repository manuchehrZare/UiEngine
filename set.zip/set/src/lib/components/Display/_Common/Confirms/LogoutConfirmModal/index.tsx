import type { FC } from 'react';
import type { IConfirmModalProps } from 'seker-ui';
import { ConfirmModal, hideLoading, showLoading, sleep } from 'seker-ui';
import type { ShellExitDataType } from '../../../../..';
import { isWebview, ShellExitTypeEnum, ShellProcessTypeEnum, shellTrigger, useTranslation } from '../../../../..';
import { app } from '../../../../../utils/constants/app';

export interface ILogoutConfirmModalProps
    extends Pick<IConfirmModalProps, 'show' | 'onClose' | 'cancelText' | 'okText'>,
        Partial<Pick<IConfirmModalProps, 'body' | 'onConfirm'>> {}

const LogoutConfirmModal: FC<ILogoutConfirmModalProps> = ({ cancelText, okText, onClose, onConfirm, show, body }) => {
    const { t, locale } = useTranslation();
    const handleApprove = () => {
        // Confirm "logout"
        if (isWebview()) {
            showLoading();
            sleep(app.delay.CLOSING_LOADING_DELAY)
                .then(() => {
                    shellTrigger<ShellExitDataType>({
                        processType: ShellProcessTypeEnum.Exit,
                        data: {
                            status: true,
                            type: ShellExitTypeEnum.Application,
                        },
                    });
                })
                .then(() => {
                    hideLoading();
                });
        }
    };

    return (
        <ConfirmModal
            show={show}
            body={body || t(locale.contents.areYouSureYouWantToLogOutOfTheApplication) || ''}
            cancelText={cancelText || t(locale.buttons.giveUp)}
            okText={okText || t(locale.buttons.logout)}
            actionProps={{
                cancelProps: {
                    color: 'error',
                    variant: 'outlined',
                },
            }}
            onClose={() => {
                onClose?.();
            }}
            onConfirm={(status) => {
                if (status) {
                    handleApprove();
                } else {
                    // Confirm "giveUp"
                    isWebview() &&
                        shellTrigger<ShellExitDataType>({
                            processType: ShellProcessTypeEnum.Exit,
                            data: {
                                status: false,
                                type: ShellExitTypeEnum.Application,
                            },
                        });
                    onClose?.();
                }
                onConfirm?.(status);
            }}
        />
    );
};

export default LogoutConfirmModal;
