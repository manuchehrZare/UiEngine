import type { FC } from 'react';
import type { IConfirmModalProps } from 'seker-ui';
import { ConfirmModal } from 'seker-ui';
import { useTranslation } from '../../../../..';

export interface ICloseAppConfirmModalProps
    extends Pick<IConfirmModalProps, 'show' | 'onClose' | 'title' | 'cancelText' | 'okText' | 'onConfirm'>,
        Partial<Pick<IConfirmModalProps, 'body'>> {}

const CloseAppConfirmModal: FC<ICloseAppConfirmModalProps> = ({
    show,
    cancelText,
    okText,
    onConfirm,
    onClose,
    body,
    title,
}) => {
    const { t, locale } = useTranslation();
    return (
        <ConfirmModal
            show={show}
            title={title}
            body={body || t(locale.contents.areYouSureYouWantToCloseTheApplication) || ''}
            actionProps={{
                cancelProps: {
                    color: 'error',
                    variant: 'outlined',
                },
            }}
            cancelText={cancelText || t(locale.buttons.giveUp)}
            okText={okText || t(locale.buttons.close)}
            onClose={onClose}
            onConfirm={onConfirm}
        />
    );
};

export default CloseAppConfirmModal;
