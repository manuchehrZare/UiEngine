import type { FC } from 'react';
import type { IConfirmModalProps } from 'seker-ui';
import { ConfirmModal } from 'seker-ui';
import { useTranslation } from '../../../../..';

export interface ILossOfChangeConfirmModalProps
    extends Pick<IConfirmModalProps, 'show' | 'onClose' | 'title' | 'cancelText' | 'okText' | 'onConfirm'>,
        Partial<Pick<IConfirmModalProps, 'body'>> {}

const LossOfChangeConfirmModal: FC<ILossOfChangeConfirmModalProps> = ({
    show,
    cancelText,
    okText,
    onConfirm,
    onClose,
    body,
    title,
}) => {
    const { t, locale } = useTranslation();
    return (
        <ConfirmModal
            show={show}
            title={title || t(locale.contentTitles.warning)}
            body={body || t(locale.contents.doYouWantToContinue)}
            actionProps={{
                cancelProps: {
                    color: 'error',
                    variant: 'outlined',
                },
            }}
            cancelText={cancelText || t(locale.buttons.no)}
            okText={okText || t(locale.buttons.yes)}
            onClose={() => {
                onClose?.();
            }}
            onConfirm={(status) => {
                onConfirm?.(status);
            }}
        />
    );
};

export default LossOfChangeConfirmModal;
