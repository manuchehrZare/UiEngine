import type { FC } from 'react';
import { Children, forwardRef, memo } from 'react';
import type { IBoxProps, ILabelProps, IPaperProps } from 'seker-ui';
import { Box, Label, Paper, manageClassNames } from 'seker-ui';
import { constants, useTranslation } from '../../../../../utils';
import { keys, omit } from 'lodash';

export interface IPasswordInformationsProps extends IPaperProps {
    componentProps?: {
        labelProps?: Partial<ILabelProps>;
        listItemProps?: IBoxProps;
        listProps?: IBoxProps;
    };
}

const PasswordInformations: FC<IPasswordInformationsProps> = forwardRef(
    ({ sx, borderBox, componentProps, ...rest }: IPasswordInformationsProps, ref) => {
        const { t, locale } = useTranslation();
        return (
            <Paper
                ref={ref}
                borderBox={borderBox}
                sx={{
                    backgroundColor: constants.design.backgroundColor.body,
                    boxShadow: 'none',
                    ...(!borderBox && { border: 'none !important' }),
                    ...sx,
                }}
                {...rest}>
                <Label
                    className={manageClassNames('password-informations__label', componentProps?.labelProps?.className)}
                    text={
                        componentProps?.labelProps?.text || t(locale.contentTitles.auth.password.passwordRequirements)
                    }
                    color={(theme) => theme.palette.primary.main}
                    {...omit(componentProps?.labelProps, ['className', 'text'])}
                />
                <Box
                    className={manageClassNames('password-informations__list', componentProps?.listProps?.className)}
                    component="ul"
                    pl={2}
                    pt={0.5}
                    sx={{ listStyle: 'disc', ...componentProps?.listProps?.sx }}
                    {...omit(componentProps?.listProps, ['className', 'sx'])}>
                    {Children.toArray(
                        keys(locale.contents.auth.password.requirements).map((item) => (
                            <Box
                                className={manageClassNames(
                                    'password-informations__list__item',
                                    componentProps?.listItemProps?.className,
                                )}
                                component="li"
                                {...omit(componentProps?.listItemProps, ['className'])}>
                                {t((locale.contents.auth.password.requirements as any)[item])}
                            </Box>
                        )),
                    )}
                </Box>
            </Paper>
        );
    },
);

export default memo(PasswordInformations);
