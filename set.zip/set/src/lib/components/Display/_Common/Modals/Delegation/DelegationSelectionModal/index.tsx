/* eslint-disable react-hooks/exhaustive-deps */
import { TouchAppOutlined } from '@mui/icons-material';
import type { FC } from 'react';
import { useEffect } from 'react';
import {
    Button,
    Divider,
    Grid,
    GridItem,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    Radio,
    RadioGroup,
    Select,
    importantStyle,
    theme,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import type {
    RequestHeaderParams,
    SetDelegationParametersRequest,
    SetDelegationParametersResponse,
} from '../../../../../..';
import { getAuthorization, getXUserName, useAxios, useTranslation } from '../../../../../..';
import type { DelegationSelectionFormValues, DelegationSelectionModalProps } from './type';
import { DelegateUserOptionValueEnum } from './type';
import { HttpStatusCodeEnum, constants } from '../../../../../../utils';

const DelegationSelectionModal: FC<DelegationSelectionModalProps> = ({
    authenticateResponseData,
    delegatingUsers,
    show,
    onSelect,
}) => {
    const { t, locale } = useTranslation();

    const { control, handleSubmit, resetField, setValue, reset } = useForm<DelegationSelectionFormValues>({
        defaultValues: {
            delegatedUser: '',
            delegatedUserOption: DelegateUserOptionValueEnum.For_MySelf,
        },
        validationSchema: {
            delegatedUserOption: validation
                .string(t(locale.labels.delegation), { required: true })
                .oneOf([DelegateUserOptionValueEnum.For_MySelf, DelegateUserOptionValueEnum.For_DelegatedOtherUser]),
            delegatedUser: validation.string(t(locale.labels.delegatedUser)).when('delegatedUserOption', {
                is: (delegatedUserOption: `${DelegateUserOptionValueEnum}`) =>
                    delegatedUserOption === DelegateUserOptionValueEnum.For_DelegatedOtherUser,
                then: () =>
                    validation.string(t(locale.labels.delegatedUser), {
                        required: true,
                        selectable: true,
                    }),
            }),
        },
    });
    const delegatedUserOptionWatch = useWatch({ control, fieldName: 'delegatedUserOption' });

    const [, setDelegationParametersRequest] = useAxios<
        SetDelegationParametersResponse,
        SetDelegationParametersRequest
    >(constants.api.endpoints.nova.gateway.delegation.setDelegationParameters.POST, { manual: true });

    const onSubmit = async (formData: DelegationSelectionFormValues) => {
        if (formData.delegatedUserOption === DelegateUserOptionValueEnum.For_MySelf) {
            onSelect?.(null);
        } else {
            const selectedDelegatedUser = delegatingUsers.find((item) => item.userOid === formData.delegatedUser);
            const requestHeaderParams: Required<Pick<RequestHeaderParams, 'Authorization' | 'x-username'>> = {
                Authorization: getAuthorization(authenticateResponseData.token) || '',
                'x-username': getXUserName(authenticateResponseData.globals) || '',
            };
            const setDelegationParametersResponse = await setDelegationParametersRequest({
                headers: requestHeaderParams,
                data: { delegatingUserOid: selectedDelegatedUser?.userOid || '' },
            });
            if (
                setDelegationParametersResponse.status === HttpStatusCodeEnum.Ok &&
                setDelegationParametersResponse.data
            ) {
                onSelect?.({
                    ...setDelegationParametersResponse.data,
                    selectedDelegatedUser: selectedDelegatedUser || null,
                });
            }
        }
    };

    useEffect(() => {
        delegatedUserOptionWatch === DelegateUserOptionValueEnum.For_MySelf && resetField('delegatedUser');
    }, [delegatedUserOptionWatch]);

    useEffect(() => {
        !show && reset();
        return () => {
            reset();
        };
    }, [show]);

    return (
        <Modal maxWidth="xs" show={show} allowClose={false} closeIcon={false}>
            <ModalTitle>{t(locale.contentTitles.delegation.selection)}</ModalTitle>
            <ModalBody sx={{ py: importantStyle(theme.spacing(2)), px: { xs: 2, sm: 5 } }}>
                <Grid spacingType="form">
                    <GridItem>
                        <RadioGroup name="delegatedUserOption" control={control}>
                            <Radio label={t(locale.labels.forMyself)} value={DelegateUserOptionValueEnum.For_MySelf} />
                            <Radio
                                label={t(locale.labels.onBehalfOfAnotherDelegatedUser)}
                                value={DelegateUserOptionValueEnum.For_DelegatedOtherUser}
                            />
                        </RadioGroup>
                    </GridItem>
                    <GridItem>
                        <Divider />
                    </GridItem>
                    <GridItem>
                        <Select
                            name="delegatedUser"
                            control={control}
                            setValue={setValue}
                            label={t(locale.labels.delegatedUser)}
                            disabled={delegatedUserOptionWatch === DelegateUserOptionValueEnum.For_MySelf}
                            options={{
                                data: delegatingUsers,
                                displayField: 'userFullName',
                                displayValue: 'userOid',
                            }}
                        />
                    </GridItem>
                </Grid>
            </ModalBody>
            <ModalFooter>
                <Grid justifyContent="center" spacingType="button">
                    <GridItem xs={false}>
                        <Button
                            onClick={handleSubmit(onSubmit)}
                            text={t(locale.buttons.choose)}
                            iconLeft={<TouchAppOutlined />}
                        />
                    </GridItem>
                </Grid>
            </ModalFooter>
        </Modal>
    );
};

export default DelegationSelectionModal;
