import type { IModalProps } from 'seker-ui';
import type { AuthenticateResponse, ReferenceDataResultListItemsListItem } from '../../../../..';

export type BranchSelectionFormValues = {
    branch: string;
};

export type BranchSelectionModalProps = Required<Pick<IModalProps, 'show' | 'onClose'>> & {
    authenticateResponseData: AuthenticateResponse;
    onSelect: (selectedBranchData: ReferenceDataResultListItemsListItem | null) => void;
};
