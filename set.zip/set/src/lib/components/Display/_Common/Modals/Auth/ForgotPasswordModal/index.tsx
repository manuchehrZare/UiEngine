import type { FC } from 'react';
import { useState } from 'react';
import {
    Button,
    ConfirmModal,
    Grid,
    gridClasses,
    GridItem,
    message,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    useForm,
    validation,
} from 'seker-ui';
import type { ForgotPasswordModalFormValues, ForgotPasswordModalProps } from './type';
import type { ForgottenPasswordRequest, ForgottenPasswordResponse, RequestHeaderParams } from '../../../../../..';
import {
    ChangeConfirmedEnum,
    ForgottenPasswordResponseSuccessEnum,
    RegistryNoInput,
    constants,
    useAxios,
    useTranslation,
} from '../../../../../..';
import { HttpStatusCodeEnum } from '../../../../../../utils';

const ForgotPasswordModal: FC<ForgotPasswordModalProps> = ({ show, onClose }) => {
    const { t, locale } = useTranslation();
    const [confirmModalShow, setConfirmModalShow] = useState(false);

    const { control, getValues, handleSubmit, reset } = useForm<ForgotPasswordModalFormValues>({
        defaultValues: {
            registryNo: '',
        },
        validationSchema: {
            registryNo: validation.string(t(locale.labels.registryNo), {
                required: true,
                maxLength: 10,
            }),
        },
    });

    const [{ data: forgottenPasswordResponseData }, forgottenPasswordRequest] = useAxios<
        ForgottenPasswordResponse,
        ForgottenPasswordRequest
    >(constants.api.endpoints.nova.infra.admin.user.password.forgottenPassword.POST, { manual: true });

    const closeModal = () => {
        reset();
        onClose?.();
    };

    const handleForgottenPasswordRequest = async (data: ForgottenPasswordRequest) => {
        const forgotPasswordResponse = await forgottenPasswordRequest({
            headers: { 'x-username': data.usrUserName } as Required<Pick<RequestHeaderParams, 'x-username'>>,
            data,
        });

        if (forgotPasswordResponse.status === HttpStatusCodeEnum.Ok) {
            if (
                forgotPasswordResponse.data.success &&
                forgotPasswordResponse.data.success === ForgottenPasswordResponseSuccessEnum.SUCCESS
            ) {
                message({
                    variant: MessageTypeEnum.success,
                    message: forgotPasswordResponse.data.coreInfoMessageId,
                });
                setConfirmModalShow(false);
                closeModal();
            } else {
                setConfirmModalShow(true);
            }
        } else {
            setConfirmModalShow(false);
        }
    };

    const onSubmit = async (formData: ForgotPasswordModalFormValues) => {
        handleForgottenPasswordRequest({ changeConfirmed: ChangeConfirmedEnum.NO, usrUserName: formData.registryNo });
    };

    return (
        <>
            <Modal maxWidth="xs" show={show} onClose={closeModal}>
                <ModalTitle>{t(locale.contentTitles.auth.password.forgot)}</ModalTitle>
                <ModalBody sx={{ textAlign: 'center' }}>
                    <Grid py={2} px={{ xs: 2, sm: 10 }}>
                        <GridItem>
                            <RegistryNoInput
                                name="registryNo"
                                control={control}
                                label={t(locale.labels.registryNumber)}
                            />
                        </GridItem>
                    </Grid>
                </ModalBody>
                <ModalFooter>
                    <Grid justifyContent="center" spacingType="button">
                        <GridItem xs={false}>
                            <Button onClick={handleSubmit(onSubmit)} text={t(locale.buttons.send)} />
                        </GridItem>
                        <GridItem xs={false}>
                            <Button
                                text={t(locale.buttons.giveUp)}
                                onClick={closeModal}
                                variant="outlined"
                                color="error"
                            />
                        </GridItem>
                    </Grid>
                </ModalFooter>
            </Modal>
            <ConfirmModal
                show={confirmModalShow}
                body={forgottenPasswordResponseData?.confirmationMessage || ''}
                title={t(locale.contentTitles.auth.password.reset)}
                actionProps={{
                    cancelProps: {
                        color: 'error',
                        variant: 'outlined',
                    },
                }}
                modalFooterProps={{
                    sx: {
                        [`.${gridClasses.root}`]: { flexDirection: 'row-reverse' },
                    },
                }}
                cancelText={t(locale.buttons.giveUp)}
                okText={t(locale.buttons.reset)}
                onClose={() => {
                    setConfirmModalShow(false);
                }}
                onConfirm={(status) => {
                    if (status) {
                        handleForgottenPasswordRequest({
                            changeConfirmed: ChangeConfirmedEnum.YES,
                            usrUserName: getValues('registryNo'),
                        });
                    } else {
                        setConfirmModalShow(false);
                    }
                }}
            />
        </>
    );
};

export default ForgotPasswordModal;
