import type { IModalProps } from 'seker-ui';
import type {
    AuthenticateResponse,
    DelegatingUsersItem,
    GetDelegatingUsersResponse,
    SetDelegationParametersResponse,
} from '../../../../../..';

export enum DelegateUserOptionValueEnum {
    For_MySelf = '0',
    For_DelegatedOtherUser = '1',
}

export type DelegationSelectionFormValues = {
    delegatedUser: string;
    delegatedUserOption: `${DelegateUserOptionValueEnum}`;
};

export type DelegationSelectionReturnData = Partial<SetDelegationParametersResponse> & {
    selectedDelegatedUser: DelegatingUsersItem | null;
};

export type DelegationSelectionModalProps = Pick<IModalProps, 'show'> &
    Pick<GetDelegatingUsersResponse, 'delegatingUsers'> & {
        authenticateResponseData: AuthenticateResponse;
        onSelect: (delegationSelectedData: DelegationSelectionReturnData | null) => void;
    };
