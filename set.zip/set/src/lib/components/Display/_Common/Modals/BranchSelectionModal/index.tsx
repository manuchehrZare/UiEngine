/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect } from 'react';
import {
    Button,
    Grid,
    GridItem,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    Select,
    importantStyle,
    message,
    theme,
    useForm,
    validation,
} from 'seker-ui';
import type { BranchSelectionFormValues, BranchSelectionModalProps } from './type';
import type {
    ISetChargedOrganizationRequest,
    ISetChargedOrganizationResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
    ReferenceDataResultListItemsListItem,
} from '../../../../..';
import {
    GlobalsItemEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getAuthorization,
    getGlobalsData,
    getXUserName,
    useAxios,
    useTranslation,
} from '../../../../..';
import { TouchAppOutlined } from '@mui/icons-material';

const BranchSelectionModal: FC<BranchSelectionModalProps> = ({ show, onClose, authenticateResponseData, onSelect }) => {
    const { t, locale } = useTranslation();

    const { control, handleSubmit, setValue, reset } = useForm<BranchSelectionFormValues>({
        defaultValues: {
            branch:
                /**
                 * The initial value should be the chargedOrganizationOid value in globals.
                 */
                getGlobalsData({
                    key: GlobalsItemEnum.ChargedOrganizationOID,
                    sourceData: authenticateResponseData?.globals,
                }) || '',
        },
        validationSchema: {
            branch: validation.string(t(locale.labels.branch), { required: true, selectable: true }),
        },
    });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                headers: {
                    Authorization: getAuthorization(authenticateResponseData?.token) || '',
                    'x-username': getXUserName(authenticateResponseData?.globals) || '',
                },
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID],
                    }),
                },
            },
            { manual: true },
        );

    const [, setChargedOrganizationRequest] = useAxios<ISetChargedOrganizationResponse, ISetChargedOrganizationRequest>(
        {
            ...constants.api.endpoints.nova.infra.admin.user.setChargedOrganization,
            headers: {
                Authorization: getAuthorization(authenticateResponseData?.token) || '',
                'x-username': getXUserName(authenticateResponseData?.globals) || '',
            },
        },
        { manual: true },
    );

    const getBranchReferenceDataList = (): ReferenceDataResultListItemsListItem[] => {
        /**
         * ChargedOrganizationCode and ChargedOtherOrganizationCode values should be shown in the list.
         * ChargedOrganizationCode value should appear at the top position.
         */
        const refList: ReferenceDataResultListItemsListItem[] = [];
        const referenceDatasResultListItems = referenceDatas?.resultList?.find(
            (item: any) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
        )?.items;
        if (referenceDatasResultListItems) {
            const chargedOrganizationCodeRefData = referenceDatasResultListItems.find((item: any) =>
                item.value.includes(
                    getGlobalsData({
                        key: GlobalsItemEnum.ChargedOrganizationCode,
                        sourceData: authenticateResponseData.globals,
                    }) || '',
                ),
            );
            const chargedOtherOrganizationCodeRefData = referenceDatasResultListItems.find((item: any) =>
                item.value.includes(
                    getGlobalsData({
                        key: GlobalsItemEnum.ChargedOtherOrganizationCode,
                        sourceData: authenticateResponseData.globals,
                    }) || '',
                ),
            );
            chargedOrganizationCodeRefData && refList.push(chargedOrganizationCodeRefData);
            chargedOtherOrganizationCodeRefData && refList.push(chargedOtherOrganizationCodeRefData);
        }
        return refList;
    };

    const closeModal = () => {
        onClose?.();
        reset();
    };

    const onSubmit = async (formData: BranchSelectionFormValues) => {
        const currentData = getGlobalsData({
            key: GlobalsItemEnum.ChargedOrganizationOID,
            sourceData: authenticateResponseData.globals,
        });

        if (currentData) {
            if (currentData !== formData.branch) {
                const selectedData =
                    referenceDatas?.resultList
                        ?.find((item: any) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID)
                        ?.items?.find((subItem: any) => subItem.key === formData.branch) || null;

                const chargedOtherOrganizationOidGlobalsData = getGlobalsData({
                    key: GlobalsItemEnum.ChargedOtherOrganizationCode,
                    sourceData: authenticateResponseData.globals,
                });

                if (chargedOtherOrganizationOidGlobalsData) {
                    const setChargedOrganizationResponse = await setChargedOrganizationRequest({
                        data: {
                            orgOid: selectedData?.key || chargedOtherOrganizationOidGlobalsData,
                        },
                    });
                    if (setChargedOrganizationResponse.status === HttpStatusCodeEnum.Ok) {
                        onSelect?.(selectedData);
                        reset();
                    }
                }
            } else {
                closeModal();
            }
        }
    };

    useEffect(() => {
        show && referenceDataCall();
    }, [show]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.branchSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="xs"
            show={Boolean(
                show &&
                    referenceDatas &&
                    referenceDatas?.resultList?.length > 0 &&
                    referenceDatas?.resultList?.find(
                        (item: any) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                    )?.items,
            )}
            onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.branchSelection)}</ModalTitle>
            <ModalBody sx={{ py: importantStyle(theme.spacing(2)), px: { xs: 2, sm: 5 } }}>
                <Grid spacingType="form">
                    <GridItem>
                        <Select
                            name="branch"
                            control={control}
                            setValue={setValue}
                            label={t(locale.labels.branchToBeContinued)}
                            options={{
                                data: !referenceDatasLoading ? getBranchReferenceDataList() : [],
                                displayField: 'value',
                                displayValue: 'key',
                            }}
                        />
                    </GridItem>
                </Grid>
            </ModalBody>
            <ModalFooter>
                <Grid justifyContent="center" spacingType="button">
                    <GridItem xs={false}>
                        <Button
                            onClick={handleSubmit(onSubmit)}
                            text={t(locale.buttons.choose)}
                            iconLeft={<TouchAppOutlined />}
                        />
                    </GridItem>
                </Grid>
            </ModalFooter>
        </Modal>
    );
};

export default BranchSelectionModal;
