import { SaveOutlined } from '@mui/icons-material';
import type { FC } from 'react';
import {
    Button,
    Grid,
    GridItem,
    importantStyle,
    message,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    theme as sekerUITheme,
    useForm,
    validation,
    ValidationsCompareTypeEnum,
} from 'seker-ui';
import type { ChangePasswordFormValues, ChangePasswordModalProps } from './type';
import type {
    ChangePasswordRequest,
    ChangePasswordResponse,
    RequestHeaderParams,
    ResponseError,
} from '../../../../../..';
import {
    constants,
    getAuthorization,
    getGlobalsData,
    GlobalsItemEnum,
    PasswordInformations,
    PasswordInput,
    useAxios,
    useTranslation,
} from '../../../../../..';
import { HttpStatusCodeEnum } from '../../../../../../utils';

const ChangePasswordModal: FC<ChangePasswordModalProps> = ({ authenticateResponseData, show, onSuccessSave }) => {
    const { t, locale } = useTranslation();

    const { control, handleSubmit } = useForm<ChangePasswordFormValues>({
        defaultValues: {
            userNewPassword2: '',
            userNewPassword: '',
            userOldPassword: '',
        },
        validationSchema: {
            userNewPassword: validation.password({
                fieldLabel: t(locale.labels.newPassword),
                required: true,
                compare: [
                    {
                        fieldName: 'userOldPassword',
                        type: ValidationsCompareTypeEnum.NotEqual,
                        fieldLabel: t(locale.labels.oldPassword),
                    },
                    {
                        fieldName: 'userNewPassword2',
                        type: ValidationsCompareTypeEnum.Equal,
                        fieldLabel: t(locale.labels.newPasswordAgain),
                    },
                ],
            }),
            userNewPassword2: validation.password({
                fieldLabel: t(locale.labels.newPasswordAgain),
                required: true,
                compare: [
                    {
                        fieldName: 'userNewPassword',
                        type: ValidationsCompareTypeEnum.Equal,
                        fieldLabel: t(locale.labels.newPassword),
                    },
                    {
                        fieldName: 'userOldPassword',
                        type: ValidationsCompareTypeEnum.NotEqual,
                        fieldLabel: t(locale.labels.oldPassword),
                    },
                ],
            }),
            userOldPassword: validation.password({
                fieldLabel: t(locale.labels.oldPassword),
                required: true,
            }),
        },
    });

    const [, changePasswordRequest] = useAxios<ChangePasswordResponse, ChangePasswordRequest, ResponseError>(
        constants.api.endpoints.nova.infra.admin.user.password.changePassword.POST,
        { manual: true },
    );

    const onSubmit = async (formData: ChangePasswordFormValues) => {
        const changePasswordResponse = await changePasswordRequest({
            headers: {
                Authorization: getAuthorization(authenticateResponseData.token),
                'x-username': getGlobalsData({
                    key: GlobalsItemEnum.UserName,
                    sourceData: authenticateResponseData.globals,
                }),
            } as Required<Pick<RequestHeaderParams, 'Authorization' | 'x-username'>>,
            data: {
                ...formData,
                userOid:
                    getGlobalsData({
                        key: GlobalsItemEnum.UserOID,
                        sourceData: authenticateResponseData.globals,
                    }) || '',
            },
        });

        if (changePasswordResponse.status === HttpStatusCodeEnum.Ok) {
            if (changePasswordResponse.data.coreInfoMessageId) {
                message({
                    message: changePasswordResponse.data.coreInfoMessageId,
                    variant: MessageTypeEnum.success,
                });
                onSuccessSave?.(formData);
            }
        }
    };

    return (
        <Modal maxWidth="xs" show={show} allowClose={false} closeIcon={false}>
            <ModalTitle>{t(locale.contentTitles.auth.password.change)}</ModalTitle>
            <ModalBody sx={{ py: importantStyle(sekerUITheme.spacing(2)), px: { xs: 2, sm: 5 } }}>
                <Grid spacing={constants.design.grid.spacing.form.row.SET.unit}>
                    <GridItem>
                        <PasswordInput
                            name="userOldPassword"
                            deps={['userNewPassword', 'userNewPassword2']}
                            control={control}
                            label={t(locale.labels.oldPassword)}
                        />
                    </GridItem>
                    <GridItem>
                        <PasswordInput
                            name="userNewPassword"
                            deps="userNewPassword2"
                            control={control}
                            label={t(locale.labels.newPassword)}
                        />
                    </GridItem>
                    <GridItem>
                        <PasswordInput
                            name="userNewPassword2"
                            deps="userNewPassword"
                            control={control}
                            label={t(locale.labels.newPasswordAgain)}
                        />
                    </GridItem>
                    <GridItem>
                        <PasswordInformations />
                    </GridItem>
                </Grid>
            </ModalBody>
            <ModalFooter>
                <Grid justifyContent="center" spacingType="button">
                    <GridItem xs={false}>
                        <Button
                            onClick={handleSubmit(onSubmit)}
                            text={t(locale.buttons.save)}
                            iconLeft={<SaveOutlined />}
                        />
                    </GridItem>
                </Grid>
            </ModalFooter>
        </Modal>
    );
};

export default ChangePasswordModal;
