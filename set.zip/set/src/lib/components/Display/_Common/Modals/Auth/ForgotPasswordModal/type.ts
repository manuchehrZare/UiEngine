import type { IModalProps } from 'seker-ui';
import type { LoginFormValues } from '../../../../../App/Auth/Login/type';

export type ForgotPasswordModalProps = Pick<IModalProps, 'show' | 'onClose'>;

export type ForgotPasswordModalFormValues = Pick<LoginFormValues, 'registryNo'>;
