import type { IModalProps } from 'seker-ui';
import type { AuthenticateResponse, ChangePasswordRequest } from '../../../../../..';

export type ChangePasswordFormValues = Pick<
    ChangePasswordRequest,
    'userNewPassword' | 'userNewPassword2' | 'userOldPassword'
>;

export type ChangePasswordModalProps = Pick<IModalProps, 'show'> & {
    authenticateResponseData: AuthenticateResponse;
    onSuccessSave: (formData: ChangePasswordFormValues) => void;
};
