import type { FC, JSX } from 'react';
import { Box, Grid, GridItem, Modal, ModalBody, ModalTitle, Paper } from 'seker-ui';
import type { ICustomerInfoModal } from '../type';
import { constants, useTranslation } from '../../../../../../../utils';

const CustomerInfoModal: FC<ICustomerInfoModal> = ({ showModal, setModalProps, modalBody }): JSX.Element => {
    const { t, locale } = useTranslation();
    return (
        <Modal show={showModal} onClose={() => setModalProps({ showModal: false, modalBody: '' })} maxWidth="sm">
            <ModalTitle>{t(locale.contentTitles.infoNote)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem>
                                    <Box textAlign="center">{modalBody}</Box>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default CustomerInfoModal;
