/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type {
    ICustImageDmsListRequest,
    ICustImageDmsListResponse,
    ICustomerInfoButtonProps,
    IDmsDocGetDocContentRequest,
    IDmsDocGetDocContentResponse,
    IDmsIcmIsMigratedToIcmRequest,
    IDmsIcmIsMigratedToIcmResponse,
} from '../type';
import { ImageTypeEnum } from '../type';
import { Button, GridItem, PdfViewer, fileDownloader } from 'seker-ui';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../../utils';
import { useAxios } from '../../../../../../..';

const CustomerInfoButton: FC<ICustomerInfoButtonProps> = ({
    customerOid,
    disableSignature,
    disablePhotograph,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [docHttpUrl, setDocHttpUrl] = useState('');
    const [itemId, setItemId] = useState('');
    const [show, setShow] = useState(false);
    const [imageType, setImageType] = useState<number>();

    const [, custCustImageDmsList] = useAxios<ICustImageDmsListResponse, ICustImageDmsListRequest>(
        getGenericSetCaller(GenericSetCallerEnum.CUST_CUST_IMAGE_DMS_LIST),
        { manual: true },
    );
    const [, dmsIcmIsMigratedToIcm] = useAxios<IDmsIcmIsMigratedToIcmResponse, IDmsIcmIsMigratedToIcmRequest>(
        getGenericSetCaller(GenericSetCallerEnum.DMS_ICM_IS_MIGRATED_TO_ICM),
        { manual: true },
    );
    const [dmsDocGetDocContentData, dmsDocGetDocContent] = useAxios<
        IDmsDocGetDocContentResponse,
        IDmsDocGetDocContentRequest
    >(getGenericSetCaller(GenericSetCallerEnum.DMS_DOC_GET_DOC_CONTENT), { manual: true });

    async function getCustImageDmsList(custImageType: number) {
        const response = await custCustImageDmsList({
            data: {
                customerOid: customerOid,
                custImageType: custImageType,
            },
        });
        setDocHttpUrl('');
        if (response.status === HttpStatusCodeEnum.Ok) {
            setDocHttpUrl(response.data.custImageTable[0].imageUrl);
        }
    }
    async function getDmsIcmIsMigratedToIcm() {
        const dmsIcmIsMigratedToIcmResponse = await dmsIcmIsMigratedToIcm({
            data: {
                docHttpUrl: docHttpUrl,
            },
        });
        setItemId('');
        if (dmsIcmIsMigratedToIcmResponse.status === HttpStatusCodeEnum.Ok) {
            setItemId(dmsIcmIsMigratedToIcmResponse.data.itemId);
        }
    }
    async function getDmsDocGetDocContent() {
        const dmsDocGetDocContentResponse = await dmsDocGetDocContent({
            data: {
                itemId: itemId,
            },
        });
        if (dmsDocGetDocContentResponse.status === HttpStatusCodeEnum.Ok) {
            const response = dmsDocGetDocContentResponse.data;
            if (imageType === ImageTypeEnum.Signature) {
                fileDownloader({
                    fileName: response.localFileName,
                    source: response.content,
                    sourceType: 'pdf',
                });
            }
        }
    }

    useEffect(() => {
        if (docHttpUrl && docHttpUrl !== '') {
            getDmsIcmIsMigratedToIcm();
        }
    }, [docHttpUrl]);

    useEffect(() => {
        if (itemId && itemId !== '') {
            getDmsDocGetDocContent();
        }
    }, [itemId]);

    const closeModal = () => {
        show && setShow(false);
    };

    return (
        <>
            <GridItem>
                <Button
                    text={t(locale.buttons.photograph)}
                    variant="outlined"
                    fullWidth
                    disabled={!disablePhotograph}
                    onClick={async () => {
                        setImageType(ImageTypeEnum.Photograph);
                        await getCustImageDmsList(ImageTypeEnum.Photograph);
                        setShow(true);
                    }}
                />
            </GridItem>
            <GridItem>
                <Button
                    text={t(locale.buttons.signature)}
                    variant="outlined"
                    fullWidth
                    disabled={!disableSignature}
                    onClick={async () => {
                        setImageType(ImageTypeEnum.Signature);
                        await getCustImageDmsList(ImageTypeEnum.Signature);
                    }}
                />
            </GridItem>
            <PdfViewer
                source={dmsDocGetDocContentData?.data?.content || ''}
                modal
                modalProps={{
                    show,
                    onClose: closeModal,
                    title: t(locale.contentTitles.photograph),
                }}
            />
        </>
    );
};
export default CustomerInfoButton;
