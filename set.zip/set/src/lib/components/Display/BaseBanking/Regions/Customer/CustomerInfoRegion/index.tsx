import { useState, type JSX } from 'react';
import type { FieldValues, Path } from 'seker-ui';
import {
    Button,
    Checkbox,
    DatePicker,
    Grid,
    GridItem,
    Input,
    NumberInput,
    Select,
    View,
    formHelperTextClasses,
    useWatch,
} from 'seker-ui';
import type { ICustomerInfoRegionProps, IModalProps } from './type';
import { CustomerTypeEnum, CustomerWarningEnum, dataIndvCustomerTypeData } from './type';
import CustomerInfoModal from './CustomerInfoModal';
import CustomerInfoButton from './CustomerInfoButton';
import { toString } from 'lodash';
import type { ICoreData, ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    generateReferenceDataRequestList,
    getReferenceData,
    stringDateToUnixtime,
    useTranslation,
} from '../../../../../../utils';
import { ModalViewer, useAxios } from '../../../../../..';

const CustomerInfoRegion = <T extends FieldValues>({
    formProps: { control, setValue, reset },
    componentProps,
}: ICustomerInfoRegionProps<T>): JSX.Element => {
    const { t, locale } = useTranslation();
    const [customerInfoModalProps, setCustomerInfoModalProps] = useState<IModalProps>({
        showModal: false,
        modalBody: '',
    });
    const [customerInfo, setCustomerInfo] = useState<ICoreData>();

    const [potentialTargetDateVal, potentialVal] = useWatch({
        control: control,
        fieldName: [
            componentProps?.datePickerProps?.potentialTargetDate?.name as string,
            componentProps?.checkboxProps?.potential?.name as string,
        ],
    } as any);

    const [{ data: referenceDatas }] = useAxios<ReferenceDataResponse, ReferenceDataRequest>(
        {
            ...constants.api.endpoints.nova.gateway.referenceData.POST,
            data: {
                requestList: generateReferenceDataRequestList({
                    nameList: [
                        ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE,
                        ReferenceDataEnum.PRM_CUST_ACTIVE_STATUS,
                        ReferenceDataEnum.PRM_CUST_NATIONALITY,
                        ReferenceDataEnum.PRM_CUST_POTENTIAL_SOURCE,
                        ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                    ],
                }),
            },
        },
        { manual: false },
    );

    const customerStatusInfo = () => {
        if (
            customerInfo &&
            customerInfo?.isFollowed === CustomerWarningEnum.ISFOLLOWED &&
            customerInfo?.isInBlockGroup === CustomerWarningEnum.INBLOCKGROUP
        ) {
            return `${t(locale.labels.block)} - ${t(locale.labels.followed)}`;
        } else if (customerInfo?.isFollowed === CustomerWarningEnum.ISFOLLOWED) {
            return t(locale.labels.followed);
        }
        return t(locale.labels.block);
    };

    return (
        <Grid spacingType="form">
            <GridItem
                md={constants.design.gridItem.sizeType.form.SET.md * 3}
                lg={constants.design.gridItem.sizeType.form.SET.lg * 4}
                xl={constants.design.gridItem.sizeType.form.SET.xl * 5}
                xxl={constants.design.gridItem.sizeType.form.SET.xxl * 7}>
                <Grid
                    spacingType="form"
                    columns={{
                        xs: constants.design.gridItem.sizeType.form.SET.xs,
                        sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                        md: constants.design.gridItem.sizeType.form.SET.md * 3,
                        lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                        xl: constants.design.gridItem.sizeType.form.SET.xl * 5,
                        xxl: constants.design.gridItem.sizeType.form.SET.xxl * 7,
                    }}>
                    <GridItem sizeType="form">
                        <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                            component="NumberInput"
                            modalComponent={SETModalsEnum.CustomerInquiryModal}
                            control={control}
                            adornmentButtonProps={{
                                tooltip: t(locale.contentTitles.customerInquiry),
                            }}
                            {...componentProps?.numberInputProps?.customerCode}
                            modalProps={{
                                onReturnData: (data: any) => {
                                    if (data) {
                                        reset({
                                            [componentProps.numberInputProps.customerCode.name]: String(
                                                data?.customerCode,
                                            ),
                                            [componentProps.numberInputProps.tcId.name]: data?.tcId,
                                            [componentProps.numberInputProps.taxNo.name]: data?.taxNo,
                                            [componentProps.checkboxProps.nonActive.name]: Boolean(data?.nonActive),
                                            [componentProps.checkboxProps.potential.name]: Boolean(data?.potential),
                                            [componentProps.checkboxProps.sharedCustomer.name]: Boolean(
                                                data?.sharedCustomer,
                                            ),
                                            [componentProps.datePickerProps.beginDate.name]: data?.beginDate
                                                ? stringDateToUnixtime(String(data?.beginDate))
                                                : null,
                                            [componentProps.datePickerProps.birthday.name]: data?.birthday
                                                ? stringDateToUnixtime(String(data?.birthday))
                                                : null,
                                            [componentProps.datePickerProps.endDate.name]: data?.endDate
                                                ? stringDateToUnixtime(String(data?.endDate))
                                                : null,
                                            [componentProps.datePickerProps.passiveToActiveDate.name]:
                                                data?.passiveToActiveDate
                                                    ? stringDateToUnixtime(String(data?.passiveToActiveDate))
                                                    : null,
                                            [componentProps.datePickerProps.potentialDate.name]: data?.potentialDate
                                                ? stringDateToUnixtime(String(data?.potentialDate))
                                                : null,
                                            [componentProps.datePickerProps.potentialTargetDate.name]:
                                                data?.potentialTargetDate
                                                    ? stringDateToUnixtime(String(data?.potentialTargetDate))
                                                    : null,
                                            [componentProps.datePickerProps.updateDate.name]: data?.updateDate
                                                ? stringDateToUnixtime(String(data?.updateDate))
                                                : null,
                                            [componentProps.inputProps.endUser.name]: toString(data?.endUser),
                                            [componentProps.inputProps.name.name]: toString(data?.name),
                                            [componentProps.inputProps.passiveToActiveUser.name]: toString(
                                                data?.passiveToActiveUser,
                                            ),
                                            [componentProps.inputProps.potentialUser.name]: toString(
                                                data?.potentialUser,
                                            ),
                                            [componentProps.inputProps.secondName.name]: toString(data?.secondName),
                                            [componentProps.inputProps.surname.name]: toString(data?.surname),
                                            [componentProps.inputProps.title.name]: toString(data?.title),
                                            [componentProps.inputProps.userCreated.name]: toString(data?.userCreated),
                                            [componentProps.inputProps.userUpdated.name]: toString(data?.userUpdated),
                                            [componentProps.selectProps.activeStatus.name]: data?.activeStatus,
                                            [componentProps.selectProps.country.name]: data?.country,
                                            [componentProps.selectProps.individualCorporate.name]:
                                                data?.individualCorporate,
                                            [componentProps.selectProps.individualFarmer.name]: data?.individualFarmer,
                                            [componentProps.selectProps.individualIndividual.name]:
                                                data?.individualIndividual,
                                            [componentProps.selectProps.mainBranchCode.name]: toString(
                                                data?.mainBranchCode,
                                            ),
                                            [componentProps.selectProps.nationality.name]: data?.nationality,
                                            [componentProps.selectProps.potentialSource.name]: data?.potentialSource,
                                            [componentProps.inputProps.customerStatus.name]: data?.customerType,
                                        } as T);
                                        setCustomerInfo(data);
                                        if (data?.potential === 1 && Number(data?.active) === 1) {
                                            setValue(
                                                componentProps.inputProps.customerStatus.name as Path<T>,
                                                // @ts-ignore
                                                t(locale.contentTitles.potential),
                                            );
                                        } else if (data?.nonActive === 1) {
                                            setValue(
                                                componentProps.inputProps.customerStatus.name as Path<T>,
                                                // @ts-ignore
                                                t(locale.contentTitles.close),
                                            );
                                        } else {
                                            setValue(
                                                componentProps.inputProps.customerStatus.name as Path<T>,
                                                // @ts-ignore
                                                t(locale.contentTitles.open),
                                            );
                                        }
                                    }
                                    componentProps?.numberInputProps?.customerCode?.modalProps?.onReturnData?.(data);
                                },
                            }}
                            helperText={
                                customerInfo?.isFollowed === CustomerWarningEnum.ISFOLLOWED ||
                                customerInfo?.isInBlockGroup === CustomerWarningEnum.INBLOCKGROUP
                                    ? customerStatusInfo()
                                    : ''
                            }
                            sx={{
                                [`.${formHelperTextClasses.root}`]: {
                                    fontWeight: 'bold',
                                    color: (theme) => theme.palette.error.main,
                                },
                            }}
                            name={componentProps.numberInputProps.customerCode.name as string}
                            label={componentProps?.numberInputProps.customerCode.label || t(locale.labels.customerCode)}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Select
                            control={control}
                            setValue={setValue}
                            options={{
                                data: getReferenceData({
                                    referenceDatas,
                                    referenceDataName: ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE,
                                }),
                                displayField: 'value',
                                displayValue: 'key',
                                renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                renderDisplayList: (params) => `${params.key} - ${params.value}`,
                            }}
                            displayEmpty
                            disabled
                            {...componentProps?.selectProps?.mainBranchCode}
                            label={componentProps?.selectProps.mainBranchCode.label || t(locale.labels.branch)}
                            name={componentProps.selectProps.mainBranchCode.name as string}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Input
                            control={control}
                            disabled
                            {...componentProps?.inputProps?.customerStatus}
                            label={componentProps?.inputProps.customerStatus.label || t(locale.labels.customerStatus)}
                            name={componentProps.inputProps.customerStatus.name as string}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Select
                            control={control}
                            setValue={setValue}
                            options={{
                                data: getReferenceData({
                                    referenceDatas,
                                    referenceDataName: ReferenceDataEnum.PRM_CUST_ACTIVE_STATUS,
                                }),
                                displayField: 'value',
                                displayValue: 'key',
                            }}
                            displayEmpty
                            disabled
                            {...componentProps?.selectProps?.activeStatus}
                            label={componentProps?.selectProps.activeStatus.label || t(locale.labels.customerActive)}
                            name={componentProps.selectProps.activeStatus.name as string}
                        />
                    </GridItem>
                    <View show={Number(customerInfo?.customerType) === CustomerTypeEnum.INDIVIDUAL}>
                        <GridItem sizeType="form">
                            <NumberInput
                                control={control}
                                disabled
                                {...componentProps?.numberInputProps?.tcId}
                                label={componentProps?.numberInputProps.tcId.label || t(locale.labels.tcId_no)}
                                name={componentProps.numberInputProps.tcId.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Grid spacingType="joinedForm">
                                <GridItem xs={6}>
                                    <Input
                                        control={control}
                                        disabled
                                        {...componentProps?.inputProps?.name}
                                        label={componentProps?.inputProps.name.label || t(locale.labels.nameSecondName)}
                                        name={componentProps.inputProps.name.name as string}
                                    />
                                </GridItem>
                                <GridItem xs={6}>
                                    <Input
                                        control={control}
                                        disabled
                                        {...componentProps?.inputProps?.secondName}
                                        name={componentProps.inputProps.secondName.name as any}
                                    />
                                </GridItem>
                            </Grid>
                        </GridItem>
                        <GridItem sizeType="form">
                            <Input
                                control={control}
                                disabled
                                {...componentProps?.inputProps?.surname}
                                label={componentProps?.inputProps.surname.label || t(locale.labels.surname)}
                                name={componentProps.inputProps.surname.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <DatePicker
                                control={control}
                                unixTime
                                disabled
                                {...componentProps?.datePickerProps?.birthday}
                                label={componentProps?.datePickerProps.birthday.label || t(locale.labels.birthDate)}
                                name={componentProps.datePickerProps.birthday.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Select
                                control={control}
                                setValue={setValue}
                                options={{
                                    data: getReferenceData({
                                        referenceDatas,
                                        referenceDataName: ReferenceDataEnum.PRM_CUST_NATIONALITY,
                                    }),
                                    displayField: 'value',
                                    displayValue: 'key',
                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                }}
                                displayEmpty
                                disabled
                                {...componentProps?.selectProps?.nationality}
                                label={componentProps?.selectProps.nationality.label || t(locale.labels.nationality)}
                                name={componentProps.selectProps.nationality.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Select
                                control={control}
                                setValue={setValue}
                                options={{
                                    data: getReferenceData({
                                        referenceDatas,
                                        referenceDataName: ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                                    }),
                                    displayField: 'value',
                                    displayValue: 'key',
                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                }}
                                displayEmpty
                                disabled
                                {...componentProps?.selectProps?.country}
                                label={componentProps?.selectProps.country.label || t(locale.labels.country)}
                                name={componentProps.selectProps.country.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Select
                                control={control}
                                displayEmpty
                                setValue={setValue}
                                disabled
                                options={{
                                    data: dataIndvCustomerTypeData,
                                    displayField: 'value',
                                    displayValue: 'key',
                                }}
                                {...componentProps?.selectProps?.individualIndividual}
                                label={
                                    componentProps?.selectProps.individualIndividual.label ||
                                    t(locale.labels.individual)
                                }
                                name={componentProps.selectProps.individualIndividual.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Select
                                control={control}
                                displayEmpty
                                setValue={setValue}
                                disabled
                                options={{
                                    data: dataIndvCustomerTypeData,
                                    displayField: 'value',
                                    displayValue: 'key',
                                }}
                                {...componentProps?.selectProps?.individualCorporate}
                                label={componentProps?.selectProps.individualCorporate.label || t(locale.labels.gkti)}
                                name={componentProps.selectProps.individualCorporate.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Select
                                control={control}
                                displayEmpty
                                setValue={setValue}
                                disabled
                                options={{
                                    data: dataIndvCustomerTypeData,
                                    displayField: 'value',
                                    displayValue: 'key',
                                }}
                                {...componentProps?.selectProps?.individualFarmer}
                                label={
                                    componentProps?.selectProps.individualFarmer.label || t(locale.labels.agricultural)
                                }
                                name={componentProps.selectProps.individualFarmer.name as string}
                            />
                        </GridItem>
                    </View>
                    <View show={Number(customerInfo?.customerType) === CustomerTypeEnum.CORPORATE}>
                        <GridItem sizeType="form">
                            <NumberInput
                                control={control}
                                disabled
                                {...componentProps?.numberInputProps?.taxNo}
                                label={componentProps?.numberInputProps?.taxNo.label || t(locale.labels.taxIdNo)}
                                name={componentProps.numberInputProps?.taxNo.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <Input
                                control={control}
                                disabled
                                {...componentProps?.inputProps?.title}
                                label={
                                    componentProps?.inputProps?.title.label || t(locale.labels.commercialAppellation)
                                }
                                name={componentProps.inputProps?.title.name as string}
                            />
                        </GridItem>
                        <GridItem sizeType="form">
                            <DatePicker
                                control={control}
                                unixTime
                                disabled
                                {...componentProps?.datePickerProps?.birthday}
                                label={
                                    componentProps?.datePickerProps?.birthday.label ||
                                    t(locale.labels.establishmentDate)
                                }
                                name={componentProps.datePickerProps?.birthday.name as string}
                            />
                        </GridItem>
                    </View>
                    <View show={potentialTargetDateVal !== null && potentialVal === 1}>
                        <GridItem sizeType="form">
                            <DatePicker
                                control={control}
                                unixTime
                                disabled
                                {...componentProps?.datePickerProps?.potentialTargetDate}
                                label={
                                    componentProps?.datePickerProps?.potentialTargetDate.label ||
                                    t(locale.labels.targetDate)
                                }
                                name={componentProps.datePickerProps?.potentialTargetDate.name as string}
                            />
                        </GridItem>
                    </View>
                    <GridItem sizeType="form">
                        <Grid spacingType="joinedForm">
                            <GridItem xs={6}>
                                <Input
                                    control={control}
                                    disabled
                                    {...componentProps?.inputProps?.userCreated}
                                    label={componentProps?.inputProps?.userCreated.label || t(locale.labels.opening)}
                                    name={componentProps.inputProps?.userCreated.name as string}
                                />
                            </GridItem>
                            <GridItem xs={6}>
                                <DatePicker
                                    control={control}
                                    unixTime
                                    disabled
                                    {...componentProps?.datePickerProps?.beginDate}
                                    name={componentProps.datePickerProps?.beginDate.name as string}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem sizeType="form">
                        <Grid spacingType="joinedForm">
                            <GridItem xs={6}>
                                <Input
                                    control={control}
                                    disabled
                                    {...componentProps?.inputProps?.userUpdated}
                                    label={
                                        componentProps?.inputProps?.userUpdated.label || t(locale.labels.lastUpdated)
                                    }
                                    name={componentProps.inputProps?.userUpdated.name as string}
                                />
                            </GridItem>
                            <GridItem xs={6}>
                                <DatePicker
                                    control={control}
                                    unixTime
                                    disabled
                                    {...componentProps?.datePickerProps?.updateDate}
                                    name={componentProps.datePickerProps?.updateDate.name as string}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem sizeType="form">
                        <Grid spacingType="joinedForm">
                            <GridItem xs={6}>
                                <Input
                                    control={control}
                                    disabled
                                    {...componentProps?.inputProps?.passiveToActiveUser}
                                    label={
                                        componentProps?.inputProps?.passiveToActiveUser.label ||
                                        t(locale.labels.offActive)
                                    }
                                    name={componentProps.inputProps?.passiveToActiveUser.name as string}
                                />
                            </GridItem>
                            <GridItem xs={6}>
                                <DatePicker
                                    control={control}
                                    unixTime
                                    disabled
                                    {...componentProps?.datePickerProps?.passiveToActiveDate}
                                    name={componentProps.datePickerProps?.passiveToActiveDate.name as string}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <GridItem sizeType="form">
                        <Grid spacingType="joinedForm">
                            <GridItem xs={6}>
                                <Input
                                    control={control}
                                    disabled
                                    {...componentProps?.inputProps?.endUser}
                                    label={componentProps?.inputProps?.endUser.label || t(locale.labels.closing)}
                                    name={componentProps.inputProps?.endUser.name as string}
                                />
                            </GridItem>
                            <GridItem xs={6}>
                                <DatePicker
                                    control={control}
                                    unixTime
                                    disabled
                                    {...componentProps?.datePickerProps?.endDate}
                                    name={componentProps.datePickerProps?.endDate.name as string}
                                />
                            </GridItem>
                        </Grid>
                    </GridItem>
                    <View show={potentialVal}>
                        <GridItem sizeType="form">
                            <Grid spacingType="joinedForm">
                                <GridItem xs={6}>
                                    <Input
                                        control={control}
                                        disabled
                                        {...componentProps?.inputProps?.potentialUser}
                                        label={
                                            componentProps?.inputProps?.potentialUser.label ||
                                            t(locale.labels.potential)
                                        }
                                        name={componentProps.inputProps?.potentialUser.name as string}
                                    />
                                </GridItem>
                                <GridItem xs={6}>
                                    <DatePicker
                                        control={control}
                                        unixTime
                                        disabled
                                        {...componentProps?.datePickerProps?.potentialDate}
                                        name={componentProps.datePickerProps?.potentialDate.name as string}
                                    />
                                </GridItem>
                            </Grid>
                        </GridItem>
                        <GridItem sizeType="form">
                            <Select
                                control={control}
                                displayEmpty
                                setValue={setValue}
                                disabled
                                options={{
                                    data: getReferenceData({
                                        referenceDatas,
                                        referenceDataName: ReferenceDataEnum.PRM_CUST_POTENTIAL_SOURCE,
                                    }),
                                    displayField: 'value',
                                    displayValue: 'key',
                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                }}
                                {...componentProps?.selectProps?.potentialSource}
                                label={
                                    componentProps?.selectProps?.potentialSource.label ||
                                    t(locale.labels.potentialSource)
                                }
                                name={componentProps.selectProps?.potentialSource.name as string}
                            />
                        </GridItem>
                    </View>
                    <GridItem sizeType="form">
                        <Checkbox
                            control={control}
                            disabled
                            sx={{ pt: { sm: 2.4 } }}
                            {...componentProps?.checkboxProps?.potential}
                            label={componentProps?.checkboxProps?.potential.label || t(locale.labels.potentialCustomer)}
                            name={componentProps.checkboxProps?.potential.name as string}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Checkbox
                            control={control}
                            disabled
                            sx={{ pt: { sm: 2.4 } }}
                            {...componentProps?.checkboxProps?.sharedCustomer}
                            label={
                                componentProps?.checkboxProps?.sharedCustomer.label || t(locale.labels.jointCustomer)
                            }
                            name={componentProps.checkboxProps?.sharedCustomer.name as string}
                        />
                    </GridItem>
                    <GridItem sizeType="form">
                        <Checkbox
                            control={control}
                            disabled
                            sx={{ pt: { sm: 2.4 } }}
                            {...componentProps?.checkboxProps?.nonActive}
                            label={componentProps?.checkboxProps?.nonActive.label || t(locale.labels.close)}
                            name={componentProps.checkboxProps?.nonActive.name as string}
                        />
                    </GridItem>
                </Grid>
            </GridItem>
            <GridItem md pt={{ md: 3.25 }}>
                <Grid spacingType="button">
                    <GridItem>
                        <Button
                            text={t(locale.buttons.infoNote)}
                            variant="outlined"
                            fullWidth
                            disabled={!customerInfo?.infoNoteExists}
                            onClick={() => {
                                setCustomerInfoModalProps({
                                    showModal: true,
                                    modalBody: customerInfo?.infoNote || '',
                                });
                            }}
                            {...componentProps?.buttonProps?.infoNoteButton}
                        />
                    </GridItem>
                    <CustomerInfoButton
                        customerOid={toString(customerInfo?.oid)}
                        disableSignature={Boolean(customerInfo?.signatureExists)}
                        disablePhotograph={Boolean(customerInfo?.photoExists)}
                        {...componentProps?.buttonProps?.customerInfoButton}
                    />
                </Grid>
            </GridItem>
            <CustomerInfoModal
                showModal={customerInfoModalProps.showModal}
                setModalProps={setCustomerInfoModalProps}
                modalBody={customerInfoModalProps.modalBody}
            />
        </Grid>
    );
};

export default CustomerInfoRegion;
