import type {
    FieldValues,
    HelperFormProps,
    IButtonProps,
    ICheckboxProps,
    IDatePickerProps,
    IInputProps,
    INumberInputProps,
    ISelectProps,
} from 'seker-ui';
import type { SETModalsEnum } from '../../../../../../utils';
import { i18n, locale } from '../../../../../../utils';
import type { IModalViewerProps } from '../../../../../..';

type INumberInputType<T> = {
    [Property in keyof Pick<ICustomerInfoRegionFormValues, 'customerCode'>]: Pick<
        IModalViewerProps<SETModalsEnum.CustomerInquiryModal>,
        'adornmentButtonProps' | 'disabled' | 'modalProps' | 'sx'
    > &
        Pick<INumberInputProps, 'readOnly' | 'label'> & { name: keyof T };
} & Record<
    `${keyof Pick<ICustomerInfoRegionFormValues, 'taxNo' | 'tcId'>}`,
    Pick<INumberInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type IInputType<T> = Record<
    `${keyof Pick<ICustomerInfoRegionFormValues, 'customerStatus' | 'name' | 'secondName' | 'surname' | 'title' | 'userCreated' | 'userUpdated' | 'passiveToActiveUser' | 'endUser' | 'potentialUser'>}`,
    Pick<IInputProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type ISelectType<T> = {
    [Property in `${keyof Pick<ICustomerInfoRegionFormValues, 'mainBranchCode' | 'activeStatus' | 'nationality' | 'country' | 'individualIndividual' | 'individualCorporate' | 'individualFarmer' | 'potentialSource'>}`]: Pick<
        ISelectProps<ICustomerInfoRegionFormValues[Property]>,
        'disabled' | 'readOnly' | 'label'
    > & { name: keyof T };
};

type IDatePickerType<T> = Record<
    `${keyof Pick<ICustomerInfoRegionFormValues, 'birthday' | 'potentialTargetDate' | 'beginDate' | 'updateDate' | 'passiveToActiveDate' | 'endDate' | 'potentialDate'>}`,
    Pick<IDatePickerProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

type ICheckboxType<T> = Record<
    `${keyof Pick<ICustomerInfoRegionFormValues, 'potential' | 'sharedCustomer' | 'nonActive'>}`,
    Pick<ICheckboxProps, 'disabled' | 'readOnly' | 'label'> & { name: keyof T }
>;

interface IButtonComponentProps {
    customerInfoButton?: Pick<IButtonProps, 'disabled'>;
    infoNoteButton?: Pick<IButtonProps, 'disabled'>;
}

export interface ICustomerInfoRegionComponentProps<T> {
    buttonProps?: IButtonComponentProps;
    checkboxProps: ICheckboxType<T>;
    datePickerProps: IDatePickerType<T>;
    inputProps: IInputType<T>;
    numberInputProps: INumberInputType<T>;
    selectProps: ISelectType<T>;
}

export interface ICustomerInfoRegionFormValues {
    activeStatus: string;
    beginDate: number | null;
    birthday: number | null;
    country: string;
    customerCode: string;
    customerStatus: string;
    customerType: string;
    endDate: number | null;
    endUser: string | null;
    individualCorporate: number | null;
    individualFarmer: number | null;
    individualIndividual: number | null;
    infoNote: string | null;
    infoNoteExists: boolean;
    isFollowed: number | null;
    isInBlockGroup: number | null;
    mainBranchCode: string;
    name: string;
    nationality: number | null;
    nonActive: boolean;
    oid: string;
    passiveToActiveDate: number | null;
    passiveToActiveUser: string;
    photoExists: boolean;
    potential: boolean;
    potentialDate: number | null;
    potentialSource: string | null;
    potentialTargetDate: number | null;
    potentialUser: string;
    secondName: string;
    sharedCustomer: boolean;
    signatureExists: boolean;
    surname: string | null;
    taxNo: number | null;
    tcId: number | null;
    title: string | null;
    updateDate: number | null;
    userCreated: string;
    userUpdated: string;
}

export enum CustomerTypeEnum {
    CORPORATE = 2,
    INDIVIDUAL = 1,
    // eslint-disable-next-line
    POTENTIAL = 1,
}

export enum ImageTypeEnum {
    Photograph = 1,
    Signature = 2,
}

export enum IndividualCustomerTypeEnum {
    Yes = 1,
    No = 0,
}

export enum CustomerWarningEnum {
    INBLOCKGROUP = 1,
    // eslint-disable-next-line
    ISFOLLOWED = 1,
}

export interface ICustomerInfo {
    customerCode?: string;
    customerOid?: string;
}

export const dataIndvCustomerTypeData = [
    { key: IndividualCustomerTypeEnum.Yes, value: i18n.t(locale.contentTitles.yes) },
    { key: IndividualCustomerTypeEnum.No, value: i18n.t(locale.contentTitles.no2) },
];

export interface ICustomerInfoRegionProps<T extends FieldValues>
    extends HelperFormProps<T, 'control' | 'setValue' | 'reset'> {
    componentProps: ICustomerInfoRegionComponentProps<T>;
}

export interface ICustomerInfoModal {
    modalBody: string;
    setModalProps: (modalProps: IModalProps) => void;
    showModal: boolean;
}

export interface IModalProps {
    modalBody: string;
    showModal: boolean;
}

export interface ICustomerInfoButtonProps {
    customerOid: string;
    disablePhotograph: boolean;
    disableSignature: boolean;
}

export interface ICustImageDmsListRequest {
    custImageType: number;
    customerOid: string;
}

export interface ICustImageDmsListResponse {
    custImageTable: ICustImageDmsListResponseList[];
}

export interface ICustImageDmsListResponseList {
    createDate: string;
    imageOid: string;
    imageType: number;
    imageUrl: string;
}

export interface IDmsIcmIsMigratedToIcmRequest {
    docHttpUrl: string;
}

export interface IDmsIcmIsMigratedToIcmResponse {
    isMigratedIcm: number;
    itemId: string;
}

export interface IDmsDocGetDocContentRequest {
    itemId: string;
}

export interface IDmsDocGetDocContentResponse {
    autoGeneratedFileName: string;
    content: string;
    extension: string;
    fileSize: number;
    localFileName: string;
    mimeType: string;
    sizeInBytes: number;
}
