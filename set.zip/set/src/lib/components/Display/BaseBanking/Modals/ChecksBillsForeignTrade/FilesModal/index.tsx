/* eslint-disable react-hooks/exhaustive-deps */
import { CleaningServices, ManageSearchOutlined } from '@mui/icons-material';
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Alert,
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
} from 'seker-ui';
import type {
    ReferenceDataRequest,
    ReferenceDataResponse,
    IFtiImportGetFilesForPopupV2Response,
    IFtiImportGetFilesForPopupV2Request,
    IFtiImportGetFilesForPopupV2CoreData as ICoreData,
} from '../../../../../..';
import {
    GenericSetCallerEnum,
    ClosenessStatusDataEnum,
    HttpStatusCodeEnum,
    ModalViewer,
    SETModalsEnum,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useAxios,
    ReferenceDataEnum,
    useTranslation,
    constants,
} from '../../../../../..';
import FilesDataGrid from './FilesDataGrid';
import type { IFileModalFormValues, IFilesModalProps } from './type';
import { StateEnum } from './type';

const FilesModal: FC<IFilesModalProps> = ({
    show,
    formData,
    onClose,
    onReturnData,
    payloadData,
    componentProps,
    eventOwnerEl,
    inputProps,
}) => {
    const { t, locale } = useTranslation();
    const [filesDataGridData, setFilesDataGridData] = useState<ICoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, setValue, reset, getValues, handleSubmit } = useForm<IFileModalFormValues>({
        defaultValues: {
            branchCode: '',
            currencyCode: '',
            customerCode: '',
            fileNo: '',
            importerName: '',
            productType: '',
            state: StateEnum.Open,
        },
    });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_FTC_COMMON_IMPORT_PROCESS_TYPE,
                            ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_FTI_FILE_STATE,
                            ReferenceDataEnum.PRM_CURRENCY_CODE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: ftiImportGetFileListError }, ftiImportGetFileListCall] = useAxios<
        IFtiImportGetFilesForPopupV2Response,
        IFtiImportGetFilesForPopupV2Request
    >(getGenericSetCaller(GenericSetCallerEnum.FTI_IMPORT_GET_FILES_FOR_POPUP_V2), { manual: true });

    const resetModal = () => {
        reset();
        setFilesDataGridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IFileModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { fileNo: String(modalViewerInputWatch) }),
        ...formData,
    });

    const onSubmit = async (formValues: IFileModalFormValues) => {
        const response = await ftiImportGetFileListCall({
            data: {
                ...formValues,
                ...payloadData,
                branchCode: String(formValues.branchCode),
                currencyCode: String(formValues.currencyCode),
                customerCode: String(formValues.customerCode),
                fileNo: String(formValues.fileNo),
                productType: String(formValues.productType),
                state: String(formValues.state),
            },
        });

        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData) {
                setFilesDataGridData(responseData);
            } else {
                setFilesDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await ftiImportGetFileListCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData[0]);
                    setValue('productType', responseData[0].productType);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (ftiImportGetFileListError) {
            show && !modalShow && closeModal();
        }
    }, [ftiImportGetFileListError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.files),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.files)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        spacingType="form"
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="fileNo"
                                                label={t(locale.labels.fileNo)}
                                                {...componentProps?.inputProps?.fileNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="productType"
                                                label={t(locale.labels.importType)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_FTC_COMMON_IMPORT_PROCESS_TYPE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                setValue={setValue}
                                                control={control}
                                                readOnly
                                                {...componentProps?.selectProps?.productType}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="branchCode"
                                                label={t(locale.labels.branch)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList
                                                            ?.find(
                                                                (item) =>
                                                                    item.name ===
                                                                    ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_CODE,
                                                            )
                                                            ?.items?.sort((a, b) => {
                                                                return Number(a.key) - Number(b.key);
                                                            }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: (params) => `${params.key}-${params.value}`,
                                                    renderDisplayList: (params) => `${params.key}-${params.value}`,
                                                }}
                                                setValue={setValue}
                                                control={control}
                                                {...componentProps?.selectProps?.branchCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="customerCode"
                                                label={t(locale.labels.customer)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.customerInquiry),
                                                    disabled: false,
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('customerCode', String(data?.customerCode));
                                                        setValue('importerName', String(data?.nameTitle));
                                                    },
                                                    formData: {
                                                        custCustActive: ClosenessStatusDataEnum.NotClose,
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.customerCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="importerName"
                                                label={t(locale.labels.importerName)}
                                                control={control}
                                                readOnly
                                                {...componentProps?.inputProps?.importerName}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="currencyCode"
                                                label={t(locale.labels.currencyType)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) => item.name === ReferenceDataEnum.PRM_CURRENCY_CODE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                setValue={setValue}
                                                control={control}
                                                {...componentProps?.selectProps?.currencyCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="state"
                                                label={t(locale.labels.status)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name === ReferenceDataEnum.PRM_FTI_FILE_STATE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                setValue={setValue}
                                                control={control}
                                                {...componentProps?.selectProps?.state}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Alert type="warning" text={t(locale.notifications.filesPopupNoti)} />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                onClick={handleSubmit(onSubmit)}
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<ManageSearchOutlined />}
                                                fullWidth
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                onClick={resetModal}
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                fullWidth
                                                variant="outlined"
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={350}>
                                    <FilesDataGrid
                                        data={filesDataGridData}
                                        closeModal={closeModal}
                                        onReturnData={onReturnData}
                                        referenceDatas={referenceDatas}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default FilesModal;
