import type { FC, JSX } from 'react';
import { Grid, GridItem, Input } from 'seker-ui';
import type { ICustomerInquiryModalFormValues, IProps } from '../type';
import { constants, useTranslation } from '../../../../../../../utils';

const LegalInformations: FC<IProps<ICustomerInquiryModalFormValues>> = ({
    formProps: { control },
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    return (
        <Grid
            pt={0.5}
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 4,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 5,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 5,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 5,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Input
                    name="custCustTitle"
                    label={t(locale.labels.title)}
                    control={control}
                    maxLength={50}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custCustTitle}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    name="custCorpSignboard"
                    label={t(locale.labels.signBoardName)}
                    control={control}
                    maxLength={256}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custCorpSignboard}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    name="custCorpCommercialRecordNo"
                    label={t(locale.labels.commerceRegistryNo)}
                    control={control}
                    maxLength={16}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custCorpCommercialRecordNo}
                />
            </GridItem>
        </Grid>
    );
};

export default LegalInformations;
