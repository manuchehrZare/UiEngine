/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Modal,
    ModalBody,
    ModalTitle,
    useForm,
    Label,
    useWatch,
    View,
    message,
    MessageTypeEnum,
    Paper,
    Tab,
    TabItem,
    validation,
} from 'seker-ui';
import { CleaningServices, Search } from '@mui/icons-material';
import type { ICustomerInquiryModalFormValues, ICustomerInquiryModalProps } from './type';
import { CustomerTypeEnum } from './type';
import GeneralInformations from './GeneralInformations';
import LegalInformations from './LegalInformations';
import RealCustomer from './RealCustomer';
import GeneralInformationsDataGrid from './GeneralInformationsDataGrid';
import MobilePhone from './MobilePhone';
import type {
    ICoreData,
    ICustPersCustListAllRequest,
    ICustPersCustListAllResponse,
} from '../../../../../../utils/types/api/models/BaseBanking/customer/custPersCustListAll/type';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../..';
import {
    GenericSetCallerEnum,
    GlobalsItemEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    getGlobalsData,
    useAxios,
    useTranslation,
    ShowCorporateBranchComboEnum,
    TimeOutListEnum,
} from '../../../../../..';
import { omit, pick, toString } from 'lodash';
import type {
    ICustPersCustInTimeOutListRequest,
    ICustPersCustInTimeOutListResponse,
} from '../../../../../../utils/types/api/models/BaseBanking/customer/custPersCustInTimeOutList/type';
import type { ICustListBranchForKksComboResponse } from '../../../../../../utils/types/api/models/BaseBanking/customer/custListBranchForKksCombo/type';

const CustomerInquiryModal: FC<ICustomerInquiryModalProps> = ({
    show,
    formData,
    onClose,
    onReturnData,
    payloadData,
    componentProps,
    eventOwnerEl,
    inputProps,
}) => {
    const { t, locale } = useTranslation();
    const [activeTab, setActiveTab] = useState<`${CustomerTypeEnum}`>(CustomerTypeEnum.RealCustomerOption);
    const [generalInformationsDataGridData, setGeneralInformationsDataGridData] = useState<ICoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, setValue, reset, getValues, handleSubmit } = useForm<ICustomerInquiryModalFormValues>({
        defaultValues: {
            accCode: '',
            custCorpCommercialRecordNo: '',
            custCorpSignboard: '',
            custCustActive: '',
            custCustActiveStatus: '',
            custCustAreaCode: '',
            custCustCountryCode: '',
            custCustCountryName: '',
            custCustCustomerCode: '',
            custCustCustomerType: '',
            custCustMainBranchCode: '',
            custCustName: '',
            custCustPotential: '',
            custCustSecondName: '',
            custCustSurname: '',
            custCustTaxNo: '',
            custCustTelNo: '',
            custCustTitle: '',
            custCustWorkTelShearch: false,
            custIndvFatherName: '',
            custIndvTcId: '',
            joint: false,
            nameTitle: '',
            showCorporateBranchCombo: '',
        },
        validationSchema: {
            custCustTaxNo: validation.string(t(locale.labels.taxNo), { length: 10 }),
            custIndvTcId: validation.string(t(locale.labels.tcIdNo)),
            accCode: validation.string(t(locale.labels.accountNo), { maxLength: 16 }),
        },
    });

    const custCustCustomerTypeVal = useWatch({ control, fieldName: 'custCustCustomerType' });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_CUST_ACTIVE_STATUS,
                            ReferenceDataEnum.PRM_CUST_CUSTTYPE,
                            ReferenceDataEnum.PRM_CUST_NATIONALITY,
                            ReferenceDataEnum.PRM_CUST_PERSONNEL,
                            ReferenceDataEnum.PRM_CUST_PROFIT_CENTER,
                            ReferenceDataEnum.PRM_CUST_PROFIT_SEGMENT_CODE,
                            ReferenceDataEnum.PRM_CUST_TEL_AREA_CODE,
                            ReferenceDataEnum.PRM_CUST_TEL_AREA_CODE_KKTC,
                            ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                            ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY_PHONE_CODES,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: custPersCustListAllError }, custPersCustListAllCall] = useAxios<
        ICustPersCustListAllResponse,
        ICustPersCustListAllRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CUST_PERS_CUST_LIST_ALL), { manual: true });

    const [, custPersCustInTimeOutListCall] = useAxios<
        ICustPersCustInTimeOutListResponse,
        ICustPersCustInTimeOutListRequest
    >(getGenericSetCaller(GenericSetCallerEnum.CUST_PERS_CUST_IN_TIME_OUT_LIST), { manual: true });

    const [
        {
            data: custListBranchForKksComboData,
            error: custListBranchForKksComboError,
            loading: custListBranchForKksComboLoading,
        },
        custListBranchForKksComboCall,
    ] = useAxios<ICustListBranchForKksComboResponse, ICustListBranchForKksComboResponse>(
        { ...getGenericSetCaller(GenericSetCallerEnum.CUST_LIST_BRANCH_FOR_KKS_COMBO), data: {} },
        { manual: true },
    );

    const resetMainBranch = () => {
        setValue(
            'custCustMainBranchCode',
            formData?.showCorporateBranchCombo === ShowCorporateBranchComboEnum.Selected
                ? custListBranchForKksComboData?.coreData?.find(
                      (item) =>
                          String(item[0]) ===
                          getGlobalsData({
                              key: GlobalsItemEnum.OrganizationCode,
                          }),
                  )?.[0] || ''
                : referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE)
                        ?.items.find(
                            (item) =>
                                item.key ===
                                getGlobalsData({
                                    key: GlobalsItemEnum.OrganizationCode,
                                }),
                        )
                  ? String(
                        getGlobalsData({
                            key: GlobalsItemEnum.OrganizationCode,
                        }),
                    )
                  : '',
        );
    };

    const resetModal = () => {
        reset();
        setGeneralInformationsDataGridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): ICustomerInquiryModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { custCustCustomerCode: toString(modalViewerInputWatch) }),
        ...omit(formData, 'custCustMainBranchCode'),
        custCustMainBranchCode:
            formData?.showCorporateBranchCombo === ShowCorporateBranchComboEnum.Selected &&
            custListBranchForKksComboData
                ? custListBranchForKksComboData?.coreData?.find(
                      (item) => String(item[0]) === String(formData?.custCustMainBranchCode),
                  )?.[0] || ''
                : referenceDatas?.resultList
                      ?.find((item) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE)
                      ?.items.find((item) => String(item.key) === String(formData?.custCustMainBranchCode))?.key || '',
    });

    const onSubmit = async (formValues: ICustomerInquiryModalFormValues) => {
        const response = await custPersCustListAllCall({
            data: {
                ...pick(formValues, [
                    'accCode',
                    'custCustActive',
                    'custCustActiveStatus',
                    'custCustCustomerCode',
                    'custCustCustomerType',
                    'custCustMainBranchCode',
                    'custCustPotential',
                    'custCustTaxNo',
                ]),
                ...payloadData,
                ...(activeTab === CustomerTypeEnum.RealCustomerOption
                    ? {
                          ...pick(formValues, [
                              'custCustAreaCode',
                              'custCustCountryCode',
                              'custCustCountryName',
                              'custCustTelNo',
                              'custCustWorkTelShearch',
                              'custIndvTcId',
                              'joint',
                          ]),
                          custCustName: formValues?.custCustName?.toLocaleUpperCase('tr'),
                          custIndvFatherName: formValues?.custIndvFatherName?.toLocaleUpperCase('tr'),
                          custCustSecondName: formValues?.custCustSecondName?.toLocaleUpperCase('tr'),
                          custCustSurname: formValues?.custCustSurname?.toLocaleUpperCase('tr'),
                      }
                    : activeTab === CustomerTypeEnum.CorporateCustomerOption
                      ? {
                            custCustTitle: formValues?.custCustTitle?.toLocaleUpperCase('tr'),
                            custCorpSignboard: formValues?.custCorpSignboard?.toLocaleUpperCase('tr'),
                            custCorpCommercialRecordNo: formValues?.custCorpSignboard?.toLocaleUpperCase('tr'),
                        }
                      : {}),
                custPersQueryRestrictSelected: '1',
                custCustUserName: getGlobalsData({ key: GlobalsItemEnum.UserName }) || '',
            },
        });

        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData?.length) {
                setGeneralInformationsDataGridData(responseData);
                const responseTimeOut = await custPersCustInTimeOutListCall({
                    data: {
                        custCustCustomerCode: responseData?.length ? toString(responseData[0]?.customerCode) : '',
                    },
                });
                if (response?.status === HttpStatusCodeEnum.Ok) {
                    if (responseTimeOut?.data?.inTimeOutList === TimeOutListEnum.Timeout) {
                        message({
                            variant: MessageTypeEnum.warning,
                            message: t(locale.notifications.timeoutCustomerBeSureToContactTheDLDepositTimeotMailbox),
                        });
                    }
                }
            } else {
                setGeneralInformationsDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noCustomersMatchingTheEntered),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await custPersCustListAllCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    custPersQueryRestrictSelected: '1',
                    custShowNoRecordMessage: '1',
                    custCustUserName: getGlobalsData({ key: GlobalsItemEnum.UserName }) || '',
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData.coreData[0]);
                } else referenceDataCall();
            }
        } else {
            referenceDataCall();
            formData?.showCorporateBranchCombo === ShowCorporateBranchComboEnum.Selected &&
                custListBranchForKksComboCall();
        }
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (custPersCustListAllError || custListBranchForKksComboError) {
            show && !modalShow && closeModal();
        }
    }, [custPersCustListAllError, custListBranchForKksComboError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        custCustCustomerTypeVal && setActiveTab(custCustCustomerTypeVal);
    }, [custCustCustomerTypeVal]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (
            formData?.showCorporateBranchCombo === ShowCorporateBranchComboEnum.Selected &&
            show &&
            !custListBranchForKksComboLoading &&
            custListBranchForKksComboData?.coreData?.length &&
            !custListBranchForKksComboError
        ) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [custListBranchForKksComboLoading, custListBranchForKksComboData]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.customerInquiry),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.customerInquiry)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid pt={0.5} spacingType="form">
                                <GridItem>
                                    <Label text={t(locale.contentTitles.generalInformations)} />
                                    <GeneralInformations
                                        formProps={{ control, setValue }}
                                        referenceDatas={referenceDatas}
                                        componentProps={componentProps}
                                        custListBranchForKksComboData={custListBranchForKksComboData?.coreData}
                                    />
                                </GridItem>
                                <View show={Boolean(custCustCustomerTypeVal)}>
                                    <GridItem>
                                        <Tab value={activeTab} onChange={(val) => setActiveTab(val)}>
                                            <TabItem
                                                text={t(locale.contentTitles.realCustomer)}
                                                value={CustomerTypeEnum.RealCustomerOption}
                                                disabled={activeTab === CustomerTypeEnum.CorporateCustomerOption}
                                            />
                                            <TabItem
                                                text={t(locale.contentTitles.corporateCustomer)}
                                                value={CustomerTypeEnum.CorporateCustomerOption}
                                                disabled={activeTab === CustomerTypeEnum.RealCustomerOption}
                                            />
                                        </Tab>
                                        <Grid spacingType="form">
                                            <View show={activeTab === CustomerTypeEnum.RealCustomerOption}>
                                                <GridItem>
                                                    <RealCustomer
                                                        formProps={{ control }}
                                                        referenceDatas={referenceDatas}
                                                        componentProps={componentProps}
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Label text={t(locale.contentTitles.mobilePhone)} />
                                                    <MobilePhone
                                                        formProps={{ control, setValue }}
                                                        referenceDatas={referenceDatas}
                                                        componentProps={componentProps}
                                                    />
                                                </GridItem>
                                            </View>
                                            <View show={activeTab === CustomerTypeEnum.CorporateCustomerOption}>
                                                <GridItem>
                                                    <LegalInformations
                                                        formProps={{ control }}
                                                        referenceDatas={referenceDatas}
                                                        componentProps={componentProps}
                                                    />
                                                </GridItem>
                                            </View>
                                        </Grid>
                                    </GridItem>
                                </View>
                                <GridItem>
                                    <Grid spacingType="button">
                                        <GridItem
                                            sizeType="form"
                                            sm={constants.design.gridItem.sizeType.form.SET.sm / 2}
                                            ml={{ sm: 'auto' }}>
                                            <Button
                                                onClick={handleSubmit(onSubmit)}
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<Search />}
                                                fullWidth
                                            />
                                        </GridItem>
                                        <GridItem
                                            sizeType="form"
                                            sm={constants.design.gridItem.sizeType.form.SET.sm / 2}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                onClick={() => {
                                                    resetModal();
                                                    resetMainBranch();
                                                }}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={{ xs: 300, md: 275, lg: 310 }}>
                                    <GeneralInformationsDataGrid
                                        data={generalInformationsDataGridData}
                                        custCustCustomerTypeVal={custCustCustomerTypeVal}
                                        onReturnData={(data) => {
                                            handleOnReturnData(data);
                                            closeModal();
                                        }}
                                        referenceDatas={referenceDatas}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default CustomerInquiryModal;
