import type { IButtonProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, ReferenceDataResponse, SETModalsCommonProps } from '../../../../../../utils';
import type {
    IAccountListCurrentAccountsOrdinaryCoreData,
    IAccountListCurrentAccountsOrdinaryRequest,
} from '../../../../../../utils/types/api/models/BaseBanking/depositAndAccounting/accountListCurrentAccountsOrdinary/type';

export interface IAccountSelectionModalFormValues {
    accCode: string;
    accCustCode: string;
    accIban: string;
    accOrgCode: string;
    accType: string;
    currencyCode: string;
    custRepresentative: string;
}

export interface IAccountSelectionDataGridProps {
    data: IAccountListCurrentAccountsOrdinaryCoreData[];
    onReturnData?: (data: IAccountListCurrentAccountsOrdinaryCoreData) => void;
    referenceDatas?: ReferenceDataResponse;
}

type ISelectType = {
    [Property in `${keyof Pick<IAccountSelectionModalFormValues, 'accOrgCode' | 'currencyCode' | 'accType'>}`]?: Pick<
        ISelectProps<IAccountSelectionModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type ISimpleNumberInputKeys = keyof Pick<IAccountSelectionModalFormValues, 'accCode' | 'accIban'>;

type IExtendedNumberInputKeys = keyof Pick<IAccountSelectionModalFormValues, 'accCustCode' | 'custRepresentative'>;

type IBaseNumberInputProps = Pick<INumberInputProps, 'disabled' | 'readOnly'>;

type INumberInputType = Partial<Record<ISimpleNumberInputKeys, IBaseNumberInputProps>> &
    Partial<
        Record<
            IExtendedNumberInputKeys,
            IBaseNumberInputProps & Partial<Pick<IHelperModalProps, 'adornmentButtonProps'>>
        >
    >;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface IAccountSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IAccountSelectionModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IAccountListCurrentAccountsOrdinaryCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IAccountListCurrentAccountsOrdinaryRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}
