import type { FC, JSX } from 'react';
import { Checkbox, Grid, GridItem, Input, NumberInput, NumberInputReturnValueEnum } from 'seker-ui';
import type { ICustomerInquiryModalFormValues, IProps } from '../type';
import { constants, useTranslation } from '../../../../../../..';

const RealCustomer: FC<IProps<ICustomerInquiryModalFormValues>> = ({
    formProps: { control },
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 4,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 5,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 5,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 5,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Input
                    name="custCustName"
                    label={t(locale.labels.name_2)}
                    control={control}
                    maxLength={20}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custCustName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    name="custCustSecondName"
                    label={t(locale.labels.middleName)}
                    control={control}
                    maxLength={25}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custCustSecondName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    name="custCustSurname"
                    label={t(locale.labels.surname)}
                    control={control}
                    maxLength={20}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custCustSurname}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    name="custIndvFatherName"
                    label={t(locale.labels.fatherName)}
                    control={control}
                    maxLength={20}
                    sx={{
                        input: {
                            textTransform: 'uppercase',
                        },
                    }}
                    {...componentProps?.inputProps?.custIndvFatherName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    name="custIndvTcId"
                    label={t(locale.labels.tcIdNo)}
                    control={control}
                    maxLength={11}
                    decimalScale={0}
                    allowLeadingZeros
                    returnValue={NumberInputReturnValueEnum.formattedValue}
                    {...componentProps?.numberInputProps?.custIndvTcId}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Checkbox
                    name="joint"
                    label={t(locale.labels.joint)}
                    control={control}
                    sx={{ pt: { sm: 2.4, lg: 0 } }}
                    {...componentProps?.checkboxProps?.joint}
                />
            </GridItem>
        </Grid>
    );
};

export default RealCustomer;
