import type { FC } from 'react';
import { useTranslation, stringToStringDate, ReferenceDataEnum, getReferenceData } from '../../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, numberFormat } from 'seker-ui';
import type { IDepositAccountCriteriaDataGridProps } from '../type';
import type { IDepTimedepGetTimedepAccountsCoreData } from '../../../../../../../utils/types/api/models/BaseBanking/depositAndAccounting/depTimedepGetTimedepAccounts/type';
import { isEqual } from 'lodash';

const DepositAccountCriteriaDataGrid: FC<IDepositAccountCriteriaDataGridProps> = ({
    data,
    onReturnData,
    referenceDatas,
}) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'accCode',
            headerName: t(locale.contentTitles.termAccountNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'status',
            headerName: t(locale.contentTitles.status),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_STATUS,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'orgCode',
            headerName: t(locale.contentTitles.branchNo),
            headerAlign: 'center',
            flex: 1,
            minWidth: 220,
            valueFormatter: (value) => {
                const orgCode = getReferenceData({
                    referenceDatas,
                    referenceDataName: ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                })?.find((item) => isEqual(item.key, String(value)));
                return orgCode ? `${orgCode.key} - ${orgCode.value}` : '';
            },
        },
        {
            field: 'custCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'custTitle',
            headerName: t(locale.contentTitles.customerName),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 110,
        },
        {
            field: 'amount',
            headerName: t(locale.contentTitles.amount),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 120,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'productCode',
            headerName: t(locale.contentTitles.accountType),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_TYPE,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'createDate',
            headerName: t(locale.contentTitles.openingDate),
            headerAlign: 'center',
            flex: 1,
            minWidth: 130,
            align: 'center',
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'term',
            headerName: t(locale.contentTitles.maturityLength),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'termType',
            headerName: t(locale.contentTitles.maturityType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_TERM,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'termStart',
            headerName: t(locale.contentTitles.maturityStartDate),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 170,
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'termEnd',
            headerName: t(locale.contentTitles.maturityEndDate),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'intRate',
            headerName: t(locale.contentTitles.interestRate),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 140,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'poolIntRate',
            headerName: t(locale.contentTitles.poolInterestRate),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'referenceIntRate',
            headerName: t(locale.contentTitles.signInterestRate),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'netIntRate',
            headerName: t(locale.contentTitles.netInterestRate),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'stopageRate',
            headerName: t(locale.contentTitles.stopageRate),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'totalInterestAmount',
            headerName: t(locale.contentTitles.grossInterestAmount),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'netInterestAmount',
            headerName: t(locale.contentTitles.netInterestAmount),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'currAccCode',
            headerName: t(locale.contentTitles.currentAccountNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'returnType',
            headerName: t(locale.contentTitles.returnForm),
            headerAlign: 'center',
            flex: 1,
            minWidth: 170,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_RETURN_TYPE,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'lastApprover',
            headerName: t(locale.contentTitles.approving),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_APPROVERS,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'periodicTerm',
            headerName: t(locale.contentTitles.periodicMaturity),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'periodicTermType',
            headerName: t(locale.contentTitles.periodicPaymentPeriod),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 190,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_PAYMENT_PERIODS,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'periodicTermStart',
            headerName: t(locale.contentTitles.periodicMaturityStart),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 160,
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'periodicTermEnd',
            headerName: t(locale.contentTitles.periodicMaturityEnd),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 160,
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'periodicIntType',
            headerName: t(locale.contentTitles.periodicInterestType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'purpose',
            headerName: t(locale.contentTitles.purposeOfTermDepositUse),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 210,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_PROD_PRODUCT_CUSTOMER_TYPE,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'orgMarginedRate',
            headerName: t(locale.contentTitles.branchOfficerInterestRate),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'contractedAmountMinLimit',
            headerName: t(locale.contentTitles.minCommitmentAmount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'contractedAmountMaxLimit',
            headerName: t(locale.contentTitles.maxCommitmentAmount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'originalAmount',
            headerName: t(locale.contentTitles.original_amount),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'fundAccRealAmount',
            headerName: t(locale.contentTitles.fund_acc_real_amount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 190,
        },
        {
            field: 'multiCurrCodeAccCode',
            headerName: t(locale.contentTitles.lotsOfMoneyMevAccountNumber),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 220,
        },
        {
            field: 'creditCardNo',
            headerName: t(locale.contentTitles.creditCardNumber),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
    ];

    return (
        <DataGrid
            columns={columns}
            rows={data || []}
            onRowDoubleClick={({ row }: { row: IDepTimedepGetTimedepAccountsCoreData }) => {
                onReturnData?.(row);
            }}
        />
    );
};

export default DepositAccountCriteriaDataGrid;
