/* eslint-disable react-hooks/exhaustive-deps */
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control, DataGridColumnsPropsType } from 'seker-ui';
import {
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import { pick } from 'lodash';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../utils';
import type {
    IChecksBillsForeignTradeBicCodeListModalProps,
    IChecksBillsForeignTradeBicCodeListModalFormValues,
} from './type';
import { useAxios } from '../../../../../../hooks/useAxios';
import type {
    IFtcCommonGetSwiftCodeForPopupV1Request,
    IFtcCommonGetSwiftCodeForPopupV1Response,
    IFtcCommonGetSwiftCodeCoreData,
} from '../../../../../../utils/types/api/models/BaseBanking/checksBillsForeignTrade/ftcCommonGetSwiftCodeForPopupV1/type';

const ChecksBillsForeignTradeBicCodeListModal: FC<IChecksBillsForeignTradeBicCodeListModalProps> = ({
    show,
    onClose,
    formData,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const [datagridData, setDatagridData] = useState<IFtcCommonGetSwiftCodeCoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, setValue, reset, getValues, handleSubmit } =
        useForm<IChecksBillsForeignTradeBicCodeListModalFormValues>({
            defaultValues: {
                bank: '',
                bicCode: '',
                countryCode: '',
            },
            validationSchema: {
                bank: validation.string(t(locale.labels.bank)).test({
                    test: function (val, context) {
                        const { bicCode } = context.parent as IChecksBillsForeignTradeBicCodeListModalFormValues;
                        if (!bicCode && val && val?.length < 3) {
                            return this.createError({
                                message: t(locale.notifications.minimumCharactersEnter, {
                                    value: `${t(locale.labels.bank)}`,
                                    count: 3,
                                }),
                            });
                        }
                        if (bicCode && val && bicCode?.length < 3 && val?.length < 3) {
                            return this.createError({
                                message: t(locale.notifications.minimumCharactersEnter, {
                                    value: `${t(locale.contentTitles.bicCode)} ${t(locale.common.or)} ${t(
                                        locale.labels.bank,
                                    )}`,
                                    count: 3,
                                }),
                            });
                        }
                        return true;
                    },
                }),
                bicCode: validation.string(t(locale.labels.bicCode)).test({
                    test: function (val, context) {
                        const { bank } = context.parent as IChecksBillsForeignTradeBicCodeListModalFormValues;
                        if (!bank && val && val?.length < 3) {
                            return this.createError({
                                message: t(locale.notifications.minimumCharactersEnter, {
                                    value: `${t(locale.labels.bicCode)}`,
                                    count: 3,
                                }),
                            });
                        }
                        if (bank && val && bank?.length < 3 && val?.length < 3) {
                            return this.createError({
                                message: t(locale.notifications.minimumCharactersEnter, {
                                    value: `${t(locale.contentTitles.bicCode)} ${t(locale.common.or)} ${t(
                                        locale.labels.bank,
                                    )}`,
                                    count: 3,
                                }),
                            });
                        }
                        return true;
                    },
                }),
            },
        });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const resetModal = () => {
        reset();
        setDatagridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: IFtcCommonGetSwiftCodeCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IChecksBillsForeignTradeBicCodeListModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { bicCode: String(modalViewerInputWatch) }),
        ...formData,
    });

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'bicCode',
            headerName: t(locale.contentTitles.bicCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            flex: 1,
        },
        {
            field: 'bank',
            headerName: t(locale.contentTitles.bank),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
        {
            field: 'branchname',
            headerName: t(locale.contentTitles.branchName),
            headerAlign: 'center',
            minWidth: 100,
            flex: 1,
        },
        {
            field: 'city',
            headerName: t(locale.contentTitles.city),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
            flex: 1,
        },
        {
            field: 'country',
            headerName: t(locale.contentTitles.country),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
            flex: 1,
        },
        {
            field: 'address',
            headerName: t(locale.contentTitles.address),
            headerAlign: 'center',
            minWidth: 300,
            flex: 1,
        },
        {
            field: 'countrycode',
            headerName: t(locale.contentTitles.countryCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
            flex: 1,
        },
    ];

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: bicCodeListError }, bicCodeListCall] = useAxios<
        IFtcCommonGetSwiftCodeForPopupV1Response,
        IFtcCommonGetSwiftCodeForPopupV1Request
    >(getGenericSetCaller(GenericSetCallerEnum.FTC_COMMON_GET_SWIFT_CODE_FOR_POPUP_V1), { manual: true });

    const onSubmit = async (formValues: IChecksBillsForeignTradeBicCodeListModalFormValues) => {
        if (!formValues?.bank.length && !formValues?.bicCode.length) {
            message({
                variant: 'warning',
                message: t(locale.notifications.minimumCharactersEnter, {
                    value: `${t(locale.contentTitles.bicCode)} ${t(locale.common.or)} ${t(locale.labels.bank)}`,
                    count: 3,
                }),
            });
        } else {
            const response = await bicCodeListCall({
                data: {
                    ...payloadData,
                    ...pick(getInitFormValues(), 'countryCode'),
                    bank: formValues?.bank.toLocaleUpperCase('tr-TR'),
                    bicCode: formValues?.bicCode.toLocaleUpperCase('tr-TR'),
                },
            });

            if (response?.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData) {
                    setDatagridData(responseData?.coreData);
                } else {
                    setDatagridData([]);
                    message({
                        variant: MessageTypeEnum.info,
                        message: t(locale.notifications.noSearchedData),
                    });
                }
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await bicCodeListCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData.coreData[0]);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (bicCodeListError) {
            show && !modalShow && closeModal();
        }
    }, [bicCodeListError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.bicCodeList),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.bicCodeList)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Input
                                                name="bicCode"
                                                control={control}
                                                label={t(locale.labels.bicCode)}
                                                deps="bank"
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                maxLength={11}
                                                {...componentProps?.inputProps?.bicCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="bank"
                                                control={control}
                                                label={t(locale.labels.bank)}
                                                deps="bicCode"
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.bank}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="countryCode"
                                                label={t(locale.labels.countryName)}
                                                options={{
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                                                        )?.items || [],
                                                }}
                                                control={control}
                                                setValue={setValue}
                                                {...componentProps?.selectProps?.countryCode}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                                onClick={() => {
                                                    resetModal();
                                                }}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={350}>
                                    <DataGrid
                                        columns={columns}
                                        rows={datagridData || []}
                                        onRowDoubleClick={({ row }: { row: IFtcCommonGetSwiftCodeCoreData }) => {
                                            handleOnReturnData(row);
                                            closeModal();
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default ChecksBillsForeignTradeBicCodeListModal;
