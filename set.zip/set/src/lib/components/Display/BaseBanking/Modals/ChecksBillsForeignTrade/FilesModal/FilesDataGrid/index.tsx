import type { FC } from 'react';
import type { IFtiImportGetFilesForPopupV2CoreData as ICoreData } from '../../../../../../..';
import { useTranslation, ReferenceDataEnum } from '../../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, NumberFormat } from 'seker-ui';
import type { IFilesDataGridProps } from '../type';
import { isEqual } from 'lodash';

const FilesDataGrid: FC<IFilesDataGridProps> = ({ data, onReturnData, closeModal, referenceDatas }) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'no',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'fileNo',
            headerName: t(locale.contentTitles.fileNo),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
            align: 'center',
        },
        {
            field: 'state',
            headerName: t(locale.contentTitles.status),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
            align: 'center',
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_FTI_FILE_STATE)
                        ?.items.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'productType',
            headerName: t(locale.contentTitles.productType),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
            align: 'center',
        },
        {
            field: 'branchCode',
            headerName: t(locale.contentTitles.branch),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
            align: 'center',
        },
        {
            field: 'customerTitle',
            headerName: t(locale.contentTitles.customer),
            headerAlign: 'center',
            flex: 1,
            minWidth: 320,
        },
        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.importerCustomerCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 180,
            align: 'center',
        },
        {
            field: 'customerGroupOid',
            headerName: t(locale.contentTitles.importerCustomerGroup),
            headerAlign: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'amount',
            headerName: t(locale.contentTitles.fileAmount),
            headerAlign: 'center',
            align: 'right',
            minWidth: 120,
            flex: 1,
            renderCell: (params): any => {
                return <NumberFormat value={params?.value || null} thousandSeparator="." decimalSeparator="," />;
            },
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
            valueFormatter: (value) => {
                const branch = referenceDatas?.resultList
                    ?.find((item) => item.name === ReferenceDataEnum.PRM_CURRENCY_CODE)
                    ?.items.find((item) => isEqual(item.key, value));
                return branch ? `${branch.value}` : '';
            },
        },
        {
            field: 'descriptionOpen',
            headerName: t(locale.contentTitles.explanation),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'oid',
        },
    ];

    return (
        <DataGrid
            rows={data || []}
            columns={columns}
            hiddenColumns={['customerOid', 'oid']}
            onRowDoubleClick={({ row }: { row: ICoreData }) => {
                onReturnData?.(row);
                closeModal();
            }}
        />
    );
};

export default FilesDataGrid;
