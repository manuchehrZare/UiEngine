import type {
    FieldValues,
    HelperFormProps,
    IButtonProps,
    IInputProps,
    INumberInputProps,
    ISelectProps,
} from 'seker-ui';
import type {
    IFtiImportGetFilesForPopupV2CoreData as ICoreData,
    IFtiImportGetFilesForPopupV2Response,
    IHelperModalProps,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../..';

export interface IProps<T extends FieldValues> extends HelperFormProps<T, 'control'> {}

type IInputType = Partial<
    Record<`${keyof Pick<IFileModalFormValues, 'fileNo' | 'importerName'>}`, Pick<IInputProps, 'disabled' | 'readOnly'>>
>;

type ISelectType = {
    [Property in `${keyof Pick<IFileModalFormValues, 'productType' | 'branchCode' | 'currencyCode' | 'state'>}`]?: Pick<
        ISelectProps<IFileModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type INumberInputType = Partial<
    Record<`${keyof Pick<IFileModalFormValues, 'customerCode'>}`, Pick<INumberInputProps, 'disabled' | 'readOnly'>>
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface IFilesModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IFileModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IFtiImportGetFilesForPopupV2Response>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IFilesDataGridProps {
    closeModal: () => void;
    data: ICoreData[];
    onReturnData?: (data: ICoreData) => void;
    referenceDatas?: ReferenceDataResponse;
}
export interface IFileModalFormValues {
    branchCode: string;
    currencyCode: string;
    customerCode: string;
    fileNo: string;
    importerName: string;
    productType: string;
    state: string;
}

export enum StateEnum {
    Open = '1',
}
