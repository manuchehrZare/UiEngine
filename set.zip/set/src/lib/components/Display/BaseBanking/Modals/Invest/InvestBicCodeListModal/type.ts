import type { IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../../utils';
import type {
    IFinmanCommonListBankCoreData,
    IFinmanCommonListBankDefinitionRequest,
} from '../../../../../../utils/types/api/models/BaseBanking/invest/finmanCommonListBankDefinition/type';

export interface IInvestBicCodeListModalFormValues {
    bank: string;
    bicCode: string;
    correspondentType: string;
    currencyType: string;
}

type ISelectType = {
    [Property in `${keyof Pick<IInvestBicCodeListModalFormValues, 'currencyType' | 'correspondentType'>}`]?: Pick<
        ISelectProps<IInvestBicCodeListModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<IInvestBicCodeListModalFormValues, 'bank' | 'bicCode'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IInvestBicCodeListModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IInvestBicCodeListModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IFinmanCommonListBankCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IFinmanCommonListBankDefinitionRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export enum TreasureCorresTypeEnum {
    TreasureCorres = '0',
}

export enum CorrespondentTypeEnum {
    Correspondent = '0',
    CounterCorres = '1',
}
