import type {
    FieldValues,
    HelperFormProps,
    IButtonProps,
    ICheckboxProps,
    IDatePickerProps,
    IInputProps,
    INumberInputProps,
    ISelectProps,
} from 'seker-ui';
import type {
    ICoreData,
    ICustPersCustListAllRequest,
    IHelperModalProps,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../..';
import type { ICustListBranchForKksComboCoreData } from '../../../../../../utils/types/api/models/BaseBanking/customer/custListBranchForKksCombo/type';

type ISelectType = {
    [Property in `${keyof Pick<
        IJointCustomerInquiryModalFormValues,
        | 'custCustActive'
        | 'custCustActiveStatus'
        | 'custCustAreaCode'
        | 'custCustCountryCode'
        | 'custCustCountryName'
        | 'custCustCustomerType'
        | 'custCustMainBranchCode'
        | 'custCustPotential'
    >}`]?: Pick<ISelectProps<IJointCustomerInquiryModalFormValues[Property]>, 'disabled' | 'readOnly'>;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<
            IJointCustomerInquiryModalFormValues,
            | 'custCustName'
            | 'custCustSecondName'
            | 'custCustSurname'
            | 'custIndvFatherName'
            | 'custCustTitle'
            | 'custCorpSignboard'
            | 'custCorpCommercialRecordNo'
            | 'custCustCountryCode'
            | 'custCustAreaCode'
        >}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type INumberInputType = Partial<
    Record<
        `${keyof Pick<
            IJointCustomerInquiryModalFormValues,
            | 'custCustTelNo'
            | 'custIndvTcId'
            | 'custCustTaxNo'
            | 'custCustCustomerCode'
            | 'accCode'
            | 'custCustMkkRegistryNo'
        >}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

type ICheckboxType = Partial<
    Record<
        `${keyof Pick<IJointCustomerInquiryModalFormValues, 'joint' | 'custCustWorkTelShearch'>}`,
        Pick<ICheckboxProps, 'disabled' | 'readOnly'>
    >
>;

type IDatePickerType = Partial<
    Record<
        `${keyof Pick<IJointCustomerInquiryModalFormValues, 'custCustBirthdayStart' | 'custCustBirthdayEnd'>}`,
        Pick<IDatePickerProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

interface IPickerComponentProps {
    datePicker?: IDatePickerType;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    checkboxProps?: ICheckboxType;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    pickerProps?: IPickerComponentProps;
    selectProps?: ISelectType;
}

export interface IJointCustomerInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IJointCustomerInquiryModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<ICustPersCustListAllRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IProps<T extends FieldValues> extends HelperFormProps<T, 'control'> {
    componentProps?: IComponentProps;
    referenceDatas?: ReferenceDataResponse;
}

export interface IGeneralInformationsProps<T extends FieldValues> extends HelperFormProps<T, 'control' | 'setValue'> {
    componentProps?: IComponentProps;
    custCustCustomerTypeVal?: CustomerTypeEnum;
    custListBranchForKksComboData?: ICustListBranchForKksComboCoreData[];
    referenceDatas?: ReferenceDataResponse;
}

export interface IGeneralInformationsDataGridProps {
    custCustCustomerTypeVal: CustomerTypeEnum;
    data: ICoreData[];
    onReturnData?: (data: ICoreData) => void;
    referenceDatas?: ReferenceDataResponse;
}

export interface IJointCustomerInquiryModalFormValues {
    accCode: string;
    custCorpCommercialRecordNo: string;
    custCorpSignboard: string;
    custCustActive: string;
    custCustActiveStatus: string;
    custCustAreaCode: string;
    /**
     * Should be unixtime value.
     */
    custCustBirthdayEnd: number | null;
    /**
     * Should be unixtime value.
     */
    custCustBirthdayStart: number | null;
    custCustCountryCode: string;
    custCustCountryName: string;
    custCustCustomerCode: string;
    custCustCustomerType: string;
    custCustMainBranchCode: string | number;
    custCustMkkRegistryNo: string;
    custCustName: string;
    custCustPotential: string;
    custCustSecondName: string;
    custCustSurname: string;
    custCustTaxNo: string;
    custCustTelNo: string;
    custCustTitle: string;
    custCustWorkTelShearch: boolean;
    custIndvFatherName: string;
    custIndvTcId: string;
    joint: boolean;
    nameTitle: string;
    showCorporateBranchCombo?: string;
}

export enum CustomerTypeEnum {
    RealCustomerOption = '1',
    CorporateCustomerOption = '2',
}

export const CustPersCustListAllData: ICustPersCustListAllRequest = {
    accCode: '',
    custCorpCommercialRecordNo: '',
    custCorpSignboard: '',
    custCustActive: '',
    custCustActiveStatus: '',
    custCustAreaCode: '',
    custCustCountryCode: '',
    custCustCustomerCode: '',
    custCustCustomerType: '',
    custCustMainBranchCode: '',
    custCustName: '',
    custCustPotential: '',
    custCustSecondName: '',
    custCustSurname: '',
    custCustTaxNo: '',
    custCustTelNo: '',
    custCustTitle: '',
    custCustUserName: '',
    custCustWorkTelShearch: false,
    custIndvFatherName: '',
    custIndvTcId: '',
    custPersQueryRestrictSelected: '',
    joint: false,
};
