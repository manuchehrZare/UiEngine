import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import type { IGeneralInformationsDataGridProps } from '../type';
import { CustomerTypeEnum } from '../type';
import { isEqual } from 'lodash';
import type { ICoreData } from '../../../../../../..';
import { RealCustomerDataEnum, ReferenceDataEnum, stringToStringDate, useTranslation } from '../../../../../../..';

const GeneralInformationsDataGrid: FC<IGeneralInformationsDataGridProps> = ({
    data,
    onReturnData,
    custCustCustomerTypeVal,
    referenceDatas,
}) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'mainBranchCode',
            headerName: t(locale.contentTitles.branch),
            headerAlign: 'center',
            minWidth: 200,
            valueFormatter: (value) => {
                const branch = referenceDatas?.resultList
                    ?.find((item) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE)
                    ?.items.find((item) => isEqual(item.key, String(value)));
                return branch ? `${branch.key} - ${branch.value}` : '';
            },
        },
        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
        },
        {
            field: 'surname',
            headerName: t(locale.contentTitles.surname),
            headerAlign: 'center',
            minWidth: 120,
        },
        {
            field: 'name',
            headerName: t(locale.contentTitles.name),
            headerAlign: 'center',
            minWidth: 120,
        },
        {
            field: 'secondName',
            headerName: t(locale.contentTitles.middleName),
            headerAlign: 'center',
            minWidth: 120,
        },
        {
            field: 'title',
            headerName: t(locale.contentTitles.title),
            headerAlign: 'center',
            minWidth: 260,
        },
        {
            field: 'beginDate',
            headerName: t(locale.contentTitles.openingDate),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => (value ? stringToStringDate(`${value}`) : ''),
        },
        {
            field: 'birthday',
            headerName:
                custCustCustomerTypeVal === CustomerTypeEnum.RealCustomerOption
                    ? t(locale.contentTitles.birthday)
                    : t(locale.contentTitles.yearOfFoundation),
            headerAlign: 'center',
            align: 'center',
            minWidth: 150,
            valueFormatter: (value) => (value ? stringToStringDate(`${value}`) : ''),
        },
        {
            field: 'sex',
            headerName: t(locale.contentTitles.sex),
            headerAlign: 'center',
            align: 'center',
            minWidth: 100,
        },
        {
            field: 'fatherName',
            headerName: t(locale.contentTitles.fatherName),
            headerAlign: 'center',
            minWidth: 120,
        },
        {
            field: 'motherName',
            headerName: t(locale.contentTitles.motherName),
            headerAlign: 'center',
            minWidth: 120,
        },
        {
            field: 'tcId',
            headerName: t(locale.contentTitles.tcIdNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
        },
        {
            field: 'taxNo',
            headerName: t(locale.contentTitles.taxNo),
            headerAlign: 'center',
            align: 'center',
            minWidth: 120,
        },
        {
            field: 'individual',
            headerName: t(locale.contentTitles.realCustomer),
            headerAlign: 'center',
            align: 'center',
            width: 150,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === RealCustomerDataEnum.RealCustomer) return true;
                if (value === RealCustomerDataEnum.NotRealCustomer) return false;
                return value;
            },
        },
        {
            field: 'updateDate',
            headerName: t(locale.contentTitles.lastUpdateDate),
            headerAlign: 'center',
            align: 'center',
            width: 180,
            valueFormatter: (value) => (value ? stringToStringDate(`${value}`) : ''),
        },
        {
            field: 'potential',
            headerName: t(locale.contentTitles.potential),
            headerAlign: 'center',
            align: 'center',
            width: 120,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === RealCustomerDataEnum.RealCustomer) return true;
                if (value === RealCustomerDataEnum.NotRealCustomer) return false;
                return value;
            },
        },
        {
            field: 'nonActive',
            headerName: t(locale.contentTitles.closenessStatus),
            headerAlign: 'center',
            align: 'center',
            width: 150,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === RealCustomerDataEnum.RealCustomer) return true;
                if (value === RealCustomerDataEnum.NotRealCustomer) return false;
                return value;
            },
        },
        {
            field: 'activeStatus',
            headerName: t(locale.contentTitles.activenessStatus),
            headerAlign: 'center',
            align: 'center',
            width: 150,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_CUST_ACTIVE_STATUS)
                        ?.items.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'country',
            headerName: t(locale.contentTitles.country),
            headerAlign: 'center',
            align: 'center',
            minWidth: 100,
        },
        {
            field: 'nationality',
            headerName: t(locale.contentTitles.nationality),
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_CUST_NATIONALITY)
                        ?.items.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'nationalityCountry',
            headerName: `${t(locale.contentTitles.nationality)} ${t(locale.contentTitles.country)}`,
            headerAlign: 'center',
            align: 'center',
            minWidth: 130,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY)
                        ?.items.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'taxNoForeign',
            headerName: t(locale.contentTitles.foreignTaxNumber),
            headerAlign: 'center',
            align: 'center',
            minWidth: 180,
        },
        {
            field: 'profitCenterCode',
            headerName: t(locale.contentTitles.profitCenterCustomerSegment_2),
            headerAlign: 'center',
            align: 'center',
            width: 180,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_CUST_PROFIT_CENTER)
                        ?.items.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'profitSegmentCode',
            headerName: t(locale.contentTitles.customerSubSegment),
            headerAlign: 'center',
            align: 'center',
            width: 170,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item.name === ReferenceDataEnum.PRM_CUST_PROFIT_SEGMENT_CODE)
                        ?.items.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
    ];

    return (
        <DataGrid
            columns={columns}
            rows={data || []}
            hiddenColumns={
                custCustCustomerTypeVal === CustomerTypeEnum.RealCustomerOption
                    ? ['title']
                    : custCustCustomerTypeVal === CustomerTypeEnum.CorporateCustomerOption
                      ? [
                            'surname',
                            'name',
                            'tcId',
                            'secondName',
                            'sex',
                            'fatherName',
                            'motherName',
                            'profitCenterCode',
                            'profitSegmentCode',
                        ]
                      : []
            }
            onRowDoubleClick={({ row }: { row: ICoreData }) => {
                onReturnData?.(row);
            }}
        />
    );
};

export default GeneralInformationsDataGrid;
