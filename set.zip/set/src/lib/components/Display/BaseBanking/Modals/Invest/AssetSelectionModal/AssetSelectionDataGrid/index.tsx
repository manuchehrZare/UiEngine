import type { FC } from 'react';
import type { IFisFiscommonListFisDefCoreData } from '../../../../../../..';
import { useTranslation, ReferenceDataEnum, stringToStringDate } from '../../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import type { IAssetSelectionDataGridProps } from '../type';
// import { CheckBox, CheckBoxOutlineBlank } from '@mui/icons-material';

const AssetSelectionDataGrid: FC<IAssetSelectionDataGridProps> = ({
    data,
    onReturnData,
    closeModal,
    referenceDatas,
}) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'currencyOid',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
            valueOptions: () =>
                referenceDatas?.resultList?.find(
                    (item: any) => item?.name === ReferenceDataEnum.PRM_INVESTCORE_ASSET_CURRENCY_LIST,
                )?.items || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => value?.value,
            type: 'singleSelect',
        },
        {
            field: 'maturityDate',
            headerName: t(locale.contentTitles.assetMaturityDate),
            headerAlign: 'center',
            flex: 1,
            minWidth: 140,
            align: 'center',
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'shortDescription',
            headerName: t(locale.contentTitles.assetDef),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
            align: 'center',
        },
        {
            field: 'assetGroupDefOid',
            headerName: t(locale.contentTitles.assetType),
            headerAlign: 'center',
            flex: 1,
            minWidth: 300,
            valueOptions: () =>
                referenceDatas?.resultList?.find(
                    (item: any) => item?.name === ReferenceDataEnum.PRM_INVESTCORE_ASSET_GROUP_DEF,
                )?.items || [],
            getOptionValue: (value: any) => value?.key,
            getOptionLabel: (value: any) => value?.value,
            type: 'singleSelect',
        },
        {
            field: 'maturityDayDifference',
            headerName: t(locale.contentTitles.maturityDayDifference),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'securityWithCoupon',
            headerName: t(locale.contentTitles.securityWithCoupon),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 0) return true;
                if (value === 1) return false;
                return value;
            },
        },
    ];

    return (
        <DataGrid
            columns={columns}
            rows={data || []}
            onRowDoubleClick={({ row }: { row: IFisFiscommonListFisDefCoreData }) => {
                onReturnData?.(row);
                closeModal();
            }}
        />
    );
};

export default AssetSelectionDataGrid;
