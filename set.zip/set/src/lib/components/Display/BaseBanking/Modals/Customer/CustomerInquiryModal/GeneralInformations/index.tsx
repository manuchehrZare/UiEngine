import type { FC, JSX } from 'react';
import type { ISelectOptions } from 'seker-ui';
import { Grid, GridItem, NumberInput, NumberInputReturnValueEnum, Select } from 'seker-ui';
import type { ICustomerInquiryModalFormValues, IGeneralInformationsProps } from '../type';
import { CustomerTypeEnum } from '../type';
import type { ReferenceDataResultListItemsListItem } from '../../../../../../..';
import {
    ActivityStatusDataEnum,
    ClosenessStatusDataEnum,
    PotentialDataEnum,
    ReferenceDataEnum,
    constants,
    useTranslation,
} from '../../../../../../..';
import type { ICustListBranchForKksComboCoreData } from '../../../../../../../utils/types/api/models/BaseBanking/customer/custListBranchForKksCombo/type';

const GeneralInformations: FC<IGeneralInformationsProps<ICustomerInquiryModalFormValues>> = ({
    formProps: { control, setValue },
    referenceDatas,
    componentProps,
    custCustCustomerTypeVal,
    custListBranchForKksComboData,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const utilsData = {
        activityStatusData: [
            { value: t(locale.contentTitles.active), key: ActivityStatusDataEnum.Active },
            { value: t(locale.contentTitles.inactive), key: ActivityStatusDataEnum.Inactive },
            { value: t(locale.contentTitles.new), key: ActivityStatusDataEnum.New },
            { value: t(locale.contentTitles.lost), key: ActivityStatusDataEnum.Lost },
        ],
        closenessStatusData: [
            { value: t(locale.contentTitles.close), key: ClosenessStatusDataEnum.Close },
            { value: t(locale.contentTitles.notClose), key: ClosenessStatusDataEnum.NotClose },
        ],
        potentialData: [
            { value: t(locale.contentTitles.potentialCustomer), key: PotentialDataEnum.PotentialCustomer },
            { value: t(locale.contentTitles.registeredCustomer), key: PotentialDataEnum.RegisteredCustomer },
        ],
    };

    const getMainBranchCodeOptions = (): ISelectOptions<any> => {
        if (custListBranchForKksComboData?.length) {
            return {
                data: custListBranchForKksComboData || [],
                displayField: 1,
                displayValue: 0,
                renderDisplayList: (params) => `${params[0]} - ${params[1]}`,
                renderDisplayField: (params) => `${params[0]} - ${params[1]}`,
            } as ISelectOptions<ICustListBranchForKksComboCoreData>;
        }
        return {
            data:
                referenceDatas?.resultList
                    ?.find((item) => item.name === ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_BRANCH_LIST_WITH_CODE)
                    ?.items.sort((a, b) => {
                        return Number(a.key) - Number(b.key);
                    }) || [],
            displayField: 'value',
            displayValue: 'key',
            renderDisplayList: (params) => `${params.key} - ${params.value}`,
            renderDisplayField: (params) => `${params.key} - ${params.value}`,
        } as ISelectOptions<ReferenceDataResultListItemsListItem>;
    };

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 4,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 5,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 5,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 5,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Select
                    name="custCustCustomerType"
                    label={t(locale.labels.type)}
                    control={control}
                    setValue={setValue}
                    options={{
                        data:
                            referenceDatas?.resultList?.find(
                                (item) => item.name === ReferenceDataEnum.PRM_CUST_CUSTTYPE,
                            )?.items || [],
                        displayField: 'value',
                        displayValue: 'key',
                    }}
                    {...componentProps?.selectProps?.custCustCustomerType}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="custCustMainBranchCode"
                    label={t(locale.labels.branch)}
                    control={control}
                    setValue={setValue}
                    options={getMainBranchCodeOptions()}
                    {...componentProps?.selectProps?.custCustMainBranchCode}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="custCustActiveStatus"
                    label={t(locale.labels.activenessStatus)}
                    control={control}
                    setValue={setValue}
                    options={{ data: utilsData.activityStatusData, displayField: 'value', displayValue: 'key' }}
                    {...componentProps?.selectProps?.custCustActiveStatus}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="custCustPotential"
                    label={t(locale.labels.potential)}
                    control={control}
                    setValue={setValue}
                    options={{ data: utilsData.potentialData, displayField: 'value', displayValue: 'key' }}
                    {...componentProps?.selectProps?.custCustPotential}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Select
                    name="custCustActive"
                    label={t(locale.labels.closenessStatus)}
                    control={control}
                    setValue={setValue}
                    options={{ data: utilsData.closenessStatusData, displayField: 'value', displayValue: 'key' }}
                    {...componentProps?.selectProps?.custCustActive}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    name="custCustTaxNo"
                    label={t(locale.labels.taxNo)}
                    control={control}
                    maxLength={10}
                    allowLeadingZeros
                    returnValue={NumberInputReturnValueEnum.formattedValue}
                    {...componentProps?.numberInputProps?.custCustTaxNo}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    name="custCustCustomerCode"
                    label={t(locale.labels.customerNo)}
                    control={control}
                    allowLeadingZeros
                    decimalScale={0}
                    returnValue={NumberInputReturnValueEnum.formattedValue}
                    maxLength={custCustCustomerTypeVal === CustomerTypeEnum.CorporateCustomerOption ? 16 : 9}
                    {...componentProps?.numberInputProps?.custCustCustomerCode}
                />
            </GridItem>
            <GridItem sizeType="form">
                <NumberInput
                    name="accCode"
                    label={t(locale.labels.accountNo)}
                    control={control}
                    maxLength={16}
                    allowLeadingZeros
                    returnValue={NumberInputReturnValueEnum.formattedValue}
                    {...componentProps?.numberInputProps?.accCode}
                />
            </GridItem>
        </Grid>
    );
};

export default GeneralInformations;
