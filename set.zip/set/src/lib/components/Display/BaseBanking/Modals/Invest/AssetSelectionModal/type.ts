import type { IButtonProps, IInputProps, IDatePickerProps, ISelectProps } from 'seker-ui';
import type {
    IFisFiscommonListFisDefCoreData,
    IFisFiscommonListFisDefResponse,
    IHelperModalProps,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../..';

type IInputType = Partial<
    Record<
        `${keyof Pick<IAssetSelectionModalFormValues, 'shortDescription' | 'isinCode'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<
        IAssetSelectionModalFormValues,
        'assetGroupDefOid' | 'currencyOid' | 'maturityDateOperator'
    >}`]?: Pick<ISelectProps<IAssetSelectionModalFormValues[Property]>, 'disabled' | 'readOnly'>;
};

type IDatePickerType = Partial<
    Record<
        `${keyof Pick<IAssetSelectionModalFormValues, 'maturityDate'>}`,
        Pick<IDatePickerProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IAssetSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    datePickerProps?: IDatePickerType;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IAssetSelectionModalFormValues {
    assetGroupDefOid: string;
    checkPDate: string;
    currencyOid: string;
    executeQuery: string;
    isinCode: string;
    listPassiveAssets: string;
    maturityDate: number;
    maturityDateOperator: string;
    shortDescription: string;
}

export enum CheckPDateEnum {
    CheckPDateOne = '1',
    CheckPDateZero = '0',
}

export interface IAssetSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    checkPDateZero?: boolean;
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IAssetSelectionModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IAssetSelectionModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IFisFiscommonListFisDefCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IFisFiscommonListFisDefResponse>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IAssetSelectionDataGridProps extends Pick<IAssetSelectionModalProps, 'onReturnData'> {
    closeModal: () => void;
    data: IFisFiscommonListFisDefCoreData[];
    referenceDatas?: ReferenceDataResponse;
}

export enum MaturityDateOperatorEnum {
    EQUAL = '=',
    GREATER_THAN = '>',
    GREATER_THAN_OR_EQUAL = '>=',
    LESS_THAN = '<',
    LESS_THAN_OR_EQUAL = '<=',
}
