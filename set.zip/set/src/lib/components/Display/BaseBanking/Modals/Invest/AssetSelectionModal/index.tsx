/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { IAssetSelectionModalFormValues, IAssetSelectionModalProps } from './type';
import { CheckPDateEnum, MaturityDateOperatorEnum } from './type';
import { getUnixTime } from 'date-fns';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    useForm,
    DatePicker,
    message,
    Label,
    MessageTypeEnum,
    useWatch,
} from 'seker-ui';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import AssetSelectionDataGrid from './AssetSelectionDataGrid';
import type {
    IFisFiscommonListFisDefCoreData,
    IFisFiscommonListFisDefRequest,
    IFisFiscommonListFisDefResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
} from '../../../../../..';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    unixtimeToStringDate,
    useAxios,
    useTranslation,
} from '../../../../../..';

const AssetSelection: FC<IAssetSelectionModalProps> = ({
    show,
    formData,
    onClose,
    onReturnData,
    payloadData,
    componentProps,
    eventOwnerEl,
    inputProps,
    checkPDateZero,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [datagridData, setDatagridData] = useState<IFisFiscommonListFisDefCoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const MaturityDateOperatorData = [
        {
            key: t(locale.labels.equal),
            value: MaturityDateOperatorEnum.EQUAL,
        },
        {
            key: t(locale.labels.greaterThan),
            value: MaturityDateOperatorEnum.GREATER_THAN,
        },
        {
            key: t(locale.labels.greaterThanOrEqual),
            value: MaturityDateOperatorEnum.GREATER_THAN_OR_EQUAL,
        },
        {
            key: t(locale.labels.lessThan),
            value: MaturityDateOperatorEnum.LESS_THAN,
        },
        {
            key: t(locale.labels.lessThanOrEqual),
            value: MaturityDateOperatorEnum.LESS_THAN_OR_EQUAL,
        },
    ];

    const { control, handleSubmit, reset, setValue, getValues } = useForm<IAssetSelectionModalFormValues>({
        defaultValues: {
            assetGroupDefOid: '',
            checkPDate: CheckPDateEnum.CheckPDateOne,
            currencyOid: '',
            executeQuery: '1',
            isinCode: '',
            listPassiveAssets: '',
            maturityDate: getUnixTime(new Date()),
            maturityDateOperator: MaturityDateOperatorEnum.GREATER_THAN,
            shortDescription: '',
        },
    });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_INVESTCORE_ASSET_GROUP_DEF,
                            ReferenceDataEnum.PRM_INVESTCORE_ASSET_CURRENCY_LIST,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: fisFiscmnListFisDefError }, fisFiscmnListFisDefCall] = useAxios<
        IFisFiscommonListFisDefResponse,
        IFisFiscommonListFisDefRequest
    >(getGenericSetCaller(GenericSetCallerEnum.FIS_FISCMN_LIST_FIS_DEF), {
        manual: true,
    });

    const resetModal = () => {
        reset();
        setDatagridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: IFisFiscommonListFisDefCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IAssetSelectionModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { shortDescription: String(modalViewerInputWatch) }),
        ...formData,
        checkPDate: checkPDateZero ? CheckPDateEnum.CheckPDateZero : getValues('checkPDate'),
    });

    const onSubmit = async (formValues: IAssetSelectionModalFormValues) => {
        const response = await fisFiscmnListFisDefCall({
            data: {
                ...formValues,
                ...payloadData,
                checkPDate: CheckPDateEnum.CheckPDateZero,
                executeQuery: '1',
                listPassiveAssets: '',
                maturityDate: unixtimeToStringDate(formValues?.maturityDate),
                shortDescription: formValues?.shortDescription?.toUpperCase(),
            },
        });
        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data.coreData;
            if (responseData?.length) {
                setDatagridData(responseData);
            } else {
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await fisFiscmnListFisDefCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    maturityDate: unixtimeToStringDate(getValues('maturityDate')),
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        referenceDataCall();
                        setDatagridData(responseData);
                    }
                } else {
                    referenceDataCall();
                    setDatagridData([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (fisFiscmnListFisDefError) {
            show && !modalShow && closeModal();
        }
    }, [fisFiscmnListFisDefError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.assetSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.assetSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.sgmkInfo)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Select
                                                name="assetGroupDefOid"
                                                control={control}
                                                label={t(locale.labels.assetType)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_INVESTCORE_ASSET_GROUP_DEF,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.assetGroupDefOid}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="shortDescription"
                                                control={control}
                                                label={t(locale.labels.assetDef)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.shortDescription}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="currencyOid"
                                                control={control}
                                                label={t(locale.labels.currencyType)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_INVESTCORE_ASSET_CURRENCY_LIST,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.currencyOid}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="isinCode"
                                                control={control}
                                                label={t(locale.labels.isinCode)}
                                                {...componentProps?.inputProps?.isinCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Grid spacingType="joinedForm">
                                                <GridItem xs>
                                                    <DatePicker
                                                        name="maturityDate"
                                                        control={control}
                                                        label={t(locale.labels.assetMaturityDate)}
                                                        unixTime
                                                        {...componentProps?.datePickerProps?.maturityDate}
                                                    />
                                                </GridItem>
                                                <GridItem xs={4.5}>
                                                    <Select
                                                        name="maturityDateOperator"
                                                        control={control}
                                                        setValue={setValue}
                                                        options={{
                                                            data: MaturityDateOperatorData,
                                                            displayField: 'key',
                                                            displayValue: 'value',
                                                        }}
                                                        {...componentProps?.selectProps?.maturityDateOperator}
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                                onClick={resetModal}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={350}>
                                    <AssetSelectionDataGrid
                                        data={datagridData}
                                        closeModal={closeModal}
                                        onReturnData={onReturnData}
                                        referenceDatas={referenceDatas}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default AssetSelection;
