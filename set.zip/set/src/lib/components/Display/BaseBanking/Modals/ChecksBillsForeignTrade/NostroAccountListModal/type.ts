import type { IButtonProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, ReferenceDataResponse, SETModalsCommonProps } from '../../../../../../utils';
import type {
    IFtbNostroGetAccountInfoCoreDataItem,
    IFtbNostroGetAccountInfoRequest,
} from '../../../../../../utils/types/api/models/BaseBanking/checksBillsForeignTrade/ftbNostroGetAccountInfo/type';

export interface INostroAccountListModalQueryFormValues {
    accountOid: string;
    bankName: string;
    bicCode: string;
    city: string;
    counterAccountNo: string;
    countryCode: string;
    currencyCode: string;
    customerCode: string;
    customerTitle: string;
}

type ISelectType = {
    [Property in `${keyof Pick<INostroAccountListModalQueryFormValues, 'currencyCode' | 'countryCode'>}`]?: Pick<
        ISelectProps<INostroAccountListModalQueryFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<
            INostroAccountListModalQueryFormValues,
            'accountOid' | 'bankName' | 'bicCode' | 'city' | 'customerTitle' | 'counterAccountNo'
        >}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type INumberInputType = Partial<
    Record<
        `${keyof Pick<INostroAccountListModalQueryFormValues, 'customerCode'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface INostroAccountListModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface INostroAccountListModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: INostroAccountListModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<INostroAccountListModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IFtbNostroGetAccountInfoCoreDataItem) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IFtbNostroGetAccountInfoRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface INostroAccountListDatagridProps {
    closeModal: () => void;
    datagridData: IFtbNostroGetAccountInfoCoreDataItem[];
    onReturnData?: (data: IFtbNostroGetAccountInfoCoreDataItem) => void;
    referenceDatas?: ReferenceDataResponse;
}
