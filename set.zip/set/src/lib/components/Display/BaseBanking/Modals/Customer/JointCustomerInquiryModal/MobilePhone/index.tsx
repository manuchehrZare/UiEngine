import type { FC, JSX } from 'react';
import { useEffect } from 'react';
import { Checkbox, Grid, GridItem, Input, PhoneNumber, Select, View, useWatch } from 'seker-ui';
import type { IJointCustomerInquiryModalFormValues, IGeneralInformationsProps } from '../type';
import { isEqual, sortBy } from 'lodash';
import { CountryNameEnum, ReferenceDataEnum, constants, useTranslation } from '../../../../../../..';

const MobilePhone: FC<IGeneralInformationsProps<IJointCustomerInquiryModalFormValues>> = ({
    formProps: { control, setValue },
    referenceDatas,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const countryNameVal = useWatch({
        control,
        fieldName: 'custCustCountryName',
    });

    useEffect(() => {
        referenceDatas?.resultList?.find((item) => item.name === ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY)?.items
            .length && setValue('custCustCountryName', CountryNameEnum.TR);
        /* eslint-disable-next-line */
    }, [referenceDatas]);

    useEffect(() => {
        if (
            countryNameVal &&
            countryNameVal !== CountryNameEnum.KK &&
            referenceDatas?.resultList?.find((item) => item.name === ReferenceDataEnum.PRM_CUST_TEL_AREA_CODE)?.items
                .length
        ) {
            setValue(
                'custCustCountryCode',
                referenceDatas?.resultList
                    ?.find((item) => item.name === ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY_PHONE_CODES)
                    ?.items.find((item) => isEqual(countryNameVal, item.key))?.value || '',
            );
            setValue('custCustAreaCode', '');
        }
        /* eslint-disable-next-line */
    }, [countryNameVal, referenceDatas]);

    return (
        <Grid
            columns={{
                xs: constants.design.gridItem.sizeType.form.SET.xs,
                sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                md: constants.design.gridItem.sizeType.form.SET.md * 4,
                lg: constants.design.gridItem.sizeType.form.SET.lg * 5,
                xl: constants.design.gridItem.sizeType.form.SET.xl * 5,
                xxl: constants.design.gridItem.sizeType.form.SET.xxl * 5,
            }}
            spacingType="form">
            <GridItem sizeType="form">
                <Select
                    name="custCustCountryName"
                    label={t(locale.labels.countryName)}
                    control={control}
                    setValue={setValue}
                    options={{
                        data:
                            sortBy(
                                referenceDatas?.resultList?.find(
                                    (item) => item.name === ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                                )?.items,
                                'key',
                            ) || [],
                        displayField: 'value',
                        displayValue: 'key',
                        renderDisplayList: (params) => `${params.key} - ${params.value}`,
                        renderDisplayField: (params) => `${params.key} - ${params.value}`,
                    }}
                    {...componentProps?.selectProps?.custCustCountryName}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Input
                    name="custCustCountryCode"
                    label={t(locale.labels.countryCode)}
                    control={control}
                    maxLength={20}
                    {...componentProps?.inputProps?.custCustCountryCode}
                />
            </GridItem>
            <GridItem sizeType="form">
                <View show={countryNameVal === CountryNameEnum.TR || countryNameVal === CountryNameEnum.KK}>
                    <Select
                        name="custCustAreaCode"
                        label={t(locale.labels.areaCode)}
                        control={control}
                        setValue={setValue}
                        options={{
                            data:
                                sortBy(
                                    referenceDatas?.resultList
                                        ?.find(
                                            (item) =>
                                                item.name ===
                                                (countryNameVal === CountryNameEnum.TR
                                                    ? ReferenceDataEnum.PRM_CUST_TEL_AREA_CODE
                                                    : ReferenceDataEnum.PRM_CUST_TEL_AREA_CODE_KKTC),
                                        )
                                        ?.items.filter((item) => {
                                            return isEqual(item.filter, '02');
                                        }),
                                    'key',
                                ) || [],
                            displayField: 'value',
                            displayValue: 'key',
                            renderDisplayList: (params) => `${params.key} - ${params.value}`,
                            renderDisplayField: (params) => `${params.key} - ${params.value}`,
                        }}
                        {...componentProps?.selectProps?.custCustAreaCode}
                    />
                </View>
                <View show={countryNameVal !== CountryNameEnum.TR && countryNameVal !== CountryNameEnum.KK}>
                    <Input
                        name="custCustAreaCode"
                        label={t(locale.labels.areaCode)}
                        control={control}
                        {...componentProps?.inputProps?.custCustAreaCode}
                    />
                </View>
            </GridItem>
            <GridItem sizeType="form">
                <PhoneNumber
                    component="NumberInput"
                    control={control}
                    name="custCustTelNo"
                    label={t(locale.labels.phoneNo)}
                    withoutAreaCode
                    {...componentProps?.numberInputProps?.custCustTelNo}
                />
            </GridItem>
            <GridItem sizeType="form">
                <Checkbox
                    control={control}
                    name="custCustWorkTelShearch"
                    label={t(locale.labels.workPhone)}
                    sx={{ pt: { lg: 2.4 } }}
                    {...componentProps?.checkboxProps?.custCustWorkTelShearch}
                />
            </GridItem>
        </Grid>
    );
};

export default MobilePhone;
