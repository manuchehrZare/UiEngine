import type { IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../../utils';
import type {
    IFtcCommonGetSwiftCodeCoreData,
    IFtcCommonGetSwiftCodeForPopupV1Request,
} from '../../../../../../utils/types/api/models/BaseBanking/checksBillsForeignTrade/ftcCommonGetSwiftCodeForPopupV1/type';

export interface IChecksBillsForeignTradeBicCodeListModalFormValues {
    bank: string;
    bicCode: string;
    countryCode: string;
}

type ISelectType = {
    [Property in `${keyof Pick<IChecksBillsForeignTradeBicCodeListModalFormValues, 'countryCode'>}`]?: Pick<
        ISelectProps<IChecksBillsForeignTradeBicCodeListModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<IChecksBillsForeignTradeBicCodeListModalFormValues, 'bank' | 'bicCode'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IChecksBillsForeignTradeBicCodeListModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IChecksBillsForeignTradeBicCodeListModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IFtcCommonGetSwiftCodeCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IFtcCommonGetSwiftCodeForPopupV1Request>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}
