/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    NumberInput,
    NumberInputReturnValueEnum,
    Paper,
    Select,
    deepmerge,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    getReferenceData,
    useTranslation,
} from '../../../../../../utils';
import { useAxios } from '../../../../../../hooks/useAxios';
import ModalViewer from '../../../../../Others/ModalViewer';
import AccountSelectionDataGrid from './AccountSelectionDataGrid';
import type { IAccountSelectionModalFormValues, IAccountSelectionModalProps } from './type';
import type {
    IAccountListCurrentAccountsOrdinaryCoreData,
    IAccountListCurrentAccountsOrdinaryRequest,
    IAccountListCurrentAccountsOrdinaryResponse,
} from '../../../../../../utils/types/api/models/BaseBanking/depositAndAccounting/accountListCurrentAccountsOrdinary/type';
import { omit, pick, toString } from 'lodash';

const AccountSelectionModal: FC<IAccountSelectionModalProps> = ({
    show,
    formData,
    onClose,
    onReturnData,
    payloadData,
    componentProps,
    eventOwnerEl,
    inputProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [dataGridData, setDataGridData] = useState<IAccountListCurrentAccountsOrdinaryCoreData[]>([]);

    const { control, handleSubmit, reset, getValues, setValue } = useForm<IAccountSelectionModalFormValues>({
        defaultValues: {
            accCode: '',
            accCustCode: '',
            custRepresentative: '',
            accOrgCode: '',
            currencyCode: '',
            accType: '',
            accIban: '',
        },
        validationSchema: {
            accCode: validation.string(t(locale.labels.accountNo), { maxLength: 19 }),
            accCustCode: validation.string(t(locale.labels.customerNo), { maxLength: 16 }),
            accIban: validation.string(t(locale.labels.iban), { maxLength: constants.format.length.iban.tr }),
            custRepresentative: validation.string(t(locale.labels.customerNo), { maxLength: 19 }),
        },
    });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_CURRENCY_CODE,
                            ReferenceDataEnum.PRM_CURRENT_ACC_PROPERTY,
                            ReferenceDataEnum.PRM_PROD_PRODUCT_CUSTOMER_TYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: accountListCurrentAccountsOrdinaryError }, accountListCurrentAccountsOrdinaryCall] = useAxios<
        IAccountListCurrentAccountsOrdinaryResponse,
        IAccountListCurrentAccountsOrdinaryRequest
    >(getGenericSetCaller(GenericSetCallerEnum.ACCOUNT_LIST_CURRENT_ACCOUNTS_ORDINARY), { manual: true });

    const resetModal = () => {
        reset();
        setDataGridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: IAccountListCurrentAccountsOrdinaryCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IAccountSelectionModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { accCode: modalViewerInputWatch }),
        ...formData,
    });

    const onSubmit = async (formValues: IAccountSelectionModalFormValues) => {
        const response = await accountListCurrentAccountsOrdinaryCall({
            data: {
                ...pick(formValues, ['accOrgCode', 'accType', 'currencyCode', 'accIban']),
                accCode: toString(formValues?.accCode),
                accCustCode: toString(formValues?.accCustCode),
                custRepresentative: toString(formValues?.custRepresentative),
            },
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            if (response.data.coreData?.length) {
                setDataGridData(response?.data?.coreData);
            } else {
                setDataGridData([]);
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await accountListCurrentAccountsOrdinaryCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    accCustCode: toString(formData?.accCustCode),
                    custRepresentative: toString(formData?.custRepresentative),
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    onReturnData?.({ ...responseData.coreData[0] });
                } else referenceDataCall();
            }
        } else {
            referenceDataCall();
        }
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (accountListCurrentAccountsOrdinaryError) {
            show && !modalShow && closeModal();
            setDataGridData([]);
        }
    }, [accountListCurrentAccountsOrdinaryError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.accountSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.accountSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.criterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="accCode"
                                                control={control}
                                                label={t(locale.labels.accountNo)}
                                                maxLength={19}
                                                {...componentProps?.numberInputProps?.accCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="accCustCode"
                                                label={t(locale.labels.customerNo)}
                                                decimalScale={0}
                                                adornmentButtonProps={deepmerge(
                                                    {
                                                        tooltip: t(locale.contentTitles.customerInquiry),
                                                    },
                                                    componentProps?.numberInputProps?.accCustCode?.adornmentButtonProps,
                                                )}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('accCustCode', toString(data?.customerCode));
                                                    },
                                                }}
                                                maxLength={16}
                                                {...omit(componentProps?.numberInputProps?.accCustCode, [
                                                    'adornmentButtonProps',
                                                ])}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.UserInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.UserInquiryModal}
                                                control={control}
                                                name="custRepresentative"
                                                label={t(locale.labels.customerRepresentative)}
                                                returnValue={NumberInputReturnValueEnum.value}
                                                allowLeadingZeros
                                                adornmentButtonProps={deepmerge(
                                                    {
                                                        tooltip: t(locale.contentTitles.userInquiry),
                                                    },
                                                    componentProps?.numberInputProps?.custRepresentative
                                                        ?.adornmentButtonProps,
                                                )}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('custRepresentative', data?.userFileNo);
                                                    },
                                                }}
                                                maxLength={19}
                                                {...omit(componentProps?.numberInputProps?.custRepresentative, [
                                                    'adornmentButtonProps',
                                                ])}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="accOrgCode"
                                                control={control}
                                                label={t(locale.labels.branch)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName:
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                                                        }).sort((a, b) => {
                                                            return Number(a.key) - Number(b.key);
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                                }}
                                                {...componentProps?.selectProps?.accOrgCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="currencyCode"
                                                control={control}
                                                label={t(locale.labels.currencyType)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName: ReferenceDataEnum.PRM_CURRENCY_CODE,
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.currencyCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="accType"
                                                control={control}
                                                label={t(locale.labels.purposeOfUsage)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName:
                                                                ReferenceDataEnum.PRM_PROD_PRODUCT_CUSTOMER_TYPE,
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.accType}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="accIban"
                                                control={control}
                                                label={t(locale.labels.iban)}
                                                maxLength={26}
                                                {...componentProps?.numberInputProps?.accIban}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                                onClick={() => {
                                                    resetModal();
                                                }}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={350}>
                                    <AccountSelectionDataGrid
                                        data={dataGridData || []}
                                        referenceDatas={referenceDatas}
                                        onReturnData={(data) => {
                                            handleOnReturnData(data);
                                            closeModal();
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default AccountSelectionModal;
