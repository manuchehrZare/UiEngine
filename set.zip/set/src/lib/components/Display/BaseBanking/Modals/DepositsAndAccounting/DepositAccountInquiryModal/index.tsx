/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    DatePicker,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    NumberInput,
    NumberInputReturnValueEnum,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    getReferenceData,
    unixtimeToStringDate,
    useTranslation,
} from '../../../../../../utils';
import type { IDepositAccountInquiryModalProps, IDepositAccountInquiryModalFormValues } from './type';
import { useAxios } from '../../../../../../hooks/useAxios';
import ModalViewer from '../../../../../Others/ModalViewer';
import type {
    IDepTimedepGetTimedepAccountsCoreData,
    IDepTimedepGetTimedepAccountsRequest,
    IDepTimedepGetTimedepAccountsResponse,
} from '../../../../../../utils/types/api/models/BaseBanking/depositAndAccounting/depTimedepGetTimedepAccounts/type';
import { pick, toString } from 'lodash';
import DepositAccountCriteriaDataGrid from './DepositAccountCriteriaDataGrid';

const DepositAccountInquiryModal: FC<IDepositAccountInquiryModalProps> = ({
    show,
    formData,
    onClose,
    onReturnData,
    payloadData,
    componentProps,
    eventOwnerEl,
    inputProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [dataGridData, setDataGridData] = useState<IDepTimedepGetTimedepAccountsCoreData[]>([]);

    const { control, handleSubmit, reset, getValues, setValue } = useForm<IDepositAccountInquiryModalFormValues>({
        defaultValues: {
            accCode: '',
            ammountFirst: 0,
            ammountLast: 0,
            currencyCode: '',
            custCode: null,
            nameTitle: '',
            orgCode: '',
            productCode: '',
            status: '',
            timeFirst: null,
            timeLast: null,
        },
        validationSchema: {
            orgCode: validation.string(t(locale.labels.branch)),
            accCode: validation.string(t(locale.labels.termAccountNo)),
        },
    });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                            ReferenceDataEnum.PRM_CURRENCY_CODE,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_APPROVERS,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_APPROVERS,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_PAYMENT_PERIODS,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_PERIOD_END_INTR_RATE,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_RETURN_TYPE,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_STATUS,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_TERM,
                            ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_TYPE,
                            ReferenceDataEnum.PRM_PROD_PRODUCT_CUSTOMER_TYPE,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: depTimedepGetTimedepAccountsError }, depTimedepGetTimedepAccountsCall] = useAxios<
        IDepTimedepGetTimedepAccountsResponse,
        IDepTimedepGetTimedepAccountsRequest
    >(getGenericSetCaller(GenericSetCallerEnum.DEP_TIMEDEP_GET_TIMEDEP_ACCOUNTS), { manual: true });

    const resetModal = () => {
        reset();
        setDataGridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: IDepTimedepGetTimedepAccountsCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IDepositAccountInquiryModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { accCode: modalViewerInputWatch }),
        ...formData,
    });

    const onSubmit = async (formValues: IDepositAccountInquiryModalFormValues) => {
        if (!formValues?.orgCode && !formValues?.accCode) {
            message({
                variant: MessageTypeEnum.info,
                message: t(locale.notifications.enterYourBranchOrCurrentAccountNumber),
            });
        } else {
            const response = await depTimedepGetTimedepAccountsCall({
                data: {
                    ...pick(formValues, ['accCode', 'orgCode', 'currencyCode', 'productCode', 'status']),
                    ammountFirst: toString(formValues?.ammountFirst),
                    ammountLast: toString(formValues?.ammountLast),
                    custCode: toString(formValues?.custCode),
                    timeFirst: formValues?.timeFirst ? unixtimeToStringDate(formValues?.timeFirst) : '',
                    timeLast: formValues?.timeLast ? unixtimeToStringDate(formValues?.timeLast) : '',
                },
            });

            if (response.status === HttpStatusCodeEnum.Ok) {
                if (response.data.coreData?.length) {
                    setDataGridData(response?.data?.coreData);
                } else {
                    setDataGridData([]);
                    message({
                        variant: MessageTypeEnum.info,
                        message: t(locale.notifications.noSearchedData),
                    });
                }
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await depTimedepGetTimedepAccountsCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    ammountFirst: toString(formData?.ammountFirst),
                    ammountLast: toString(formData?.ammountLast),
                    custCode: toString(formData?.custCode),
                    timeFirst: formData?.timeFirst ? unixtimeToStringDate(formData?.timeFirst) : '',
                    timeLast: formData?.timeLast ? unixtimeToStringDate(formData?.timeLast) : '',
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    onReturnData?.({ ...responseData.coreData[0] });
                } else referenceDataCall();
            }
        } else {
            referenceDataCall();
        }
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (depTimedepGetTimedepAccountsError) {
            show && !modalShow && closeModal();
        }
    }, [depTimedepGetTimedepAccountsError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.depositAccountInquiry),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.depositAccountInquiry)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Select
                                                name="orgCode"
                                                control={control}
                                                label={t(locale.labels.branch)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName:
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                                                        }).sort((a, b) => {
                                                            return Number(a.key) - Number(b.key);
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                                }}
                                                {...componentProps?.inputProps?.orgCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="accCode"
                                                control={control}
                                                label={t(locale.labels.termAccountNo)}
                                                allowLeadingZeros
                                                returnValue={NumberInputReturnValueEnum.formattedValue}
                                                {...componentProps?.numberInputProps?.accCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="custCode"
                                                label={t(locale.labels.customerNo)}
                                                decimalScale={0}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.labels.customerNo),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('nameTitle', data?.nameTitle || '');
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.custCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="nameTitle"
                                                control={control}
                                                label={t(locale.labels.customerNameSurname)}
                                                readOnly
                                                {...componentProps?.inputProps?.nameTitle}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="productCode"
                                                control={control}
                                                label={t(locale.labels.termAccountType)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName:
                                                                ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_TYPE,
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.productCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="currencyCode"
                                                control={control}
                                                label={t(locale.labels.currencyType)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName: ReferenceDataEnum.PRM_CURRENCY_CODE,
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.currencyCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="ammountFirst"
                                                control={control}
                                                label={t(locale.labels.amountRangeStart)}
                                                textAlign="right"
                                                decimalScale={2}
                                                decimalSeparator=","
                                                thousandSeparator="."
                                                fixedDecimalScale
                                                {...componentProps?.numberInputProps?.ammountFirst}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="ammountLast"
                                                control={control}
                                                label={t(locale.labels.amountRangeEnd)}
                                                textAlign="right"
                                                decimalScale={2}
                                                decimalSeparator=","
                                                thousandSeparator="."
                                                fixedDecimalScale
                                                {...componentProps?.numberInputProps?.ammountLast}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="timeFirst"
                                                control={control}
                                                label={t(locale.labels.openingDateRangeStart)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.timeFirst}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="timeLast"
                                                control={control}
                                                label={t(locale.labels.openingDateRangeEnd)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.timeLast}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="status"
                                                control={control}
                                                label={t(locale.labels.accountStatus)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        getReferenceData({
                                                            referenceDatas,
                                                            referenceDataName:
                                                                ReferenceDataEnum.PRM_DEPOSIT_TIME_DEPOSIT_STATUS,
                                                        }) || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.status}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                                onClick={() => {
                                                    resetModal();
                                                }}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={350}>
                                    <DepositAccountCriteriaDataGrid
                                        data={dataGridData || []}
                                        referenceDatas={referenceDatas}
                                        onReturnData={(data) => {
                                            handleOnReturnData(data);
                                            closeModal();
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default DepositAccountInquiryModal;
