import type { FC, JSX } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem, numberFormat } from 'seker-ui';
import { ReferenceDataEnum, useTranslation } from '../../../../../../../utils';
import type { INostroAccountListDatagridProps } from '../type';

const NostroAccountListDatagrid: FC<INostroAccountListDatagridProps> = ({
    datagridData,
    closeModal,
    onReturnData,
    referenceDatas,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'bicCode',
            headerName: t(locale.contentTitles.swiftCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'bankTitle',
            headerName: t(locale.contentTitles.bankName),
            headerAlign: 'center',
            flex: 1,
            minWidth: 250,
        },
        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'balance',
            headerName: t(locale.contentTitles.balance),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 120,
            renderCell: (params) => {
                return numberFormat(params?.value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'accountNo',
            headerName: t(locale.contentTitles.accountNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'counterAccountNo',
            headerName: t(locale.contentTitles.nostroAccountNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'intraDay',
            headerName: t(locale.contentTitles.intradayLimit),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 120,
            valueFormatter: (value) => {
                return numberFormat(value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'endOfDay',
            headerName: t(locale.contentTitles.endOfDayLimit),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'intraDayAvailable',
            headerName: t(locale.contentTitles.dailyAvailableLimit),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return numberFormat(value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'endOfDayAvailable',
            headerName: t(locale.contentTitles.endOfDayAvailableLimit),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 200,
            renderCell: (params) => {
                return numberFormat(params?.value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'intraDayUsageCredit',
            headerName: t(locale.contentTitles.intradayCreditUsage),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return numberFormat(value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'intraDayUsageDebit',
            headerName: t(locale.contentTitles.intradayDebtUsage),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return numberFormat(value || '0', {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'city',
            headerName: t(locale.contentTitles.city),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'countryCode',
            headerName: t(locale.contentTitles.country),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return referenceDatas?.resultList
                    ?.find((item) => item.name === ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY)
                    ?.items?.find((item) => item.key === value)?.value;
            },
        },
        {
            field: 'nostroAccountOid',
            headerName: t(locale.contentTitles.nostroAccountOid),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
        },
    ];

    return (
        <Grid>
            <GridItem height={400}>
                <DataGrid
                    rows={datagridData || []}
                    columns={columns}
                    onRowDoubleClick={(row) => {
                        onReturnData?.(row?.row);
                        closeModal();
                    }}
                    sx={{
                        '.negativeCell': {
                            color: (theme) => theme.palette.error.light,
                        },
                    }}
                    getCellClassName={(params) => {
                        if (
                            (params?.field === 'balance' && Number(params?.row?.balance) < 0) ||
                            (params?.field === 'endOfDayAvailable' && Number(params?.row?.endOfDayAvailable) < 0)
                        ) {
                            return 'negativeCell';
                        }
                        return '';
                    }}
                />
            </GridItem>
        </Grid>
    );
};
export default NostroAccountListDatagrid;
