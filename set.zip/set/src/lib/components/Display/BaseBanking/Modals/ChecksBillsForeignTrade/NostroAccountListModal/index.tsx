/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import type { INostroAccountListModalProps, INostroAccountListModalQueryFormValues } from './type';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    SETModalsEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../utils';
import ModalViewer from '../../../../../Others/ModalViewer';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import NostroAccountListDatagrid from './NostroAcoountListDatagrid';
import type {
    IFtbNostroGetAccountInfoCoreDataItem,
    IFtbNostroGetAccountInfoRequest,
    IFtbNostroGetAccountInfoResponse,
} from '../../../../../../utils/types/api/models/BaseBanking/checksBillsForeignTrade/ftbNostroGetAccountInfo/type';
import { useAxios } from '../../../../../..';

const NostroAccountListModal: FC<INostroAccountListModalProps> = ({
    onClose,
    show,
    componentProps,
    eventOwnerEl,
    inputProps,
    onReturnData,
    formData,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [datagridData, setDatagridData] = useState<IFtbNostroGetAccountInfoCoreDataItem[]>([]);

    const { control, setValue, reset, handleSubmit, getValues } = useForm<INostroAccountListModalQueryFormValues>({
        defaultValues: {
            accountOid: '',
            bankName: '',
            city: '',
            countryCode: '',
            currencyCode: '',
            customerCode: '',
            customerTitle: '',
            counterAccountNo: '',
            bicCode: '',
        },
        validationSchema: {
            currencyCode: validation.string(t(locale.labels.currencyType), { required: true, selectable: true }),
        },
    });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY, ReferenceDataEnum.PRM_CURRENCY_CODE],
                    }),
                },
            },
            { manual: true },
        );

    const [, ftbNostroGetAccountInfoCall] = useAxios<IFtbNostroGetAccountInfoResponse, IFtbNostroGetAccountInfoRequest>(
        getGenericSetCaller(GenericSetCallerEnum.FTB_NOSTRO_GET_ACCOUNT_INFO),
        { manual: true },
    );

    const resetModal = () => {
        reset();
        setDatagridData([]);
    };

    const closeModal = () => {
        onClose?.(false);
        setModalShow(false);
        resetModal();
    };

    const onSubmit = async (formValues: INostroAccountListModalQueryFormValues) => {
        const response = await ftbNostroGetAccountInfoCall({
            data: formValues,
        });
        if (response.status === HttpStatusCodeEnum.Ok) {
            if (response?.data?.coreData?.length) {
                setDatagridData(response?.data?.coreData);
            } else {
                setDatagridData([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };

    const getInitFormValues = (): INostroAccountListModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name &&
            modalViewerInputWatch && { customerCode: String(modalViewerInputWatch) }),
        ...formData,
    });

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            referenceDataCall();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.requiredFieldMessage, {
                    value: t(locale.labels.currencyType),
                }),
            });
        } else {
            referenceDataCall();
        }
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.nostroAccountList),
                }),
            });
        }
    }, [referenceDatasError]);

    useEffect(() => {
        if (referenceDatasError) {
            show && !modalShow && closeModal();
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.nostroAccountList)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Grid
                                        spacingType="form"
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                                        }}>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.InstitutionSelectionModal>
                                                component="NumberInput"
                                                control={control}
                                                modalComponent={SETModalsEnum.InstitutionSelectionModal}
                                                name="customerCode"
                                                label={t(locale.labels.customerNo)}
                                                decimalScale={0}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.institutionSelection),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('customerCode', data?.customerCode);
                                                        setValue('customerTitle', data?.title);
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.customerCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="customerTitle"
                                                label={t(locale.labels.customerTitle)}
                                                readOnly
                                                {...componentProps?.inputProps?.customerTitle}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="counterAccountNo"
                                                label={t(locale.labels.nostroAccountNo)}
                                                {...componentProps?.inputProps?.counterAccountNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                control={control}
                                                name="currencyCode"
                                                label={t(locale.labels.currencyType)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) => item.name === ReferenceDataEnum.PRM_CURRENCY_CODE,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                setValue={setValue}
                                                {...componentProps?.selectProps?.currencyCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                control={control}
                                                name="countryCode"
                                                label={t(locale.labels.country)}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                setValue={setValue}
                                                {...componentProps?.selectProps?.countryCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="city"
                                                label={t(locale.labels.city)}
                                                {...componentProps?.inputProps?.city}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal>
                                                component="Input"
                                                control={control}
                                                modalComponent={SETModalsEnum.ChecksBillsForeignTradeBicCodeListModal}
                                                name="bicCode"
                                                label={t(locale.labels.swiftCode)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.bicCodeList),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('bicCode', data?.bicCode);
                                                        setValue('bankName', data?.bank);
                                                        setValue('countryCode', data?.countryCode);
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.bicCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="bankName"
                                                label={t(locale.labels.bankName)}
                                                readOnly
                                                {...componentProps?.inputProps?.bankName}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.AccountSelectionModal>
                                                component="Input"
                                                control={control}
                                                modalComponent={SETModalsEnum.AccountSelectionModal}
                                                name="accountOid"
                                                label={t(locale.labels.accountNo)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.accountSelection),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('accountOid', String(data?.accCode));
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.accountOid}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md pt={{ md: 3.2 }}>
                                    <Grid spacingType="button">
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                fullWidth
                                                onClick={() => resetModal()}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <NostroAccountListDatagrid
                                datagridData={datagridData}
                                closeModal={closeModal}
                                onReturnData={onReturnData}
                                referenceDatas={referenceDatas}
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};
export default NostroAccountListModal;
