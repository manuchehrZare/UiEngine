/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control, DataGridColumnsPropsType } from 'seker-ui';
import {
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
    validation,
} from 'seker-ui';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import { omit, pick } from 'lodash';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../../utils';
import type { IInvestBicCodeListModalProps, IInvestBicCodeListModalFormValues } from './type';
import { CorrespondentTypeEnum, TreasureCorresTypeEnum } from './type';
import { useAxios } from '../../../../../../hooks/useAxios';
import type {
    IFinmanCommonListBankCoreData,
    IFinmanCommonListBankDefinitionRequest,
    IFinmanCommonListBankDefinitionResponse,
} from '../../../../../../utils/types/api/models/BaseBanking/invest/finmanCommonListBankDefinition/type';

const InvestBicCodeListModal: FC<IInvestBicCodeListModalProps> = ({
    show,
    onClose,
    formData,
    onReturnData,
    payloadData,
    eventOwnerEl,
    inputProps,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [datagridData, setDatagridData] = useState<IFinmanCommonListBankCoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, handleSubmit, reset, setValue, getValues } = useForm<IInvestBicCodeListModalFormValues>({
        defaultValues: {
            bicCode: '',
            bank: '',
            currencyType: '',
            correspondentType: '',
        },
        validationSchema: {
            bank: validation.string(t(locale.labels.bank)).test({
                test: function (val, context) {
                    const { bicCode } = context.parent as IInvestBicCodeListModalFormValues;
                    if (!bicCode && val && val?.length < 3) {
                        return this.createError({
                            message: t(locale.notifications.minimumCharactersEnter, {
                                value: `${t(locale.labels.bank)}`,
                                count: 3,
                            }),
                        });
                    }
                    if (bicCode && val && bicCode?.length < 3 && val?.length < 3) {
                        return this.createError({
                            message: t(locale.notifications.minimumCharactersEnter, {
                                value: `${t(locale.contentTitles.bicCode)} ${t(locale.common.or)} ${t(
                                    locale.labels.bank,
                                )}`,
                                count: 3,
                            }),
                        });
                    }
                    return true;
                },
            }),
            bicCode: validation.string(t(locale.labels.bicCode)).test({
                test: function (val, context) {
                    const { bank } = context.parent as IInvestBicCodeListModalFormValues;
                    if (!bank && val && val?.length < 3) {
                        return this.createError({
                            message: t(locale.notifications.minimumCharactersEnter, {
                                value: `${t(locale.labels.bicCode)}`,
                                count: 3,
                            }),
                        });
                    }
                    if (bank && val && bank?.length < 3 && val?.length < 3) {
                        return this.createError({
                            message: t(locale.notifications.minimumCharactersEnter, {
                                value: `${t(locale.contentTitles.bicCode)} ${t(locale.common.or)} ${t(
                                    locale.labels.bank,
                                )}`,
                                count: 3,
                            }),
                        });
                    }
                    return true;
                },
            }),
        },
    });

    const correspondentTypeData = [
        { name: t(locale.contentTitles.correspondent), value: CorrespondentTypeEnum.Correspondent },
        { name: t(locale.contentTitles.counterCorres), value: CorrespondentTypeEnum.CounterCorres },
    ];

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const resetModal = () => {
        reset();
        setDatagridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: IFinmanCommonListBankCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IInvestBicCodeListModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { bicCode: String(modalViewerInputWatch) }),
        ...formData,
    });

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'bicCode',
            headerName: t(locale.contentTitles.bicCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'bank',
            headerName: t(locale.contentTitles.bank),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
        },
        {
            field: 'city',
            headerName: t(locale.contentTitles.city),
            headerAlign: 'center',
            flex: 1,
            minWidth: 100,
        },
        {
            field: 'countrycode',
            headerName: t(locale.contentTitles.countryCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
        },
        {
            field: 'shortName',
            headerName: t(locale.contentTitles.bankShortCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 170,
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
        },
        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
        },
        {
            field: 'account',
            headerName: t(locale.contentTitles.accountNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
        },
    ];

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [ReferenceDataEnum.PRM_INVESTCORE_ASSET_CURRENCY_LIST],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: finmanCommonListBankDefinitionError }, finmanCommonListBankDefinitionCall] = useAxios<
        IFinmanCommonListBankDefinitionResponse,
        IFinmanCommonListBankDefinitionRequest
    >(getGenericSetCaller(GenericSetCallerEnum.FINMAN_COMMON_LIST_BANK_DEFINITION), {
        manual: true,
    });

    const onSubmit = async (formValues: IInvestBicCodeListModalFormValues) => {
        if (!formValues?.bank.length && !formValues?.bicCode.length) {
            message({
                variant: 'warning',
                message: t(locale.notifications.minimumCharactersEnter, {
                    value: `${t(locale.contentTitles.bicCode)} ${t(locale.common.or)} ${t(locale.labels.bank)}`,
                    count: 3,
                }),
            });
        } else {
            const response = await finmanCommonListBankDefinitionCall({
                data: {
                    ...payloadData,
                    ...pick(formValues, ['bank', 'currencyType']),
                    bicCode: formValues?.bicCode.toLocaleUpperCase('tr-TR'),
                    currencyOid: formValues?.currencyType,
                    corresType: '',
                    type: '',
                    treasureCorres: TreasureCorresTypeEnum.TreasureCorres,
                    corres: formValues?.correspondentType === CorrespondentTypeEnum.Correspondent ? '1' : '0',
                    counter: formValues?.correspondentType === CorrespondentTypeEnum.CounterCorres ? '1' : '0',
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length) {
                    setDatagridData(responseData.coreData);
                } else {
                    setDatagridData([]);
                    message({
                        variant: 'info',
                        message: t(locale.notifications.noSearchedData),
                    });
                }
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await finmanCommonListBankDefinitionCall({
                data: {
                    ...omit(getInitFormValues(), ['correspondentType']),
                    ...payloadData,
                    currencyOid: getInitFormValues()?.currencyType,
                    corres: CorrespondentTypeEnum.CounterCorres,
                    corresType: '',
                    counter: CorrespondentTypeEnum.CounterCorres,
                    treasureCorres: TreasureCorresTypeEnum.TreasureCorres,
                    type: '',
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data;
                if (responseData?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(responseData.coreData[0]);
                } else referenceDataCall();
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (finmanCommonListBankDefinitionError) {
            show && !modalShow && closeModal();
        }
    }, [finmanCommonListBankDefinitionError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.bicCodeList),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.bicCodeList)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Input
                                                name="bicCode"
                                                control={control}
                                                label={t(locale.labels.bicCode)}
                                                deps="bank"
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.bicCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="bank"
                                                control={control}
                                                label={t(locale.labels.bank)}
                                                deps="bicCode"
                                                {...componentProps?.inputProps?.bank}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="currencyType"
                                                control={control}
                                                label={t(locale.labels.currencyType)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_INVESTCORE_ASSET_CURRENCY_LIST,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.currencyType}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="correspondentType"
                                                control={control}
                                                label={t(locale.labels.correspondentType)}
                                                setValue={setValue}
                                                options={{
                                                    data: correspondentTypeData,
                                                    displayField: 'name',
                                                    displayValue: 'value',
                                                }}
                                                {...componentProps?.selectProps?.correspondentType}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                                onClick={() => {
                                                    resetModal();
                                                }}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={350}>
                                    <DataGrid
                                        columns={columns}
                                        rows={datagridData || []}
                                        onRowDoubleClick={({ row }: { row: IFinmanCommonListBankCoreData }) => {
                                            handleOnReturnData(row);
                                            closeModal();
                                        }}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default InvestBicCodeListModal;
