import type { FieldValues, HelperFormProps, IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../..';
import type {
    IFtcCommonStatisticsCodePopupListCoreData,
    IFtcCommonStatisticsCodePopupListResponse,
} from '../../../../../../utils';
export interface IProps<T extends FieldValues> extends HelperFormProps<T, 'control'> {}

export interface IFTCCommonStatisticsModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    componentProps?: IComponentProps;
    formData?: Partial<IFTCCommonStatisticsModalValues>;
    onClose: (show: boolean) => void;
    onReturnData?: (data: IFtcCommonStatisticsCodePopupListCoreData) => Promise<void> | void;
    payloadData?: Partial<IFtcCommonStatisticsCodePopupListResponse>;
    show: boolean;
}

export interface IFTCCommonStatisticsModalValues {
    bfxDiscriminator: string;
    bfxState: string;
    discriminator: string;
    statisticCode: string;
    statisticName: string;
}

export interface IFTCCommonStatisticsDataGridProps {
    closeModal: () => void;
    gridData: IFtcCommonStatisticsCodePopupListCoreData[];
    onReturnData?: (data: IFtcCommonStatisticsCodePopupListCoreData) => void;
}

export enum DiscriminatorEnum {
    DGER = 'DGER',
    DVAL = 'DVAL',
    DVSA = 'DVSA',
    EFCK = 'EFCK',
    EFGR = 'EFGR',
}

export interface IProps<T extends FieldValues> extends HelperFormProps<T, 'control'> {}

type IInputType = Partial<
    Record<
        `${keyof Pick<IFTCCommonStatisticsModalValues, 'statisticCode' | 'statisticName'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<IFTCCommonStatisticsModalValues, 'discriminator'>}`]?: Pick<
        ISelectProps<IFTCCommonStatisticsModalValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}
