import type { IButtonProps, IDatePickerProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, ReferenceDataResponse, SETModalsCommonProps } from '../../../../../../utils';
import type {
    IDepTimedepGetTimedepAccountsCoreData,
    IDepTimedepGetTimedepAccountsRequest,
} from '../../../../../../utils/types/api/models/BaseBanking/depositAndAccounting/depTimedepGetTimedepAccounts/type';

export interface IDepositAccountInquiryModalFormValues {
    accCode: string;
    ammountFirst: number | null;
    ammountLast: number | null;
    currencyCode: string;
    custCode: number | null;
    nameTitle: string;
    orgCode: string;
    productCode: string;
    status: string;
    timeFirst: number | null;
    timeLast: number | null;
}

type ISelectType = {
    [Property in `${keyof Pick<IDepositAccountInquiryModalFormValues, 'currencyCode' | 'status' | 'productCode'>}`]?: Pick<
        ISelectProps<IDepositAccountInquiryModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type INumberInputType = Partial<
    Record<
        `${keyof Pick<IDepositAccountInquiryModalFormValues, 'ammountFirst' | 'ammountLast' | 'custCode' | 'accCode'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

type IDatePickerType = Partial<
    Record<
        `${keyof Pick<IDepositAccountInquiryModalFormValues, 'timeFirst' | 'timeLast'>}`,
        Pick<IDatePickerProps, 'disabled' | 'readOnly'>
    >
>;

type IInputType = Partial<
    Record<
        `${keyof Pick<IDepositAccountInquiryModalFormValues, 'nameTitle' | 'orgCode'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IComponentProps {
    buttonProps?: IButtonComponentProps;
    datePickerProps?: IDatePickerType;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface IDepositAccountInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IDepositAccountInquiryModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IDepTimedepGetTimedepAccountsCoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IDepTimedepGetTimedepAccountsRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IDepositAccountCriteriaDataGridProps extends Pick<IDepositAccountInquiryModalProps, 'onReturnData'> {
    data: IDepTimedepGetTimedepAccountsCoreData[];
    onReturnData?: (data: IDepTimedepGetTimedepAccountsCoreData) => void;
    referenceDatas?: ReferenceDataResponse;
}

export enum TreasureCorresTypeEnum {
    TreasureCorres = '0',
}

export enum CorrespondentTypeEnum {
    Correspondent = '0',
    CounterCorres = '1',
}

export interface IValidationFormValuesProps
    extends Pick<IDepositAccountInquiryModalFormValues, 'orgCode' | 'accCode'> {}
