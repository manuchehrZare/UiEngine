import type { FC, JSX } from 'react';

import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import type { IFTCCommonStatisticsDataGridProps } from '../type';
import { useTranslation } from '../../../../../../../utils';

const FtcCommonStatisticsCodeDataGrid: FC<IFTCCommonStatisticsDataGridProps> = ({
    gridData,
    onReturnData,
    closeModal,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'oid',
            headerName: t(locale.contentTitles.oid),
            headerAlign: 'center',
            align: 'center',
            width: 30,
        },
        {
            field: 'code',
            headerName: t(locale.contentTitles.statisticsCode),
            headerAlign: 'center',
            align: 'center',
            minWidth: 140,
            flex: 0.25,
        },
        {
            field: 'discriminator',
            headerName: t(locale.contentTitles.discriminator),
            headerAlign: 'center',
            align: 'center',
            minWidth: 50,
            flex: 0.25,
        },
        {
            field: 'name',
            headerName: t(locale.contentTitles.statisticsExplanation),
            headerAlign: 'center',
            minWidth: 200,
            flex: 1,
        },
    ];
    return (
        <DataGrid
            columns={columns}
            rows={gridData || []}
            hiddenColumns={['oid']}
            onRowDoubleClick={(mainRow) => {
                onReturnData?.(mainRow?.row);
                closeModal();
            }}
        />
    );
};

export default FtcCommonStatisticsCodeDataGrid;
