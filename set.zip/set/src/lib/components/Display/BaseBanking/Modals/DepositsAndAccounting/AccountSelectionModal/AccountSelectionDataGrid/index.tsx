import type { FC } from 'react';
import { useTranslation, ReferenceDataEnum, getReferenceData } from '../../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, numberFormat } from 'seker-ui';
import { isEqual } from 'lodash';
import type { IAccountSelectionDataGridProps } from '../type';
import type { IAccountListCurrentAccountsOrdinaryCoreData } from '../../../../../../../utils/types/api/models/BaseBanking/depositAndAccounting/accountListCurrentAccountsOrdinary/type';

const AccountSelectionDataGrid: FC<IAccountSelectionDataGridProps> = ({ data, onReturnData, referenceDatas }) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'purpose',
            headerName: t(locale.contentTitles.purposeOfUsage),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_PROD_PRODUCT_CUSTOMER_TYPE,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'accCode',
            headerName: t(locale.contentTitles.accountNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'accTypeExplanation',
            headerName: t(locale.contentTitles.accountType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'accOrgCode',
            headerName: t(locale.contentTitles.branch),
            headerAlign: 'center',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_ADMIN_ORG_BRANCH_LIST_WITH_CODE,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'accCustCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'accBalance',
            headerName: t(locale.contentTitles.balance),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'accUsebalance',
            headerName: t(locale.contentTitles.availableBalance),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'custNameTitle',
            headerName: t(locale.contentTitles.customer),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
        },
        {
            field: 'currencyCode',
            headerName: t(locale.contentTitles.currencyType),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'accRefCode',
            headerName: t(locale.contentTitles.referenceAccountNo),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
            align: 'center',
        },
        {
            field: 'accIban',
            headerName: t(locale.contentTitles.iban),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'limitBalance',
            headerName: t(locale.contentTitles.limitBalance),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 130,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'salaryAcc',
            headerName: t(locale.contentTitles.salaryAccount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 1) return true;
                if (value === 0) return false;
                return value;
            },
        },
        {
            field: 'depositProductCode',
            headerName: t(locale.contentTitles.depositAccountProductCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 190,
        },
        {
            field: 'fundBalance',
            headerName: t(locale.contentTitles.fundBalance),
            headerAlign: 'center',
            align: 'right',
            flex: 1,
            minWidth: 120,
            valueFormatter: (value) => {
                return numberFormat(value || 0, {
                    decimalSeparator: ',',
                    thousandSeparator: '.',
                    minimumFractionDigits: 2,
                });
            },
        },
        {
            field: 'isSekerHesap',
            headerName: t(locale.contentTitles.isIncreasedAccount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 170,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 1) return true;
                if (value === 0) return false;
                return value;
            },
        },
        {
            field: 'isDayNight',
            headerName: t(locale.contentTitles.isDayNightAccount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 1) return true;
                if (value === 0) return false;
                return value;
            },
        },
        {
            field: 'isEDayNight',
            headerName: t(locale.contentTitles.isEDayNightAccount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 1) return true;
                if (value === 0) return false;
                return value;
            },
        },
        {
            field: 'property',
            headerName: t(locale.contentTitles.accountProperty),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
            valueFormatter: (value) => {
                return (
                    getReferenceData({
                        referenceDatas,
                        referenceDataName: ReferenceDataEnum.PRM_CURRENT_ACC_PROPERTY,
                    })?.find((item) => isEqual(item.key, String(value)))?.value || ''
                );
            },
        },
        {
            field: 'isPaymentInstProtectedAcc',
            headerName: t(locale.contentTitles.isPaymentInstitutionProtectionAccount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 240,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 1) return true;
                if (value === 0) return false;
                return value;
            },
        },
        {
            field: 'isEmoneyInstProtectAcc',
            headerName: t(locale.contentTitles.isElectronicEnterpriseProdectionAccount),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 240,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === 1) return true;
                if (value === 0) return false;
                return value;
            },
        },
    ];

    return (
        <DataGrid
            columns={columns}
            rows={data || []}
            onRowDoubleClick={({ row }: { row: IAccountListCurrentAccountsOrdinaryCoreData }) => {
                onReturnData?.(row);
            }}
        />
    );
};

export default AccountSelectionDataGrid;
