/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
} from 'seker-ui';

import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useAxios,
    useTranslation,
} from '../../../../../..';
import FtcCommonStatisticsCodeDataGrid from './FtcCommonStatisticsCodeDataGrid';
import type { IFTCCommonStatisticsModalProps, IFTCCommonStatisticsModalValues } from './type';
import { DiscriminatorEnum } from './type';

import type {
    IFtcCommonStatisticsCodePopupListCoreData,
    IFtcCommonStatisticsCodePopupListRequest,
    IFtcCommonStatisticsCodePopupListResponse,
} from '../../../../../../utils';

const FTCCommonStatisticsModal: FC<IFTCCommonStatisticsModalProps> = ({
    show,
    onClose,
    inputProps,
    formData,
    eventOwnerEl,
    payloadData,
    onReturnData,
    componentProps,
}) => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [gridData, setGridData] = useState<IFtcCommonStatisticsCodePopupListCoreData[]>([]);

    const DiscriminatorData = [
        {
            key: DiscriminatorEnum.DVAL,
            value: t(locale.contentTitles.dval),
        },
        {
            key: DiscriminatorEnum.DVSA,
            value: t(locale.contentTitles.dval),
        },
        {
            key: DiscriminatorEnum.EFGR,
            value: t(locale.contentTitles.efgr),
        },
        {
            key: DiscriminatorEnum.EFCK,
            value: t(locale.contentTitles.efck),
        },
        {
            key: DiscriminatorEnum.DGER,
            value: t(locale.contentTitles.dger),
        },
    ];

    const { control, reset, setValue, handleSubmit, getValues } = useForm<IFTCCommonStatisticsModalValues>({
        defaultValues: {
            bfxDiscriminator: '',
            bfxState: '',
            discriminator: '',
            statisticCode: '',
            statisticName: '',
        },
    });
    /**
     * For Modal Showable Component === 'Input'
     */
    const modalViewerInputWatch = useWatch({
        control: (inputProps?.control ? inputProps?.control : control) as Control,
        fieldName: inputProps?.name ? inputProps?.name : 'statisticCode',
    });

    const [
        { loading: FtcCommonStatisticsCodePopupListLoading, error: FtcCommonStatisticsCodePopupListError },
        setFtcCommonStatisticsCodePopupListCall,
    ] = useAxios<IFtcCommonStatisticsCodePopupListResponse, IFtcCommonStatisticsCodePopupListRequest>(
        getGenericSetCaller(GenericSetCallerEnum.FTC_COMMON_STATISTICS_CODE_POPUP_LIST),
        { manual: true },
    );

    const handleOnReturnData = (data: IFtcCommonStatisticsCodePopupListCoreData) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IFTCCommonStatisticsModalValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { statisticCode: String(modalViewerInputWatch) }),
        ...formData,
    });

    const closeModal = () => {
        reset();
        setGridData([]);
        onClose?.(false);
        setModalShow(false);
    };

    const initControl = async () => {
        setModalShow(false);

        const response = await setFtcCommonStatisticsCodePopupListCall({
            data: {
                ...payloadData,
                ...getInitFormValues(),
            },
        });
        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (eventOwnerEl === 'input' && responseData?.length === 1) {
                closeModal();
                handleOnReturnData?.(responseData[0]);
                setValue('statisticCode', responseData[0]?.code);
            } else {
                setGridData(responseData);
                setModalShow(true);
            }
        } else {
            setGridData([]);
            setModalShow(true);
            message({
                variant: MessageTypeEnum.info,
                message: t(locale.notifications.noSearchedData),
            });
        }
    };
    useEffect(() => {
        !FtcCommonStatisticsCodePopupListLoading &&
            !FtcCommonStatisticsCodePopupListError &&
            show &&
            !modalShow &&
            setModalShow(true);
    }, [FtcCommonStatisticsCodePopupListLoading, FtcCommonStatisticsCodePopupListError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    const onSubmit = async (formValues: IFTCCommonStatisticsModalValues) => {
        const response = await setFtcCommonStatisticsCodePopupListCall({
            data: formValues,
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData?.length) {
                setGridData(responseData);
            } else {
                setGridData([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };
    useEffect(() => {
        show && initControl();
    }, [show]);

    return (
        <Modal maxWidth="md" show={modalShow} onClose={closeModal}>
            <ModalTitle>{t(locale.contentTitles.statisticsCodesList)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        spacingType="form"
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="statisticCode"
                                                label={t(locale.labels.statisticsCode)}
                                                {...componentProps?.inputProps?.statisticCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                options={{
                                                    data: DiscriminatorData,
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayField: (params) => `${params.key} - ${params.value}`,
                                                    renderDisplayList: (params) => `${params.key} - ${params.value}`,
                                                }}
                                                setValue={setValue}
                                                name="discriminator"
                                                label={t(locale.labels.discriminator)}
                                                control={control}
                                                {...componentProps?.selectProps?.discriminator}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                control={control}
                                                name="statisticName"
                                                label={t(locale.labels.explanation)}
                                                {...componentProps?.inputProps?.statisticName}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.query)}
                                                fullWidth
                                                onClick={handleSubmit(onSubmit)}
                                                {...componentProps?.buttonProps?.inquiryButton}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                fullWidth
                                                variant="outlined"
                                                onClick={() => {
                                                    reset();
                                                    setGridData([]);
                                                }}
                                                {...componentProps?.buttonProps?.clearButton}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem height={400}>
                                    <FtcCommonStatisticsCodeDataGrid
                                        onReturnData={onReturnData}
                                        gridData={gridData}
                                        closeModal={closeModal}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default FTCCommonStatisticsModal;
