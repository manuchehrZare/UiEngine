import type { FC } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem } from 'seker-ui';
import { stringToStringDate, useTranslation, ReferenceDataEnum } from '../../../../../../utils';
import type { IUserInquiryDataGridProps, IUserInquiryModalResultListItem } from '../type';
import { FetchTypeEnum } from '../type';

const UserInquiryDataGrid: FC<IUserInquiryDataGridProps> = ({
    data,
    onReturnData,
    closeModal,
    referenceDatas,
    apiRef,
    getUserInquiryDataGridData,
}) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'userName',
            headerName: t(locale.contentTitles.userCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'userFirstName',
            headerName: t(locale.contentTitles.name),
            headerAlign: 'center',
            flex: 1,
            minWidth: 110,
        },
        {
            field: 'userLastName',
            headerName: t(locale.contentTitles.surname),
            headerAlign: 'center',
            flex: 1,
            minWidth: 110,
        },
        {
            field: 'userFileNo',
            headerName: t(locale.contentTitles.registryNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'userOrgCode',
            headerName: t(locale.contentTitles.unitCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
        },
        {
            field: 'userOrganization',
            headerName: t(locale.contentTitles.unit),
            headerAlign: 'center',
            flex: 1,
            minWidth: 370,
        },
        {
            field: 'userUnit',
            headerName: t(locale.contentTitles.service),
            headerAlign: 'center',
            flex: 1,
            minWidth: 250,
        },
        {
            field: 'userTitle',
            headerName: t(locale.contentTitles.title),
            headerAlign: 'center',
            flex: 1,
            minWidth: 250,
        },
        {
            field: 'userActive',
            headerName: t(locale.contentTitles.active),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 110,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'userLogin',
            headerName: t(locale.contentTitles.login),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 110,
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'userExpirationDate',
            headerName: t(locale.contentTitles.validityDate),
            headerAlign: 'center',
            align: 'center',
            valueFormatter: (value) => (value ? stringToStringDate(value) : ''),
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'userChargedOrgCode',
            headerName: t(locale.contentTitles.assignedUnitCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 200,
        },
        {
            field: 'userChargedOrganization',
            headerName: t(locale.contentTitles.assignedUnit),
            headerAlign: 'center',
            flex: 1,
            minWidth: 370,
        },
        {
            field: 'userChargedUnit',
            headerName: t(locale.contentTitles.assignedService),
            headerAlign: 'center',
            flex: 1,
            minWidth: 250,
        },
        {
            field: 'userChannelCode',
            headerName: t(locale.contentTitles.assignedChannel),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_CHANNELS)
                        ?.items?.find((item) => item?.key === value)?.value || ''
                );
            },
        },
        {
            field: 'userStatus',
            headerName: t(locale.contentTitles.status),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 110,
            valueFormatter: (value) => {
                return (
                    referenceDatas?.resultList
                        ?.find((item) => item?.name === ReferenceDataEnum.PRM_ADMIN_USR_STATUS)
                        ?.items?.find((item) => item?.key === value)?.value || ''
                );
            },
        },
        {
            field: 'userNote',
            headerName: t(locale.contentTitles.note),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
        },
        {
            field: 'userChargedOtherOrgCode',
            headerName: t(locale.contentTitles.assignedOtherUnitCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 230,
        },
        {
            field: 'userChargedOtherOrg',
            headerName: t(locale.contentTitles.assignedOtherUnit),
            headerAlign: 'center',
            flex: 1,
            minWidth: 300,
        },
    ];

    return (
        <Grid>
            <GridItem height={400}>
                <DataGrid
                    apiRef={apiRef}
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={({ row }: { row: IUserInquiryModalResultListItem }) => {
                        onReturnData?.(row);
                        closeModal();
                    }}
                    onRowsScrollEnd={(_, __, details) =>
                        (details as any)?.api?.getScrollPosition()?.top !== 0 &&
                        getUserInquiryDataGridData(FetchTypeEnum.SCROLL)
                    }
                />
            </GridItem>
        </Grid>
    );
};

export default UserInquiryDataGrid;
