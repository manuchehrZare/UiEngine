import type { IButtonProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, ReferenceDataResponse, SETModalsCommonProps } from '../../../../../utils';
import type { MutableRefObject } from 'react';

export interface IUnitInquiryModalQueryFormValues {
    code: string;
    name: string;
    orgType: string;
}

export interface IUnitInquiryResultListItem {
    canOperateForOther: string;
    eftCode: string;
    isBeingEstablished: string;
    isClosed: string;
    organizationCode: string;
    organizationName: string;
    organizationOid: string;
    orgType: string;
    parentOid: string;
    riskCentralizationCode: string | null;
    taxNumber: string;
    taxOfficeCode: string;
}

interface IButtonComponentProps {
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

type InputType = Partial<
    Record<`${keyof Pick<IUnitInquiryModalQueryFormValues, 'name'>}`, Pick<IInputProps, 'disabled' | 'readOnly'>>
>;

type NumberInputType = Partial<
    Record<`${keyof Pick<IUnitInquiryModalQueryFormValues, 'code'>}`, Pick<INumberInputProps, 'disabled' | 'readOnly'>>
>;

type SelectType = {
    [Property in `${keyof Pick<IUnitInquiryModalQueryFormValues, 'orgType'>}`]?: Pick<
        ISelectProps<IUnitInquiryModalQueryFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

export interface IUnitInquiryComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: InputType;
    numberInputProps?: NumberInputType;
    selectProps?: SelectType;
}

export interface IUnitInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IUnitInquiryComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IUnitInquiryModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IUnitInquiryResultListItem) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IUnitInquiryModalQueryFormValues>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IUnitInquiryModalDataGridProps extends Pick<IUnitInquiryModalProps, 'onReturnData'> {
    apiRef: MutableRefObject<any>;
    closeModal: () => void;
    getUnitInquiryDataGridData: (fetchType: FetchType, formValues?: IUnitInquiryModalQueryFormValues) => Promise<void>;
    referenceDatas?: ReferenceDataResponse;
    resultListData: IUnitInquiryResultListItem[];
}

export enum FetchTypeEnum {
    SCROLL = 'scroll',
    SUBMIT = 'submit',
}

export type FetchType = `${FetchTypeEnum}`;
