import type { IButtonProps, IDatePickerProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../utils';
import type {
    ICoreData,
    IEprocProcessInstanceSearchRequest,
} from '../../../../../utils/types/api/models/Infrastructure/eprocProcessInstanceSearch/type';

export interface IEprocProcessSelectionModalQueryFormValues {
    eprocCustomerNo: number | null;
    eprocEnd1: number | null;
    eprocEnd2: number | null;
    eprocProcessId: number | string;
    eprocProcessOrganization: string;
    eprocReferenceId: number | null;
    eprocStart1: number | null;
    eprocStart2: number | null;
    eprocStatus: string;
}

type INumberInputType = Partial<
    Record<
        `${keyof Pick<
            IEprocProcessSelectionModalQueryFormValues,
            'eprocReferenceId' | 'eprocCustomerNo' | 'eprocProcessId'
        >}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<
        IEprocProcessSelectionModalQueryFormValues,
        'eprocStatus' | 'eprocProcessOrganization'
    >}`]?: Pick<ISelectProps<IEprocProcessSelectionModalQueryFormValues[Property]>, 'disabled' | 'readOnly'>;
};

type IDatePickerType = Partial<
    Record<
        `${keyof Pick<
            IEprocProcessSelectionModalQueryFormValues,
            'eprocEnd1' | 'eprocEnd2' | 'eprocStart1' | 'eprocStart2'
        >}`,
        Pick<IDatePickerProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}
export interface IEprocProcessSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    datePickerProps?: IDatePickerType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}
export interface IEprocProcessSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IEprocProcessSelectionModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IEprocProcessSelectionModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IEprocProcessInstanceSearchRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IEprocProcessSelectionModalDatagridProps {
    closeModal: () => void;
    data: ICoreData[];
    onReturnData?: (data: ICoreData) => void;
}

export enum EprocProcessSelectionStateEnum {
    Done = '20902',
    Undone = '0',
}
