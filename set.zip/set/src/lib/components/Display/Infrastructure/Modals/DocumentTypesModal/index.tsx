/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable react-hooks/exhaustive-deps */
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import type { Control, DataGridColumnsPropsType } from 'seker-ui';
import {
    Button,
    DataGrid,
    DataGridColumnTypeEnum,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    message,
    useForm,
    useWatch,
} from 'seker-ui';
import type { IDocumentTypesModalProps, IDocumentTypesQueryFormValues } from './type';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../utils';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import { useAxios } from '../../../../../hooks/useAxios';
import type {
    ICoreData,
    IDmsStructListTypesRequest,
    IDmsStructListTypesResponse,
} from '../../../../../utils/types/api/models/Infrastructure/dmsStructListTypes/type';

const DocumentTypesModal: FC<IDocumentTypesModalProps> = ({
    show,
    onClose,
    onReturnData,
    formData,
    componentProps,
    payloadData,
    eventOwnerEl,
    inputProps,
}) => {
    const { t, locale } = useTranslation();
    const [documentTypesDataGridData, setDocumentTypesDataGridData] = useState<ICoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, handleSubmit, reset, getValues } = useForm<IDocumentTypesQueryFormValues>({
        defaultValues: {
            itemType: '',
        },
    });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const resetModal = () => {
        setDocumentTypesDataGridData([]);
        reset();
    };

    const closeModal = () => {
        setModalShow(false);
        onClose?.(false);
        resetModal();
    };

    const getInitFormValues = (): IDocumentTypesQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { itemType: String(modalViewerInputWatch) }),
        ...formData,
    });

    const [{ error: dmsStructListTypesCallError }, dmsStructListTypesCall] = useAxios<
        IDmsStructListTypesResponse,
        IDmsStructListTypesRequest
    >(getGenericSetCaller(GenericSetCallerEnum.DMS_STRUCT_LIST_TYPES), { manual: true });

    const onSubmit = async (formValues: IDocumentTypesQueryFormValues) => {
        const response = await dmsStructListTypesCall({
            data: formValues,
        });

        if (response.status === HttpStatusCodeEnum.Ok) {
            if (response?.data?.coreData?.length) {
                setDocumentTypesDataGridData(response?.data?.coreData);
            } else {
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
                documentTypesDataGridData?.length && setDocumentTypesDataGridData([]);
            }
        }
    };

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'itemType',
            headerName: t(locale.contentTitles.name_2),
            headerAlign: 'center',
            flex: 2,
        },
        {
            field: 'itemTypeDesc',
            headerName: t(locale.contentTitles.explanation_2),
            headerAlign: 'center',
            flex: 3,
        },
    ];

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await dmsStructListTypesCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                },
            });

            if (response.status === HttpStatusCodeEnum.Ok) {
                if (response?.data?.coreData?.length === 1) {
                    closeModal();
                    handleOnReturnData(response?.data?.coreData[0]);
                } else {
                    setModalShow(true);
                    response?.data?.coreData?.length && setDocumentTypesDataGridData(response?.data?.coreData);
                    !response?.data?.coreData?.length &&
                        message({
                            variant: MessageTypeEnum.info,
                            message: t(locale.notifications.noSearchedData),
                        });
                }
            }
        } else {
            setModalShow(true);
        }
    };

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (dmsStructListTypesCallError && eventOwnerEl === 'input') {
            setModalShow(false);
            onClose?.(false);
        }
    }, [dmsStructListTypesCallError]);

    return (
        <Modal maxWidth="md" show={modalShow} onClose={() => show && modalShow && closeModal()}>
            <ModalTitle>{t(locale.contentTitles.documentTypes)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="form">
                                        <GridItem
                                            sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                            md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                            <Grid
                                                columns={{
                                                    xs: constants.design.gridItem.sizeType.form.SET.xs,
                                                    sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                                    md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                                    lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                                    xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                                    xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                                }}
                                                spacingType="form">
                                                <GridItem
                                                    sizeType="form"
                                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}>
                                                    <Input
                                                        name="itemType"
                                                        control={control}
                                                        label={t(locale.labels.typeName)}
                                                        {...componentProps?.inputProps.itemType}
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem md>
                                            <Grid spacingType="button" pt={{ md: 2.25 }}>
                                                <GridItem>
                                                    <Button
                                                        text={t(locale.buttons.inquire)}
                                                        fullWidth
                                                        iconLeft={
                                                            <HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />
                                                        }
                                                        onClick={handleSubmit(onSubmit)}
                                                        {...componentProps?.buttonProps.inquiryButton}
                                                    />
                                                </GridItem>
                                                <GridItem>
                                                    <Button
                                                        text={t(locale.buttons.cleanUp)}
                                                        fullWidth
                                                        variant="outlined"
                                                        iconLeft={<CleaningServices />}
                                                        onClick={resetModal}
                                                        {...componentProps?.buttonProps.clearButton}
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem height={300}>
                                            <DataGrid
                                                rows={documentTypesDataGridData}
                                                columns={columns}
                                                selectionOnClickable
                                                disableMultipleRowSelection
                                                onRowDoubleClick={(params) => {
                                                    handleOnReturnData(params?.row);
                                                    closeModal();
                                                }}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default DocumentTypesModal;
