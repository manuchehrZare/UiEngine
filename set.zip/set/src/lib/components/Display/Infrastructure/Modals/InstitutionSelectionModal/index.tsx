/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/rules-of-hooks */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    Label,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    NumberInput,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
} from 'seker-ui';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import type { IInstitutionSelectionModalProps, IInstitutionModalFormValues } from './type';
import InstitutionSelectionDataGrid from './InstitutionSelectionDataGrid';
import type {
    ICoreDataItem,
    IFinmanSwapListInstitutionRequest,
    IFinmanSwapListInstitutionResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
} from '../../../../..';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    useAxios,
    useTranslation,
} from '../../../../..';

const InstitutionSelectionModal: FC<IInstitutionSelectionModalProps> = ({
    show,
    formData,
    onClose,
    onReturnData,
    payloadData,
    componentProps,
    eventOwnerEl,
    inputProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [datagridData, setDatagridData] = useState<ICoreDataItem[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { control, handleSubmit, reset, setValue, getValues } = useForm<IInstitutionModalFormValues>({
        defaultValues: {
            countryCode: '',
            customerCode: '',
            functionOid: '',
            shortCode: '',
            stockExchangeCode: '',
            swiftCode: '',
            title: '',
        },
    });

    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                            ReferenceDataEnum.PRM_UTL_FUNCTION_WITH_OID,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: utlInstitutionListAllError }, utlInstitutionListAllCall] = useAxios<
        IFinmanSwapListInstitutionResponse,
        IFinmanSwapListInstitutionRequest
    >(getGenericSetCaller(GenericSetCallerEnum.UTL_INSTITUTION_LIST_ALL), {
        manual: true,
    });

    const resetModal = () => {
        reset();
        setDatagridData([]);
    };

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICoreDataItem) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IInstitutionModalFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { title: String(modalViewerInputWatch) }),
        ...formData,
        title: formData?.title?.toUpperCase() || '',
    });

    const onSubmit = async (formValues: IInstitutionModalFormValues) => {
        const response = await utlInstitutionListAllCall({
            data: {
                ...formValues,
                ...payloadData,
                shortCode: formValues?.shortCode?.toUpperCase(),
                stockExchangeCode: formValues?.stockExchangeCode?.toUpperCase(),
                swiftCode: formValues?.swiftCode?.toUpperCase(),
                title: formValues?.title?.toUpperCase(),
            },
        });
        if (response?.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (responseData?.length) {
                setDatagridData(responseData);
            } else {
                message({
                    variant: MessageTypeEnum.info,
                    message: t(locale.notifications.noSearchedData),
                });
            }
        }
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await utlInstitutionListAllCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        referenceDataCall();
                        setDatagridData(responseData);
                    }
                } else {
                    referenceDataCall();
                    setDatagridData([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (utlInstitutionListAllError) {
            show && !modalShow && closeModal();
        }
    }, [utlInstitutionListAllError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.institutionSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.institutionSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.criterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Input
                                                name="shortCode"
                                                control={control}
                                                label={t(locale.labels.shortCode)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.shortCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="title"
                                                control={control}
                                                label={t(locale.labels.title)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.title}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="stockExchangeCode"
                                                control={control}
                                                label={t(locale.labels.bourseCode)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.stockExchangeCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="swiftCode"
                                                control={control}
                                                label={t(locale.labels.swiftCode)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.swiftCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="countryCode"
                                                control={control}
                                                label={t(locale.labels.countryCode)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_UTL_LOCATION_COUNTRY,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.countryCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="functionOid"
                                                control={control}
                                                label={t(locale.labels.function)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item.name ===
                                                                ReferenceDataEnum.PRM_UTL_FUNCTION_WITH_OID,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.functionOid}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="customerCode"
                                                control={control}
                                                label={t(locale.labels.customerNumber)}
                                                {...componentProps?.numberInputProps?.customerCode}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                iconLeft={<CleaningServices />}
                                                variant="outlined"
                                                fullWidth
                                                onClick={resetModal}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <Grid>
                                <GridItem height={330}>
                                    <InstitutionSelectionDataGrid
                                        data={datagridData}
                                        closeModal={closeModal}
                                        onReturnData={onReturnData}
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default InstitutionSelectionModal;
