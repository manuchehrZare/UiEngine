/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type {
    IUserInquiryModalResultListItem,
    IUserInquiryModalProps,
    IUserInquiryModalQueryFormValues,
    FetchType,
} from './type';
import { UserInquiryModalActivityStatusDataEnum, FetchTypeEnum } from './type';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useDataGridApiRef,
    useWatch,
} from 'seker-ui';
import type {
    IRunQueryRequest,
    IRunQueryResponse,
    ReferenceDataRequest,
    ReferenceDataResponse,
} from '../../../../../utils';
import {
    GenericSetCallerEnum,
    GlobalsItemEnum,
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    RunQueryPopupNamesEnum,
    YesNoDataEnum,
    constants,
    generateReferenceDataRequestList,
    getGenericSetCaller,
    getGlobalsData,
    useTranslation,
} from '../../../../../utils';
import UserInquiryDataGrid from './UserInquiryDataGrid';
import { useAxios } from '../../../../..';
import type {
    IAdminOrgOrganizationUnitListForComboRequest,
    IAdminOrgOrganizationUnitListForComboResponse,
} from '../../../../../utils/types/api/models/Infrastructure/adminOrgOrganizationUnitListForCombo/type';
import type {
    IAdminUsrProfileListForComboRequest,
    IAdminUsrProfileListForComboResponse,
} from '../../../../../utils/types/api/models/Infrastructure/adminUsrProfileListForCombo/type';
import { sum } from 'lodash';

const UserInquiryModal: FC<IUserInquiryModalProps> = ({
    show,
    onClose,
    onReturnData,
    formData,
    eventOwnerEl,
    inputProps,
    payloadData,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [userInquiryDataGridData, setUserInquiryDataGridData] = useState<IUserInquiryModalResultListItem[]>([]);
    const [offset, setOffset] = useState<number>(1);
    const apiRef = useDataGridApiRef();
    const limit = 50;

    const defaultFormValues: IUserInquiryModalQueryFormValues = {
        cmbChannelCode: '',
        cmbUserActive: YesNoDataEnum.YesValue,
        cmbUserChargedOrganization:
            getGlobalsData({ key: GlobalsItemEnum.OrganizationType }) === '20'
                ? getGlobalsData({ key: GlobalsItemEnum.ChargedOrganizationOID })
                : '',
        cmbUserChargedOtherOrg: '',
        cmbUserChargedUnit: '',
        cmbUserLogin: UserInquiryModalActivityStatusDataEnum.Active,
        cmbUserOrganization: '',
        cmbUserProfile: '',
        cmbUserStatus: '',
        cmbUserTitle: '',
        cmbUserUnit: '',
        txtUserFileNo: '',
        txtUserFirstName: '',
        txtUserLastName: '',
        txtUserName: '',
    };

    const [scrollFormData, setSetscrollFormData] = useState<IUserInquiryModalQueryFormValues>(defaultFormValues);

    const utilsData = {
        yesNoData: [
            { name: t(locale.labels.yesQuestion), value: YesNoDataEnum.YesValue },
            { name: t(locale.labels.noQuestion), value: YesNoDataEnum.NoValue },
        ],
    };

    const activityStatusData = [
        { name: t(locale.contentTitles.active), value: UserInquiryModalActivityStatusDataEnum.Active },
        { name: t(locale.contentTitles.inactive), value: UserInquiryModalActivityStatusDataEnum.Inactive },
    ];

    const { control, setValue, reset, handleSubmit, getValues } = useForm<IUserInquiryModalQueryFormValues>({
        defaultValues: defaultFormValues,
    });

    const [cmbUserOrganizationVal, cmbUserChargedOrganizationVal] = useWatch({
        control,
        fieldName: ['cmbUserOrganization', 'cmbUserChargedOrganization'],
    });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const [{ data: referenceDatas, error: referenceDatasError, loading: referenceDatasLoading }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                            ReferenceDataEnum.PRM_CHANNELS,
                            ReferenceDataEnum.PRM_ADMIN_USR_USER_TITLES_WITH_OID,
                            ReferenceDataEnum.PRM_ADMIN_USR_STATUS,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ data: adminOrgOrganizationUnitListForComboData }, adminOrgOrganizationUnitListForComboCall] = useAxios<
        IAdminOrgOrganizationUnitListForComboResponse,
        IAdminOrgOrganizationUnitListForComboRequest
    >(getGenericSetCaller(GenericSetCallerEnum.ADMIN_ORG_ORGANIZATION_UNIT_LIST_FOR_COMBO), { manual: true });

    const [
        {
            data: adminUsrProfileListForComboData,
            error: adminUsrProfileListForComboError,
            loading: adminUsrProfileListForComboLoading,
        },
        adminUsrProfileListForComboCall,
    ] = useAxios<IAdminUsrProfileListForComboResponse, IAdminUsrProfileListForComboRequest>(
        getGenericSetCaller(GenericSetCallerEnum.ADMIN_USR_PROFILE_LIST_FOR_COMBO),
        { manual: true },
    );

    const [{ data: runQueryData }, popupRunQueryCall] = useAxios<
        IRunQueryResponse<IUserInquiryModalResultListItem>,
        IRunQueryRequest
    >(constants.api.endpoints.nova.infra.core.popup.runQuery.POST, { manual: true });

    const resetModal = () => {
        reset();
        setUserInquiryDataGridData([]);
    };

    const closeModal = () => {
        setOffset(1);
        setSetscrollFormData(defaultFormValues);
        onClose?.(false);
        setModalShow(false);
        resetModal();
    };

    const getUserInquiryDataGridData = async (fetchType: FetchType, formValues?: IUserInquiryModalQueryFormValues) => {
        if ((runQueryData?.hasNext && fetchType === FetchTypeEnum.SCROLL) || fetchType === FetchTypeEnum.SUBMIT) {
            const payloadFormValues = fetchType === FetchTypeEnum.SUBMIT ? formValues : scrollFormData;
            const response = await popupRunQueryCall({
                data: {
                    popupName: RunQueryPopupNamesEnum.PP_USER,
                    parameters: [
                        {
                            name: 'userFileNo',
                            value: `${payloadFormValues?.txtUserFileNo}%`,
                        },
                        {
                            name: 'userUsername',
                            value: `${payloadFormValues?.txtUserName}%`,
                        },
                        {
                            name: 'userFirstName',
                            value: `${payloadFormValues?.txtUserFirstName?.toLocaleUpperCase('TR')}%`,
                        },
                        {
                            name: 'userLastName',
                            value: `${payloadFormValues?.txtUserLastName.toLocaleUpperCase('TR')}%`,
                        },
                        {
                            name: 'userOrganizationOid',
                            value: `${payloadFormValues?.cmbUserOrganization}%`,
                        },
                        {
                            name: 'userUnitOid',
                            value: `${payloadFormValues?.cmbUserUnit}%`,
                        },
                        {
                            name: 'userTitleOid',
                            value: `${payloadFormValues?.cmbUserTitle}%`,
                        },
                        {
                            name: 'userChannelCode',
                            value: `${payloadFormValues?.cmbChannelCode}%`,
                        },
                        {
                            name: 'userOid',
                            value: '%',
                        },
                        {
                            name: 'userActive',
                            value: `${payloadFormValues?.cmbUserActive}%`,
                        },
                        {
                            name: 'userLogin',
                            value: `${payloadFormValues?.cmbUserLogin}%`,
                        },
                        {
                            name: 'userChargedOrgOid',
                            value: `${payloadFormValues?.cmbUserChargedOrganization}%`,
                        },
                        {
                            name: 'userChargedOtherOrgOid',
                            value: `${payloadFormValues?.cmbUserChargedOtherOrg}%`,
                        },
                        {
                            name: 'userStatus',
                            value: `${payloadFormValues?.cmbUserStatus}%`,
                        },
                        {
                            name: 'profileCode',
                            value: `${payloadFormValues?.cmbUserProfile}%`,
                        },
                        {
                            name: 'userChargedUnitOid',
                            value: `${payloadFormValues?.cmbUserChargedUnit}%`,
                        },
                    ],
                    offset: fetchType === FetchTypeEnum.SUBMIT ? 1 : sum([offset, limit]),
                    limit,
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                if (fetchType === FetchTypeEnum.SUBMIT) {
                    if (response?.data?.resultList?.length) {
                        apiRef.current.scrollToIndexes({ rowIndex: 0 });
                        setOffset(1);
                        formValues && setSetscrollFormData(formValues);
                        setUserInquiryDataGridData(response?.data?.resultList);
                    } else {
                        setUserInquiryDataGridData([]);
                        message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                    }
                } else if (fetchType === FetchTypeEnum.SCROLL) {
                    if (response?.data?.resultList?.length) {
                        setOffset((prevState) => sum([prevState, limit]));
                        setUserInquiryDataGridData((prevState) => {
                            return [...prevState, ...response.data.resultList];
                        });
                    }
                }
            }
        }
    };

    const onSubmit = async (formValues: IUserInquiryModalQueryFormValues) => {
        getUserInquiryDataGridData(FetchTypeEnum.SUBMIT, formValues);
    };

    const handleOnReturnData = (data: IUserInquiryModalResultListItem) => {
        onReturnData?.(data);
    };

    const getInitFormValues = (): IUserInquiryModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name &&
            modalViewerInputWatch && { txtUserName: String(modalViewerInputWatch) }),
        ...formData,
    });

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await popupRunQueryCall({
                data: {
                    ...payloadData,
                    popupName: RunQueryPopupNamesEnum.PP_USER,
                    parameters: [
                        {
                            name: 'userFileNo',
                            value: '%',
                        },
                        {
                            name: 'userUsername',
                            value: `${String(modalViewerInputWatch)}%`,
                        },
                        {
                            name: 'userFirstName',
                            value: '%',
                        },
                        {
                            name: 'userLastName',
                            value: '%',
                        },
                        {
                            name: 'userOrganizationOid',
                            value: '%',
                        },
                        {
                            name: 'userUnitOid',
                            value: '%',
                        },
                        {
                            name: 'userTitleOid',
                            value: '%',
                        },
                        {
                            name: 'userChannelCode',
                            value: '%',
                        },
                        {
                            name: 'userOid',
                            value: '%',
                        },
                        {
                            name: 'userActive',
                            value: `${getValues('cmbUserActive')}%`,
                        },
                        {
                            name: 'userLogin',
                            value: `${getValues('cmbUserLogin')}%`,
                        },
                        {
                            name: 'userChargedOrgOid',
                            value:
                                getGlobalsData({ key: GlobalsItemEnum.OrganizationType }) === '20'
                                    ? `${getValues('cmbUserChargedOrganization')}%`
                                    : '%',
                        },
                        {
                            name: 'userChargedOtherOrgOid',
                            value: '%',
                        },
                        {
                            name: 'userStatus',
                            value: '%',
                        },
                        {
                            name: 'profileCode',
                            value: '%',
                        },
                        {
                            name: 'userChargedUnitOid',
                            value: '%',
                        },
                    ],
                    offset: offset,
                    limit: limit,
                },
            });
            if ((response.status = HttpStatusCodeEnum.Ok)) {
                const responseData = response?.data?.resultList;
                if (responseData?.length) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        referenceDataCall();
                        adminUsrProfileListForComboCall({
                            data: {
                                usrListType: '1',
                            },
                        });
                        setUserInquiryDataGridData(responseData);
                    }
                } else {
                    referenceDataCall();
                    adminUsrProfileListForComboCall({
                        data: {
                            usrListType: '1',
                        },
                    });
                    setUserInquiryDataGridData([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else {
            referenceDataCall();
            adminUsrProfileListForComboCall({
                data: {
                    usrListType: '1',
                },
            });
        }
    };

    useEffect(() => {
        if (show && modalShow && cmbUserOrganizationVal) {
            setValue('cmbUserUnit', '');
            adminOrgOrganizationUnitListForComboCall({
                data: {
                    orgCode: null,
                    orgOid: cmbUserOrganizationVal,
                    orgUnitListType: '0',
                },
            });
        }
    }, [cmbUserOrganizationVal]);

    useEffect(() => {
        if (show && modalShow && cmbUserChargedOrganizationVal) {
            setValue('cmbUserChargedUnit', '');
            adminOrgOrganizationUnitListForComboCall({
                data: {
                    orgCode: null,
                    orgOid: cmbUserChargedOrganizationVal,
                    orgUnitListType: '0',
                },
            });
        }
    }, [cmbUserChargedOrganizationVal]);

    useEffect(() => {
        if (show) {
            getGlobalsData({ key: GlobalsItemEnum.OrganizationType }) === '20' &&
                adminOrgOrganizationUnitListForComboCall({
                    data: {
                        orgCode: null,
                        orgOid: String(getGlobalsData({ key: GlobalsItemEnum.ChargedOrganizationOID })),
                        orgUnitListType: '0',
                    },
                });
        }
    }, [show]);

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (
            show &&
            !referenceDatasLoading &&
            !adminUsrProfileListForComboLoading &&
            referenceDatas?.resultList?.length &&
            adminUsrProfileListForComboData?.usrProfilesList?.length &&
            !referenceDatasError &&
            !adminUsrProfileListForComboError
        ) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, adminUsrProfileListForComboLoading, adminUsrProfileListForComboData, referenceDatas]);

    useEffect(() => {
        if (referenceDatasError || adminUsrProfileListForComboError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.userInquiry),
                }),
            });
        }
    }, [referenceDatasError, adminUsrProfileListForComboError]);

    useEffect(() => {
        if (adminUsrProfileListForComboError || referenceDatasError) {
            show && !modalShow && closeModal();
        }
    }, [referenceDatasError, adminUsrProfileListForComboError]);

    return (
        <Modal
            maxWidth="lg"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.userInquiry)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 4}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 4,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 4,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 4,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Input
                                                name="txtUserName"
                                                control={control}
                                                label={t(locale.labels.userCode)}
                                                {...componentProps?.inputProps?.txtUserName}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="txtUserFileNo"
                                                control={control}
                                                label={t(locale.labels.registryNo)}
                                                {...componentProps?.inputProps?.txtUserFileNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="txtUserFirstName"
                                                control={control}
                                                label={t(locale.labels.name)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.txtUserFirstName}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="txtUserLastName"
                                                control={control}
                                                label={t(locale.labels.surname)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.txtUserLastName}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserOrganization"
                                                label={t(locale.labels.unit)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserOrganization}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserUnit"
                                                label={t(locale.labels.service)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        (cmbUserOrganizationVal &&
                                                            adminOrgOrganizationUnitListForComboData?.orgUnitList) ||
                                                        [],
                                                    displayField: '1',
                                                    displayValue: '0',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserUnit}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserChargedOrganization"
                                                label={t(locale.labels.assignedUnit)}
                                                control={control}
                                                setValue={setValue}
                                                readOnly={
                                                    getGlobalsData({ key: GlobalsItemEnum.OrganizationType }) === '20'
                                                }
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserChargedOrganization}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserChargedUnit"
                                                label={t(locale.labels.assignedService)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        (cmbUserChargedOrganizationVal &&
                                                            adminOrgOrganizationUnitListForComboData?.orgUnitList) ||
                                                        [],
                                                    displayField: '1',
                                                    displayValue: '0',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserChargedUnit}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserChargedOtherOrg"
                                                label={t(locale.labels.assignedOtherUnit)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserChargedOtherOrg}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserActive"
                                                label={t(locale.labels.activeness)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data: activityStatusData,
                                                    displayField: 'name',
                                                    displayValue: 'value',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserActive}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbChannelCode"
                                                label={t(locale.labels.assignedChannel)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) => item.name === ReferenceDataEnum.PRM_CHANNELS,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                    renderDisplayList: (value) => `${value.key} - ${value.value}`,
                                                    renderDisplayField: (value) => `${value.key} - ${value.value}`,
                                                }}
                                                {...componentProps?.selectProps?.cmbChannelCode}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserLogin"
                                                label={t(locale.labels.login)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data: utilsData.yesNoData,
                                                    displayField: 'name',
                                                    displayValue: 'value',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserLogin}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserTitle"
                                                label={t(locale.labels.title)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_ADMIN_USR_USER_TITLES_WITH_OID,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserTitle}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserProfile"
                                                label={t(locale.labels.profile)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data: adminUsrProfileListForComboData?.usrProfilesList || [],
                                                    displayField: '1',
                                                    displayValue: '0',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserProfile}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="cmbUserStatus"
                                                label={t(locale.labels.status)}
                                                control={control}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name === ReferenceDataEnum.PRM_ADMIN_USR_STATUS,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.cmbUserStatus}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem sm={12} ml={{ sm: 'auto' }}>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                onClick={handleSubmit(onSubmit)}
                                                fullWidth
                                            />
                                        </GridItem>
                                        <GridItem sm={12}>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                onClick={resetModal}
                                                variant="outlined"
                                                fullWidth
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <UserInquiryDataGrid
                                data={userInquiryDataGridData}
                                onReturnData={onReturnData}
                                closeModal={closeModal}
                                referenceDatas={referenceDatas}
                                apiRef={apiRef}
                                getUserInquiryDataGridData={getUserInquiryDataGridData}
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};
export default UserInquiryModal;
