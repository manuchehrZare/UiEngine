/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type {
    FetchType,
    IUnitInquiryModalProps,
    IUnitInquiryModalQueryFormValues,
    IUnitInquiryResultListItem,
} from './type';
import { FetchTypeEnum } from './type';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    NumberInput,
    Paper,
    Select,
    message,
    useForm,
    useDataGridApiRef,
    useWatch,
} from 'seker-ui';
import type { ReferenceDataRequest, ReferenceDataResponse } from '../../../../../utils';
import {
    HttpStatusCodeEnum,
    ReferenceDataEnum,
    constants,
    generateReferenceDataRequestList,
    useTranslation,
} from '../../../../../utils';
import UnitInquiryModalDataGrid from './UnitInquiryModalDataGrid';
import { useAxios } from '../../../../../hooks/useAxios';
import type {
    IRunQueryRequest,
    IRunQueryResponse,
} from '../../../../../utils/types/api/models/nova/infra/admin/popup/runQuery/type';
import { RunQueryPopupNamesEnum } from '../../../../../utils/types/api/models/nova/infra/admin/popup/runQuery/type';
import { sum } from 'lodash';

const defaultFormValues: IUnitInquiryModalQueryFormValues = {
    code: '',
    name: '',
    orgType: '',
};

const UnitInquiryModal: FC<IUnitInquiryModalProps> = ({
    show,
    onClose,
    eventOwnerEl,
    onReturnData,
    componentProps,
    inputProps,
    formData,
    payloadData,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [resultListData, setResultListData] = useState<IUnitInquiryResultListItem[]>([]);
    const [scrollFormData, setSetscrollFormData] = useState<IUnitInquiryModalQueryFormValues>(defaultFormValues);
    const [offset, setOffset] = useState<number>(1);
    const apiRef = useDataGridApiRef();
    const limit = 50;

    const { control, setValue, reset, handleSubmit, getValues } = useForm<IUnitInquiryModalQueryFormValues>({
        defaultValues: defaultFormValues,
    });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const getInitFormValues = (): IUnitInquiryModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control && inputProps?.name && { code: modalViewerInputWatch && modalViewerInputWatch }),
        ...formData,
    });

    const handleOnReturnData = (data: IUnitInquiryResultListItem) => {
        onReturnData?.(data);
    };

    const closeModal = () => {
        setOffset(1);
        setSetscrollFormData(defaultFormValues);
        onClose?.(false);
        setModalShow(false);
        setResultListData([]);
        reset();
    };

    const [{ data: referenceDatas, loading: referenceDatasLoading, error: referenceDatasError }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [
                            ReferenceDataEnum.PRM_ADMIN_ORG_ORGANIZATION_TYPE,
                            ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                        ],
                    }),
                },
            },
            { manual: true },
        );

    const [{ data: runQueryData, error: runQueryError }, runQueryCall] = useAxios<
        IRunQueryResponse<IUnitInquiryResultListItem>,
        IRunQueryRequest
    >(constants.api.endpoints.nova.infra.core.popup.runQuery.POST, {
        manual: true,
    });

    const getUnitInquiryDataGridData = async (fetchType: FetchType, formValues?: IUnitInquiryModalQueryFormValues) => {
        if ((runQueryData?.hasNext && fetchType === FetchTypeEnum.SCROLL) || fetchType === FetchTypeEnum.SUBMIT) {
            const payloadFormValues = fetchType === FetchTypeEnum.SUBMIT ? formValues : scrollFormData;

            const response = await runQueryCall({
                data: {
                    popupName: RunQueryPopupNamesEnum.PP_ORGANISATION,
                    parameters: [
                        {
                            name: 'orgType',
                            value: `${payloadFormValues?.orgType}%`,
                        },
                        {
                            name: 'name',
                            value: `%${payloadFormValues?.name}%`,
                        },
                        {
                            name: 'code',
                            value: `${payloadFormValues?.code}%`,
                        },
                    ],
                    offset: fetchType === FetchTypeEnum.SUBMIT ? 1 : sum([offset, limit]),
                    limit,
                },
            });

            if (response.status === HttpStatusCodeEnum.Ok) {
                if (fetchType === FetchTypeEnum.SUBMIT) {
                    if (response?.data?.resultList?.length) {
                        apiRef.current.scrollToIndexes({ rowIndex: 0 });
                        setOffset(1);
                        formValues && setSetscrollFormData(formValues);
                        setResultListData(response?.data?.resultList);
                    } else {
                        setResultListData([]);
                        message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                    }
                } else if (fetchType === FetchTypeEnum.SCROLL) {
                    if (response?.data?.resultList?.length) {
                        setOffset((prevState) => sum([prevState, limit]));
                        setResultListData((prevState) => {
                            return [...prevState, ...response.data.resultList];
                        });
                    }
                }
            }
        }
    };

    const onSubmit = async (formValues: IUnitInquiryModalQueryFormValues) => {
        getUnitInquiryDataGridData(FetchTypeEnum.SUBMIT, formValues);
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            setModalShow(false);
            const response = await runQueryCall({
                data: {
                    popupName: RunQueryPopupNamesEnum.PP_ORGANISATION,
                    parameters: [
                        { name: 'orgType', value: `${getInitFormValues()?.orgType || payloadData?.orgType || ''}%` },
                        { name: 'name', value: `%${getInitFormValues()?.name || payloadData?.name || ''}%` },
                        { name: 'code', value: `${getInitFormValues()?.code || payloadData?.code || ''}%` },
                    ],
                    offset: 1,
                    limit,
                },
            });
            if (response?.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.resultList;
                if (responseData?.length) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        setSetscrollFormData({
                            code: getInitFormValues()?.code || payloadData?.code || '',
                            name: getInitFormValues()?.name || payloadData?.name || '',
                            orgType: getInitFormValues()?.orgType || payloadData?.orgType || '',
                        });
                        setResultListData(responseData);
                        referenceDataCall();
                    }
                } else {
                    setModalShow(true);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else referenceDataCall();
    };

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (runQueryError) {
            show && !modalShow && closeModal();
        }
    }, [runQueryError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.unitInquiry),
                }),
            });
        }
    }, [referenceDatasError]);

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    return (
        <Modal maxWidth="md" show={modalShow} onClose={() => show && modalShow && closeModal()}>
            <ModalTitle>{t(locale.contentTitles.unitInquiry)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="common">
                                <GridItem>
                                    <Grid spacingType="form">
                                        <GridItem
                                            sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                            md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                            <Grid
                                                columns={{
                                                    xs: constants.design.gridItem.sizeType.form.SET.xs,
                                                    sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                                    md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                                    lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                                    xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                                    xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                                }}
                                                spacingType="form">
                                                <GridItem sizeType="form">
                                                    <Input
                                                        name="name"
                                                        label={t(locale.labels.unitName)}
                                                        control={control}
                                                        {...componentProps?.inputProps?.name}
                                                    />
                                                </GridItem>
                                                <GridItem sizeType="form">
                                                    <NumberInput
                                                        name="code"
                                                        label={t(locale.labels.unitCode)}
                                                        control={control}
                                                        allowLeadingZeros
                                                        returnValue="formattedValue"
                                                        {...componentProps?.numberInputProps?.code}
                                                    />
                                                </GridItem>
                                                <GridItem
                                                    sizeType="form"
                                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}>
                                                    <Select
                                                        name="orgType"
                                                        label={t(locale.labels.unitType)}
                                                        control={control}
                                                        setValue={setValue}
                                                        options={{
                                                            data:
                                                                referenceDatas?.resultList?.find(
                                                                    (item) =>
                                                                        item?.name ===
                                                                        ReferenceDataEnum.PRM_ADMIN_ORG_ORGANIZATION_TYPE,
                                                                )?.items || [],
                                                            displayField: 'value',
                                                            displayValue: 'key',
                                                        }}
                                                        {...componentProps?.selectProps?.orgType}
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                        <GridItem md>
                                            <Grid spacingType="button" pt={{ md: 2.25 }}>
                                                <GridItem>
                                                    <Button
                                                        text={t(locale.buttons.inquire)}
                                                        fullWidth
                                                        onClick={handleSubmit(onSubmit)}
                                                        {...componentProps?.buttonProps?.inquiryButton}
                                                    />
                                                </GridItem>
                                            </Grid>
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem>
                                    <Grid>
                                        <GridItem height={450}>
                                            <UnitInquiryModalDataGrid
                                                resultListData={resultListData}
                                                referenceDatas={referenceDatas}
                                                closeModal={closeModal}
                                                onReturnData={onReturnData}
                                                apiRef={apiRef}
                                                getUnitInquiryDataGridData={getUnitInquiryDataGridData}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default UnitInquiryModal;
