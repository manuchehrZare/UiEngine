/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Modal,
    ModalTitle,
    ModalBody,
    Grid,
    GridItem,
    NumberInput,
    Paper,
    useForm,
    DatePicker,
    Select,
    Button,
    Label,
    MessageTypeEnum,
    message,
    useWatch,
} from 'seker-ui';
import {
    constants,
    useTranslation,
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    getGenericSetCaller,
    unixtimeToStringDate,
    SETModalsEnum,
} from '../../../../../utils';
import type { IBpmProcessSelectionModalProps, IBpmProcessSelectionModalQueryFormValues } from './type';
import { BpmProcessSelectionStateEnum } from './type';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import ProcessSelectionDataGrid from './ProcessSelectionDataGrid';
import { useAxios } from '../../../../../hooks/useAxios';
import type {
    IBpmCoreProcessInstanceSearchRequest,
    IBpmCoreProcessInstanceSearchResponse,
    ICoreData,
} from '../../../../../utils/types/api/models/Infrastructure/bpmCoreProcessInstanceSearch/type';
import ModalViewer from '../../../../Others/ModalViewer';
import { omit } from 'lodash';

const BpmProcessSelectionModal: FC<IBpmProcessSelectionModalProps> = ({
    onClose,
    show,
    onReturnData,
    formData,
    inputProps,
    payloadData,
    eventOwnerEl,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [bpmCoreProcessInstanceSearchData, setBpmCoreProcessInstanceSearchData] = useState<ICoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const BpmProcessSelectionStateData = [
        {
            value: t(locale.labels.done),
            key: BpmProcessSelectionStateEnum.Done,
        },
        {
            value: t(locale.labels.undone),
            key: BpmProcessSelectionStateEnum.Undone,
        },
    ];

    const { control, setValue, reset, handleSubmit, getValues } = useForm<IBpmProcessSelectionModalQueryFormValues>({
        defaultValues: {
            customerNo: null,
            endDate1: null,
            endDate2: null,
            processDefinitionName: '',
            processStatus: '',
            referenceId: null,
            startDate1: null,
            startDate2: null,
        },
    });

    const [, bpmCoreProcessInstanceSearchCall] = useAxios<
        IBpmCoreProcessInstanceSearchResponse,
        IBpmCoreProcessInstanceSearchRequest
    >(getGenericSetCaller(GenericSetCallerEnum.BPM_CORE_PROCESS_INSTANCE_SEARCH), { manual: true });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const resetModal = () => {
        reset();
        setBpmCoreProcessInstanceSearchData([]);
    };

    const getInitFormValues = (): IBpmProcessSelectionModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name &&
            modalViewerInputWatch && { referenceId: Number(modalViewerInputWatch) }),
        ...formData,
    });

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            setModalShow(false);
            const response = await bpmCoreProcessInstanceSearchCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    ...omit(formData, ['customerNo', 'processDefinitionName', 'referenceId']),
                    customerNo: formData?.customerNo ? String(formData?.customerNo) : '',
                    processDefinitionName: formData?.processDefinitionName
                        ? String(formData?.processDefinitionName)
                        : '',
                    referenceId: modalViewerInputWatch ? String(modalViewerInputWatch) : '',
                },
            });
            if (response.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length && modalViewerInputWatch) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                        message({
                            variant: MessageTypeEnum.info,
                            message: t(locale.notifications.processReferenceSearch),
                        });
                    } else {
                        setModalShow(true);
                        setBpmCoreProcessInstanceSearchData(responseData);
                    }
                } else {
                    setModalShow(true);
                    setBpmCoreProcessInstanceSearchData([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else setModalShow(true);
    };

    const processInstanceSearchOnSubmit = async (data: IBpmProcessSelectionModalQueryFormValues) => {
        const response = await bpmCoreProcessInstanceSearchCall({
            data: {
                ...data,
                customerNo: data?.customerNo ? String(data?.customerNo) : '',
                endDate1: data?.endDate1 ? Number(unixtimeToStringDate(data?.endDate1)) : null,
                endDate2: data?.endDate2 ? Number(unixtimeToStringDate(data?.endDate2)) : null,
                processDefinitionName: data?.processDefinitionName ? String(data?.processDefinitionName) : '',
                referenceId: data?.referenceId ? String(data?.referenceId) : '',
                startDate1: data?.startDate1 ? Number(unixtimeToStringDate(data?.startDate1)) : null,
                startDate2: data?.startDate2 ? Number(unixtimeToStringDate(data?.startDate2)) : null,
            },
        });
        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (data?.referenceId && responseData?.length) {
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.processReferenceSearch) });
            }
            if (responseData) {
                setBpmCoreProcessInstanceSearchData(responseData);
            } else {
                setBpmCoreProcessInstanceSearchData([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        show && initControl();
    }, [show]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.processSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.selectionCriterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="referenceId"
                                                control={control}
                                                label={t(locale.labels.referenceNumber)}
                                                {...componentProps?.numberInputProps?.referenceId}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="customerNo"
                                                label={t(locale.labels.customerNumber)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.customerInquiry),
                                                }}
                                                decimalScale={0}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        data?.customerCode &&
                                                            setValue('customerNo', data?.customerCode);
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.customerNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.EprocProcessDefinitionSelectionModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.EprocProcessDefinitionSelectionModal}
                                                control={control}
                                                name="processDefinitionName"
                                                label={t(locale.labels.processCode)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.processDefinitionSelection),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        setValue('processDefinitionName', data?.eprocProcessId);
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.processDefinitionName}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="startDate1"
                                                control={control}
                                                label={t(locale.labels.startDateStart)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.startDate1}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="startDate2"
                                                control={control}
                                                label={t(locale.labels.startDateEnd)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.startDate2}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="endDate1"
                                                control={control}
                                                label={t(locale.labels.endDateStart)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.endDate1}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="endDate2"
                                                control={control}
                                                label={t(locale.labels.endDateEnd)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.endDate2}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="processStatus"
                                                control={control}
                                                label={t(locale.labels.status)}
                                                setValue={setValue}
                                                options={{
                                                    data: BpmProcessSelectionStateData,
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.processStatus}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                fullWidth
                                                onClick={handleSubmit(processInstanceSearchOnSubmit)}
                                                {...componentProps?.buttonProps}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                variant="outlined"
                                                iconLeft={<CleaningServices />}
                                                fullWidth
                                                onClick={() => resetModal()}
                                                {...componentProps?.buttonProps}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <ProcessSelectionDataGrid
                                onReturnData={onReturnData}
                                data={bpmCoreProcessInstanceSearchData}
                                closeModal={closeModal}
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default BpmProcessSelectionModal;
