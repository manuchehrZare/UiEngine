/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type { Control } from 'seker-ui';
import {
    Modal,
    ModalTitle,
    ModalBody,
    Grid,
    GridItem,
    NumberInput,
    Paper,
    useForm,
    DatePicker,
    Select,
    Button,
    Label,
    MessageTypeEnum,
    message,
    useWatch,
} from 'seker-ui';
import type {
    IEprocProcessDefinitionSearchCoreData,
    ReferenceDataResponse,
    ReferenceDataRequest,
} from '../../../../../utils';
import {
    constants,
    useTranslation,
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    getGenericSetCaller,
    SETModalsEnum,
    ReferenceDataEnum,
    generateReferenceDataRequestList,
    unixtimeToStringDate,
} from '../../../../../utils';
import { CleaningServices, HighlightOutlined } from '@mui/icons-material';
import EprocProcessSelectionDataGrid from './EprocProcessSelectionDataGrid';
import { useAxios } from '../../../../../hooks/useAxios';
import ModalViewer from '../../../../Others/ModalViewer';
import type { IEprocProcessSelectionModalProps, IEprocProcessSelectionModalQueryFormValues } from './type';
import { EprocProcessSelectionStateEnum } from './type';
import type {
    ICoreData,
    IEprocProcessInstanceSearchRequest,
    IEprocProcessInstanceSearchResponse,
} from '../../../../../utils/types/api/models/Infrastructure/eprocProcessInstanceSearch/type';
import { getUnixTime } from 'date-fns';

const EprocProcessSelectionModal: FC<IEprocProcessSelectionModalProps> = ({
    onClose,
    show,
    onReturnData,
    formData,
    inputProps,
    payloadData,
    eventOwnerEl,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [eprocProcessInstanceSearchData, setEprocProcessInstanceSearchData] = useState<ICoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const EprocProcessSelectionStateData = [
        {
            value: t(locale.labels.done),
            key: EprocProcessSelectionStateEnum.Done,
        },
        {
            value: t(locale.labels.undone),
            key: EprocProcessSelectionStateEnum.Undone,
        },
    ];

    const { control, setValue, reset, handleSubmit, getValues } = useForm<IEprocProcessSelectionModalQueryFormValues>({
        defaultValues: {
            eprocCustomerNo: null,
            eprocEnd1: getUnixTime(new Date()),
            eprocEnd2: getUnixTime(new Date()),
            eprocProcessId: '',
            eprocStatus: '',
            eprocReferenceId: null,
            eprocStart1: getUnixTime(new Date()),
            eprocStart2: getUnixTime(new Date()),
            eprocProcessOrganization: '',
        },
    });

    const [{ data: referenceDatas, loading: referenceDatasLoading, error: referenceDatasError }, referenceDataCall] =
        useAxios<ReferenceDataResponse, ReferenceDataRequest>(
            {
                ...constants.api.endpoints.nova.gateway.referenceData.POST,
                data: {
                    requestList: generateReferenceDataRequestList({
                        nameList: [ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_ORG_LIST_WITH_OID],
                    }),
                },
            },
            { manual: true },
        );

    const [{ error: eprocProcessInstanceSearchError }, eprocProcessInstanceSearchCall] = useAxios<
        IEprocProcessInstanceSearchResponse,
        IEprocProcessInstanceSearchRequest
    >(getGenericSetCaller(GenericSetCallerEnum.EPROC_PROCESS_INSTANCE_SEARCH), { manual: true });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const resetModal = () => {
        reset();
        setEprocProcessInstanceSearchData([]);
    };

    const getInitFormValues = (): IEprocProcessSelectionModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name &&
            modalViewerInputWatch && { eprocReferenceId: Number(modalViewerInputWatch) }),
        ...formData,
    });

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            const response = await eprocProcessInstanceSearchCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                    eprocCustomerNo: formData?.eprocCustomerNo ? String(formData?.eprocCustomerNo) : '',
                    eprocEnd1: formData?.eprocEnd1 ? unixtimeToStringDate(formData?.eprocEnd1) : '',
                    eprocEnd2: formData?.eprocEnd2 ? unixtimeToStringDate(formData?.eprocEnd2) : '',
                    eprocProcessId: formData?.eprocProcessId ? String(formData?.eprocProcessId) : '',
                    eprocReferenceId: modalViewerInputWatch ? String(modalViewerInputWatch) : '',
                    eprocStart1: formData?.eprocStart1 ? unixtimeToStringDate(formData?.eprocStart1) : '',
                    eprocStart2: formData?.eprocStart2 ? unixtimeToStringDate(formData?.eprocStart2) : '',
                    requestSource: 'INFRA',
                    requestType: 'R',
                },
            });
            if (response?.status === HttpStatusCodeEnum.Ok) {
                const responseData = response?.data?.coreData;
                if (responseData?.length && formData?.eprocReferenceId) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                        message({
                            variant: MessageTypeEnum.info,
                            message: t(locale.notifications.processReferenceSearch),
                        });
                    } else {
                        referenceDataCall();
                        setEprocProcessInstanceSearchData(responseData);
                    }
                } else {
                    referenceDataCall();
                    setEprocProcessInstanceSearchData([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else referenceDataCall();
    };

    const processInstanceSearchOnSubmit = async (data: IEprocProcessSelectionModalQueryFormValues) => {
        const response = await eprocProcessInstanceSearchCall({
            data: {
                ...data,
                eprocCustomerNo: data?.eprocCustomerNo ? String(data?.eprocCustomerNo) : '',
                eprocEnd1: data?.eprocEnd1 ? unixtimeToStringDate(data?.eprocEnd1) : '',
                eprocEnd2: data?.eprocEnd2 ? unixtimeToStringDate(data?.eprocEnd2) : '',
                eprocProcessId: data?.eprocProcessId ? String(data?.eprocProcessId) : '',
                eprocReferenceId: data?.eprocReferenceId ? String(data?.eprocReferenceId) : '',
                eprocStart1: data?.eprocStart1 ? unixtimeToStringDate(data?.eprocStart1) : '',
                eprocStart2: data?.eprocStart2 ? unixtimeToStringDate(data?.eprocStart2) : '',
                requestSource: 'INFRA',
                requestType: 'R',
            },
        });
        if (response.status === HttpStatusCodeEnum.Ok) {
            const responseData = response?.data?.coreData;
            if (data?.eprocReferenceId && responseData?.length) {
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.processReferenceSearch) });
            }
            if (responseData) {
                setEprocProcessInstanceSearchData(responseData);
            } else {
                setEprocProcessInstanceSearchData([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };

    useEffect(() => {
        if (show && !referenceDatasLoading && referenceDatas?.resultList?.length && !referenceDatasError) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [referenceDatasLoading, referenceDatas]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (eprocProcessInstanceSearchError) {
            show && !modalShow && closeModal();
        }
    }, [eprocProcessInstanceSearchError]);

    useEffect(() => {
        if (referenceDatasError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.processSelection),
                }),
            });
        }
    }, [referenceDatasError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.processSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Label text={t(locale.contentTitles.selectionCriterias)} />
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <NumberInput
                                                name="eprocReferenceId"
                                                control={control}
                                                label={t(locale.labels.referenceNumber)}
                                                {...componentProps?.numberInputProps?.eprocReferenceId}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.CustomerInquiryModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.CustomerInquiryModal}
                                                control={control}
                                                name="eprocCustomerNo"
                                                label={t(locale.labels.customerNumber)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.customerInquiry),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: any) => {
                                                        data?.customerCode &&
                                                            setValue('eprocCustomerNo', data?.customerCode);
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.eprocCustomerNo}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <ModalViewer<SETModalsEnum.EprocProcessDefinitionSelectionModal>
                                                component="NumberInput"
                                                modalComponent={SETModalsEnum.EprocProcessDefinitionSelectionModal}
                                                control={control}
                                                name="eprocProcessId"
                                                label={t(locale.labels.processCode)}
                                                adornmentButtonProps={{
                                                    tooltip: t(locale.contentTitles.processDefinitionSelection),
                                                }}
                                                modalProps={{
                                                    onReturnData: (data: IEprocProcessDefinitionSearchCoreData) => {
                                                        setValue('eprocProcessId', data?.eprocProcessId);
                                                    },
                                                }}
                                                {...componentProps?.numberInputProps?.eprocProcessId}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="eprocProcessOrganization"
                                                control={control}
                                                label={t(locale.labels.processStarterUnit)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        referenceDatas?.resultList?.find(
                                                            (item) =>
                                                                item?.name ===
                                                                ReferenceDataEnum.PRM_ADMIN_ORG_OPEN_ORG_LIST_WITH_OID,
                                                        )?.items || [],
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.eprocProcessOrganization}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="eprocStart1"
                                                control={control}
                                                label={t(locale.labels.entryDateStart)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.eprocStart1}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="eprocStart2"
                                                control={control}
                                                label={t(locale.labels.entryDateEnd)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.eprocStart2}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="eprocEnd1"
                                                control={control}
                                                label={t(locale.labels.executionDateStart)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.eprocEnd1}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <DatePicker
                                                name="eprocEnd2"
                                                control={control}
                                                label={t(locale.labels.executionDateEnd)}
                                                unixTime
                                                {...componentProps?.datePickerProps?.eprocEnd2}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Select
                                                name="eprocStatus"
                                                control={control}
                                                label={t(locale.labels.status)}
                                                setValue={setValue}
                                                options={{
                                                    data: EprocProcessSelectionStateData,
                                                    displayField: 'value',
                                                    displayValue: 'key',
                                                }}
                                                {...componentProps?.selectProps?.eprocStatus}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                fullWidth
                                                onClick={handleSubmit(processInstanceSearchOnSubmit)}
                                                {...componentProps?.buttonProps}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                variant="outlined"
                                                iconLeft={<CleaningServices />}
                                                fullWidth
                                                onClick={() => resetModal()}
                                                {...componentProps?.buttonProps}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <EprocProcessSelectionDataGrid
                                onReturnData={onReturnData}
                                data={eprocProcessInstanceSearchData}
                                closeModal={closeModal}
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default EprocProcessSelectionModal;
