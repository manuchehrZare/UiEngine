import type { IHelperModalProps } from '../../../../../utils';

export interface IExtractModalProps extends Pick<IHelperModalProps, 'onClose' | 'show'> {
    bankStatementOid: string;
}

export interface ISendEmailExtractModalProps extends Pick<IHelperModalProps, 'onClose' | 'show'> {
    bankStatementOid: string;
}

export interface ISendEmailExtractFormValues {
    from: string;
    message: string;
    subject: string;
    to: string;
}

export enum DefaultClassName {
    EXTRACT_MODAL_HIDDEN_CONTROL = 'extract-modal-hidden-control',
}
