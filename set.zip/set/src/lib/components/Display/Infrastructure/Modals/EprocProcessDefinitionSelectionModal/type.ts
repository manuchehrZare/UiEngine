import type { IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../utils';
import type {
    ICoreData,
    IEprocProcessDefinitionSearchRequest,
} from '../../../../../utils/types/api/models/Infrastructure/eprocProcessDefinitionSearch/type';
import type { IProcessGroupTable } from '../../../../../utils/types/api/models/Infrastructure/eprocDefinitionGetProcessGroupsForcomboSpecial/type';

export interface IEprocProcessDefinitionSelectionModalQueryFormValues {
    eprocGroupOid: string;
    eprocProcessId: string;
    eprocProcessName: string;
}

type IInputType = Partial<
    Record<
        `${keyof Pick<IEprocProcessDefinitionSelectionModalQueryFormValues, 'eprocProcessId' | 'eprocProcessName'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<IEprocProcessDefinitionSelectionModalQueryFormValues, 'eprocGroupOid'>}`]?: Pick<
        ISelectProps<IEprocProcessDefinitionSelectionModalQueryFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IEprocProcessDefinitionSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IEprocProcessDefinitionSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IEprocProcessDefinitionSelectionModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IEprocProcessDefinitionSelectionModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IEprocProcessDefinitionSearchRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IEprocProcessDefinitionSelectionModalDataGridProps {
    closeModal: () => void;
    data: ICoreData[];
    onReturnData?: (data: ICoreData) => void;
    processGroupData: IProcessGroupTable[];
}
