import type { IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../utils';
import type {
    IBpmCoreProcessDefinitionNameSearchRequest,
    ICoreData,
} from '../../../../../utils/types/api/models/Infrastructure/bpmCoreProcessDefinitionNameSearch/type';

export interface IBpmProcessDefinitionSelectionModalQueryFormValues {
    processDefinitionLabel: string;
    processDefinitionName: string;
    processGroupOid: string;
}

type IInputType = Partial<
    Record<
        `${keyof Pick<
            IBpmProcessDefinitionSelectionModalQueryFormValues,
            'processDefinitionLabel' | 'processDefinitionName'
        >}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<IBpmProcessDefinitionSelectionModalQueryFormValues, 'processGroupOid'>}`]?: Pick<
        ISelectProps<IBpmProcessDefinitionSelectionModalQueryFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IBpmProcessDefinitionSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IBpmProcessDefinitionSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IBpmProcessDefinitionSelectionModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IBpmProcessDefinitionSelectionModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IBpmCoreProcessDefinitionNameSearchRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IBpmProcessDefinitionSelectionModalDataGridProps {
    closeModal: () => void;
    data: ICoreData[];
    onReturnData?: (data: ICoreData) => void;
}
