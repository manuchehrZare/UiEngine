import type { IButtonProps, IInputProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../utils';
import type {
    ICoreData,
    IDmsStructListTypesRequest,
} from '../../../../../utils/types/api/models/Infrastructure/dmsStructListTypes/type';

export interface IDocumentTypesQueryFormValues {
    itemType: string;
}

type InputType = Partial<
    Record<`${keyof Pick<IDocumentTypesQueryFormValues, 'itemType'>}`, Pick<IInputProps, 'disabled' | 'readOnly'>>
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IDocumentTypesModalComponentProps {
    buttonProps: IButtonComponentProps;
    inputProps: InputType;
}

export interface IDocumentTypesModalProps
    extends Omit<IHelperModalProps, 'show' | 'onClose' | 'adornmentButtonProps'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IDocumentTypesModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IDocumentTypesQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => void;
    /**
     * Allows control of components within the modal.
     */
    payloadData?: Partial<IDmsStructListTypesRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}
