import type { FC, JSX } from 'react';
import type { ISendEmailExtractFormValues, ISendEmailExtractModalProps } from '../type';
import {
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle,
    Paper,
    message,
    useForm,
    validation,
} from 'seker-ui';
import {
    GenericSetCallerEnum,
    GlobalsItemEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    getGlobalsData,
    useTranslation,
} from '../../../../../../utils';
import { useAxios } from '../../../../../../hooks/useAxios';
import type {
    IIdcSendBankStatementRequest,
    IIdcSendBankStatementResponse,
} from '../../../../../../utils/types/api/models/Infrastructure/idcSendBankStatement/type';

const SendEmailExtractModal: FC<ISendEmailExtractModalProps> = ({ show, onClose, bankStatementOid }): JSX.Element => {
    const { t, locale } = useTranslation();

    const { control, handleSubmit, reset } = useForm<ISendEmailExtractFormValues>({
        defaultValues: {
            from: getGlobalsData({ key: GlobalsItemEnum.EmailAddress }) || '',
            message: '',
            subject: '',
            to: '',
        },
        validationSchema: {
            to: validation.string(t(locale.labels.toWho), { required: true }),
            from: validation.string(t(locale.labels.fromWho), { required: true }),
            subject: validation.string(t(locale.labels.subject), { required: true }),
            message: validation.string(t(locale.labels.message), { required: true }),
        },
    });

    const closeModal = () => {
        onClose?.(false);
        reset();
    };

    const [, idcSendBankStatementCall] = useAxios<IIdcSendBankStatementResponse, IIdcSendBankStatementRequest>(
        getGenericSetCaller(GenericSetCallerEnum.IDC_SEND_BANK_STATEMENT),
        { manual: true },
    );

    const onSubmit = async (formData: ISendEmailExtractFormValues) => {
        const response = await idcSendBankStatementCall({
            data: {
                bankStatementOid: bankStatementOid,
                ...formData,
            },
        });

        if (response.status === HttpStatusCodeEnum.Ok && Number(response.data.isMailSend)) {
            message({ variant: MessageTypeEnum.success, message: t(locale.notifications.succesEmailSendMessage) });
        }
    };

    return (
        <Modal
            show={show}
            onClose={() => {
                closeModal();
            }}
            maxWidth="md">
            <ModalTitle>{t(locale.contentTitles.sendEmailExtract)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sizeType="form"
                                    md={constants.design.gridItem.sizeType.form.SET.md * 2}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 2.5}
                                    xl={constants.design.gridItem.sizeType.form.SET.xl * 3}
                                    xxl={constants.design.gridItem.sizeType.form.SET.xxl * 4}>
                                    <Input name="from" control={control} label={t(locale.labels.fromWho)} readOnly />
                                </GridItem>
                                <GridItem
                                    sizeType="form"
                                    md={constants.design.gridItem.sizeType.form.SET.md * 2}
                                    lg={constants.design.gridItem.sizeType.form.SET.lg * 2.5}
                                    xl={constants.design.gridItem.sizeType.form.SET.xl * 3}
                                    xxl={constants.design.gridItem.sizeType.form.SET.xxl * 4}>
                                    <Input name="to" control={control} label={t(locale.labels.toWho)} />
                                </GridItem>
                                <GridItem>
                                    <Input name="subject" control={control} label={t(locale.labels.subject)} />
                                </GridItem>
                                <GridItem>
                                    <Input
                                        name="message"
                                        control={control}
                                        label={t(locale.labels.message)}
                                        rows={14}
                                        multiline
                                    />
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
            <ModalFooter>
                <Grid spacingType="button">
                    <GridItem>
                        <Button text={t(locale.buttons.send)} onClick={handleSubmit(onSubmit)} fullWidth />
                    </GridItem>
                </Grid>
            </ModalFooter>
        </Modal>
    );
};

export default SendEmailExtractModal;
