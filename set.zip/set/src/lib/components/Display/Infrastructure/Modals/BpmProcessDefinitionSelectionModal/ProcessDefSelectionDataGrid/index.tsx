import type { FC, JSX } from 'react';
import { useTranslation } from '../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem } from 'seker-ui';
import type { IBpmProcessDefinitionSelectionModalDataGridProps } from '../type';

const ProcessDefSelectionDataGrid: FC<IBpmProcessDefinitionSelectionModalDataGridProps> = ({
    data,
    closeModal,
    onReturnData,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'processGroupName',
            headerName: t(locale.contentTitles.processGroup),
            headerAlign: 'center',
            flex: 2,
            minWidth: 160,
        },
        {
            field: 'processDefinitionName',
            headerName: t(locale.contentTitles.processCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
        },
        {
            field: 'processDefinitionLabel',
            headerName: t(locale.contentTitles.processName),
            headerAlign: 'center',
            flex: 3,
            minWidth: 300,
        },
    ];
    return (
        <Grid>
            <GridItem height={300}>
                <DataGrid
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={(row) => {
                        onReturnData?.(row?.row);
                        closeModal();
                    }}
                />
            </GridItem>
        </Grid>
    );
};

export default ProcessDefSelectionDataGrid;
