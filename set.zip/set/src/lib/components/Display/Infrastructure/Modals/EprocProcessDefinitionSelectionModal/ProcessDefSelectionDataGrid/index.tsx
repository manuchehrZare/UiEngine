import type { FC, JSX } from 'react';
import { useTranslation } from '../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem } from 'seker-ui';
import type { IEprocProcessDefinitionSelectionModalDataGridProps } from '../type';

const ProcessDefSelectionDataGrid: FC<IEprocProcessDefinitionSelectionModalDataGridProps> = ({
    data,
    closeModal,
    onReturnData,
    processGroupData,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'eprocGroupOid',
            headerName: t(locale.contentTitles.processGroup),
            headerAlign: 'center',
            flex: 2,
            minWidth: 160,
            valueFormatter: (value) => {
                return processGroupData?.find((item) => item[0] === value)?.[1];
            },
        },
        {
            field: 'eprocProcessId',
            headerName: t(locale.contentTitles.processCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
        },
        {
            field: 'eprocProcessName',
            headerName: t(locale.contentTitles.processName),
            headerAlign: 'center',
            flex: 3,
            minWidth: 320,
        },
        {
            field: 'eprocIsEproc',
            headerName: t(locale.contentTitles.isEproc),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 100,
        },
    ];
    return (
        <Grid>
            <GridItem height={300}>
                <DataGrid
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={(row) => {
                        onReturnData?.(row?.row);
                        closeModal();
                    }}
                />
            </GridItem>
        </Grid>
    );
};

export default ProcessDefSelectionDataGrid;
