import type { IButtonProps, IInputProps, ISelectProps } from 'seker-ui';
import type {
    IHelperModalProps,
    IRunQueryRequest,
    ReferenceDataResponse,
    SETModalsCommonProps,
} from '../../../../../utils';
import type { MutableRefObject } from 'react';

export interface IUserInquiryModalQueryFormValues {
    cmbChannelCode: string;
    cmbUserActive: string;
    cmbUserChargedOrganization: string | null;
    cmbUserChargedOtherOrg: string;
    cmbUserChargedUnit: string;
    cmbUserLogin: string;
    cmbUserOrganization: string;
    cmbUserProfile: string;
    cmbUserStatus: string;
    cmbUserTitle: string;
    cmbUserUnit: string;
    txtUserFileNo: string;
    txtUserFirstName: string;
    txtUserLastName: string;
    txtUserName: string;
}

export interface IUserInquiryModalResultListItem {
    userActive: string;
    userChannelCode: string;
    userChargedOrganization: string;
    userChargedOrganizationOid: string;
    userChargedOrgCode: string;
    userChargedOtherOrg: string | null;
    userChargedOtherOrgCode: string | null;
    userChargedOtherOrgOid: string | null;
    userChargedUnit: string;
    userChargedUnitOid: string;
    userExpirationDate: string;
    userFileNo: string;
    userFirstName: string;
    userLastName: string;
    userLogin: string;
    userName: string;
    userNote: null;
    userOid: string;
    userOrganization: string;
    userOrganizationOid: string;
    userOrgCode: string;
    userStatus: string;
    userTitle: string;
    userTitleOid: string;
    userUnit: string;
    userUnitOid: string;
}

type ISelectType = {
    [Property in `${keyof Pick<
        IUserInquiryModalQueryFormValues,
        | 'cmbUserUnit'
        | 'cmbChannelCode'
        | 'cmbUserActive'
        | 'cmbUserChargedOrganization'
        | 'cmbUserChargedOtherOrg'
        | 'cmbUserChargedUnit'
        | 'cmbUserLogin'
        | 'cmbUserOrganization'
        | 'cmbUserProfile'
        | 'cmbUserStatus'
        | 'cmbUserTitle'
    >}`]?: Pick<ISelectProps<IUserInquiryModalQueryFormValues[Property]>, 'disabled' | 'readOnly'>;
};

type IInputType = Partial<
    Record<
        `${keyof Pick<
            IUserInquiryModalQueryFormValues,
            'txtUserFileNo' | 'txtUserFirstName' | 'txtUserLastName' | 'txtUserName'
        >}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IUserInquiryModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    selectProps?: ISelectType;
}

export interface IUserInquiryModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IUserInquiryModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IUserInquiryModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: IUserInquiryModalResultListItem) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IRunQueryRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export enum UserInquiryModalActivityStatusDataEnum {
    Active = '1',
    Inactive = '0',
}

export interface IUserInquiryDataGridProps {
    apiRef: MutableRefObject<any>;
    closeModal: () => void;
    data?: IUserInquiryModalResultListItem[];
    getUserInquiryDataGridData: (fetchType: FetchType, formValues?: IUserInquiryModalQueryFormValues) => Promise<void>;
    onReturnData?: (data: IUserInquiryModalResultListItem) => void;
    referenceDatas?: ReferenceDataResponse;
}

export enum FetchTypeEnum {
    SCROLL = 'scroll',
    SUBMIT = 'submit',
}

export type FetchType = `${FetchTypeEnum}`;
