import type { IButtonProps, IDatePickerProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type { IHelperModalProps, SETModalsCommonProps } from '../../../../../utils';
import type {
    IBpmCoreProcessInstanceSearchRequest,
    ICoreData,
} from '../../../../../utils/types/api/models/Infrastructure/bpmCoreProcessInstanceSearch/type';

export interface IBpmProcessSelectionModalQueryFormValues {
    customerNo: number | null;
    endDate1: number | null;
    endDate2: number | null;
    processDefinitionName: number | string;
    processStatus: string;
    referenceId: number | null;
    startDate1: number | null;
    startDate2: number | null;
}

type INumberInputType = Partial<
    Record<
        `${keyof Pick<
            IBpmProcessSelectionModalQueryFormValues,
            'referenceId' | 'customerNo' | 'processDefinitionName'
        >}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<IBpmProcessSelectionModalQueryFormValues, 'processStatus'>}`]?: Pick<
        ISelectProps<IBpmProcessSelectionModalQueryFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type IDatePickerType = Partial<
    Record<
        `${keyof Pick<
            IBpmProcessSelectionModalQueryFormValues,
            'endDate1' | 'endDate2' | 'startDate1' | 'startDate2'
        >}`,
        Pick<IDatePickerProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}
export interface IBpmProcessSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    datePickerProps?: IDatePickerType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}
export interface IBpmProcessSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IBpmProcessSelectionModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IBpmProcessSelectionModalQueryFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreData) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IBpmCoreProcessInstanceSearchRequest>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IBpmProcessSelectionModalDatagridProps {
    closeModal: () => void;
    data: ICoreData[];
    onReturnData?: (data: ICoreData) => void;
}

export enum BpmProcessSelectionStateEnum {
    Done = '1',
    Undone = '0',
}
