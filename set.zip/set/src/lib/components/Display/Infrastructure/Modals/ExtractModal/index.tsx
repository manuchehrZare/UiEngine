/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import { Button, Grid, GridItem, Modal, ModalBody, ModalFooter, ModalTitle, Paper, useMeasure } from 'seker-ui';
import type { IExtractModalProps } from './type';
import { DefaultClassName } from './type';
import type { AxiosError } from '../../../../../utils';
import {
    GenericSetCallerEnum,
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useTranslation,
} from '../../../../../utils';
import SendEmailExtractModal from './SendEmailExtractModal';
import { useAxios } from '../../../../../hooks/useAxios';
import type {
    IIdcLoadBankStatementRequest,
    IIdcLoadBankStatementResponse,
} from '../../../../../utils/types/api/models/Infrastructure/idcLoadBankStatement/type';
import { DmsDocumentViewer } from '../../../../../../lib';
import type { IDmsDocGetDocContentRequest } from '../../../../../utils/types/api/models/Infrastructure/dmsDocGetDocContent/type';
import { sum } from 'lodash';

const ExtractModal: FC<IExtractModalProps> = ({ show, onClose, bankStatementOid }): JSX.Element => {
    const { t, locale } = useTranslation();
    const modalTitleMeasure = useMeasure();
    const modalFooterMeasure = useMeasure();
    const [sendEmailExtractModalShow, setSendEmailExtractModalShow] = useState<boolean>(false);
    const [modalShow, setModalShow] = useState<boolean>(false);
    const [documentViewerRequestData, setDocumentViewerRequestData] = useState<IDmsDocGetDocContentRequest>({
        docVersion: '',
        docVersionPiid: '',
        docHttpUrl: '',
        piid: '',
        restrictionNeeded: '',
    });
    const [documentViewerError, setDocumentViewerError] = useState<AxiosError<any, IDmsDocGetDocContentRequest> | null>(
        null,
    );

    const closeModal = () => {
        onClose?.(false);
        setModalShow(false);
    };

    const [{ error: idcLoadBankStatementError }, idcLoadBankStatementCall] = useAxios<
        IIdcLoadBankStatementResponse,
        IIdcLoadBankStatementRequest
    >(getGenericSetCaller(GenericSetCallerEnum.IDC_LOAD_BANK_STATEMENT), { manual: true });

    const getCallServices = async () => {
        const idcLoadBankStatementResponse = await idcLoadBankStatementCall({
            data: { bankStatementOid: bankStatementOid },
        });

        if (idcLoadBankStatementResponse.status === HttpStatusCodeEnum.Ok) {
            setModalShow(true);
            setDocumentViewerRequestData({
                docVersion: '',
                docVersionPiid: '',
                docHttpUrl: idcLoadBankStatementResponse?.data?.url,
                piid: '',
                restrictionNeeded: '0',
            });
        }
    };

    useEffect(() => {
        show && getCallServices();
    }, [show]);

    useEffect(() => {
        if (idcLoadBankStatementError || documentViewerError) {
            show && closeModal();
        }
    }, [idcLoadBankStatementError, documentViewerError]);

    return (
        <>
            <Modal
                show={modalShow}
                fullWidth
                onClose={closeModal}
                sx={{ [`&.${DefaultClassName.EXTRACT_MODAL_HIDDEN_CONTROL}`]: { display: 'none' } }}
                className={DefaultClassName.EXTRACT_MODAL_HIDDEN_CONTROL}
                fullHeight>
                <ModalTitle ref={modalTitleMeasure.ref}>{t(locale.contentTitles.extract)}</ModalTitle>
                <ModalBody sx={{ p: constants.design.grid.spacing.common.SET.unit }}>
                    <Grid spacingType="common" pt={constants.design.grid.spacing.common.SET.unit}>
                        <GridItem>
                            <Paper>
                                <DmsDocumentViewer
                                    payloadData={documentViewerRequestData}
                                    onError={(error) => setDocumentViewerError(error)}
                                    onReturnData={(data) => {
                                        data.status === HttpStatusCodeEnum.Ok &&
                                            document
                                                .getElementsByClassName(
                                                    `${DefaultClassName.EXTRACT_MODAL_HIDDEN_CONTROL}`,
                                                )[0]
                                                .classList.remove(`${DefaultClassName.EXTRACT_MODAL_HIDDEN_CONTROL}`);
                                    }}
                                    outerHeight={
                                        window.innerHeight -
                                        sum([
                                            modalFooterMeasure?.values?.height,
                                            modalTitleMeasure?.values?.height,
                                            constants.design.grid.spacing.common.SET.unit * 2,
                                            constants.design.padding.paper.y.pixel * 2,
                                            constants.design.border.paper.borderBox.SET.width * 2,
                                            86,
                                        ])
                                    }
                                />
                            </Paper>
                        </GridItem>
                    </Grid>
                </ModalBody>
                <ModalFooter ref={modalFooterMeasure.ref}>
                    <Grid spacingType="button">
                        <GridItem>
                            <Button
                                text={t(locale.buttons.sendEmail)}
                                onClick={() => setSendEmailExtractModalShow(true)}
                            />
                        </GridItem>
                    </Grid>
                </ModalFooter>
            </Modal>
            <SendEmailExtractModal
                show={sendEmailExtractModalShow}
                onClose={setSendEmailExtractModalShow}
                bankStatementOid={bankStatementOid}
            />
        </>
    );
};

export default ExtractModal;
