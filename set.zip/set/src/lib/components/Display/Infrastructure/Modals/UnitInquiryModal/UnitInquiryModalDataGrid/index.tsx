import type { FC, JSX } from 'react';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import { ReferenceDataEnum, useTranslation } from '../../../../../../utils';
import type { IUnitInquiryModalDataGridProps } from '../type';
import { FetchTypeEnum } from '../type';

const UnitInquiryModalDataGrid: FC<IUnitInquiryModalDataGridProps> = ({
    resultListData,
    referenceDatas,
    closeModal,
    onReturnData,
    apiRef,
    getUnitInquiryDataGridData,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'organizationCode',
            headerName: t(locale.contentTitles.unitCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 120,
            align: 'center',
        },
        {
            field: 'organizationName',
            headerName: t(locale.contentTitles.unitName),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
        },
        {
            field: 'parentOid',
            headerName: t(locale.contentTitles.topUnit),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
            valueOptions:
                referenceDatas?.resultList?.find(
                    (item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORG_LIST_WITH_OID,
                )?.items || [],
            getOptionLabel: (params: any) => params?.value,
            getOptionValue: (params: any) => params?.key,
            type: 'singleSelect',
        },
        {
            field: 'orgType',
            headerName: t(locale.contentTitles.unitType),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
            valueOptions:
                referenceDatas?.resultList?.find(
                    (item) => item?.name === ReferenceDataEnum.PRM_ADMIN_ORG_ORGANIZATION_TYPE,
                )?.items || [],
            getOptionLabel: (params: any) => params?.value,
            getOptionValue: (params: any) => params?.key,
            type: 'singleSelect',
        },
        {
            field: 'canOperateForOther',
            headerName: t(locale.contentTitles.processForAnotherUnit),
            headerAlign: 'center',
            flex: 1,
            minWidth: 220,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'isBeingEstablished',
            headerName: t(locale.contentTitles.setupPhase),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'isClosed',
            headerName: t(locale.contentTitles.close),
            headerAlign: 'center',
            flex: 1,
            minWidth: 100,
            align: 'center',
            type: 'boolean',
            valueGetter: (value) => {
                if (value === '1') return true;
                if (value === '0') return false;
                return value;
            },
        },
        {
            field: 'eftCode',
            headerName: t(locale.contentTitles.eftCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 100,
            align: 'center',
        },
        {
            field: 'riskCentralizationCode',
            headerName: t(locale.contentTitles.riskCentralizationCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
            align: 'center',
        },
        {
            field: 'taxNumber',
            headerName: t(locale.contentTitles.taxNumber),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
            align: 'center',
        },
        {
            field: 'taxOfficeCode',
            headerName: t(locale.contentTitles.taxOfficeCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 150,
            align: 'center',
        },
    ];

    return (
        <DataGrid
            apiRef={apiRef}
            rows={resultListData}
            columns={columns}
            onRowDoubleClick={(params) => {
                onReturnData && params?.row && onReturnData(params.row);
                closeModal();
            }}
            onRowsScrollEnd={(_, __, details) =>
                (details as any)?.api?.getScrollPosition()?.top !== 0 &&
                getUnitInquiryDataGridData(FetchTypeEnum.SCROLL)
            }
        />
    );
};

export default UnitInquiryModalDataGrid;
