/* eslint-disable react-hooks/exhaustive-deps */
import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import type {
    IEprocProcessDefinitionSelectionModalProps,
    IEprocProcessDefinitionSelectionModalQueryFormValues,
} from './type';
import type { Control } from 'seker-ui';
import {
    Button,
    Grid,
    GridItem,
    Input,
    MessageTypeEnum,
    Modal,
    ModalBody,
    ModalTitle,
    Paper,
    Select,
    message,
    useForm,
    useWatch,
} from 'seker-ui';
import { HighlightOutlined, CleaningServices } from '@mui/icons-material';
import ProcessDefSelectionDataGrid from './ProcessDefSelectionDataGrid';
import type {
    IEprocDefinitionGetProcessGroupsForcomboSpecialResponse,
    IEprocDefinitionGetProcessGroupsForcomboSpecialRequest,
} from '../../../../../utils/types/api/models/Infrastructure/eprocDefinitionGetProcessGroupsForcomboSpecial/type';
import {
    HttpStatusCodeEnum,
    constants,
    getGenericSetCaller,
    useTranslation,
    GenericSetCallerEnum,
} from '../../../../../utils';
import { useAxios } from '../../../../..';
import type {
    ICoreData,
    IEprocProcessDefinitionSearchRequest,
    IEprocProcessDefinitionSearchResponse,
} from '../../../../../utils/types/api/models/Infrastructure/eprocProcessDefinitionSearch/type';

const EprocProcessDefinitionSelectionModal: FC<IEprocProcessDefinitionSelectionModalProps> = ({
    onClose,
    show,
    onReturnData,
    formData,
    eventOwnerEl,
    inputProps,
    payloadData,
    componentProps,
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [processDefSelectionDataGrid, setProcessDefSelectionDataGrid] = useState<ICoreData[]>([]);
    const [modalShow, setModalShow] = useState<boolean>(false);

    const { handleSubmit, control, setValue, reset, getValues } =
        useForm<IEprocProcessDefinitionSelectionModalQueryFormValues>({
            defaultValues: {
                eprocProcessName: formData?.eprocProcessName || '',
                eprocProcessId: formData?.eprocProcessId || '',
                eprocGroupOid: formData?.eprocGroupOid || '',
            },
        });
    const [
        {
            data: eprocDefinitionGetProcessGroupsForcomboSpecialData,
            error: eprocDefinitionGetProcessGroupsForcomboSpecialError,
            loading: eprocDefinitionGetProcessGroupsForcomboSpecialLoading,
        },
        eprocDefinitionGetProcessGroupsForcomboSpecialCall,
    ] = useAxios<
        IEprocDefinitionGetProcessGroupsForcomboSpecialResponse,
        IEprocDefinitionGetProcessGroupsForcomboSpecialRequest
    >(
        { ...getGenericSetCaller(GenericSetCallerEnum.EPROC_DEFINITION_GET_PROCESS_GROUPS_FORCOMBO_SPECIAL), data: {} },
        { manual: true },
    );

    const [, eprocProcessDefinitionSearchCall] = useAxios<
        IEprocProcessDefinitionSearchResponse,
        IEprocProcessDefinitionSearchRequest
    >(getGenericSetCaller(GenericSetCallerEnum.EPROC_PROCESS_DEFINITION_SEARCH), { manual: true });

    /**
     * For Modal Showable Component === 'Input' || 'NumberInput'
     */
    const modalViewerInputWatch =
        inputProps?.control &&
        inputProps?.name &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useWatch({
            control: inputProps?.control as Control,
            fieldName: inputProps?.name,
        });

    const onSubmit = async (data: IEprocProcessDefinitionSelectionModalQueryFormValues) => {
        const response = await eprocProcessDefinitionSearchCall({
            data: {
                ...data,
                eprocProcessName: data?.eprocProcessName?.toLocaleUpperCase('TR'),
            },
        });

        if ((response.status = HttpStatusCodeEnum.Ok)) {
            const responseData = response?.data?.coreData;
            if (responseData) {
                setProcessDefSelectionDataGrid(responseData);
            } else {
                setProcessDefSelectionDataGrid([]);
                message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
            }
        }
    };

    const resetModal = () => {
        reset();
        setProcessDefSelectionDataGrid([]);
    };

    const getInitFormValues = (): IEprocProcessDefinitionSelectionModalQueryFormValues => ({
        ...getValues(),
        ...(inputProps?.control &&
            inputProps?.name &&
            modalViewerInputWatch && { eprocProcessId: String(modalViewerInputWatch) }),
        ...formData,
    });

    const closeModal = () => {
        resetModal();
        setModalShow(false);
        onClose?.(false);
    };

    const handleOnReturnData = (data: ICoreData) => {
        onReturnData?.(data);
    };

    const initControl = async () => {
        setModalShow(false);
        if (eventOwnerEl === 'input') {
            setModalShow(false);
            const response = await eprocProcessDefinitionSearchCall({
                data: {
                    ...getInitFormValues(),
                    ...payloadData,
                },
            });
            if ((response.status = HttpStatusCodeEnum.Ok)) {
                const responseData = response?.data?.coreData;
                if (responseData) {
                    if (responseData?.length === 1) {
                        closeModal();
                        handleOnReturnData(responseData[0]);
                    } else {
                        eprocDefinitionGetProcessGroupsForcomboSpecialCall();
                        setProcessDefSelectionDataGrid(responseData);
                    }
                } else {
                    eprocDefinitionGetProcessGroupsForcomboSpecialCall();
                    setProcessDefSelectionDataGrid([]);
                    message({ variant: MessageTypeEnum.info, message: t(locale.notifications.noSearchedData) });
                }
            }
        } else eprocDefinitionGetProcessGroupsForcomboSpecialCall();
    };
    useEffect(() => {
        show && initControl();
    }, [show]);

    useEffect(() => {
        if (eprocDefinitionGetProcessGroupsForcomboSpecialError) {
            show && !modalShow && closeModal();
        }
    }, [eprocDefinitionGetProcessGroupsForcomboSpecialError]);

    useEffect(() => {
        if (modalShow) {
            reset(getInitFormValues());
        }
    }, [modalShow, formData]);

    useEffect(() => {
        if (
            show &&
            !eprocDefinitionGetProcessGroupsForcomboSpecialLoading &&
            eprocDefinitionGetProcessGroupsForcomboSpecialData?.processGroupTable?.length &&
            !eprocDefinitionGetProcessGroupsForcomboSpecialError
        ) {
            setModalShow(true);
        } else {
            modalShow && setModalShow(false);
        }
    }, [eprocDefinitionGetProcessGroupsForcomboSpecialLoading, eprocDefinitionGetProcessGroupsForcomboSpecialData]);

    useEffect(() => {
        if (eprocDefinitionGetProcessGroupsForcomboSpecialError) {
            show && closeModal();
            message({
                variant: MessageTypeEnum.warning,
                message: t(locale.notifications.componentCouldNotBeDisplayed, {
                    value: t(locale.contentTitles.processDefinitionSelection),
                }),
            });
        }
    }, [eprocDefinitionGetProcessGroupsForcomboSpecialError]);

    return (
        <Modal
            maxWidth="md"
            show={modalShow}
            onClose={() => {
                show && modalShow && closeModal();
            }}>
            <ModalTitle>{t(locale.contentTitles.processDefinitionSelection)}</ModalTitle>
            <ModalBody sx={{ p: constants.design.padding.common.unit }}>
                <Grid spacingType="common" pt={constants.design.padding.common.unit}>
                    <GridItem>
                        <Paper>
                            <Grid spacingType="form">
                                <GridItem
                                    sm={constants.design.gridItem.sizeType.form.SET.sm * 2}
                                    md={constants.design.gridItem.sizeType.form.SET.md * 3}>
                                    <Grid
                                        columns={{
                                            xs: constants.design.gridItem.sizeType.form.SET.xs,
                                            sm: constants.design.gridItem.sizeType.form.SET.sm * 2,
                                            md: constants.design.gridItem.sizeType.form.SET.md * 3,
                                            lg: constants.design.gridItem.sizeType.form.SET.lg * 3,
                                            xl: constants.design.gridItem.sizeType.form.SET.xl * 3,
                                            xxl: constants.design.gridItem.sizeType.form.SET.xxl * 3,
                                        }}
                                        spacingType="form">
                                        <GridItem sizeType="form">
                                            <Select
                                                name="eprocGroupOid"
                                                control={control}
                                                label={t(locale.labels.processGroup)}
                                                setValue={setValue}
                                                options={{
                                                    data:
                                                        eprocDefinitionGetProcessGroupsForcomboSpecialData?.processGroupTable ||
                                                        [],
                                                    displayField: 1,
                                                    displayValue: 0,
                                                }}
                                                {...componentProps?.selectProps?.eprocGroupOid}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="eprocProcessId"
                                                control={control}
                                                label={t(locale.labels.processCode)}
                                                {...componentProps?.inputProps?.eprocProcessId}
                                            />
                                        </GridItem>
                                        <GridItem sizeType="form">
                                            <Input
                                                name="eprocProcessName"
                                                control={control}
                                                label={t(locale.labels.processName)}
                                                sx={{
                                                    input: {
                                                        textTransform: 'uppercase',
                                                    },
                                                }}
                                                {...componentProps?.inputProps?.eprocProcessName}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                                <GridItem md>
                                    <Grid spacingType="button" pt={{ md: 2.25 }}>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.inquire)}
                                                iconLeft={<HighlightOutlined sx={{ transform: 'rotate(225deg)' }} />}
                                                fullWidth
                                                onClick={handleSubmit(onSubmit)}
                                                {...componentProps?.buttonProps}
                                            />
                                        </GridItem>
                                        <GridItem>
                                            <Button
                                                text={t(locale.buttons.cleanUp)}
                                                variant="outlined"
                                                fullWidth
                                                iconLeft={<CleaningServices />}
                                                onClick={() => resetModal()}
                                                {...componentProps?.buttonProps}
                                            />
                                        </GridItem>
                                    </Grid>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </GridItem>
                    <GridItem>
                        <Paper>
                            <ProcessDefSelectionDataGrid
                                data={processDefSelectionDataGrid}
                                closeModal={closeModal}
                                onReturnData={onReturnData}
                                processGroupData={
                                    eprocDefinitionGetProcessGroupsForcomboSpecialData?.processGroupTable || []
                                }
                            />
                        </Paper>
                    </GridItem>
                </Grid>
            </ModalBody>
        </Modal>
    );
};

export default EprocProcessDefinitionSelectionModal;
