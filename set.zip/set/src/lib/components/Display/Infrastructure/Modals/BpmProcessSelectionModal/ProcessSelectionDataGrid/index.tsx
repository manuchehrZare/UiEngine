import type { FC, JSX } from 'react';
import { useTranslation, stringToStringDate } from '../../../../../../utils';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem } from 'seker-ui';
import type { IBpmProcessSelectionModalDatagridProps } from '../type';

const ProcessSelectionDataGrid: FC<IBpmProcessSelectionModalDatagridProps> = ({
    data,
    onReturnData,
    closeModal,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'referenceId',
            headerName: t(locale.contentTitles.referenceNumber),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'makerName',
            headerName: t(locale.contentTitles.processStarter),
            headerAlign: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'processId',
            headerName: t(locale.contentTitles.processCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'processDefinitionLabel',
            headerName: t(locale.contentTitles.processName),
            headerAlign: 'center',
            flex: 1,
            minWidth: 200,
        },
        {
            field: 'processStatus',
            headerName: t(locale.contentTitles.status),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
        },
        {
            field: 'start',
            headerName: t(locale.contentTitles.startDate),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 150,
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
        {
            field: 'end',
            headerName: t(locale.contentTitles.endDate),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
            valueFormatter: (value) => (value ? stringToStringDate(String(value)) : ''),
        },
    ];

    return (
        <Grid>
            <GridItem height={300}>
                <DataGrid
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={(row) => {
                        onReturnData?.(row?.row);
                        closeModal();
                    }}
                />
            </GridItem>
        </Grid>
    );
};

export default ProcessSelectionDataGrid;
