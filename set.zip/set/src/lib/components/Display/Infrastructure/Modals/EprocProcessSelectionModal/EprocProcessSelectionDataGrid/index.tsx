import type { FC, JSX } from 'react';
import { useTranslation } from '../../../../../../utils';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum, Grid, GridItem } from 'seker-ui';
import type { IEprocProcessSelectionModalDatagridProps } from '../type';
import { EprocProcessSelectionStateEnum } from '../type';

const EprocProcessSelectionDataGrid: FC<IEprocProcessSelectionModalDatagridProps> = ({
    data,
    onReturnData,
    closeModal,
}): JSX.Element => {
    const { t, locale } = useTranslation();

    const EprocProcessSelectionStateData = [
        {
            value: t(locale.labels.done),
            key: EprocProcessSelectionStateEnum.Done,
        },
        {
            value: t(locale.labels.undone),
            key: EprocProcessSelectionStateEnum.Undone,
        },
    ];

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            width: 30,
            align: 'center',
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'referenceId',
            headerName: t(locale.contentTitles.referenceNumber),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'user',
            headerName: t(locale.contentTitles.processStarter),
            headerAlign: 'center',
            flex: 1,
            minWidth: 180,
        },
        {
            field: 'processName',
            headerName: t(locale.contentTitles.processName),
            headerAlign: 'center',
            flex: 2,
            minWidth: 200,
        },
        {
            field: 'status',
            headerName: t(locale.contentTitles.status),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 120,
            valueFormatter: (value) => {
                return EprocProcessSelectionStateData?.find((item) => item?.key === String(value))?.value;
            },
        },
    ];

    return (
        <Grid>
            <GridItem height={300}>
                <DataGrid
                    columns={columns}
                    rows={data || []}
                    onRowDoubleClick={(row) => {
                        onReturnData?.(row?.row);
                        closeModal();
                    }}
                />
            </GridItem>
        </Grid>
    );
};

export default EprocProcessSelectionDataGrid;
