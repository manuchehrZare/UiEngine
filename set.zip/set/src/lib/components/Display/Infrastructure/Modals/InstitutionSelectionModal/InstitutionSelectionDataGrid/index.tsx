import type { FC } from 'react';
import type { ICoreDataItem } from '../../../../../..';
import { useTranslation } from '../../../../../..';
import type { DataGridColumnsPropsType } from 'seker-ui';
import { DataGrid, DataGridColumnTypeEnum } from 'seker-ui';
import type { IInstitutionSelectionDataGridProps } from '../type';

const InstitutionSelectionDataGrid: FC<IInstitutionSelectionDataGridProps> = ({ data, onReturnData, closeModal }) => {
    const { t, locale } = useTranslation();

    const columns: DataGridColumnsPropsType = [
        {
            field: 'index',
            headerName: t(locale.contentTitles.no),
            headerAlign: 'center',
            align: 'center',
            width: 30,
            type: DataGridColumnTypeEnum.counter,
        },
        {
            field: 'shortCode',
            headerName: t(locale.contentTitles.bankShortCode),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 140,
        },
        {
            field: 'title',
            headerName: t(locale.contentTitles.title),
            headerAlign: 'center',
            flex: 1,
            minWidth: 500,
        },
        {
            field: 'stockExchangeCode',
            headerName: t(locale.contentTitles.bourseCode),
            headerAlign: 'center',
            flex: 1,
            minWidth: 140,
            align: 'center',
        },

        {
            field: 'customerCode',
            headerName: t(locale.contentTitles.customerNo),
            headerAlign: 'center',
            align: 'center',
            flex: 1,
            minWidth: 130,
        },
        {
            align: 'center',
            field: 'countryCode',
            flex: 1,
            headerAlign: 'center',
            headerName: t(locale.contentTitles.countryCode),
            minWidth: 130,
        },
        {
            align: 'center',
            field: 'swiftCode',
            flex: 1,
            headerAlign: 'center',
            headerName: t(locale.contentTitles.swiftCode),
            minWidth: 130,
        },
    ];

    return (
        <DataGrid
            columns={columns}
            rows={data || []}
            onRowDoubleClick={({ row }: { row: ICoreDataItem }) => {
                onReturnData?.(row);
                closeModal();
            }}
        />
    );
};

export default InstitutionSelectionDataGrid;
