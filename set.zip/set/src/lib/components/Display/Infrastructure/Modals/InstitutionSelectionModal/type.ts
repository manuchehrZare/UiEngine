import type { IButtonProps, IInputProps, INumberInputProps, ISelectProps } from 'seker-ui';
import type {
    ICoreDataItem,
    IFinmanSwapListInstitutionResponse,
    IHelperModalProps,
    SETModalsCommonProps,
} from '../../../../..';

type IInputType = Partial<
    Record<
        `${keyof Pick<IInstitutionModalFormValues, 'shortCode' | 'title' | 'stockExchangeCode' | 'swiftCode'>}`,
        Pick<IInputProps, 'disabled' | 'readOnly'>
    >
>;

type ISelectType = {
    [Property in `${keyof Pick<IInstitutionModalFormValues, 'countryCode' | 'functionOid'>}`]?: Pick<
        ISelectProps<IInstitutionModalFormValues[Property]>,
        'disabled' | 'readOnly'
    >;
};

type INumberInputType = Partial<
    Record<
        `${keyof Pick<IInstitutionModalFormValues, 'customerCode'>}`,
        Pick<INumberInputProps, 'disabled' | 'readOnly'>
    >
>;

interface IButtonComponentProps {
    clearButton?: Pick<IButtonProps, 'disabled'>;
    inquiryButton?: Pick<IButtonProps, 'disabled'>;
}

export interface IInstitutionSelectionModalComponentProps {
    buttonProps?: IButtonComponentProps;
    inputProps?: IInputType;
    numberInputProps?: INumberInputType;
    selectProps?: ISelectType;
}

export interface IInstitutionModalFormValues {
    countryCode: string;
    customerCode: string;
    functionOid: string;
    shortCode: string;
    stockExchangeCode: string;
    swiftCode: string;
    title: string;
}

export interface IInstitutionSelectionModalProps
    extends Omit<IHelperModalProps, 'adornmentButtonProps' | 'show' | 'onClose'>,
        SETModalsCommonProps {
    /**
     * Allows control of components within the modal.
     */
    componentProps?: IInstitutionSelectionModalComponentProps;
    /**
     * Allows the modal to receive data from outside.
     *
     *  Note: For picker elements the value must be given unixtime.
     */
    formData?: Partial<IInstitutionModalFormValues>;
    /**
     * Callback fired when the component requests to be closed.
     */
    onClose: (modalShow: boolean) => void;
    /**
     * This method returns data from the service or modal.
     */
    onReturnData?: (data: ICoreDataItem) => Promise<void> | void;
    /**
     * The data required for the service is sent with these prop.
     */
    payloadData?: Partial<IFinmanSwapListInstitutionResponse>;
    /**
     * These props trigger the modal's visibility.
     */
    show: boolean;
}

export interface IInstitutionSelectionDataGridProps {
    closeModal: () => void;
    data: ICoreDataItem[];
    onReturnData?: (data: ICoreDataItem) => void;
}
