import type { FC } from 'react';
import type { IInputProps } from 'seker-ui';
import { Input } from 'seker-ui';
import { constants, useTranslation } from '../../../../../utils';

export interface IRegistryNoInputProps extends IInputProps {}

const RegistryNoInput: FC<IRegistryNoInputProps> = ({ label, labelPlacement, minLength, maxLength, ...rest }) => {
    const { t, locale } = useTranslation();
    return (
        <Input
            labelPlacement={labelPlacement || 'top'}
            label={label || t(locale.labels.registryNo)}
            minLength={minLength || constants.format.length.registryNo.min}
            maxLength={maxLength || constants.format.length.registryNo.max}
            {...rest}
        />
    );
};

export default RegistryNoInput;
