import type { FC } from 'react';
import type { IInputProps } from 'seker-ui';
import { Input } from 'seker-ui';
import { constants, useTranslation } from '../../../../../utils';

export interface IPasswordInputProps extends Omit<IInputProps, 'type'> {}

const PasswordInput: FC<IPasswordInputProps> = ({ label, labelPlacement, ...rest }) => {
    const { t, locale } = useTranslation();

    return (
        <Input
            labelPlacement={labelPlacement || 'top'}
            type="password"
            label={label || t(locale.labels.password)}
            minLength={constants.format.length.password.min}
            maxLength={constants.format.length.password.max}
            {...rest}
        />
    );
};

export default PasswordInput;
