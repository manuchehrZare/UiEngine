import type { FC, JSX } from 'react';
import { useState } from 'react';
import type { IButtonProps, IConfirmModalProps } from 'seker-ui';
import { Button, ConfirmModal } from 'seker-ui';
import { useTranslation } from '../../../../../utils';

export interface IDeleteButtonProps extends IButtonProps {
    confirmModalProps?: Pick<IConfirmModalProps, 'onConfirm'> &
        Partial<Pick<IConfirmModalProps, 'body' | 'title' | 'cancelText' | 'okText' | 'onClose' | 'show'>>;
}

const DeleteButton: FC<IDeleteButtonProps> = ({
    text,
    color,
    variant,
    confirmModalProps,
    onClick,
    ...rest
}): JSX.Element => {
    const { t, locale } = useTranslation();
    const [deleteConfirmModalShow, setDeleteConfirmModalShow] = useState<boolean>(false);

    return (
        <>
            <Button
                text={text || t(locale.buttons.delete)}
                color={color || 'error'}
                variant={variant || 'outlined'}
                onClick={() => {
                    onClick?.();
                    typeof confirmModalProps?.show !== 'boolean' &&
                        !deleteConfirmModalShow &&
                        setDeleteConfirmModalShow(true);
                }}
                {...rest}
            />
            <ConfirmModal
                show={confirmModalProps?.show || deleteConfirmModalShow}
                title={confirmModalProps?.title || t(locale.contents.warning)}
                body={confirmModalProps?.body || t(locale.contents.doYouWantToDelete)}
                cancelText={confirmModalProps?.cancelText || t(locale.buttons.no)}
                okText={confirmModalProps?.okText || t(locale.buttons.yes)}
                actionProps={{
                    cancelProps: {
                        color: 'error',
                        variant: 'outlined',
                    },
                }}
                onConfirm={(status) => {
                    confirmModalProps?.onConfirm?.(status);
                    deleteConfirmModalShow && setDeleteConfirmModalShow(false);
                }}
                onClose={() => {
                    confirmModalProps?.onClose?.();
                    deleteConfirmModalShow && setDeleteConfirmModalShow(false);
                }}
            />
        </>
    );
};

export default DeleteButton;
