import type { FC } from 'react';
import { useState } from 'react';
import { Button, ConfirmModal } from 'seker-ui';
import { useTranslation } from '../../../../..';
import type { ISaveButtonProps } from './type';
import { omit } from 'lodash';

const SaveButton: FC<ISaveButtonProps> = (props: ISaveButtonProps) => {
    const { locale, t } = useTranslation();
    const [saveConfirmModalShow, setSaveConfirmModalShow] = useState<boolean>(false);

    const renderButton = () => {
        return (
            <Button
                text={props?.text || t(locale.buttons.save)}
                onClick={() => {
                    props?.onClick?.();
                    props?.enableConfirm &&
                        typeof props?.confirmModalProps?.show !== 'boolean' &&
                        !saveConfirmModalShow &&
                        setSaveConfirmModalShow(true);
                }}
                {...(props?.enableConfirm ? omit(props, ['enableConfirm', 'confirmModalProps']) : props)}
            />
        );
    };

    if (props?.enableConfirm === true) {
        return (
            <>
                {renderButton()}
                <ConfirmModal
                    {...props?.confirmModalProps}
                    show={props.confirmModalProps?.show || saveConfirmModalShow}
                    title={props?.confirmModalProps?.title || t(locale.contentTitles.warning)}
                    body={props?.confirmModalProps?.body || t(locale.contents.areYouSureYouWantToSave)}
                    cancelText={props?.confirmModalProps?.cancelText || t(locale.buttons.no)}
                    okText={props?.confirmModalProps?.okText || t(locale.buttons.yes)}
                    actionProps={{
                        cancelProps: {
                            color: 'error',
                            variant: 'outlined',
                        },
                    }}
                    onClose={() => {
                        props?.confirmModalProps?.onClose?.();
                        saveConfirmModalShow && setSaveConfirmModalShow(false);
                    }}
                    onConfirm={(status) => {
                        props?.confirmModalProps?.onConfirm?.(status);
                        saveConfirmModalShow && setSaveConfirmModalShow(false);
                    }}
                />
            </>
        );
    }
    return renderButton();
};

export default SaveButton;
