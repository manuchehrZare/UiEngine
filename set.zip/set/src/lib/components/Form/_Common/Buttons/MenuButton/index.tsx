import { Menu } from '@mui/icons-material';
import type { FC } from 'react';
import { useNavigate } from 'react-router-dom';
import type { HelperComponentProps, IButtonProps } from 'seker-ui';
import { Button } from 'seker-ui';
import { isWebview, ShellProcessTypeEnum, shellTrigger, useTranslation } from '../../../../..';

export interface IMenuButtonProps extends Omit<IButtonProps, 'design'>, Required<Pick<HelperComponentProps, 'link'>> {}

const MenuButton: FC<IMenuButtonProps> = ({
    link,
    text,
    onClick,
    variant = 'outlined',
    iconLeft = <Menu />,
    ...rest
}) => {
    const { locale, t } = useTranslation();
    const navigate = useNavigate();

    return (
        <Button
            text={text || t(locale.buttons.menu)}
            onClick={() => {
                if (isWebview()) {
                    shellTrigger({ processType: ShellProcessTypeEnum.Sidebar, data: '/menu-list' });
                } else link && navigate(link);
                onClick?.();
            }}
            variant={variant}
            iconLeft={iconLeft}
            {...rest}
        />
    );
};

export default MenuButton;
