import type { IButtonProps, IConfirmModalProps } from 'seker-ui';

export interface ISaveConfirmModalProps extends IButtonProps {
    confirmModalProps?: Pick<IConfirmModalProps, 'onConfirm'> &
        Partial<Pick<IConfirmModalProps, 'body' | 'title' | 'cancelText' | 'okText' | 'onClose' | 'show'>>;
    enableConfirm: true;
}

export interface ISaveProps extends IButtonProps {
    enableConfirm?: false;
}

export type ISaveButtonProps = ISaveProps | ISaveConfirmModalProps;
