import { PowerSettingsNew } from '@mui/icons-material';
import { omit } from 'lodash';
import type { FC } from 'react';
import { useState } from 'react';
import type { HelperComponentProps, IButtonProps } from 'seker-ui';
import { Button } from 'seker-ui';
import type { ShellExitDataType, ILossOfChangeConfirmModalProps } from '../../../../..';
import {
    LossOfChangeConfirmModal,
    isWebview,
    ShellExitTypeEnum,
    ShellProcessTypeEnum,
    shellTrigger,
    useTranslation,
} from '../../../../..';
import { useNavigate } from 'react-router-dom';

export interface IClosePageButtonProps extends Omit<IButtonProps, 'design'>, Pick<HelperComponentProps, 'link'> {
    closePageConfirmModalProps?: Omit<ILossOfChangeConfirmModalProps, 'show' | 'link'>;
}

const ClosePageButton: FC<IClosePageButtonProps> = ({
    closePageConfirmModalProps,
    link,
    text,
    onClick,
    variant = 'outlined',
    iconLeft = <PowerSettingsNew />,
    ...rest
}) => {
    const navigate = useNavigate();
    const { locale, t } = useTranslation();
    const [closePageConfirmModalShow, setClosePageConfirmModalShow] = useState<boolean>(false);

    const handleApprove = () => {
        // Confirm "Close Page"
        if (isWebview()) {
            shellTrigger<ShellExitDataType>({
                processType: ShellProcessTypeEnum.Exit,
                data: {
                    status: true,
                    type: ShellExitTypeEnum.Page,
                },
            });
        } else link && navigate(link);
    };

    return (
        <>
            <Button
                text={text || t(locale.buttons.close)}
                onClick={() => {
                    if (isWebview()) {
                        shellTrigger({ processType: ShellProcessTypeEnum.Confirm, data: '/confirm/close-page' });
                    } else {
                        setClosePageConfirmModalShow(true);
                    }
                    onClick?.();
                }}
                variant={variant}
                iconLeft={iconLeft}
                {...rest}
            />
            <LossOfChangeConfirmModal
                show={closePageConfirmModalShow}
                onClose={() => {
                    setClosePageConfirmModalShow(false);
                    closePageConfirmModalProps?.onClose?.();
                }}
                onConfirm={(status) => {
                    if (status) {
                        handleApprove();
                    } else {
                        // Confirm "giveUp"
                        isWebview() &&
                            shellTrigger<ShellExitDataType>({
                                processType: ShellProcessTypeEnum.Exit,
                                data: {
                                    status: false,
                                    type: ShellExitTypeEnum.Page,
                                },
                            });
                    }
                    setClosePageConfirmModalShow(false);
                }}
                {...omit(closePageConfirmModalProps, ['onClose', 'onConfirm'])}
            />
        </>
    );
};

export default ClosePageButton;
