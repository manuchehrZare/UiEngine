import type { FC } from 'react';
import type { IButtonProps } from 'seker-ui';
import { Button } from 'seker-ui';
import type { ICloseAppConfirmModalProps } from '../../../../..';
import { CloseAppConfirmModal, useTranslation } from '../../../../..';

export interface ICloseAppButtonProps extends Omit<IButtonProps, 'design'> {
    closeAppConfirmModalProps: ICloseAppConfirmModalProps;
}

const CloseAppButton: FC<ICloseAppButtonProps> = ({
    closeAppConfirmModalProps,
    text,
    variant = 'outlined',
    color = 'error',
    ...rest
}) => {
    const { t, locale } = useTranslation();

    return (
        <>
            <Button text={text || t(locale.buttons.close)} variant={variant} color={color} {...rest} />
            <CloseAppConfirmModal {...closeAppConfirmModalProps} />
        </>
    );
};

export default CloseAppButton;
