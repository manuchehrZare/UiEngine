import type { FC } from 'react';
import { useEffect, useRef, useState } from 'react';
import {
    Box,
    Button,
    DesignTypeEnum,
    Grid,
    GridItem,
    Label,
    MessageTypeEnum,
    Paper,
    Select,
    View,
    getLocalStorageItem,
    hideLoading,
    message,
    showLoading,
    sleep,
    useForm,
    useStorage,
    validation,
} from 'seker-ui';
import type {
    AuthenticateRequest,
    AuthenticateResponse,
    DelegatingUsersItem,
    GetDelegatingUsersRequest,
    GetDelegatingUsersResponse,
    LocalesType,
    ProviderProjectProps,
    RequestHeaderParams,
    ResponseError,
} from '../../../..';
import {
    AuthenticateStatusEnum,
    BranchSelectionModal,
    ChangePasswordModal,
    CloseAppButton,
    DelegationSelectionModal,
    DelegationUserListTypeEnum,
    ForgotPasswordModal,
    GlobalsItemEnum,
    LocalesEnum,
    PasswordExpiredEnum,
    PasswordInput,
    RegistryNoInput,
    ShellProcessTypeEnum,
    constants,
    getAuthorization,
    getGlobalsData,
    getXUserName,
    isWebview,
    languageStorageKey,
    shellTrigger,
    unixtimeToStringDate,
    useAxios,
    useTranslation,
} from '../../../..';
import type { LoginFormValues, LoginProps } from './type';
import { getUnixTime } from 'date-fns';
import type { ChangePasswordFormValues } from '../../../Display/_Common/Modals/Auth/ChangePasswordModal/type';
import { HttpStatusCodeEnum, ProcessEnvEnum, getLoginNavigateRoute } from '../../../../utils';
import type { DelegationSelectionReturnData } from '../../../Display/_Common/Modals/Delegation/DelegationSelectionModal/type';
import { isUndefined, pick } from 'lodash';
import { useLocation } from 'react-router-dom';
import { generateGlobalsDataByBranchSelection } from '../../../../utils/methods/common';

const Login: FC<LoginProps> = ({
    logo,
    formProps,
    gridProps,
    navigateProps,
    onSetAuth,
    onResetAuth,
    onResetQuery,
    onNavigate,
}) => {
    const { t, i18n, locale } = useTranslation();
    const { search: locationSearch } = useLocation();
    const storageProjectProps = useStorage<ProviderProjectProps>({
        key: constants.key.SETUI_Provider_ProjectProps,
        source: 'session',
    });
    const [forgotPasswordModalShow, setForgotPasswordModalShow] = useState<boolean>(false);
    const [closeConfirmModalShow, setCloseConfirmModalShow] = useState<boolean>(false);
    const [changePasswordFormValues, setChangePasswordFormValues] = useState<ChangePasswordFormValues | null>(null);
    const [changePasswordModalShow, setChangePasswordModalShow] = useState<boolean>(false);
    const [delegationUsers, setDelegationUsers] = useState<DelegatingUsersItem[]>([]);
    const [delegationSelectionModalShow, setDelegationSelectionModalShow] = useState<boolean>(false);
    const [branchSelectionModalShow, setBranchSelectionModalShow] = useState<boolean>(false);
    const [authenticationResponseState, setAuthenticationResponseState] = useState<AuthenticateResponse | null>(null);

    const passwordInputRef = useRef<HTMLInputElement>(null);

    const { control, getValues, handleSubmit, setValue, reset } = useForm<LoginFormValues>({
        defaultValues: {
            registryNo: '',
            password: '',
            language: getLocalStorageItem(languageStorageKey) || LocalesEnum.TURKISH,
            ...formProps?.defaultValues,
        },
        validationSchema: {
            registryNo: validation.string(t(locale.labels.registryNo), {
                required: true,
                maxLength: 10,
            }),
            password: validation.string(t(locale.labels.password), {
                required: true,
                minLength: 8,
            }),
            language: validation.string(t(locale.labels.language), {
                required: true,
                selectable: true,
            }),
        },
    });

    const [{ data: authenticateData }, authenticateRequest] = useAxios<
        AuthenticateResponse,
        AuthenticateRequest,
        ResponseError
    >(constants.api.endpoints.nova.gateway.authentication.authenticate.POST, { manual: true });

    const [, getDelegatingUsersRequest] = useAxios<GetDelegatingUsersResponse, GetDelegatingUsersRequest>(
        constants.api.endpoints.nova.infra.admin.user.delegation.getDelegatingUsers.POST,
        { manual: true },
    );

    const setAuthenticationData = ({
        authenticateResponseData,
        selectedDelegationData,
    }: {
        authenticateResponseData: AuthenticateResponse;
        selectedDelegationData?: DelegationSelectionReturnData | null;
    }) => {
        onSetAuth?.({
            ...authenticateResponseData,
            loginUserName:
                getGlobalsData({
                    key: GlobalsItemEnum.UserName,
                    sourceData: authenticateResponseData.globals,
                }) || '',
            /**
             * If the delegated user is selected; the token and globals information obtained after the election is used.
             */
            ...(selectedDelegationData && { ...pick(selectedDelegationData, ['token', 'globals']) }),
        });
    };

    const resetStates = () => {
        changePasswordModalShow && setChangePasswordModalShow(false);
        delegationSelectionModalShow && setDelegationSelectionModalShow(false);
        branchSelectionModalShow && setBranchSelectionModalShow(false);
        authenticationResponseState !== null && setAuthenticationResponseState(null);
    };

    const navigateLogin = () => {
        onNavigate?.(
            getLoginNavigateRoute({
                homeRoute: navigateProps.routes.home || '/',
                locationSearch: locationSearch,
                resetQuery: onResetQuery,
            }),
        );
    };

    const navigatePage = async ({
        authenticateResponseData,
        formData,
        selectedDelegationData,
    }: {
        authenticateResponseData: AuthenticateResponse;
        formData: LoginFormValues;
        selectedDelegationData?: DelegationSelectionReturnData | null;
    }) => {
        // * Navigate to Content Pages
        if (isWebview()) {
            // * For Shell
            message({
                message: t(locale.notifications.loginIsProvided),
                variant: MessageTypeEnum.info,
                autoHideDuration: 1500,
                onEnter: () => {
                    showLoading();
                },
                onExit: () => {
                    hideLoading();
                    // * Set user data
                    setAuthenticationData({ authenticateResponseData, selectedDelegationData });
                    shellTrigger({
                        processType: ShellProcessTypeEnum.Login,
                        data: {
                            globals: selectedDelegationData?.globals || authenticateResponseData?.globals,
                            token: selectedDelegationData?.token || authenticateResponseData?.token,
                            delegation: selectedDelegationData?.selectedDelegatedUser || null,
                            payload: formData,
                        },
                    });
                    resetStates();
                },
            });
        } else {
            // * Set user data
            setAuthenticationData({ authenticateResponseData, selectedDelegationData });
            // * Navigate For Not Shell
            navigateLogin();
            resetStates();
        }
    };

    const handleGetDelegatingUsersRequest = async ({
        authenticateResponseData,
        formData,
    }: {
        authenticateResponseData: AuthenticateResponse;
        formData: LoginFormValues;
    }) => {
        // getDelegatingUsers Request
        const requestHeaderParams: Required<Pick<RequestHeaderParams, 'Authorization' | 'x-username'>> = {
            Authorization: getAuthorization(authenticateResponseData.token) || '',
            'x-username': getXUserName(authenticateResponseData.globals) || '',
        };
        const getDelegatingUsersResponse = await getDelegatingUsersRequest({
            headers: requestHeaderParams,
            data: {
                delegatedUserOid:
                    getGlobalsData({
                        key: GlobalsItemEnum.UserOID,
                        sourceData: authenticateResponseData.globals,
                    }) || '',
                listType: DelegationUserListTypeEnum.Zero,
                referenceDate: unixtimeToStringDate(getUnixTime(new Date())),
                usrDelegatingUserOid: '',
            },
        });

        if (getDelegatingUsersResponse.status === HttpStatusCodeEnum.Ok) {
            if (
                getDelegatingUsersResponse.data.delegatingUsers &&
                getDelegatingUsersResponse.data.delegatingUsers.length > 0
            ) {
                // * Delegation Users state data
                setDelegationUsers(getDelegatingUsersResponse.data.delegatingUsers);
            } else {
                delegationUsers?.length > 0 && setDelegationUsers([]);
            }

            if (getDelegatingUsersResponse.data.passwordExpired === PasswordExpiredEnum.NotExpired) {
                if (
                    getDelegatingUsersResponse.data.delegatingUsers &&
                    getDelegatingUsersResponse.data.delegatingUsers.length > 0
                ) {
                    // * Password Expire degil ve delegatedUser'da data varsa delegasyon secimi modal acilir
                    setDelegationSelectionModalShow(true);
                } else {
                    delegationUsers?.length > 0 && setDelegationUsers([]);
                    // * Password Expire degil ve delegatedUser'da data yoksa ic ekranlara yönelir.
                    navigatePage({ authenticateResponseData, formData });
                }
            } else {
                // * Password Expire - Change Password Modal acilir
                setChangePasswordModalShow(true);
            }
        } else {
            // resetStoreAuth();
            onResetAuth?.();
        }
    };

    const onSubmit = async (formData: LoginFormValues) => {
        const authenticateResponse = await authenticateRequest({
            headers: {
                'x-username': formData.registryNo,
            } as Required<Pick<RequestHeaderParams, 'x-username'>>,
            data: {
                password: formData.password,
                userName: formData.registryNo,
            },
        });

        if (
            authenticateResponse.status === HttpStatusCodeEnum.Ok &&
            authenticateResponse.data.status === AuthenticateStatusEnum.OK
        ) {
            // setAuthenticationResponseState

            setAuthenticationResponseState(authenticateResponse.data);
            /**
             * 1. Branch Selection Control
             * 2. Call getDelegationUsersRequest and show changePasswordModal
             * 3. Show DelegationSelectionModal
             */
            /**
             * 1. Branch Selection Control
             */
            if (
                getGlobalsData({
                    key: GlobalsItemEnum.ChargedOtherOrganizationCode,
                    sourceData: authenticateResponse.data.globals,
                }) !== null &&
                getGlobalsData({
                    key: GlobalsItemEnum.ChargedOtherOrganizationOID,
                    sourceData: authenticateResponse.data.globals,
                }) !== null
            ) {
                // Show Branch Selection Modal
                setBranchSelectionModalShow(true);
            } else {
                // Hide Branch Selection Modal
                branchSelectionModalShow && setBranchSelectionModalShow(false);
                /**
                 * 2. ChangePassword and Delegation Control
                 * Note: changePasswordModal can be show according to the "passwordExpired" value obtained from getDelegatingUsers service.
                 */
                handleGetDelegatingUsersRequest({ authenticateResponseData: authenticateResponse.data, formData });
            }
        }
    };

    useEffect(() => {
        if (isUndefined(formProps?.defaultValues?.password)) {
            setValue('password', storageProjectProps?.newValue?.env !== ProcessEnvEnum.Prod ? 'Alfa1111' : '');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [storageProjectProps.newValue?.env, formProps?.defaultValues.password]);

    return (
        <>
            <Grid height="100%" {...gridProps}>
                <GridItem sm>
                    <Box
                        p={2}
                        display="flex"
                        height="100%"
                        alignItems="center"
                        justifyContent="center"
                        textAlign="center">
                        <Grid>
                            <GridItem>
                                <Label
                                    text={constants.app.shortTitle}
                                    align="center"
                                    fontSize={{ xs: 28, sm: 32 }}
                                    fontWeight={900}
                                    color={(theme) => theme.palette.secondary.dark}
                                />
                            </GridItem>
                            <GridItem>
                                <Label
                                    text={t(locale.common.sekerbankInformationTechnologies)}
                                    align="center"
                                    fontSize={{ xs: 20, sm: 24 }}
                                    fontWeight={700}
                                    color={(theme) => theme.palette.secondary.dark}
                                />
                            </GridItem>
                            <GridItem mt={{ xs: 2, sm: 9 }} height={{ xs: 120, sm: 200, md: 265 }}>
                                {logo}
                            </GridItem>
                        </Grid>
                    </Box>
                </GridItem>
                <GridItem sm>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Paper
                            sx={{
                                height: '100%',
                                boxShadow: '0px 2px 18px rgba(0, 0, 0, 0.1)',
                                borderRadius: { xs: '10px 10px 0px 0px', md: '10px 0px 0px 10px' },
                                p: 2,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                            }}>
                            <Grid spacingType="form" xs={9} md={7} lg={6} xl={5} xxl={5} mt={{ sm: 8 }}>
                                <GridItem mb={{ xs: 5, sm: 9 }}>
                                    <Label
                                        text={t(locale.common.welcome)}
                                        fontSize={20}
                                        align="center"
                                        color={(theme) => theme.palette.secondary.dark}
                                    />
                                </GridItem>
                                <GridItem>
                                    <RegistryNoInput
                                        name="registryNo"
                                        control={control}
                                        label={t(locale.labels.userName)}
                                    />
                                </GridItem>
                                <GridItem>
                                    <PasswordInput
                                        name="password"
                                        control={control}
                                        inputRef={passwordInputRef}
                                        capslockDetector
                                        passwordVisibility
                                    />
                                </GridItem>
                                <GridItem>
                                    <Select
                                        labelPlacement="top"
                                        name="language"
                                        control={control}
                                        label={t(locale.labels.languageSelection)}
                                        setValue={setValue}
                                        disabled
                                        options={{
                                            data: i18n.languages?.map((lang) => ({
                                                name: t(locale.languages[lang as LocalesType]),
                                                value: lang,
                                            })),
                                            displayField: 'name',
                                            displayValue: 'value',
                                        }}
                                    />
                                </GridItem>
                                <GridItem my={3}>
                                    <Grid justifyContent="center" spacingType="button">
                                        <GridItem xs={false}>
                                            <Button type="submit" text={t(locale.buttons.login)} />
                                        </GridItem>
                                        <View show={isWebview()}>
                                            <GridItem xs={false}>
                                                <CloseAppButton
                                                    text={t(locale.buttons.giveUp)}
                                                    onClick={() => setCloseConfirmModalShow(true)}
                                                    closeAppConfirmModalProps={{
                                                        show: closeConfirmModalShow,
                                                        body: t(locale.labels.areYouSureYouWantToCloseTheApplication),
                                                        onClose: () => {
                                                            setCloseConfirmModalShow(false);
                                                        },
                                                        onConfirm: (status) => {
                                                            if (status) {
                                                                if (isWebview()) {
                                                                    showLoading();
                                                                    sleep(constants.app.delay.CLOSING_LOADING_DELAY)
                                                                        .then(() => {
                                                                            reset();
                                                                            // For shell close window
                                                                            shellTrigger({
                                                                                processType: ShellProcessTypeEnum.Exit,
                                                                                data: null,
                                                                            });
                                                                        })
                                                                        .then(() => {
                                                                            hideLoading();
                                                                            setCloseConfirmModalShow(false);
                                                                        });
                                                                }
                                                            } else {
                                                                setCloseConfirmModalShow(false);
                                                            }
                                                        },
                                                    }}
                                                />
                                            </GridItem>
                                        </View>
                                    </Grid>
                                </GridItem>
                                <GridItem textAlign="center" mt={{ xs: 3, md: 5 }} py={1}>
                                    <Box
                                        textAlign="center"
                                        fontSize={`var(--field-label-font-size-${DesignTypeEnum.SET})`}>
                                        {t(locale.labels.forgotYourPassword)}&nbsp;
                                        <Box
                                            display="inline"
                                            sx={{
                                                color: (theme) => theme.palette.secondary.main,
                                                textDecoration: 'underline',
                                                cursor: 'pointer',
                                            }}
                                            onClick={() => {
                                                setForgotPasswordModalShow(true);
                                            }}>
                                            {t(locale.buttons.clickHere)}
                                        </Box>
                                    </Box>
                                </GridItem>
                            </Grid>
                        </Paper>
                    </form>
                </GridItem>
            </Grid>
            <ForgotPasswordModal show={forgotPasswordModalShow} onClose={() => setForgotPasswordModalShow(false)} />
            {authenticateData && authenticationResponseState && (
                <>
                    <ChangePasswordModal
                        show={changePasswordModalShow}
                        authenticateResponseData={authenticationResponseState}
                        onSuccessSave={(changePasswordFormData) => {
                            setChangePasswordModalShow(false);
                            /** DelegationUsers datasi varsa ona ait modal gosterilmeli. */
                            /** DelegationUsers yoksa ic ekranlara yonlendirilmeli. */
                            if (delegationUsers.length > 0) {
                                setChangePasswordFormValues(changePasswordFormData);
                                setDelegationSelectionModalShow(true);
                            } else {
                                navigatePage({
                                    authenticateResponseData: authenticationResponseState,
                                    formData: {
                                        ...getValues(),
                                        password: changePasswordFormData.userNewPassword,
                                    },
                                });
                            }
                        }}
                    />
                    <DelegationSelectionModal
                        show={delegationSelectionModalShow}
                        authenticateResponseData={authenticationResponseState}
                        delegatingUsers={delegationUsers}
                        onSelect={(selectedDelegationData) => {
                            setDelegationSelectionModalShow(false);
                            /** ChangePassword sonrası calistiysa yeni password degeri ile yonlendirme calismali */
                            /** ChangePassword olmadan calistiysa mevcut login form degeri ile yonlendirme calismali */
                            navigatePage({
                                authenticateResponseData: authenticationResponseState,
                                formData: {
                                    ...getValues(),
                                    ...(changePasswordFormValues && {
                                        password: changePasswordFormValues.userNewPassword,
                                    }),
                                },
                                selectedDelegationData,
                            });
                            // reset delegationUsers
                            setDelegationUsers([]);
                        }}
                    />
                    <BranchSelectionModal
                        show={branchSelectionModalShow}
                        authenticateResponseData={authenticateData}
                        onSelect={(selectedBranch) => {
                            if (branchSelectionModalShow) {
                                setBranchSelectionModalShow(false);
                                /**
                                 * 2. ChangePassword and Delegation Control
                                 * Note: changePasswordModal can be show according to the "passwordExpired" value obtained from getDelegatingUsers service.
                                 */
                                const newAuthResponseData = {
                                    ...authenticateData,
                                    globals: generateGlobalsDataByBranchSelection({
                                        selectedBranch,
                                        globals: authenticateData.globals,
                                    }),
                                };
                                setAuthenticationResponseState(newAuthResponseData);
                                handleGetDelegatingUsersRequest({
                                    authenticateResponseData: newAuthResponseData,
                                    formData: getValues(),
                                });
                            }
                        }}
                        onClose={() => {
                            if (branchSelectionModalShow) {
                                setBranchSelectionModalShow(false);
                                /**
                                 * 2. ChangePassword and Delegation Control
                                 * Note: changePasswordModal can be show according to the "passwordExpired" value obtained from getDelegatingUsers service.
                                 */
                                handleGetDelegatingUsersRequest({
                                    authenticateResponseData: authenticateData,
                                    formData: getValues(),
                                });
                            }
                        }}
                    />
                </>
            )}
        </>
    );
};

export default Login;
