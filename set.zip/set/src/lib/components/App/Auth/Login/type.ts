import type { ReactNode } from 'react';
import type { AuthenticateType, LocalesType } from '../../../..';
import type { IGridProps, IUseFormProps } from 'seker-ui';

export type LoginFormValues = {
    language: LocalesType;
    password: string;
    registryNo: string;
};

export type LoginNavigateProps = {
    routes: { home: string };
};

export type LoginProps = {
    formProps?: Pick<IUseFormProps<Partial<LoginFormValues>>, 'defaultValues'>;
    gridProps?: IGridProps;
    logo: ReactNode;
    navigateProps: LoginNavigateProps;
    onNavigate: (route: string) => void;
    onResetAuth: () => void;
    onResetQuery: () => void;
    onSetAuth: (authenticateData: AuthenticateType) => void;
};
