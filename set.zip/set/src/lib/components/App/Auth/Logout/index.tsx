import { omit } from 'lodash';
import type { FC, JSX } from 'react';
import { cloneElement, useState } from 'react';
import type { ILogoutConfirmModalProps } from '../../../..';
import { isWebview, LogoutConfirmModal, ShellProcessTypeEnum, shellTrigger } from '../../../..';

export interface ILogoutProps {
    component: any;
    logoutConfirmModalProps?: Omit<ILogoutConfirmModalProps, 'show'>;
}

const Logout: FC<ILogoutProps> = ({ component, logoutConfirmModalProps }): JSX.Element => {
    const [logoutConfirmModalShow, setLogoutConfirmModalShow] = useState<boolean>(false);

    const handleLogoutClick = async (e: any) => {
        e.preventDefault();
        if (isWebview()) {
            // * For logout confirm show in shell
            shellTrigger({ processType: ShellProcessTypeEnum.Confirm, data: '/confirm/logout' });
        } else setLogoutConfirmModalShow(true);
    };

    return (
        <>
            {cloneElement(component, {
                onClick: handleLogoutClick,
            })}
            <LogoutConfirmModal
                show={logoutConfirmModalShow}
                onClose={() => {
                    setLogoutConfirmModalShow(false);
                    logoutConfirmModalProps?.onClose?.();
                }}
                {...omit(logoutConfirmModalProps, ['onClose'])}
            />
        </>
    );
};

export default Logout;
