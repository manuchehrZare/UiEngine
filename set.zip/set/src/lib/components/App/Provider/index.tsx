import type { FC } from 'react';
import { useEffect } from 'react';
import {
    DesignTypeEnum,
    Provider as SekerUIProvider,
    removeSessionStorageItem,
    setSessionStorageItem,
    useStorage,
} from 'seker-ui';
import { merge, omit } from 'lodash';
import ErrorMessageContent from '../../Utils/Message/ErrorMessageContent';
import { constants } from '../../../utils';
import type { ProviderProjectProps, ProviderProps } from './type';

const Provider: FC<ProviderProps> = ({
    children,
    loadingProps,
    messageProviderProps,
    globalStyles,
    projectProps,
    ...rest
}) => {
    const storageProjectProps = useStorage<ProviderProjectProps>({
        key: constants.key.SETUI_Provider_ProjectProps,
        source: 'session',
    });

    useEffect(() => {
        setSessionStorageItem(constants.key.SETUI_Provider_ProjectProps, projectProps);
        return () => {
            removeSessionStorageItem(constants.key.SETUI_Provider_ProjectProps);
        };
    }, [projectProps]);

    useEffect(() => {
        !storageProjectProps.newValue &&
            projectProps &&
            setSessionStorageItem(constants.key.SETUI_Provider_ProjectProps, projectProps);
    }, [storageProjectProps, projectProps]);

    return (
        <SekerUIProvider
            design={DesignTypeEnum.SET}
            globalStyles={merge({ body: { backgroundColor: constants.design.backgroundColor.body } }, globalStyles)}
            loadingProps={{
                keepMounted: true,
                ...loadingProps,
            }}
            messageProviderProps={{
                anchorOrigin: messageProviderProps?.anchorOrigin || { horizontal: 'right', vertical: 'bottom' },
                Components: { error: ErrorMessageContent, ...messageProviderProps?.Components },
                TransitionProps: {
                    style: {
                        padding: '4px 12px',
                        maxWidth: constants.design.message.maxWidth,
                        borderRadius: constants.design.message.borderRadius,
                        boxShadow:
                            '0px 3px 5px -1px rgb(0 0 0 / 20%), 0px 6px 10px 0px rgb(0 0 0 / 14%), 0px 1px 18px 0px rgb(0 0 0 / 12%)',
                        ...messageProviderProps?.TransitionProps?.style,
                    },
                    ...omit(messageProviderProps?.TransitionProps, ['style']),
                },
                ...omit(messageProviderProps, ['anchorOrigin', 'Components', 'TransitionProps']),
            }}
            {...rest}>
            {children}
        </SekerUIProvider>
    );
};

export default Provider;
