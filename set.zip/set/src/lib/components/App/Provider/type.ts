import type { IProviderProps as ISekerUIProviderProps } from 'seker-ui';
import type { AxiosRequestConfig, ProcessEnvType } from '../../../utils';

export type ProviderServiceProps = AxiosRequestConfig;

export type ProviderRouteProps = {
    paths: { home: string; login: string };
};

export type ProviderProjectProps = {
    env: ProcessEnvType;
    routeProps: ProviderRouteProps;
    serviceProps?: ProviderServiceProps;
};

export type ProviderProps = Omit<ISekerUIProviderProps, 'design'> & { projectProps: ProviderProjectProps };
