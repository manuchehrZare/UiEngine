/* eslint-disable react-hooks/exhaustive-deps */
import { KeyboardBackspace } from '@mui/icons-material';
import { omit } from 'lodash';
import type { FC } from 'react';
import { forwardRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import type { IButtonProps, IGridProps, ILabelProps, IPaperProps } from 'seker-ui';
import {
    Button,
    getSessionStorageItem,
    Grid,
    GridItem,
    Label,
    message,
    MessageTypeEnum,
    Paper,
    sleep,
    View,
} from 'seker-ui';
import type { AuthenticateType, IMenuButtonProps } from '../../../..';
import { constants, isWebview, MenuButton, ShellProcessTypeEnum, shellTrigger, useTranslation } from '../../../..';
import { app } from '../../../../utils/constants/app';

export interface INotFoundProps extends Partial<Pick<ILabelProps, 'text'>>, Pick<IGridProps, 'ref'> {
    gridProps?: Omit<IGridProps, 'ref'>;
    isLoggedIn: boolean;
    labelProps?: Omit<ILabelProps, 'text'>;
    loginLink: string;
    menuButtonProps: IMenuButtonProps;
    paperProps?: IPaperProps;
    previousButtonProps?: Omit<IButtonProps, 'design'>;
}

const NotFound: FC<INotFoundProps> = forwardRef(
    (
        {
            gridProps,
            isLoggedIn,
            labelProps,
            loginLink,
            menuButtonProps,
            paperProps,
            previousButtonProps,
            text,
        }: INotFoundProps,
        ref,
    ) => {
        const { t, locale } = useTranslation();
        const navigate = useNavigate();
        const authStorageValue = getSessionStorageItem<AuthenticateType>(constants.key.SET_AUTH);

        useEffect(() => {
            if (!authStorageValue && !isLoggedIn) {
                message({
                    message: t(locale.notifications.navigateToLoginPage),
                    variant: MessageTypeEnum.info,
                });
                sleep(app.delay.LOGIN_REDIRECT_DELAY).then(() => {
                    if (isWebview()) {
                        // * For Shell
                        shellTrigger({ processType: ShellProcessTypeEnum.Screen, data: loginLink });
                    } else if (loginLink) {
                        // * Not Shell
                        navigate(loginLink);
                    }
                });
            }
        }, [isLoggedIn]);

        return (
            <Paper {...paperProps}>
                <Grid ref={ref} spacingType="common" {...gridProps}>
                    <GridItem>
                        <Label
                            text={text || t(locale.common.screenNotFound) || ''}
                            align="center"
                            color={(theme) => theme.palette.error.main}
                            {...labelProps}
                        />
                    </GridItem>
                    <View show={Boolean(isLoggedIn)}>
                        <GridItem>
                            <Grid spacingType="button" justifyContent="center">
                                <View show={Boolean(!isWebview())}>
                                    <GridItem sm="auto">
                                        <Button
                                            variant={previousButtonProps?.variant || 'outlined'}
                                            iconLeft={previousButtonProps?.iconLeft || <KeyboardBackspace />}
                                            onClick={() => {
                                                navigate(-1);
                                                previousButtonProps?.onClick?.();
                                            }}
                                            text={previousButtonProps?.text || t(locale.buttons.returnToPreviousPage)}
                                            {...omit(previousButtonProps, ['variant', 'iconLeft', 'onClick'])}
                                            fullWidth
                                        />
                                    </GridItem>
                                </View>
                                <GridItem sm="auto">
                                    <MenuButton
                                        variant={menuButtonProps.variant || 'contained'}
                                        {...omit(menuButtonProps, ['variant'])}
                                        fullWidth
                                    />
                                </GridItem>
                            </Grid>
                        </GridItem>
                    </View>
                </Grid>
            </Paper>
        );
    },
);

export default NotFound;
