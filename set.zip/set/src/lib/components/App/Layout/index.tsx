import type { IBoxProps } from 'seker-ui';
import { Box, CustomScrollbar, useMeasure, useTitle } from 'seker-ui';
import type { FC, JSX, ReactNode } from 'react';
import { useEffect, useState } from 'react';
import { constants } from '../../../utils';

export interface ILayoutProps extends Pick<IBoxProps, 'sx'> {
    children: ReactNode;
    title?: string;
}

const Layout: FC<ILayoutProps> = ({ children, title, sx }): JSX.Element => {
    const layoutMeasure = useMeasure();
    const [footerPixels, setFooterPixels] = useState<string>('0px');

    useTitle(`${constants.app.shortTitle}${title ? ` | ${title}` : ''}`);

    useEffect(() => {
        if (document.getElementsByClassName('set-content-footer')[0]) {
            const newFooterPixels = `${getComputedStyle(
                document.getElementsByClassName('set-content-footer')[0],
            ).getPropertyValue('bottom')} + ${getComputedStyle(
                document.getElementsByClassName('set-content-footer')[0],
            ).getPropertyValue('height')}`;
            footerPixels !== newFooterPixels && setFooterPixels(newFooterPixels);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [layoutMeasure?.values?.width]);

    return (
        <Box
            ref={layoutMeasure.ref}
            component="div"
            className={constants.design.className.contentLayout}
            sx={{
                position: 'relative',
                minHeight: '100vh',
                height: '100%',
                backgroundColor: constants.design.backgroundColor.body,
                ...sx,
            }}>
            <CustomScrollbar
                className={constants.design.className.contentLayoutCustomScrollbar}
                height="100%"
                style={{ minHeight: '100vh' }}
                thickness={8}>
                <Box
                    component="div"
                    className={constants.design.className.contentLayoutBox}
                    sx={{
                        position: 'relative',
                        px: constants.design.padding.layout.x.unit,
                        pt: constants.design.padding.layout.y.unit,
                        pb: `calc(${constants.design.padding.layout.y.pixel}px + ${footerPixels})`,
                    }}>
                    {children}
                </Box>
            </CustomScrollbar>
        </Box>
    );
};

export default Layout;
