import type { FC, JSX, ReactNode, Ref } from 'react';
import { forwardRef } from 'react';
import type { IPaperProps } from 'seker-ui';
import { alpha, Paper, useWidth } from 'seker-ui';
import { constants } from '../../..';

export interface IFooterProps extends Pick<IPaperProps, 'sx'> {
    children: ReactNode;
    ref?: Ref<any>;
}

const Footer: FC<IFooterProps> = forwardRef(({ children, sx, ...rest }: IFooterProps, ref): JSX.Element => {
    const screenWidth = useWidth();
    return (
        <Paper
            ref={ref}
            className={constants.design.className.footer}
            sx={{
                boxShadow: (theme) => `0px 1px 8px ${alpha(theme.palette.common.black, 0.25)}`,
                position: 'fixed',
                bottom: constants.design.padding.layout.x.pixel[screenWidth || 'xxl'] / 4,
                left: constants.design.padding.layout.x.pixel[screenWidth || 'xxl'] / 2,
                width: `calc(100% - ${constants.design.padding.layout.x.pixel[screenWidth || 'xxl']}px)`,
                zIndex: (theme) => theme.zIndex.appBar,
                ...sx,
            }}
            {...rest}>
            {children}
        </Paper>
    );
});

export default Footer;
