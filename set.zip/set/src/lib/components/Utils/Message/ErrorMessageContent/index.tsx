import { Check, Close, ContentCopy, KeyboardArrowDown } from '@mui/icons-material';
import type { FC } from 'react';
import { forwardRef, useState } from 'react';
import type { MessageCustomContentProps, Theme } from 'seker-ui';
import {
    MessageContent,
    Box,
    Grid,
    GridItem,
    Button,
    closeMessage,
    View,
    theme as sekerUITheme,
    KeyValueList,
    CustomScrollbar,
    Tooltip,
    useClipboard,
    useMeasure,
    Collapse,
    stringHTMLToJSX,
    sanitizeHTML,
} from 'seker-ui';
import type { AxiosError } from 'axios';
import { isUndefined } from 'lodash';
import type { ResponseError } from '../../../../utils';
import { constants, useTranslation } from '../../../../utils';

interface IErrorMessageContentProps extends MessageCustomContentProps {
    error: AxiosError<ResponseError>;
}

const ErrorMessageContent: FC<IErrorMessageContentProps> = forwardRef<HTMLDivElement, IErrorMessageContentProps>(
    ({ id, message, style, iconVariant, hideIconVariant, error }: IErrorMessageContentProps, ref) => {
        const { t, locale } = useTranslation();
        const { copy, isCopied } = useClipboard();
        const copyButtonMeasure = useMeasure();
        const [detailShow, setDetailShow] = useState<boolean>(false);

        const getSafeMessage = () => {
            const sanitizedMessage = sanitizeHTML(message as string) || '';
            return stringHTMLToJSX(sanitizedMessage);
        };

        return (
            <MessageContent
                ref={ref}
                role="alert"
                style={{
                    ...style,
                    backgroundColor: sekerUITheme.palette.common.white,
                    color: sekerUITheme.palette.common.white,
                    padding: 0,
                    minWidth: constants.design.message.minWidth,
                    display: 'block',
                }}>
                <Box
                    bgcolor={(theme) => theme.palette.error.main}
                    py={1.25}
                    px={1.5}
                    sx={{
                        ...(detailShow
                            ? {
                                  borderTopLeftRadius: style.borderRadius,
                                  borderTopRightRadius: style.borderRadius,
                              }
                            : { borderRadius: `${style.borderRadius}px` }),
                    }}>
                    <Grid spacingType="common" alignItems="flex-start">
                        <View show={!hideIconVariant}>
                            <GridItem xs={false} pr={0}>
                                <Box>{iconVariant.error}</Box>
                            </GridItem>
                        </View>
                        <GridItem {...(!hideIconVariant && { pl: '0px !important' })} xs>
                            <Box component="div" py={0.35} fontSize={'0.895rem'} sx={{ wordBreak: 'break-word' }}>
                                {getSafeMessage()}
                            </Box>
                        </GridItem>
                        <GridItem xs={false}>
                            <Grid spacing={1}>
                                <View
                                    show={
                                        !isUndefined(error?.config?.headers[constants.key.x_requestId]) ||
                                        !isUndefined(error?.config?.url) ||
                                        !isUndefined(error?.response?.data?.trace)
                                    }>
                                    <GridItem xs={false}>
                                        <Button
                                            variant="outlined"
                                            iconButton
                                            icon={
                                                <KeyboardArrowDown
                                                    sx={{ ...(detailShow && { transform: 'rotate(180deg)' }) }}
                                                />
                                            }
                                            color="error"
                                            size="small"
                                            sx={{
                                                backgroundColor: (theme) => theme.palette.common.white,
                                                ':hover': {
                                                    backgroundColor: (theme) => theme.palette.common.white,
                                                },
                                            }}
                                            onClick={() => setDetailShow(!detailShow)}
                                        />
                                    </GridItem>
                                </View>
                                <GridItem xs={false}>
                                    <Button
                                        variant="outlined"
                                        iconButton
                                        icon={<Close />}
                                        color="error"
                                        size="small"
                                        sx={{
                                            backgroundColor: (theme) => theme.palette.common.white,
                                            ':hover': {
                                                backgroundColor: (theme) => theme.palette.common.white,
                                            },
                                        }}
                                        onClick={() => closeMessage(id)}
                                    />
                                </GridItem>
                            </Grid>
                        </GridItem>
                    </Grid>
                </Box>
                <Collapse in={detailShow}>
                    <Box p={1.5}>
                        <Grid spacing={1}>
                            <GridItem>
                                <Box p={1} bgcolor={(theme) => theme.palette.error[50]} borderRadius={0.5}>
                                    <KeyValueList
                                        data={[
                                            ...(!isUndefined(error?.config?.headers[constants.key.x_requestId])
                                                ? [
                                                      {
                                                          text: constants.key.x_requestId,
                                                          value: error?.config?.headers[constants.key.x_requestId],
                                                      },
                                                  ]
                                                : []),
                                            ...(!isUndefined(error?.config?.url)
                                                ? [
                                                      {
                                                          text: constants.key.path,
                                                          value: error?.config?.url,
                                                      },
                                                  ]
                                                : []),
                                        ]}
                                        sx={{
                                            '.sekerUI-KeyValueList-item': {
                                                p: '0px !important',
                                                borderColor: (theme) => `${theme.palette.error.main} !important`,

                                                '.sekerUI-KeyValueList-item-text': {
                                                    '.sekerUI-KeyValueList-item-text-primary': {
                                                        color: (theme) => theme.palette.error.main,
                                                        fontWeight: 600,
                                                        wordBreak: 'break-word',
                                                    },
                                                    '.sekerUI-KeyValueList-item-text-secondary': {
                                                        color: (theme) => theme.palette.error.main,
                                                        fontWeight: 600,
                                                        wordBreak: 'break-word',
                                                    },
                                                },
                                            },
                                        }}
                                    />
                                </Box>
                            </GridItem>
                            <View show={!isUndefined(error?.response?.data?.trace)}>
                                <GridItem>
                                    <Box
                                        position="relative"
                                        bgcolor={(theme) => theme.palette.error[50]}
                                        borderRadius={0.5}
                                        fontSize={12}
                                        sx={{ color: (theme) => theme.palette.error.main }}>
                                        <CustomScrollbar
                                            height={100}
                                            thumbProps={{
                                                sx: {
                                                    backgroundColor: (theme) => theme.palette.error.main,
                                                },
                                            }}>
                                            <Box
                                                p={1}
                                                fontWeight={600}
                                                width={`calc(100% - ${copyButtonMeasure?.values?.width}px)`}
                                                whiteSpace="break-spaces"
                                                sx={{ wordBreak: 'break-word' }}>
                                                {error?.response?.data?.trace}
                                            </Box>
                                        </CustomScrollbar>
                                        <Box
                                            ref={copyButtonMeasure?.ref}
                                            p={1}
                                            pl={0.5}
                                            sx={{ position: 'absolute', top: 0, right: 0 }}>
                                            <Tooltip
                                                title={
                                                    isCopied
                                                        ? t(locale.contentTitles.copied)
                                                        : t(locale.contentTitles.copy)
                                                }
                                                componentsProps={{
                                                    tooltip: {
                                                        sx: {
                                                            backgroundColor: (theme) =>
                                                                (theme as Theme).palette.common.white,
                                                            boxShadow: style.boxShadow,
                                                            color: (theme) => (theme as Theme).palette.error.main,
                                                        },
                                                    },
                                                    arrow: {
                                                        sx: {
                                                            color: (theme) => (theme as Theme).palette.common.white,
                                                        },
                                                    },
                                                }}>
                                                <Button
                                                    color="error"
                                                    iconButton
                                                    icon={isCopied ? <Check /> : <ContentCopy />}
                                                    onClick={() => copy(error?.response?.data?.trace)}
                                                    sx={{
                                                        boxShadow: style.boxShadow,
                                                    }}
                                                />
                                            </Tooltip>
                                        </Box>
                                    </Box>
                                </GridItem>
                            </View>
                            <View show={import.meta.env.NODE_ENV !== 'production'}>
                                <GridItem>
                                    <Button
                                        variant="outlined"
                                        fullWidth
                                        text={t(locale.buttons.reportError)}
                                        color="error"
                                    />
                                </GridItem>
                            </View>
                        </Grid>
                    </Box>
                </Collapse>
            </MessageContent>
        );
    },
);

export default ErrorMessageContent;
