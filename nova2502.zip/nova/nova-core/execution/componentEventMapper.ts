/* eslint-disable */
/**
 * Component Event Mapper
 * Maps legacy EBML events to React component event handlers
 *
 * This module provides the execution bridge between the legacy event definitions
 * in COMPONENT_TO_EVENTS_MAP and the actual React component event handlers.
 */

/**
 * Interface for event handler props that should be added to React components
 * These handlers will fire events through the Nova event system
 */
export interface ComponentEventHandlers {
    onClick?: (event: any) => void;
    onChange?: (event: any) => void;
    onFocus?: (event: any) => void;
    onBlur?: (event: any) => void;
    onDoubleClick?: (event: any) => void;
    onKeyDown?: (event: any) => void;
    onMouseDown?: (event: any) => void;
    onSelect?: (event: any) => void;
    [key: string]: ((event: any) => void) | undefined;
}

/**
 * Maps legacy event names to React event handler names
 * Structure: { [legacyEventName]: reactEventHandlerName }
 */
export const LEGACY_EVENT_TO_REACT_HANDLER_MAP: Record<string, keyof ComponentEventHandlers> = {
    // Button events
    'actionPerformed': 'onClick',

    // Input/Focus events
    'focusGained': 'onFocus',
    'focusLost': 'onBlur',
    'insertUpdate': 'onChange',
    'removeUpdate': 'onChange',

    // Mouse events
    'mouseDoubleClicked': 'onDoubleClick',
    'mousePressed': 'onMouseDown',
    'mouseClicked': 'onClick',

    // Selection/State events
    'itemStateChanged': 'onChange',
    'itemStateSelected': 'onChange',
    'itemStateUnSelected': 'onChange',
    'valueChanged': 'onChange',
    'stateChanged': 'onChange',

    // Table-specific events
    'cellDataChanged': 'onChange',
    'rowSelected': 'onSelect',
    'rowInserted': 'onChange',
    'rowDeleted': 'onChange',

    // Checkbox events
    'allItemsUnSelected': 'onChange',

    // Popup events
    'onShowPopup': 'onFocus',
    'onClosePopup': 'onBlur',
    'onCancelPopup': 'onBlur',
    'popupCanceled': 'onBlur',
    'popupMenuWillBecomeVisible': 'onFocus',

    // File picker
    'fileSelected': 'onChange',
};

/**
 * Component-specific event to React handler mapping
 * This allows customization per component type
 */
export const COMPONENT_EVENT_HANDLERS: Record<string, Record<string, keyof ComponentEventHandlers>> = {
    'SetButton': {
        'actionPerformed': 'onClick',
    },
    'Input': {
        'actionPerformed': 'onKeyDown', // Enter key in input
        'focusGained': 'onFocus',
        'focusLost': 'onBlur',
        'insertUpdate': 'onChange',
        'removeUpdate': 'onChange',
        'onCancelPopup': 'onBlur',
        'onClosePopup': 'onBlur',
    },
    'NumberInput': {
        'actionPerformed': 'onKeyDown',
        'focusGained': 'onFocus',
        'focusLost': 'onBlur',
        'insertUpdate': 'onChange',
        'removeUpdate': 'onChange',
    },
    'Checkbox': {
        'actionPerformed': 'onChange',
        'itemStateSelected': 'onChange',
        'itemStateUnSelected': 'onChange',
        'allItemsUnSelected': 'onChange',
    },
    'Select': {
        'actionPerformed': 'onChange',
        'focusGained': 'onFocus',
        'focusLost': 'onBlur',
        'itemStateChanged': 'onChange',
    },
    'DatePicker': {
        'actionPerformed': 'onChange',
        'focusGained': 'onFocus',
        'focusLost': 'onBlur',
        'insertUpdate': 'onChange',
    },
    'TimePicker': {
        'actionPerformed': 'onChange',
        'focusLost': 'onBlur',
    },
    'Currency': {
        'actionPerformed': 'onKeyDown',
        'focusGained': 'onFocus',
        'focusLost': 'onBlur',
    },
    'TableComponent': {
        'cellDataChanged': 'onChange',
        'mouseDoubleClicked': 'onDoubleClick',
        'mousePressed': 'onMouseDown',
        'rowDeleted': 'onChange',
        'rowInserted': 'onChange',
        'rowSelected': 'onSelect',
    },
    'HandleButton': {
        'actionPerformed': 'onClick',
        'focusGained': 'onFocus',
        'focusLost': 'onBlur',
        'onCancelPopup': 'onBlur',
        'onClosePopup': 'onBlur',
        'onShowPopup': 'onFocus',
    },
    'Label': {
        'actionPerformed': 'onClick',
        'itemStateSelected': 'onChange',
        'itemStateUnSelected': 'onChange',
    },
    'Radio': {
        'actionPerformed': 'onChange',
        'itemStateSelected': 'onChange',
        'itemStateUnSelected': 'onChange',
    },
    'TabbedPane': {
        'stateChanged': 'onChange',
    },
    'Page': {
        // Page events are handled specially (lifecycle events)
        'pageLoad': 'onMount',
        'pageClose': 'onUnmount',
        'pageKeyEvent': 'onKeyDown',
    },
};

/**
 * Gets the React event handler name for a legacy event on a specific component type
 */
export function getReactHandlerForEvent(componentType: string, legacyEventName: string): keyof ComponentEventHandlers | null {
    // First check component-specific mapping
    const componentHandlers = COMPONENT_EVENT_HANDLERS[componentType];
    if (componentHandlers && componentHandlers[legacyEventName]) {
        return componentHandlers[legacyEventName];
    }

    // Fall back to generic mapping
    return LEGACY_EVENT_TO_REACT_HANDLER_MAP[legacyEventName] || null;
}


/**
 * Creates event handlers for a component based on its registered event bindings
 */
export function createComponentEventHandlers(
    componentId: string,
    componentType: string,
    eventBindings: Array<{ eventName: string; actionId: string; rule?: string }>,
    fireEvent: (componentId: string, eventName: string, eventData?: any) => Promise<void>
): ComponentEventHandlers {
    const handlers: ComponentEventHandlers = {};

    // Group event bindings by React handler
    const handlerToEvents = new Map<string, string[]>();

    eventBindings.forEach(binding => {
        const reactHandler = getReactHandlerForEvent(componentType, binding.eventName);
        if (reactHandler) {
            const handlerKey = reactHandler as string;
            if (!handlerToEvents.has(handlerKey)) {
                handlerToEvents.set(handlerKey, []);
            }
            handlerToEvents.get(handlerKey)!.push(binding.eventName);
        }
    });

    // Create React handlers that fire multiple legacy events
    handlerToEvents.forEach((legacyEvents, reactHandler) => {
        handlers[reactHandler] = async (event: any) => {
            // Fire all legacy events associated with this React handler
            for (const legacyEvent of legacyEvents) {
                await fireEvent(componentId, legacyEvent, event);
            }
        };
    });

    return handlers;
}

/**
 * Wraps component props with event handlers
 */
export function wrapComponentPropsWithEventHandlers(
    componentId: string,
    componentType: string,
    originalProps: any,
    eventBindings: Array<{ eventName: string; actionId: string; rule?: string }>,
    fireEvent: (componentId: string, eventName: string, eventData?: any) => Promise<void>
): any {
    const eventHandlers = createComponentEventHandlers(componentId, componentType, eventBindings, fireEvent);

    // Merge handlers with original props
    // If original props already have handlers, chain them
    const wrappedProps = { ...originalProps };

    Object.keys(eventHandlers).forEach(handlerName => {
        const newHandler = eventHandlers[handlerName];
        const existingHandler = originalProps[handlerName];

        if (existingHandler && newHandler) {
            // Chain handlers
            wrappedProps[handlerName] = async (event: any) => {
                await newHandler(event);
                await existingHandler(event);
            };
        } else if (newHandler) {
            wrappedProps[handlerName] = newHandler;
        }
    });

    return wrappedProps;
}

/**
 * Special handler for Enter key press in Input components
 * This maps to 'actionPerformed' event
 */
export function createEnterKeyHandler(
    componentId: string,
    fireEvent: (componentId: string, eventName: string, eventData?: any) => Promise<void>
): (event: React.KeyboardEvent) => void {
    return async (event: React.KeyboardEvent) => {
        if (event.key === 'Enter') {
            await fireEvent(componentId, 'actionPerformed', event);
        }
    };
}

/**
 * Gets event data from React event for legacy event system
 */
export function extractEventData(reactEvent: any, legacyEventName: string): any {
    const eventData: any = {};

    // Extract common data
    if (reactEvent?.target) {
        eventData.value = reactEvent.target.value;
        eventData.checked = reactEvent.target.checked;
    }

    // Event-specific data extraction
    switch (legacyEventName) {
        case 'mouseDoubleClicked':
        case 'mousePressed':
        case 'mouseClicked':
            eventData.x = reactEvent?.clientX;
            eventData.y = reactEvent?.clientY;
            eventData.button = reactEvent?.button;
            break;

        case 'rowSelected':
        case 'cellDataChanged':
            eventData.rowIndex = reactEvent?.rowIndex;
            eventData.columnIndex = reactEvent?.columnIndex;
            break;

        case 'pageKeyEvent':
            eventData.key = reactEvent?.key;
            eventData.keyCode = reactEvent?.keyCode;
            eventData.ctrlKey = reactEvent?.ctrlKey;
            eventData.shiftKey = reactEvent?.shiftKey;
            eventData.altKey = reactEvent?.altKey;
            break;
    }

    return eventData;
}
