/* eslint-disable */
/**
 * Popup Menu Component
 * Renders EBML JCSPopupMenu - Hidden container for popup menu items
 * This component doesn't render anything - its children (JCSPopupItem) are rendered by JCSDropdownButton
 */

import React from 'react';
import type { NovaComponentProps } from '..';

export const PopupMenuComponent: React.FC<NovaComponentProps> = () => {
    // This component is hidden and doesn't render anything
    // Its children are read by JCSDropdownButton to populate the menu
    return null;
};
