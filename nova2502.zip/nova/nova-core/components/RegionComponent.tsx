/* eslint-disable */
/**
 * Region Component
 * Renders EBML Region components (references to reusable sub-pages)
 * Supports both absolute positioning and responsive grid layout
 */

import React, { useState, useEffect } from 'react';
import { Box, Label, Paper, Nav } from '../../../seker-ui-lib';
import { GridItem } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import type { NovaUiSchema } from '../types/nova-ui-schema.types';
import { PreviewRenderer } from '../../nova-studio/components/PreviewRenderer';
import { getScreenEbmlSchema } from '../nova-ebml/ebml-schema-provider';
import { convertNovaEbmlToNovaUiSchema } from '../nova-ebml/nova-ebml-converter';
import DynamicModal from './DynamicModal';

export const RegionComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    regionName,
    title,
    popup,
    xs,
    component,
    componentKey,
    allPages,
    designComponent,
    name,
    type,
    text,
    value,
    placeholder,
    enabled,
    children,
    ...gridProps
}) => {
    const gridSize = { xs: 12, minHeight: 0 };
    const [regionSchema, setRegionSchema] = useState<NovaUiSchema | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [showPopup, setShowPopup] = useState(false);

    useEffect(() => {
        const loadRegionSchema = async () => {
            setIsLoading(true);
            try {
                const regionEbml = await getScreenEbmlSchema(regionName);
                if (regionEbml) {
                    const convertedSchema = convertNovaEbmlToNovaUiSchema(regionEbml);
                    setRegionSchema(convertedSchema);
                } else {
                    setRegionSchema(null);
                }
            } catch (error) {
                setRegionSchema(null);
            } finally {
                setIsLoading(false);
            }
        };

        if (regionName) {
            loadRegionSchema();
        } else {
            setRegionSchema(null);
            setIsLoading(false);
        }
    }, [regionName]);

    // Helper function to wrap content based on positioning mode
    const wrapContent = (content: React.ReactNode) => {
        if (useAbsolutePositioning) {
            return content;
        }

        const resolvedXs = xs ?? gridSize.xs;
        return (
            <GridItem xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} {...gridProps}>
                {content}
            </GridItem>
        );
    };

    // If popup is true, render as DynamicModal
    if (popup) {
        return (
            <DynamicModal
                showModal={showPopup}
                onClose={() => setShowPopup(false)}
                pageId={regionName}
                title={title || label || regionName}
            />
        );
    }

    // No region name specified
    if (!regionName) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #ff9800',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text="[Region: No name specified]" />
            </Box>
        );
    }

    // Loading state
    if (isLoading) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #2196f3',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <Label text={`[Loading region: ${regionName}...]`} />
            </Box>
        );
    }

    // Region not found or error loading
    if (!regionSchema) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #f44336',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text={`[Region not found: ${regionName}]`} />
            </Box>
        );
    }

    // Check if the Region has a title prop or if the root component (JCSPage) has a title
    // If so, render like a Container with Nav and Paper
    const rootComponent = regionSchema.ui[0];
    // Priority: title prop > root component title > root component label
    const regionTitle = title || rootComponent?.props?.title || rootComponent?.props?.label;
    // If region has a title, wrap in Paper with Nav (Container-like behavior)
    if (regionTitle) {
        const content = (
            <Paper
                sx={{
                    height: '100%',
                    width: '100%',
                    padding: '16px',
                    overflow: 'hidden'
                }}
            >
                <Box sx={{
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column'
                }}>
                    <Nav navTitleProps={{ title: regionTitle }} />
                    <PreviewRenderer component={rootComponent} />
                </Box>
            </Paper>
        );

        return wrapContent(content);
    }

    // Default: render region without additional container wrapper
    const content = (
        <Box sx={{
            width: '100%',
            height: '100%',
            position: useAbsolutePositioning ? 'relative' : undefined,
            display: 'flex',
            flexDirection: 'column'
        }}>
            <PreviewRenderer component={rootComponent} />
        </Box>
    );

    return wrapContent(content);
};
