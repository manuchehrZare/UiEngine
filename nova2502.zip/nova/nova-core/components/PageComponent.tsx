/* eslint-disable */
/**
 * Page Component
 * Renders EBML Page components (root container).
 * If popupMenuName is set, wraps content in ContextMenuWrapper to provide right-click menu.
 */

import React from 'react';
import { Box, Grid, Paper } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { ContextMenuWrapper } from './ContextMenuWrapper';


export const PageComponent: React.FC<NovaComponentProps> = ({
    id,
    bounds,
    pageSize,
    pageWidth: propPageWidth,
    pageHeight: propPageHeight,
    backgroundColor,
    children,
    designComponent,
    component,
    allPages,
    useAbsolutePositioning = false,
    popupMenuName,
    ...props
}) => {
    const content = (
        <Paper sx={{ width: '100%', p: 2 }}>
            <Grid
                minHeight={propPageHeight}
                height="100%"
                display="flex"
                justifyContent="center"
                alignItems="flex-start"
            >
                <Box sx={{ width: '100%' }}>
                    {children}
                </Box>
            </Grid>
        </Paper>
    );

    if (popupMenuName) {
        return (
            <ContextMenuWrapper popupMenuName={popupMenuName}>
                {content}
            </ContextMenuWrapper>
        );
    }

    return content;
}
