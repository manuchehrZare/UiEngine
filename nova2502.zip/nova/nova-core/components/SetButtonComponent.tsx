/* eslint-disable */
/**
 * Button Component
 * Renders EBML Button components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Button, GridItem, Tooltip } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { boundsToGridSize } from '..';
import { useNovaComponent } from '../hooks/useComponentRuntime';
import { 
    AddCircleOutline, 
    EditNote, 
    Search, 
    ChevronLeft, 
    ChevronRight, 
    Save, 
    Close, 
    Add, 
    Menu, 
    Refresh, 
    Delete, 
    Print, 
    CorporateFare ,
    Adjust,
    Image,
    ArrowUpward,
    ArrowDownward,
    Star,
    BrokenImage,
    Update,
    Clear,
    Warning,
    Class,
    ViewColumn,
    ViewWeek,
    Extension,
    Widgets,
    Computer,
    SettingsInputComponent,
    FilterList,
    Person,
    Code,
    Business,
    Settings,
    OpenInNew,
    Memory,
    ListAlt,
    Storage,
    Public,
    AdminPanelSettings,
    GroupWork,
    DesktopWindows,
    Check,
    RoomService,
    AccessTime,
    History,
    Group,
    Functions,
    ErrorOutline,
    Error,
    FilterAlt,
    Info,
    Flag,
    ArrowUpwardOutlined,
    ArrowDownwardOutlined,
    Edit,
    CheckCircle,
    NoteAdd,
    PostAdd,
    LibraryAdd,
    Archive,
    LockOpen,
    LockClock,
    ContentCopy,
    ContentCutOutlined,
    TableChart,
    StarBorder,
    Folder,
    Link,
    ContentPaste,
    Visibility,
    Publish,
    DeleteForever,
    StarBorderOutlined,
    DriveFileRenameOutline,
    Scanner,
    FindInPage,
    NotificationsActive,
    LockOpenOutlined,
    NotificationsOff,
    RestoreFromTrash,
    Sync,
    Description,
    InfoOutlined,
    ChangeCircle,
    Compress,
    CloudDownload,
    Draw,
    Verified,
    Help,
    ChevronLeftOutlined,
    ChevronRightOutlined,
    CheckCircleOutline,
    MergeTypeOutlined,
    ReadMore,
    KeyboardArrowDown,
    KeyboardArrowLeft,
    CompareArrows,
    HighlightOff,
    KeyboardArrowRight,
    KeyboardArrowUp,
    Cancel,
    SwapHoriz,
    FileUpload,
    FindReplace,
    FolderZip,
    FolderOpen,
    Payment,
    AttachMoney,
    Preview,
    Send,
    Share,
    ArrowForward,
    CheckBoxOutlineBlank
} from '@mui/icons-material';
import { Box, Checkbox, List } from '@mui/material';

const ICON_MAPPING: Record<string, React.ReactNode> = {
'32.png': <Image />
,'Add.gif': <Add />
,'CheckIn.gif': <ArrowUpward />
,'CheckOut.gif': <ArrowDownward />
,'Delete.gif': <Delete />
,'Favorites.gif': <Star />
,'Search.gif': <Search />
,'Select.gif': <Checkbox />
,'Thumbs.db': <BrokenImage />
,'Update.gif': <Update />
,'core/.svn/text-base/Clear.gif.svn-base': <Clear />
,'core/.svn/text-base/Update.gif.svn-base': <Update />
,'core/Add.gif': <Add />
,'core/Alert.gif': <Warning />
,'core/Class.gif': <Class />
,'core/Clear.gif': <Clear />
,'core/Close.gif': <Close />
,'core/Column.gif': <ViewColumn />
,'core/Columns.gif': <ViewWeek />
,'core/Component.gif': <Extension />
,'core/ComponentGroup.gif': <Widgets />
,'core/Computer.gif': <Computer />
,'core/Delete.gif': <Delete />
,'core/DomainParameters.gif': <SettingsInputComponent />
,'core/Filter.gif': <FilterList />
,'core/Member.gif': <Person />
,'core/Method.gif': <Code />
,'core/New.gif': <AddCircleOutline />
,'core/Organization.gif': <CorporateFare />
,'core/OrganizationGroup.gif': <Business />
,'core/Parameters.gif': <Settings />
,'core/Popup.gif': <OpenInNew />
,'core/Printer.gif': <Print />
,'core/Process.gif': <Memory />
,'core/ProcessList.gif': <ListAlt />
,'core/ReferenceData.gif': <Storage />
,'core/Refresh.gif': <Refresh />
,'core/Region.gif': <Public />
,'core/Role.gif': <AdminPanelSettings />
,'core/RoleGroup.gif': <GroupWork />
,'core/Save.gif': <Save />
,'core/Screen.gif': <DesktopWindows />
,'core/Select.gif': <Check />
,'core/Service.gif': <RoomService />
,'core/ServiceList.gif': <List />
,'core/Time.gif': <AccessTime />
,'core/TimeList.gif': <History />
,'core/Update.gif': <Update />
,'core/User.gif': <Person />
,'core/UserGroup.gif': <Group />
,'core/Variable.gif': <Functions />
,'core/alert.gif': <ErrorOutline />
,'core/error.gif': <Error />
,'core/filter.gif': <FilterAlt />
,'core/info.gif': <Info />
,'core/search.gif': <Search />
,'core/tr_flag.gif': <Flag />
,'core/warning.gif': <Warning />
,'dms/.svn/text-base/CheckIn.gif.svn-base': <ArrowUpwardOutlined />
,'dms/.svn/text-base/CheckOut.gif.svn-base': <ArrowDownwardOutlined />
,'dms/.svn/text-base/Search.gif.svn-base': <Search />
,'dms/.svn/text-base/edit_icon.gif.svn-base': <Edit />
,'dms/ActiveVersion.gif': <CheckCircle />
,'dms/Add.gif': <NoteAdd />
,'dms/AddCompoundDoc.gif': <PostAdd />
,'dms/AddMultipleDoc.gif': <LibraryAdd />
,'dms/Archieve.gif': <Archive />
,'dms/CheckIn.gif': <LockOpen />
,'dms/CheckOut.gif': <LockClock />
,'dms/Clear.gif': <Clear />
,'dms/Copy.gif': <ContentCopy />
,'dms/Cut.gif': <ContentCutOutlined />
,'dms/ExportToExcel.gif': <TableChart />
,'dms/Favorites.gif': <StarBorder />
,'dms/Folder.gif': <Folder />
,'dms/Link.gif': <Link />
,'dms/MyFavorites.gif': <Star />
,'dms/Paste.gif': <ContentPaste />
,'dms/PreviewFile.gif': <Visibility />
,'dms/Publish.gif': <Publish />
,'dms/Purge.gif': <DeleteForever />
,'dms/RemoveMyFavorites.gif': <StarBorderOutlined />
,'dms/Rename.gif': <DriveFileRenameOutline />
,'dms/Scanner.gif': <Scanner />
,'dms/Search.gif': <Search />
,'dms/SearchResults.gif': <FindInPage />
,'dms/Subscribe.gif': <NotificationsActive />
,'dms/UnCheckout.gif': <LockOpenOutlined />
,'dms/UnSubscribe.gif': <NotificationsOff />
,'dms/UndoDelete.gif': <RestoreFromTrash />
,'dms/Update.gif': <Sync />
,'dms/ViewContent.gif': <Description />
,'dms/ViewDetails.gif': <InfoOutlined />
,'dms/change1.gif': <ChangeCircle />
,'dms/compact.gif': <Compress />
,'dms/downloadsign.gif': <CloudDownload />
,'dms/edit_icon.gif': <Edit />
,'dms/sign.gif': <Draw />
,'dms/verify.gif': <Verified />
,'help2.gif': <Help />
,'iconLeft.png': <ChevronLeftOutlined />
,'iconRight.png': <ChevronRightOutlined />
,'mop/Approve.gif': <CheckCircleOutline />
,'mop/Combine.gif': <MergeTypeOutlined />
,'mop/Details.gif': <ReadMore />
,'mop/Down.gif': <KeyboardArrowDown />
,'mop/Left.gif': <KeyboardArrowLeft />
,'mop/Match.gif': <CompareArrows />
,'mop/Print.gif': <Print />
,'mop/Reject.gif': <HighlightOff />
,'mop/Right.gif': <KeyboardArrowRight />
,'mop/Up.gif': <KeyboardArrowUp />
,'pay/Cancel.jpg': <Cancel />
,'pay/change.jpg': <SwapHoriz />
,'pay/fileload.gif': <FileUpload />
,'pay/find.jpg': <FindReplace />
,'pay/folderdownload.jpg': <FolderZip />
,'pay/foldersearch.jpg': <FolderOpen />
,'pay/payment.gif': <Payment />
,'pay/payment.jpg': <AttachMoney />
,'pay/preview_icon.gif': <Preview />
,'pay/send.jpg': <Send />
,'pay/sharing.jpg': <Share />
,'right3 (2).gif': <ArrowForward />
,'space.gif': <CheckBoxOutlineBlank />
};

export const SetButtonComponent: React.FC<NovaComponentProps> = ({
    id,
    text,
    label,
    enabled,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    type,
    xs,
    ...props
}) => {
    // Use Nova runtime hook to get event handlers attached
    const runtimeProps = useNovaComponent(id, 'SetButton', props);

    const containerWidth = parentBounds?.width || 960;
    const buttonText = text || label || '';

    let buttonProps = { ...runtimeProps };
    buttonProps.icon=null;
    const iconName = props.icon as string;

    if (iconName ) {
        buttonProps.iconLeft = ICON_MAPPING[iconName] ||<Adjust/> ;
    }
    const buttonContent =( buttonText ?  
        <Button
            fullWidth
            text={buttonText}
            disabled={enabled === 'false'}
            sx={{
                width: '100%',
                height: '100%',
                minWidth: bounds?.width,
                whiteSpace: 'nowrap',
                '& .MuiButton-label': {
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                },
            }}
            {...buttonProps}
        /> : 
        <Box sx={{ height: '20px', width: '20px' ,overflow:'hidden' }}> 
        <Button
            name='openModalBtn'
            iconButton
            disabled={enabled === 'false'}
             sx={{ maxHeight: '20px !important', minWidth: '24px' ,marginTop:'-2px', padding:'5px  !important' }}
            {...buttonProps}
        />
        </Box >
    );

    if (useAbsolutePositioning) {
        return buttonContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {buttonContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
     const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
             xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}>
            {buttonContent}
        </GridItem>
    );
};
