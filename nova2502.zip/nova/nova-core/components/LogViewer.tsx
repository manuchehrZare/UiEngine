/* eslint-disable */
/**
 * Log Viewer Component
 * Displays logs from LogCenter in a filterable, scrollable view
 */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Box, Typography, IconButton, Select, MenuItem, TextField, Chip } from '@mui/material';
import { Clear } from '@mui/icons-material';
import { useLogCenter, type LogLevel, type LogEntry } from '../context/LogCenterContext';

const LOG_LEVEL_COLORS: Record<LogLevel, string> = {
    debug: '#9e9e9e',
    info: '#2196f3',
    warn: '#ff9800',
    error: '#f44336'
};

const LOG_LEVEL_LABELS: Record<LogLevel, string> = {
    debug: 'DEBUG',
    info: 'INFO',
    warn: 'WARN',
    error: 'ERROR'
};

export const LogViewer: React.FC = () => {
    const { logs, clearLogs } = useLogCenter();
    const [levelFilter, setLevelFilter] = useState<LogLevel | 'all'>('all');
    const [categoryFilter, setCategoryFilter] = useState<string>('all');
    const [searchText, setSearchText] = useState('');
    const [autoScroll, setAutoScroll] = useState(true);
    const logEndRef = useRef<HTMLDivElement>(null);
    const logContainerRef = useRef<HTMLDivElement>(null);

    // Extract unique categories
    const categories = useMemo(() => {
        const cats = new Set(logs.map(log => log.category));
        return ['all', ...Array.from(cats)];
    }, [logs]);

    // Filter logs
    const filteredLogs = useMemo(() => {
        return logs.filter(log => {
            // Level filter
            if (levelFilter !== 'all' && log.level !== levelFilter) {
                return false;
            }

            // Category filter
            if (categoryFilter !== 'all' && log.category !== categoryFilter) {
                return false;
            }

            // Search filter
            if (searchText && !log.message.toLowerCase().includes(searchText.toLowerCase())) {
                return false;
            }

            return true;
        });
    }, [logs, levelFilter, categoryFilter, searchText]);

    // Auto-scroll to bottom when new logs arrive
    useEffect(() => {
        if (autoScroll && logEndRef.current) {
            logEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [filteredLogs, autoScroll]);

    // Detect manual scroll
    const handleScroll = () => {
        if (logContainerRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = logContainerRef.current;
            const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;
            setAutoScroll(isAtBottom);
        }
    };

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            {/* Filters */}
            <Box sx={{
                p: 1,
                borderBottom: '1px solid #e0e0e0',
                display: 'flex',
                gap: 1,
                alignItems: 'center',
                flexWrap: 'wrap'
            }}>
                <Select
                    size="small"
                    value={levelFilter}
                    onChange={(e) => setLevelFilter(e.target.value as LogLevel | 'all')}
                    sx={{ minWidth: 100 }}
                >
                    <MenuItem value="all">All Levels</MenuItem>
                    <MenuItem value="debug">Debug</MenuItem>
                    <MenuItem value="info">Info</MenuItem>
                    <MenuItem value="warn">Warn</MenuItem>
                    <MenuItem value="error">Error</MenuItem>
                </Select>

                <Select
                    size="small"
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    sx={{ minWidth: 120 }}
                >
                    {categories.map(cat => (
                        <MenuItem key={cat} value={cat}>
                            {cat === 'all' ? 'All Categories' : cat}
                        </MenuItem>
                    ))}
                </Select>

                <TextField
                    size="small"
                    placeholder="Search logs..."
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    sx={{ flexGrow: 1, maxWidth: 300 }}
                />

                <Typography variant="caption" sx={{ color: 'text.secondary', ml: 'auto' }}>
                    {filteredLogs.length} / {logs.length} logs
                </Typography>

                <IconButton size="small" onClick={clearLogs} title="Clear logs">
                    <Clear fontSize="small" />
                </IconButton>
            </Box>

            {/* Log entries */}
            <Box
                ref={logContainerRef}
                onScroll={handleScroll}
                sx={{
                    flexGrow: 1,
                    overflow: 'auto',
                    bgcolor: '#000',
                    color: '#F00',
                    fontFamily: 'monospace',
                    fontSize: '12px',
                    p: 1
                }}
            >
                {filteredLogs.length === 0 ? (
                    <Box sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        height: '100%',
                        color: '#F00'
                    }}>
                        <Typography variant="body2">
                            {logs.length === 0 ? 'No logs yet' : 'No logs match filters'}
                        </Typography>
                    </Box>
                ) : (
                    filteredLogs.map(log => (
                        <LogEntryRow key={log.id} log={log} />
                    ))
                )}
                <div ref={logEndRef} />
            </Box>

            {/* Auto-scroll indicator */}
            {!autoScroll && (
                <Box sx={{
                    position: 'absolute',
                    bottom: 40,
                    right: 20,
                    bgcolor: 'primary.main',
                    color: 'white',
                    px: 1.5,
                    py: 0.5,
                    borderRadius: 1,
                    fontSize: '12px',
                    cursor: 'pointer',
                    boxShadow: 2
                }}
                onClick={() => {
                    setAutoScroll(true);
                    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
                }}
                >
                    ↓ Scroll to bottom
                </Box>
            )}
        </Box>
    );
};

const LogEntryRow: React.FC<{ log: LogEntry }> = ({ log }) => {
    const [expanded, setExpanded] = useState(false);

    const formatTime = (date: Date) => {
        const timeStr = date.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const ms = date.getMilliseconds().toString().padStart(3, '0');
        return `${timeStr}.${ms}`;
    };

    return (
        <Box
            sx={{
                mb: 0.5,
                p: 0.5,
                borderRadius: 0.5,
                '&:hover': {
                    bgcolor: 'rgba(255, 255, 255, 0.05)',
                    color: '#eee7e7'
                },
                cursor: log.data ? 'pointer' : 'default'
            }}
            onClick={() => log.data && setExpanded(!expanded)}
        >
            <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                {/* Timestamp */}
                {/* <Typography
                    component="span"
                    sx={{
                        color: '#858585',
                        cpş
                        fontSize: '11px',
                        minWidth: '90px',
                        fontFamily: 'monospace'
                    }}
                >
                    {formatTime(log.timestamp)}
                </Typography> */}

                {/* Level badge */}
                <Chip
                    label={LOG_LEVEL_LABELS[log.level]}
                    size="small"
                    sx={{
                        height: '18px',
                        fontSize: '10px',
                        fontWeight: 'bold',
                        bgcolor: LOG_LEVEL_COLORS[log.level],
                       color: '#eee7e7',
                        minWidth: '50px',
                        '& .MuiChip-label': {
                            px: 0.5
                        }
                    }}
                />

                {/* Category */}
                {/* <Typography
                    component="span"
                    sx={{
                        color: '#4ec9b0',
                        fontSize: '11px',
                        fontWeight: 'bold',
                        minWidth: '120px'
                    }}
                >
                    [{log.category}]
                </Typography> */}

                {/* Message */}
                <Typography
                    component="span"
                    sx={{
                        color: '#eee7e7!important',
                        fontSize: '12px',
                        flexGrow: 1,
                        wordBreak: 'break-word'
                    }}
                >
                    {log.message}
                </Typography>
            </Box>

            {/* Expanded data */}
            {expanded && log.data && (
                <Box
                    sx={{
                        mt: 0.5,
                        ml: 4,
                        p: 1,
                        backgroundColor:'#383838',  color: '#eee7e7',
                        borderRadius: 0.5,
                        borderLeft: '2px solid #4ec9b0',
                        fontSize: '11px',
                        overflow: 'auto'
                    }}
                >
                    <pre style={{ margin: 0, backgroundColor:'#383838',  color: '#eee7e7' }}>
                        {typeof log.data === 'string'
                            ? log.data
                            : JSON.stringify({ timestamp:log.timestamp,
                                category:log.category,
                             ...log.data,}, null, 2)}
                    </pre>
                </Box>
            )}
        </Box>
    );
};
