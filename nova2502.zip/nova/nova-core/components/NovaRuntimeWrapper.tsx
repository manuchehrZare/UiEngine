/* eslint-disable */
/**
 * Nova Runtime Wrapper
 * Automatically wraps components with runtime features:
 * - Method registration
 * - Event handler setup
 * - State synchronization
 * - Visibility control
 *
 * This component should wrap all rendered Nova components in the runtime
 * to enable BeanAction method calls and event binding execution.
 */

import React, { useEffect } from 'react';
import { useNova } from '../context/NovaContext';
import { useLogger } from '../context/LogCenterContext';
import { registerAllComponentMethods } from '../execution/componentMethodMapper';
import { wrapComponentPropsWithEventHandlers } from '../execution/componentEventMapper';
import type { DesignComponent } from '../types/nova-ui-schema.types';

interface NovaRuntimeWrapperProps {
    component: DesignComponent;
    children: React.ReactElement;
}

/**
 * Wrapper component that adds runtime features to Nova components
 */
export const NovaRuntimeWrapper: React.FC<NovaRuntimeWrapperProps> = ({ component, children }) => {
    const logger = useLogger('NovaRuntimeWrapper');
    const {
        registerComponentMethod,
        getComponentState,
        setComponentState,
        invokeComponentMethod,
        getVariable,
        setVariable,
        fireEvent,
        schema,
    } = useNova();

    const componentId = component.id;
    const componentType = component.type;

    // Register all component methods on mount
    useEffect(() => {
        logger.debug('Registering component methods', { componentId, componentType });
        registerAllComponentMethods(
            componentId,
            componentType,
            registerComponentMethod,
            getComponentState,
            setComponentState,
            invokeComponentMethod,
            getVariable,
            setVariable
        );
    }, [componentId, componentType]);

    // Fire lifecycle events for Page components
    useEffect(() => {
        if (componentType === 'Page') {
            logger.info('Firing pageLoad event', { componentId });
            // Fire pageLoad event on mount
            fireEvent(componentId, 'pageLoad');

            // Fire pageClose event on unmount
            return () => {
                logger.info('Firing pageClose event', { componentId });
                fireEvent(componentId, 'pageClose');
            };
        }
        return undefined; // Fix TypeScript warning
    }, [componentId, componentType, fireEvent]);

    // Get event bindings for this component from schema
    const eventBindings = React.useMemo(() => {
        if (!schema?.events?.actions) {
            logger.debug('No actions in schema for component', { componentId });
            return [];
        }

        const bindings: Array<{ eventName: string; actionId: string; rule?: string }> = [];

        schema.events.actions.forEach(action => {
            // Check if this action is bound to this component
            if (action.componentId === componentId) {
                logger.debug('Found event binding', { componentId, eventName: action.eventName, actionName: action.name });
                bindings.push({
                    eventName: action.eventName || '',
                    actionId: action.id,
                    rule: action.rule,
                });
            }
        });

        if (bindings.length > 0) {
            logger.debug('Component has event bindings', { componentId, componentType, count: bindings.length, bindings });
        }

        return bindings;
    }, [schema, componentId, componentType]);

    // Wrap props with event handlers
    const wrappedProps = React.useMemo(() => {
        if (eventBindings.length === 0) {
            return children.props;
        }

        logger.debug('Wrapping props with event handlers', { componentId });
        const wrapped = wrapComponentPropsWithEventHandlers(
            componentId,
            componentType,
            children.props,
            eventBindings,
            fireEvent
        );

        // Log which handlers were added
        const handlerKeys = Object.keys(wrapped).filter(k => k.startsWith('on'));
        if (handlerKeys.length > 0) {
            logger.debug('Added event handlers to component', { componentId, handlers: handlerKeys });
        }

        return wrapped;
    }, [componentId, componentType, children.props, eventBindings, fireEvent]);

    // Get visibility state - check both componentState and component.props
    // componentState.visible can be changed at runtime via actions
    // component.props.visible is the design-time default value
    const componentState = getComponentState(componentId);
    const propsVisible = component.props?.visible;
    // Use componentState.visible if explicitly set, otherwise fall back to props.visible
    // Both default to true if not specified
    const isVisible = componentState?.visible !== false && propsVisible !== false;

    // Clone the child element with wrapped props and visibility
    return React.cloneElement(children, {
        ...wrappedProps,
        style: {
            ...wrappedProps.style,
            display: isVisible ? wrappedProps.style?.display : 'none',
        },
    });
};

/**
 * Higher-order component version for wrapping component classes
 */
export function withNovaRuntime<P extends object>(
    Component: React.ComponentType<P>,
    componentType: string
) {
    return React.forwardRef<any, P & { id: string }>((props, ref) => {
        const { id, ...restProps } = props;
        const componentId = id;

        const {
            registerComponentMethod,
            getComponentState,
            setComponentState,
            invokeComponentMethod,
            getVariable,
            setVariable,
            fireEvent,
            schema,
        } = useNova();

        // Register all component methods on mount
        useEffect(() => {
            registerAllComponentMethods(
                componentId,
                componentType,
                registerComponentMethod,
                getComponentState,
                setComponentState,
                invokeComponentMethod,
                getVariable,
                setVariable
            );
        }, [componentId, componentType]);

        // Get event bindings for this component from schema
        const eventBindings = React.useMemo(() => {
            if (!schema?.events?.actions) return [];

            const bindings: Array<{ eventName: string; actionId: string; rule?: string }> = [];

            schema.events.actions.forEach(action => {
                // Check if this action is bound to this component
                if (action.componentId === componentId) {
                    bindings.push({
                        eventName: action.eventName || '',
                        actionId: action.id,
                        rule: action.rule,
                    });
                }
            });

            return bindings;
        }, [schema, componentId]);

        // Wrap props with event handlers
        const wrappedProps = React.useMemo(() => {
            if (eventBindings.length === 0) {
                return restProps;
            }

            return wrapComponentPropsWithEventHandlers(
                componentId,
                componentType,
                restProps,
                eventBindings,
                fireEvent
            );
        }, [componentId, componentType, restProps, eventBindings, fireEvent]);

        // Get visibility state - check both componentState and props
        // componentState.visible can be changed at runtime via actions
        // props.visible is the design-time default value
        const componentState = getComponentState(componentId);
        const propsVisible = (restProps as any).visible;
        // Use componentState.visible if explicitly set, otherwise fall back to props.visible
        // Both default to true if not specified
        const isVisible = componentState?.visible !== false && propsVisible !== false;

        if (!isVisible) {
            return null;
        }

        return <Component ref={ref} {...(wrappedProps as P)} />;
    });
}
