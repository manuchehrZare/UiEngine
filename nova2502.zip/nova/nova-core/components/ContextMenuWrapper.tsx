/* eslint-disable */
/**
 * ContextMenuWrapper
 * A transparent wrapper that attaches a right-click context menu to any container component.
 * Menu items are resolved from schema.popupMenus via NovaContext using the popupMenuName prop.
 * Fires fireEvent(item.id, 'actionPerformed') when a menu item is clicked.
 */

import React, { useState } from 'react';
import { Menu, MenuItem } from '../../../seker-ui-lib';
import { useNovaOptional } from '../context/NovaContext';

interface ContextMenuWrapperProps {
    popupMenuName?: string;
    children: React.ReactNode;
    [key: string]: any;
}

export const ContextMenuWrapper: React.FC<ContextMenuWrapperProps> = ({
    popupMenuName,
    children,
    ...rest
}) => {
    const context = useNovaOptional();
    const [anchor, setAnchor] = useState<{ mouseX: number; mouseY: number } | null>(null);

    const menu = popupMenuName && context ? context.getPopupMenu(popupMenuName) : undefined;
    const items = menu?.items ?? [];

    const handleContextMenu = (event: React.MouseEvent) => {
        if (items.length === 0) return;
        event.preventDefault();
        setAnchor({ mouseX: event.clientX, mouseY: event.clientY });
    };

    const handleClose = () => setAnchor(null);

    const handleItemClick = (itemId: string) => {
        handleClose();
        context?.fireEvent(itemId, 'actionPerformed');
    };

    return (
        <div
            onContextMenu={handleContextMenu}
            style={{ width: '100%', height: '100%', cursor: items.length > 0 ? 'context-menu' : undefined }}
            {...rest}
        >
            {children}

            {items.length > 0 && (
                <Menu
                    open={anchor !== null}
                    onClose={handleClose}
                    anchorReference="anchorPosition"
                    anchorPosition={
                        anchor !== null
                            ? { top: anchor.mouseY, left: anchor.mouseX }
                            : undefined
                    }
                >
                    {items.map(item => (
                        <MenuItem
                            key={item.id}
                            disabled={!item.enabled}
                            onClick={() => handleItemClick(item.id)}
                        >
                            {item.text}
                        </MenuItem>
                    ))}
                </Menu>
            )}
        </div>
    );
};
