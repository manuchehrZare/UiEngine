/* eslint-disable */
/**
 * Popup Item Component
 * Renders EBML JCSPopupItem - Individual item in a popup menu
 * This component doesn't render anything - it's only used as data by JCSDropdownButton/JCSPopupMenu
 */

import React from 'react';
import type { NovaComponentProps } from '..';

export const PopupItemComponent: React.FC<NovaComponentProps> = () => {
    // This component is hidden and doesn't render anything
    // It's only used as data by the parent JCSPopupMenu/JCSDropdownButton
    return null;
};
