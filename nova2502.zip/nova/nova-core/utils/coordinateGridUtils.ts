/* eslint-disable */
/**
 * Coordinate-Based Grid Utilities
 * Generates a CSS Grid layout based on exact component bounds coordinates.
 */

import type { ParsedComponent } from '../types';

/**
 * Default tolerance (px) for row grouping.
 * Y-coordinates within this distance of each other are collapsed into
 * a single row, preventing micro-gaps from becoming extra grid tracks.
 */
const ROW_GROUPING_TOLERANCE = 5;

/**
 * Component types that must never contribute X/Y cuts to the grid.
 * JCSPopupMenu and JCSPopupItem are definition-only beans — their bounds
 * describe a floating popup position, not a layout slot, so including them
 * would create spurious column and row tracks.
 */
const GRID_EXCLUDED_TYPES = new Set<string>([
    'JCSPopupMenu',
    'JCSPopupItem',
]);

export interface GridTrack {
    start: number;
    end: number;
    size: number;
    index: number;
}

export interface CoordinateGridResult {
    rows: string;    // grid-template-rows value
    columns: string; // grid-template-columns value
    placements: Map<string, GridPlacement>; // Map of componentId -> placement style
    width: number;
    height: number;
}

export interface GridPlacement {
    gridColumnStart: number;
    gridColumnEnd: number;
    gridRowStart: number;
    gridRowEnd: number;
}

/**
 * Groups a sorted list of coordinate values so that any value within
 * `tolerance` pixels of the previous one is snapped to that same value.
 * This collapses near-identical row/column cuts into a single track.
 */
function groupCoordinates(sorted: number[], tolerance: number): number[] {
    if (sorted.length === 0) return [];
    const grouped: number[] = [sorted[0]];
    for (let i = 1; i < sorted.length; i++) {
        if (sorted[i] - grouped[grouped.length - 1] <= tolerance) {
            // Within tolerance — snap to the existing representative value
            continue;
        }
        grouped.push(sorted[i]);
    }
    return grouped;
}

/**
 * Calculates a CSS Grid layout based on unique X and Y coordinates of all components.
 * Uses 'fr' units for columns to ensure the layout scales responsively to the container width.
 *
 * @param rowTolerance - Y-coordinates within this many pixels are merged into one row track.
 *                       Defaults to ROW_GROUPING_TOLERANCE.
 */
export function calculateCoordinateGrid(
    components: ParsedComponent[],
    containerWidth: number = 960,
    rowTolerance: number = ROW_GROUPING_TOLERANCE
): CoordinateGridResult {
    /**
     * Returns true for components that must not contribute any grid cuts.
     * - GRID_EXCLUDED_TYPES: popup-menu definition beans (floating, not layout slots)
     * - Region with popup=true: overlay regions that float over the layout
     */
    const isExcluded = (comp: ParsedComponent): boolean => {
        if (GRID_EXCLUDED_TYPES.has(comp.type)) return true;
        if (
            comp.type === 'Region' &&
            (comp.properties?.popup === true || comp.properties?.popup === 'true')
        ) return true;
        return false;
    };

    // 1. Collect all unique X and Y coordinates (cuts)
    const xCuts = new Set<number>([0]); // Always start at 0
    const rawYCuts = new Set<number>([0]);

    // Also track max boundaries
    let maxY = 0;

    components.forEach(comp => {
        if (!comp.bounds) return;
        if (isExcluded(comp)) return;
        // Skip zero-size components — they contribute no visual area and would
        // create degenerate (zero-height/width) grid tracks.
        if (comp.bounds.width <= 0 || comp.bounds.height <= 0) return;
        const { x, y, width, height } = comp.bounds;

        xCuts.add(x);
        xCuts.add(x + width);

        rawYCuts.add(y);
        rawYCuts.add(y + height);

        if (y + height > maxY) maxY = y + height;
    });

    // Ensure we account for the full container width to maintain proportions
    // Only add if it's larger than the last component
    const maxX = Math.max(...Array.from(xCuts));
    if (containerWidth > maxX) {
        xCuts.add(containerWidth);
    }

    // 2. Sort coordinates; group nearby Y cuts within rowTolerance into single tracks
    const sortedX = Array.from(xCuts).sort((a, b) => a - b);
    const sortedY = groupCoordinates(
        Array.from(rawYCuts).sort((a, b) => a - b),
        rowTolerance
    );

    // 3. Generate Track Definitions (intervals between cuts)
    const colTracks: GridTrack[] = [];
    const rowTracks: GridTrack[] = [];

    // Columns: Use 'fr' units proportional to the pixel width to makes it responsive
    let gridTemplateColumns = '';
    for (let i = 0; i < sortedX.length - 1; i++) {
        const size = sortedX[i+1] - sortedX[i];
        colTracks.push({ start: sortedX[i], end: sortedX[i+1], size, index: i + 1 });
        // Use fractional units (fr) so the grid scales to fit the container
        // We use the pixel value as the fraction (e.g. 50px -> 50fr)
        gridTemplateColumns += `${size}fr `;
    }

    // Determine which row intervals have at least one component spanning them.
    // Compare using tolerance so snapped rows are matched correctly.
    const rowHasComponent = new Set<number>();
    components.forEach(comp => {
        if (!comp.bounds) return;
        if (isExcluded(comp)) return;
        const { y, height } = comp.bounds;
        for (let i = 0; i < sortedY.length - 1; i++) {
            // A component spans interval i if its y-start is at/near sortedY[i]
            // and its y-end reaches at/beyond sortedY[i+1] (within tolerance).
            if (y <= sortedY[i] + rowTolerance && y + height >= sortedY[i + 1] - rowTolerance) {
                rowHasComponent.add(i);
            }
        }
    });

    // Rows: if the interval contains a component use minmax(0px, auto) so the row
    // shrinks to fit its content without enforcing the legacy pixel height.
    // Empty/gap intervals keep minmax(size, auto) to preserve spacing.
    let gridTemplateRows = '';
    for (let i = 0; i < sortedY.length - 1; i++) {
        const size = sortedY[i+1] - sortedY[i];
        rowTracks.push({ start: sortedY[i], end: sortedY[i+1], size, index: i + 1 });
        gridTemplateRows += rowHasComponent.has(i)
            ? `minmax(0px, auto) `
            : `minmax(${size}px, auto) `;
    }

    // 4. Map components to grid areas
    const placements = new Map<string, GridPlacement>();

    // After Y-grouping, a component's raw y/y+height may not exist verbatim in
    // sortedY. Find the nearest grouped value within tolerance so placements
    // still resolve correctly.
    const snapToGrouped = (raw: number, sorted: number[], tolerance: number): number => {
        let best = -1;
        let bestDist = Infinity;
        for (let i = 0; i < sorted.length; i++) {
            const dist = Math.abs(sorted[i] - raw);
            if (dist <= tolerance && dist < bestDist) {
                bestDist = dist;
                best = i;
            }
        }
        return best;
    };

    components.forEach(comp => {
        if (!comp.bounds) return;
        if (isExcluded(comp)) return;
        const { x, y, width, height } = comp.bounds;

        // X coordinates are not grouped, so exact lookup is fine
        const startColIndex = sortedX.indexOf(x);
        const endColIndex = sortedX.indexOf(x + width);

        // Y coordinates may have been snapped — use nearest-grouped lookup
        const startRowIndex = snapToGrouped(y, sortedY, rowTolerance);
        const endRowIndex = snapToGrouped(y + height, sortedY, rowTolerance);

        // Grid lines are 1-based.
        if (startColIndex !== -1 && endColIndex !== -1 && startRowIndex !== -1 && endRowIndex !== -1) {
            placements.set(comp.id, {
                gridColumnStart: startColIndex + 1,
                gridColumnEnd: endColIndex + 1,
                gridRowStart: startRowIndex + 1,
                gridRowEnd: endRowIndex + 1
            });
        }
    });

    return {
        rows: gridTemplateRows.trim(),
        columns: gridTemplateColumns.trim(),
        placements,
        width: sortedX[sortedX.length - 1],
        height: sortedY[sortedY.length - 1]
    };
}
