/* eslint-disable */
/**
 * Definitions Editor Modal
 * Allows editing options for components that use schema.data.definitions
 * (Select, ComboBox, etc.)
 */

import React, { useState, useEffect } from 'react';
import type { FC } from 'react';
import { Box, Modal, ModalBody, ModalTitle, Button } from '../../../../seker-ui-lib';
import { TextField, IconButton } from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { useNova } from '../../../nova-core';
import type { NovaDataOption } from '../../../nova-core/types/nova-ui-schema.types';

export interface DefinitionsEditorModalProps {
    showModal: boolean;
    onClose: () => void;
    componentId: string;
}

interface OptionRow extends NovaDataOption {
    tempId: string; // For React keys
}

export const DefinitionsEditorModal: FC<DefinitionsEditorModalProps> = ({
    showModal,
    onClose,
    componentId
}) => {
    const { schema, loadSchema } = useNova();
    const [options, setOptions] = useState<OptionRow[]>([]);
    const [hasChanges, setHasChanges] = useState(false);

    // Load existing options when modal opens
    useEffect(() => {
        if (showModal && componentId && schema?.data?.definitions) {
            const definition = schema.data.definitions.find(def => def.id === componentId);
            if (definition && definition.options) {
                setOptions(definition.options.map((opt, idx) => ({
                    ...opt,
                    tempId: `opt_${idx}_${Date.now()}`
                })));
            } else {
                setOptions([]);
            }
        } else if (showModal) {
            // No definition exists yet - start with empty array
            setOptions([]);
        }
        setHasChanges(false);
    }, [showModal, componentId, schema]);

    const handleAddOption = () => {
        setOptions([...options, {
            value: '',
            text: '',
            tempId: `opt_new_${Date.now()}`
        }]);
        setHasChanges(true);
    };

    const handleDeleteOption = (tempId: string) => {
        setOptions(options.filter(opt => opt.tempId !== tempId));
        setHasChanges(true);
    };

    const handleOptionChange = (tempId: string, field: 'value' | 'text', newValue: string) => {
        setOptions(options.map(opt =>
            opt.tempId === tempId ? { ...opt, [field]: newValue } : opt
        ));
        setHasChanges(true);
    };

    const handleSave = () => {
        if (!schema) return;

        // Clean up options - remove tempId
        const cleanedOptions: NovaDataOption[] = options.map(({ tempId, ...opt }) => opt);

        // Update or create definition using componentId
        const updatedDefinitions = schema.data?.definitions || [];
        const existingDefIndex = updatedDefinitions.findIndex(def => def.id === componentId);

        if (existingDefIndex >= 0) {
            // Update existing definition
            updatedDefinitions[existingDefIndex] = {
                ...updatedDefinitions[existingDefIndex],
                options: cleanedOptions
            };
        } else {
            // Create new definition
            updatedDefinitions.push({
                id: componentId,
                options: cleanedOptions
            });
        }

        // Update schema
        loadSchema({
            ...schema,
            data: {
                ...schema.data,
                var: schema.data?.var || [],
                definitions: updatedDefinitions
            }
        });

        setHasChanges(false);
        onClose();
    };

    const handleCancel = () => {
        setHasChanges(false);
        onClose();
    };

    return (
        <Modal show={showModal} onClose={handleCancel} maxWidth="md">
            <ModalTitle>Edit Options - {componentId}</ModalTitle>
            <ModalBody>
                <Box sx={{ minHeight: 300, maxHeight: 500, overflow: 'auto', p:4 }}>
                    {/* Header Row */}
                    <Box sx={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr 60px',
                        gap: 2,
                        mb: 2,
                        pb: 1,
                        borderBottom: '2px solid #ddd',
                        fontWeight: 'bold'
                    }}>
                        <div>Value (Key)</div>
                        <div>Text (Display)</div>
                        <div>Actions</div>
                    </Box>

                    {/* Options Rows */}
                    {options.map((option) => (
                        <Box
                            key={option.tempId}
                            sx={{
                                display: 'grid',
                                gridTemplateColumns: '1fr 1fr 60px',
                                gap: 2,
                                mb: 2,
                                alignItems: 'center'
                            }}
                        >
                            <TextField
                                value={option.value}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                                    handleOptionChange(option.tempId, 'value', e.target.value)
                                }
                                placeholder="Value"
                                size="small"
                                fullWidth
                            />
                            <TextField
                                value={option.text}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                                    handleOptionChange(option.tempId, 'text', e.target.value)
                                }
                                placeholder="Text"
                                size="small"
                                fullWidth
                            />
                            <IconButton
                                onClick={() => handleDeleteOption(option.tempId)}
                                color="error"
                                size="small"
                            >
                                <DeleteIcon />
                            </IconButton>
                        </Box>
                    ))}

                    {/* Add Button */}
                    <Box sx={{ mt: 2 }}>
                        <Button
                            variant="outlined"
                            onClick={handleAddOption}
                            iconLeft={<AddIcon />}
                            text="Add Option"
                            size="small"
                        />
                    </Box>

                    {options.length === 0 && (
                        <Box sx={{
                            textAlign: 'center',
                            py: 4,
                            color: 'text.secondary',
                            fontStyle: 'italic'
                        }}>
                            No options defined. Click "Add Option" to create one.
                        </Box>
                    )}
                </Box>

                {/* Action Buttons */}
                <Box sx={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    gap: 2,
                    mt: 3,
                    p: 2,
                    borderTop: '1px solid #ddd'
                }}>
                    <Button
                        variant="outlined"
                        onClick={handleCancel}
                        text="Cancel"
                    />
                    <Button
                        variant="contained"
                        onClick={handleSave}
                        disabled={!hasChanges}
                        text="Save"
                    />
                </Box>
            </ModalBody>
        </Modal>
    );
};
