/* eslint-disable */
import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Box } from '@mui/material';
import type { ComponentBounds } from '../../nova-core/types';

interface GridLines {
    columns: number[];
    rows: number[];
}

interface ResizableWrapperProps {
    bounds: ComponentBounds;
    onBoundsChange: (newBounds: ComponentBounds) => void;
    gridLines?: GridLines;
    snapThreshold?: number;
    isSelected: boolean;
    children: React.ReactNode;
    onClick?: (e: React.MouseEvent) => void;
    onMouseEnter?: () => void;
    onMouseLeave?: () => void;
}

type ResizeHandle = 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

const HANDLE_SIZE = 8;
const DEFAULT_SNAP_THRESHOLD = 10;

/**
 * Snaps a value to the nearest grid line if within threshold
 */
const snapToGrid = (value: number, gridLines: number[], threshold: number): number => {
    if (gridLines.length === 0) return value;

    let closestLine = gridLines[0];
    let minDistance = Math.abs(value - closestLine);

    for (const line of gridLines) {
        const distance = Math.abs(value - line);
        if (distance < minDistance) {
            minDistance = distance;
            closestLine = line;
        }
    }

    return minDistance <= threshold ? closestLine : value;
};

/**
 * Get cursor style for resize handle
 */
const getCursor = (position: ResizeHandle): string => {
    switch (position) {
        case 'n':
        case 's':
            return 'ns-resize';
        case 'e':
        case 'w':
            return 'ew-resize';
        case 'ne':
        case 'sw':
            return 'nesw-resize';
        case 'nw':
        case 'se':
            return 'nwse-resize';
        default:
            return 'pointer';
    }
};

/**
 * Get style for resize handle based on position
 */
const getHandleStyle = (position: ResizeHandle): React.CSSProperties => {
    const base: React.CSSProperties = {
        position: 'absolute',
        width: HANDLE_SIZE,
        height: HANDLE_SIZE,
        backgroundColor: '#eb7a34',
        border: '1px solid white',
        borderRadius: '2px',
        cursor: getCursor(position),
        zIndex: 1001,
    };

    switch (position) {
        case 'n':
            return { ...base, top: -HANDLE_SIZE / 2, left: '50%', transform: 'translateX(-50%)' };
        case 's':
            return { ...base, bottom: -HANDLE_SIZE / 2, left: '50%', transform: 'translateX(-50%)' };
        case 'e':
            return { ...base, right: -HANDLE_SIZE / 2, top: '50%', transform: 'translateY(-50%)' };
        case 'w':
            return { ...base, left: -HANDLE_SIZE / 2, top: '50%', transform: 'translateY(-50%)' };
        case 'ne':
            return { ...base, top: -HANDLE_SIZE / 2, right: -HANDLE_SIZE / 2 };
        case 'nw':
            return { ...base, top: -HANDLE_SIZE / 2, left: -HANDLE_SIZE / 2 };
        case 'se':
            return { ...base, bottom: -HANDLE_SIZE / 2, right: -HANDLE_SIZE / 2 };
        case 'sw':
            return { ...base, bottom: -HANDLE_SIZE / 2, left: -HANDLE_SIZE / 2 };
        default:
            return base;
    }
};

const HANDLES: ResizeHandle[] = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'];

/**
 * ResizableWrapper - Wraps a component with drag-to-move and resize handles
 * Supports grid-aware snapping for precise positioning
 */
export const ResizableWrapper: React.FC<ResizableWrapperProps> = ({
    bounds,
    onBoundsChange,
    gridLines = { columns: [], rows: [] },
    snapThreshold = DEFAULT_SNAP_THRESHOLD,
    isSelected,
    children,
    onClick,
    onMouseEnter,
    onMouseLeave,
}) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [isResizing, setIsResizing] = useState(false);
    const [activeHandle, setActiveHandle] = useState<ResizeHandle | null>(null);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
    const [initialBounds, setInitialBounds] = useState<ComponentBounds>(bounds);

    // Handle mouse down for dragging (move)
    const handleDragStart = useCallback((e: React.MouseEvent) => {
        if (isResizing) return;
        e.stopPropagation();
        e.preventDefault();

        setIsDragging(true);
        setDragStart({ x: e.clientX, y: e.clientY });
        setInitialBounds(bounds);
    }, [bounds, isResizing]);

    // Handle mouse down for resizing
    const handleResizeStart = useCallback((e: React.MouseEvent, handle: ResizeHandle) => {
        e.stopPropagation();
        e.preventDefault();

        setIsResizing(true);
        setActiveHandle(handle);
        setDragStart({ x: e.clientX, y: e.clientY });
        setInitialBounds(bounds);
    }, [bounds]);

    // Handle mouse move for both drag and resize
    useEffect(() => {
        if (!isDragging && !isResizing) return;

        const handleMouseMove = (e: MouseEvent) => {
            const deltaX = e.clientX - dragStart.x;
            const deltaY = e.clientY - dragStart.y;

            let newBounds = { ...initialBounds };

            if (isDragging) {
                // Moving the component
                newBounds.x = snapToGrid(initialBounds.x + deltaX, gridLines.columns, snapThreshold);
                newBounds.y = snapToGrid(initialBounds.y + deltaY, gridLines.rows, snapThreshold);
            } else if (isResizing && activeHandle) {
                // Resizing based on handle
                switch (activeHandle) {
                    case 'e':
                        newBounds.width = Math.max(20, initialBounds.width + deltaX);
                        newBounds.width = snapToGrid(initialBounds.x + newBounds.width, gridLines.columns, snapThreshold) - newBounds.x;
                        break;
                    case 'w':
                        const newX = snapToGrid(initialBounds.x + deltaX, gridLines.columns, snapThreshold);
                        newBounds.width = Math.max(20, initialBounds.width - (newX - initialBounds.x));
                        newBounds.x = newX;
                        break;
                    case 's':
                        newBounds.height = Math.max(20, initialBounds.height + deltaY);
                        newBounds.height = snapToGrid(initialBounds.y + newBounds.height, gridLines.rows, snapThreshold) - newBounds.y;
                        break;
                    case 'n':
                        const newY = snapToGrid(initialBounds.y + deltaY, gridLines.rows, snapThreshold);
                        newBounds.height = Math.max(20, initialBounds.height - (newY - initialBounds.y));
                        newBounds.y = newY;
                        break;
                    case 'se':
                        newBounds.width = Math.max(20, initialBounds.width + deltaX);
                        newBounds.height = Math.max(20, initialBounds.height + deltaY);
                        newBounds.width = snapToGrid(initialBounds.x + newBounds.width, gridLines.columns, snapThreshold) - newBounds.x;
                        newBounds.height = snapToGrid(initialBounds.y + newBounds.height, gridLines.rows, snapThreshold) - newBounds.y;
                        break;
                    case 'sw':
                        const newXSw = snapToGrid(initialBounds.x + deltaX, gridLines.columns, snapThreshold);
                        newBounds.width = Math.max(20, initialBounds.width - (newXSw - initialBounds.x));
                        newBounds.x = newXSw;
                        newBounds.height = Math.max(20, initialBounds.height + deltaY);
                        newBounds.height = snapToGrid(initialBounds.y + newBounds.height, gridLines.rows, snapThreshold) - newBounds.y;
                        break;
                    case 'ne':
                        newBounds.width = Math.max(20, initialBounds.width + deltaX);
                        newBounds.width = snapToGrid(initialBounds.x + newBounds.width, gridLines.columns, snapThreshold) - newBounds.x;
                        const newYNe = snapToGrid(initialBounds.y + deltaY, gridLines.rows, snapThreshold);
                        newBounds.height = Math.max(20, initialBounds.height - (newYNe - initialBounds.y));
                        newBounds.y = newYNe;
                        break;
                    case 'nw':
                        const newXNw = snapToGrid(initialBounds.x + deltaX, gridLines.columns, snapThreshold);
                        newBounds.width = Math.max(20, initialBounds.width - (newXNw - initialBounds.x));
                        newBounds.x = newXNw;
                        const newYNw = snapToGrid(initialBounds.y + deltaY, gridLines.rows, snapThreshold);
                        newBounds.height = Math.max(20, initialBounds.height - (newYNw - initialBounds.y));
                        newBounds.y = newYNw;
                        break;
                }
            }

            onBoundsChange(newBounds);
        };

        const handleMouseUp = () => {
            setIsDragging(false);
            setIsResizing(false);
            setActiveHandle(null);
        };

        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);

        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, isResizing, activeHandle, dragStart, initialBounds, gridLines, snapThreshold, onBoundsChange]);

    return (
        <Box
            ref={containerRef}
            onClick={onClick}
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
            sx={{
                position: 'absolute',
                left: bounds.x,
                top: bounds.y,
                width: bounds.width,
                height: bounds.height,
                cursor: isDragging ? 'grabbing' : 'grab',
                border: isSelected ? '2px solid #eb7a34' : '1px solid transparent',
                boxSizing: 'border-box',
                '&:hover': {
                    border: isSelected ? '2px solid #eb7a34' : '1px dashed #eb7a34',
                },
                transition: isDragging || isResizing ? 'none' : 'border 0.2s',
            }}
        >
            {/* Drag handle overlay (entire component) */}
            <Box
                onMouseDown={handleDragStart}
                sx={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    zIndex: 1000,
                    cursor: isDragging ? 'grabbing' : 'grab',
                }}
            />

            {/* Resize handles - only show when selected */}
            {isSelected && HANDLES.map((handle) => (
                <div
                    key={handle}
                    onMouseDown={(e) => handleResizeStart(e, handle)}
                    style={getHandleStyle(handle)}
                />
            ))}

            {/* Actual component content */}
            <Box
                sx={{
                    width: '100%',
                    height: '100%',
                    overflow: 'hidden',
                    pointerEvents: 'none',
                }}
            >
                {children}
            </Box>

            {/* Bounds info tooltip when dragging/resizing */}
            {(isDragging || isResizing) && (
                <Box
                    sx={{
                        position: 'absolute',
                        top: -24,
                        left: 0,
                        backgroundColor: '#eb7a34',
                        color: 'white',
                        fontSize: '10px',
                        padding: '2px 6px',
                        borderRadius: '4px',
                        whiteSpace: 'nowrap',
                        zIndex: 1002,
                    }}
                >
                    {bounds.x}, {bounds.y} - {bounds.width}×{bounds.height}
                </Box>
            )}
        </Box>
    );
};

export default ResizableWrapper;
