/* eslint-disable */
import React, { useState, useRef, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Toolbar } from './components/Toolbar';
import { DesignArea } from './components/DesignArea';
import { PropertiesPanel } from './components/PropertiesPanel';
import { JsonEditor } from './components/Editors/JsonEditor';
import { JavascriptEditor } from './components/Editors/JavascriptEditor';
import { CssEditor } from './components/Editors/CssEditor';
import { ActionDesigner } from './components/Designers/ActionDesigner';
import { RuleDesigner } from './components/Designers/RuleDesigner';
import { DataDesigner } from './components/Designers/DataDesigner';
import { EngineDebugPanel } from '../nova-core/components/EngineDebugPanel';
import { NovaProvider, useNova } from '../nova-core/context/NovaContext';
import { LogCenterProvider } from '../nova-core/context/LogCenterContext';
import { GridProvider } from './context/GridContext';
import { parseEbml } from '../nova-core/nova-ebml/nova-ebml-parser';
import { convertNovaEbmlToNovaUiSchema } from '../nova-core/nova-ebml/nova-ebml-converter';
import {
    Box, AppBar, Tabs, Tab, Stack, Typography, Snackbar, Alert
} from '@mui/material';

import PreviewIcon from '@mui/icons-material/Preview';
import EditIcon from '@mui/icons-material/Edit';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '../../seker-ui-lib';

const DesignerContent: React.FC = () => {
    const [activeTab, setActiveTab] = useState(0);
    const { mode, setMode, exportDesign, importDesign, clearDesign } = useNova();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const location = useLocation();
    const navigate = useNavigate();
    const hasImportedFromState = useRef(false);

    // Snackbar state for import feedback
    const [snackbar, setSnackbar] = useState<{
        open: boolean;
        message: string;
        severity: 'success' | 'error' | 'info';
    }>({ open: false, message: '', severity: 'info' });

    const showSnackbar = (message: string, severity: 'success' | 'error' | 'info') => {
        setSnackbar({ open: true, message, severity });
    };

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({ ...prev, open: false }));
    };

    const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
        setActiveTab(newValue);
    };

    const handleExport = () => {
        const json = exportDesign();
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `design-${new Date().toISOString()}.json`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const fileName = file.name.toLowerCase();
        const isEbml = fileName.endsWith('.ebml') || fileName.endsWith('.xml');

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                let content: string;

                if (isEbml) {
                    // For EBML files, use ArrayBuffer with encoding detection (UTF-8 or ISO-8859-9)
                    const buffer = e.target?.result as ArrayBuffer;
                    if (!buffer) return;

                    // Try UTF-8 first (most common), then fall back to ISO-8859-9 (Turkish)
                    try {
                        const utf8Decoder = new TextDecoder('utf-8', { fatal: true });
                        content = utf8Decoder.decode(buffer);
                    } catch {
                        // If UTF-8 fails, try ISO-8859-9 (Turkish encoding)
                        const isoDecoder = new TextDecoder('iso-8859-9');
                        content = isoDecoder.decode(buffer);
                    }

                    // Parse EBML file and convert to NovaUiSchema
                    const novaEbml = parseEbml(content);
                    const novaSchema = convertNovaEbmlToNovaUiSchema(novaEbml);
                    const jsonStr = JSON.stringify(novaSchema, null, 2);
                    importDesign(jsonStr);
                    showSnackbar(`EBML file "${file.name}" imported successfully`, 'success');
                } else {
                    // JSON file - read as text and import directly
                    content = e.target?.result as string;
                    if (!content) return;
                    importDesign(content);
                    showSnackbar(`JSON file "${file.name}" imported successfully`, 'success');
                }
            } catch (error) {
                console.error('Import error:', error);
                const errorMessage = error instanceof Error ? error.message : 'Unknown error';
                showSnackbar(`Failed to import file: ${errorMessage}`, 'error');
            }
        };
        reader.onerror = () => {
            showSnackbar('Failed to read file', 'error');
        };

        // Use ArrayBuffer for EBML (for encoding detection), Text for JSON
        if (isEbml) {
            reader.readAsArrayBuffer(file);
        } else {
            reader.readAsText(file);
        }
        // Reset input
        event.target.value = '';
    };

    useEffect(() => {
        const importedDesign = (location.state as { importedDesign?: string } | null)?.importedDesign;
        if (!hasImportedFromState.current && importedDesign) {
            importDesign(importedDesign);
            setMode('design');
            hasImportedFromState.current = true;
            navigate(location.pathname, { replace: true });
        }
    }, [location, importDesign, setMode, navigate]);

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
            {/* Header / Tabs */}
            <AppBar position="static" color="default" elevation={1} sx={{ zIndex: 1201 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', px: 2 }}>
                    <Typography variant="h6" sx={{ mr: 4 }}>UI Designer</Typography>
                    <Tabs value={activeTab} onChange={handleTabChange} sx={{ flexGrow: 1 }}>
                        <Tab label="Visual Designer" />
                        <Tab label="Schema (JSON)"  />
                        <Tab label="JS Code" />
                        <Tab label="CSS Code" />
                        <Tab label="Action Designer" />
                        <Tab label="Rule Designer" />
                        <Tab label="Data Designer" />
                         
                    </Tabs>
                    <Stack direction="row" spacing={1}>
                        <input
                            type="file"
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                            accept=".json,.ebml,.xml"
                            onChange={handleFileChange}
                        />
                        {mode === 'design' && <> <Button
                            iconRight={<DeleteSweepIcon />}
                            variant="outlined"
                            color="error"
                            onClick={() => {
                                if (window.confirm('Are you sure you want to clear the current design? This action cannot be undone.')) {
                                    clearDesign();
                                }
                            }}
                            text="Clear"
                        />
                       <Button
                            iconRight={<FileUploadIcon />}
                            variant="outlined"
                            onClick={handleImportClick}
                            text="Import"
                        />
                        <Button
                            iconRight={<FileDownloadIcon />}
                            variant="outlined"
                            onClick={handleExport}
                            text="Export"
                        /></>}
                        {activeTab === 0 && (
                            <>
                            <EngineDebugPanel />
                                <Button
                                    iconRight={mode === 'design' ? <PreviewIcon /> : <EditIcon />}
                                    variant="outlined"
                                    onClick={() => setMode(mode === 'design' ? 'preview' : 'design')}
                                    text={mode === 'design' ? 'Preview' : 'Edit'}
                                />
                            </>
                        )}
                    </Stack>
                </Box>
            </AppBar>

            {/* Main Content */}
            <Box sx={{ flexGrow: 1, display: 'flex', overflow: 'hidden' }}>
                
                {/* Tab 0: Visual Designer */}
                {activeTab === 0 && (
                    <>
                        {/* Left: Toolbar (Only in Design Mode) */}
                        {mode === 'design' && (
                            <Box sx={{ width: 280, flexShrink: 0, bgcolor: 'background.paper', borderRight: 1, borderColor: 'divider' }}>
                                <Toolbar />
                            </Box>
                        )}

                        {/* Center: Design Area */}
                        <Box sx={{ flexGrow: 1, bgcolor: '#f0f2f5', overflow: 'hidden' }}>
                            <DesignArea />
                        </Box>

                        {/* Right: Properties (Only in Design Mode) */}
                        {mode === 'design' && (
                            <Box sx={{ width: 300, flexShrink: 0, bgcolor: 'background.paper', borderLeft: 1, borderColor: 'divider' }}>
                                <PropertiesPanel />
                            </Box>
                        )}
                    </>
                )}

                {/* Tab 1: JSON Editor */}
                {activeTab === 1 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <JsonEditor />
                    </Box>
                )}

                {/* Tab 2: JS Editor */}
                {activeTab === 2 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <JavascriptEditor />
                    </Box>
                )}

                {/* Tab 3: CSS Editor */}
                {activeTab === 3 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <CssEditor />
                    </Box>
                )}

                {/* Tab 4: Action Designer */}
                {activeTab === 4 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <ActionDesigner />
                    </Box>
                )}

                {/* Tab 5: Rule Designer */}
                {activeTab === 5 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <RuleDesigner />
                    </Box>
                )}

                {/* Tab 6: Data Designer */}
                {activeTab === 6 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <DataDesigner />
                    </Box>
                )}
            </Box>

            {/* Import Feedback Snackbar */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={4000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Box>
    );
};

export const DesignerPage: React.FC = () => {
    return (
        <LogCenterProvider>
            <NovaProvider workingMode='design'>
                <GridProvider>
                    <DndProvider backend={HTML5Backend}>
                        <DesignerContent />
                    </DndProvider>
                </GridProvider>
            </NovaProvider>
        </LogCenterProvider>
    );
};

export default DesignerPage;

