/* eslint-disable */
import { createSchema } from './schema';
import { commonProps } from './common';

export const DisplaySchemas = {
    Typography: createSchema('Typography', 'Display', [
        ...commonProps,
        { name: 'children', type: 'string', label: 'Content', group: 'Content' },
        { name: 'variant', type: 'select', label: 'Variant', options: ['h1','h2','h3','h4','h5','h6','subtitle1','subtitle2','body1','body2','button','caption','overline'] },
        { name: 'align', type: 'select', label: 'Align', options: ['inherit', 'left', 'center', 'right', 'justify'] },
        { name: 'color', type: 'string', label: 'Color' },
        { name: 'noWrap', type: 'boolean', label: 'No Wrap' },
        { name: 'paragraph', type: 'boolean', label: 'Paragraph' },
        { name: 'gutterBottom', type: 'boolean', label: 'Gutter Bottom' },
    ]),

    Label: createSchema('Label', 'Display', [
        ...commonProps,
        { name: 'text', type: 'string', label: 'Content', group: 'Content' },
        { name: 'required', type: 'boolean', label: 'Required' },
        { name: 'color', type: 'string', label: 'Color' },
    ]),

    Alert: createSchema('Alert', 'Display', [
        ...commonProps,
        { name: 'severity', type: 'select', label: 'Severity', options: ['error', 'warning', 'info', 'success'] },
        { name: 'variant', type: 'select', label: 'Variant', options: ['standard', 'filled', 'outlined'] },
        { name: 'children', type: 'string', label: 'Content', group: 'Content' },
        { name: 'title', type: 'string', label: 'Title' },
    ]),

    Chip: createSchema('Chip', 'Display', [
        ...commonProps,
        { name: 'label', type: 'string', label: 'Label' },
        { name: 'variant', type: 'select', label: 'Variant', options: ['filled', 'outlined'] },
        { name: 'color', type: 'select', label: 'Color', options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'] },
        { name: 'size', type: 'select', label: 'Size', options: ['small', 'medium'] },
        { name: 'clickable', type: 'boolean', label: 'Clickable' },
        { name: 'onDelete', type: 'boolean', label: 'Has Delete Handler' }, // Boolean trigger to show delete icon, technically needs function
    ]),

    Accordion: createSchema('Accordion', 'Display', [
        ...commonProps,
        { name: 'title', type: 'string', label: 'Title' },
        { name: 'defaultExpanded', type: 'boolean', label: 'Default Expanded' },
        { name: 'disabled', type: 'boolean', label: 'Disabled' },
        { name: 'children', type: 'string', label: 'Content' },
    ]),

    Breadcrumbs: createSchema('Breadcrumbs', 'Display', [
        ...commonProps,
        { name: 'separator', type: 'string', label: 'Separator' },
        { name: 'maxItems', type: 'number', label: 'Max Items' },
        { name: 'items', type: 'json', label: 'Items (JSON)', defaultValue: [] }, // For dynamic breadcrumbs
    ]),

    Carousel: createSchema('Carousel', 'Display', [
        ...commonProps,
        { name: 'autoPlay', type: 'boolean', label: 'Auto Play', defaultValue: true },
        { name: 'interval', type: 'number', label: 'Interval (ms)', defaultValue: 4000 },
        { name: 'animation', type: 'select', label: 'Animation', options: ['fade', 'slide'] },
        { name: 'indicators', type: 'boolean', label: 'Indicators' },
        { name: 'navButtonsAlwaysVisible', type: 'boolean', label: 'Nav Buttons Always Visible' },
    ]),

    Collapse: createSchema('Collapse', 'Display', [
        ...commonProps,
        { name: 'in', type: 'boolean', label: 'Open', defaultValue: true },
        { name: 'orientation', type: 'select', label: 'Orientation', options: ['vertical', 'horizontal'] },
    ]),

    ConfirmModal: createSchema('ConfirmModal', 'Display', [
        ...commonProps,
        { name: 'title', type: 'string', label: 'Title' },
        { name: 'content', type: 'string', label: 'Content' },
        { name: 'open', type: 'boolean', label: 'Open' },
        { name: 'confirmText', type: 'string', label: 'Confirm Text' },
        { name: 'cancelText', type: 'string', label: 'Cancel Text' },
    ]),

    CustomScrollbar: createSchema('CustomScrollbar', 'Display', [
        ...commonProps,
        { name: 'autoHide', type: 'boolean', label: 'Auto Hide' },
        { name: 'style', type: 'json', label: 'Style' },
    ]),

    DataGrid: createSchema('DataGrid', 'Display', [
        ...commonProps,
        { name: 'columns', type: 'json', label: 'Columns (JSON)', defaultValue: [] },
        { name: 'rows', type: 'json', label: 'Rows (JSON)', defaultValue: [] },
        { name: 'checkboxSelection', type: 'boolean', label: 'Checkbox Selection' },
        { name: 'disableSelectionOnClick', type: 'boolean', label: 'Disable Selection On Click' },
        { name: 'pageSize', type: 'number', label: 'Page Size' },
        { name: 'autoHeight', type: 'boolean', label: 'Auto Height' },
    ]),

    Empty: createSchema('Empty', 'Display', [
        ...commonProps,
        { name: 'title', type: 'string', label: 'Title' },
        { name: 'description', type: 'string', label: 'Description' },
        { name: 'image', type: 'string', label: 'Image URL' },
    ]),

    KeyValueList: createSchema('KeyValueList', 'Display', [
        ...commonProps,
        { name: 'data', type: 'json', label: 'Data (JSON)', defaultValue: [] },
        { name: 'divider', type: 'boolean', label: 'Divider' },
        { name: 'labelWidth', type: 'string', label: 'Label Width' },
    ]),

    LoadingModal: createSchema('LoadingModal', 'Display', [
        ...commonProps,
        { name: 'open', type: 'boolean', label: 'Open' },
        { name: 'message', type: 'string', label: 'Message' },
    ]),

    Modal: createSchema('Modal', 'Display', [
        ...commonProps,
        { name: 'open', type: 'boolean', label: 'Open' },
        { name: 'title', type: 'string', label: 'Title' },
        { name: 'size', type: 'select', label: 'Size', options: ['xs', 'sm', 'md', 'lg', 'xl'] },
        { name: 'fullWidth', type: 'boolean', label: 'Full Width' },
        { name: 'scroll', type: 'select', label: 'Scroll', options: ['paper', 'body'] },
    ]),

    Nav: createSchema('Nav', 'Display', [
        ...commonProps,
        { name: 'title', type: 'string', label: 'Title', defaultValue: 'Navigation Title' },
        { name: 'navTitleProps', type: 'object', label: 'Nav Title Props (Advanced)', defaultValue: { title: 'Navigation Title' } },
        { name: 'orientation', type: 'select', label: 'Orientation', options: ['vertical', 'horizontal'] },
        { name: 'collapsed', type: 'boolean', label: 'Collapsed' },
    ]),

    NumberFormat: createSchema('NumberFormat', 'Display', [
        ...commonProps,
        { name: 'value', type: 'number', label: 'Value' },
        { name: 'displayType', type: 'select', label: 'Display Type', options: ['text', 'input'], defaultValue: 'text' },
        { name: 'thousandSeparator', type: 'boolean', label: 'Thousand Separator' },
        { name: 'prefix', type: 'string', label: 'Prefix' },
        { name: 'suffix', type: 'string', label: 'Suffix' },
        { name: 'decimalScale', type: 'number', label: 'Decimal Scale' },
    ]),

    Pagination: createSchema('Pagination', 'Display', [
        ...commonProps,
        { name: 'count', type: 'number', label: 'Count' },
        { name: 'page', type: 'number', label: 'Page' },
        { name: 'variant', type: 'select', label: 'Variant', options: ['text', 'outlined'] },
        { name: 'shape', type: 'select', label: 'Shape', options: ['circular', 'rounded'] },
        { name: 'color', type: 'select', label: 'Color', options: ['standard', 'primary', 'secondary'] },
        { name: 'showFirstButton', type: 'boolean', label: 'Show First Button' },
        { name: 'showLastButton', type: 'boolean', label: 'Show Last Button' },
    ]),

    PdfViewer: createSchema('PdfViewer', 'Display', [
        ...commonProps,
        { name: 'file', type: 'string', label: 'File URL' },
        { name: 'height', type: 'string', label: 'Height' },
    ]),

    Popup: createSchema('Popup', 'Display', [
        ...commonProps,
        { name: 'open', type: 'boolean', label: 'Open' },
        { name: 'content', type: 'string', label: 'Content' },
        { name: 'title', type: 'string', label: 'Title' },
        { name: 'placement', type: 'select', label: 'Placement', options: ['top', 'bottom', 'left', 'right'] },
    ]),

    Progress: createSchema('Progress', 'Display', [
        ...commonProps,
        { name: 'value', type: 'number', label: 'Value' },
        { name: 'variant', type: 'select', label: 'Variant', options: ['determinate', 'indeterminate', 'buffer', 'query'] },
        { name: 'color', type: 'select', label: 'Color', options: ['primary', 'secondary', 'inherit'] },
        { name: 'size', type: 'number', label: 'Size' }, // For circular
        { name: 'thickness', type: 'number', label: 'Thickness' }, // For circular
    ]),

    Rating: createSchema('Rating', 'Display', [
        ...commonProps,
        { name: 'value', type: 'number', label: 'Value' },
        { name: 'max', type: 'number', label: 'Max' },
        { name: 'precision', type: 'number', label: 'Precision' },
        { name: 'readOnly', type: 'boolean', label: 'Read Only' },
        { name: 'size', type: 'select', label: 'Size', options: ['small', 'medium', 'large'] },
    ]),

    Stepper: createSchema('Stepper', 'Display', [
        ...commonProps,
        { name: 'activeStep', type: 'number', label: 'Active Step' },
        { name: 'orientation', type: 'select', label: 'Orientation', options: ['horizontal', 'vertical'] },
        { name: 'alternativeLabel', type: 'boolean', label: 'Alternative Label' },
    ]),

    Tab: createSchema('Tab', 'Display', [
        ...commonProps,
        { name: 'value', type: 'number', label: 'Value' },
        { name: 'variant', type: 'select', label: 'Variant', options: ['standard', 'scrollable', 'fullWidth'] },
        { name: 'indicatorColor', type: 'select', label: 'Indicator Color', options: ['secondary', 'primary'] },
        { name: 'textColor', type: 'select', label: 'Text Color', options: ['secondary', 'primary', 'inherit'] },
        { name: 'centered', type: 'boolean', label: 'Centered' },
    ]),

    Table: createSchema('Table', 'Display', [
        ...commonProps,
        { name: 'size', type: 'select', label: 'Size', options: ['small', 'medium'] },
        { name: 'stickyHeader', type: 'boolean', label: 'Sticky Header' },
        { name: 'padding', type: 'select', label: 'Padding', options: ['normal', 'checkbox', 'none'] },
    ]),

    Tooltip: createSchema('Tooltip', 'Display', [
        ...commonProps,
        { name: 'title', type: 'string', label: 'Title' },
        { name: 'placement', type: 'select', label: 'Placement', options: ['bottom-end', 'bottom-start', 'bottom', 'left-end', 'left-start', 'left', 'right-end', 'right-start', 'right', 'top-end', 'top-start', 'top'] },
        { name: 'arrow', type: 'boolean', label: 'Arrow' },
    ]),

    TreeView: createSchema('TreeView', 'Display', [
        ...commonProps,
        { name: 'items', type: 'json', label: 'Items (JSON)', defaultValue: [] },
        { name: 'multiSelect', type: 'boolean', label: 'Multi Select' },
        { name: 'defaultExpandIcon', type: 'string', label: 'Expand Icon' }, // Simplified
        { name: 'defaultCollapseIcon', type: 'string', label: 'Collapse Icon' },
    ]),

    View: createSchema('View', 'Display', [
        ...commonProps,
        { name: 'condition', type: 'boolean', label: 'Condition' },
    ]),

    VRKeyboard: createSchema('VRKeyboard', 'Display', [
        ...commonProps,
        { name: 'layout', type: 'select', label: 'Layout', options: ['default', 'numeric'] },
        { name: 'inputName', type: 'string', label: 'Input Name' },
    ]),

    BarChart: createSchema('BarChart', 'Display', [
        ...commonProps,
        { name: 'data', type: 'json', label: 'Data (JSON)', defaultValue: [] },
        { name: 'width', type: 'number', label: 'Width' },
        { name: 'height', type: 'number', label: 'Height' },
    ]),

    PieChart: createSchema('PieChart', 'Display', [
        ...commonProps,
        { name: 'data', type: 'json', label: 'Data (JSON)', defaultValue: [] },
        { name: 'width', type: 'number', label: 'Width' },
        { name: 'height', type: 'number', label: 'Height' },
    ]),

    LineChart: createSchema('LineChart', 'Display', [
        ...commonProps,
        { name: 'data', type: 'json', label: 'Data (JSON)', defaultValue: [] },
        { name: 'width', type: 'number', label: 'Width' },
        { name: 'height', type: 'number', label: 'Height' },
    ]),

    TableComponent: createSchema('TableComponent', 'Display', [
        ...commonProps,
        { name: 'minHeight', type: 'number', label: 'Min Height (px)', group: 'Layout', defaultValue: 400 },
        { name: 'maxHeight', type: 'number', label: 'Max Height (px)', group: 'Layout' },
        { name: 'stickyHeader', type: 'boolean', label: 'Sticky Header', group: 'Behavior', defaultValue: true },
        { name: 'size', type: 'select', label: 'Size', group: 'Style', options: ['small', 'medium'], defaultValue: 'small' },
        { name: 'padding', type: 'select', label: 'Padding', group: 'Style', options: ['normal', 'checkbox', 'none'], defaultValue: 'normal' },
        { name: 'striped', type: 'boolean', label: 'Striped Rows', group: 'Style' },
        { name: 'bordered', type: 'boolean', label: 'Bordered', group: 'Style' },
        { name: 'hover', type: 'boolean', label: 'Hover Effect', group: 'Style', defaultValue: true },
        { name: 'columns', type: 'json', label: 'Columns (JSON)', group: 'Data', defaultValue: [] },
        { name: 'rows', type: 'json', label: 'Rows (JSON)', group: 'Data', defaultValue: [] },
        { name: 'sortable', type: 'boolean', label: 'Sortable', group: 'Behavior' },
        { name: 'selectable', type: 'boolean', label: 'Selectable Rows', group: 'Behavior' },
        { name: 'pagination', type: 'boolean', label: 'Pagination', group: 'Behavior' },
        { name: 'rowsPerPage', type: 'number', label: 'Rows Per Page', group: 'Behavior', defaultValue: 10 },
    ]),
};
