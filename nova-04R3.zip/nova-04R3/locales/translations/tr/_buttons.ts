export default {
    backHomePage: 'Ana Sayfaya Dön',
    backMenuList: '$t(pageTitles:menuList)ne Dön',
    close: 'Kapat',
    copy: 'Kopyala',
    exit: 'Çıkış',
    login: '$t(pageTitles:auth.login)',
    no: 'Hayır',
    open: 'Aç',
    openScreen: 'Ekranı $t(buttons:open)',
    reportError: 'Hata Bildir',
    yes: 'Evet',
};
