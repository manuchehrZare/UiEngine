export default {
    pageNotFound: 'Aradığınız ekran bulunmamaktadır.',
    welcome: 'Hoş Geldiniz',
};
