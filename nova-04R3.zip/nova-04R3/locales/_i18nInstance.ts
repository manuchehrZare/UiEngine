import { createInstance } from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import localeTR from './translations/tr';
import localeEN from './translations/en';
import { LocalesEnum, i18n as i18nSetUI } from '../set-lib';
import { constants } from '../utils/constants';
import { getLocalStorageItem, i18n as i18nSekerUI } from '../seker-ui-lib';
import { merge } from 'lodash';

export const languageStorageKey = constants.key.Shell_LANGUAGE;
export const defaultlocaleData = localeTR; // for keyPaths using

export const i18n = createInstance({
    debug: true,
    resources: merge(i18nSekerUI.options.resources, i18nSetUI.options.resources, {
        [LocalesEnum.TURKISH]: localeTR,
        [LocalesEnum.ENGLISH]: localeEN,
    }),
    lng: getLocalStorageItem<string>(languageStorageKey) || i18nSetUI.options.lng, // if defined, it triggers the defined language at every render instant
    fallbackLng: i18nSetUI.options.fallbackLng,
    interpolation: {
        escapeValue: false, // react already safes from xss => https://www.i18next.com/translation-function/interpolation#unescape
    },
    react: {
        useSuspense: false,
    },
});

export const i18nInit = async (): Promise<void> => {
    await i18n
        .use(new LanguageDetector(null, { lookupLocalStorage: languageStorageKey }))
        .use(initReactI18next)
        .init({}, () => {
            document.documentElement.setAttribute('lang', String(getLocalStorageItem<string>(languageStorageKey)));
        });
};
