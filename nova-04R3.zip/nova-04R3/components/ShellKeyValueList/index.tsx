import type { FC } from 'react';
import type { IKeyValueListProps } from '../../seker-ui-lib';
import { KeyValueList, importantStyle } from '../../seker-ui-lib';

interface IShellKeyValueListProps extends Pick<IKeyValueListProps, 'data' | 'wrap'> {}

const ShellKeyValueList: FC<IShellKeyValueListProps> = (props) => {
    return (
        <KeyValueList
            sx={{
                '.sekerUI-KeyValueList-item': {
                    p: importantStyle('0px'),
                    borderBottom: importantStyle('none'),

                    '.sekerUI-Switch-formControl': {
                        '&.switch-labelPlacement-end': {
                            '.sekerUI-Switch-label': {
                                ml: importantStyle('auto'),
                            },
                        },
                    },
                },
            }}
            {...props}
        />
    );
};

export default ShellKeyValueList;
