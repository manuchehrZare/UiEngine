declare module '*.svg' {
    import type * as React from 'react';
    export const ReactComponent: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
    const src: string;
    export default src;
}

declare module '@fontsource/*' {}
declare module 'eslint-plugin-import';
declare module 'mutation-observer';
declare module 'intersection-observer';
declare module 'mq-polyfill';
declare module '*.pdf';
declare module '*.wav';
