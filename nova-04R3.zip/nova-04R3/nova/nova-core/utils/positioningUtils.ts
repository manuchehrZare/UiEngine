/* eslint-disable */
/**
 * Positioning Utilities
 * Handles conversion of Windows Forms bounds to web CSS positioning
 */

import type { ComponentBounds } from '../types';
import type { SxProps, Theme } from '@mui/material';

const GRID_COLUMNS = 12;
const DEFAULT_PAGE_WIDTH = 960;

/**
 * Convert bounds to absolute positioning CSS styles
 * Used when useAbsolutePositioning = true
 */
export const boundsToAbsoluteStyle = (
    bounds: ComponentBounds,
    parentBounds?: ComponentBounds
): SxProps<Theme> => {
    // If parent bounds provided, calculate relative position
    const left = parentBounds ? bounds.x - parentBounds.x : bounds.x;
    const top = parentBounds ? bounds.y - parentBounds.y : bounds.y;

    return {
        position: 'absolute',
        left: `${left}px`,
        top: `${top}px`,
        width: `${bounds.width}px`,
        height: `${bounds.height}px`,
        boxSizing: 'border-box',
    };
};

/**
 * Convert bounds width to responsive grid columns
 * Used when useAbsolutePositioning = false (responsive mode)
 */
export const boundsToGridSize = (
    bounds: ComponentBounds,
    containerWidth: number = DEFAULT_PAGE_WIDTH,
    shouldFillRow: boolean = false,
): { xs: number; minHeight: number } => {
    const effectiveContainerWidth = Math.max(1, containerWidth);
    const ratio = bounds.width / effectiveContainerWidth;
    let columns = Math.round(ratio * GRID_COLUMNS);

    if (shouldFillRow) {
        columns = GRID_COLUMNS;
    }

    return {
        xs: Math.max(1, Math.min(GRID_COLUMNS, columns)),
        minHeight: bounds.height,
    };
};

/**
 * Get container style for absolute positioning mode
 * Containers need position: relative to contain absolutely positioned children
 */
export const getContainerStyle = (
    bounds: ComponentBounds,
    useAbsolutePositioning: boolean
): SxProps<Theme> => {
    if (useAbsolutePositioning) {
        return {
            position: 'relative',
            width: `${bounds.width}px`,
            height: `${bounds.height}px`,
            minHeight: `${bounds.height}px`,
            overflow: 'visible',
        };
    }

    // Responsive mode - use full width
    return {
        width: '100%',
        minHeight: bounds.height > 0 ? `${bounds.height}px` : 'auto',
    };
};

/**
 * Get component style based on positioning mode
 * Main entry point for component styling
 */
export const getComponentStyle = (
    bounds: ComponentBounds,
    useAbsolutePositioning: boolean,
    parentBounds?: ComponentBounds,
    additionalStyles?: SxProps<Theme>
): SxProps<Theme> => {
    const baseStyle = useAbsolutePositioning
        ? boundsToAbsoluteStyle(bounds, parentBounds)
        : {};

    return {
        ...baseStyle,
        ...additionalStyles,
    } as SxProps<Theme>;
};

/**
 * Calculate the bounding box that contains all children
 * Useful for determining container dimensions
 */
export const calculateBoundingBox = (
    children: Array<{ bounds: ComponentBounds }>
): ComponentBounds => {
    if (!children || children.length === 0) {
        return { x: 0, y: 0, width: 0, height: 0 };
    }

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    children.forEach(child => {
        const { x, y, width, height } = child.bounds;
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x + width);
        maxY = Math.max(maxY, y + height);
    });

    return {
        x: minX,
        y: minY,
        width: maxX - minX,
        height: maxY - minY,
    };
};

/**
 * Normalize children positions relative to container
 * Converts absolute screen coordinates to relative container coordinates
 */
export const normalizeChildrenBounds = (
    children: Array<{ bounds: ComponentBounds }>,
    containerBounds: ComponentBounds
): void => {
    children.forEach(child => {
        child.bounds = {
            x: child.bounds.x - containerBounds.x,
            y: child.bounds.y - containerBounds.y,
            width: child.bounds.width,
            height: child.bounds.height,
        };
    });
};

/**
 * Sort components by visual position (top-to-bottom, left-to-right)
 * Used for tab order and accessibility
 */
export const sortByVisualPosition = <T extends { bounds: ComponentBounds }>(
    components: T[],
    rowTolerance: number = 10
): T[] => {
    return [...components].sort((a, b) => {
        // Group by row (Y position with tolerance)
        if (Math.abs(a.bounds.y - b.bounds.y) > rowTolerance) {
            return a.bounds.y - b.bounds.y;
        }
        // Within same row, sort by X position
        return a.bounds.x - b.bounds.x;
    });
};

/**
 * Group components into rows based on Y position, then sort by X position
 * Used for responsive layout rendering
 */
export const groupComponentsByRow = <T extends { bounds: ComponentBounds }>(
    components: T[],
    rowTolerance: number = 10
): T[][] => {
    // 1. Sort primarily by Y to establish vertical order
    const sortedByY = [...components].sort((a, b) => a.bounds.y - b.bounds.y);
    
    const rows: T[][] = [];
    let currentRow: T[] = [];
    let currentRowY: number | null = null;

    sortedByY.forEach(component => {
        if (currentRowY === null) {
            currentRowY = component.bounds.y;
            currentRow.push(component);
        } else {
            // Check if this component is on the same "row" (Y tolerance)
            if (Math.abs(component.bounds.y - currentRowY) <= rowTolerance) {
                currentRow.push(component);
            } else {
                // New row
                rows.push(currentRow);
                currentRow = [component];
                currentRowY = component.bounds.y;
            }
        }
    });

    if (currentRow.length > 0) {
        rows.push(currentRow);
    }

    // 2. For each row, sort by X to establish column order
    rows.forEach(row => {
        row.sort((a, b) => a.bounds.x - b.bounds.x);
    });

    return rows;
};

 /* Calculate optimal grid sizes for a row of components to fill available space
 */
export interface RowPlacement {
    xs: number;
    gap: number;
}

export const calculateRowGridSizes = (
    components: Array<{ bounds: ComponentBounds }>,
    containerWidth: number,
): Map<any, RowPlacement> => {
    const placements = new Map<any, RowPlacement>();
    if (!components || components.length === 0) {
        return placements;
    }

    const effectiveContainerWidth = Math.max(1, containerWidth || DEFAULT_PAGE_WIDTH);
    let consumedColumns = 0;

    const clampColumns = (value: number) => Math.max(0, Math.min(GRID_COLUMNS, value));

    components.forEach((component) => {
        const { x, width } = component.bounds;
        const startColumn = clampColumns(Math.round((x / effectiveContainerWidth) * GRID_COLUMNS));
        const widthColumns = Math.round((width / effectiveContainerWidth) * GRID_COLUMNS);
        let gap = 0;

        if (startColumn > consumedColumns) {
            gap = Math.min(startColumn - consumedColumns, GRID_COLUMNS - consumedColumns);
            consumedColumns += gap;
        }

        if (consumedColumns >= GRID_COLUMNS) {
            consumedColumns = 0;
            gap = Math.min(startColumn, GRID_COLUMNS);
            consumedColumns += gap;
        }

        const columnsLeft = GRID_COLUMNS - consumedColumns;
        let span = Math.max(1, Math.min(widthColumns, GRID_COLUMNS));

        if (columnsLeft <= 0) {
            span = GRID_COLUMNS;
            consumedColumns = GRID_COLUMNS;
        } else if (span > columnsLeft) {
            span = columnsLeft;
        }

        placements.set(component, { xs: span, gap });
        consumedColumns += span;
    });

    if (consumedColumns < GRID_COLUMNS) {
        const lastComponent = components[components.length - 1];
        const lastPlacement = placements.get(lastComponent);
        if (lastPlacement) {
            lastPlacement.xs += GRID_COLUMNS - consumedColumns;
            placements.set(lastComponent, lastPlacement);
        }
    }

    return placements;
};

export default {
    boundsToAbsoluteStyle,
    boundsToGridSize,
    getContainerStyle,
    getComponentStyle,
    calculateBoundingBox,
    normalizeChildrenBounds,
    sortByVisualPosition,
    groupComponentsByRow,
    calculateRowGridSizes,
};

/**
 * Helper interface to normalize different component structures (ParsedComponent vs DesignComponent)
 */
export interface LayoutComponent {
    id: string;
    bounds: ComponentBounds;
    children?: LayoutComponent[];
    original: any; // The original component object
}

/**
 * Normalize component structure to LayoutComponent for positioning calculations
 */
export const normalizeLayout = (component: any): LayoutComponent | null => {
    if (!component) return null;
    
    // Handle DesignComponent (bounds in props)
    if (component.props && component.props.bounds) {
        const children = component.children 
            ? component.children.map(normalizeLayout).filter((c: any) => c !== null) as LayoutComponent[]
            : [];

        return {
            id: component.id,
            bounds: component.props.bounds,
            children,
            original: component
        };
    }
    
    // Handle ParsedComponent (bounds at root)
    if (component.bounds) {
        const children = component.children 
            ? component.children.map(normalizeLayout).filter((c: any) => c !== null) as LayoutComponent[]
            : [];

         return {
            id: component.id,
            bounds: component.bounds,
            children,
            original: component
        };
    }
    
    return null;
};
