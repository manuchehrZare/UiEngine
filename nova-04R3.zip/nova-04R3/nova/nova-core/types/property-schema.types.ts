/* eslint-disable */
/**
 * Property Schema Type Definitions
 * Schema definitions for component properties
 */

/**
 * Property schema for a single component property
 */
export interface PropertySchema {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'select' | 'json' | 'array' | 'object' | 'keyvalue' | 'definitions';
    label?: string;
    options?: (string | number | { label: string; value: any })[];
    defaultValue?: any;
    description?: string;
    group?: string; // For grouping properties in the UI
    required?: boolean;
    keyLabel?: string; // For keyvalue type: label for key column
    valueLabel?: string; // For keyvalue type: label for value column
}

/**
 * Event schema for a component event
 */
export interface EventSchema {
    name: string; // Event name (e.g., 'onClick', 'onChange', 'onBlur')
    label?: string; // Display label for the event
    description?: string; // Description of when this event fires
}

/**
 * Component schema definition
 */
export interface ComponentSchema {
    name: string;
    category: string;
    properties: PropertySchema[];
    events?: EventSchema[]; // Available events for this component
    defaultProps?: Record<string, any>;
}

/**
 * Base properties common to all components
 */
export const BASE_PROPERTIES: PropertySchema[] = [
    { name: 'id', type: 'string', label: 'ID', group: 'General' },
    { name: 'className', type: 'string', label: 'Class Name', group: 'Style' },
    { name: 'sx', type: 'json', label: 'SX (MUI Style)', group: 'Style', defaultValue: {} },
];

/**
 * Helper to create simple schema
 */
export const createSchema = (
    name: string,
    category: string,
    specificProps: PropertySchema[] = [],
    defaultProps: Record<string, any> = {},
    events: EventSchema[] = []
): ComponentSchema => ({
    name,
    category,
    properties: [...BASE_PROPERTIES, ...specificProps],
    events: events.length > 0 ? events : undefined,
    defaultProps
});
