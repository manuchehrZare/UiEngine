/* eslint-disable */
/**
 * Nav Component Wrapper
 * Wraps the lib Nav component to handle EBML properties and provide
 * easier property editing in the designer
 */

import React from 'react';
import { Nav } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const NavComponent: React.FC<NovaComponentProps> = ({
    id,
    title,
    navTitleProps,
    children,
    ...props
}) => {
    // Support both direct title prop (easier for designer) and navTitleProps (proper API)
    const finalNavTitleProps = navTitleProps || (title ? { title } : undefined);

    return (
        <Nav
            navTitleProps={finalNavTitleProps}
            {...props}
        >
            {children}
        </Nav>
    );
};
