/* eslint-disable */
/**
 * NumberInput Component Wrapper
 * Wraps the lib NumberInput component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { NumberInput } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const NumberInputComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;

    // Ensure string properties are never undefined to prevent errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `numberinput_${Math.random().toString(36).substring(2, 11)}`;

    const safeProps = {
        ...props,
        label: label || '',
        name: safeName,
        value: value !== undefined ? value : null, // NumberInput expects null for empty, not undefined
        control: control as any,
    };

    return <NumberInput {...safeProps} />;
};
