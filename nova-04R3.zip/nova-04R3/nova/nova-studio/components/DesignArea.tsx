/* eslint-disable */
import React, { useMemo, useEffect } from 'react';
import { useDrop } from 'react-dnd';
import { FormProvider } from 'react-hook-form';
import useForm from '../../../seker-ui-lib/hooks/useForm';
import { ComponentRenderer } from './ComponentRenderer';
import { Box, Typography, Paper } from '@mui/material';
import { buildFormDefaultValues } from '../../nova-core/utils/formUtils';
import { PreviewRenderer } from './PreviewRenderer';
import { useNova } from '../../nova-core';

export const DesignArea: React.FC = () => {
    const { components, addComponent, selectComponent, moveComponent, mode } = useNova();

    // Build initial default values only once on mount or when component structure changes
    // Use component IDs as dependency to avoid recalculating on every prop change
    const componentIds = useMemo(() => {
        const extractIds = (comps: any[]): string => {
            return comps.map(c => `${c.id}:${c.type}${c.children ? ':' + extractIds(c.children) : ''}`).join(',');
        };
        return extractIds(components);
    }, [components]);

    const initialDefaultValues = useMemo(() => {
        return buildFormDefaultValues(components);
    }, [componentIds]); // Only recalculate when component structure (IDs) changes

    // Initialize form with initial default values
    const pageForm = useForm({
        defaultValues: initialDefaultValues,
        mode: 'onChange',
    });

    // Watch all form values and log changes
    // const formData = pageForm.watch();

    // useEffect(() => {
    //     console.log('📋 Form Data Changed:', formData);
    // }, [pageForm]);

    // Call all hooks before any conditional returns (Rules of Hooks)
    const [{ isOver }, drop] = useDrop({
        accept: ['COMPONENT', 'COMPONENT_INSTANCE'],
        drop: (item: any, monitor) => {
            if (monitor.didDrop()) return; // Already handled by a child

            if (item.id) {
                // Reordering (Dropped on empty space or root)
                 // If dropped on root area, maybe move to end of root list?
                 moveComponent(item.id, null, 'inside'); // 'root' is not a real ID, logic in Context needs to handle this case or we treat root special
                 // Actually Context `moveComponent` expects a valid hoverId. 
                 // We can't easily "move to root" with current logic if hoverId is required to find parent.
                 // Let's skip "move to root" via D&D for now unless we update context.
            } else {
                // New Component dropped on root
                addComponent(item.type, null);
            }
        },
        collect: (monitor) => ({
            isOver: monitor.isOver({ shallow: true }),
        }),
    });

    const handleBackgroundClick = () => {
        selectComponent(null);
    };

    // Conditional rendering AFTER all hooks have been called
    if (mode === 'preview' || mode === 'generator') {
        // In preview/generator mode, render without D&D wrappers
        return (
             <Box sx={{ bgcolor: '#f0f2f5', height: '100%', overflow: 'auto' }}>
                 <FormProvider {...pageForm}>
                    {components.map(comp => <PreviewRenderer key={comp.id} component={comp} />)}
                 </FormProvider>
             </Box>
        );
    }

    // Design mode - with D&D functionality
    return (
        <Box
            ref={drop}
            onClick={handleBackgroundClick}
            sx={{
                height: '100%',
                p: 4,
                backgroundColor: isOver ? '#e3f2fd' : '#f0f2f5',
                overflow: 'auto',
                transition: 'background-color 0.2s'
            }}
        >
            <Paper
                elevation={0}
                sx={{
                    minHeight: '100%',
                    p: 2,
                    backgroundColor: 'white',
                    border: '1px solid #e0e0e0',
                    backgroundImage: isOver
                    ? 'radial-gradient(#2196f3 1px, transparent 1px)'
                    : 'radial-gradient(#e0e0e0 1px, transparent 1px)',
                    backgroundSize: '20px 20px',

                }}
            >
                <FormProvider {...pageForm}>
                    {components.length === 0 ? (
                        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '300px', color: 'text.secondary' }}>
                            <Typography>Drag components here to start designing</Typography>
                        </Box>
                    ) : (
                        components.map(comp => (
                            <ComponentRenderer key={comp.id} component={comp} />
                        ))
                    )}
                </FormProvider>
            </Paper>
        </Box>
    );
};

