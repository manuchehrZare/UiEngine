/* eslint-disable */
import React, { useState } from 'react';
import { Box, useForm, Button, Input, Select, Paper, Chip, Typography } from '../../../../seker-ui-lib';
import {
    List, ListItem, ListItemText, IconButton, Stack,
    ToggleButtonGroup, ToggleButton, Accordion, AccordionSummary, AccordionDetails
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CodeIcon from '@mui/icons-material/Code';
import ViewListIcon from '@mui/icons-material/ViewList';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { v4 as uuidv4 } from 'uuid';
import Editor from '@monaco-editor/react';
import { SubActionEditor } from './SubActionEditor';
import { useNova, type Action, type SubAction } from '../../../nova-core';
import type { NovaEventActionStep } from '../../../nova-core/types/nova-ui-schema.types';

interface ActionFormValues {
    name: string;
    rule: string;
}

export const ActionDesigner: React.FC = () => {
    const { actions: allActions = [], addAction, updateAction, deleteAction, rules = [] } = useNova();
    // Filter to show only actions with type 'action' (not event bindings)
    const actions = allActions.filter(action => action.type === 'action');
    const [selectedAction, setSelectedAction] = useState<Action | null>(null);
    const [isCreating, setIsCreating] = useState(false);
    const [viewMode, setViewMode] = useState<'visual' | 'json'>('visual');
    const [subActionDialogOpen, setSubActionDialogOpen] = useState(false);
    const [editingSubAction, setEditingSubAction] = useState<{ subAction: SubAction | null; index: number | null } | null>(null);
    const [actionSteps, setActionSteps] = useState<NovaEventActionStep[]>([]);

    const { control, handleSubmit, reset, setValue } = useForm<ActionFormValues>({
        defaultValues: {
            name: '',
            rule: ''
        }
    });

    const handleSelectAction = (action: Action) => {
        setSelectedAction(action);
        setIsCreating(false);
        setValue('name', action.name);
        setValue('rule', action.rule || '');
        // Prefer actions over subActions to preserve data
        setActionSteps(action.actions || []);
    };

    const handleNewAction = () => {
        setSelectedAction(null);
        setIsCreating(true);
        reset();
        setActionSteps([]);
    };

    const handleCancelEdit = () => {
        setSelectedAction(null);
        setIsCreating(false);
        reset();
        setActionSteps([]);
    };

    const onSubmit = (data: ActionFormValues) => {
        if (!data.name) {
            alert('Please enter an action name');
            return;
        }

        const actionData: Partial<Action> = {
            name: data.name,
            rule: data.rule || undefined,
            actions: actionSteps,
            // Keep subActions for backward compatibility (empty array)
            subActions: []
        };

        if (selectedAction) {
            updateAction(selectedAction.id, actionData);
        } else {
            addAction({
                id: uuidv4(),
                type: 'action',
                ...actionData
            } as Action);
        }
        handleCancelEdit();
    };

    const handleDelete = (id: string) => {
        if (window.confirm('Are you sure you want to delete this action?')) {
            deleteAction(id);
        }
    };

    const handleOpenSubActionDialog = (actionStep?: NovaEventActionStep, index?: number) => {
        // Convert NovaEventActionStep back to SubAction for editing
        const subAction = actionStep ? convertActionStepToSubAction(actionStep) : null;
        setEditingSubAction({
            subAction: subAction,
            index: index !== undefined ? index : null
        });
        setSubActionDialogOpen(true);
    };

    // Helper to convert NovaEventActionStep back to SubAction for editing
    const convertActionStepToSubAction = (step: NovaEventActionStep): SubAction => {
        const baseId = uuidv4();

        switch (step.type) {
            case 'BeanAction':
                return {
                    id: baseId,
                    type: 'BeanAction',
                    beanValue: step.action.targetId,
                    method: step.action.method,
                    parameters: [{
                        name: step.action.property || 'value',
                        value: step.action.value?.toString() || step.action.sourceVar || '',
                        valueType: step.action.sourceVar ? 'variable' : 'constant'
                    }]
                };
            case 'RemoteCall':
                // Handle flat array with type field
                return {
                    id: baseId,
                    type: 'RemoteCall',
                    service: step.call.serviceName,
                    inputs: (step.call.inputs || []).map(p => ({
                        bagKey: p.name,
                        value: p.type === 'var' ? (p.var || p.name) : p.text,
                        valueType: p.type === 'var' ? 'variable' : 'constant'
                    })),
                    outputs: (step.call.outputs || []).map(o => ({
                        bagKey: o.name,
                        targetVariable: o.var || o.name,
                        targetType: o.type === 'var' ? 'variable' : 'component'
                    }))
                };
            case 'ReferenceCall':
                return {
                    id: baseId,
                    type: 'ReferenceCall',
                    referencedAction: step.reference
                };
            case 'VariableSetting':
                return {
                    id: baseId,
                    type: 'VariableSetting',
                    variableName: step.setting.variableId,
                    variableValue: step.setting.value?.toString() || step.setting.sourceComp?.componentId || '',
                    variableValueType: step.setting.sourceComp ? 'component' : 'constant',
                    variableValueMethod: step.setting.sourceComp?.method
                };
            case 'PageCall':
                return {
                    id: baseId,
                    type: 'PageCall',
                    pageName: step.call.pageName,
                    pageTitle: step.call.pageName,
                    pageParameters: []
                };
            default:
                return {
                    id: baseId,
                    type: 'BeanAction'
                };
        }
    };

    const handleSaveSubAction = (subAction: SubAction) => {
        if (!editingSubAction) return;

        // Convert SubAction to NovaEventActionStep to preserve data
        const actionStep = convertSubActionToActionStep(subAction);

        const updatedSteps = [...actionSteps];
        if (editingSubAction.index !== null) {
            updatedSteps[editingSubAction.index] = actionStep;
        } else {
            updatedSteps.push(actionStep);
        }

        setActionSteps(updatedSteps);
        setSubActionDialogOpen(false);
        setEditingSubAction(null);
    };

    const handleDeleteSubAction = (index: number) => {
        if (window.confirm('Are you sure you want to delete this sub-action?')) {
            const updatedSteps = [...actionSteps];
            updatedSteps.splice(index, 1);
            setActionSteps(updatedSteps);
        }
    };

    // Helper to convert SubAction to NovaEventActionStep
    const convertSubActionToActionStep = (subAction: SubAction): NovaEventActionStep => {
        switch (subAction.type) {
            case 'BeanAction':
                return {
                    type: 'BeanAction',
                    action: {
                        targetId: subAction.beanValue || '',
                        method: subAction.method || '',
                        property: subAction.parameters?.[0]?.name,
                        value: subAction.parameters?.[0]?.valueType === 'constant' ? subAction.parameters[0].value : undefined,
                        sourceVar: subAction.parameters?.[0]?.valueType === 'variable' ? subAction.parameters[0].value : undefined
                    }
                };
            case 'RemoteCall':
                // Convert to flat array with type field
                const inputs = (subAction.inputs || []).map(i => ({
                    name: i.bagKey,
                    text: i.valueType === 'constant' ? i.value : '',
                    type: (i.valueType === 'variable' ? 'var' : 'p') as 'var' | 'p',
                    id: i.valueType === 'variable' ? i.value : null,
                    var: i.valueType === 'variable' ? i.value : undefined,
                    n: i.bagKey
                }));

                const outputs = (subAction.outputs || []).map(o => ({
                    name: o.bagKey,
                    text: '',
                    type: (o.targetType === 'variable' ? 'var' : 'p') as 'var' | 'p',
                    id: o.targetType === 'component' ? o.targetVariable : null,
                    var: o.targetType === 'variable' ? o.targetVariable : undefined,
                    n: o.bagKey
                }));

                return {
                    type: 'RemoteCall',
                    call: {
                        serviceName: subAction.service || '',
                        inputs,
                        outputs
                    }
                };
            case 'ReferenceCall':
                return {
                    type: 'ReferenceCall',
                    reference: subAction.referencedAction || ''
                };
            case 'VariableSetting':
                return {
                    type: 'VariableSetting',
                    setting: {
                        variableId: subAction.variableName || '',
                        value: subAction.variableValueType === 'constant' ? subAction.variableValue : undefined,
                        sourceComp: subAction.variableValueType === 'component' ? {
                            componentId: subAction.variableValue || '',
                            method: subAction.variableValueMethod || ''
                        } : undefined
                    }
                };
            case 'PageCall':
                return {
                    type: 'PageCall',
                    call: {
                        pageName: subAction.pageName,
                        params: subAction.pageParameters
                    }
                };
            default:
                return {
                    type: 'ReferenceCall',
                    reference: ''
                };
        }
    };

    const getSubActionIcon = (type: string) => {
        switch (type) {
            case 'BeanAction': return '🔧';
            case 'RemoteCall': return '🌐';
            case 'ReferenceCall': return '🔗';
            case 'VariableSetting': return '📝';
            case 'PageCall': return '📄';
            default: return '⚙️';
        }
    };

    return (
        <Box sx={{ display: 'flex', height: '100%' }}>
            {/* Left Panel - Action List */}
            <Box sx={{ width: 300, borderRight: 1, borderColor: 'divider', display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Actions</Typography>
                        <Button
                            size="small"
                            variant="contained"
                            iconLeft={<AddIcon />}
                            onClick={handleNewAction}
                            text='New'
                        />
                        </Stack>
                </Box>
                <List sx={{ flexGrow: 1, overflow: 'auto' }}>
                    {actions.map((action) => (
                        <ListItem
                            key={action.id}
                            selected={selectedAction?.id === action.id}
                            button
                            onClick={() => handleSelectAction(action)}
                            secondaryAction={
                                <IconButton edge="end" size="small" onClick={(e) => {
                                    e.stopPropagation();
                                    handleDelete(action.id);
                                }}>
                                    <DeleteIcon fontSize="small" />
                                </IconButton>
                            }
                        >
                            <ListItemText
                                primary={action.name}
                                secondary={`${(action.actions || []).length} action step(s)`}
                            />
                        </ListItem>
                    ))}
                </List>
            </Box>

            {/* Right Panel - Details/JSON View */}
            <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Action Designer</Typography>
                        <ToggleButtonGroup
                            value={viewMode}
                            exclusive
                            onChange={(_, newMode) => newMode && setViewMode(newMode)}
                            size="small"
                        >
                            <ToggleButton value="visual">
                                <ViewListIcon sx={{ mr: 1 }} /> Visual
                            </ToggleButton>
                            <ToggleButton value="json">
                                <CodeIcon sx={{ mr: 1 }} /> JSON
                            </ToggleButton>
                        </ToggleButtonGroup>
                    </Stack>
                </Box>

                {viewMode === 'visual' ? (
                    <Box sx={{ p: 3, overflow: 'auto' }}>
                        {!isCreating && !selectedAction ? (
                            <>
                               {/*  
                               <Typography variant="body2" color="text.secondary" paragraph>
                                    Actions define operations to be executed in response to events. Each action can contain multiple
                                    sub-actions that execute sequentially.
                                </Typography>

                                <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
                                    <Typography variant="subtitle2" gutterBottom>Sub-Action Types:</Typography>
                                    <Stack spacing={1}>
                                        <Chip icon={<span>🔧</span>} label="Bean Action - Call methods on page components" size="small" />
                                        <Chip icon={<span>🌐</span>} label="Remote Call - Call server-side services" size="small" />
                                        <Chip icon={<span>🔗</span>} label="Reference Call - Execute another action" size="small" />
                                        <Chip icon={<span>📝</span>} label="Variable Setting - Set variable values" size="small" />
                                        <Chip icon={<span>📄</span>} label="Page Call - Navigate to another page" size="small" />
                                    </Stack>
                                </Paper>

                                {actions.length === 0 && (
                                    <Box sx={{ mt: 4, textAlign: 'center' }}>
                                        <Typography variant="body1" color="text.secondary">
                                            No actions defined. Click "New" to create an action.
                                        </Typography>
                                    </Box>
                                )} */}
                            </>
                        ) : (
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom>
                                    {selectedAction ? 'Edit Action' : 'New Action'}
                                </Typography>
                                <form onSubmit={handleSubmit(onSubmit)}>
                                    <Stack spacing={2} sx={{ mt: 2 }}>
                                        <Input
                                            label="Action Name *"
                                            name="name"
                                            control={control}
                                        />

                                        <Select
                                            label="Rule"
                                            name="rule"
                                            control={control}
                                            options={{
                                                data: [{ id: '', name: 'No Rule' }, ...rules],
                                                displayField: 'name',
                                                displayValue: 'name',
                                            }}
                                            setValue={setValue}
                                        />

                                    <Box>
                                        <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                                            <Typography variant="subtitle2">Action Steps</Typography>
                                            <Button
                                                size="small"
                                                iconLeft={<AddIcon />}
                                                onClick={()=>handleOpenSubActionDialog()}
                                                text='Add Action Step'
                                            />


                                        </Stack>

                                        {actionSteps.map((step, index) => (
                                            <Accordion key={index}>
                                                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                                                    <Stack direction="row" spacing={1} alignItems="center" sx={{ width: '100%' }}>
                                                        <span>{getSubActionIcon(step.type)}</span>
                                                        <Typography>{step.type}</Typography>
                                                        <Box sx={{ flexGrow: 1 }} />
                                                        <IconButton
                                                            size="small"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                handleOpenSubActionDialog(step, index);
                                                            }}
                                                        >
                                                            <EditIcon fontSize="small" />
                                                        </IconButton>
                                                        <IconButton
                                                            size="small"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                handleDeleteSubAction(index);
                                                            }}
                                                        >
                                                            <DeleteIcon fontSize="small" />
                                                        </IconButton>
                                                    </Stack>
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                    <Typography variant="caption" component="pre" sx={{ whiteSpace: 'pre-wrap' }}>
                                                        {JSON.stringify(step, null, 2)}
                                                    </Typography>
                                                </AccordionDetails>
                                            </Accordion>
                                        ))}
                                    </Box>

                                    <Stack direction="row" spacing={2} justifyContent="flex-end">
                                        <Button onClick={handleCancelEdit} type="button" text='Cancel' />
                                        <Button  onClick={handleSubmit(onSubmit)}  type="submit" variant="contained" text='Save' />
                                    </Stack>
                                </Stack>
                                </form>
                            </Paper>
                        )}
                    </Box>
                ) : (
                    <Box sx={{ flexGrow: 1 }}>
                        <Editor
                            height="100%"
                            defaultLanguage="json"
                            value={JSON.stringify({ actions }, null, 2)}
                            options={{
                                minimap: { enabled: false },
                                readOnly: true
                            }}
                        />
                    </Box>
                )}
            </Box>

            {/* Sub-Action Editor Dialog */}
            {subActionDialogOpen && editingSubAction && (
                <SubActionEditor
                    open={subActionDialogOpen}
                    subAction={editingSubAction.subAction}
                    onSave={handleSaveSubAction}
                    onClose={() => setSubActionDialogOpen(false)}
                />
            )}
        </Box>
    );
};
