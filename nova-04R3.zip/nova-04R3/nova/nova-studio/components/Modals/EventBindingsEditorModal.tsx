/* eslint-disable */
/**
 * Event Bindings Editor Modal
 * Allows editing component event bindings that trigger actions
 */

import { useState, useEffect, useMemo } from 'react';
import type { FC } from 'react';
import { Box, Modal, ModalBody, ModalTitle, Button } from '../../../../seker-ui-lib';
import { IconButton, MenuItem, FormControl, Select } from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { useNova } from '../../../nova-core';
import { resolveComponentEvents } from '../../../nova-core/utils/mappings';

export interface EventBindingsEditorModalProps {
    showModal: boolean;
    onClose: () => void;
    componentId: string;
    componentType: string; // Component type (e.g., 'SetButton', 'Input', 'TableComponent')
    availableEvents?: string[]; // Fallback: Event names like 'onClick', 'onChange', etc.
}

interface EventBindingRow {
    tempId: string;
    eventName: string;
    actionId: string;
    rule?: string;
}

export const EventBindingsEditorModal: FC<EventBindingsEditorModalProps> = ({
    showModal,
    onClose,
    componentId,
    componentType,
    availableEvents
}) => {
    const { schema, updateSchemaEvents, actions, rules } = useNova();
    const [bindings, setBindings] = useState<EventBindingRow[]>([]);
    const [hasChanges, setHasChanges] = useState(false);

    // Resolve available events based on component type or use fallback
    const resolvedEvents = useMemo(() => {
        const events = resolveComponentEvents(componentType);
        return events.length > 0 ? events : (availableEvents || []);
    }, [componentType, availableEvents]);

    // Load existing bindings when modal opens
    useEffect(() => {
        if (showModal && componentId && schema?.events) {
            // Find event bindings for this component (type='event' only, not actions)
            const componentEvents = schema.events.filter(
                (event: any) => event.id === componentId && event.type === 'event'
            );

            setBindings(componentEvents.map((event: any, idx: number) => ({
                tempId: `binding_${idx}_${Date.now()}`,
                eventName: event.name || '',
                // Event bindings use refId to reference the action
                actionId: event.refId || '',
                rule: undefined // NovaEvent doesn't have rule at event level
            })));
        } else if (showModal) {
            setBindings([]);
        }
        setHasChanges(false);
    }, [showModal, componentId, schema]);

    const handleAddBinding = () => {
        setBindings([...bindings, {
            tempId: `binding_new_${Date.now()}`,
            eventName: resolvedEvents[0] || '',
            actionId: '',
            rule: ''
        }]);
        setHasChanges(true);
    };

    const handleDeleteBinding = (tempId: string) => {
        setBindings(bindings.filter(b => b.tempId !== tempId));
        setHasChanges(true);
    };

    const handleBindingChange = (tempId: string, field: keyof EventBindingRow, newValue: string) => {
        setBindings(bindings.map(b =>
            b.tempId === tempId ? { ...b, [field]: newValue } : b
        ));
        setHasChanges(true);
    };

    // Get available actions and rules for dropdowns
    // Show standalone actions (type='action' or undefined), not event bindings (type='event')
    const availableActions = (actions || []).filter(a => a.type !== 'event');
    const availableRules = rules || [];

    const handleSave = () => {
        if (!schema) return;

        // Remove existing events for this component (but keep actions with type='action')
        const otherEvents = (schema.events || []).filter(
            (event: any) => event.id !== componentId || event.type === 'action'
        );

        // Create new NovaEvent entries for each binding
        // Event bindings just reference the action by refId, they don't copy the action steps
        const newEvents = bindings
            .filter(binding => binding.eventName && binding.actionId)
            .map(binding => ({
                id: componentId,
                name: binding.eventName,
                type: 'event',
                refId: binding.actionId,
                // Event bindings don't need actions array - they reference the action by refId
                actions: []
            }));

        // Update only schema events without reinitializing everything
        updateSchemaEvents([...otherEvents, ...newEvents]);

        setHasChanges(false);
        onClose();
    };

    const handleCancel = () => {
        setHasChanges(false);
        onClose();
    };

    return (
        <Modal show={showModal} onClose={handleCancel} maxWidth="md">
            <ModalTitle>
                Event Bindings - {componentId}
                {componentType && resolvedEvents.length > 0 && (
                    <Box component="span" sx={{ fontSize: '0.8em', color: 'text.secondary', ml: 1 }}>
                        ({componentType})
                    </Box>
                )}
            </ModalTitle>
            <ModalBody>
                <Box sx={{ minHeight: 300, maxHeight: 500, overflow: 'auto', p: 2 }}>
                    {resolvedEvents.length === 0 ? (
                        <Box sx={{
                            textAlign: 'center',
                            py: 4,
                            color: 'text.secondary',
                            fontStyle: 'italic'
                        }}>
                            No events available for this component type.
                            {componentType && (
                                <Box sx={{ mt: 1, fontSize: '0.9em' }}>
                                    Component Type: {componentType}
                                </Box>
                            )}
                        </Box>
                    ) : (
                        <>
                            {/* Header Row */}
                            <Box sx={{
                                display: 'grid',
                                gridTemplateColumns: '200px 1fr 200px 80px',
                                gap: 2,
                                mb: 2,
                                pb: 1,
                                borderBottom: '2px solid #ddd',
                                fontWeight: 'bold'
                            }}>
                                <div>Event Name</div>
                                <div>Action</div>
                                <div>Rule (Optional)</div>
                                <div>Actions</div>
                            </Box>

                    {/* Binding Rows */}
                    {bindings.map((binding) => (
                        <Box
                            key={binding.tempId}
                            sx={{
                                display: 'grid',
                                gridTemplateColumns: '200px 1fr 200px 80px',
                                gap: 2,
                                mb: 2,
                                alignItems: 'start'
                            }}
                        >
                            {/* Event Name Select */}
                            <FormControl size="small" fullWidth>
                                {/* <InputLabel>Event</InputLabel> */}
                                <Select
                                    value={binding.eventName}
                                    label="Event"
                                    onChange={(e: any) =>
                                        handleBindingChange(binding.tempId, 'eventName', e.target.value)
                                    }
                                    sx={{ m: 1, minWidth: 100 }}
                                >
                                    {resolvedEvents.map(event => (
                                        <MenuItem key={event} value={event}>{event}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>

                            {/* Action Select */}
                            <FormControl size="small" fullWidth>
                                {/* <InputLabel>Action</InputLabel> */}
                                <Select
                                    value={binding.actionId || ''}
                                    label="Action"
                                    onChange={(e: any) =>
                                        handleBindingChange(binding.tempId, 'actionId', e.target.value)
                                    }
                                    sx={{ m: 1, minWidth: 100 }}
                                >
                                    <MenuItem value="">
                                        <em>Select Action</em>
                                    </MenuItem>
                                    {availableActions.map(action => (
                                        <MenuItem key={action.id} value={action.id}>
                                            {action.name || action.id}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>

                            {/* Rule Select */}
                            <FormControl size="small" fullWidth>
                                {/* <InputLabel>Rule (Optional)</InputLabel> */}
                                <Select
                                    value={binding.rule || ''}
                                    label="Rule (Optional)"
                                    onChange={(e: any) =>
                                        handleBindingChange(binding.tempId, 'rule', e.target.value)
                                    }
                                    sx={{ m: 1, minWidth: 100 }}
                                >
                                    <MenuItem value="">
                                        <em>No Rule</em>
                                    </MenuItem>
                                    {availableRules.map(rule => (
                                        <MenuItem key={rule.id} value={rule.id}>
                                            {rule.name || rule.id}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>

                            {/* Delete Button */}
                            <Box sx={{ display: 'flex', alignItems: 'center', height: '40px' }}>
                                <IconButton
                                    onClick={() => handleDeleteBinding(binding.tempId)}
                                    color="error"
                                    size="small"
                                >
                                    <DeleteIcon />
                                </IconButton>
                            </Box>
                        </Box>
                    ))}

                            {/* Add Button */}
                            <Box sx={{ mt: 2 }}>
                                <Button
                                    variant="outlined"
                                    onClick={handleAddBinding}
                                    iconLeft={<AddIcon />}
                                    text="Add Event Binding"
                                    size="small"
                                />
                            </Box>

                            {bindings.length === 0 && (
                                <Box sx={{
                                    textAlign: 'center',
                                    py: 4,
                                    color: 'text.secondary',
                                    fontStyle: 'italic'
                                }}>
                                    No event bindings defined. Click "Add Event Binding" to create one.
                                </Box>
                            )}
                        </>
                    )}
                </Box>

                {/* Action Buttons */}
                <Box sx={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    gap: 2,
                    p: 2,
                    borderTop: '1px solid #ddd'
                }}>
                    <Button
                        variant="outlined"
                        onClick={handleCancel}
                        text="Cancel"
                    />
                    <Button
                        variant="contained"
                        onClick={handleSave}
                        disabled={!hasChanges}
                        text="Save"
                    />
                </Box>
            </ModalBody>
        </Modal>
    );
};
