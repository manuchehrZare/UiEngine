/* eslint-disable */
import React, { useRef, useState } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { Box, Unstable_Grid2 as Grid2 } from '@mui/material';
import { COMPONENT_REGISTRY } from '../../nova-core/registry/component-registry';
import { useNova, type DesignComponent } from '../../nova-core';

interface ComponentRendererProps {
    component: DesignComponent;
}

export const ComponentRenderer: React.FC<ComponentRendererProps> = ({ component }) => {
    const { selectComponent, selectedComponentId, moveComponent, addComponent } = useNova();
    const ref = useRef<HTMLDivElement>(null);
    const [isHovered, setIsHovered] = useState(false);

    const registryItem = COMPONENT_REGISTRY[component.type];
    // Fallback for unknown components
    const ActualComponent = registryItem?.component || 'div';
    const isContainer = registryItem?.isContainer;

    const [{ isDragging }, drag] = useDrag({
        type: 'COMPONENT_INSTANCE',
        item: { id: component.id, type: component.type },
        collect: (monitor) => ({
            isDragging: monitor.isDragging(),
        }),
    });

    const [{ isOver, canDrop }, drop] = useDrop({
        accept: ['COMPONENT', 'COMPONENT_INSTANCE'],
        canDrop: (item: any, monitor) => {
             if (!isContainer) return false;
             // Prevent dropping into self (handled in context, but good to check here visually)
             if (item.id === component.id) return false;
             return true;
        },
        drop: (item: any, monitor) => {
            // Only handle drop if the mouse is directly over this component (shallow drop)
            // UNLESS this component is a valid container and we want to support bubbling for nested drops if children didn't handle it.
            // But 'monitor.didDrop()' usually prevents bubbling if child handled it.
            
            if (monitor.didDrop()) {
                return;
            }

            // Debug logging
            console.log('Drop detected on:', component.id, 'Item:', item);

            if (item.id) {
                // Existing component move
                moveComponent(item.id, component.id, 'inside');
            } else {
                // New component from toolbar
                addComponent(item.type, component.id);
            }
        },
        collect: (monitor) => ({
            isOver: monitor.isOver({ shallow: true }),
            canDrop: monitor.canDrop(),
        }),
    });
    
    // Unified ref for drag and drop
    // Note: Some components might not forward ref properly.
    // We wrap in a Box to ensure we have a DOM node.
    drag(drop(ref));

    const isSelected = selectedComponentId === component.id;

    const handleClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        selectComponent(component.id);
    };

    // Recursively render children
    const renderChildren = () => {
        return component.children.map((child) => (
            <ComponentRenderer key={child.id} component={child} />
        ));
    };

    // Check if component is a GridItem to handle layout properly
    const isGridItem = component.type === 'GridItem';

    // Extract grid layout props if this is a GridItem
    const gridLayoutProps = isGridItem ? {
        xs: component.props.xs,
        sm: component.props.sm,
        md: component.props.md,
        lg: component.props.lg,
        xl: component.props.xl,
    } : {};

    // For GridItem, filter out the grid layout props from component.props
    // so they don't get passed to the actual GridItem component (since we apply them to the wrapper)
    const componentPropsToPass = isGridItem
        ? Object.fromEntries(
            Object.entries(component.props).filter(([key]) =>
                !['xs', 'sm', 'md', 'lg', 'xl'].includes(key)
            )
          )
        : component.props;

    // Common wrapper styles
    const wrapperStyles = {
        position: 'relative' as const,
        opacity: isDragging ? 0.5 : 1,
        border: isSelected ? '2px solid #2196f3' : isHovered ? '1px dashed #2196f3' : '1px solid transparent',
        // Remove margin for GridItem to prevent layout issues with Grid
        m: isGridItem ? 0 : 0.5,
        backgroundColor: (isOver && canDrop) ? 'rgba(33, 150, 243, 0.1)' : undefined,
        transition: 'all 0.2s',
    };

    // Render content inside wrapper
    const renderContent = () => (
        <>
            {/* Label for selected/hovered component */}
            {(isSelected || isHovered) && (
                <Box
                    sx={{
                        position: 'absolute',
                        top: -20,
                        left: 0,
                        backgroundColor: isSelected ? '#2196f3' : '#90caf9',
                        color: 'white',
                        fontSize: '0.75rem',
                        padding: '2px 6px',
                        borderRadius: '4px 4px 0 0',
                        zIndex: 10,
                        pointerEvents: 'none'
                    }}
                >
                    {component.type}
                </Box>
            )}

            <ActualComponent {...componentPropsToPass} designComponent={component}>
                {/* Render Children or Placeholders */}
                {isContainer ? (
                    component.children.length > 0 ? (
                        renderChildren()
                    ) : (
                        <Box
                            sx={{
                                minHeight: '50px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                border: '1px dashed #ccc',
                                borderRadius: 1,
                                m: 1,
                                backgroundColor: '#fafafa'
                            }}
                        >
                            <span style={{ fontSize: '0.8rem', color: '#999' }}>Drop components here</span>
                        </Box>
                    )
                ) : (
                    component.props.children
                )}
            </ActualComponent>
        </>
    );

    // Use Grid2 as wrapper for GridItem to maintain grid layout
    if (isGridItem) {
        return (
            <Grid2
                ref={ref}
                onClick={handleClick}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                {...gridLayoutProps}
                sx={{
                    ...wrapperStyles,
                    display: 'flex',
                    flexDirection: 'column',
                    minWidth: 0, // Prevent overflow issues in grid
                }}
            >
                {renderContent()}
            </Grid2>
        );
    }

    return (
        <Box
            ref={ref}
            onClick={handleClick}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            sx={wrapperStyles}
        >
            {renderContent()}
        </Box>
    );
};
