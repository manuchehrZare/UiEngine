if (typeof ResizeObserver === 'undefined') {
    import('resize-observer-polyfill').then((module) => {
        window.ResizeObserver = module.default;
    });
}

if (typeof MutationObserver === 'undefined') {
    import('mutation-observer').then((module) => {
        window.MutationObserver = module.default;
    });
}

if (typeof IntersectionObserver === 'undefined') {
    import('intersection-observer').then((module) => {
        window.IntersectionObserver = module.default;
    });
}

if (typeof window.matchMedia === 'undefined') {
    import('mq-polyfill').then((module) => {
        module.default(window);
    });
}

export {};
