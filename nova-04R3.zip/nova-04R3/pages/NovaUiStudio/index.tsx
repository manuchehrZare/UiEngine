import type { FC, JSX } from 'react';
import { Layout } from '../../App';
import { Grid, GridItem } from '../../seker-ui-lib';
import DesignerPage from '../../nova/nova-studio';

const NovaStudio: FC = (): JSX.Element => {
    return (
        <Layout title="Nova Ui Studio">
            <Grid>
                <GridItem>
                    <DesignerPage />
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NovaStudio;
