import type { FC, JSX } from 'react';
import { useTranslation } from '../../../utils';
import { routes, Layout } from '../../../App';
import { useSelector } from '../../../_store';
import { authValue } from '../../../_store/slices/auth';
import { NotFound as PageNotFound } from '../../../set-lib';

const NotFound: FC = (): JSX.Element => {
    const { t, locale } = useTranslation();
    const authStoreValue = useSelector(authValue);

    return (
        <Layout
            title={t(locale.pageTitles.notFound)}
            showFooter={authStoreValue.loggedIn}
            showHeader={authStoreValue.loggedIn}
            showSidebar={authStoreValue.loggedIn}>
            <PageNotFound
                isLoggedIn={Boolean(authStoreValue.loggedIn && authStoreValue.data)}
                loginLink={routes.auth.login.path}
                menuButtonProps={{ link: routes.menuList.path, text: t(locale.buttons.backMenuList) }}
            />
        </Layout>
    );
};

export default NotFound;
