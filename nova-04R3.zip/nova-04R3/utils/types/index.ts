export enum KeyboardEventCodeEnum {
    Enter = 'Enter',
    NumpadEnter = 'NumpadEnter',
}

export enum ScreenNameEnum {
    BANKING_EXIT = 'BANKING_EXIT',
}
