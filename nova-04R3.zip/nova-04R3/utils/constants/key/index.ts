export const key = {
    Shell_LANGUAGE: 'Shell-language',
};
