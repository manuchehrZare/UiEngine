import { useTranslation as usei18nTranslation } from 'react-i18next';
import type { ChangeLanguageOptions } from '../../seker-ui-lib';
import {
    deepCopy,
    deepKeysAsArray,
    i18nChangeLanguage as i18nChangeLanguageSekerUI,
    setLocalStorageItem,
} from '../../seker-ui-lib';
import { defaultlocaleData, i18n, languageStorageKey } from '../../locales/_i18nInstance';
import { set } from 'lodash';
import { i18nChangeLanguage as i18nChangeLanguageSetUI } from '../../set-lib';

/**
 * @param lng New Language Value
 * @param reload for window.location.reload active param. ( default : true )
 */
export const i18nChangeLanguage = ({ lng, callback, reload }: ChangeLanguageOptions): void => {
    document.documentElement.lang = lng;
    document.documentElement.setAttribute('lang', lng);
    setLocalStorageItem(languageStorageKey, lng);
    const prevLng = i18n.language;
    prevLng !== lng && reload !== false && window.location.reload();
    setTimeout(() => {
        i18n.changeLanguage(lng, () => {
            i18nChangeLanguageSekerUI({ lng, reload: false });
            i18nChangeLanguageSetUI({ lng, reload: false });
            callback?.();
        });
    }, 0);
};

const getLocaleData = () => {
    const localeData = deepCopy(defaultlocaleData);
    const keyArr = deepKeysAsArray(localeData);

    keyArr.forEach((path) => {
        set(localeData, path, path.replace('.', ':'));
    });
    return localeData;
};

// eslint-disable-next-line
export const useTranslation = () => {
    const params = usei18nTranslation();
    return { ...params, locale: getLocaleData() };
};

const locale = getLocaleData();
export { i18n, locale };
