import { dispatch, store } from '../../../_store';
import { setStoreApp } from '../../../_store/slices/app';
import { setStoreAuth } from '../../../_store/slices/auth';
import type { ShellListenerData } from '../../../set-lib';
import { generateGlobalsDataByMenuKey } from '../../../set-lib';
import { setStoreScreen } from '../../../_store/slices/screen';

export const handleShellListenerCallback = (data?: ShellListenerData): void => {
    if (data) {
        const { auth, loginUserName, screen, ...appData } = data;
        // Update operation with active screen value for "screen" store value
        dispatch(setStoreScreen(screen));
        // For Auth Update
        if (auth) {
            dispatch(
                setStoreAuth({
                    ...store.getState().auth,
                    loggedIn: Boolean(auth.token),
                    data: {
                        ...auth,
                        globals: generateGlobalsDataByMenuKey({
                            globals: auth?.globals,
                            menuKey: screen?.menuKey || null,
                        }),
                        loginUserName: loginUserName ?? '',
                    },
                }),
            );
        }
        // For AppInfo Update
        dispatch(setStoreApp({ ...store.getState().app, ...appData }));
    }
};
