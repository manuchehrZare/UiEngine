import { dispatch } from '../../../_store';
import type { AuthStoreData } from '../../../_store/slices/auth';
import { resetStoreAuth, setStoreAuth } from '../../../_store/slices/auth';

export const setAuthData = (data: Partial<AuthStoreData>): void => {
    dispatch(setStoreAuth({ loggedIn: true, data: data as AuthStoreData }));
};

export const resetAuthData = (): void => {
    dispatch(resetStoreAuth());
};
