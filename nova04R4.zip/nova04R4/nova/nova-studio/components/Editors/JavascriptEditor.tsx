/* eslint-disable */
import React from 'react';
import Editor from '@monaco-editor/react';
import { useNova } from '../../../nova-core';

export const JavascriptEditor: React.FC = () => {
    const { jsCode, setJsCode } = useNova();

    return (
        <Editor
            height="100%"
            defaultLanguage="javascript"
            value={jsCode}
            onChange={(value) => setJsCode(value || '')}
            options={{
                minimap: { enabled: false },
            }}
        />
    );
};

