// Re-export from nova-core for backward compatibility
export type { PropertySchema, ComponentSchema } from '../../nova-core/types/property-schema.types';
