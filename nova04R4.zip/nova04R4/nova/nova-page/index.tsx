/* eslint-disable */
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Box, Typography } from '../../seker-ui-lib';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import type { NovaUiSchema } from '../nova-core/types/nova-ui-schema.types';
import { DesignArea } from '../nova-studio/components/DesignArea';
import { useNova } from '../nova-core';
import { convertNovaEbmlToNovaUiSchema } from '../nova-core/nova-ebml/nova-ebml-converter';
import { getScreenEbmlSchema } from '../nova-core/nova-ebml/ebml-schema-provider';

/**
 * DynamicRenderer component that imports and renders a NovaUiSchema
 */
const DynamicRenderer: React.FC<{ novaSchema: NovaUiSchema }> = ({ novaSchema }) => {
    const { importDesign, setMode } = useNova();

    useEffect(() => {
        if (novaSchema) {
            // Import the complete NovaUiSchema (includes UI, events, rules, variables)
            importDesign(JSON.stringify(novaSchema));
            setMode('preview');
        }
    }, [novaSchema, importDesign, setMode]);

    return (
        <Box sx={{ height: '100vh', width: '100vw', overflow: 'hidden', bgcolor: '#f0f2f5' }}>
            <DesignArea />
        </Box>
    );
};

/**
 * NovaPage component that fetches and renders a page by screenCode from URL
 * Usage: /novaPage?screen-code=CCA009
 * This page does not show menu bar, only the rendered page
 */
const NovaPageContent: React.FC = () => {
    const [searchParams] = useSearchParams();
    const screenCode = searchParams.get('screen-code');
    const [novaSchema, setNovaSchema] = useState<NovaUiSchema | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadPageByScreenCode = async () => {
            try {
                setLoading(true);
                setError(null);

                // // Load the ui-definition.json file
                // const response = await fetch('/src/assets/docs/ui-definition.json');
                // if (!response.ok) {
                //     throw new Error('Failed to load page definitions');
                // }

                // const pages: PageDefinition[] = await response.json();

                // // Find the page by screenCode
                // const page = pages.find((p) => p.ScreenCode === screenCode);

                // if (!page) {
                //     throw new Error(`Page with screenCode "${screenCode}" not found`);
                // }

                // setPageDefinition(page);

                // Convert EBML to NovaUiSchema
                try {
                    if(screenCode)
                        getScreenEbmlSchema(screenCode).then(screenEbml=>{
                                    if(screenEbml)
                                    {
                                        const convertedSchema = convertNovaEbmlToNovaUiSchema(screenEbml);
                                        setNovaSchema(convertedSchema);
                                    }
                                });
                    // const convertedSchema = mapEbmlContentToNovaSchema(page.EbmlContent);
                    // setNovaSchema(convertedSchema);
                } catch (conversionError) {
                    console.error('Failed to convert page schema:', conversionError);
                    throw new Error('Failed to convert page schema');
                }
            } catch (err) {
                console.error('Error loading page:', err);
                setError(err instanceof Error ? err.message : 'Unknown error occurred');
            } finally {
                setLoading(false);
            }
        };

        if (screenCode) {
            loadPageByScreenCode();
        } else {
            setError('No screenCode provided in URL');
            setLoading(false);
        }
    }, [screenCode]);

    if (loading) {
        return (
            <Box
                sx={{
                    height: '100vh',
                    width: '100vw',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    bgcolor: '#f5f5f5',
                }}
            >
                <Typography variant="h6" color="text.secondary">
                    Loading page "{screenCode}"...
                </Typography>
            </Box>
        );
    }

    if (error) {
        return (
            <Box
                sx={{
                    height: '100vh',
                    width: '100vw',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    bgcolor: '#f5f5f5',
                }}
            >
                <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h5" color="error" gutterBottom>
                        Error Loading Page
                    </Typography>
                    <Typography variant="body1" color="text.secondary">
                        {error}
                    </Typography>
                </Box>
            </Box>
        );
    }

    if (!novaSchema) {
        return (
            <Box
                sx={{
                    height: '100vh',
                    width: '100vw',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    bgcolor: '#f5f5f5',
                }}
            >
                <Typography variant="h6" color="text.secondary">
                    No schema available for page "{screenCode}"
                </Typography>
            </Box>
        );
    }

    return <DynamicRenderer novaSchema={novaSchema} />;
};

/**
 * Main NovaPage component with providers
 */
const NovaPage: React.FC = () => {
    return (
            <DndProvider backend={HTML5Backend}>
                    <NovaPageContent />
            </DndProvider>
    );
};

export default NovaPage;
