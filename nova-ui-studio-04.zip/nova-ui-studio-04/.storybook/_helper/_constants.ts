export const constants = {
    components: {},
    hooks: {},
    utils: {
        validations: {
            yupLink: 'https://github.com/jquense/yup',
            confluenceLink: 'https://confluence.cb.sekerbank.com.tr:8443/display/SETUI/Validations',
        },
    },
};
