# Shell-UI

## Library Information

- [React](https://reactjs.org/)
- [Vite](https://vite.dev/)
- [Typescript](https://www.typescriptlang.org/)
- [ESLint](https://eslint.org/)
- [SekerUI](https://sekerui.seker.net/)
- [SetUI](https://set-ui-setui-master.ocp.sekerbank.com.tr/)
- [Redux Toolkit](https://redux-toolkit.js.org/)
- [Query](https://tanstack.com/query/latest)

## Browser Support

- Google Chrome
- Mozilla Firefox
- Microsoft Edge
- Safari

##

Developed by the **Şekerbank Software Development** team.<br/>
