export type ChildrenLoaderProps = {
    children: any;
    fallback?: React.ReactNode;
};

export type ComponentLoaderProps = {
    component: any;
    componentProps?: any;
    fallback?: React.ReactNode;
};
