export * from './component-registry';
