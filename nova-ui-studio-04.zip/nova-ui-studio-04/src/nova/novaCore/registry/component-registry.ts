/* eslint-disable */
/**
 * Component Registry
 * Central registry mapping component types to implementations
 * This is shared across nova-studio (designer) and nova-ui (runtime)
 */

import * as Components from '../../../seker-ui-lib';
import * as NovaComponents from '../../nova-ui/components';

export type ComponentCategory = 'Layout' | 'Form' | 'Display' | 'Set' | 'Others';

export interface ComponentConfig {
    name: string;
    component: any;
    category: ComponentCategory;
    defaultProps: Record<string, any>;
    isContainer?: boolean; // If it can hold other components
    needsDesignComponent?: boolean; // If it requires the designComponent prop
    documentation?: string; // Path to documentation or story
    showInDesignerToolbar?: boolean;
}

export const COMPONENT_REGISTRY: Record<string, ComponentConfig> = {
    // --- Layout ---
    Grid: {
        name: 'Grid',
        component: Components.Grid,
        category: 'Layout',
        defaultProps: { container: true, spacing: 2 },
        isContainer: true,
        documentation: 'Display/Grid',
        showInDesignerToolbar: true
    },
    GridItem: {
        name: 'GridItem',
        component: Components.GridItem,
        category: 'Layout',
        defaultProps: { xs: 12, md: 6 },
        isContainer: true,
        documentation: 'Display/Grid',
        showInDesignerToolbar: true
    },
    Box: {
        name: 'Box',
        component: Components.Box,
        category: 'Layout',
        defaultProps: { sx: { p: 2, border: '1px dashed grey' } },
        isContainer: true,
        documentation: 'Display/Box',
        showInDesignerToolbar: true
    },
    Container: {
        name: 'Container',
        component: Components.Container,
        category: 'Layout',
        defaultProps: {},
        isContainer: true,
        documentation: 'Display/Container',
        showInDesignerToolbar: true
    },
    Paper: {
        name: 'Paper',
        component: Components.Paper,
        category: 'Layout',
        defaultProps: { elevation: 1, sx: { p: 2 } },
        isContainer: true,
        documentation: 'Display/Paper',
        showInDesignerToolbar: true
    },
    Divider: {
        name: 'Divider',
        component: Components.Divider,
        category: 'Layout',
        defaultProps: {},
        documentation: 'Display/Divider',
        showInDesignerToolbar: true
    },
    Break: {
        name: 'Break',
        component: Components.Break,
        category: 'Layout',
        defaultProps: {},
        documentation: 'Display/Break',
        showInDesignerToolbar: true
    },

    // --- Form ---
    Button: {
        name: 'Button',
        component: Components.Button,
        category: 'Form',
        defaultProps: {},
        showInDesignerToolbar: false
    },
    Input: {
        name: 'Input',
        component: NovaComponents.InputComponent,
        category: 'Form',
        defaultProps: { label: '', fullWidth: true, labelPlacement: 'start' },
        documentation: 'Form/Input',
        showInDesignerToolbar: true
    },
    NumberInput: {
        name: 'NumberInput',
        component: NovaComponents.NumberInputComponent,
        category: 'Form',
        defaultProps: { label: '', fullWidth: true, labelPlacement: 'start' },
        documentation: 'Form/NumberInput',
        showInDesignerToolbar: true
    },
    Checkbox: {
        name: 'Checkbox',
        component: NovaComponents.CheckboxComponent,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/Checkbox',
        showInDesignerToolbar: true
    },
    Radio: {
        name: 'Radio',
        component: NovaComponents.RadioComponent,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/Radio',
        showInDesignerToolbar: true
    },
    RadioGroup: {
        name: 'RadioGroup',
        component: NovaComponents.RadioGroupComponent,
        category: 'Form',
        defaultProps: { row: true },
        isContainer: true,
        documentation: 'Form/RadioGroup',
        showInDesignerToolbar: true
    },
    Select: {
        name: 'Select',
        component: NovaComponents.SelectComponent,
        category: 'Form',
        defaultProps: { label: '', options: [{ value: 1, label: 'Option 1' }], labelPlacement: 'start' },
        documentation: 'Form/Select',
        showInDesignerToolbar: true
    },
    Switch: {
        name: 'Switch',
        component: Components.Switch,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/Switch',
        showInDesignerToolbar: true
    },
    DatePicker: {
        name: 'DatePicker',
        component: NovaComponents.DatePickerComponent,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/Pickers/DatePicker',
        showInDesignerToolbar: true
    },
    DateTimePicker: {
        name: 'DateTimePicker',
        component: NovaComponents.DateTimePickerComponent,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/Pickers/DateTimePicker',
        showInDesignerToolbar: true
    },
    TimePicker: {
        name: 'TimePicker',
        component: NovaComponents.TimePickerComponent,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/Pickers/TimePicker',
        showInDesignerToolbar: true
    },
    Autocomplete: {
        name: 'Autocomplete',
        component: Components.Autocomplete,
        category: 'Form',
        defaultProps: { label: '', options: [], labelPlacement: 'start' },
        documentation: 'Form/Autocomplete',
        showInDesignerToolbar: true
    },
    RangeInput: {
        name: 'RangeInput',
        component: Components.RangeInput,
        category: 'Form',
        defaultProps: { label: '', labelPlacement: 'start' },
        documentation: 'Form/RangeInput',
        showInDesignerToolbar: true
    },
    RichEditor: {
        name: 'RichEditor',
        component: Components.RichEditor,
        category: 'Form',
        defaultProps: {},
        documentation: 'Form/RichEditor',
        showInDesignerToolbar: true
    },
    Upload: {
        name: 'Upload',
        component: Components.Upload,
        category: 'Form',
        defaultProps: {},
        documentation: 'Form/Upload',
        showInDesignerToolbar: true
    },

    // --- Set ---
    TableComponent: {
        name: 'Table',
        component: NovaComponents.TableComponent,
        category: 'Set',
        defaultProps: {},
        showInDesignerToolbar: true
    },
    HandleButton: {
        name: 'HandleButton',
        component: NovaComponents.HandleButtonFieldComponent,
        category: 'Set',
        defaultProps: {},
        showInDesignerToolbar: true
    },
    SetButton: {
        name: 'SetButton',
        component: NovaComponents.SetButtonComponent,
        category: 'Set',
        defaultProps: {},
        showInDesignerToolbar: true
    },
    Page: {
        name: 'Page',
        component: NovaComponents.PageComponent,
        category: 'Set',
        defaultProps: {},
        isContainer: true,
        needsDesignComponent: true,
        showInDesignerToolbar: true
    },
    Region: {
        name: 'Region',
        component: NovaComponents.RegionComponent,
        category: 'Set',
        defaultProps: {},
        isContainer: true,
        showInDesignerToolbar: true
    },
    TabbedPane: {
        name: 'TabbedPane',
        component: NovaComponents.TabbedPaneComponent,
        category: 'Set',
        defaultProps: {},
        isContainer: true,
        needsDesignComponent: true,
        showInDesignerToolbar: true
    },
    TabPage: {
        name: 'TabPage',
        component: NovaComponents.TabPageComponent,
        category: 'Set',
        defaultProps: {},
        isContainer: true,
        showInDesignerToolbar: true
    },
    Tab: {
        name: 'Tab',
        component: NovaComponents.TabComponent,
        category: 'Set',
        defaultProps: {},
        isContainer: true,
        showInDesignerToolbar: true
    },
    Unknown: {
        name: 'Unknown',
        component: NovaComponents.UnknownComponent,
        category: 'Set',
        defaultProps: {},
        isContainer: true,
        showInDesignerToolbar: false
    },

    // --- Display ---
    Label: {
        name: 'Label',
        component: NovaComponents.LabelComponent,
        category: 'Display',
        defaultProps: { text: 'Label' },
        showInDesignerToolbar: true
    },
    Typography: {
        name: 'Typography',
        component: Components.Typography,
        category: 'Display',
        defaultProps: { children: 'Text Content', variant: 'body1' },
        documentation: 'Display/Typography',
        showInDesignerToolbar: true
    },
    Alert: {
        name: 'Alert',
        component: Components.Alert,
        category: 'Display',
        defaultProps: { severity: 'info', children: 'Alert Message' },
        documentation: 'Display/Alert',
        showInDesignerToolbar: true
    },
    Chip: {
        name: 'Chip',
        component: Components.Chip,
        category: 'Display',
        defaultProps: { label: 'Chip' },
        documentation: 'Display/Chip',
        showInDesignerToolbar: true
    },
    Accordion: {
        name: 'Accordion',
        component: Components.Accordion,
        category: 'Display',
        defaultProps: { title: 'Accordion Title', children: 'Content' },
        isContainer: true,
        documentation: 'Display/Accordion',
        showInDesignerToolbar: true
    },
    Breadcrumbs: {
        name: 'Breadcrumbs',
        component: Components.Breadcrumbs,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Breadcrumbs',
        showInDesignerToolbar: true
    },
    Carousel: {
        name: 'Carousel',
        component: Components.Carousel,
        category: 'Display',
        defaultProps: {},
        isContainer: true,
        documentation: 'Display/Carousel',
        showInDesignerToolbar: true
    },
    Collapse: {
        name: 'Collapse',
        component: Components.Collapse,
        category: 'Display',
        defaultProps: { in: true },
        isContainer: true,
        documentation: 'Display/Collapse',
        showInDesignerToolbar: true
    },
    ConfirmModal: {
        name: 'ConfirmModal',
        component: Components.ConfirmModal,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/ConfirmModal',
        showInDesignerToolbar: true
    },
    CustomScrollbar: {
        name: 'CustomScrollbar',
        component: Components.CustomScrollbar,
        category: 'Display',
        defaultProps: {},
        isContainer: true,
        documentation: 'Display/CustomScrollbar',
        showInDesignerToolbar: true
    },
    DataGrid: {
        name: 'DataGrid',
        component: Components.DataGrid,
        category: 'Display',
        defaultProps: { columns: [], rows: [] },
        documentation: 'Display/DataGrid',
        showInDesignerToolbar: true
    },
    Empty: {
        name: 'Empty',
        component: Components.Empty,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Empty',
        showInDesignerToolbar: true
    },
    KeyValueList: {
        name: 'KeyValueList',
        component: Components.KeyValueList,
        category: 'Display',
        defaultProps: { data: [] },
        documentation: 'Display/KeyValueList',
        showInDesignerToolbar: true
    },
    LoadingModal: {
        name: 'LoadingModal',
        component: Components.LoadingModal,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/LoadingModal',
        showInDesignerToolbar: true
    },
    Modal: {
        name: 'Modal',
        component: Components.Modal,
        category: 'Display',
        defaultProps: {},
        isContainer: true,
        documentation: 'Display/Modal',
        showInDesignerToolbar: true
    },
    Nav: {
        name: 'Nav',
        component: NovaComponents.NavComponent,
        category: 'Display',
        defaultProps: {
            title: 'Navigation Title'
        },
        documentation: 'Display/Nav',
        showInDesignerToolbar: true
    },
    NumberFormat: {
        name: 'NumberFormat',
        component: Components.NumberFormat,
        category: 'Display',
        defaultProps: { value: 1234 },
        documentation: 'Display/NumberFormat',
        showInDesignerToolbar: true
    },
    Pagination: {
        name: 'Pagination',
        component: Components.Pagination,
        category: 'Display',
        defaultProps: { count: 10 },
        documentation: 'Display/Pagination',
        showInDesignerToolbar: true
    },
    PdfViewer: {
        name: 'PdfViewer',
        component: Components.PdfViewer,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/PdfViewer',
        showInDesignerToolbar: true
    },
    Popup: {
        name: 'Popup',
        component: Components.Popup,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Popup',
        showInDesignerToolbar: true
    },
    Progress: {
        name: 'Progress',
        component: Components.Progress,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Progress',
        showInDesignerToolbar: true
    },
    Rating: {
        name: 'Rating',
        component: Components.Rating,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Rating',
        showInDesignerToolbar: true
    },
    Stepper: {
        name: 'Stepper',
        component: Components.Stepper,
        category: 'Display',
        defaultProps: { steps: ['Step 1', 'Step 2'] },
        documentation: 'Display/Stepper',
        showInDesignerToolbar: true
    },
    TabItem: {
        name: 'TabItem',
        component: NovaComponents.TabItemComponent,
        category: 'Display',
        defaultProps: { text: 'Tab Item' },
        documentation: 'Display/Tab',
        showInDesignerToolbar: true
    },
    Tooltip: {
        name: 'Tooltip',
        component: Components.Tooltip,
        category: 'Display',
        defaultProps: { title: 'Tooltip' },
        isContainer: true,
        documentation: 'Display/Tooltip',
        showInDesignerToolbar: true
    },
    TreeView: {
        name: 'TreeView',
        component: Components.TreeView,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/TreeView',
        showInDesignerToolbar: true
    },
    View: {
        name: 'View',
        component: Components.View,
        category: 'Display',
        defaultProps: {},
        isContainer: true,
        documentation: 'Display/View',
        showInDesignerToolbar: true
    },
    VRKeyboard: {
        name: 'VRKeyboard',
        component: Components.VRKeyboard,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/VRKeyboard',
        showInDesignerToolbar: true
    },

    // --- Charts ---
    BarChart: {
        name: 'BarChart',
        component: Components.BarChart,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Charts/BarChart',
        showInDesignerToolbar: true
    },
    PieChart: {
        name: 'PieChart',
        component: Components.PieChart,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Charts/PieChart',
        showInDesignerToolbar: true
    },
    LineChart: {
        name: 'LineChart',
        component: Components.LineChart,
        category: 'Display',
        defaultProps: {},
        documentation: 'Display/Charts/LineChart',
        showInDesignerToolbar: true
    },

    // --- Others ---
    CardNumber: {
        name: 'CardNumber',
        component: Components.CardNumber,
        category: 'Others',
        defaultProps: { label: 'Card Number' },
        documentation: 'Others/CardNumber',
        showInDesignerToolbar: true
    },
    Currency: {
        name: 'Currency',
        component: Components.Currency,
        category: 'Others',
        defaultProps: { label: 'Currency', component: 'NumberInput' },
        documentation: 'Others/Currency',
        showInDesignerToolbar: true
    },
    IBAN: {
        name: 'IBAN',
        component: Components.IBAN,
        category: 'Others',
        defaultProps: { label: 'IBAN', input: true },
        documentation: 'Others/IBAN',
        showInDesignerToolbar: true
    },
    PhoneNumber: {
        name: 'PhoneNumber',
        component: Components.PhoneNumber,
        category: 'Others',
        defaultProps: { label: 'Phone Number' },
        documentation: 'Others/PhoneNumber',
        showInDesignerToolbar: true
    },
};

export const getComponentConfig = (name: string) => COMPONENT_REGISTRY[name];
