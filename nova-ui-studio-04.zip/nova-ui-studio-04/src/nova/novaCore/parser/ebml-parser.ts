/* eslint-disable */
/**
 * EBML Parser
 * Unified parser for EBML bean structure and business logic (rules, variables, actions)
 */

import { v4 as uuidv4 } from 'uuid';
import type { EbmlBean, EbmlProperty, ComponentBounds, ParsedComponent } from '../types/ebml.types';
import type { Rule, Variable, Action, SubAction } from '../types/design.types';
import { nestComponentsByBounds } from '../utils/boundsNesting';
import { resolveComponentType } from '../utils/mappings';

/**
 * Parse bounds string (e.g., "15,40,110,20") to ComponentBounds object
 */
export const parseBounds = (boundsText: string): ComponentBounds => {
    const [x, y, width, height] = boundsText.split(',').map(Number);
    return { x, y, width, height };
};

/**
 * Extract properties from EBML Style object
 */
export const extractProperties = (bean: EbmlBean): Record<string, any> => {
    const properties: Record<string, any> = {};

    if (!bean.Style?.P) {
        return properties;
    }

    bean.Style.P.forEach((prop: EbmlProperty) => {
         if (prop.Name) {
      // For properties with Columns (like adapterInfo), use Columns instead of Text
      if (prop.Columns) {
                properties[prop.Name] = prop.Columns;
      } else if (prop.Text !== undefined) {
                properties[prop.Name] = prop.Text;
      }
    }
    });

    return properties;
};

/**
 * Get property value by name
 */
export const getProperty = (bean: EbmlBean, propertyName: string): string | undefined => {
    if (!bean.Style?.P) {
        return undefined;
    }

    const prop = bean.Style.P.find((p: EbmlProperty) => p.Name === propertyName);
    return prop?.Text;
};

/**
 * Get bounds property
 */
export const getBounds = (bean: EbmlBean): ComponentBounds | null => {
    const boundsText = getProperty(bean, 'bounds');
    if (!boundsText) {
        return null;
    }
    return parseBounds(boundsText);
};

/**
 * Parse EBML bean to ParsedComponent
 */
export const parseBean = (bean: EbmlBean): ParsedComponent => {
    const properties = extractProperties(bean);
    const bounds = getBounds(bean) || { x: 0, y: 0, width: 100, height: 20 };
    const type = resolveComponentType(bean.Class);

    // Preserve original class name for Unknown components so we can display it
    if (type === 'Unknown') {
        properties.originalClassName = bean.Class;
    }

    const component: ParsedComponent = {
        id: bean.Id,
        type,
        bounds,
        properties,
    };

    // Recursively parse children
    if (bean.SubBean && bean.SubBean.length > 0) {
        component.children = bean.SubBean.map(parseBean);
    }

    return component;
};

/**
 * Parse EBML bean and reorganize by bounds containment
 */
export const parseBeanWithNesting = (bean: EbmlBean): ParsedComponent => {
    // First parse normally
    const parsed = parseBean(bean);
    // Then reconstruct based on geometry
    // We pass a copy to avoid mutating the original parse result if needed, but here we want the transformation
     const deepCopy = JSON.parse(JSON.stringify(parsed));
     return nestComponentsByBounds(deepCopy);
  // return deepCopy;
};

/**
 * Parse page size property
 */
export const parsePageSize = (pageSizeText: string): { width: number; height: number } => {
    const [width, height] = pageSizeText.split(',').map(Number);
    return { width, height };
};

/**
 * Get all beans as flat array (depth-first traversal)
 */
export const flattenBeans = (bean: EbmlBean): EbmlBean[] => {
    const result: EbmlBean[] = [bean];

    if (bean.SubBean && bean.SubBean.length > 0) {
        bean.SubBean.forEach((subBean) => {
            result.push(...flattenBeans(subBean));
        });
    }

    return result;
};

/**
 * Find bean by ID
 */
export const findBeanById = (rootBean: EbmlBean, id: string): EbmlBean | null => {
    if (rootBean.Id === id) {
        return rootBean;
    }

    if (rootBean.SubBean && rootBean.SubBean.length > 0) {
        for (const subBean of rootBean.SubBean) {
            const found = findBeanById(subBean, id);
            if (found) {
                return found;
            }
        }
    }

    return null;
};

// ============================================================================
// Business Logic Parsers (Rules, Variables, Actions)
// ============================================================================

/**
 * Parse legacy EBML Variables from EbmlContent.Data.Var
 * Legacy format: { Id: string, N: string|null, Comp: string|null, Text: string|null, Rule: string|null }
 */
export function parseEbmlVariables(ebmlVars: any[]): Variable[] {
    if (!Array.isArray(ebmlVars)) return [];

    return ebmlVars.map(ebmlVar => ({
        id: uuidv4(),
        name: ebmlVar.Id || '',
        initialValue: ebmlVar.Text || '',
        valueType: 'string' as const, // Legacy doesn't specify type, default to string
        scope: 'page' as const,
        description: `Legacy variable from EBML: ${ebmlVar.Id}`
    }));
}

/**
 * Parse source/target from legacy format
 * Format: "var:variableName", "const:value", "comp:Page.ComponentName", or "comp:Page.ComponentName.method"
 */
function parseSourceTarget(value: string | null | undefined): { type: 'constant' | 'variable' | 'component'; value: string; method?: string } {
    if (!value) {
        return { type: 'constant', value: '' };
    }

    if (value.startsWith('var:')) {
        return { type: 'variable', value: value.substring(4) };
    }

    if (value.startsWith('const:')) {
        return { type: 'constant', value: value.substring(6) };
    }

    if (value.startsWith('comp:')) {
        const compValue = value.substring(5);
        // Check if it has a method (e.g., comp:Page.COMPONENT.getText)
        const parts = compValue.split('.');
        if (parts.length > 2) {
            return {
                type: 'component',
                value: parts.slice(0, 2).join('.'),
                method: parts[2]
            };
        }
        return { type: 'component', value: compValue };
    }

    // If no prefix, treat as constant
    return { type: 'constant', value };
}

/**
 * Parse legacy EBML Rules from EbmlContent.Ruleset
 * Ruleset contains: { Message: [], Rule: [], Combination: [] }
 */
export function parseEbmlRules(ebmlRuleset: any): Rule[] {
    const rules: Rule[] = [];

    if (!ebmlRuleset) return rules;

    // Parse Simple Rules from Ruleset.Rule
    if (Array.isArray(ebmlRuleset.Rule)) {
        ebmlRuleset.Rule.forEach((rule: any) => {
            // Extract source type and value
            const source = parseSourceTarget(rule.Source);
            const target = parseSourceTarget(rule.Target);

            rules.push({
                id: uuidv4(),
                name: rule.Id || '',
                type: 'Simple',
                source: source.value,
                sourceMethod: source.method || undefined,
                operator: rule.Op || 'EQ',
                target: target.value,
                targetType: target.type,
                targetMethod: target.method || undefined
            });
        });
    }

    // Parse Message Rules from Ruleset.Message
    if (Array.isArray(ebmlRuleset.Message)) {
        ebmlRuleset.Message.forEach((msg: any) => {
            rules.push({
                id: uuidv4(),
                name: msg.Id || '',
                type: 'Message',
                messageTitle: msg.Title || '',
                messageType: msg.Type || 'OK', // OK, OK_CANCEL, YES_NO
                messageAppearance: msg.MessageType || 'INFO', // INFO, WARNING, ERROR
                messageContent: msg.Text || '',
                messageContentType: msg.Var ? 'variable' : 'constant'
            });
        });
    }

    // Parse Combination Rules from Ruleset.Combination
    if (Array.isArray(ebmlRuleset.Combination)) {
        ebmlRuleset.Combination.forEach((combo: any) => {
            rules.push({
                id: uuidv4(),
                name: combo.Id || '',
                type: 'Combination',
                combinationExpression: combo.Expression || ''
            });
        });
    }

    return rules;
}

/**
 * Parse legacy EBML Actions from EbmlContent.Interface.Events
 * Events contains: { LC: [], [eventName]: [] }
 * Each event is an array of action definitions
 */
export function parseEbmlActions(ebmlEvents: any): Action[] {
    const actions: Action[] = [];

    if (!ebmlEvents) return actions;

    // Iterate through all event types (LC, ButtonClick, etc.)
    Object.keys(ebmlEvents).forEach(eventKey => {
        const eventArray = ebmlEvents[eventKey];
        if (!Array.isArray(eventArray)) return;

        eventArray.forEach((eventDef: any, index: number) => {
            const subActions: SubAction[] = [];

            // Parse RemoteCall (RC) if present
            if (eventDef.RC) {
                const rc = eventDef.RC;
                const inputs: any[] = [];
                const outputs: any[] = [];

                // Parse inputs
                if (rc.Inputs) {
                    if (Array.isArray(rc.Inputs.Var)) {
                        rc.Inputs.Var.forEach((v: any) => {
                            inputs.push({
                                bagKey: v.N || '',
                                value: v.Id || v.Text || '',
                                valueType: v.Id ? 'variable' : 'constant'
                            });
                        });
                    }
                    if (Array.isArray(rc.Inputs.P)) {
                        rc.Inputs.P.forEach((p: any) => {
                            inputs.push({
                                bagKey: p.N || '',
                                value: p.Id || p.Text || '',
                                valueType: p.Id ? 'component' : 'constant'
                            });
                        });
                    }
                }

                // Parse outputs
                if (rc.Outputs) {
                    if (Array.isArray(rc.Outputs.P)) {
                        rc.Outputs.P.forEach((p: any) => {
                            outputs.push({
                                bagKey: p.N || '',
                                targetVariable: p.Id || '',
                                targetType: p.Id && p.Id.startsWith('Page.') ? 'component' : 'variable'
                            });
                        });
                    }
                    if (Array.isArray(rc.Outputs.Var)) {
                        rc.Outputs.Var.forEach((v: any) => {
                            outputs.push({
                                bagKey: v.N || '',
                                targetVariable: v.Id || '',
                                targetType: 'variable'
                            });
                        });
                    }
                }

                subActions.push({
                    id: uuidv4(),
                    type: 'RemoteCall',
                    service: rc.S || '',
                    inputs,
                    outputs
                });
            }

            // Parse BeanActions (P array)
            if (Array.isArray(eventDef.P)) {
                eventDef.P.forEach((p: any) => {
                    const parameters: any[] = [];

                    // If there are parameters, add them
                    if (p.Text) {
                        parameters.push({
                            name: 'value',
                            value: p.Text,
                            valueType: 'constant'
                        });
                    }

                    subActions.push({
                        id: uuidv4(),
                        type: 'BeanAction',
                        beanValue: p.Id || '',
                        method: p.M || '',
                        parameters
                    });
                });
            }

            // Parse Variable Setting (Var)
            if (eventDef.Var) {
                subActions.push({
                    id: uuidv4(),
                    type: 'VariableSetting',
                    variableName: eventDef.Var.Id || '',
                    variableValue: eventDef.Var.Text || eventDef.Var.Comp || '',
                    variableValueType: eventDef.Var.Text ? 'constant' : 'component'
                });
            }

            // Parse Reference (Ref array)
            if (Array.isArray(eventDef.Ref) && eventDef.Ref.length > 0) {
                eventDef.Ref.forEach((ref: string) => {
                    subActions.push({
                        id: uuidv4(),
                        type: 'ReferenceCall',
                        referencedAction: ref
                    });
                });
            }

            // Only create action if there are sub-actions
            if (subActions.length > 0) {
                // Determine action name: Use first Ref value if available, otherwise use Id or fallback
                let actionName: string;
                let refValue: string | undefined;

                if (Array.isArray(eventDef.Ref) && eventDef.Ref.length > 0) {
                    actionName = eventDef.Ref[0]; // Use first child of Ref array as name
                    refValue = eventDef.Ref[0]; // Store the ref value
                } else {
                    actionName = eventDef.Id || `${eventKey}_${index}`;
                    refValue = undefined;
                }

                actions.push({
                    id: uuidv4(),
                    name: actionName,
                    type: eventKey, // Store the event type (LC, ButtonClick, etc.)
                    ref: refValue, // Store the ref value
                    rule: eventDef.Rule || undefined,
                    subActions
                });
            }
        });
    });

    return actions;
}

/**
 * Main parser function to convert full EBML content to our format
 */
export function parseEbmlContent(ebmlContent: any): { rules: Rule[]; variables: Variable[]; actions: Action[] } {
    const variables = parseEbmlVariables(ebmlContent?.Data?.Var || []);
    const rules = parseEbmlRules(ebmlContent?.Ruleset);
    const actions = parseEbmlActions(ebmlContent?.Interface?.Events);

    return { rules, variables, actions };
}
