export * from './component-mapper';
