/* eslint-disable */
/**
 * Form Utilities
 * Utilities for extracting form fields from Nova components and building form schemas
 */

import type { NovaComponent } from '../types/nova-schema.types';

/**
 * Form field types that can be managed by react-hook-form
 */
const FORM_COMPONENT_TYPES = [
    'Input',
    'NumberInput',
    'Checkbox',
    'Radio',
    'RadioGroup',
    'Select',
    'Switch',
    'DatePicker',
    'DateTimePicker',
    'TimePicker',
    'Autocomplete',
    'RangeInput',
    'RichEditor',
    'Upload',
    'FileSelector',
];

/**
 * Extract all form field components from a component tree
 */
export const extractFormFields = (components: NovaComponent[]): NovaComponent[] => {
    const formFields: NovaComponent[] = [];

    const traverse = (component: NovaComponent) => {
        // Check if this is a form component
        if (FORM_COMPONENT_TYPES.includes(component.type)) {
            formFields.push(component);
        }

        // Recursively check children
        if (component.children && component.children.length > 0) {
            component.children.forEach(traverse);
        }
    };

    components.forEach(traverse);
    return formFields;
};

/**
 * Get default value for a form field based on its type and props
 */
const getDefaultValueForField = (component: NovaComponent): any => {
    const { type, props } = component;

    // If value is explicitly set in props, use it
    if (props.value !== undefined) {
        return props.value;
    }

    // If defaultValue is set, use it
    if (props.defaultValue !== undefined) {
        return props.defaultValue;
    }

    // Type-specific defaults
    switch (type) {
        case 'Checkbox':
        case 'Switch':
            return props.checked !== undefined ? props.checked : false;

        case 'NumberInput':
        case 'RangeInput':
            return props.value !== undefined ? props.value : 0;

        case 'DatePicker':
        case 'DateTimePicker':
        case 'TimePicker':
            return props.value !== undefined ? props.value : null;

        case 'Radio':
        case 'RadioGroup':
            return props.value !== undefined ? props.value : '';

        case 'Select':
        case 'Autocomplete':
            return props.multiple ? [] : '';

        case 'Upload':
        case 'FileSelector':
            return props.multiple ? [] : null;

        case 'RichEditor':
            return props.value !== undefined ? props.value : '';

        case 'Input':
        default:
            return props.text !== undefined ? props.text : '';
    }
};

/**
 * Build default values object from form fields for useForm hook
 */
export const buildFormDefaultValues = (components: NovaComponent[]): Record<string, any> => {
    const formFields = extractFormFields(components);
    const defaultValues: Record<string, any> = {};

    formFields.forEach((field) => {
        // Use 'name' prop as the field key, fallback to id
        const fieldName = field.props.name || field.id;

        if (fieldName) {
            defaultValues[fieldName] = getDefaultValueForField(field);
        }
    });

    return defaultValues;
};

/**
 * Check if a component tree contains any form fields
 */
export const hasFormFields = (components: NovaComponent[]): boolean => {
    return extractFormFields(components).length > 0;
};

/**
 * Get all form field names from component tree
 */
export const getFormFieldNames = (components: NovaComponent[]): string[] => {
    const formFields = extractFormFields(components);
    return formFields
        .map((field) => field.props.name || field.id)
        .filter((name): name is string => !!name);
};
