/* eslint-disable */
/**
 * Component Mappings
 * Maps Java Swing classes to Designer Component types
 */

export const CLASS_TO_COMPONENT_MAP: Record<string, string> = {
    'tr.com.cs.aurora.ebml.bean.swing.JCSPage': 'Page',
    'tr.com.cs.aurora.ebml.bean.swing.JCSPanel': 'Container',
    'tr.com.cs.aurora.ebml.bean.swing.JCSRegion': 'Region',
    
    'tr.com.cs.aurora.ebml.bean.swing.JCSTabbedPane': 'TabbedPane',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTabPage': 'TabPage',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTab': 'TabPage',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTextField': 'Input',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTextArea': 'Input',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTextPane': 'Input',
    'tr.com.cs.aurora.ebml.bean.swing.JCSNumberField': 'NumberInput',
    'tr.com.cs.aurora.ebml.bean.swing.JCSDateField': 'DatePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTimeField': 'TimePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSDateTimeField': 'DateTimePicker',
    'tr.com.cs.aurora.ebml.bean.swing.JCSCheckBox': 'Checkbox',
    'tr.com.cs.aurora.ebml.bean.swing.JCSButtonGroup': 'RadioGroup',
    'tr.com.cs.aurora.ebml.bean.swing.JCSRadioButton': 'Radio',
    'tr.com.cs.aurora.ebml.bean.swing.JCSComboBox': 'Select',
    'tr.com.cs.aurora.ebml.bean.swing.JCSCurrencyField': 'Currency',
    'tr.com.cs.aurora.ebml.bean.swing.JCSLabel': 'Label',
    'tr.com.cs.aurora.ebml.bean.swing.JCSTable': 'TableComponent',
    'tr.com.cs.aurora.ebml.bean.swing.JCSButton': 'SetButton',
    'tr.com.cs.aurora.ebml.bean.swing.JCSHandleButtonField': 'HandleButton',
    'tr.com.cs.aurora.ebml.bean.swing.JSeparator': 'Divider',
};

/**
 * Resolves a Java class name to a Designer Component type
 */
export const resolveComponentType = (className: string): string => {
    if (CLASS_TO_COMPONENT_MAP[className]) {
        return CLASS_TO_COMPONENT_MAP[className];
    }
    console.log('Class Mapper not Found', className);
    return 'Unknown';
    // const parts = className.split('.');
    // const rawName = parts[parts.length - 1] || 'Box';
    // if (rawName.startsWith('JCS')) {
    //     return rawName.substring(3);
    // }
    // if (rawName.startsWith('J')) {
    //     return rawName.substring(1);
    // }
    // return rawName;
};

