/* eslint-disable */
/**
 * Nova UI Schema Type Definitions
 * This is the unified schema format for Nova UI Studio
 */

import type { DesignComponent, Rule, Variable, Action } from './design.types';
import type { EbmlEvents, EbmlRuleset, EbmlData } from './ebml.types';

/**
 * Nova UI Schema - Unified format for UI definitions
 * This schema maintains all aspects of the UI definition including:
 * - UI components
 * - Events/Actions
 * - Business rules
 * - Variables
 */
export interface NovaUiSchema {
    /** UI component tree */
    ui: DesignComponent[];

    /** Events and actions (compatible with EbmlContent.Interface.Events) */
    events: NovaEvents;

    /** Business rules (compatible with EbmlContent.Ruleset) */
    ruleset: NovaRuleset;

    /** Variables and data (compatible with EbmlContent.Data) */
    variables: NovaVariables;

    /** Optional custom JavaScript code */
    jsCode?: string;

    /** Optional custom CSS code */
    cssCode?: string;

    /** Metadata about the schema */
    metadata?: {
        version: string;
        name?: string;
        description?: string;
        createdAt?: string;
        updatedAt?: string;
    };
}

/**
 * Nova Events - Simplified action definitions
 */
export interface NovaEvents {
    /** List of actions */
    actions: Action[];
}

/**
 * Nova Ruleset - Business rules
 */
export interface NovaRuleset {
    /** List of rules */
    rules: Rule[];
}

/**
 * Nova Variables - Variable definitions
 */
export interface NovaVariables {
    /** List of variables */
    vars: Variable[];
}

/**
 * Helper to convert NovaUiSchema to EBML format (for backward compatibility)
 */
export interface EbmlCompatibleSchema {
    Interface: {
        Structure: {
            Bean: any; // Will be converted from DesignComponent
        };
        Events?: EbmlEvents;
    };
    Data?: EbmlData;
    Ruleset?: EbmlRuleset;
}
