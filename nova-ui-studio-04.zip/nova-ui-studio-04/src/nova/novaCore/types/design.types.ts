/* eslint-disable */
/**
 * Design Type Definitions
 * Core types for design components, rules, variables, and actions
 * These types are shared across nova-studio and novaCore
 */

/**
 * Design Component - Core component structure for the designer
 */
export interface DesignComponent {
    id: string;
    type: string; // Key in COMPONENT_REGISTRY
    props: Record<string, any>;
    children: DesignComponent[];
    parentId?: string | null;
}

/**
 * Rule - Business rule definition
 */
export interface Rule {
    id: string;
    name: string;
    type: 'Simple' | 'Message' | 'Combination';
    // Simple rule fields
    source?: string;
    sourceMethod?: string;
    operator?: 'ISEMPTY' | 'GTE' | 'LTE' | 'NE' | 'LT' | 'GT' | 'EQ';
    target?: string;
    targetType?: 'constant' | 'variable' | 'component';
    targetMethod?: string;
    // Message rule fields
    messageTitle?: string;
    messageType?: 'OK' | 'OK_CANCEL' | 'YES_NO';
    messageAppearance?: 'INFO' | 'WARNING' | 'ERROR';
    messageContent?: string;
    messageContentType?: 'constant' | 'variable';
    // Combination rule fields
    combinationExpression?: string;
}

/**
 * Variable - Variable definition
 */
export interface Variable {
    id: string;
    name: string;
    initialValue?: string;
    valueType: 'string' | 'integer' | 'boolean' | 'object' | 'array';
    description?: string;
    scope?: 'page' | 'session' | 'global';
}

/**
 * SubAction - Sub-action within an action
 */
export interface SubAction {
    id: string;
    type: 'BeanAction' | 'RemoteCall' | 'ReferenceCall' | 'VariableSetting' | 'PageCall';
    rule?: string;
    // BeanAction fields
    beanValue?: string;
    method?: string;
    parameters?: Array<{ name: string; value: string; valueType: string; valueMethod?: string }>;
    // RemoteCall fields
    service?: string;
    inputs?: Array<{ bagKey: string; value: string; valueType: string }>;
    outputs?: Array<{ bagKey: string; targetVariable: string; targetType: string }>;
    // ReferenceCall fields
    referencedAction?: string;
    // VariableSetting fields
    variableName?: string;
    variableValue?: string;
    variableValueType?: 'constant' | 'variable' | 'component' | 'rule';
    variableValueMethod?: string;
    // PageCall fields
    pageName?: string;
    pageTitle?: string;
    returnAction?: string;
    pageParameters?: Array<{ variableName: string; value: string; valueMethod: string }>;
}

/**
 * Action - Action definition with sub-actions
 */
export interface Action {
    id: string;
    name: string;
    type?: string; // Event type from EBML (e.g., 'LC', 'ButtonClick', etc.)
    ref?: string; // Reference value from EBML events
    rule?: string;
    subActions: SubAction[];
}
