# Nova UI Engine - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Wrap Your App with PageEngineProvider

```tsx
// In your main App.tsx or root component
import { PageEngineProvider } from './nova/nova-ui/engine';

function App() {
  return (
    <PageEngineProvider
      onRemoteCall={async (service, inputs) => {
        // Your API call logic
        const response = await fetch(`/api/${service}`, {
          method: 'POST',
          body: JSON.stringify(inputs)
        });
        return response.json();
      }}
      onNavigate={(pageName, pageTitle, params) => {
        // Your navigation logic
        window.location.href = `/page/${pageName}`;
      }}
    >
      <YourApp />
    </PageEngineProvider>
  );
}
```

### Step 2: Create a Page with Schema

```tsx
import { EnhancedPageComponent } from './nova/nova-ui/engine';

function LoginPage() {
  const schema = {
    ui: [
      {
        id: 'Page',
        type: 'Page',
        props: { pageSize: '800,600' },
        children: [
          {
            id: 'Page.txtUsername',
            type: 'Input',
            props: { label: 'Username' },
            children: []
          },
          {
            id: 'Page.btnLogin',
            type: 'Button',
            props: { text: 'Login' },
            children: []
          }
        ]
      }
    ],
    variables: {
      vars: [
        { id: 'v1', name: 'username', valueType: 'string', initialValue: '' }
      ]
    },
    ruleset: {
      rules: [
        {
          id: 'r1',
          name: 'isUsernameEmpty',
          type: 'Simple',
          source: 'Page.txtUsername',
          sourceMethod: 'getText',
          operator: 'ISEMPTY'
        }
      ]
    },
    events: {
      actions: [
        {
          id: 'a1',
          name: 'login',
          subActions: [
            {
              id: 's1',
              type: 'RemoteCall',
              service: 'AUTH_LOGIN',
              inputs: [
                { bagKey: 'USERNAME', value: 'Page.txtUsername', valueType: 'component' }
              ]
            }
          ]
        }
      ]
    }
  };

  return <EnhancedPageComponent id="Page" novaSchema={schema} />;
}
```

### Step 3: Make Your Components Engine-Aware

```tsx
import { useComponentEngine } from './nova/nova-ui/engine';

function MyInput({ id, label }) {
  const [value, setValue] = useState('');

  // Define methods for bean actions
  const methods = {
    getText: () => value,
    setText: (text) => setValue(text),
    clear: () => setValue('')
  };

  // Register with engine
  const engine = useComponentEngine({ id, methods });

  const handleChange = (e) => {
    const newValue = e.target.value;
    setValue(newValue);
    engine.setValue(newValue);
    engine.fireEvent('textChanged', { value: newValue });
  };

  return <input value={value} onChange={handleChange} />;
}
```

## 📋 Common Patterns

### Pattern 1: Bean Action on Button Click

```typescript
// In your schema's events.actions
{
  id: 'btnSaveClick',
  name: 'saveData',
  subActions: [
    {
      type: 'BeanAction',
      beanValue: 'Page.txtName',
      method: 'getText',
      parameters: []
    }
  ]
}
```

Then attach to button's click event in your component.

### Pattern 2: Remote Call with Input/Output

```typescript
{
  type: 'RemoteCall',
  service: 'USER_GET_BY_ID',
  inputs: [
    { bagKey: 'USER_ID', value: 'userId', valueType: 'variable' }
  ],
  outputs: [
    { bagKey: 'USER_NAME', targetVariable: 'userName', targetType: 'variable' }
  ]
}
```

### Pattern 3: Conditional Execution with Rules

```typescript
// Define a rule
{
  id: 'isFormValid',
  name: 'isFormValid',
  type: 'Combination',
  combinationExpression: '!isNameEmpty AND !isEmailEmpty'
}

// Use in action
{
  id: 'submitForm',
  rule: 'isFormValid',  // Only execute if rule returns true
  subActions: [...]
}
```

### Pattern 4: Variable Setting

```typescript
{
  type: 'VariableSetting',
  variableName: 'currentUser',
  variableValue: 'Page.txtUsername',
  variableValueType: 'component',
  variableValueMethod: 'getText'
}
```

### Pattern 5: Page Navigation

```typescript
{
  type: 'PageCall',
  pageName: 'USER_DETAILS',
  pageTitle: 'User Details',
  pageParameters: [
    { variableName: 'userId', value: 'selectedUserId', valueMethod: '' }
  ]
}
```

## 🔧 Debugging Tips

### 1. Enable Console Logging

The engine logs important events. Check your browser console for:
- Action execution logs
- Rule evaluation results
- Component registration
- Event firing

### 2. Access Engine State

```tsx
function DebugPanel() {
  const engine = usePageEngine();

  console.log('Current phase:', engine.lifecyclePhase);
  console.log('Variables:', Object.fromEntries(engine.variables));
  console.log('Component states:', Object.fromEntries(engine.componentStates));

  return null;
}
```

### 3. Test Rules Independently

```tsx
const isValid = await engine.evaluateRule('myRule');
console.log('Rule result:', isValid);
```

### 4. Test Actions Manually

```tsx
<button onClick={() => engine.executeAction('myAction')}>
  Test Action
</button>
```

## 📚 Next Steps

1. **Read the full documentation**: [ENGINE_DOCUMENTATION.md](./ENGINE_DOCUMENTATION.md)
2. **Study the example**: [EngineUsageExample.tsx](./nova-ui/examples/EngineUsageExample.tsx)
3. **Explore the API**: [PageEngineContext.tsx](./nova-ui/context/PageEngineContext.tsx)
4. **Convert your EBML pages**: Use the existing converters to migrate legacy pages

## 🆘 Common Issues

### Issue: "Action not found"
**Solution**: Check that the action ID matches in both the schema and the executeAction call.

### Issue: "Component method not found"
**Solution**: Ensure the component is registered and the method is added to the methods object.

### Issue: "Rule always returns false"
**Solution**: Verify the source and target values are correct. Test with a simple constant comparison first.

### Issue: "Variables not updating"
**Solution**: Make sure you're using `engine.setVariable()` and the variable name is correct.

## 💡 Pro Tips

1. **Use TypeScript**: The engine is fully typed. Let TypeScript help you catch errors early.

2. **Keep schemas separate**: Store your NovaUiSchema in separate files for better organization.

3. **Reuse rules and actions**: Define common rules and actions once and reference them.

4. **Test incrementally**: Start with simple actions and build up complexity.

5. **Use the designer**: The Nova Studio designer can help you create schemas visually.

## 🤝 Getting Help

- Check the [full documentation](./ENGINE_DOCUMENTATION.md)
- Look at the [example](./nova-ui/examples/EngineUsageExample.tsx)
- Review the [PDF documentation](../assets/docs/analyse.pdf) for legacy EBML concepts

---

Happy coding! 🎉
