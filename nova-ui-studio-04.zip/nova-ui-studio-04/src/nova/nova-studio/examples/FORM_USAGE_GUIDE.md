# Nova Pages Form Management Guide

This guide explains how form data is managed in dynamically generated Nova pages using the `useForm` hook from `seker-ui-lib/hooks/useForm`.

## Overview

The Nova Pages form management system automatically:
- Extracts form fields from your component tree
- Builds default values for each field
- Provides `control` prop to all form components
- Manages form state, validation, and submission

## Architecture

### 1. Form Hook Integration

The `DesignArea` component now uses the `useForm` hook from `seker-ui-lib`:

```typescript
import useForm from '../../../seker-ui-lib/hooks/useForm';
import { buildFormDefaultValues } from '../../novaCore/utils/formUtils';

const defaultValues = useMemo(() => {
  return buildFormDefaultValues(components);
}, [components]);

const methods = useForm({
  defaultValues,
  mode: 'onChange',
});

// Update form when new fields are added, preserving existing user input
useEffect(() => {
  const currentValues = methods.getValues();
  const newDefaultValues = { ...defaultValues };

  // Only add new fields, don't overwrite existing values
  Object.keys(newDefaultValues).forEach((key) => {
    if (!(key in currentValues)) {
      methods.setValue(key, newDefaultValues[key]);
    }
  });
}, [defaultValues]);
```

### 2. Form Provider

The form context is provided via `FormProvider` from `react-hook-form`:

```tsx
<FormProvider {...methods}>
  {components.map(comp => <ComponentRenderer key={comp.id} component={comp} />)}
</FormProvider>
```

### 3. Component Integration

Form components automatically receive the `control` prop via `useFormContext()`:

```typescript
// In InputComponent.tsx
const context = useFormContext();
const control = context ? context.control : undefined;

const safeProps = {
  ...props,
  name: name || id || '',
  control: control as any,
};

return <Input {...safeProps} />;
```

## Supported Form Components

The following components are automatically detected as form fields:

- **Input** - Text, password, email, file inputs
- **NumberInput** - Number fields with formatting
- **Checkbox** - Boolean toggle with label
- **Radio / RadioGroup** - Single selection from options
- **Select** - Dropdown selection
- **Switch** - Toggle switch
- **DatePicker** - Date selection
- **DateTimePicker** - Date and time selection
- **TimePicker** - Time selection
- **Autocomplete** - Search with suggestions
- **RangeInput** - Slider input
- **RichEditor** - Rich text editing
- **Upload** - File upload
- **FileSelector** - File selection button

## How It Works

### 1. Field Extraction

When components are loaded, the system traverses the component tree and extracts all form fields:

```typescript
const extractFormFields = (components: NovaComponent[]): NovaComponent[] => {
  // Recursively finds all form components in the tree
};
```

### 2. Default Values

For each form field, default values are determined:

```typescript
const getDefaultValueForField = (component: NovaComponent): any => {
  // Priority:
  // 1. props.value
  // 2. props.defaultValue
  // 3. Type-specific defaults
};
```

**Default Value Rules:**

| Component Type | Default Value |
|----------------|---------------|
| Input | `''` (empty string) or `props.text` |
| NumberInput | `0` or `props.value` |
| Checkbox / Switch | `false` or `props.checked` |
| Select | `''` or `[]` (if multiple) |
| DatePicker | `null` or `props.value` |
| Radio / RadioGroup | `''` or `props.value` |
| Upload | `null` or `[]` (if multiple) |

### 3. Field Naming

Each form field must have a unique `name` prop:

- If `props.name` is set → use it
- Otherwise → fall back to component `id`

**Example:**
```json
{
  "id": "input-123",
  "type": "Input",
  "props": {
    "name": "username",  // This becomes the field key
    "label": "Username"
  }
}
```

Form data will be: `{ username: '' }`

## Accessing Form Data

### From Within Components

Use the `useFormContext()` hook from `react-hook-form`:

```typescript
import { useFormContext } from 'react-hook-form';

const MyComponent = () => {
  const { watch, getValues, setValue } = useFormContext();

  // Watch a specific field
  const username = watch('username');

  // Get all form values
  const allValues = getValues();

  // Set a field value
  setValue('username', 'john_doe');

  return <div>Username: {username}</div>;
};
```

### From Parent Components

Access the form methods from the `useForm` hook:

```typescript
const methods = useForm({ defaultValues });

// Get current values
const formData = methods.getValues();

// Watch for changes
const watchedData = methods.watch();

// Set values programmatically
methods.setValue('fieldName', 'newValue');
```

## Form Validation

To add validation, pass a `validationSchema` to `useForm`:

```typescript
import * as yup from 'yup';

const validationSchema = {
  username: yup.string().required('Username is required').min(3),
  email: yup.string().email('Invalid email').required('Email is required'),
  age: yup.number().min(18, 'Must be at least 18').required(),
};

const methods = useForm({
  defaultValues,
  validationSchema,
  mode: 'onChange', // Validate on change
});
```

### Validation Modes

- `onChange` - Validate on every change
- `onBlur` - Validate when field loses focus
- `onSubmit` - Validate only on submit
- `all` - Validate on all events

## Form Submission

### Basic Submit Handler

```typescript
const onSubmit = (data: any) => {
  console.log('Form data:', data);
  // Send to API, navigate, etc.
};

<form onSubmit={methods.handleSubmit(onSubmit)}>
  {/* Form components */}
  <button type="submit">Submit</button>
</form>
```

### With Error Handling

```typescript
const onSubmit = async (data: any) => {
  try {
    const response = await fetch('/api/save', {
      method: 'POST',
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error('Failed to save');
    }

    console.log('Saved successfully!');
  } catch (error) {
    methods.setFieldError('_root', 'Failed to save form');
  }
};
```

## Form State

Access form state via `formState`:

```typescript
const { formState } = useFormContext();

// Check if form is dirty (has changes)
const isDirty = formState.isDirty;

// Check if form is valid
const isValid = formState.isValid;

// Get all errors
const errors = formState.errors;

// Check if submitted
const isSubmitted = formState.isSubmitted;
```

## Resetting the Form

```typescript
// Reset to default values
methods.reset();

// Reset to specific values
methods.reset({ username: '', email: '' });

// Reset a single field
methods.resetField('username');
```

## Advanced: Custom Form Logic

### Watching Multiple Fields

```typescript
const { watch } = useFormContext();

const [firstName, lastName] = watch(['firstName', 'lastName']);

const fullName = `${firstName} ${lastName}`;
```

### Conditional Field Validation

```typescript
const { watch } = useFormContext();
const accountType = watch('accountType');

const validationSchema = {
  accountType: yup.string().required(),
  // Only validate companyName if accountType is 'business'
  companyName: yup.string().when('accountType', {
    is: 'business',
    then: (schema) => schema.required('Company name is required'),
  }),
};
```

### Triggering Validation Manually

```typescript
// Trigger validation for specific field
methods.trigger('username');

// Trigger validation for all fields
methods.trigger();
```

## Example: Complete Form Page

```typescript
import React from 'react';
import { useFormContext } from 'react-hook-form';
import { Button, Box } from '../../seker-ui-lib';

const MyFormPage = () => {
  const { handleSubmit, watch, formState } = useFormContext();

  const onSubmit = (data: any) => {
    console.log('Form submitted:', data);
    // Handle form submission
  };

  const formValues = watch();

  return (
    <Box>
      {/* Form components are rendered here via Nova */}

      {/* Debug: Show current form values */}
      <pre>{JSON.stringify(formValues, null, 2)}</pre>

      {/* Submit button */}
      <Button
        onClick={handleSubmit(onSubmit)}
        disabled={!formState.isValid}
      >
        Submit Form
      </Button>

      {/* Show errors */}
      {Object.keys(formState.errors).length > 0 && (
        <Box color="error">
          {Object.entries(formState.errors).map(([field, error]) => (
            <div key={field}>{field}: {error.message}</div>
          ))}
        </Box>
      )}
    </Box>
  );
};
```

## Utilities

### Check if Page Has Form Fields

```typescript
import { hasFormFields } from '../../novaCore/utils/formUtils';

const hasForm = hasFormFields(components);
```

### Get All Field Names

```typescript
import { getFormFieldNames } from '../../novaCore/utils/formUtils';

const fieldNames = getFormFieldNames(components);
// ['username', 'email', 'age', ...]
```

## Best Practices

1. **Always set `name` prop** on form components for clear field identification
2. **Use meaningful names** like `username` instead of `input1`
3. **Validate on change** for better UX (`mode: 'onChange'`)
4. **Reset after submission** to clear the form
5. **Handle errors gracefully** with user-friendly messages
6. **Watch sparingly** to avoid performance issues
7. **Use memoization** for expensive validation schemas

## Troubleshooting

### Field not updating
- Ensure `name` prop is set correctly
- Check that component is wrapped in `FormProvider`
- Verify component type is in the supported list

### Validation not working
- Check `validationSchema` is passed to `useForm`
- Ensure field names match between schema and components
- Verify `mode` is set appropriately

### Form data is empty
- Check that components have `name` or `id` props
- Verify components are recognized form types
- Use `getFormFieldNames()` to debug

## API Reference

### useForm Hook

```typescript
useForm({
  defaultValues: Record<string, any>,
  validationSchema?: object,
  mode?: 'onChange' | 'onBlur' | 'onSubmit' | 'all',
  reValidateMode?: 'onChange' | 'onBlur' | 'onSubmit',
  criteriaMode?: 'firstError' | 'all',
})
```

**Returns:**
- `control` - Form control for components
- `handleSubmit` - Submit handler function
- `watch` - Watch field values
- `getValues` - Get current form values
- `setValue` - Set field value
- `reset` - Reset form
- `resetField` - Reset single field
- `formState` - Form state (errors, isDirty, etc.)
- `clearErrors` - Clear validation errors
- `setFieldError` - Set manual error
- `trigger` - Trigger validation
- `setFocus` - Focus on field

### Form Utilities

```typescript
// Extract form fields from component tree
extractFormFields(components: NovaComponent[]): NovaComponent[]

// Build default values object
buildFormDefaultValues(components: NovaComponent[]): Record<string, any>

// Check if components contain form fields
hasFormFields(components: NovaComponent[]): boolean

// Get all form field names
getFormFieldNames(components: NovaComponent[]): string[]
```
