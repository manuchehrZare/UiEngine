/* eslint-disable */
import { createSchema, type PropertySchema } from './schema';
import { commonProps } from './common';

/**
 * Button properties that can be reused across button-like components
 */
export const buttonProperties: PropertySchema[] = [
    { name: 'children', type: 'string', label: 'Label', group: 'Content' },
    { name: 'variant', type: 'select', label: 'Variant', group: 'Style', options: ['text', 'contained', 'outlined'] },
    { name: 'color', type: 'select', label: 'Color', group: 'Style', options: ['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning'] },
    { name: 'size', type: 'select', label: 'Size', group: 'Style', options: ['small', 'medium', 'large'] },
    { name: 'fullWidth', type: 'boolean', label: 'Full Width', group: 'Style' },
    { name: 'disabled', type: 'boolean', label: 'Disabled', group: 'State' },
    { name: 'type', type: 'select', label: 'Type', group: 'Behavior', options: ['button', 'submit', 'reset'] },
    { name: 'loading', type: 'boolean', label: 'Loading', group: 'State' },
    { name: 'text', type: 'string', label: 'Text', group: 'Content' },
    { name: 'href', type: 'string', label: 'Href', group: 'Behavior' },
    { name: 'icon', type: 'string', label: 'Icon Name', group: 'Content' },
    { name: 'rounded', type: 'boolean', label: 'Rounded', group: 'Style' },
];

/**
 * Set category component schemas
 */
export const SetSchemas = {
    SetButton: createSchema('SetButton', 'Set', [
        ...commonProps,
        ...buttonProperties,
    ], { children: 'Set Button', variant: 'contained', color: 'primary' }),

    TableComponent: createSchema('TableComponent', 'Set', [
        ...commonProps,
        { name: 'adapterInfo', type: 'json', label: 'Adapter Info', group: 'Data' },
        { name: 'background', type: 'string', label: 'Background Color', group: 'Style' },
        { name: 'rows', type: 'array', label: 'Rows', group: 'Data' },
    ]),
};
