/* eslint-disable */
import type { PropertySchema } from './schema';

export const commonProps: PropertySchema[] = [
    { name: 'id', type: 'string', label: 'ID', group: 'Common' },
    { name: 'className', type: 'string', label: 'Class Name', group: 'Common' },
    { name: 'design', type: 'select', label: 'Design', group: 'Common', options: ['default', 'SET'] },
    { name: 'sx', type: 'json', label: 'SX Styles', group: 'Style' },
];

export const commonFormProps: PropertySchema[] = [
    ...commonProps,
    { name: 'name', type: 'string', label: 'Name', group: 'Form', required: true },
    { name: 'label', type: 'string', label: 'Label', group: 'Form' },
    { name: 'helperText', type: 'string', label: 'Helper Text', group: 'Form' },
    { name: 'placeholder', type: 'string', label: 'Placeholder', group: 'Form' },
    { name: 'disabled', type: 'boolean', label: 'Disabled', group: 'State' },
    { name: 'required', type: 'boolean', label: 'Required', group: 'Validation' },
    { name: 'readOnly', type: 'boolean', label: 'Read Only', group: 'State' },
    { name: 'fullWidth', type: 'boolean', label: 'Full Width', group: 'Style', defaultValue: true },
    { name: 'size', type: 'select', label: 'Size', group: 'Style', options: ['small', 'medium'] },
    { name: 'variant', type: 'select', label: 'Variant', group: 'Style', options: ['outlined', 'filled', 'standard'] },
    { name: 'hidden', type: 'boolean', label: 'Hidden', group: 'State' },
    { name: 'labelPlacement', type: 'select', label: 'Label Placement', group: 'Style', options: ['top', 'start'] },
    { name: 'labelWidth', type: 'string', label: 'Label Width', group: 'Style' },
    { name: 'tabIndex', type: 'number', label: 'Tab Index', group: 'Common' },
];

