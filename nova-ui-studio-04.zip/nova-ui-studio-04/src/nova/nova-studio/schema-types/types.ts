// Re-export from novaCore for backward compatibility
export type { PropertySchema, ComponentSchema } from '../../novaCore/types/property-schema.types';
