/* eslint-disable */
// Re-export from novaCore for backward compatibility
export type {
    PropertySchema,
    ComponentSchema
} from '../../novaCore/types/property-schema.types';

export {
    BASE_PROPERTIES,
    createSchema
} from '../../novaCore/types/property-schema.types';
