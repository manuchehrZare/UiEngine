/* eslint-disable */
import React from 'react';
import { COMPONENT_REGISTRY } from '../../novaCore/registry/component-registry';
import type { DesignComponent } from '../../novaCore';


export const PreviewRenderer_dup: React.FC<{ component: DesignComponent }> = ({ component }) => {
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';

    const renderChildren = () => {
         return component.children?.map((child) => (
            <PreviewRenderer_dup key={child.id} component={child} />
        ));
    };

    // Extract key and designComponent from component.props to avoid React warnings
    // React keys must be passed directly, not spread
    // designComponent should not be passed to DOM elements
    const { key: _, designComponent: __, ...propsWithoutKey } = component.props || {};

    // Pass designComponent only if the component explicitly requires it (e.g. TabbedPane)
    // This prevents React warnings about passing unrecognized props to DOM elements
    const extraProps: Record<string, any> = {};
    if (registryItem?.needsDesignComponent) {
        extraProps.designComponent = component;
    }

    return (
        <ActualComponent {...propsWithoutKey} {...extraProps}>
            {registryItem?.isContainer ? renderChildren() : component.props?.children}
        </ActualComponent>
    );
};

