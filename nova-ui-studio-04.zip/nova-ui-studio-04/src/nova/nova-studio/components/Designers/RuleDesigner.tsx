/* eslint-disable */
import React, { useState, useEffect } from 'react';
import { Box, Paper, Button, Typography, Chip, useForm, Input, Select } from '../../../../seker-ui-lib';
import {
    List, ListItem, ListItemText, IconButton,
    Stack, ToggleButtonGroup, ToggleButton, TextField
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import CodeIcon from '@mui/icons-material/Code';
import ViewListIcon from '@mui/icons-material/ViewList';
import { v4 as uuidv4 } from 'uuid';
import Editor from '@monaco-editor/react';
import { useNova, type Rule } from '../../../novaCore';

interface RuleFormValues {
    name: string;
    type: string;
    source: string;
    sourceMethod: string;
    operator: string;
    target: string;
    targetType: string;
    targetMethod: string;
    messageTitle: string;
    messageType: string;
    messageAppearance: string;
    messageContent: string;
    messageContentType: string;
    combinationExpression: string;
}

export const RuleDesigner: React.FC = () => {
    const { rules = [], addRule, updateRule, deleteRule } = useNova();
    const [selectedRule, setSelectedRule] = useState<Rule | null>(null);
    const [isCreating, setIsCreating] = useState(false);
    const [viewMode, setViewMode] = useState<'visual' | 'json'>('visual');

    const [formData, setFormData] = useState<Partial<Rule>>({
        name: '',
        type: 'Simple',
        operator: 'EQ',
        targetType: 'constant',
        messageType: 'OK',
        messageAppearance: 'INFO',
        messageContentType: 'constant'
    });

    const { control, handleSubmit, reset, setValue } = useForm<RuleFormValues>({
        defaultValues: {
            name: '',
            type: 'Simple',
            source: '',
            sourceMethod: '',
            operator: 'EQ',
            target: '',
            targetType: 'constant',
            targetMethod: '',
            messageTitle: '',
            messageType: 'OK',
            messageAppearance: 'INFO',
            messageContent: '',
            messageContentType: 'constant',
            combinationExpression: ''
        }
    });

    const handleSelectRule = (rule: Rule) => {
        setSelectedRule(rule);
        setIsCreating(false);
        setFormData(rule);
        reset({
            name: rule.name || '',
            type: rule.type || 'Simple',
            source: rule.source || '',
            sourceMethod: rule.sourceMethod || '',
            operator: rule.operator || 'EQ',
            target: rule.target || '',
            targetType: rule.targetType || 'constant',
            targetMethod: rule.targetMethod || '',
            messageTitle: rule.messageTitle || '',
            messageType: rule.messageType || 'OK',
            messageAppearance: rule.messageAppearance || 'INFO',
            messageContent: rule.messageContent || '',
            messageContentType: rule.messageContentType || 'constant',
            combinationExpression: rule.combinationExpression || ''
        });
    };

    const handleNewRule = () => {
        setSelectedRule(null);
        setIsCreating(true);
        setFormData({
            name: '',
            type: 'Simple',
            operator: 'EQ',
            targetType: 'constant',
            messageType: 'OK',
            messageAppearance: 'INFO',
            messageContentType: 'constant'
        });
        reset({
            name: '',
            type: 'Simple',
            source: '',
            sourceMethod: '',
            operator: 'EQ',
            target: '',
            targetType: 'constant',
            targetMethod: '',
            messageTitle: '',
            messageType: 'OK',
            messageAppearance: 'INFO',
            messageContent: '',
            messageContentType: 'constant',
            combinationExpression: ''
        });
    };

    const handleCancelEdit = () => {
        setSelectedRule(null);
        setIsCreating(false);
        setFormData({
            name: '',
            type: 'Simple',
            operator: 'EQ',
            targetType: 'constant',
            messageType: 'OK',
            messageAppearance: 'INFO',
            messageContentType: 'constant'
        });
        reset();
    };

    const handleSave = handleSubmit((data:any) => {
        if (!data.name || !data.type) {
            alert('Please fill in required fields: Name and Type');
            return;
        }

        // Validate based on type
        if (data.type === 'Simple' && (!data.source || !data.operator)) {
            alert('Simple rules require Source and Operator');
            return;
        }

        if (data.type === 'Message' && (!data.messageTitle || !data.messageType || !data.messageContent)) {
            alert('Message rules require Title, Type, and Content');
            return;
        }

        if (data.type === 'Combination' && !data.combinationExpression) {
            alert('Combination rules require an Expression');
            return;
        }

        if (selectedRule) {
            updateRule(selectedRule.id, data);
        } else {
            addRule({
                id: uuidv4(),
                ...data
            } as Rule);
        }
        handleCancelEdit();
    });

    const handleDelete = (id: string) => {
        if (window.confirm('Are you sure you want to delete this rule?')) {
            deleteRule(id);
        }
    };

    const getRuleTypeIcon = (type: string) => {
        switch (type) {
            case 'Simple': return '📏';
            case 'Message': return '💬';
            case 'Combination': return '🔗';
            default: return '📋';
        }
    };

    return (
        <Box sx={{ display: 'flex', height: '100%' }}>
            {/* Left Panel - Rule List */}
            <Box sx={{ width: 300, borderRight: 1, borderColor: 'divider', display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Rules</Typography>
                        <Button
                            size="small"
                            variant="contained"
                            iconLeft={<AddIcon />}
                            onClick={handleNewRule}
                            text="New"
                        />
                    </Stack>
                </Box>
                <List sx={{ flexGrow: 1, overflow: 'auto' }}>
                    {rules.map((rule) => (
                        <ListItem
                            key={rule.id}
                            selected={selectedRule?.id === rule.id}
                            button
                            onClick={() => handleSelectRule(rule)}
                            secondaryAction={
                                <IconButton edge="end" size="small" onClick={(e) => {
                                    e.stopPropagation();
                                    handleDelete(rule.id);
                                }}>
                                    <DeleteIcon fontSize="small" />
                                </IconButton>
                            }
                        >
                            <ListItemText
                                primary={
                                    <Stack direction="row" spacing={1} alignItems="center">
                                        <span>{getRuleTypeIcon(rule.type)}</span>
                                        <span>{rule.name}</span>
                                    </Stack>
                                }
                                secondary={rule.type}
                            />
                        </ListItem>
                    ))}
                </List>
            </Box>

            {/* Right Panel - Details/JSON View */}
            <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Rule Designer</Typography>
                        <ToggleButtonGroup
                            value={viewMode}
                            exclusive
                            onChange={(_, newMode) => newMode && setViewMode(newMode)}
                            size="small"
                        >
                            <ToggleButton value="visual">
                                <ViewListIcon sx={{ mr: 1 }} /> Visual
                            </ToggleButton>
                            <ToggleButton value="json">
                                <CodeIcon sx={{ mr: 1 }} /> JSON
                            </ToggleButton>
                        </ToggleButtonGroup>
                    </Stack>
                </Box>

                {viewMode === 'visual' ? (
                    <Box sx={{ p: 3, overflow: 'auto' }}>
                        {!isCreating && !selectedRule ? (
                            <>
                                <Typography variant="body2" color="text.secondary" paragraph>
                                    Rules are used to define conditions for different actions. Rules evaluate to true or false.
                                    If a rule returns true, the associated event/action is fired; otherwise, it's not executed.
                                </Typography>

                                <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
                                    <Typography variant="subtitle2" gutterBottom>Rule Types:</Typography>
                                    <Stack spacing={1}>
                                        <Chip icon={<span>📏</span>} label="Simple - Compare component/variable values" />
                                        <Chip icon={<span>💬</span>} label="Message - Show confirmation/info dialogs" />
                                        <Chip icon={<span>🔗</span>} label="Combination - Combine multiple rules with AND/OR/!" />
                                    </Stack>
                                </Paper>

                                {rules.length === 0 && (
                                    <Box sx={{ mt: 4, textAlign: 'center' }}>
                                        <Typography variant="body1" color="text.secondary">
                                            No rules defined. Click "New" to create a rule.
                                        </Typography>
                                    </Box>
                                )}
                            </>
                        ) : (
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom>
                                    {selectedRule ? 'Edit Rule' : 'New Rule'}
                                </Typography>
                                <Stack spacing={2} sx={{ mt: 2 }}>
                                    <Input
                                        label="Rule Name *"
                                        name="name"
                                        control={control}
                                    />

                                    <Select
                                        label="Rule Type *"
                                        name="type"
                                        control={control}
                                        options={{
                                            data: [
                                                { value: 'Simple', label: 'Simple' },
                                                { value: 'Message', label: 'Message' },
                                                { value: 'Combination', label: 'Combination' }
                                            ],
                                            displayField: 'label',
                                            displayValue: 'value',
                                        }}
                                        setValue={setValue}
                                        onChange={( selectedValue) => setFormData({ ...formData, type:  selectedValue })}
                                    />

                                    {/* Simple Rule Fields */}
                                    {formData.type === 'Simple' && (
                                        <>
                                            <Input
                                                label="Source *"
                                                name="source"
                                                control={control}
                                            />

                                            <Input
                                                label="Source Method"
                                                name="sourceMethod"
                                                control={control}
                                            />

                                            <Select
                                                label="Operator *"
                                                name="operator"
                                                control={control}
                                                options={{
                                                    data: [
                                                        { value: 'ISEMPTY', label: 'ISEMPTY - source is empty' },
                                                        { value: 'EQ', label: 'EQ - source equals target' },
                                                        { value: 'NE', label: 'NE - source not equals target' },
                                                        { value: 'GT', label: 'GT - source greater than target' },
                                                        { value: 'GTE', label: 'GTE - source greater than or equal to target' },
                                                        { value: 'LT', label: 'LT - source less than target' },
                                                        { value: 'LTE', label: 'LTE - source less than or equal to target' }
                                                    ],
                                                    displayField: 'label',
                                                    displayValue: 'value',
                                                }}
                                                setValue={setValue}
                                            />

                                            <Input
                                                label="Target"
                                                name="target"
                                                control={control}
                                            />

                                            <Select
                                                label="Target Type"
                                                name="targetType"
                                                control={control}
                                                options={{
                                                    data: [
                                                        { value: 'constant', label: 'Constant' },
                                                        { value: 'variable', label: 'Variable' },
                                                        { value: 'component', label: 'Component' }
                                                    ],
                                                    displayField: 'label',
                                                    displayValue: 'value',
                                                }}
                                                setValue={setValue}
                                                onChange={( selectedValue) => setFormData({ ...formData, targetType: selectedValue })}
                                            />

                                            {formData.targetType === 'component' && (
                                                <Input
                                                    label="Target Method"
                                                    name="targetMethod"
                                                    control={control}
                                                />
                                            )}
                                        </>
                                    )}

                                    {/* Message Rule Fields */}
                                    {formData.type === 'Message' && (
                                        <>
                                            <Input
                                                label="Message Title *"
                                                name="messageTitle"
                                                control={control}
                                            />

                                            <Select
                                                label="Message Type *"
                                                name="messageType"
                                                control={control}
                                                options={{
                                                    data: [
                                                        { value: 'OK', label: 'OK - Information/Warning (always returns true)' },
                                                        { value: 'OK_CANCEL', label: 'OK/Cancel - Confirmation (OK=true, Cancel=false)' },
                                                        { value: 'YES_NO', label: 'Yes/No - Question (Yes=true, No=false)' }
                                                    ],
                                                    displayField: 'label',
                                                    displayValue: 'value',
                                                }}
                                                setValue={setValue}
                                            />

                                            <Select
                                                label="Appearance"
                                                name="messageAppearance"
                                                control={control}
                                                options={{
                                                    data: [
                                                        { value: 'INFO', label: 'Info' },
                                                        { value: 'WARNING', label: 'Warning' },
                                                        { value: 'ERROR', label: 'Error' }
                                                    ],
                                                    displayField: 'label',
                                                    displayValue: 'value',
                                                }}
                                                setValue={setValue}
                                            />

                                            <TextField
                                                label="Message Content *"
                                                fullWidth
                                                multiline
                                                rows={3}
                                                value={formData.messageContent || ''}
                                                onChange={( selectedValue:any) => setFormData({ ...formData, messageContent: selectedValue })}
                                            />

                                            <Select
                                                label="Content Type"
                                                name="messageContentType"
                                                control={control}
                                                options={{
                                                    data: [
                                                        { value: 'constant', label: 'Constant String' },
                                                        { value: 'variable', label: 'From Variable' }
                                                    ],
                                                    displayField: 'label',
                                                    displayValue: 'value',
                                                }}
                                                setValue={setValue}
                                            />
                                        </>
                                    )}

                                    {/* Combination Rule Fields */}
                                    {formData.type === 'Combination' && (
                                        <TextField
                                            label="Combination Expression *"
                                            fullWidth
                                            multiline
                                            rows={3}
                                            value={formData.combinationExpression || ''}
                                            onChange={( selectedValue:any) => setFormData({ ...formData, combinationExpression:  selectedValue })}
                                        />
                                    )}

                                    <Stack direction="row" spacing={2} justifyContent="flex-end">
                                        <Button onClick={handleCancelEdit} text="Cancel" />
                                        <Button onClick={handleSave} variant="contained" text="Save" />
                                    </Stack>
                                </Stack>
                            </Paper>
                        )}
                    </Box>
                ) : (
                    <Box sx={{ flexGrow: 1 }}>
                        <Editor
                            height="100%"
                            defaultLanguage="json"
                            value={JSON.stringify({ rules }, null, 2)}
                            options={{
                                minimap: { enabled: false },
                                readOnly: true
                            }}
                        />
                    </Box>
                )}
            </Box>
        </Box>
    );
};
