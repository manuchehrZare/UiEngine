/* eslint-disable */
import React, { useState } from 'react';
import { Box, Paper, Button, Typography, Divider,
     Chip, useForm, Input, Select } from '../../../../seker-ui-lib';
import {
    List, ListItem, ListItemText, IconButton,
    Stack, ToggleButton, ToggleButtonGroup, TextField
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import CodeIcon from '@mui/icons-material/Code';
import ViewListIcon from '@mui/icons-material/ViewList';
import { v4 as uuidv4 } from 'uuid';
import Editor from '@monaco-editor/react';
import { useNova, type Variable } from '../../../novaCore';

interface VariableFormValues {
    name: string;
    valueType: string;
    initialValue: string;
    scope: string;
    description: string;
}

export const VariableDesigner: React.FC = () => {
    const { variables = [], addVariable, updateVariable, deleteVariable } = useNova();
    const [selectedVariable, setSelectedVariable] = useState<Variable | null>(null);
    const [isCreating, setIsCreating] = useState(false);
    const [viewMode, setViewMode] = useState<'visual' | 'json'>('visual');

    const [formData, setFormData] = useState<Partial<Variable>>({
        name: '',
        valueType: 'string',
        initialValue: '',
        scope: 'page',
        description: ''
    });

    const { control, handleSubmit, reset, setValue } = useForm<VariableFormValues>({
        defaultValues: {
            name: '',
            valueType: 'string',
            initialValue: '',
            scope: 'page',
            description: ''
        }
    });

    const handleSelectVariable = (variable: Variable) => {
        setSelectedVariable(variable);
        setIsCreating(false);
        setFormData(variable);
        reset({
            name: variable.name || '',
            valueType: variable.valueType || 'string',
            initialValue: variable.initialValue || '',
            scope: variable.scope || 'page',
            description: variable.description || ''
        });
    };

    const handleNewVariable = () => {
        setSelectedVariable(null);
        setIsCreating(true);
        setFormData({
            name: '',
            valueType: 'string',
            initialValue: '',
            scope: 'page',
            description: ''
        });
        reset({
            name: '',
            valueType: 'string',
            initialValue: '',
            scope: 'page',
            description: ''
        });
    };

    const handleCancelEdit = () => {
        setSelectedVariable(null);
        setIsCreating(false);
        setFormData({
            name: '',
            valueType: 'string',
            initialValue: '',
            scope: 'page',
            description: ''
        });
        reset();
    };

    const handleSave = handleSubmit((data:any) => {
        if (!data.name || !data.valueType) {
            alert('Please fill in required fields: Name and Value Type');
            return;
        }

        if (selectedVariable) {
            updateVariable(selectedVariable.id, data);
        } else {
            addVariable({
                id: uuidv4(),
                ...data
            } as Variable);
        }
        handleCancelEdit();
    });

    const handleDelete = (id: string) => {
        if (window.confirm('Are you sure you want to delete this variable?')) {
            deleteVariable(id);
        }
    };

    const handleJsonChange = (value: string | undefined) => {
        // For JSON view in future enhancement
    };

    const builtInVariables = [
        { name: '$today', description: 'Current date' },
        { name: '$menuKey', description: 'Menu key property from menu definition' },
        { name: '$clienthostname', description: 'Client\'s host name' },
        { name: '$clientosname', description: 'Operating system name' },
        { name: '$securitylevel', description: 'Security level of current user' },
        { name: '$RC_ERROR_ID', description: 'Remote call error ID (-1 if successful)' }
    ];

    return (
        <Box sx={{ display: 'flex', height: '100%' }}>
            {/* Left Panel - Variable List */}
            <Box sx={{ width: 300, borderRight: 1, borderColor: 'divider', display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Variables</Typography>
                        <Button
                            size="small"
                            variant="contained"
                            iconLeft={<AddIcon />}
                            onClick={handleNewVariable}
                            text="New"
                        />
                    </Stack>
                </Box>
                <List sx={{ flexGrow: 1, overflow: 'auto' }}>
                    {variables.map((variable) => (
                        <ListItem
                            key={variable.id}
                            selected={selectedVariable?.id === variable.id}
                            button
                            onClick={() => handleSelectVariable(variable)}
                            secondaryAction={
                                <IconButton edge="end" size="small" onClick={(e) => {
                                    e.stopPropagation();
                                    handleDelete(variable.id);
                                }}>
                                    <DeleteIcon fontSize="small" />
                                </IconButton>
                            }
                        >
                            <ListItemText
                                primary={variable.name}
                                secondary={`Type: ${variable.valueType}`}
                            />
                        </ListItem>
                    ))}
                </List>
            </Box>

            {/* Right Panel - Details/JSON View */}
            <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Variable Designer</Typography>
                        <ToggleButtonGroup
                            value={viewMode}
                            exclusive
                            onChange={(_, newMode) => newMode && setViewMode(newMode)}
                            size="small"
                        >
                            <ToggleButton value="visual">
                                <ViewListIcon sx={{ mr: 1 }} /> Visual
                            </ToggleButton>
                            <ToggleButton value="json">
                                <CodeIcon sx={{ mr: 1 }} /> JSON
                            </ToggleButton>
                        </ToggleButtonGroup>
                    </Stack>
                </Box>

                {viewMode === 'visual' ? (
                    <Box sx={{ p: 3, overflow: 'auto' }}>
                        {!isCreating && !selectedVariable ? (
                            <>
                                <Typography variant="body2" color="text.secondary" paragraph>
                                    ERE Store-Variables are used for storing values in the page. Variables can be assigned to components,
                                    used in rule definitions, passed to services, and used as input/output for popups.
                                </Typography>

                                <Divider sx={{ my: 3 }}>
                                    <Chip label="Built-in Variables (Read-only)" />
                                </Divider>

                                <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                                    <List dense>
                                        {builtInVariables.map((builtIn) => (
                                            <ListItem key={builtIn.name}>
                                                <ListItemText
                                                    primary={<Typography variant="body2" fontFamily="monospace">{builtIn.name}</Typography>}
                                                    secondary={builtIn.description}
                                                />
                                            </ListItem>
                                        ))}
                                    </List>
                                </Paper>

                                {variables.length === 0 && (
                                    <Box sx={{ mt: 4, textAlign: 'center' }}>
                                        <Typography variant="body1" color="text.secondary">
                                            No variables defined. Click "New" to create a variable.
                                        </Typography>
                                    </Box>
                                )}
                            </>
                        ) : (
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom>
                                    {selectedVariable ? 'Edit Variable' : 'New Variable'}
                                </Typography>
                                <Stack spacing={2} sx={{ mt: 2 }}>
                                    <Input
                                        label="Variable Name *"
                                        name="name"
                                        control={control}
                                    />

                                    <Select
                                        label="Value Type *"
                                        name="valueType"
                                        control={control}
                                        options={{
                                            data: [
                                                { value: 'string', label: 'String' },
                                                { value: 'integer', label: 'Integer' },
                                                { value: 'boolean', label: 'Boolean' },
                                                { value: 'object', label: 'Object' },
                                                { value: 'array', label: 'Array' }
                                            ],
                                            displayField: 'label',
                                            displayValue: 'value',
                                        }}
                                        setValue={setValue}
                                    />

                                    <Input
                                        label="Initial Value"
                                        name="initialValue"
                                        control={control}
                                    />

                                    <Select
                                        label="Scope"
                                        name="scope"
                                        control={control}
                                        options={{
                                            data: [
                                                { value: 'page', label: 'Page' },
                                                { value: 'session', label: 'Session' },
                                                { value: 'global', label: 'Global' }
                                            ],
                                            displayField: 'label',
                                            displayValue: 'value',
                                        }}
                                        setValue={setValue}
                                    />

                                    <TextField
                                        label="Description"
                                        fullWidth
                                        multiline
                                        rows={2}
                                        value={formData.description || ''}
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                    />

                                    <Stack direction="row" spacing={2} justifyContent="flex-end">
                                        <Button onClick={handleCancelEdit} text="Cancel" />
                                        <Button onClick={handleSave} variant="contained" text="Save" />
                                    </Stack>
                                </Stack>
                            </Paper>
                        )}
                    </Box>
                ) : (
                    <Box sx={{ flexGrow: 1 }}>
                        <Editor
                            height="100%"
                            defaultLanguage="json"
                            value={JSON.stringify({ variables }, null, 2)}
                            onChange={handleJsonChange}
                            options={{
                                minimap: { enabled: false },
                                readOnly: true
                            }}
                        />
                    </Box>
                )}
            </Box>

        </Box>
    );
};
