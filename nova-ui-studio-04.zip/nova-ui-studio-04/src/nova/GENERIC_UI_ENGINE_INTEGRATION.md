# GenericUI Engine Integration Guide

## What Was Changed

The `GenericUi` component ([nova-ui/index.tsx](./nova-ui/index.tsx)) has been enhanced with the PageEngineContext to enable full execution of:
- ✅ Actions (Bean Actions, Remote Calls, Reference Calls, Variable Settings, Page Calls)
- ✅ Rules (Simple, Message, Combination)
- ✅ Variables (Page, Session, Global scopes)
- ✅ Events (Component events with action binding)

## Changes Made

### 1. Added PageEngineProvider Wrapper

The GenericUi component now wraps the entire UI with `PageEngineProvider`:

```tsx
<PageDefinitionsProvider>
  <PageEngineProvider
    onRemoteCall={handleRemoteCall}
    onNavigate={handleNavigate}
    onShowPopup={handleShowPopup}
  >
    <GenericUiContent />
  </PageEngineProvider>
</PageDefinitionsProvider>
```

### 2. Schema Loading in DynamicRenderer

The `DynamicRenderer` component now loads the schema into the engine:

```tsx
const engine = usePageEngine();

useEffect(() => {
  if (novaSchema) {
    // Load schema into engine for action/rule/variable execution
    engine.loadSchema(novaSchema);

    // Import into designer for rendering
    importDesign(JSON.stringify(novaSchema));
    setMode('preview');
  }
}, [novaSchema, importDesign, setMode, engine]);
```

### 3. Remote Call Handler

Integrated with your backend API (currently uses placeholder):

```tsx
const handleRemoteCall = async (serviceName: string, inputs: any) => {
  const response = await fetch(`/api/services/${serviceName}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(inputs),
  });
  return response.json();
};
```

**TODO**: Update the `/api/services/${serviceName}` endpoint to match your actual backend API.

### 4. Navigation Handler

Uses React Router for page navigation:

```tsx
const handleNavigate = (pageName: string, pageTitle?: string, params?: any) => {
  navigate(`/nova-page/${pageName}`, {
    state: { pageTitle, params }
  });
};
```

### 5. Popup Handler

Placeholder for popup/modal dialogs:

```tsx
const handleShowPopup = async (popupName: string, data: any) => {
  // TODO: Implement modal/popup dialog
  console.log(`Show popup: ${popupName}`, data);
  return { closed: true };
};
```

### 6. Engine Debug Panel

Added a debug panel to inspect and test the engine state:

- Shows lifecycle phase
- Lists all variables
- Lists all component states
- Lists all actions (with execute button)
- Lists all rules (with test button)

Click "Engine Debug" button in the toolbar to open.

## How It Works

### 1. Page Selection Flow

```
User selects page
    ↓
EBML content converted to NovaUiSchema
    ↓
Schema loaded into PageEngineContext
    ↓
Schema imported into DesignerContext (for rendering)
    ↓
Page rendered with engine context active
    ↓
Components can now execute actions/rules/variables
```

### 2. Action Execution Flow

```
Event triggered (e.g., button click)
    ↓
Engine finds subscribed actions
    ↓
Evaluates action's rule (if any)
    ↓
Executes sub-actions sequentially:
  - Bean Action → Calls component methods
  - Remote Call → Calls backend service
  - Reference Call → Executes another action
  - Variable Setting → Updates variable
  - Page Call → Navigates to another page
```

### 3. Rule Evaluation Flow

```
Rule needs evaluation
    ↓
Engine checks rule type:
  - Simple → Compare source vs target
  - Message → Show dialog to user
  - Combination → Evaluate expression of other rules
    ↓
Returns true/false
```

## Testing the Integration

### 1. Select a Page with Actions

1. Run the application
2. Navigate to Nova UI Explorer
3. Select a page from the sidebar
4. Click "Engine Debug" to see the loaded schema

### 2. Test Variables

In the Engine Debug panel:
- View all variables and their values
- Variables are automatically initialized from the schema

### 3. Test Actions

In the Engine Debug panel:
- Click any action name to execute it
- Watch the console for execution logs
- Actions with bean actions will call component methods
- Actions with remote calls will call your API

### 4. Test Rules

In the Engine Debug panel:
- Click "Test" next to any rule
- An alert will show the evaluation result
- Check console for detailed logs

## Customization

### Update API Endpoint

Edit the `handleRemoteCall` function in [GenericUi](./nova-ui/index.tsx):

```tsx
const handleRemoteCall = async (serviceName: string, inputs: any) => {
  // Replace with your actual endpoint
  const response = await fetch(`https://your-api.com/services/${serviceName}`, {
    method: 'POST',
    body: JSON.stringify(inputs),
  });
  return response.json();
};
```

### Add Authentication

```tsx
const handleRemoteCall = async (serviceName: string, inputs: any) => {
  const token = localStorage.getItem('authToken');

  const response = await fetch(`/api/services/${serviceName}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(inputs),
  });
  return response.json();
};
```

### Implement Popup Dialogs

Replace the `handleShowPopup` function with actual modal logic:

```tsx
const handleShowPopup = async (popupName: string, data: any) => {
  // Example using a modal library
  const result = await openModal({
    component: PopupRegistry[popupName],
    props: data
  });
  return result;
};
```

### Custom Error Handling

```tsx
const handleRemoteCall = async (serviceName: string, inputs: any) => {
  try {
    const response = await fetch(`/api/services/${serviceName}`, {
      method: 'POST',
      body: JSON.stringify(inputs),
    });

    if (!response.ok) {
      // Log to error tracking service
      trackError(`Service ${serviceName} failed`, response);

      return {
        ERROR: true,
        ERROR_ID: response.status.toString(),
        ERROR_MESSAGE: `Service failed with status ${response.status}`
      };
    }

    return response.json();
  } catch (error) {
    // Handle network errors
    return {
      ERROR: true,
      ERROR_ID: '999',
      ERROR_MESSAGE: error.message
    };
  }
};
```

## Console Logging

The engine logs important events to the console:

- `[Engine] Remote call to service: SERVICE_NAME` - Remote call initiated
- `[Engine] Service SERVICE_NAME response:` - Remote call completed
- `[Engine] Service SERVICE_NAME error:` - Remote call failed
- `[Engine] Navigate to page: PAGE_NAME` - Page navigation requested
- `[Engine] Show popup: POPUP_NAME` - Popup requested
- `[Debug] Executing action: ACTION_NAME` - Action executed from debug panel
- `[Debug] Rule RULE_NAME evaluated to: true/false` - Rule tested from debug panel

## Next Steps

1. **Test with Real Data**: Select pages from your converted EBML definitions
2. **Connect Backend**: Update the `handleRemoteCall` to point to your actual API
3. **Implement Popups**: Create popup/modal components for popup actions
4. **Add Error Handling**: Enhance error handling for production use
5. **Component Integration**: Gradually migrate components to use `useComponentEngine` hook
6. **Add Logging**: Integrate with your logging/monitoring service

## Troubleshooting

### Actions Not Executing

Check:
- Schema is loaded (visible in Engine Debug panel)
- Action exists in schema
- Rule evaluation (if action has a rule)
- Console for error messages

### Remote Calls Failing

Check:
- API endpoint is correct
- Network tab in DevTools
- CORS settings on backend
- Authentication/authorization

### Variables Not Updating

Check:
- Variable name is correct
- Variable scope is appropriate
- Engine Debug panel shows variable
- Console for errors

### Rules Not Working

Check:
- Rule type is correct
- Source and target are valid
- Operator is appropriate for the comparison
- Test rule independently using Engine Debug

## Benefits of This Integration

1. **Full Legacy Support**: All EBML actions, rules, and variables work
2. **Real-time Testing**: Debug panel allows instant testing
3. **Easy Migration**: Can gradually move from designer preview to production
4. **Extensible**: Easy to add custom handlers for remote calls and popups
5. **Type-Safe**: Full TypeScript support throughout
6. **Developer-Friendly**: Console logs and debug panel make development easy

## Example: Complete Page with Actions

Here's what happens when you load a page with the engine:

1. **Page Selection**: User selects "MOP001_ADMIN_SPECIALITY_DEFINITION"
2. **Conversion**: EBML content → NovaUiSchema
3. **Engine Load**: Schema loaded into PageEngineContext
4. **Variables Init**: All variables initialized with default values
5. **Components Register**: Each component registers with engine
6. **Events Setup**: Event subscriptions created for all events in schema
7. **Page Ready**: Page is now fully interactive with actions/rules/variables

When user interacts:

1. **User clicks button** → Event fired
2. **Engine checks rule** → Rule evaluated
3. **Action executes** → Sub-actions run sequentially
4. **Remote call** → Backend API called
5. **Variables updated** → State synchronized
6. **UI updates** → React re-renders

All of this happens automatically with the engine integration!

---

For more information, see:
- [Engine Documentation](./ENGINE_DOCUMENTATION.md)
- [Quick Start Guide](./QUICK_START_GUIDE.md)
- [Implementation Summary](./IMPLEMENTATION_SUMMARY.md)
