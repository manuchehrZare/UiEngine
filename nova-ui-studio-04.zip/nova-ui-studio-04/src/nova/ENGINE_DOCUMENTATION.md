# Nova UI Engine Context Documentation

## Overview

The Nova UI Engine Context is a comprehensive system for managing the lifecycle of pages, events, actions, rules, and variables in your React application. It provides a bridge between the legacy EBML Java application and the new React implementation.

## Key Features

1. **Bean Actions**: Actions can be assigned to UI components and executed via component methods
2. **Data Communication**: Context can send and receive data to/from popup windows and region sub-pages
3. **Page Lifecycle**: Complete page lifecycle management from initialization to cleanup
4. **Rule-Based Engine**: Conditional execution based on Simple, Message, and Combination rules
5. **Event System**: Event-driven architecture with action execution
6. **Variable Management**: Page, session, and global variable support

## Architecture

```
PageEngineProvider (Context)
├── Lifecycle Management
├── Component State Registry
├── Variable Management
├── Rule Engine
├── Action Executor
│   ├── Bean Actions
│   ├── Remote Calls
│   ├── Reference Calls
│   ├── Variable Settings
│   └── Page Calls
└── Event Bus
```

## Core Concepts

### 1. Page Lifecycle

Pages go through the following lifecycle phases:

- `initializing`: Page is being set up
- `loading`: Schema and data are being loaded
- `loaded`: Schema loaded, ready to initialize
- `ready`: Page is fully ready for user interaction
- `unloading`: Page is being torn down
- `unloaded`: Page cleanup complete

### 2. Component Registration

Components register themselves with the engine to:
- Expose methods for bean actions
- Maintain state managed by the engine
- Fire and listen to events

### 3. Rules

Three types of rules:

#### Simple Rules
Compare a source value with a target value using operators:
- `ISEMPTY`: Source is empty
- `EQ`: Source equals target
- `NE`: Source not equals target
- `GT`: Source greater than target
- `LT`: Source less than target
- `GTE`: Source greater than or equal to target
- `LTE`: Source less than or equal to target

#### Message Rules
Show confirmation or information dialogs:
- `OK`: Information message (always returns true)
- `OK_CANCEL`: Confirmation dialog
- `YES_NO`: Question dialog

#### Combination Rules
Combine multiple rules using logical operators (AND, OR, !)

### 4. Actions

Actions contain a sequence of sub-actions:

#### Bean Actions
Call methods on UI components:
```typescript
{
  type: 'BeanAction',
  beanValue: 'Page.txtUsername',
  method: 'setText',
  parameters: [{ value: 'John', valueType: 'constant' }]
}
```

#### Remote Calls
Call server-side services:
```typescript
{
  type: 'RemoteCall',
  service: 'USER_SERVICE_GET',
  inputs: [{ bagKey: 'USER_ID', value: '123', valueType: 'constant' }],
  outputs: [{ bagKey: 'USER_NAME', targetVariable: 'username', targetType: 'variable' }]
}
```

#### Reference Calls
Execute other actions:
```typescript
{
  type: 'ReferenceCall',
  referencedAction: 'validateForm'
}
```

#### Variable Settings
Set variable values:
```typescript
{
  type: 'VariableSetting',
  variableName: 'isValid',
  variableValue: 'true',
  variableValueType: 'constant'
}
```

#### Page Calls
Navigate to other pages:
```typescript
{
  type: 'PageCall',
  pageName: 'USER_DETAIL',
  pageTitle: 'User Details',
  pageParameters: [{ variableName: 'userId', value: '123' }]
}
```

### 5. Variables

Variables can store data at different scopes:
- **Page scope**: Available only within the current page
- **Session scope**: Available across pages in the same session
- **Global scope**: Available application-wide

#### Built-in Variables
- `$today`: Current date
- `$menuKey`: Menu key from session
- `$clienthostname`: Client hostname
- `$clientosname`: Operating system name
- `$securitylevel`: Current user security level
- `$RC_ERROR_ID`: Last remote call error ID (-1 for success)

## Usage

### 1. Basic Setup

Wrap your application with `PageEngineProvider`:

```tsx
import { PageEngineProvider } from './nova/nova-ui/context/PageEngineContext';

function App() {
  const handleRemoteCall = async (serviceName: string, inputs: any) => {
    // Call your backend service
    const response = await fetch(`/api/${serviceName}`, {
      method: 'POST',
      body: JSON.stringify(inputs)
    });
    return response.json();
  };

  const handleNavigate = (pageName: string, pageTitle?: string, params?: any) => {
    // Navigate to another page
    router.push(`/page/${pageName}`, { state: params });
  };

  return (
    <PageEngineProvider
      onRemoteCall={handleRemoteCall}
      onNavigate={handleNavigate}
    >
      <YourApp />
    </PageEngineProvider>
  );
}
```

### 2. Using Enhanced Page Component

```tsx
import { EnhancedPageComponent } from './nova/nova-ui/components/EnhancedPageComponent';
import { usePageEngine } from './nova/nova-ui/context/PageEngineContext';

function MyPage() {
  const novaSchema = {
    ui: [...], // UI components
    variables: { vars: [...] },
    ruleset: { rules: [...] },
    events: { actions: [...] }
  };

  return (
    <EnhancedPageComponent
      id="Page"
      novaSchema={novaSchema}
      pageSize="960,700"
    />
  );
}
```

### 3. Creating Engine-Aware Components

```tsx
import { useComponentEngine } from './nova/nova-ui/hooks/useComponentEngine';

function MyInput({ id, ...props }) {
  // Define component methods for bean actions
  const methods = {
    getText: () => value,
    setText: (text) => setValue(text),
    clear: () => setValue(''),
    focus: () => inputRef.current?.focus()
  };

  // Register with engine
  const engine = useComponentEngine({
    id,
    initialState: { value: '' },
    methods
  });

  // Fire events
  const handleChange = (e) => {
    const newValue = e.target.value;
    setValue(newValue);
    engine.setValue(newValue);
    engine.fireEvent('textChanged', { value: newValue });
  };

  return <input value={value} onChange={handleChange} />;
}
```

### 4. Working with Variables

```tsx
function MyComponent() {
  const engine = usePageEngine();

  // Get variable
  const username = engine.getVariable('username');

  // Set variable
  engine.setVariable('username', 'John Doe');

  // Get built-in variable
  const today = engine.getBuiltInVariable('$today');
}
```

### 5. Executing Actions Manually

```tsx
function MyComponent() {
  const engine = usePageEngine();

  const handleClick = async () => {
    // Execute action by ID
    await engine.executeAction('validateAndSubmit');
  };

  return <button onClick={handleClick}>Submit</button>;
}
```

### 6. Evaluating Rules

```tsx
function MyComponent() {
  const engine = usePageEngine();

  const checkValidity = async () => {
    const isValid = await engine.evaluateRule('isFormValid');
    if (isValid) {
      console.log('Form is valid!');
    }
  };
}
```

### 7. Page-to-Popup Communication

```tsx
// In parent page
function ParentPage() {
  const engine = usePageEngine();

  const openPopup = () => {
    engine.sendDataToPopup('USER_SEARCH_POPUP', {
      searchCriteria: 'active'
    });
  };
}

// In popup
function PopupPage() {
  const engine = usePageEngine();

  // Access data sent from parent
  const searchCriteria = engine.pageData.searchCriteria;

  const returnData = () => {
    // Return data to parent
    engine.receiveDataFromPopup({
      selectedUserId: '123',
      selectedUserName: 'John Doe'
    });
  };
}
```

### 8. Handling Page Load Events

```tsx
import { usePageLoad } from './nova/nova-ui/hooks/usePageEvent';

function MyPage() {
  // Execute action on page load
  usePageLoad('initializePageAction');

  return <div>Page Content</div>;
}
```

## Component Method Naming Conventions

For bean actions to work correctly, components should implement standard methods:

### Text Components (Input, TextArea)
- `getText()`: Get text value
- `setText(text)`: Set text value
- `clear()`: Clear the text
- `isEmpty()`: Check if empty

### Select Components (ComboBox, Dropdown)
- `getValue()`: Get selected value
- `setValue(value)`: Set selected value
- `getSelectedText()`: Get selected display text
- `getSelectedValue()`: Get selected value
- `clear()`: Clear selection

### Button Components
- `click()`: Trigger click
- `setEnabled(enabled)`: Enable/disable button
- `setVisible(visible)`: Show/hide button

### Table Components
- `getRowCount()`: Get number of rows
- `getSelectedRow()`: Get selected row index
- `getSelectedRows()`: Get all selected row indices
- `getCellValue(row, col)`: Get cell value
- `setCellValue(row, col, value)`: Set cell value
- `addRow(data)`: Add new row
- `deleteRow(row)`: Delete row

### Common Methods (All Components)
- `setEnabled(enabled)`: Enable/disable component
- `setVisible(visible)`: Show/hide component
- `focus()`: Set focus to component
- `blur()`: Remove focus from component

## Best Practices

1. **Always register components**: Use `useComponentEngine` hook in all interactive components
2. **Provide all necessary methods**: Implement all methods that might be called by bean actions
3. **Fire events appropriately**: Fire events when component state changes
4. **Use variables for shared state**: Use engine variables instead of component state for data shared across components
5. **Keep actions atomic**: Each sub-action should do one thing
6. **Use rules for conditional logic**: Don't hardcode conditions in actions, use rules instead
7. **Handle errors gracefully**: Check `$RC_ERROR_ID` after remote calls
8. **Clean up on unmount**: The engine handles cleanup, but always ensure components are properly registered/unregistered

## Migration from Legacy EBML

1. **Convert EBML to NovaUiSchema**: Use the existing converters in `EbmlConverter.ts`
2. **Map component classes**: Ensure all EBML component classes map to React components
3. **Implement component methods**: Add all methods used by bean actions
4. **Test action execution**: Verify all actions work as expected
5. **Test rule evaluation**: Verify rules evaluate correctly
6. **Test remote calls**: Ensure service integration works

## Troubleshooting

### Action not executing
- Check if action ID/name is correct
- Verify rule is evaluating to true
- Check console for errors

### Component method not found
- Ensure component is registered with engine
- Verify method name matches exactly
- Check method is added to methods object

### Variable not updating
- Confirm variable name is correct
- Check variable scope
- Verify setValue is called

### Rule always returns false
- Check source and target values
- Verify operator is correct
- Test rule independently

## API Reference

See [PageEngineContext.tsx](./nova/nova-ui/context/PageEngineContext.tsx) for complete API documentation.

## Examples

See [EngineUsageExample.tsx](./nova/nova-ui/examples/EngineUsageExample.tsx) for complete working example.
