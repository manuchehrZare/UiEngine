# Nova UI Engine

> Complete engine context for managing page lifecycle, events, actions, rules, and variables

## Quick Import

```typescript
import {
  // Context
  PageEngineProvider,
  usePageEngine,

  // Hooks
  useComponentEngine,
  usePageLoad,
  usePageEvent,

  // Components
  EnhancedPageComponent,
  EnhancedInputComponent
} from './nova/nova-ui/engine';
```

## 30-Second Example

```tsx
// 1. Wrap app with provider
<PageEngineProvider onRemoteCall={apiCall} onNavigate={navigate}>

  // 2. Use enhanced page component
  <EnhancedPageComponent id="Page" novaSchema={schema} />

</PageEngineProvider>

// 3. Make components engine-aware
function MyInput({ id }) {
  const engine = useComponentEngine({
    id,
    methods: {
      getText: () => value,
      setText: (v) => setValue(v)
    }
  });

  return <input value={value} onChange={e => {
    setValue(e.target.value);
    engine.fireEvent('textChanged');
  }} />;
}
```

## Features

- ✅ **Bean Actions**: Call component methods from actions
- ✅ **Popup Communication**: Send/receive data between pages
- ✅ **Page Root**: Page is the root component
- ✅ **Rule Engine**: Simple, Message, Combination rules
- ✅ **5 Action Types**: Bean, Remote Call, Reference, Variable Setting, Page Call
- ✅ **Variables**: Page, session, global scope
- ✅ **Event System**: Subscribe and fire events
- ✅ **Lifecycle**: Complete page lifecycle management

## Documentation

- 📖 [Full Documentation](../../ENGINE_DOCUMENTATION.md)
- 🚀 [Quick Start Guide](../../QUICK_START_GUIDE.md)
- 📋 [Implementation Summary](../../IMPLEMENTATION_SUMMARY.md)
- 💡 [Usage Example](../examples/EngineUsageExample.tsx)

## Key Files

| File | Purpose |
|------|---------|
| [PageEngineContext.tsx](../context/PageEngineContext.tsx) | Main engine context |
| [useComponentEngine.ts](../hooks/useComponentEngine.ts) | Component integration hook |
| [usePageEvent.ts](../hooks/usePageEvent.ts) | Event handling hooks |
| [EnhancedPageComponent.tsx](../components/EnhancedPageComponent.tsx) | Page with engine |
| [EngineUsageExample.tsx](../examples/EngineUsageExample.tsx) | Working example |

## Support

Check the documentation files listed above for detailed information on:
- Architecture and concepts
- API reference
- Usage patterns
- Migration guide
- Troubleshooting
