/* eslint-disable */
/**
 * Nova UI Engine - Main exports
 */

// Context
export { NovaProvider, useNova, useNovaOptional } from '../../novaCore/context/NovaContext';
export type {
    ComponentState,
    PageLifecyclePhase,
    EventSubscription,
    PageData,
    RemoteCallStatus
} from '../../novaCore/context/NovaContext';

// Hooks
export { useComponentEngine } from '../hooks/useComponentEngine';
export type { UseComponentEngineOptions } from '../hooks/useComponentEngine';

export { usePageEvent, usePageLoad, usePageUnload } from '../hooks/usePageEvent';

// Components
export { EnhancedPageComponent } from '../components/EnhancedPageComponent';
export type { EnhancedPageComponentProps } from '../components/EnhancedPageComponent';

export { EnhancedInputComponent } from '../components/EnhancedInputComponent';

// Types from schema
export type { NovaUiSchema, NovaEvents, NovaRuleset, NovaVariables } from '../../novaCore/types/nova-schema.types';
export type { Action, Rule, Variable, SubAction } from '../../nova-studio/context/DesignerContext';
