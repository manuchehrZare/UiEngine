/* eslint-disable */
import React, { useState, useMemo, useEffect } from 'react';
import { Box, Paper, Typography, Grid, GridItem, Button } from '../../seker-ui-lib';
import { TextField } from '@mui/material';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import type { PageDefinition } from '../novaCore/types/ebml.types';
import type { NovaUiSchema } from '../novaCore/types/nova-schema.types';
import { DesignArea } from '../nova-studio/components/DesignArea';
import { useNavigate } from 'react-router-dom';
import { mapEbmlContentToNovaSchema } from '../novaCore/converters/nova-schema-mapper';
import { NovaProvider, useNova } from '../novaCore/context/NovaContext';
import { EngineDebugPanel } from './components';

const EditInDesignerButton: React.FC<{ novaSchema: NovaUiSchema | null }> = ({ novaSchema }) => {
    const navigate = useNavigate();

    const handleOpenDesigner = () => {
        if (!novaSchema) return;
        navigate('/nova-studio', {
            state: {
                importedDesign: JSON.stringify(novaSchema),
            },
        });
    };

    return (
        <Button
            variant="contained"
            color="primary"
            size="small"
            disabled={!novaSchema}
            onClick={handleOpenDesigner}
            text="Edit in Designer"
            sx={{ mr: 1 }}
        />
    );
};
 
const DynamicRenderer: React.FC<{ novaSchema: NovaUiSchema }> = ({ novaSchema }) => {
    const { importDesign, setMode } = useNova();
    const { loadSchema } = useNova();

    // Create a stable string representation for comparison
    const schemaKey = useMemo(() => {
        return novaSchema ? JSON.stringify(novaSchema.metadata || novaSchema.ui?.[0]?.id || Math.random()) : '';
    }, [novaSchema]);

    useEffect(() => {
        if (novaSchema) {
            // Load schema into engine context for action/rule/variable execution
            loadSchema(novaSchema);

            // Import into designer for rendering
            importDesign(JSON.stringify(novaSchema));
            setMode('preview');
        }
    }, [schemaKey]); // Only re-run when schema actually changes

    return (
        <Box sx={{ height: '100%', overflow: 'hidden', bgcolor: '#f0f2f5' }}>
            <DesignArea  />
        </Box>
    );
};

const GenericUiContent: React.FC = () => {
    const { pages, loading, error } = useNova();
    const [selectedPage, setSelectedPage] = useState<PageDefinition | null>(null);
    const [novaSchema, setNovaSchema] = useState<NovaUiSchema | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const handlePageSelect = (page: PageDefinition) => {
        setSelectedPage(page);
        try {
            // Use the new NovaUiSchema converter that includes UI, events, rules, and variables
            const convertedSchema = mapEbmlContentToNovaSchema(page.EbmlContent);
            setNovaSchema(convertedSchema);
        } catch (err) {
            console.error('Failed to convert page:', err);
            setNovaSchema(null);
        }
    };

    const filteredPages = useMemo(() => {
        const onlyPages = pages.filter((p) => p.Type === 'page');
        if (!searchTerm) return onlyPages;
        const term = searchTerm.toLowerCase();
        return onlyPages.filter(
            (p) =>
                p.MenuName?.toLowerCase().includes(term) ||
                p.ScreenCode?.toLowerCase().includes(term)  
                // p.Name?.toLowerCase().includes(term)
                ,
        );
    }, [pages, searchTerm]);

    if (loading) {
        return <Box sx={{ p: 3 }}>Loading definitions...</Box>;
    }

    if (error) {
        return <Box sx={{ p: 3, color: 'error.main' }}>Error: {error.message}</Box>;
    }

    return (
     <>
            {/*    <DndProvider backend={HTML5Backend}><NovaProvider> */}
                <Grid container spacing={2} sx={{ height: 'calc(100vh - 64px)', overflow: 'hidden' }}>
                    <GridItem xs={12} md={2} sx={{ height: '100%', borderRight: '1px solid #eee', overflow: 'auto' }}>
                        <Typography variant="h6" gutterBottom>
                            NOVA UI Explorer
                        </Typography>

                        <Box sx={{ mb: 2 }}>
                            <TextField
                                fullWidth
                                placeholder="Search pages..."
                                value={searchTerm}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
                                size="small"
                            />
                        </Box>

                        <Box>
                            {filteredPages.map((page) => (
                                <Box
                                    key={page.Name}
                                    onClick={() => handlePageSelect(page)}
                                    sx={{
                                        p: 1.5,
                                        mb: 1,
                                        cursor: 'pointer',
                                        borderRadius: 1,
                                        bgcolor: selectedPage?.Name === page.Name ? 'action.selected' : 'transparent',
                                        '&:hover': {
                                            bgcolor: 'action.hover',
                                        },
                                        border: '1px solid',
                                        borderColor: selectedPage?.Name === page.Name ? 'primary.main' : 'divider',
                                    }}
                                >
                                    <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
                                        {page.MenuName || page.Name}
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary" display="block">
                                        Code: {page.ScreenCode} | Type: {page.Type}
                                    </Typography>
                                </Box>
                            ))}
                            {filteredPages.length === 0 && (
                                <Typography variant="body2" color="text.secondary" align="center">
                                    No pages found
                                </Typography>
                            )}
                        </Box>
                    </GridItem>

                    <GridItem xs={12} md={10} sx={{ height: '100%', p: 0, display: 'flex', flexDirection: 'column' }}>
                        {selectedPage ? (
                            <>
                                <Paper sx={{ p: 2, borderRadius: 0, borderBottom: '1px solid #eee' }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <Box>
                                            <Typography variant="h5">{selectedPage.MenuName}</Typography>
                                            <Typography variant="body2" color="text.secondary">
                                                {selectedPage.ScreenCode} - {selectedPage.ModuleName}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                            <EditInDesignerButton novaSchema={novaSchema} />
                                            <EngineDebugPanel />
                                            <Button variant="outlined" size="small" onClick={() => {
                                                console.log("Selected Page EbmlContent:", selectedPage.EbmlContent);
                                                console.log('Current NovaSchema:', novaSchema);}} text="Log Schema" />
                                        </Box>
                                    </Box>
                                </Paper>

                                <Box sx={{ flexGrow: 1, overflow: 'hidden', position: 'relative', bgcolor: '#f5f5f5' }}>
                                    {novaSchema ? (
                                        <DynamicRenderer novaSchema={novaSchema} />
                                    ) : (
                                        <Box sx={{ p: 3, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                            <Typography color="error">Failed to convert schema or empty definition</Typography>
                                        </Box>
                                    )}
                                </Box>
                            </>
                        ) : (
                            <Box
                                sx={{
                                    height: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    bgcolor: '#fafafa',
                                }}
                            >
                                <Typography variant="h6" color="text.secondary">
                                    Select a page from the sidebar to render
                                </Typography>
                            </Box>
                        )}
                    </GridItem>
                </Grid>
            {/* </NovaProvider>  </DndProvider> */}
      </>
    );
};

const GenericUi: React.FC = () => {
    const navigate = useNavigate();

    // Handle page navigation
    const handleNavigate = (pageName: string, pageTitle?: string, params?: any) => {
        console.log(`[Engine] Navigate to page: ${pageName}`, { pageTitle, params });

        // Navigate using React Router
        navigate(`/nova-page/${pageName}`, {
            state: {
                pageTitle,
                params
            }
        });
    };

    // Handle popup dialogs
    const handleShowPopup = async (popupName: string, data: any): Promise<any> => {
        console.log(`[Engine] Show popup: ${popupName}`, data);

        // TODO: Implement popup/modal display logic
        // For now, return empty object
        return new Promise((resolve) => {
            // You can implement a modal dialog here
            // For demonstration, we'll just log and resolve
            console.log(`[Engine] Popup ${popupName} would show with data:`, data);

            // Simulate user interaction
            setTimeout(() => {
                resolve({
                    // Return data from popup
                    closed: true
                });
            }, 100);
        });
    };

    return (
        <NovaProvider
            workingMode='generator'
            onNavigate={handleNavigate}
            onShowPopup={handleShowPopup}>
                <DndProvider backend={HTML5Backend}>
                    <GenericUiContent />
                </DndProvider>
        </NovaProvider>
    );
};

export default GenericUi;
