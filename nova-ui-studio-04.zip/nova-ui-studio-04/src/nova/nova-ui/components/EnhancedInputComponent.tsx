/* eslint-disable */
/**
 * Enhanced Input Component
 * Input component with integrated engine context for bean actions
 */

import React, { useState, useCallback, useEffect } from 'react';
import { Input } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';
import { useComponentEngine } from '../hooks/useComponentEngine';

export const EnhancedInputComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    placeholder,
    disabled,
    required,
    value: initialValue,
    onChange,
    onBlur,
    onFocus,
    ...props
}) => {
    const [localValue, setLocalValue] = useState(initialValue || '');

    // Component methods for bean actions
    const componentMethods = {
        getText: () => localValue,
        setText: (text: string) => setLocalValue(text),
        getValue: () => localValue,
        setValue: (val: string) => setLocalValue(val),
        clear: () => setLocalValue(''),
        isEmpty: () => !localValue || localValue.trim() === '',
        focus: () => {
            const input = document.getElementById(id);
            input?.focus();
        },
        blur: () => {
            const input = document.getElementById(id);
            input?.blur();
        },
        setEnabled: (enabled: boolean) => {
            engine.setEnabled(enabled);
        },
        setVisible: (visible: boolean) => {
            engine.setVisible(visible);
        }
    };

    // Register with engine
    const engine = useComponentEngine({
        id,
        initialState: { value: initialValue },
        methods: componentMethods
    });

    // Sync local value with engine state
    useEffect(() => {
        const engineValue = engine.getValue();
        if (engineValue !== undefined && engineValue !== localValue) {
            setLocalValue(engineValue);
        }
    }, [engine.state?.value]);

    // Handle change
    const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = e.target.value;
        setLocalValue(newValue);
        engine.setValue(newValue);

        // Fire textChanged event
        engine.fireEvent('textChanged', { value: newValue });

        if (onChange) {
            onChange(e);
        }
    }, [engine, onChange]);

    // Handle blur
    const handleBlur = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
        engine.fireEvent('focusLost', { value: localValue });

        if (onBlur) {
            onBlur(e);
        }
    }, [engine, localValue, onBlur]);

    // Handle focus
    const handleFocus = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
        engine.fireEvent('focusGained', { value: localValue });

        if (onFocus) {
            onFocus(e);
        }
    }, [engine, localValue, onFocus]);

    // Respect visibility and enabled state from engine
    if (!engine.isVisible()) {
        return null;
    }

    return (
        <Input
            id={id}
            label={label}
            labelPlacement='start'
            placeholder={placeholder}
            value={localValue}
            disabled={disabled || !engine.isEnabled()}
            required={required}
            onChange={handleChange}
            onBlur={handleBlur}
            onFocus={handleFocus}
            {...props}
        />
    );
};
