/* eslint-disable */
/**
 * TimePicker Component Wrapper
 * Wraps the lib TimePicker component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { TimePicker } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';

export const TimePickerComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;

    // Ensure string properties are never undefined to prevent .substring() errors
    const safeProps = {
        ...props,
        label: label || '',
        name: name || id || 'timepicker',
        value: value || null, // TimePicker expects null for empty time, not undefined
        control: control as any,
    };

    return <TimePicker {...safeProps} />;
};
