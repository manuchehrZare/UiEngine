/* eslint-disable */
/**
 * Button Component
 * Renders EBML Button components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Button, GridItem } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';
import { boundsToGridSize } from '../../novaCore';
import { 
    AddCircleOutline, 
    EditNote, 
    Search, 
    ChevronLeft, 
    ChevronRight, 
    Save, 
    Close, 
    Add, 
    Menu, 
    Refresh, 
    Delete, 
    Print, 
    CorporateFare ,
    Adjust
} from '@mui/icons-material';

const ICON_MAPPING: Record<string, React.ReactNode> = {
    'core/Add.gif': <AddCircleOutline />,
    'core/Edit.gif': <EditNote />,
    'core/Search.gif': <Search />,
    'core/Left.gif': <ChevronLeft />,
    'core/Right.gif': <ChevronRight />,
    'CORE/SAVE.gif': <Save />,
    'core/Update.gif': <Save />,
    'core/Close.gif': <Close />,
    'core/New.gif': <Add />,
    'core/Menu.gif': <Menu />,
    'core/Refrech.gif': <Refresh />,
    'core/Delete.gif': <Delete />,
    'core/Print.gif': <Print />,
    'core/Organization.gif': <CorporateFare />,
};

export const SetButtonComponent: React.FC<NovaComponentProps> = ({
    text,
    label,
    enabled,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    type,
    xs,
    ...props
}) => {
    const containerWidth = parentBounds?.width || 960;
    const buttonText = text || label || 'Button';

    let buttonProps = { ...props };
    const iconName = props.icon as string;

    if (iconName ) {
        buttonProps.icon = ICON_MAPPING[iconName] ||<Adjust/> ;
    }

    const buttonContent = (
        <Button
            text={buttonText}
            disabled={enabled === 'false'}
            sx={{
                width: useAbsolutePositioning ? '100%' : 'auto',
                height: useAbsolutePositioning ? '100%' : 'auto',
            }}
            {...buttonProps}
        />
    );

    if (useAbsolutePositioning) {
        return buttonContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {buttonContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    // const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
            // xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {buttonContent}
        </GridItem>
    );
};
