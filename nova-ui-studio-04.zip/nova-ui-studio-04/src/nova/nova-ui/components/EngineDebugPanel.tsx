/* eslint-disable */
/**
 * Engine Debug Panel
 * Reusable debug panel for inspecting and testing the page engine
 */

import React, { useState } from 'react';
import { Box, Paper, Typography, Button, message } from '../../../seker-ui-lib';
import { useNova, useNovaOptional } from '../../novaCore/context/NovaContext';
import { PestControl } from '@mui/icons-material';

export const EngineDebugPanel: React.FC = () => {
    const engine = useNova();
    const [showDebug, setShowDebug] = useState(false);
    const variables = Array.from(engine.variables.entries());
    const componentStates = Array.from(engine.componentStates.entries());

    // Use designer actions/rules if available, otherwise fall back to schema
    const actions = engine.actions?.length > 0
        ? engine.actions
        : (engine.schema?.events?.actions || []);
    const rules = engine.rules?.length > 0
        ? engine.rules
        : (engine.schema?.ruleset?.rules || []);

    return (
        <>
        <Button
                variant= {showDebug==true ? "contained":"outlined" }
                iconRight={<PestControl/>}
                onClick={() => setShowDebug(!showDebug)}
                text="Engine Debug"
                sx={{ mr: 1, whiteSpace: 'nowrap' }}
            />
           {showDebug==true &&  <Paper
            sx={{
                position: 'fixed',
                top: 64,
                right: 20,
                width: 400,
                maxHeight: '100vh',
                overflow: 'auto',
                zIndex: 1000,
                height: 'calc(100vh - 64px)',
                p: 2
            }}
        >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                <Typography variant="h6">Engine Debug</Typography>
                 <Button size="small" onClick={() => setShowDebug(false)} text="Close" />
            </Box>

            <Typography variant="subtitle2" gutterBottom>
                Lifecycle: <strong>{engine.lifecyclePhase}</strong>
            </Typography>

            <Typography variant="subtitle2" sx={{ mt: 2 }}>Variables ({variables.length})</Typography>
            <Box sx={{ maxHeight: 150, overflow: 'auto', bgcolor: '#f5f5f5', p: 1, fontSize: '0.75rem' }}>
                {variables.map(([key, value]) => (
                    <div key={key}>{key}: {JSON.stringify(value)}</div>
                ))}
            </Box>

            <Typography variant="subtitle2" sx={{ mt: 2 }}>Components ({componentStates.length})</Typography>
            <Box sx={{ maxHeight: 150, overflow: 'auto', bgcolor: '#f5f5f5', p: 1, fontSize: '0.75rem' }}>
                {componentStates.map(([key, state]) => (
                    <div key={key}>{key}: {JSON.stringify(state)}</div>
                ))}
            </Box>

            <Typography variant="subtitle2" sx={{ mt: 2 }}>Actions ({actions.length})</Typography>
            <Box sx={{ maxHeight: 150, overflow: 'auto', bgcolor: '#f5f5f5', p: 1 }}>
                {actions.map((action) => (
                    <Box key={action.id} sx={{ mb: 1 }}>
                        <Button
                            size="small"
                            variant="outlined"
                            fullWidth
                            onClick={() => {
                                console.log(`[Debug] Executing action: ${action.name}`);
                                engine.executeAction(action.id);
                            }}
                            text={action.name}
                        />
                    </Box>
                ))}
            </Box>

            <Typography variant="subtitle2" sx={{ mt: 2 }}>Rules ({rules.length})</Typography>
            <Box sx={{ maxHeight: 150, overflow: 'auto', bgcolor: '#f5f5f5', p: 1, fontSize: '0.75rem' }}>
                {rules.map((rule) => (
                    <div key={rule.id}>
                        {rule.name} ({rule.type})
                        <Button
                            size="small"
                            onClick={async () => {
                                const result = await engine.evaluateRule(rule.id);
                                console.log(`[Debug] Rule ${rule.name} evaluated to:`, result);
                                message(`Rule "${rule.name}" = ${result}`);
                            }}
                            text="Test"
                        />
                    </div>
                ))}
            </Box>
        </Paper>}
            </>
        
    );
};
