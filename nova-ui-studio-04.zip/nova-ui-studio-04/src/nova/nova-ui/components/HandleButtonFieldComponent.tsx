/* eslint-disable */
/**
 * HandleButtonField Component
 * Renders EBML HandleButtonField - Text field with button
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { GridItem, Input, Box, Tooltip, Button }   from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';
import { boundsToGridSize } from '../../novaCore';
import { MoreHoriz } from '@mui/icons-material';

export const HandleButtonFieldComponent: React.FC<NovaComponentProps> = ({
    id,
    name,
    text,
    value,
    label,
    fieldLabel,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    xs,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;
    const containerWidth = parentBounds?.width || 960;
    const fieldId = name || id?.split('.').pop() || 'handlefield';
    
    const handleButtonContent = (
         <Input
            name={fieldId}
            sx={{
                input: {
                    textTransform: 'uppercase',
                },
            }}
            control={control}
            readOnly
            label={label || fieldLabel}
            labelPlacement='start'
            endAdornment={
                <Box sx={{ mr: '-5px' }}>
                    <Tooltip title={''}>
                        <Button
                            iconButton
                            icon={<MoreHoriz />}
                        />
                    </Tooltip>
                </Box>
            }
            {...props}
        />
    );

    if (useAbsolutePositioning) {
        return handleButtonContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {handleButtonContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
            xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {handleButtonContent}
        </GridItem>
    );
};
