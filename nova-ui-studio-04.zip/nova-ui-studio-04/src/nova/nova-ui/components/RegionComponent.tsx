/* eslint-disable */
/**
 * Region Component
 * Renders EBML Region components (references to reusable sub-pages)
 * Supports both absolute positioning and responsive grid layout
 */

import React, { useMemo } from 'react';
import { Box, Label }   from '../../../seker-ui-lib';
import { GridItem }   from '../../../seker-ui-lib';
import { boundsToGridSize } from '../../novaCore';
import { useNovaOptional } from '../../novaCore/context/NovaContext';
import { convertEbmlToSchema } from '../../novaCore/converters/EbmlConverter';
import type { PageDefinition } from '../../novaCore/types/ebml.types';
import type { NovaComponentProps } from './types';
import { PreviewRenderer } from '../../nova-studio/components/PreviewRenderer';

const findRegionByName = (regionName: string, allPages: PageDefinition[]): PageDefinition | null => {
    return allPages.find(page => page.Type === 'region' && page.Name === regionName) || null;
};

export const RegionComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    regionName,
    xs,
    allPages = [],
    ...props
}) => {
    // Use context instead of prop
    const context = useNovaOptional();
    const pages = context?.pages || allPages;
    const containerWidth = parentBounds?.width || 960;
    const gridSize = bounds ? boundsToGridSize(bounds, containerWidth) : { xs: 12, minHeight: 0 };
    
    const regionDef = useMemo(() => {
        if (!regionName) return null;
        return findRegionByName(regionName, pages);
    }, [regionName, pages]);

    const regionSchema = useMemo(() => {
        if (!regionDef) return null;
        try {
            // We convert the region EBML to Schema on the fly
             if (!regionDef.EbmlContent) return null;
             return convertEbmlToSchema(regionDef.EbmlContent);
        } catch (e) {
            console.error('Failed to convert region schema', e);
            return null;
        }
    }, [regionDef]);

    if (!regionName) {
        const content = (
             <Box sx={{
                border: '2px dashed #ff9800',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text="[Region: No name specified]" />
            </Box>
        );

        if (useAbsolutePositioning) return content;
        const resolvedXs = xs ?? gridSize.xs;
        return <GridItem xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} {...props}>
            {content}
            </GridItem>;
    }

    if (!regionDef) {
        const content = (
            <Box sx={{
                border: '2px dashed #f44336',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text={`[Region not found: ${regionName}]`} />
            </Box>
        );
         if (useAbsolutePositioning) return content;
        const resolvedXs = xs ?? gridSize.xs;
        return <GridItem xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} {...props}>{content}</GridItem>;
    }

    if (!regionSchema) {
         const content = (
            <Box sx={{
                border: '2px dashed #f44336',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text={`[Region error: ${regionName}]`} />
            </Box>
        );
         if (useAbsolutePositioning) return content;
        const resolvedXs = xs ?? gridSize.xs;
        return <GridItem xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} {...props}>{content}</GridItem>;
    }

    // Render the region schema using PreviewRenderer
    // This will recursively render components defined in the region
    const content = (
        <Box sx={{
            width: '100%',
            height: '100%',
            position: useAbsolutePositioning ? 'relative' : undefined
        }}>
            <PreviewRenderer component={regionSchema} />
        </Box>
    );

    if (useAbsolutePositioning) {
        return content;
    }

    const resolvedXs = xs ?? gridSize.xs;
    console.log(xs);
    return (
        <GridItem container xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} >
             {content}
        </GridItem>
    );
};
