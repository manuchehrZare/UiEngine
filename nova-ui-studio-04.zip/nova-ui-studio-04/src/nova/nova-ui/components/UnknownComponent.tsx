/* eslint-disable */
/**
 * Unknown Component
 * Fallback renderer for unknown component types
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Box, Label, GridItem } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';
import { boundsToGridSize } from '../../novaCore';


export const UnknownComponent: React.FC<NovaComponentProps> = ({
    type,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    xs,
    originalClassName,
    ...props
}) => {
    const containerWidth = props.designComponent?.props.bounds?.width || 960;

    // Get the display name - use original class name if available, otherwise use type
    const displayName = originalClassName || type || 'Unknown';

    // Extract just the class name from the full Java class path for cleaner display
    const shortName = displayName.includes('.')
        ? displayName.split('.').pop()
        : displayName;

    // Calculate real size from bounds
    const realWidth = bounds?.width || 100;
    const realHeight = bounds?.height || 30;

    const unknownContent = (
        <Box sx={{
            border: '2px dashed #ff9800',
            backgroundColor: '#dcdcdcff',
            p: 1,
            height: '100%',
            minHeight: `${realHeight}px`,
            width: '100%',
            minWidth: `${realWidth}px`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            position: useAbsolutePositioning ? 'relative' : 'static',
        }}>
            <Label
                text={`⚠️ Unknown: ${shortName}`}
                sx={{
                    fontWeight: 'bold',
                    color: '#e65100',
                    fontSize: '12px',
                    textAlign: 'center'
                }}
            />
        </Box>
    );

    if (useAbsolutePositioning) {
        return unknownContent;
    }

    if (!bounds) {
         return (
            <GridItem xs={12}>
                {unknownContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
            xs={resolvedXs}
            sx={{
                minHeight: `${realHeight}px`,
                height: 'auto'
            }}
        >
            {unknownContent}
        </GridItem>
    );
};
