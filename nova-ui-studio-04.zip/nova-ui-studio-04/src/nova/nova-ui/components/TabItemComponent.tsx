/* eslint-disable */
/**
 * TabItem Component Wrapper
 * Wraps the lib TabItem component (individual tab button) to handle EBML properties
 */

import React from 'react';
import { TabItem } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';

export const TabItemComponent: React.FC<NovaComponentProps> = ({
    id,
    text,
    label,
    title,
    value,
    ...props
}) => {
    // TabItem is an individual tab button
    return (
        <TabItem
            text={title || text || label || 'Tab'}
            value={value !== undefined ? value : id}
            {...props}
        />
    );
};
