/* eslint-disable */
/**
 * Select Component Wrapper
 * Wraps the lib Select component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React, { useMemo } from 'react';
import { useFormContext } from 'react-hook-form';
import { Select } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';
import { useNova } from '../../novaCore';

export const SelectComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    options,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;
    const setValue = context ? context.setValue : undefined;
    const engine = useNova();

    // Ensure string properties are never undefined to prevent .substring() errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `select_${Math.random().toString(36).substring(2, 11)}`;

    // Get options from component state (set by remote call actions)
    const componentState = engine.getComponentState(id);
    const dynamicOptions = useMemo(() => {
        // Priority: state.options > state.value (if array) > props.options > default
        const stateOptions = componentState?.options;

        if (stateOptions) {
            // If options is already in the correct format
            if (stateOptions.data && Array.isArray(stateOptions.data)) {
                return stateOptions;
            }
            // If state.options is a plain array, wrap it in the expected format
            if (Array.isArray(stateOptions)) {
                return {
                    data: stateOptions,
                    displayField: 'label',
                    displayValue: 'value',
                };
            }
        }

        // Check if state.value is an array (alternative way to set options)
        const stateValue = componentState?.value;
        if (Array.isArray(stateValue)) {
            return {
                data: stateValue,
                displayField: 'label',
                displayValue: 'value',
            };
        }

        // Fall back to props.options or default
        return options || {
            data: [],
            displayField: 'label',
            displayValue: 'value',
        };
    }, [componentState?.options, componentState?.value, options]);

    // IMPORTANT: Do NOT pass 'value' prop when control is present - the control manages the value
    const safeProps = {
        ...props,
        label: label || '',
        name: safeName,
        options: dynamicOptions,
        control: control as any,
        setValue: setValue as any,
    };

    return <Select {...safeProps} />;
};
