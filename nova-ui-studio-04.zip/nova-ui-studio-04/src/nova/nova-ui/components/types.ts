/* eslint-disable */
/**
 * Component Registry Types
 * Re-export core component types for backward compatibility
 */

// Re-export from novaCore
export type {
    NovaComponentProps,
    BaseComponentProps,
    ComponentRenderer,
    ComponentRegistryEntry,
    ComponentRegistry
} from '../../novaCore/types/component.types';
