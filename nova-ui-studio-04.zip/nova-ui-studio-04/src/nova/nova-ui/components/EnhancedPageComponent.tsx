/* eslint-disable */
/**
 * Enhanced Page Component
 * Page component with integrated engine context
 */

import React, { useEffect } from 'react';
import { Box, Grid, GridItem, Paper } from '../../../seker-ui-lib';
import type { NovaComponentProps } from './types';
import { groupComponentsByRow, calculateRowGridSizes, normalizeLayout, type LayoutComponent } from '../../novaCore/utils/positioningUtils';
import { mapComponent } from '../../novaCore/mapper/component-mapper';
import { PreviewRenderer } from '../../nova-studio/components/PreviewRenderer';
import { useNova } from '../../novaCore/context/NovaContext';
import { usePageLoad } from '../hooks/usePageEvent';
import type { NovaUiSchema } from '../../novaCore/types/nova-schema.types';

export interface EnhancedPageComponentProps extends NovaComponentProps {
    /** Nova UI Schema with events, rules, actions, and variables */
    novaSchema?: NovaUiSchema;
    /** Callback when remote call is triggered */
    onRemoteCall?: (serviceName: string, inputs: any) => Promise<any>;
    /** Callback when navigation is requested */
    onNavigate?: (pageName: string, pageTitle?: string, params?: any) => void;
    /** Callback when popup is requested */
    onShowPopup?: (popupName: string, data: any) => Promise<any>;
}

export const EnhancedPageComponent: React.FC<EnhancedPageComponentProps> = ({
    id,
    bounds,
    pageSize,
    pageWidth: propPageWidth,
    pageHeight: propPageHeight,
    backgroundColor,
    children,
    designComponent,
    component,
    allPages,
    useAbsolutePositioning = false,
    novaSchema,
    onRemoteCall,
    onNavigate,
    onShowPopup,
    ...props
}) => {
    const engine = useNova();

    // Load schema when component mounts
    useEffect(() => {
        if (novaSchema) {
            engine.loadSchema(novaSchema);
        }
    }, [novaSchema]);

    // Register page component
    useEffect(() => {
        engine.registerComponent('Page', {
            id: 'Page',
            pageSize,
            pageWidth: propPageWidth,
            pageHeight: propPageHeight
        });

        // Register standard page methods
        engine.registerComponentMethod('Page', 'getPageSize', () => pageSize);
        engine.registerComponentMethod('Page', 'getPageWidth', () => propPageWidth || 1024);
        engine.registerComponentMethod('Page', 'getPageHeight', () => propPageHeight || 768);

        return () => {
            engine.unregisterComponent('Page');
        };
    }, [id, pageSize, propPageWidth, propPageHeight]);

    // Handle pageLoad event
    const pageLoadAction = novaSchema?.events?.actions?.find(action =>
        action.type === 'pageLoad' || action.name === 'pageLoad'
    );

    usePageLoad(pageLoadAction?.id);

    // Get page dimensions
    let pageWidth = 1024;
    let pageHeight = 768;

    const structuralComponent = normalizeLayout(component || designComponent);
    const actualBounds = bounds || structuralComponent?.bounds;

    if (pageSize) {
        const [w, h] = String(pageSize).split(',').map(Number);
        if (w && h) {
            pageWidth = w;
            pageHeight = h;
        }
    } else if (propPageWidth && propPageHeight) {
        pageWidth = Number(propPageWidth);
        pageHeight = Number(propPageHeight);
    } else if (actualBounds && actualBounds.width > 0 && actualBounds.height > 0) {
        pageWidth = actualBounds.width;
        pageHeight = actualBounds.height;
    }

    const pageBounds = actualBounds
        ? { ...actualBounds, width: pageWidth, height: pageHeight }
        : { x: 0, y: 0, width: pageWidth, height: pageHeight };

    // Render responsive children
    const renderResponsiveChildren = () => {
        if (React.Children.count(children) > 0) {
            return (
                <Grid container={false} spacing={2}>
                    {children}
                </Grid>
            );
        }

        if (!structuralComponent || !structuralComponent.children || structuralComponent.children.length === 0) {
            return children;
        }

        const rows = groupComponentsByRow(structuralComponent.children);

        return (
            <Grid container direction="column" spacing={2}>
                {rows.map((row, rowIndex) => {
                    const rowSizes = calculateRowGridSizes(row, pageBounds.width);

                    return (
                        <GridItem key={`row-${rowIndex}`} xs={12}>
                            <Grid container spacing={2}>
                                {row.map((childLayout: LayoutComponent) => {
                                    const placement = rowSizes.get(childLayout);
                                    const xs = placement?.xs;
                                    const gap = placement?.gap ?? 0;
                                    const child = childLayout.original;

                                    const elements: React.ReactNode[] = [];

                                    if (gap > 0) {
                                        elements.push(
                                            <GridItem
                                                key={`${child.id}-gap-${rowIndex}`}
                                                xs={gap}
                                                sx={{ p: 0, m: 0, visibility: 'hidden' }}
                                            />,
                                        );
                                    }

                                    if (designComponent) {
                                        const modifiedChild = {
                                            ...child,
                                            props: xs ? { ...child.props, xs } : child.props,
                                        };
                                        elements.push(<PreviewRenderer key={child.id} component={modifiedChild} />);
                                    } else {
                                        elements.push(
                                            <React.Fragment key={child.id}>
                                                {mapComponent(
                                                    child,
                                                    child.id,
                                                    false,
                                                    allPages,
                                                    pageBounds,
                                                    xs ? { xs } : {},
                                                )}
                                            </React.Fragment>,
                                        );
                                    }

                                    return elements;
                                })}
                            </Grid>
                        </GridItem>
                    );
                })}
            </Grid>
        );
    };

    if (useAbsolutePositioning) {
        return (
            <Paper sx={{ width: '100%', overflow: 'auto' }}>
                <Grid
                    minHeight={pageHeight}
                    height="100%"
                    display="flex"
                    justifyContent="center"
                    alignItems="flex-start"
                >
                    <Box
                        sx={{
                            position: 'relative',
                            width: `${pageWidth}px`,
                            height: `${pageHeight}px`,
                            minHeight: `${pageHeight}px`,
                            backgroundColor: backgroundColor || '#ece9d8',
                            margin: '0 auto',
                        }}
                    >
                        {children}
                    </Box>
                </Grid>
            </Paper>
        );
    }

    return (
        <Paper sx={{ width: '100%', p: 2 }}>
            <Grid
                minHeight={pageHeight}
                height="100%"
                display="flex"
                justifyContent="center"
                alignItems="flex-start"
            >
                <Box sx={{ width: '100%' }}>
                    {renderResponsiveChildren()}
                </Box>
            </Grid>
        </Paper>
    );
};
