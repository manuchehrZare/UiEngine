/* eslint-disable */
/**
 * usePageEvent Hook
 * Simplified hook for handling page events
 */

import { useEffect, useCallback } from 'react';
import { useNova } from '../../novaCore/context/NovaContext';

/**
 * Hook for executing actions on page lifecycle events
 */
export const usePageEvent = (eventName: string, actionId?: string) => {
    const engine = useNova();

    useEffect(() => {
        if (actionId && eventName) {
            // For page-level events, use 'Page' as component ID
            engine.addEventListener('Page', eventName, actionId);

            // Fire pageLoad event automatically
            if (eventName === 'pageLoad' && engine.lifecyclePhase === 'ready') {
                engine.fireEvent('Page', 'pageLoad');
            }

            return () => {
                engine.removeEventListener('Page', eventName);
            };
        }
    }, [eventName, actionId, engine]);

    // Manual trigger
    const trigger = useCallback((eventData?: any) => {
        return engine.fireEvent('Page', eventName, eventData);
    }, [engine, eventName]);

    return { trigger };
};

/**
 * Hook for page load event
 */
export const usePageLoad = (actionId?: string) => {
    const engine = useNova();

    useEffect(() => {
        if (actionId && engine.lifecyclePhase === 'ready') {
            engine.executeAction(actionId);
        }
    }, [actionId, engine.lifecyclePhase]);
};

/**
 * Hook for page unload event
 */
export const usePageUnload = (callback: () => void) => {
    useEffect(() => {
        return () => {
            callback();
        };
    }, [callback]);
};
