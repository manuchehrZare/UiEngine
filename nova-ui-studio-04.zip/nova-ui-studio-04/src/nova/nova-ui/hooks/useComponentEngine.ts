/* eslint-disable */
/**
 * useComponentEngine Hook
 * Provides component-level integration with the page engine
 */

import { useEffect, useCallback, useRef } from 'react';
import { useNova } from '../../novaCore/context/NovaContext';

export interface UseComponentEngineOptions {
    /** Component unique identifier */
    id: string;
    /** Initial component state */
    initialState?: Record<string, any>;
    /** Component methods to register for bean actions */
    methods?: Record<string, Function>;
    /** Auto-register component on mount */
    autoRegister?: boolean;
}

/**
 * Hook for integrating components with the page engine
 */
export const useComponentEngine = (options: UseComponentEngineOptions) => {
    const {
        id,
        initialState,
        methods,
        autoRegister = true
    } = options;

    const engine = useNova();
    const isRegisteredRef = useRef(false);

    // Register component on mount
    useEffect(() => {
        if (autoRegister && !isRegisteredRef.current) {
            engine.registerComponent(id, initialState);
            isRegisteredRef.current = true;

            // Register methods
            if (methods) {
                Object.entries(methods).forEach(([methodName, method]) => {
                    engine.registerComponentMethod(id, methodName, method);
                });
            }
        }

        // Cleanup on unmount
        return () => {
            if (isRegisteredRef.current) {
                engine.unregisterComponent(id);
                isRegisteredRef.current = false;
            }
        };
    }, [id, autoRegister]);

    // Update methods when they change
    useEffect(() => {
        if (methods && isRegisteredRef.current) {
            Object.entries(methods).forEach(([methodName, method]) => {
                engine.registerComponentMethod(id, methodName, method);
            });
        }
    }, [methods, id]);

    // Get current component state
    const state = engine.getComponentState(id);

    // Update component state
    const setState = useCallback((newState: Record<string, any>) => {
        engine.setComponentState(id, newState);
    }, [engine, id]);

    // Fire event
    const fireEvent = useCallback((eventName: string, eventData?: any) => {
        return engine.fireEvent(id, eventName, eventData);
    }, [engine, id]);

    // Get value
    const getValue = useCallback(() => {
        return state?.value;
    }, [state]);

    // Set value
    const setValue = useCallback((value: any) => {
        setState({ value });
    }, [setState]);

    // Get enabled
    const isEnabled = useCallback(() => {
        return state?.enabled ?? true;
    }, [state]);

    // Set enabled
    const setEnabled = useCallback((enabled: boolean) => {
        setState({ enabled });
    }, [setState]);

    // Get visible
    const isVisible = useCallback(() => {
        return state?.visible ?? true;
    }, [state]);

    // Set visible
    const setVisible = useCallback((visible: boolean) => {
        setState({ visible });
    }, [setState]);

    return {
        state,
        setState,
        fireEvent,
        getValue,
        setValue,
        isEnabled,
        setEnabled,
        isVisible,
        setVisible
    };
};
