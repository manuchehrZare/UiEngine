export default {
    auth: {
        login: 'Login',
    },
    favourites: 'Favourites',
    menu: 'Menu',
    menuList: 'Menu List',
    notFound: 'Page Not Found!',
    notifications: 'Notifications',
    settings: 'Settings',
};
