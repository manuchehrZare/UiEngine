export default {
    openDetailLog: 'Open Detail Log',
    openSignalRConsole: 'Open SignalR Console',
    search: 'Search',
};
