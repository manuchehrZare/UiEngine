export default {
    copied: 'Copied!',
    navigateToLoginPage: 'You will be taken to the login screen.',
    noData: 'Data Not Found!',
};
