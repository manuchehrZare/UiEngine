import DOMPurify from 'isomorphic-dompurify';
import type { SanitizeOptions } from '../../../..';

/**
 * Sanitizes a given string of HTML with the specified DOMPurify settings.
 * @param dirtyHTML - The potentially unsafe HTML to be sanitized.
 * @param options - The configuration object to be passed to DOMPurify.
 * @returns The sanitized HTML.
 */
export const sanitizeHTML = (dirtyHTML: string | null | undefined, options?: SanitizeOptions): string | null => {
    if (!dirtyHTML) {
        return null;
    }

    const sanitizedMessage = DOMPurify.sanitize(dirtyHTML, options);
    return sanitizedMessage;
};
