import { read, utils } from 'xlsx';
import { uniq } from 'lodash';
import type { FileExtentionsEnum } from '../type';
import { FileAcceptValues, FileTypes } from '../type';
import { i18n, locale } from '../../../locales';

export interface IExcelToJsonSheetRangeValues {
    end: number;
    start: number;
}

export type ExcelToJsonSheetRangeType = {
    cell: IExcelToJsonSheetRangeValues;
    row: IExcelToJsonSheetRangeValues;
};

export interface IExcelToJsonSheetCell {
    cellIndex?: number;
    colSpan?: number;
    rowSpan?: number;
    value?: any;
}

type ExcelToJsonSheetMergeType = Record<string, Pick<Required<IExcelToJsonSheetCell>, 'colSpan' | 'rowSpan'>>;

export type ExcelToJsonSheetRowsType = IExcelToJsonSheetCell[];

interface IExcelToJsonSheet {
    sheetHtml: string;
    sheetIndex: number;
    sheetName: string;
    sheetRange: ExcelToJsonSheetRangeType;
    sheetRows: ExcelToJsonSheetRowsType[];
    sheetTxt: string;
}

export type ExcelToJsonReturnType = IExcelToJsonSheet[];

export type ExcelToJsonAcceptType = `${Extract<
    FileExtentionsEnum,
    FileExtentionsEnum.CSV | FileExtentionsEnum.XLS | FileExtentionsEnum.XLSX
>}`;

export interface IExcelToJsonOptions {
    accept?: ExcelToJsonAcceptType[];
}

interface ILocalExcelToJsonOptions
    extends Required<Pick<IExcelToJsonOptions, 'accept'>>, Omit<IExcelToJsonOptions, 'accept'> {}

export const excelToJson = (file: File, options?: IExcelToJsonOptions): Promise<ExcelToJsonReturnType> => {
    // Initial Options
    const localOptions: ILocalExcelToJsonOptions = {
        accept: [...FileAcceptValues.CSV, ...FileAcceptValues.EXCEL],
        ...options,
    };
    const errorInformations = {
        fileType: { code: 0, description: i18n.t(locale.contents.invalidFileType) },
    };

    // Generate Accept <-> FileTypes control for valid file type
    const getActiveFileTypes = (): string[] => {
        const arr: string[] = [];
        localOptions.accept.forEach((item) => {
            let key: string = '';
            Object.values(FileAcceptValues).forEach((a, index) => {
                if (a.includes(item)) {
                    key = Object.keys(FileAcceptValues)[index];
                    return;
                }
            });
            key !== '' && arr.push(...FileTypes[key as keyof typeof FileAcceptValues]);
        });
        return uniq(arr);
    };
    return new Promise((resolve, reject) => {
        if (getActiveFileTypes().includes(file.type)) {
            const fileReader = new FileReader();
            fileReader.onloadend = (e) => {
                const sheets: ExcelToJsonReturnType = [];
                // File Read
                const workBook = read(e?.target?.result, { type: 'binary', dense: true });

                workBook.SheetNames.length > 0 &&
                    workBook.SheetNames?.forEach((sheetName, sheetIndex) => {
                        const workSheet = workBook.Sheets[sheetName];
                        const merge: ExcelToJsonSheetMergeType = {};
                        // Generate Merges
                        if (workSheet['!merges'] && workSheet['!merges'].length > 0) {
                            workSheet['!merges'].forEach((mergeItem) => {
                                const diffCell = mergeItem.e.c - mergeItem.s.c;
                                const diffRow = mergeItem.e.r - mergeItem.s.r;
                                merge[`${mergeItem.s.r}-${mergeItem.s.c}`] = {
                                    colSpan: diffCell !== 0 ? diffCell + 1 : diffCell,
                                    rowSpan: diffRow !== 0 ? diffRow + 1 : diffRow,
                                };
                            });
                        }

                        // Calculate Total Range
                        const generateRange = (): ExcelToJsonSheetRangeType => {
                            if (workSheet['!ref']) {
                                const sheetRange = utils.decode_range(workSheet['!ref']);
                                return {
                                    cell: { end: sheetRange.e.c, start: sheetRange.s.c },
                                    row: { end: sheetRange.e.r, start: sheetRange.s.r },
                                };
                            }
                            return { cell: { end: 0, start: 0 }, row: { end: 0, start: 0 } };
                        };

                        // Generate Data
                        const generateRows = () => {
                            const rows: ExcelToJsonSheetRowsType[] = [];
                            if (workSheet.length > 0) {
                                const sheetRows = utils.sheet_to_json<string[]>(workSheet, { header: 1 });
                                if (sheetRows.length > 0) {
                                    sheetRows.forEach((rowCells, rowIndex) => {
                                        const newRow: ExcelToJsonSheetRowsType = [];
                                        // Cells
                                        rowCells.length > 0 &&
                                            rowCells.forEach((cellItem, cellIndex) => {
                                                // Cells Modelling
                                                newRow.push({
                                                    cellIndex: cellIndex,
                                                    value: cellItem,
                                                    ...(merge[`${rowIndex}-${cellIndex}`] && {
                                                        ...(merge[`${rowIndex}-${cellIndex}`].colSpan !== 0 && {
                                                            colSpan: merge[`${rowIndex}-${cellIndex}`].colSpan,
                                                        }),
                                                        ...(merge[`${rowIndex}-${cellIndex}`].rowSpan !== 0 && {
                                                            rowSpan: merge[`${rowIndex}-${cellIndex}`].rowSpan,
                                                        }),
                                                    }),
                                                });
                                            });
                                        rows.push(newRow);
                                    });
                                }
                            }
                            return rows;
                        };

                        // Generate HTML
                        const generateHtml = (): string => {
                            if (workSheet.length > 0) {
                                const sheetHtml = utils.sheet_to_html(workSheet);
                                // DOMParser support control
                                if (window.DOMParser) {
                                    const parser = new DOMParser();
                                    const doc = parser.parseFromString(
                                        sheetHtml,
                                        FileTypes.HTML[0] as DOMParserSupportedType,
                                    );
                                    return doc.body.innerHTML;
                                }
                                // When Unsupport DomParser
                                const htmlDiv = document.createElement('div');
                                htmlDiv.innerHTML = sheetHtml;
                                return htmlDiv.lastChild ? (htmlDiv.lastChild as Element).outerHTML : sheetHtml;
                            }
                            return '';
                        };

                        sheets.push({
                            sheetHtml: generateHtml(),
                            sheetIndex: sheetIndex,
                            sheetName: sheetName,
                            sheetRange: generateRange(),
                            sheetRows: generateRows(),
                            sheetTxt: utils.sheet_to_txt(workSheet),
                        });
                    });
                // Return
                resolve(sheets);
            };
            fileReader.onerror = reject;
            fileReader.readAsBinaryString(file);
        } else {
            reject(errorInformations.fileType);
        }
    });
};
