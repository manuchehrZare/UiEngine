import FileSaver from 'file-saver';
import { asBlob } from 'html-docx-js-typescript';
import type { IExportPDFProps } from './exportHtmlToPDF';
import { FileExtentionsEnum } from '../type';

interface IExportWordProps extends Omit<IExportPDFProps, 'margin'> {}

export const exportWord = ({ data, fileName }: IExportWordProps): void => {
    const BOM = '\uFEFF';
    asBlob(BOM + data).then((content: any) => {
        FileSaver.saveAs(content, `${fileName}.${FileExtentionsEnum.DOCX}`);
    });
};
