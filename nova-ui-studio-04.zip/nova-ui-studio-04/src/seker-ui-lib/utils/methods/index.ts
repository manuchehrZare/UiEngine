export {
    asyncForEach,
    cleanDeep,
    deepCopy,
    findDeep,
    isDataUri,
    isParsableToJson,
    isXmlString,
    jsToXml,
    sleep,
    stripHtmlFromText,
    xmlToJs,
} from './common';
export { getCookie, removeCookie, setCookie } from './cookies';
export { isBase64, base64Decryption, base64Encryption, base64ToDataUri } from './crypto';
export {
    generateClass,
    getComponentDesignProperty,
    getProviderDesign,
    removeProviderDesign,
    setProviderDesign,
} from './design';
export {
    excelToJson,
    txtToString,
    exportHtmlToPDF,
    exportHtmlToText,
    exportTable,
    exportWord,
    fileDownloader,
    getDateFromExcelDate,
    getExcelDateFromDate,
    getFileSize,
} from './file';
export { deepKeysAsArray, deepKeysAsObject } from './keys';
export { hideLoading, showLoading } from './loading';
export { currency, isNumeric, numberFormat, randomNumber } from './number';
export { jsonToQueryString, queryStringToJSON } from './query';
export { scrollToElement, scrollToTop } from './scroll';
export {
    getLocalStorageItem,
    removeLocalStorageItem,
    setLocalStorageItem,
    getSessionStorageItem,
    removeSessionStorageItem,
    setSessionStorageItem,
} from './storage';
export { getComputedStyles, getBgColorByClassName, importantStyle, randomColor } from './style';
export { cardNumberFormatter, replaceTRtoENChars, phoneNumberFormatter, groupString, iban } from './string';
export { confirm } from './confirm';
export { deepmerge } from './deepmerge';
export { getProviderTheme, removeProviderTheme, setProviderTheme } from './theme';
export { getNow, millisecondsToTime, timeToMilliseconds } from './time';
export { sanitizeHTML, stringHTMLToJSX } from './HTML';

/** TYPES */
export type {
    ExcelToJsonAcceptType,
    ExcelToJsonReturnType,
    ExcelToJsonSheetRangeType,
    ExcelToJsonSheetRowsType,
    IExcelToJsonOptions,
    IExcelToJsonSheetCell,
    IExcelToJsonSheetRangeValues,
    IExportTableColumns,
    IExportTableDateOptions,
    IExportTableProps,
} from './file';
export type { INumberFormatOptions } from './number';
export type { ComputedStyles, GetFlashAnimationCSSOptions } from './style';
export type { ReplaceTRtoEnCharsConfig, IPhoneNumberFormatterOptions } from './string';
export type { IConfirm } from './confirm';

/** ENUMS */
export { FileExtentionsEnum } from './file';
export { BgColorEnum } from './style';

/** CONSTANTS */
export { FileAcceptValues, FileTypes, mimeTypes } from './file';
