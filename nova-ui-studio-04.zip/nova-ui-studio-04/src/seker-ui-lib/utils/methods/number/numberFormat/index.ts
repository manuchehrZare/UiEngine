import type { INumberFormatProps } from '../../../../components/Form/NumberInput/type';

export interface INumberFormatOptions extends Pick<INumberFormatProps, 'decimalSeparator' | 'prefix' | 'suffix'> {
    maximumFractionDigits?: number;
    minimumFractionDigits?: number;
    minimumIntegerDigits?: number;
    thousandSeparator?: ',' | '.' | ' ';
}

export const numberFormat = (number: string | number, options?: INumberFormatOptions): string => {
    let formatedPrice = new Intl.NumberFormat('tr-TR', {
        style: 'decimal',
        minimumFractionDigits: options?.minimumFractionDigits,
        maximumFractionDigits: options?.maximumFractionDigits,
        minimumIntegerDigits: options?.minimumIntegerDigits,
    }).format(Number(typeof number === 'string' ? number.replace(/[^0-9.-]+/g, '') : number));

    if (options?.thousandSeparator) {
        formatedPrice = formatedPrice.replace(/\./g, options?.thousandSeparator);
    }
    if (options?.decimalSeparator) {
        formatedPrice = formatedPrice.replace(/,([^,]*)$/, `${options?.decimalSeparator}$1`);
    }
    if (options?.prefix) {
        formatedPrice = `${options?.prefix}${formatedPrice}`;
    }
    if (options?.suffix) {
        formatedPrice = `${formatedPrice}${options?.suffix}`;
    }

    return formatedPrice;
};
