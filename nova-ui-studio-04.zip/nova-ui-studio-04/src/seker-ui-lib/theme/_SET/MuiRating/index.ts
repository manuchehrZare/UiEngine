import type { Components } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiRatingTheme: Components = {
    MuiRating: {
        defaultProps: {
            color: 'secondary',
        },
        styleOverrides: {
            root: ({ ownerState, theme }: any) => ({
                color: theme.palette[ownerState.sx.color || theme.components.MuiRating.defaultProps.color].main,
            }),
            sizeSmall: {
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 1px)`,
            },
            sizeMedium: {
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 0px)`,
            },
            sizeLarge: {
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 2px)`,
            },
        },
    },
};
