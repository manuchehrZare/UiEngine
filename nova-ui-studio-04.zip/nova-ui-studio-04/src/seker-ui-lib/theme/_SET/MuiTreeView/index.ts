import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import type {} from '@mui/x-tree-view/themeAugmentation';
import { DesignTypeEnum, treeItemClasses } from '../../..';

export const MuiTreeViewTheme: Components = {
    MuiSimpleTreeView: {
        styleOverrides: {
            root: ({ theme, ownerState }) => ({
                [`& .${treeItemClasses.content}`]: {
                    '.MuiCheckbox-root': {
                        padding: '0px !important',
                    },
                    gap: '4px',
                    padding: '0px 8px !important',
                    [`& .${treeItemClasses.label}`]: {
                        fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 1px) !important`,
                        paddingLeft: '2px',

                        'p, span, strong': {
                            fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 1px)`,
                        },

                        '.MuiSvgIcon-root': {
                            fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 2px)`,
                        },
                    },
                    [`& .${treeItemClasses.iconContainer} svg`]: {
                        fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 2px) !important`,
                    },
                    [`&:not(.${treeItemClasses.disabled}):hover`]: {
                        backgroundColor: ownerState?.disableSelection
                            ? 'transparent !important'
                            : alpha((theme as Theme).palette.grey[100], 0.6),
                    },
                    [`&.${treeItemClasses.selected}`]: {
                        backgroundColor: ownerState?.disableSelection
                            ? 'transparent !important'
                            : alpha((theme as Theme).palette?.grey[100], 0.6),

                        [`&.${treeItemClasses.focused}`]: {
                            backgroundColor: ownerState?.disableSelection
                                ? 'transparent !important'
                                : alpha((theme as Theme).palette?.grey[100], 0.6),
                        },
                    },
                    [`&.${treeItemClasses.focused}`]: {
                        backgroundColor: ownerState?.disableSelection
                            ? 'transparent !important'
                            : alpha((theme as Theme).palette?.grey[100], 0.6),
                    },
                },
                [`& .${treeItemClasses.groupTransition}`]: {
                    borderLeft: `1px dashed ${(theme as Theme).palette.grey[100]}`,
                },
                [`& .${treeItemClasses.iconContainer} svg`]: {
                    transform: 'translateY(-1px)',
                },

                '&.small': {
                    [`& .${treeItemClasses.root}`]: {
                        [`& .${treeItemClasses.content}`]: {
                            [`& .${treeItemClasses.label}`]: {
                                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET}) !important`,
                                paddingLeft: '2px',

                                'p, span, strong': {
                                    fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                                },

                                '.MuiSvgIcon-root': {
                                    fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 1px)`,
                                },
                            },
                            [`& .${treeItemClasses.iconContainer} svg`]: {
                                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 1px) !important`,
                            },
                        },
                    },
                },
            }),
        },
    },
};
