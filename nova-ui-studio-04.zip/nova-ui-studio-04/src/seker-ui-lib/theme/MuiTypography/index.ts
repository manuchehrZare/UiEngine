import type { Components, Theme } from '@mui/material';
import { alertTitleClasses, dialogTitleClasses } from '@mui/material';
import { generateClass } from '../../utils/methods/design';
import { DesignTypeEnum } from '../../utils/types/common';

export const MuiTypographyTheme: Components = {
    MuiTypography: {
        styleOverrides: {
            root: ({ theme, ownerState }) => ({
                textTransform: 'none',
                [`&:not(.${alertTitleClasses.root}):not(.${dialogTitleClasses.root}):not(.${generateClass('NavTitle')}):not(.${generateClass('Label')} &):not(.${generateClass('KeyValueList')} &)`]:
                    {
                        color: (theme as Theme).palette.primary.main,
                    },

                [`&.${DesignTypeEnum.Default}`]: {
                    fontSize: (ownerState as any)?.sx?.fontSize || `var(--field-label-font-size)`,
                },

                [`&.${DesignTypeEnum.SET}`]: {
                    fontSize: (ownerState as any)?.sx?.fontSize || `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                },

                [`.${generateClass('Label')} &`]: {
                    fontWeight: (ownerState as any)?.sx?.fontWeight || 600,

                    [`&.${DesignTypeEnum.SET}`]: {
                        color: ownerState.color || (theme as Theme).palette.green.main,
                    },
                },

                [`&.${generateClass('NumberFormat-prefix')}`]: {
                    fontSize: '1em',
                },

                [`&.${generateClass('NumberFormat-suffix')}`]: {
                    fontSize: '1em',
                },

                [`&.${generateClass('NumberFormat-styledValue-integerPart')}`]: {
                    fontSize: '1em',
                },

                [`&.${generateClass('NumberFormat-styledValue-integerFirstPart')}`]: {
                    fontSize: '1em',
                },

                [`&.${generateClass('NumberFormat-styledValue-fractionalPart')}`]: {
                    fontSize: '0.7em',

                    [`.${DesignTypeEnum.SET} &`]: {
                        fontSize: '0.9em',
                    },
                },
            }),
            overline: {
                lineHeight: 1,
                fontSize: '.65em',
                [`&.${generateClass('NavTitle')}`]: {
                    fontSize: '.6em',
                    fontWeight: 800,
                },
            },
            h4: {
                fontSize: '1.3em',
                fontWeight: 600,
            },
            h5: {
                fontSize: '1.1em',
                fontWeight: 600,
            },
            h6: {
                fontSize: '.9em',
                fontWeight: 600,
                [`&.${generateClass('NavTitle')}`]: {
                    fontSize: '.7em',
                },
            },
        },
    },
};
