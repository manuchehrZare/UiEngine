import type { Components, Theme } from '@mui/material';

const tabConfig = {
    item: {
        marginRight: 10,
    },
};

export const MuiTabTheme: Components = {
    MuiTabs: {
        styleOverrides: {
            root: {
                width: '100%',
                minHeight: 'auto',
            },
            flexContainer: {
                height: '100%',
            },
            indicator: ({ theme }) => ({
                backgroundColor: (theme as Theme).palette.green.light,
                height: 3.75,
                borderTopLeftRadius: 10,
                borderTopRightRadius: 10,
            }),
            scrollButtons: ({ theme }) => ({
                color: (theme as Theme).palette.primary.main,
                transition: 'width .3s',

                '&.Mui-disabled': {
                    width: 0,
                },
            }),
        },
    },
    MuiTab: {
        styleOverrides: {
            root: ({ theme }) => ({
                minWidth: 0,
                marginRight: tabConfig.item.marginRight,
                color: (theme as Theme).palette.primary[500],
                fontWeight: 600,
                textTransform: 'none',
                fontSize: 'var(--field-label-font-size)',
                minHeight: 'auto',

                '&:last-child': {
                    marginRight: 0,
                },
                '&.Mui-selected': {
                    color: (theme as Theme).palette.secondary.main,
                },
                '.is-small &': {
                    padding: '6px 8px',
                    fontSize: 'calc(var(--field-label-font-size) - 1px)',
                },
            }),
        },
    },
};
