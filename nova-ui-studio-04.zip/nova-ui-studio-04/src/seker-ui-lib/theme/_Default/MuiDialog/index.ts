import type { Components, Theme } from '@mui/material';

export const MuiDialogTheme: Components = {
    MuiDialogTitle: {
        styleOverrides: {
            root: ({ theme }) => ({
                textAlign: 'center',
                borderBottom: 'var(--border-style)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 'bold',
                position: 'sticky',
                top: 0,
                zIndex: 2,
                background: (theme as Theme).palette.common.white,
                padding: '1rem 1.5rem',
                fontSize: 'calc(var(--field-label-font-size) + 1px)',
                minHeight: 57, // if title === ''

                '.close-icon &': {
                    padding: '1rem 3.125rem 1rem 1.5rem',
                },
                '.drag-icon &': {
                    padding: '1rem 5rem 0.5rem 1rem',
                },
                'confirm-icon': {
                    padding: '1rem 3.125rem 1rem 1.5rem',
                },
            }),
        },
    },
    MuiDialogActions: {
        styleOverrides: {
            root: ({ theme }) => ({
                position: 'sticky',
                bottom: 0,
                zIndex: 2,
                background: (theme as Theme).palette.common.white,
                borderTop: 'var(--border-style)',
                justifyContent: 'center',
            }),
        },
    },
    MuiDialogContent: {
        styleOverrides: {
            root: {
                padding: 0,
            },
        },
    },
    MuiDialog: {
        styleOverrides: {
            root: {
                boxShadow: 'var(--box-shadow-2)',
                fontSize: 'var(--field-label-font-size)',
            },
            paper: {
                boxShadow: 'var(--box-shadow-2)',
                '& .modal-close-icon': {
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 3,
                },
                '& .modal-drag-icon': {
                    position: 'absolute',
                    right: 40,
                    top: 8,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 3,
                },
                '& .confirm-drag-icon': {
                    position: 'absolute',
                    right: 5,
                    top: 5,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 3,
                },
                '& form': {
                    width: '100%',
                    maxHeight: 'calc(100vh - 64px)',
                    display: 'flex',
                    flexDirection: 'column',
                },

                '&.fullHeight': {
                    height: window.innerHeight - 64,
                },
            },
        },
    },
    MuiDrawer: {
        styleOverrides: {},
        defaultProps: {
            PaperProps: {
                sx: {
                    backgroundColor: (theme) => theme.palette.grey[50],
                },
            },
        },
    },
};
