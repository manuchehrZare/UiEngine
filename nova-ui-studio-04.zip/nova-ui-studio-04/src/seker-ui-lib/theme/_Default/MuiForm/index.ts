import type { Components, Theme } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';
import { dataGridClasses } from '../../..';

export const MuiFormTheme: Components = {
    MuiFormControl: {
        styleOverrides: {
            root: {
                '&.upload-form-control': {
                    width: '100%',
                },
                [`&.${generateClass('Checkbox-formControl')}, &.${generateClass('Switch-formControl')}`]: {
                    display: 'flex',
                    alignItems: 'flex-start',
                    justifyContent: 'flex-start',
                },
                '&.radio-group-labelPlacement-start': {
                    flexDirection: 'initial',
                    flexWrap: 'wrap',
                },
            },
        },
    },
    MuiFormGroup: {
        styleOverrides: {
            root: {
                '.radio-group-labelPlacement-start &': {
                    marginTop: '-7.5px !important',
                },
            },
        },
    },
    MuiFormHelperText: {
        styleOverrides: {
            root: ({ ownerState }) => ({
                [`&.${generateClass('HelperText')}`]: {
                    '&:not(.radio-group):not(.select):not(.switch):not(.range-input):not(.upload)': {
                        paddingLeft: 17,
                        marginTop: -5,
                    },
                    '&.radio-group': {
                        flex: '0 0 100%',
                    },
                    '&.range-input': {
                        ...(ownerState.size === 'small' && {
                            fontSize: 'calc(var(--field-label-font-size) - 2px)',
                        }),
                        ...(ownerState.size === 'medium' && {
                            fontSize: 'var(--field-label-font-size)',
                        }),
                    },
                    '&.upload': {
                        paddingLeft: 4,
                        marginTop: 3,
                    },
                    '&.radio, &.checkbox': {
                        ...(ownerState.size === 'small' && {
                            paddingLeft: '15.2px !important',
                        }),
                        ...(ownerState.size === 'medium' && {
                            paddingLeft: '19px !important',
                        }),
                    },
                    '.checbox-labelPlacement-start &, .checbox-labelPlacement-top &, .checbox-labelPlacement-bottom &, .switch-labelPlacement-start &':
                        {
                            paddingLeft: 0,
                            marginLeft: 0,
                            '&.small, &.medium': {
                                paddingLeft: '0 !important',
                            },
                        },
                    '.checbox-labelPlacement-top &, .checbox-labelPlacement-bottom &, .switch-labelPlacement-top &, .switch-labelPlacement-bottom &':
                        {
                            textAlign: 'center',
                            marginLeft: 0,
                        },
                    '.switch-labelPlacement-end &': {
                        marginLeft: 54,
                        '&.small': {
                            marginLeft: '46px',
                            marginTop: '-4px',
                        },
                    },
                },
            }),
        },
    },
    MuiFormControlLabel: {
        styleOverrides: {
            root: ({ ownerState }) => ({
                cursor: 'text',
                [`&.${generateClass('Checkbox-label')}`]: {
                    marginBottom: 9,
                    [`.${dataGridClasses.cell} &`]: { marginBottom: 0 },
                },
                [`&.${generateClass('Switch-label')}`]: {
                    padding: '1px',
                    marginBottom: '1px',
                    '.switch-labelPlacement-start &, .switch-labelPlacement-end &': {
                        marginLeft: 0,
                        height: '40px !important',
                    },
                },
                [`&.${generateClass('Checkbox-label')}, &.${generateClass('Switch-label')}`]: {
                    ...(ownerState.labelPlacement === 'start' && {
                        display: 'flex',
                        justifyContent: 'left',
                        marginLeft: 0,
                    }),
                    ...((ownerState.labelPlacement === 'top' || ownerState.labelPlacement === 'bottom') && {
                        marginLeft: 0,
                    }),
                },
                [`&.${generateClass('RangeInput-label')}`]: {
                    marginLeft: '0px',
                    width: '100%',
                    ...(ownerState.labelPlacement === 'top' && {
                        alignItems: 'flex-start',
                    }),

                    '& > .MuiFormControlLabel-label': {
                        ...(ownerState.labelPlacement === 'top' &&
                            ownerState.control.props.orientation === 'vertical' && {
                                marginBottom: '10px !important',
                            }),
                        ...(ownerState.control.props.size === 'small' && {
                            fontSize: 'calc(var(--field-label-font-size) - 1px)',
                        }),
                        ...(ownerState.control.props.size === 'medium' && {
                            fontSize: 'var(--field-label-font-size)',
                        }),
                    },
                },
                [`&.${generateClass('Checkbox-label')}, &.${generateClass('Radio-label')}`]: {
                    [`.${dataGridClasses.cell} &`]: {
                        marginLeft: '0px !important',
                        marginRight: '0px !important',
                    },
                },
            }),
        },
    },
    MuiFormLabel: {
        styleOverrides: {
            root: ({ theme }) => ({
                '&.Mui-focused:not(&.Mui-error)': {
                    color: (theme as Theme).palette.secondary.main,
                },
                [`&.${generateClass('RadioGroup-label')}`]: {
                    '.radio-group-labelPlacement-start &': {
                        paddingRight: '8px',
                    },
                },
            }),
        },
    },
};
