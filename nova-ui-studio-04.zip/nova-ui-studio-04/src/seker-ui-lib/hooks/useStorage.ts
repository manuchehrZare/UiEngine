import { useEffect, useState } from 'react';
import { constants } from '..';

export type UseStorageOptions = {
    key: string;
    source: 'local' | 'session';
};

export type StorageValueType<T> = T | null;

export type UseStorageReturnType<T> = {
    newValue: StorageValueType<T>;
    oldValue: StorageValueType<T>;
};

const useStorage = <T>({ key, source }: UseStorageOptions): UseStorageReturnType<T> => {
    const initialStorageValue: UseStorageReturnType<T> = { newValue: null, oldValue: null };

    const getValue = (value: string | null) => {
        return value ? JSON.parse(value) : null;
    };

    if (key) {
        const data = source === 'local' ? localStorage[key] : sessionStorage[key];
        initialStorageValue.newValue = getValue(data);
        initialStorageValue.oldValue = getValue(data);
    }

    const [storedValue, setStoredValue] = useState<UseStorageReturnType<T>>(initialStorageValue);

    const syncStorage = (event: StorageEvent) => {
        if (event.key === key) {
            setStoredValue({ newValue: getValue(event.newValue), oldValue: getValue(event.oldValue) });
        } else {
            event.key === null && setStoredValue((prevState) => ({ newValue: null, oldValue: prevState.newValue }));
        }
    };

    useEffect(() => {
        window.addEventListener(constants.key.StorageEventName, (event) => syncStorage(event as StorageEvent));
        return () => {
            window.removeEventListener(constants.key.StorageEventName, (event) => syncStorage(event as StorageEvent));
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return storedValue;
};

export default useStorage;
