/* eslint-disable react-hooks/rules-of-hooks */
import type { FC } from 'react';
import React, { useEffect } from 'react';
import type { IBANProps, IIBANDisplayProps, IIBANError } from './type';
import { IBANErrorTypeEnum } from './type';
import { isNumber, omit } from 'lodash';
import { constants, groupString, iban, useTranslation } from '../../../utils';
import { Input, Box } from '../../../../seker-ui-lib';
import { useController } from 'react-hook-form';

const IBAN: FC<IBANProps> = (props: IBANProps) => {
    const { input } = props;

    if (input) {
        const { t, locale } = useTranslation();
        const {
            field: { ...field },
            formState: { isSubmitted, isDirty, dirtyFields, errors },
        } = useController({ name: props.name, control: props.control });

        // This function validates IBAN format, applicable for all IBAN values
        const isValidIban = (targetIbanValue: string): boolean => {
            const cleanedIban = iban(targetIbanValue).toUpperCase();

            // First two characters must be letters
            const countryCode = cleanedIban.slice(0, 2);
            if (!/^[A-Z]{2}$/.test(countryCode)) {
                return false;
            }

            // Remaining characters must be numbers
            const restOfIban = cleanedIban.slice(2);
            if (!/^\d+$/.test(restOfIban)) {
                return false;
            }

            return true;
        };

        // If fixedCountryCode is true, it will be 'TR' by default
        // If another country code is needed, it should be sent as a parameter
        const getFixedCountryCode = (): string | null => {
            if (!props?.fixedCountryCode) return null;
            if (props?.fixedCountryCode === true)
                return Object.keys(constants.IBANFormats).reduce(
                    (acc, code) => {
                        acc[code as keyof typeof constants.IBANFormats] = code;
                        return acc;
                    },
                    {} as Record<keyof typeof constants.IBANFormats, string>,
                ).TR;
            return props.fixedCountryCode;
        };

        // used for error cases
        const errorHandler = (error: IIBANError) => {
            props?.onError?.(error);
            // eslint-disable-next-line
            console.error(error);
        };

        const replaceChangeHandler = (value: string, type: 'letter' | 'number') => {
            if (type === 'letter') {
                return value.replace(/[^A-Z]/g, '');
            }
            return value.replace(/[^0-9]/g, '');
        };

        const formatIBANDisplay = (value: string): string => {
            return iban(value, { formatted: true });
        };

        const validateAndFormatIBAN = (value: string): string => {
            // Remove spaces
            let cleanValue = iban(value).toUpperCase();
            const countryCodeFromProps = getFixedCountryCode();

            // If fixedCountryCode exists and value length is less than 2, use the fixed country code
            if (countryCodeFromProps && cleanValue.length < 2) {
                cleanValue = countryCodeFromProps + cleanValue;
            }
            if (countryCodeFromProps && cleanValue.length >= 2) {
                const currentCountryCode = cleanValue.slice(0, 2);
                if (currentCountryCode !== countryCodeFromProps) {
                    cleanValue = countryCodeFromProps + cleanValue.slice(2);
                }
            }

            // Get first two characters (country code)
            const countryCode = cleanValue.slice(0, 2);
            const countryFormat = (constants.IBANFormats as any)[countryCode];
            if (countryFormat) {
                // Validate based on country format
                if (cleanValue.length > countryFormat.length) {
                    cleanValue = cleanValue.slice(0, countryFormat.length);
                }

                // Character validation based on country format
                if (!countryFormat.regex.test(cleanValue)) {
                    // Only letter validation for first two characters
                    if (cleanValue.length <= 2) {
                        cleanValue = replaceChangeHandler(cleanValue, 'letter');
                    } else {
                        // Get first two characters as letters
                        const firstTwoChars = replaceChangeHandler(cleanValue.slice(0, 2), 'letter');
                        // Get remaining characters as numbers
                        const rest = replaceChangeHandler(cleanValue.slice(2), 'number');
                        cleanValue = firstTwoChars + rest;
                    }
                }
            }
            // Default behavior for unknown country codes
            if (cleanValue.length <= 2) {
                cleanValue = replaceChangeHandler(cleanValue, 'letter');
            } else {
                const firstTwoChars = replaceChangeHandler(cleanValue.slice(0, 2), 'letter');
                const rest = replaceChangeHandler(cleanValue.slice(2), 'number');
                cleanValue = firstTwoChars + rest;
            }
            return cleanValue;
        };

        const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
            const value = event.target.value;

            // Check if the entire input is being deleted
            // If deleted and fixedCountryCode exists, restore it and return
            const fixedCountryCode = getFixedCountryCode();
            if (fixedCountryCode && value.length < fixedCountryCode.length) {
                event.target.value = fixedCountryCode;
                return;
            }
            const formattedValue = validateAndFormatIBAN(value);
            const displayValue = formatIBANDisplay(formattedValue);
            event.target.value = displayValue;
        };

        // Determine maximum length based on country code
        const getMaxLength = (): number => {
            const currentValue = field?.value || '';
            // Remove spaces
            const cleanValue = iban(currentValue);
            const countryCode = cleanValue.slice(0, 2).toUpperCase();
            const countryFormat = (constants.IBANFormats as any)[countryCode];

            if (countryFormat) {
                // Add space every 4 characters
                // Example: 26 character IBAN requires 6 spaces (26/4 = 6.5, rounded down)
                const numberOfSpaces = Math.floor(countryFormat.length / 4);
                return countryFormat.length + numberOfSpaces;
            }

            return 34 + Math.floor(34 / 4); // Default maximum length + spaces
        };

        useEffect(() => {
            // Get current value and reset state
            const defaultValue = field?.value;
            const isFieldReset = !isDirty && !dirtyFields[props.name];
            const fixedCountryCode = getFixedCountryCode();

            if (defaultValue) {
                if (
                    isValidIban(defaultValue) ||
                    (fixedCountryCode && defaultValue && defaultValue === fixedCountryCode)
                ) {
                    // Valid IBAN - format and display
                    const displayValue = formatIBANDisplay(validateAndFormatIBAN(defaultValue));
                    field.onChange(displayValue);
                } else {
                    // Invalid IBAN - handle based on fixedCountryCode
                    field.onChange(fixedCountryCode || '');
                    errorHandler({
                        fieldName: props.name,
                        message: t(locale.labels.invalidDefaultValue),
                        invalidValue: defaultValue,
                        code: IBANErrorTypeEnum.InvalidDefaultValue,
                    });
                }
            } else if (fixedCountryCode && !isFieldReset) {
                // No value but fixedCountryCode exists
                field.onChange(fixedCountryCode);
            }
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [isDirty, dirtyFields]);

        // This effect handles the error clearing when;
        // the value matches the country code length when the form is not submitted
        useEffect(() => {
            const fixedCountryCode = getFixedCountryCode();
            const cleanValue = iban(field.value) || '';
            const hasError = errors[props.name];

            if (
                hasError &&
                !isSubmitted &&
                fixedCountryCode &&
                cleanValue &&
                cleanValue.length === fixedCountryCode.length
            ) {
                props.control._runSchema([props.name]).then(() => {
                    const newErrors = { ...errors };
                    // Remove the property from errors object
                    delete newErrors[props.name];

                    props.control._subjects.state.next({
                        errors: newErrors,
                    });
                    // Force update form state
                    props.control._setValid();
                });
            }
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [field.value, isSubmitted, props.name, props.control, errors[props.name]]);

        const handleInputInsertValidation = (
            e: React.ClipboardEvent<HTMLInputElement> | React.DragEvent<HTMLInputElement>,
            rawInsertedText: string,
        ) => {
            const cleanedInserted = iban(rawInsertedText);
            // eslint-disable-next-line
            const input = e.currentTarget;
            const { value: currentValue, selectionStart, selectionEnd } = input;
            if (selectionStart === null || selectionEnd === null) return;

            const before = currentValue.slice(0, selectionStart);
            const after = currentValue.slice(selectionEnd);
            const resultingValue = before + cleanedInserted + after;

            const fullReplace =
                currentValue.length === 0 || (selectionStart === 0 && selectionEnd === currentValue.length);

            // If the entire input value is being replaced with the pasted value
            if (fullReplace && !isValidIban(cleanedInserted)) {
                e.preventDefault();
                errorHandler({
                    fieldName: props.name,
                    message: t(locale.labels.ibanFullReplaceFailed),
                    invalidValue: resultingValue,
                    code: IBANErrorTypeEnum.FullReplace,
                });
                return;
            }

            // If partially replacing the input value
            if (!fullReplace && !isValidIban(resultingValue)) {
                e.preventDefault();
                errorHandler({
                    fieldName: props.name,
                    message: t(locale.labels.ibanInsertFailedError),
                    invalidValue: resultingValue,
                    code: IBANErrorTypeEnum.InsertText,
                });
                return;
            }
        };
        return (
            <Input
                {...omit(props, ['input', 'fixedCountryCode'])}
                inputProps={{
                    maxLength: getMaxLength(),
                    onChange: handleChange,
                    onPaste: (e: React.ClipboardEvent<HTMLInputElement>) => {
                        const pastedText = e.clipboardData.getData('text');
                        handleInputInsertValidation(e, pastedText);
                    },
                    onDrop: (e: React.DragEvent<HTMLInputElement>) => {
                        const droppedText = e.dataTransfer.getData('text');
                        handleInputInsertValidation(e, droppedText);
                    },
                }}
            />
        );
    }

    const { showBoldAccountNo, accountNoLength, value } = props as IIBANDisplayProps;
    const cleanIBAN = iban(value);
    if (showBoldAccountNo) {
        const boldCharCount = isNumber(accountNoLength) ? accountNoLength : 9;
        const getGroupStringOptions = (): number[] => {
            const remainder: number = (cleanIBAN.length - boldCharCount) % 4;
            if (remainder === 0) {
                return [4];
            }
            return [4 - remainder, 4];
        };
        const firstIbanPart = cleanIBAN.slice(0, -boldCharCount);
        const secondIbanPart = cleanIBAN.slice(-boldCharCount);

        return (
            <>
                {getGroupStringOptions().length > 1
                    ? groupString(firstIbanPart, 4)
                    : `${groupString(firstIbanPart, 4)} `}
                <Box component="b">{groupString(secondIbanPart, getGroupStringOptions())}</Box>
            </>
        );
    }
    return <>{iban(cleanIBAN, { formatted: true })}</>;
};

export default IBAN;
