import type { FC, JSX } from 'react';
import type { IPhoneNumberProps } from './type';
import { constants, useTranslation } from '../../../utils';
import NumberInput from '../../Form/NumberInput';
import { NumberInputReturnValueEnum } from '../../Form/NumberInput/type';
import NumberFormat from '../../Display/NumberFormat';

const PhoneNumber: FC<IPhoneNumberProps> = (props: IPhoneNumberProps): JSX.Element => {
    const { component, withCountryCode, withZero, withoutAreaCode, withoutBrackets, ...rest } = props;
    const { t, locale } = useTranslation();

    if (component === 'NumberInput') {
        return (
            <NumberInput
                label={props.label || t(locale.labels.telephoneNumber)}
                returnValue={props.returnValue || NumberInputReturnValueEnum.value}
                format={
                    props.format ||
                    (withoutAreaCode
                        ? constants.format.design.phoneNumber.withoutAreacode
                        : withZero
                          ? withoutBrackets
                              ? withCountryCode
                                  ? constants.format.design.phoneNumber.withCountryCode.withoutBrackets
                                  : constants.format.design.phoneNumber.withAreaCode.withoutBrackets.withZero
                              : withCountryCode
                                ? constants.format.design.phoneNumber.withCountryCode.withBrackets
                                : constants.format.design.phoneNumber.withAreaCode.withBrackets.withZero
                          : withoutBrackets
                            ? constants.format.design.phoneNumber.withAreaCode.withoutBrackets.withoutZero
                            : constants.format.design.phoneNumber.withAreaCode.withBrackets.withoutZero)
                }
                mask={props.mask || constants.format.char.underscore}
                name={props.name}
                control={props.control}
                {...rest}
            />
        );
    }
    return (
        <NumberFormat
            format={
                props.format ||
                (withoutAreaCode
                    ? constants.format.design.phoneNumber.withoutAreacode
                    : withZero
                      ? withoutBrackets
                          ? withCountryCode
                              ? constants.format.design.phoneNumber.withCountryCode.withoutBrackets
                              : constants.format.design.phoneNumber.withAreaCode.withoutBrackets.withZero
                          : withCountryCode
                            ? constants.format.design.phoneNumber.withCountryCode.withBrackets
                            : constants.format.design.phoneNumber.withAreaCode.withBrackets.withZero
                      : withoutBrackets
                        ? constants.format.design.phoneNumber.withAreaCode.withoutBrackets.withoutZero
                        : constants.format.design.phoneNumber.withAreaCode.withBrackets.withoutZero)
            }
            {...rest}
        />
    );
};
export default PhoneNumber;
