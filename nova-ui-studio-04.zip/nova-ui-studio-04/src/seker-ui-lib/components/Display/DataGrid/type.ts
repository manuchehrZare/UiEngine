import type {
    DataGridProProps,
    GridActionsColDef,
    GridCallbackDetails,
    GridColDef,
    GridColumnTypes,
    GridColumnVisibilityModel,
    GridRowSelectionModel,
    GridSingleSelectColDef,
    GridValidRowModel,
} from '@mui/x-data-grid-pro';
import type { GridInitialStatePro } from '@mui/x-data-grid-pro/models/gridStatePro';
import type { ICommonProps } from '../../../utils/types/common';
import type { IPaginationProps } from '../Pagination/type';

export const rowUniqueKey = 'rowId';

interface IEditChangeReturn {
    index: number;
    newRow: any;
    oldRow: any;
    rowId: number;
}

interface ISelectChangeReturn {
    index: number;
    indexes: number[];
    row: any;
    rowId: number;
    rowIds: number[];
    rows: any[];
}

interface ICommonFileProps {
    /**
     * To export default is true, to import default is false.
     **/
    showCSV?: boolean;
    /**
     * To export default is true, to import default is false.
     **/
    showXLS?: boolean;
    /**
     * To export default is true, to import default is false.
     **/
    showXLSX?: boolean;
}

interface IFileImportProps extends ICommonFileProps {
    /**
     * Manage importing data with using this property.
     **/
    onImport?: (params: any[]) => any[];
}

interface IFileExportProps extends ICommonFileProps {
    /**
     * This property determines file name of exported file.
     **/
    fileName?: string;
    /**
     * This property gets fields that you don't want to export.
     **/
    hiddenColumns?: string[];
    /**
     * Manage exporting data with using this property.
     **/
    onExport?: (params: any[]) => any[];
}

interface IFileOptionsProps {
    /**
     * Default is true. Includes exporting options
     **/
    export?: IFileExportProps | boolean;
    /**
     * Default is false. Includes importing options.
     **/
    import?: IFileImportProps | boolean;
}

export type ToolbarPropsType =
    | {
          quickFilterDebounce?: number;
          showColumns?: boolean;
          showDensity?: boolean;
          showFile: false;
          showFilter?: boolean;
          showQuickFilter?: boolean;
      }
    | {
          fileOptions?: IFileOptionsProps;
          quickFilterDebounce?: number;
          showColumns?: boolean;
          showDensity?: boolean;
          showFile?: true;
          showFilter?: boolean;
          showQuickFilter?: boolean;
      };

export type pageSizeOptionsType = number | { label: string; value: number };

export interface IDataGridFooterAndPaginationProps extends Pick<
    DataGridProProps,
    | 'pagination'
    | 'paginationMode'
    | 'hideFooter'
    | 'hideFooterPagination'
    | 'hideFooterSelectedRowCount'
    | 'autoPageSize'
    | 'onPaginationModelChange'
    | 'paginationModel'
    | 'pageSizeOptions'
> {
    numberPagination?: boolean;
    numberPaginationProps?: IPaginationProps;
    page?: number;
    pageSize?: number;
    selectedCountView?: boolean;
}

export interface IDataGridSelectionProps extends Pick<
    DataGridProProps,
    'checkboxSelection' | 'rowSelectionModel' | 'disableRowSelectionOnClick'
> {
    onRowSelectionModelChange?: (rowSelectionModel: GridRowSelectionModel, details: GridCallbackDetails<any>) => void;
    onSelectChange?: (params: ISelectChangeReturn) => void;
    selectionOnClickable?: boolean;
}

export interface IDataGridEditProps extends Pick<DataGridProProps, 'editMode'> {
    onEditChange?: (params: IEditChangeReturn) => void;
    processRowUpdate?: (newRow: any, oldRow: any) => any;
}

export interface IDataGridHiddenColumnsProps extends Pick<
    DataGridProProps,
    'columnVisibilityModel' | 'onColumnVisibilityModelChange'
> {
    hiddenColumns?: string[];
    onHiddenColumnsChange?: (newModel: GridColumnVisibilityModel) => void;
}

export interface IDataGridInitialStateProps extends Pick<
    GridInitialStatePro,
    'sorting' | 'filter' | 'pagination' | 'preferencePanel' | 'pinnedColumns'
> {}

export interface ICustomGridColumnTypes extends GridColumnTypes {
    abbreviation: 'abbreviation';
    counter: 'counter';
    currency: 'currency';
    '': '';
}

export type CustomGridColType = ICustomGridColumnTypes[keyof ICustomGridColumnTypes];

export type GridColBaseDefType<R extends GridValidRowModel = any, V = any, F = V> = Omit<
    GridColDef<R, V, F>,
    'type'
> & {
    type?: CustomGridColType;
};

export type DataGridColDef = GridColBaseDefType | GridSingleSelectColDef | GridActionsColDef;

export type PageSizeType = number | undefined;
export type DataGridColumnsPropsType = DataGridColDef[];

export enum DataGridColumnTypeEnum {
    abbreviation = 'abbreviation',
    actions = 'actions',
    boolean = 'boolean',
    counter = 'counter',
    currency = 'currency',
    date = 'date',
    dateTime = 'dateTime',
    number = 'number',
    singleSelect = 'singleSelect',
    string = 'string',
}

export interface IDataGridProps
    extends
        Pick<
            DataGridProProps,
            | 'loading'
            | 'density'
            | 'localeText'
            | 'sx'
            | 'isRowSelectable'
            | 'rows'
            | 'sortingOrder'
            | 'sortModel'
            | 'sortingMode'
            | 'onSortModelChange'
            | 'filterModel'
            | 'filterMode'
            | 'onFilterModelChange'
            | 'disableColumnFilter'
            | 'disableColumnMenu'
            | 'disableColumnSelector'
            | 'disableDensitySelector'
            | 'disableVirtualization'
            | 'initialState'
            | 'getRowHeight'
            | 'rowHeight'
            | 'columnGroupHeaderHeight'
            | 'columnHeaderHeight'
            | 'slots'
            | 'onCellClick'
            | 'onCellDoubleClick'
            | 'onCellEditStart'
            | 'onCellEditStop'
            | 'onCellKeyDown'
            | 'onRowClick'
            | 'onRowDoubleClick'
            | 'onRowEditStart'
            | 'onRowEditStop'
            | 'onStateChange'
            | 'onColumnHeaderClick'
            | 'onColumnHeaderDoubleClick'
            | 'onColumnHeaderEnter'
            | 'onColumnHeaderLeave'
            | 'onColumnHeaderOut'
            | 'onColumnHeaderOver'
            | 'onColumnOrderChange'
            | 'onColumnVisibilityModelChange'
            | 'onResize'
            | 'apiRef'
            | 'getRowClassName'
            | 'getCellClassName'
            | 'disableMultipleRowSelection'
            | 'pinnedColumns'
            | 'pinnedRows'
            | 'getDetailPanelContent'
            | 'getDetailPanelHeight'
            | 'onRowsScrollEnd'
            | 'className'
            | 'rowCount'
            | 'rowBufferPx'
            | 'rowsLoadingMode'
            | 'scrollbarSize'
            | 'unstable_dataSource'
        >,
        Omit<IDataGridFooterAndPaginationProps, 'hideFooterPagination' | 'hideFooter' | 'hideFooterSelectedRowCount'>,
        Omit<IDataGridSelectionProps, 'disableSelectionOnClick' | 'onSelectionModelChange'>,
        Pick<IDataGridHiddenColumnsProps, 'hiddenColumns' | 'onHiddenColumnsChange'>,
        Pick<IDataGridEditProps, 'editMode' | 'onEditChange'>,
        ICommonProps {
    columns: DataGridColDef[];
    editable?: boolean;
    initialState?: IDataGridInitialStateProps;
    ref?: any;
    sortable?: boolean;
    strippedRows?: boolean;
    toolbar?: boolean;
    toolbarProps?: ToolbarPropsType;
    unpinCounterColumn?: boolean;
}
