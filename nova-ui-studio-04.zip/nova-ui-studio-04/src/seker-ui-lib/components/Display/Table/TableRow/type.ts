import type { TableRowProps } from '@mui/material';
import type { ITableProps } from '../type';

export interface ITableRowProps
    extends
        Pick<
            TableRowProps,
            | 'children'
            | 'className'
            | 'hidden'
            | 'hover'
            | 'id'
            | 'key'
            | 'onClick'
            | 'onClickCapture'
            | 'onDoubleClick'
            | 'onDoubleClickCapture'
            | 'onKeyDown'
            | 'onKeyDownCapture'
            | 'onKeyPress'
            | 'onKeyPressCapture'
            | 'onKeyUp'
            | 'onKeyUpCapture'
            | 'onLoad'
            | 'onLoadCapture'
            | 'onLoadStart'
            | 'onLoadStartCapture'
            | 'onMouseDown'
            | 'onMouseDownCapture'
            | 'onMouseEnter'
            | 'onMouseLeave'
            | 'onMouseMove'
            | 'onMouseMoveCapture'
            | 'onMouseOut'
            | 'onMouseOutCapture'
            | 'onMouseOver'
            | 'onMouseOverCapture'
            | 'onMouseUp'
            | 'onMouseUpCapture'
            | 'onScroll'
            | 'onScrollCapture'
            | 'onWheel'
            | 'onWheelCapture'
            | 'selected'
            | 'sx'
        >,
        Pick<ITableProps, 'ref'> {}
