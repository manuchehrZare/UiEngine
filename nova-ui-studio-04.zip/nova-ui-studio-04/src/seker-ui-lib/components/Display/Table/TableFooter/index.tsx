import { TableFooter as MuiTableFooter } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { ITableFooterProps } from './type';

const TableFooter: FC<ITableFooterProps> = forwardRef(({ children, ...rest }: ITableFooterProps, ref) => {
    return (
        <MuiTableFooter ref={ref} {...rest}>
            {children}
        </MuiTableFooter>
    );
});

export default TableFooter;
