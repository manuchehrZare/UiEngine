import type { SxProps, Theme } from '@mui/material';
import type { ICarouselItemProps, ICarouselProps } from './type';
import { CarouselContentPositionEnum } from './type';
import { generateClass } from '../../../utils/methods/design';

export const MuiCarouselSxProps = ({
    height,
    indicatorsPosition,
}: Pick<ICarouselProps, 'height' | 'indicatorsPosition'>): SxProps<Theme> => ({
    [`.${generateClass('CarouselItem-image')}`]: {
        height: height,
    },
    [`.${generateClass('Carousel-indicator')}`]: {
        ...(indicatorsPosition === 'in' && {
            padding: '10px',
            position: 'absolute',
            bottom: 0,
            zIndex: 1,
        }),
    },
});

export const MuiCarouselItemSxProps = ({
    contentPosition,
    image,
}: Pick<ICarouselItemProps, 'contentPosition' | 'image'>): SxProps<Theme> => ({
    height: '100%',
    [`.${generateClass('CarouselItem-content')}`]: {
        position: 'absolute',
        p: 5,
        ...(contentPosition === CarouselContentPositionEnum.TopStart
            ? { top: 0, left: 0 }
            : contentPosition === CarouselContentPositionEnum.TopCenter
              ? { top: 0, left: '50%', transform: 'translate(-50%, 0)' }
              : contentPosition === CarouselContentPositionEnum.TopEnd
                ? { top: 0, right: 0 }
                : contentPosition === CarouselContentPositionEnum.CenterStart
                  ? { top: '50%', left: 0, transform: 'translate(0, -50%)' }
                  : contentPosition === CarouselContentPositionEnum.Center
                    ? { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }
                    : contentPosition === CarouselContentPositionEnum.CenterEnd
                      ? { top: '50%', right: 0, transform: 'translate(0, -50%)' }
                      : contentPosition === CarouselContentPositionEnum.BottomStart
                        ? { bottom: 0, left: 0 }
                        : contentPosition === CarouselContentPositionEnum.BottomCenter
                          ? { bottom: 0, left: '50%', transform: 'translate(-50%, 0)' }
                          : contentPosition === CarouselContentPositionEnum.BottomEnd
                            ? { bottom: 0, right: 0 }
                            : { top: 0, left: 0 }),
    },
    [`.${generateClass('CarouselItem-image')}`]: {
        background: `center / contain no-repeat url(${image})`,
    },
});
