import type { FC } from 'react';
import { forwardRef } from 'react';
import { DialogActions } from '@mui/material';
import type { IModalFooterProps } from './type';
import { manageClassNames } from '../../..';
import { generateClass } from '../../../utils';

const ModalFooter: FC<IModalFooterProps> = forwardRef(({ children, className, ...rest }: IModalFooterProps, ref) => {
    return (
        <DialogActions className={manageClassNames(generateClass('Modal-Footer'), className)} ref={ref} {...rest}>
            {children}
        </DialogActions>
    );
});

export default ModalFooter;
