import type { FC } from 'react';
import { useRef, useEffect, useState, memo } from 'react';
import { useController } from 'react-hook-form';
import type { Theme } from '@mui/material';
import { FormControl, FormHelperText, FormControlLabel, Switch as MuiSwitch } from '@mui/material';
import type { ISwitchProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const Switch: FC<ISwitchProps> = ({
    helperText,
    name,
    hidden = false,
    label,
    control,
    onChange,
    size,
    color = 'secondary',
    design,
    labelPlacement = 'end',
    className,
    sx,
    deps,
    autoFocus = false,
    disableRipple = false,
    disabled = false,
    readOnly = false,
    required = false,
}: ISwitchProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const labelRef: any = useRef(null);
    const [helperTextStyleWidth, setHelperTextStyleWidth] = useState(null);
    const {
        field,
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    /* istanbul ignore next */
    useEffect(() => {
        if (labelRef) {
            if (labelPlacement === 'top' || labelPlacement === 'bottom') {
                setHelperTextStyleWidth(labelRef.current?.offsetWidth);
            }
        }
        // eslint-disable-next-line react-hooks/refs
    }, [labelRef?.current?.offsetWidth, labelPlacement]);

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <FormControl
                variant="outlined"
                className={manageClassNames(
                    generateClass('Switch-formControl'),
                    `switch-labelPlacement-${labelPlacement}`,
                    {
                        'label-active': Boolean(getLabel()),
                    },
                    className,
                )}
                error={Boolean(error) && validationControl}
                disabled={disabled}
                fullWidth
                size={size}
                hidden={hidden}
                sx={sx}>
                <FormControlLabel
                    ref={labelRef}
                    disabled={disabled}
                    hidden={hidden}
                    label={getLabel()}
                    labelPlacement={labelPlacement}
                    className={manageClassNames(
                        generateClass('Switch-label'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                    )}
                    autoFocus={autoFocus}
                    control={
                        <MuiSwitch
                            {...field}
                            readOnly={readOnly}
                            disableRipple={disableRipple}
                            autoFocus={autoFocus}
                            color={color}
                            size={size}
                            disabled={disabled}
                            required={required}
                            checked={field.value}
                            onChange={(event, checked) => {
                                onChange?.(event, checked);
                                field.onChange(checked);
                            }}
                            inputProps={{
                                'aria-label': label,
                                role: 'switch',
                            }}
                        />
                    }
                />
                {((validationControl && error?.message) || helperText) && (
                    <FormHelperText
                        sx={{ width: `${helperTextStyleWidth}px` }}
                        className={manageClassNames(
                            generateClass('HelperText'),
                            'switch',
                            getComponentDesignProperty(design, storageDesign.newValue),
                            `${size}`,
                        )}>
                        {error?.message || helperText}
                    </FormHelperText>
                )}
            </FormControl>
        </ThemeProvider>
    );
};

export default memo(Switch);
