import { KeyboardArrowDown } from '@mui/icons-material';
import {
    autocompleteClasses,
    FormControl,
    FormHelperText,
    InputBase,
    InputLabel,
    Autocomplete as MuiAutocomplete,
} from '@mui/material';
import { isBoolean, isNumber, isString, omit, uniqBy } from 'lodash';
import type { JSX, ReactElement } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { renderToString } from 'react-dom/server';
import { useController } from 'react-hook-form';
import { Box, chipClasses } from '../../../../../seker-ui-lib';
import { constants, generateClass, i18n, locale, manageClassNames, stripHtmlFromText } from '../../../../utils';
import { DesignTypeEnum } from '../../../../utils/types/common';
import type { IAutocompleteProps } from '../type';

const Autocomplete = <T,>({
    helperText,
    name,
    autoComplete,
    disabled,
    readOnly,
    required,
    label,
    hidden,
    autoFocus,
    open,
    noOptionsDataText = i18n.t(locale.contents.thereWereNoResults),
    loadingText = i18n.t(locale.contents.loading),
    disableCloseOnSelect,
    options,
    multiple,
    control,
    fullWidth = true,
    labelPlacement,
    labelWidth,
    labelEllipsis,
    sx,
    onKeyPress,
    onBlur,
    onFocus,
    onChange,
    placeholder,
    popupIcon,
    openText = '',
    closeText = '',
    disablePopupIconRotate,
    componentsProps,
    className,
    deps,
    ChipProps,
    renderTags,
    showSelectedItemsSummary,
    variant,
    getOptionDisabled,
}: IAutocompleteProps<T>): JSX.Element => {
    const labelRef: any = useRef(null);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });
    const [labelStyleWidth, setLabelStyleWidth] = useState(null);

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const optionsData = useMemo<T[]>(() => {
        if (options?.data?.length) {
            return options?.dataFormatter ? options.dataFormatter(options.data) : options.data;
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [options?.data, options?.dataFormatter]);

    useEffect(() => {
        /*istanbul ignore else*/
        if (labelRef) {
            setLabelStyleWidth(labelRef?.current?.offsetWidth || null);
        }
    }, [labelRef?.current?.offsetWidth]);

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    /* istanbul ignore next */
    const renderInput = (params: any) => {
        const { InputLabelProps, InputProps, ...others } = params;
        return (
            <FormControl
                variant={variant}
                error={Boolean(error) && validationControl}
                className={manageClassNames(labelPlacement, { [constants.classNames.labelEllipsis]: labelEllipsis })}
                sx={sx}>
                <InputLabel
                    variant={variant}
                    ref={labelRef}
                    className={manageClassNames(labelPlacement, {
                        [constants.classNames.labelEllipsis]: labelEllipsis,
                    })}
                    title={typeof getLabel() === 'string' ? `${getLabel()}` : ''}
                    {...InputLabelProps}
                    sx={{
                        width: labelWidth,
                    }}>
                    {getLabel()}
                </InputLabel>
                <Box
                    sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        width: `calc(100% - ${
                            labelPlacement === 'top' || (!label && !labelWidth)
                                ? '0px'
                                : labelWidth === 'auto'
                                  ? `${String(labelStyleWidth || 0)}px`
                                  : labelWidth
                                    ? isNumber(labelWidth)
                                        ? `${labelWidth}px`
                                        : labelWidth
                                    : `var(--field-label-width-${[DesignTypeEnum.SET]})`
                        })`,
                    }}>
                    <InputBase
                        {...others}
                        {...InputProps}
                        name={field.name}
                        inputRef={ref}
                        id={name}
                        fullWidth
                        autoComplete={autoComplete}
                        spellCheck={false}
                        autoFocus={autoFocus}
                        onKeyPress={onKeyPress}
                        onFocus={onFocus}
                        onBlur={onBlur}
                        placeholder={placeholder}
                    />
                    {(error?.message || helperText) && (
                        <FormHelperText>{(validationControl && error?.message) || helperText}</FormHelperText>
                    )}
                </Box>
            </FormControl>
        );
    };

    return (
        <MuiAutocomplete
            {...field}
            options={uniqBy(
                options?.renderDisplayList
                    ? optionsData.map((item) => {
                          const displayFieldData = options.renderDisplayList
                              ? isString(options.renderDisplayList(item))
                                  ? options?.renderDisplayList(item)
                                  : stripHtmlFromText(renderToString(options?.renderDisplayList(item) as ReactElement))
                              : item[options.displayField];
                          return {
                              ...item,
                              [options.displayField]: displayFieldData,
                          };
                      })
                    : optionsData,
                options?.displayValue || '',
            )}
            {...(options?.renderDisplayList && {
                renderOption: (props, option: T) => {
                    const optionData =
                        optionsData.find((item) => item[options.displayValue] === option[options.displayValue]) ||
                        option;
                    return (
                        <Box component="li" {...props} key={props.id}>
                            {options?.renderDisplayList?.(optionData)}
                        </Box>
                    );
                },
            })}
            getOptionLabel={(option: any) => {
                if ((isString(option) || isNumber(option) || isBoolean(option)) && optionsData?.length && option) {
                    const item = optionsData?.filter((findItem) => findItem[options?.displayValue] === option)[0];
                    return options?.renderDisplayField
                        ? options?.renderDisplayField(item)
                        : item[options?.displayField];
                }
                return option[options?.displayField || ''] || '';
            }}
            clearOnEscape
            disableClearable={optionsData?.length === 0}
            disableCloseOnSelect={multiple ? true : disableCloseOnSelect}
            open={open}
            openText={openText}
            closeText={closeText}
            multiple={optionsData?.length > 0 && multiple} // A check for the existence of options.data has been added, as it shows an empty chip if the initial value is given for the form in multiple use fed with delayed data.
            fullWidth={fullWidth}
            ChipProps={{
                variant: 'standard',
                size: 'small',
                className: manageClassNames(autocompleteClasses.tag, {
                    [`${ChipProps?.className}`]: Boolean(ChipProps?.className),
                    [`${chipClasses?.cornered}`]:
                        typeof ChipProps?.cornered !== 'undefined'
                            ? ChipProps.cornered
                            : !(ChipProps?.leftCornered || ChipProps?.rightCornered),
                    [`${chipClasses?.corneredLeft}`]: ChipProps?.leftCornered,
                    [`${chipClasses?.corneredRight}`]: ChipProps?.rightCornered,
                }),
                ...omit(ChipProps, ['className', 'cornered', 'leftCornered', 'rightCornered']),
            }}
            renderTags={
                renderTags
                    ? renderTags
                    : showSelectedItemsSummary
                      ? (tagValue) => {
                            const count = tagValue?.length || 0;
                            return (
                                <Box className={manageClassNames(generateClass('selectedItems-summary'), variant)}>
                                    {typeof showSelectedItemsSummary === 'function'
                                        ? showSelectedItemsSummary(count)
                                        : i18n.t(locale.labels.membersSelected, { count })}
                                </Box>
                            );
                        }
                      : undefined
            }
            popupIcon={popupIcon || <KeyboardArrowDown />}
            noOptionsText={noOptionsDataText}
            loadingText={loadingText}
            disabled={disabled}
            readOnly={readOnly}
            hidden={hidden}
            componentsProps={{
                paper: {
                    className: manageClassNames(DesignTypeEnum.SET, {
                        [`${className}__paper`]: Boolean(className),
                        [`${componentsProps?.paper?.className}`]: Boolean(componentsProps?.paper?.className),
                    }),
                    ...(componentsProps?.paper ? omit(componentsProps?.paper, ['className']) : {}),
                },
                popupIndicator: {
                    className: manageClassNames({
                        disablePopupIconRotate: disablePopupIconRotate,
                        [`${className}__popupIndicator`]: Boolean(className),
                        [`${componentsProps?.popupIndicator?.className}`]: Boolean(
                            componentsProps?.popupIndicator?.className,
                        ),
                    }),
                    ...(componentsProps?.popupIndicator ? omit(componentsProps?.popupIndicator, ['className']) : {}),
                },
                ...(componentsProps ? omit(componentsProps, ['paper', 'popupIndicator']) : {}),
            }}
            isOptionEqualToValue={(option, value) => {
                const key = options?.displayValue;
                return (option?.[key] ?? '') === value;
            }}
            className={DesignTypeEnum.SET}
            renderInput={(params) => renderInput(params)}
            onChange={(event, newData, reason, details) => {
                const value = Array.isArray(newData)
                    ? newData.map((item) =>
                          typeof item === 'object' && item !== null ? item[options?.displayValue] : item,
                      )
                    : typeof newData === 'object' && newData !== null
                      ? newData[options?.displayValue]
                      : (newData ?? null);

                field.onChange(value);
                onChange?.(event, value, reason, details);
            }}
            getOptionDisabled={getOptionDisabled}
        />
    );
};
export default Autocomplete;
