import Default from './DefaultNumberInput';
import SET from './SETNumberInput';
import type { FC } from 'react';
import { memo } from 'react';
import type { INumberInputProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const NumberInput: FC<INumberInputProps> = ({
    design,
    allowEmptyFormatting = false,
    allowLeadingZeros = false,
    allowNegative = false,
    autoComplete = 'off',
    fixedDecimalScale = false,
    focused = false,
    fullWidth = true,
    hidden = false,
    labelEllipsis = true,
    labelPlacement = 'top',
    passwordVisibility = false,
    readOnly = false,
    size = 'medium',
    textAlign = 'left',
    variant = 'outlined',
    ...rest
}: INumberInputProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: (
            <Default
                variant={variant}
                allowEmptyFormatting={allowEmptyFormatting}
                allowLeadingZeros={allowLeadingZeros}
                allowNegative={allowNegative}
                autoComplete={autoComplete}
                fixedDecimalScale={fixedDecimalScale}
                focused={focused}
                fullWidth={fullWidth}
                hidden={hidden}
                labelEllipsis={labelEllipsis}
                labelPlacement={labelPlacement}
                passwordVisibility={passwordVisibility}
                readOnly={readOnly}
                size={size}
                textAlign={textAlign}
                {...rest}
            />
        ),
        [DesignTypeEnum.SET]: (
            <SET
                variant={variant}
                allowEmptyFormatting={allowEmptyFormatting}
                allowLeadingZeros={allowLeadingZeros}
                allowNegative={allowNegative}
                autoComplete={autoComplete}
                fixedDecimalScale={fixedDecimalScale}
                focused={focused}
                fullWidth={fullWidth}
                hidden={hidden}
                labelEllipsis={labelEllipsis}
                labelPlacement={labelPlacement}
                passwordVisibility={passwordVisibility}
                readOnly={readOnly}
                size={size}
                textAlign={textAlign}
                {...rest}
            />
        ),
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default memo(NumberInput);
