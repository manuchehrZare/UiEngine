import type { FC } from 'react';
import { useState, useEffect } from 'react';
import { useController } from 'react-hook-form';
import { InputAdornment, TextField } from '@mui/material';
import type { INumberInputProps } from '../type';
import NumberInputBaseComponent from '../NumberInput';
import { omit, trim } from 'lodash';
import { manageClassNames } from '../../../../utils';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import Button from '../../Button/Button';

const NumberInput: FC<INumberInputProps> = ({
    allowEmptyFormatting,
    allowLeadingZeros,
    allowNegative,
    autoComplete,
    decimalScale,
    decimalSeparator,
    endAdornment,
    fixedDecimalScale,
    format,
    fullWidth,
    helperText,
    isAllowed,
    label,
    mask,
    maxLength,
    minLength,
    name,
    prefix,
    readOnly,
    removeFormatting,
    required,
    size,
    startAdornment,
    suffix,
    thousandSeparator,
    type,
    variant,
    control, // not defaultProps
    returnValue = 'floatValue', // not defaultProps
    placeholder,
    textAlign,
    sx,
    className,
    deps,
    passwordVisibility,
    ...rest
}: INumberInputProps) => {
    const [maskView, setMaskView] = useState<boolean | undefined>(undefined);
    const [isFocused, setIsFocused] = useState<boolean>(false);
    const [showPassword, setShowPassword] = useState<boolean>(false);

    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        if (allowEmptyFormatting) {
            if (placeholder) {
                if (!field.value && isFocused) {
                    setMaskView(false);
                } else if (!field.value && !isFocused) {
                    setMaskView(false);
                }
            } else if (!placeholder) {
                if (!field.value && !isFocused) {
                    setMaskView(false);
                }
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [allowEmptyFormatting, field.value, placeholder]);

    return (
        <TextField
            {...field}
            label={getLabel()}
            inputRef={ref}
            autoComplete={autoComplete}
            fullWidth={fullWidth}
            variant={variant}
            size={size}
            spellCheck={false}
            error={Boolean(error) && validationControl}
            helperText={(validationControl && error?.message) || helperText}
            InputLabelProps={{
                ...{
                    shrink:
                        placeholder && (!field.value || field.value) && isFocused
                            ? true
                            : field.value && !isFocused
                              ? true
                              : maskView,
                },
                className: manageClassNames({ 'Mui-focused': isFocused }),
            }}
            onFocus={
                /* istanbul ignore next */ () => {
                    setIsFocused(true);
                    if (placeholder && allowEmptyFormatting && field.value) {
                        setMaskView(true);
                    } else if (!placeholder && allowEmptyFormatting && (field.value || !field.value)) {
                        setMaskView(true);
                    } else if (!placeholder && (field.value || !field.value)) {
                        setMaskView(true);
                    } else {
                        setMaskView(undefined);
                    }
                }
            }
            onBlur={
                /* istanbul ignore next */ () => {
                    setIsFocused(false);
                    if (placeholder && allowEmptyFormatting && !field.value) {
                        setMaskView(false);
                    } else if (!placeholder && allowEmptyFormatting && !field.value) {
                        setMaskView(false);
                    } else {
                        setMaskView(undefined);
                    }
                    field.onBlur();
                }
            }
            InputProps={{
                ...(startAdornment
                    ? {
                          startAdornment: <InputAdornment position="start">{startAdornment}</InputAdornment>,
                      }
                    : {}),
                ...(endAdornment || passwordVisibility
                    ? {
                          endAdornment: (
                              <InputAdornment position="end">
                                  {type === 'password' && passwordVisibility && (
                                      <Button
                                          iconButton
                                          rounded
                                          variant="text"
                                          color="primary"
                                          icon={showPassword ? <VisibilityOff /> : <Visibility />}
                                          onClick={handleClickShowPassword}
                                          {...(!endAdornment && { sx: { mr: -0.75 } })}
                                      />
                                  )}
                                  {endAdornment}
                              </InputAdornment>
                          ),
                      }
                    : {}),
                className: manageClassNames(className, { 'Mui-focused': isFocused }),
                readOnly,
                inputComponent: NumberInputBaseComponent as any,
                inputProps: {
                    type: type === 'password' ? (showPassword ? undefined : 'password') : String(type),
                    allowEmptyFormatting: maskView,
                    allowLeadingZeros,
                    allowNegative,
                    decimalScale,
                    decimalSeparator,
                    fixedDecimalScale,
                    format,
                    isAllowed,
                    mask,
                    maxLength,
                    minLength,
                    prefix,
                    removeFormatting,
                    suffix,
                    thousandSeparator,
                    returnValue, // not defaultProps
                    control, // not defaultProps
                    placeholder,
                },
            }}
            sx={{
                input: {
                    textAlign: field.value || !placeholder || trim(placeholder).length === 0 ? textAlign : 'left',
                },
                ...sx,
            }}
            {...omit(rest, ['labelPlacement', 'labelWidth', 'labelEllipsis'])}
        />
    );
};

export default NumberInput;
