import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { useController } from 'react-hook-form';
import type { ITimePickerProps, TimeType } from '../type';
import { TimeTypeEnum } from '../type';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { TimePicker as MuiTimePicker } from '@mui/x-date-pickers/TimePicker';
import { fromUnixTime, getUnixTime, isAfter, isDate, isValid } from 'date-fns';
import { AccessTimeOutlined } from '@mui/icons-material';
import { isNumber, isUndefined, omit } from 'lodash';
import { pickerProps } from '../../_helper';
import { LocalesEnum, i18n } from '../../../../utils/locales';
import { enUS, renderTimeViewClock, trTR } from '@mui/x-date-pickers';
import trLocale from 'date-fns/locale/tr';
import enLocale from 'date-fns/locale/en-US';

const TimePicker: FC<ITimePickerProps> = ({
    analogClock,
    control,
    deps,
    format,
    helperText,
    label,
    name,
    onBlur,
    onClose,
    onFocus,
    onOpen,
    placeholder,
    required,
    size,
    slotProps,
    slots,
    unixTime,
    views,
    variant,
    ...rest
}: ITimePickerProps) => {
    const separator = pickerProps.default.timePicker.timeSeparator;
    const [viewsFormat, setViewsFormat] = useState<string>(pickerProps.default.timePicker.inputFormat);
    const [open, setOpen] = useState<boolean>(false);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const localeTextObj: any = {
        [LocalesEnum.TURKISH]: trTR.components.MuiLocalizationProvider.defaultProps.localeText,
        [LocalesEnum.ENGLISH]: enUS.components.MuiLocalizationProvider.defaultProps.localeText,
    };

    const getInputDate = (value: any) => {
        if (unixTime) {
            return value ? fromUnixTime(value) : value;
        }
        return value;
    };

    /* istanbul ignore next */
    const toggleOpen = (val?: boolean) => {
        if (val !== undefined) {
            val && !open && onOpen?.();
            !val && open && onClose?.();
            setOpen(val);
        } else {
            !open && onOpen?.();
            open && onClose?.();
            setOpen(!open);
        }
    };

    useEffect(() => {
        if (views?.length) {
            const formatArr: any[] = views?.map((item: TimeType) => {
                if (item === TimeTypeEnum.hours) {
                    return 'HH';
                }
                if (item === TimeTypeEnum.minutes) {
                    return 'mm';
                }
                if (item === TimeTypeEnum.seconds) {
                    return 'ss';
                }
                return null;
            });
            setViewsFormat(formatArr.join(`${separator}`));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [views]);

    const placeholderFormat = (data: string) => {
        switch (!isUndefined(data)) {
            case data === 'HH' ||
                data === 'mm' ||
                data === 'ss' ||
                data === `HH${separator}mm` ||
                data === `HH${separator}ss` ||
                data === `mm${separator}ss` ||
                data === `mm${separator}HH` ||
                data === `ss${separator}HH` ||
                data === `ss${separator}mm` ||
                data === `HH${separator}mm${separator}ss` ||
                data === `HH${separator}ss${separator}mm` ||
                data === `mm${separator}HH${separator}ss` ||
                data === `mm${separator}ss${separator}HH` ||
                data === `ss${separator}HH${separator}mm` ||
                data === `ss${separator}mm${separator}HH`:
                return data;
            default:
                return '';
        }
    };

    const setOpenTo = () => {
        if (views) {
            if (views[0] === TimeTypeEnum.minutes) return TimeTypeEnum.minutes;
            if (views[0] === TimeTypeEnum.seconds) return TimeTypeEnum.seconds;
            return TimeTypeEnum.hours;
        }
        return TimeTypeEnum.hours;
    };

    const minDateControl = (date: any) => {
        return isAfter(isNumber(date) ? fromUnixTime(date) : date, new Date(1900, 1, 1));
    };

    const errorVal = Boolean(error) || (error && field?.value?.length > 0);
    const helperTextVal = validationControl
        ? // eslint-disable-next-line no-constant-binary-expression
          ((error || !minDateControl(field.value)) && field?.value?.length > 0 && '') ||
          error?.message ||
          helperText ||
          ''
        : helperText || '';

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    return (
        <LocalizationProvider
            dateAdapter={AdapterDateFns}
            adapterLocale={i18n.language === LocalesEnum.TURKISH ? trLocale : enLocale}>
            <MuiTimePicker
                {...field}
                className="picker-input"
                inputRef={ref}
                value={getInputDate(field?.value)}
                label={getLabel()}
                autoFocus={false}
                open={open}
                ampm={false}
                onOpen={() => toggleOpen()}
                onClose={() => toggleOpen(false)}
                onChange={(date: any, context) => {
                    let d = null;
                    if (isDate(date) && isValid(date) && minDateControl(date)) {
                        d = unixTime ? Number(getUnixTime(new Date(date))) : date;
                    }
                    const inputEmpty = !d && !context.validationError && !open;
                    const pickerChange = open && !context.validationError && d;
                    if (context || pickerChange || inputEmpty) {
                        let resultD = d;
                        if (d === null) {
                            resultD = inputEmpty ? null : NaN;
                        }
                        field.onChange(resultD);
                    }
                }}
                views={views || [TimeTypeEnum.hours, TimeTypeEnum.minutes, TimeTypeEnum.seconds]}
                format={views ? viewsFormat : format || `HH${separator}mm${separator}ss`}
                localeText={{
                    ...localeTextObj[i18n.language],
                }}
                timeSteps={{ hours: 1, minutes: 1, seconds: 1 }}
                openTo={setOpenTo()}
                slots={{
                    openPickerIcon: () => <AccessTimeOutlined fontSize={size} />,
                    ...slots,
                }}
                slotProps={{
                    inputAdornment: {
                        position: 'end',
                    },
                    openPickerButton: {
                        onClick: () => toggleOpen(),
                    },
                    textField: {
                        variant: variant,
                        size: size,
                        error: errorVal && validationControl,
                        helperText: helperTextVal,
                        onFocus: onFocus,
                        onBlur: (e) => {
                            field.onBlur();
                            onBlur?.(e);
                        },
                        inputProps: {
                            placeholder: placeholder
                                ? placeholder
                                : placeholderFormat(
                                      views ? viewsFormat : format || pickerProps.SET.datePicker.inputFormat,
                                  ).replace(/[a-zA-Z]/gm, '_'),
                        },
                        fullWidth: true,
                        id: name,
                        autoComplete: 'off',
                        spellCheck: false,
                    },
                    actionBar: {
                        actions: [],
                    },
                    ...slotProps,
                }}
                {...(analogClock && {
                    viewRenderers: {
                        hours: renderTimeViewClock,
                        minutes: renderTimeViewClock,
                        seconds: renderTimeViewClock,
                    },
                })}
                {...omit(rest, [
                    'disabled',
                    'fullWidth',
                    'labelPlacement',
                    'labelWidth',
                    'labelEllipsis',
                    'onKeyPress',
                ])}
            />
        </LocalizationProvider>
    );
};

export default TimePicker;
