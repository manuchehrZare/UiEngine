import type { ButtonGroupProps, ButtonProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';

export interface IButtonGroupProps extends Pick<
    ButtonGroupProps,
    'children' | 'className' | 'disabled' | 'fullWidth' | 'ref' | 'orientation' | 'sx'
> {}
export interface IButtonProps
    extends
        ICommonProps,
        Pick<
            ButtonProps,
            | 'className'
            | 'color'
            | 'disabled'
            | 'fullWidth'
            | 'href'
            | 'id'
            | 'name'
            | 'ref'
            | 'size'
            | 'sx'
            | 'variant'
            | 'type'
            | 'onMouseDown'
        > {
    icon?: React.ReactNode;
    iconButton?: true;
    iconLeft?: React.ReactNode;
    iconRight?: React.ReactNode;
    leftRounded?: boolean;
    loading?: boolean;
    onClick?: (e?: any) => void;
    rightRounded?: boolean;
    rounded?: boolean;
    text?: string;
}
