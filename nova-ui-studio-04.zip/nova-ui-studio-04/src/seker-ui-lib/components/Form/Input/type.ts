import type { TextFieldProps } from '@mui/material';
import type { FileExtentionsEnum } from '../../../utils';
import type { ITooltipProps } from '../../Display/Tooltip/type';
import type { ICommonFieldProps } from '../commonTypes';

export enum InputTypeEnum {
    File = 'file',
    Hidden = 'hidden',
    Password = 'password',
}
export interface ICapslockDetectorProps {
    /**
     * Optional text to display as a tooltip title.
     */
    helperText?: string;
    /**
     * Callback function fired when the capslock state changes.
     *
     * @param capslockDetectorStatus The current status of the capslock key.
     * @param title The title or content to be passed to the callback.
     */
    onCapslockDetector?: (capslockDetectorStatus: boolean, title: React.ReactNode) => void;
    /**
     * Partial set of tooltip properties.
     */
    Tooltip?: Partial<ITooltipProps>;
}
export interface IInputProps
    extends
        Pick<
            TextFieldProps,
            | 'autoComplete'
            | 'className'
            | 'disabled'
            | 'id'
            | 'inputProps'
            | 'inputRef'
            | 'label'
            | 'maxRows'
            | 'minRows'
            | 'multiline'
            | 'onBlur'
            | 'onChange'
            | 'onFocus'
            | 'onKeyPress'
            | 'placeholder'
            | 'ref'
            | 'required'
            | 'rows'
            | 'size'
            | 'sx'
        >,
        ICommonFieldProps {
    accept?: `${FileExtentionsEnum}`[];
    /**
     * Determines whether the caps lock detector should be enabled,
     * or provides configuration options for the caps lock detector.
     *
     * If capslockDetector prop used, you need to use the inputRef prop of the input component.
     */
    capslockDetector?: boolean | ICapslockDetectorProps;
    mask?: any;
    maskChar?: '*' | '.' | ',' | '_' | '-';
    maskLazy?: boolean;
    maxLength?: number;
    minLength?: number;
    passwordVisibility?: boolean;
    type?: `${InputTypeEnum}`;
}
