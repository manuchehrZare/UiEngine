import type { SxProps, Theme } from '@mui/material';
import { DesignTypeEnum, constants, importantStyle } from '../../..';
import { GlobalFont } from '../../../theme/_css_global';
import type { IRichEditorProps } from './type';
import { calculateEditorContentHeight } from './helpers/action';

interface IParams extends Pick<
    IRichEditorProps,
    'design' | 'height' | 'readOnly' | 'disabled' | 'toolbar' | 'variant'
> {
    froalaRef?: any;
    labelRef?: any;
}

/* istanbul ignore next*/
const MuiRichEditorSxProps = ({
    design,
    height,
    froalaRef,
    labelRef,
    disabled,
    readOnly,
    toolbar,
    variant,
}: IParams): SxProps<Theme> => ({
    position: 'relative',
    ...(variant === 'outlined' && {
        border: (theme) => `1px solid ${theme.palette.grey?.[400]}`,
        borderRadius: 'var(--border-radius-5)',
        background: (theme) => theme.palette.common.white,
    }),
    ...(variant !== 'outlined' && {
        borderBottom: (theme) => `1px solid ${theme.palette.grey?.[700]}`,
    }),
    ...(variant === 'filled' && {
        borderTopLeftRadius: 'var(--border-radius-4)',
        borderTopRightRadius: 'var(--border-radius-4)',
        background: (theme) => theme.palette.grey[100],
    }),
    margin: 0,
    padding: '0px 8px',
    width: '100%',
    ':hover': {
        ...(!readOnly &&
            !disabled && {
                ...(variant === 'filled' && {
                    background: (theme) => theme.palette.grey[200],
                    '.fr-box': {
                        '.fr-toolbar': {
                            background: (theme) => theme.palette.grey[200],
                        },
                    },
                }),
                ...(variant === 'standard' && {
                    borderWidth: 2,
                }),
                borderColor: (theme) => theme.palette.grey[700],
            }),
    },

    [`&.${constants.classNames.labelEllipsis}`]: {
        minInlineSize: 'initial',
    },

    '& > legend': (theme) => ({
        ...(variant === 'outlined' && {
            margin: '0 10px',
            padding: '0 5px',
        }),
        ...(variant === 'filled' && {
            margin: '0 8px',
            padding: '4px 0px',
        }),

        ...(design === DesignTypeEnum.Default && {
            fontSize: 'calc(var(--field-label-font-size) * 0.875)',
            color: theme.palette.primary.light,
        }),
        ...(design === DesignTypeEnum.SET && {
            fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            color: theme.palette.common.black,
        }),

        [`.${constants.classNames.labelEllipsis} &`]: {
            maxWidth: `calc(100% - ${variant === 'outlined' ? '23px' : '0px'})`,
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
        },
    }),
    '.fr-code-view': {
        '.fr-wrapper': {
            height: froalaRef?.current?.editor?.$tb?.length
                ? `${calculateEditorContentHeight({
                      height,
                      froalaRef,
                      charCounterCount: false,
                      design,
                      labelRef,
                  })} !important`
                : 0,
        },
    },
    '.fr-box': (theme) => ({
        '.fr-element, .fr-counter, .fr-btn, .fr-code, label, & .fr-submit, input, .fr-action-buttons, .fr-image-upload-layer, .fr-file-upload-layer, & .fr-message, & .fr-special-character-category, & .fr-special-character, & .fr-submit, .fr-layer.fr-color-hex-layer label, & .fr-table-size .fr-table-size-info':
            {
                fontSize:
                    design === DesignTypeEnum.Default
                        ? 'var(--field-label-font-size) !important'
                        : `var(--field-label-font-size-${DesignTypeEnum.SET})!important`,
                fontFamily: GlobalFont,
                color: theme.palette.primary.main,
            },
        '.fr-basic': {
            ...(variant === 'standard' && {
                borderRadius: '0px',
            }),
        },
        '.fr-toolbar': {
            position: 'sticky',
            zIndex: theme.zIndex.modal,
            ...(variant === 'filled' && {
                background: theme.palette.grey[100],
            }),
            '.fr-newline': {
                height: readOnly || disabled ? 0 : '1px',
                margin: '0px',
                ...(variant === 'filled' && {
                    background: theme.palette.grey[200],
                }),
            },
            display: toolbar === false ? 'none' : 'block',
        },
        '.fr-toolbar, .fr-wrapper, .fr-second-toolbar': {
            border: 'none',
        },
        '.fr-btn-grp': {
            margin: design === DesignTypeEnum.Default ? '5px 0 5px 0' : 0,
            borderRadius: 'var(--border-radius-5)',
            'button:hover': {
                background: theme.palette.grey[variant === 'filled' ? 200 : 100],
            },
            '.fr-active svg path': {
                fill: `${theme.palette.secondary.main} !important`,
            },

            '& .fr-btn-active-popup:hover, & .fr-btn-active-popup, & .fr-dropdown.fr-active, & .fr-dropdown.fr-active:hover':
                {
                    background: theme.palette.grey[variant === 'filled' ? 200 : 100],
                },
        },
        //expanded more toolbar
        '.fr-more-toolbar': {
            background: theme.palette.grey[variant === 'filled' ? 200 : 100],
        },
        '.fr-expanded': {
            height: design === DesignTypeEnum.SET ? '35px !important' : '48px',
        },
        //dropdown
        '& .fr-btn.fr-dropdown:after': {
            top: design === DesignTypeEnum.SET ? '12px' : '18px',
            right: design === DesignTypeEnum.SET ? '5px' : '6px',
            borderTop: `4px solid ${theme.palette.primary.main}`,
        },
        '& .fr-btn.fr-dropdown.fr-active:after': {
            borderTop: 'none !important',
            borderBottom: `4px solid ${theme.palette.primary.main}`,
        },
        '.fr-dropdown-menu, .fr-dropdown-list': {
            '.fr-dropdown-wrapper': {
                ul: {
                    padding: '2px 0',
                },
                '& li': {
                    fontSize:
                        design === DesignTypeEnum.Default
                            ? 'var(--field-label-font-size) !important'
                            : `var(--field-label-font-size-${DesignTypeEnum.SET}) !important`,
                    a: {
                        padding: design === DesignTypeEnum.Default ? '0px 20px' : '0px 7px',
                    },
                },
                '& a:hover, & a.fr-active, & .fr-active:hover': {
                    background: `${theme.palette.grey[50]} !important`,
                },
            },
        },
        //line breaker button
        '.fr-line-breaker , .fr-insert-helper': {
            'a.fr-floating-btn': {
                margin: design === DesignTypeEnum.Default ? '0px 7px' : '0px 4px',
                height: design === DesignTypeEnum.SET ? '25px !important' : '40px !important',
                width: design === DesignTypeEnum.SET ? '25px !important' : '40px !important',
                svg: {
                    margin: design === DesignTypeEnum.SET ? 0 : '7px',
                    path: {
                        fill: theme.palette.primary.main,
                    },
                },
            },
        },
        //popup
        '.fr-popup': {
            '.fr-table-size': {
                margin: design === DesignTypeEnum.SET ? '13px' : '20px',
            },
            // general popup design
            input: {
                height: design === DesignTypeEnum.SET ? '30px' : '46px',
                border: `1px solid ${theme.palette.primary.main}`,
                ':focus': {
                    border: `1px solid ${theme.palette.primary.main}`,
                },
                ':checked+span': {
                    background: theme.palette.secondary.main,
                },
            },
            label: {
                top: design === DesignTypeEnum.SET ? '14px' : '28px',
            },
            '.fr-action-buttons': { padding: design === DesignTypeEnum.SET ? '5px 0' : '15px 11px' },
            '.fr-link-insert-layer .fr-submit': {
                background: theme.palette.secondary.main,
                color: theme.palette.common.white,
                height: design === DesignTypeEnum.SET ? '30px !important' : '40px !important',
                width: design === DesignTypeEnum.SET ? '50px !important' : '60px !important',
                padding: design === DesignTypeEnum.SET ? '5px' : '10px',
                borderRadius: design === DesignTypeEnum.SET ? 'var(--border-radius-2)' : 'var(--border-radius-4)',
                boxShadow: '1px 3px 4px 0 var(--shadow-1)',
                ':hover': {
                    background: theme.palette.secondary.dark,
                    color: theme.palette.common.white,
                },
            },
            '& .fr-input-line': {
                padding: design === DesignTypeEnum.SET ? '6px 0' : '15px 0',
                'input.fr-not-empty+label': {
                    top: design === DesignTypeEnum.SET ? 0 : 8,
                },
            },
            '.fr-buttons, button:hover': { background: theme.palette.grey?.[100] },
            //color selected control
            '.fr-tabs .fr-active': {
                paddingBottom: '31px',
            },
            '& .fr-active': {
                paddingBottom: '5px',
            },
            //image
            '.fr-image-upload-layer, .fr-file-upload-layer': {
                padding: design === DesignTypeEnum.Default ? '10px' : '2px',
                margin: design === DesignTypeEnum.Default ? '15px' : '9px',
                border: `1px dotted ${theme.palette.primary.main}`,
                ':hover': {
                    background: theme.palette.grey?.[100],
                    color: theme.palette.primary.main,
                },
            },
            '#imageUpload-1': {
                'svg path': {
                    fill: `${theme.palette.primary.main} !important`,
                },
            },
            '.fr-image-progress-bar-layer': {
                padding: '0px',
                margin: '10px',
                '.fr-loader': {
                    marginTop: '10px',
                    background: theme.palette.secondary[100],
                    span: {
                        background: theme.palette.green?.main,
                    },
                },
            },
            //special character
            '.fr-icon-container': {
                padding: design === DesignTypeEnum.SET ? '12px' : '20px',
            },
            '& .fr-special-character-category:hover, & .fr-special-character:hover': {
                background: theme.palette.grey?.[100],
                color: theme.palette.primary.main,
            },
            '& .fr-special-character-category': {
                paddingBottom: '22px',
                background: theme.palette.grey?.[100],
            },
            '& .fr-special-character': {
                width: '24px',
                height: '24px',
                padding: 0,
                paddingTop: '13px',
            },
        },
        //insert link
        '.fr-link-insert-layer': {
            width: design === DesignTypeEnum.SET ? '200px' : '240px',
            margin: design === DesignTypeEnum.SET ? '10px 9px 2px 9px' : '20px',
            '.fr-checkbox-line': {
                label: {
                    fontSize:
                        design === DesignTypeEnum.Default
                            ? 'var(--field-label-font-size)'
                            : `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                },
                marginTop: design === DesignTypeEnum.Default ? '5px' : 0,
                '.fr-checkbox': {
                    width: design === DesignTypeEnum.SET ? '14px' : '18px',
                    height: design === DesignTypeEnum.SET ? '14px' : '18px',
                    padding: '6px 3px',
                    span: {
                        width: design === DesignTypeEnum.SET ? '14px' : '18px',
                        height: design === DesignTypeEnum.SET ? '14px' : '18px',
                        border: `1px solid ${theme.palette.primary.main}`,
                    },
                    svg: {
                        margin: design === DesignTypeEnum.SET ? '1px' : '3px',
                        background: theme.palette.secondary.main,
                        path: {
                            fill: theme.palette.common.white,
                        },
                    },
                },
            },
        },
        //table
        '.fr-table-size': {
            margin: design === DesignTypeEnum.SET ? '7px' : '13px',
            '.fr-select-table-size>span.hover>span': {
                background: theme.palette.secondary[100],
                border: `1px solid ${theme.palette.secondary.main}`,
            },
        },
        table: {
            '.fr-selected-cell': {
                border: `1px double ${theme.palette.secondary.main}`,
            },
        },
        'p, td': {
            overflowWrap: 'anywhere',
        },
        'td, th': {
            padding: '2px 3px',
        },
        '.fr-table-resizer div, .fr-line-breaker': {
            border: `1px solid ${theme.palette.secondary[400]}`,
        },
        '#isPasted': {
            width: '100% !important',
        },
        //image
        '.fr-image-resizer': {
            border: `1px solid ${theme.palette.secondary.main}`,
            '.fr-handler': {
                background: theme.palette.secondary.main,
            },
        },
        //content
        '.fr-sticky-dummy': {
            display: 'none',
        },
        '.fr-wrapper, .fr-code': {
            display: 'none',
            overflow: 'auto',
            overflowWrap: 'anywhere',
        },
        '.fr-wrapper': {
            margin: '5px 0',
            background: 'transparent',
        },
        '.fr-element': {
            padding: '5px',
            height: '100%',
            div: { width: '100%', float: 'left', display: 'block' },
            ...(readOnly && {
                contenteditable: 'false',
            }),
        },
        '.fr-btn': {
            height: design === DesignTypeEnum.SET ? '25px !important' : '40px !important',
            svg: {
                margin: design === DesignTypeEnum.Default ? '0px 7px' : '0px 4px',
                height: design === DesignTypeEnum.SET ? '20px !important' : '40px !important',
                path: {
                    fill: theme.palette.primary.main,
                },
            },
            span: {
                width: design === DesignTypeEnum.Default ? '100px !important' : '77px !important',
                fontSize:
                    design === DesignTypeEnum.Default
                        ? 'var(--field-label-font-size)'
                        : `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            },
        },
        '.fr-placeholder': {
            paddingLeft: '5px',
        },
        //second toolbar
        '.fr-second-toolbar': {
            borderTop: 'none',
            display: 'none',
            //logo
            '#fr-logo': {
                display: 'none',
            },
        },
        // basic css
        'ol,ul': {
            display: 'block',
            marginTop: '0px !important',
            marginBottom: '1em',
            marginLeft: '0',
            marginRight: '0',
            paddingLeft: '40px',
        },
        ol: {
            listStyleType: 'decimal',
        },
        ul: {
            listStyleType: 'disc',
        },
        li: {
            marginBottom: '0.5rem',
        },
        'h1,h2,h3,h4,h5,h6': {
            marginTop: '10px',
            marginBottom: '10px',
            fontWeight: 'bold',
            display: 'block',
        },
        h1: {
            fontSize: '2em',
        },
        h2: {
            fontSize: '1.5em',
        },
        h3: {
            fontSize: '1.17em',
        },
        sup: {
            verticalAlign: 'super',
        },
        sub: {
            verticalAlign: 'sub',
        },
        blockquote: {
            border: 'none !important',
            borderLeft: `1px solid ${theme.palette.secondary.main} !important`,
            color: `${theme.palette.primary.main}`,
        },
        'td,th,blockquote,hr': {
            border: `1px solid ${theme.palette.grey[300]}`,
        },
    }),
    '.fr-box .fr-counter': {
        padding: design === DesignTypeEnum.Default ? '8px !important' : '5px !important',
        marginRight: '17px !important',
    },

    '&.focus': {
        borderColor: (theme) => theme.palette.secondary.main,

        '> legend': {
            color: (theme) => importantStyle(theme.palette.secondary.main),
        },
    },

    '&.error': {
        '> legend': {
            color: (theme) => importantStyle(theme.palette.error.main),
        },
        borderColor: (theme) => theme.palette.error.main,
    },
});

export default MuiRichEditorSxProps;
