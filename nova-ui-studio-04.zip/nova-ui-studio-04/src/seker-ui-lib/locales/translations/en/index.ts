import buttons from './_buttons';
import contents from './_contents';
import labels from './_labels';
import languages from './_languages';
import pageTitles from './_pageTitles';
import validations from './_validations';

export default {
    buttons,
    contents,
    labels,
    languages,
    pageTitles,
    validations,
};
