import { merge } from 'lodash';
import { constants } from '../../set-lib';
import { nova } from './nova';

export const api = merge(constants.api.endpoints, { nova });
