using System.IO;
using System.Reflection.Metadata.Ecma335;
using System.Text.Encodings.Web;
using System.Text.Json;
using UiGenerator.Core.Schema;
using UiGenerator.Core.Services;

namespace UiGenerator.EbmlCrawler
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private List<EbmlProcessingResult> processingResults;
        private List<EbmlInfo> EbmlList;
        private List<ScreenDefinition> ScreenDefinitions;

        private void pathOpenDialogBtn_Click(object sender, EventArgs e)
        {

            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    //string[] files = Directory.GetFiles(fbd.SelectedPath);
                    repositoryPathTxt.Text = fbd.SelectedPath;
                }
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {

            var paths = LoadAllPaths();
            resultDataGridView.DataSource = paths.Select(d => new { FilePath = d }).ToList();
        }
        private void resultDataGridView_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var selectedPath = resultDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            ParseEbmlXml(new List<string> { selectedPath });
        }
        private void btnProcessAllfiles_Click(object sender, EventArgs e)
        {
            var paths = LoadAllPaths();
            EbmlList = ParseEbmlXml(paths);
        }
        private void beanClassLoaderBtn_Click(object sender, EventArgs e)
        {
            //var parser = new EbmlParser();
            //var ebml = parser.ParseEbml("C:\\Users\\Manouchehr.zare\\Desktop\\Documents\\temp\\ADM001_UTIL_DATE_HOLIDAY_MANAGEMENT.ebml");
            if (EbmlList?.Count > 0)
                RetriveAllBeanClassess(EbmlList);
        }


        public void RetriveAllBeanClassess(List<EbmlInfo> allEbml)
        {
            var beanClassList = new List<string>();
            allEbml.ForEach(ebml => ProcessBean(ebml.EbmlContent.Interface.Structure.Bean, beanClassList));
            beanClassessGV.DataSource = beanClassList.Distinct().Select(b => new { ClassName = b }).ToList();
        }
        private void ProcessBean(Bean bean, List<string> beanList)
        {
            beanList.Add(bean.Class);
            if (bean.SubBean?.Count > 0)
            {
                bean.SubBean.ForEach(b => ProcessBean(b, beanList));
            }
        }
        private List<EbmlInfo> ParseEbmlXml(List<string> ebmlPaths)
        {
            processingResults = new List<EbmlProcessingResult>();
            var ebmls = new List<EbmlInfo>();

            LoadScreenDefinitions();


            ebmlPaths.ForEach(ebmlPath =>
            {
                var parser = new EbmlParser();

                var allFiles = Directory.GetFiles(ebmlPath, "*.ebml", searchOption: SearchOption.AllDirectories).ToList();
                allFiles.ForEach(file =>
                {
                    try
                    {

                        var ebmlObject = parser.ParseEbml(file);
                        if (ebmlObject == null) return;
                        var fileInfo = new FileInfo(file);
                        var name = ebmlObject.Pid.Replace(".ebml", "");
                        var screenCode = ebmlObject.Pid.Substring(0, ebmlObject.Pid.IndexOf('_'));
                        var menuName = ScreenDefinitions.FirstOrDefault(m => m.ScreenCode == screenCode)?.MenuTitle ?? name;
                        var ebmlInfo = new EbmlInfo()
                        {
                            ScreenCode = screenCode,
                            MenuName = menuName,
                            Name = name,
                            EbmlName = fileInfo.Name,
                            EbmlContent = ebmlObject,
                            Type = fileInfo.Directory.Name.ToLower(),
                            ModuleName = $"{fileInfo.Directory.Parent.Parent.Parent.Name} - {fileInfo.Directory.Parent.Parent.Name}",

                        };
                        ebmls.Add(ebmlInfo);

                        processingResults.Add(new EbmlProcessingResult
                        {
                            FilePath = file,
                            IsSuccess = true
                        });

                    }
                    catch (Exception ex)
                    {
                        processingResults.Add(new EbmlProcessingResult
                        {
                            Exception = ex.Message,
                            FilePath = file,
                            IsSuccess = false
                        });
                    }
                });

            });

            ebmProcessingResultGV.DataSource = processingResults;
            return ebmls;
        }
        private List<string> LoadAllPaths()
        {
            if (string.IsNullOrEmpty(repositoryPathTxt.Text)) return new List<string>();
            var directories = Directory.GetDirectories(repositoryPathTxt.Text, "", searchOption: SearchOption.AllDirectories);
            var paths = directories.Where(d => d.ToLower().EndsWith("ebml")).ToList();
            return paths;
        }
        private void LoadScreenDefinitions()
        {
            var filePath = Environment.CurrentDirectory + "\\ScreenDefinitions.json";
            string jsonText = File.ReadAllText(filePath);
            ScreenDefinitions = JsonSerializer.Deserialize<List<ScreenDefinition>>(jsonText);



        }
        private void exportEbmlJsonBtn_Click(object sender, EventArgs e)
        {

            var ebmlJsons = JsonSerializer.Serialize(EbmlList, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });


            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Json Files | *.json";
            saveFileDialog.DefaultExt = "json";
            var dialogResult = saveFileDialog.ShowDialog();
            if (dialogResult == DialogResult.OK)
            {
                using (var fileStream = saveFileDialog.OpenFile())
                using (var sw = new System.IO.StreamWriter(fileStream, System.Text.Encoding.UTF8))
                {
                    sw.Write(ebmlJsons);
                    sw.Flush();
                    sw.Close();
                }
            }

        }

        private void distPathOpenDialogBtn_Click(object sender, EventArgs e)
        {

        }
    }

    public class EbmlProcessingResult
    {
        public string FilePath { get; set; }
        public bool IsSuccess { get; set; }
        public string Exception { get; set; }
    }

    public class EbmlInfo
    {
        public string Name { get; set; }
        public string EbmlName { get; set; }
        public string ModuleName { get; set; }
        public string Type { get; set; }
        public string ScreenCode { get; set; }
        public string MenuName { get; set; }
        public Ebml EbmlContent { get; set; }
    }
}
