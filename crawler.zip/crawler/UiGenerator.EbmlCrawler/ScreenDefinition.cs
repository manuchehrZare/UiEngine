﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace UiGenerator.EbmlCrawler
{
    public class ScreenDefinition
    {
        [JsonPropertyName("SCREEN_CODE")]
        public string ScreenCode { get; set; }

        [JsonPropertyName("MENU_NAME")]
        public string MenuTitle { get; set; }
    }
}
