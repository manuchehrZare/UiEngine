﻿namespace UiGenerator.EbmlCrawler
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            label1 = new Label();
            tableLayoutPanel4 = new TableLayoutPanel();
            pathOpenDialogBtn = new Button();
            repositoryPathTxt = new TextBox();
            searchBtn = new Button();
            btnProcessAllfiles = new Button();
            beanClassLoaderBtn = new Button();
            tableLayoutPanel5 = new TableLayoutPanel();
            distPathOpenDialogBtn = new Button();
            distPathTxt = new TextBox();
            label2 = new Label();
            ebmlFilesTab = new TabControl();
            tabPage1 = new TabPage();
            resultDataGridView = new DataGridView();
            tabPage2 = new TabPage();
            ebmProcessingResultGV = new DataGridView();
            tabPage3 = new TabPage();
            beanClassessGV = new DataGridView();
            tableLayoutPanel6 = new TableLayoutPanel();
            exportEbmlJsonBtn = new Button();
            button2 = new Button();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            ebmlFilesTab.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)resultDataGridView).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ebmProcessingResultGV).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)beanClassessGV).BeginInit();
            tableLayoutPanel6.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 0);
            tableLayoutPanel1.Controls.Add(ebmlFilesTab, 0, 1);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel6, 0, 2);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 17.9775276F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 82.02247F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 48F));
            tableLayoutPanel1.Size = new Size(1096, 643);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 4);
            tableLayoutPanel2.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 69.44444F));
            tableLayoutPanel2.Size = new Size(1090, 98);
            tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 6;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.9259262F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 74.07407F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 15F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 175F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 184F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155F));
            tableLayoutPanel3.Controls.Add(label1, 0, 0);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel4, 1, 0);
            tableLayoutPanel3.Controls.Add(searchBtn, 3, 0);
            tableLayoutPanel3.Controls.Add(btnProcessAllfiles, 4, 0);
            tableLayoutPanel3.Controls.Add(beanClassLoaderBtn, 5, 0);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel5, 1, 1);
            tableLayoutPanel3.Controls.Add(label2, 0, 1);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 4);
            tableLayoutPanel3.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 51.47059F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 48.52941F));
            tableLayoutPanel3.Size = new Size(1084, 90);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Fill;
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(137, 46);
            label1.TabIndex = 0;
            label1.Text = "EBML Source Path";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 86.11898F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 13.88102F));
            tableLayoutPanel4.Controls.Add(pathOpenDialogBtn, 1, 0);
            tableLayoutPanel4.Controls.Add(repositoryPathTxt, 0, 0);
            tableLayoutPanel4.Dock = DockStyle.Fill;
            tableLayoutPanel4.Location = new Point(146, 4);
            tableLayoutPanel4.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(405, 38);
            tableLayoutPanel4.TabIndex = 1;
            // 
            // pathOpenDialogBtn
            // 
            pathOpenDialogBtn.Location = new Point(351, 4);
            pathOpenDialogBtn.Margin = new Padding(3, 4, 3, 4);
            pathOpenDialogBtn.Name = "pathOpenDialogBtn";
            pathOpenDialogBtn.Size = new Size(49, 30);
            pathOpenDialogBtn.TabIndex = 0;
            pathOpenDialogBtn.Text = "...";
            pathOpenDialogBtn.TextAlign = ContentAlignment.TopCenter;
            pathOpenDialogBtn.UseVisualStyleBackColor = true;
            pathOpenDialogBtn.Click += pathOpenDialogBtn_Click;
            // 
            // repositoryPathTxt
            // 
            repositoryPathTxt.BackColor = SystemColors.ButtonHighlight;
            repositoryPathTxt.Dock = DockStyle.Fill;
            repositoryPathTxt.Location = new Point(3, 4);
            repositoryPathTxt.Margin = new Padding(3, 4, 3, 4);
            repositoryPathTxt.Name = "repositoryPathTxt";
            repositoryPathTxt.ReadOnly = true;
            repositoryPathTxt.Size = new Size(342, 27);
            repositoryPathTxt.TabIndex = 1;
            repositoryPathTxt.Text = "C:\\CodeRepositories";
            // 
            // searchBtn
            // 
            searchBtn.Location = new Point(572, 4);
            searchBtn.Margin = new Padding(3, 4, 3, 4);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(168, 35);
            searchBtn.TabIndex = 2;
            searchBtn.Text = "Search";
            searchBtn.UseVisualStyleBackColor = true;
            searchBtn.Click += searchBtn_Click;
            // 
            // btnProcessAllfiles
            // 
            btnProcessAllfiles.Location = new Point(747, 4);
            btnProcessAllfiles.Margin = new Padding(3, 4, 3, 4);
            btnProcessAllfiles.Name = "btnProcessAllfiles";
            btnProcessAllfiles.Size = new Size(174, 35);
            btnProcessAllfiles.TabIndex = 3;
            btnProcessAllfiles.Text = "Process All Files";
            btnProcessAllfiles.UseVisualStyleBackColor = true;
            btnProcessAllfiles.Click += btnProcessAllfiles_Click;
            // 
            // beanClassLoaderBtn
            // 
            beanClassLoaderBtn.Location = new Point(931, 4);
            beanClassLoaderBtn.Margin = new Padding(3, 4, 3, 4);
            beanClassLoaderBtn.Name = "beanClassLoaderBtn";
            beanClassLoaderBtn.Size = new Size(146, 35);
            beanClassLoaderBtn.TabIndex = 4;
            beanClassLoaderBtn.Text = "Load Bean Class";
            beanClassLoaderBtn.UseVisualStyleBackColor = true;
            beanClassLoaderBtn.Click += beanClassLoaderBtn_Click;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 86.11898F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 13.88102F));
            tableLayoutPanel5.Controls.Add(distPathOpenDialogBtn, 1, 0);
            tableLayoutPanel5.Controls.Add(distPathTxt, 0, 0);
            tableLayoutPanel5.Location = new Point(146, 50);
            tableLayoutPanel5.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 1;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Size = new Size(403, 36);
            tableLayoutPanel5.TabIndex = 6;
            // 
            // distPathOpenDialogBtn
            // 
            distPathOpenDialogBtn.Location = new Point(350, 4);
            distPathOpenDialogBtn.Margin = new Padding(3, 4, 3, 4);
            distPathOpenDialogBtn.Name = "distPathOpenDialogBtn";
            distPathOpenDialogBtn.Size = new Size(49, 28);
            distPathOpenDialogBtn.TabIndex = 0;
            distPathOpenDialogBtn.Text = "...";
            distPathOpenDialogBtn.TextAlign = ContentAlignment.TopCenter;
            distPathOpenDialogBtn.UseVisualStyleBackColor = true;
            distPathOpenDialogBtn.Click += distPathOpenDialogBtn_Click;
            // 
            // distPathTxt
            // 
            distPathTxt.BackColor = SystemColors.ButtonHighlight;
            distPathTxt.Dock = DockStyle.Fill;
            distPathTxt.Location = new Point(3, 4);
            distPathTxt.Margin = new Padding(3, 4, 3, 4);
            distPathTxt.Name = "distPathTxt";
            distPathTxt.ReadOnly = true;
            distPathTxt.Size = new Size(341, 27);
            distPathTxt.TabIndex = 1;
            distPathTxt.Text = "C:\\UIGenerator\\EBML";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Fill;
            label2.Location = new Point(3, 46);
            label2.Name = "label2";
            label2.Size = new Size(137, 44);
            label2.TabIndex = 7;
            label2.Text = "EBML Dist Path";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // ebmlFilesTab
            // 
            ebmlFilesTab.Controls.Add(tabPage1);
            ebmlFilesTab.Controls.Add(tabPage2);
            ebmlFilesTab.Controls.Add(tabPage3);
            ebmlFilesTab.Dock = DockStyle.Fill;
            ebmlFilesTab.Location = new Point(3, 110);
            ebmlFilesTab.Margin = new Padding(3, 4, 3, 4);
            ebmlFilesTab.Name = "ebmlFilesTab";
            ebmlFilesTab.SelectedIndex = 0;
            ebmlFilesTab.Size = new Size(1090, 480);
            ebmlFilesTab.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(resultDataGridView);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Margin = new Padding(3, 4, 3, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3, 4, 3, 4);
            tabPage1.Size = new Size(1082, 447);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "EBML files";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // resultDataGridView
            // 
            resultDataGridView.AllowUserToAddRows = false;
            resultDataGridView.AllowUserToDeleteRows = false;
            resultDataGridView.AllowUserToOrderColumns = true;
            resultDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            resultDataGridView.BackgroundColor = SystemColors.ScrollBar;
            resultDataGridView.CausesValidation = false;
            resultDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resultDataGridView.Dock = DockStyle.Fill;
            resultDataGridView.Location = new Point(3, 4);
            resultDataGridView.Margin = new Padding(3, 4, 3, 4);
            resultDataGridView.MultiSelect = false;
            resultDataGridView.Name = "resultDataGridView";
            resultDataGridView.RowHeadersWidth = 51;
            resultDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            resultDataGridView.Size = new Size(1076, 439);
            resultDataGridView.TabIndex = 2;
            resultDataGridView.RowHeaderMouseDoubleClick += resultDataGridView_RowHeaderMouseDoubleClick;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(ebmProcessingResultGV);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Margin = new Padding(3, 4, 3, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3, 4, 3, 4);
            tabPage2.Size = new Size(1081, 446);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "EBML Processessing Result";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // ebmProcessingResultGV
            // 
            ebmProcessingResultGV.AllowUserToAddRows = false;
            ebmProcessingResultGV.AllowUserToDeleteRows = false;
            ebmProcessingResultGV.AllowUserToOrderColumns = true;
            ebmProcessingResultGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            ebmProcessingResultGV.BackgroundColor = SystemColors.ScrollBar;
            ebmProcessingResultGV.CausesValidation = false;
            ebmProcessingResultGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ebmProcessingResultGV.Dock = DockStyle.Fill;
            ebmProcessingResultGV.Location = new Point(3, 4);
            ebmProcessingResultGV.Margin = new Padding(3, 4, 3, 4);
            ebmProcessingResultGV.MultiSelect = false;
            ebmProcessingResultGV.Name = "ebmProcessingResultGV";
            ebmProcessingResultGV.RowHeadersWidth = 51;
            ebmProcessingResultGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ebmProcessingResultGV.Size = new Size(1075, 438);
            ebmProcessingResultGV.TabIndex = 3;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(beanClassessGV);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Margin = new Padding(3, 4, 3, 4);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3, 4, 3, 4);
            tabPage3.Size = new Size(1081, 446);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Bean Classes";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // beanClassessGV
            // 
            beanClassessGV.AllowUserToAddRows = false;
            beanClassessGV.AllowUserToDeleteRows = false;
            beanClassessGV.AllowUserToOrderColumns = true;
            beanClassessGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            beanClassessGV.BackgroundColor = SystemColors.ScrollBar;
            beanClassessGV.CausesValidation = false;
            beanClassessGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            beanClassessGV.Dock = DockStyle.Fill;
            beanClassessGV.Location = new Point(3, 4);
            beanClassessGV.Margin = new Padding(3, 4, 3, 4);
            beanClassessGV.Name = "beanClassessGV";
            beanClassessGV.RowHeadersWidth = 51;
            beanClassessGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            beanClassessGV.Size = new Size(1075, 438);
            beanClassessGV.TabIndex = 4;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 4;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57.72231F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42.27769F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 178F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 217F));
            tableLayoutPanel6.Controls.Add(exportEbmlJsonBtn, 3, 0);
            tableLayoutPanel6.Controls.Add(button2, 2, 0);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(3, 598);
            tableLayoutPanel6.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Size = new Size(1090, 41);
            tableLayoutPanel6.TabIndex = 6;
            // 
            // exportEbmlJsonBtn
            // 
            exportEbmlJsonBtn.Dock = DockStyle.Fill;
            exportEbmlJsonBtn.Location = new Point(875, 4);
            exportEbmlJsonBtn.Margin = new Padding(3, 4, 3, 4);
            exportEbmlJsonBtn.Name = "exportEbmlJsonBtn";
            exportEbmlJsonBtn.Size = new Size(212, 33);
            exportEbmlJsonBtn.TabIndex = 6;
            exportEbmlJsonBtn.Text = "Export Ebml Content Json";
            exportEbmlJsonBtn.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Dock = DockStyle.Fill;
            button2.Location = new Point(697, 4);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(172, 33);
            button2.TabIndex = 6;
            button2.Text = "Export Ebml List Json";
            button2.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1096, 643);
            Controls.Add(tableLayoutPanel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Main";
            Text = "Ebml Crawler";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            ebmlFilesTab.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)resultDataGridView).EndInit();
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ebmProcessingResultGV).EndInit();
            tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)beanClassessGV).EndInit();
            tableLayoutPanel6.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel4;
        private Button pathOpenDialogBtn;
        private TextBox repositoryPathTxt;
        private Button searchBtn;
        private TabControl ebmlFilesTab;
        private TabPage tabPage1;
        private DataGridView resultDataGridView;
        private TabPage tabPage2;
        private DataGridView ebmProcessingResultGV;
        private Button btnProcessAllfiles;
        private TabPage tabPage3;
        private DataGridView beanClassessGV;
        private Button beanClassLoaderBtn;
        private TableLayoutPanel tableLayoutPanel5;
        private Button distPathOpenDialogBtn;
        private TextBox distPathTxt;
        private Label label2;
        private TableLayoutPanel tableLayoutPanel6;
        private Button exportEbmlJsonBtn;
        private Button button2;
    }
}
