﻿using System.Text;
using System.Xml.Serialization;
using UiGenerator.Core.Schema;

namespace UiGenerator.Core.Services
{
    public class EbmlParser
    {
        public Ebml ParseEbml(string filePath)
        {
            Ebml ebml = null;

            // This text is added only once to the file.
            if (File.Exists(filePath))
            {

                // Open the file to read from.
                //string readText = File.ReadAllText(filePath,encoding: Encoding.GetEncoding("ISO-8859-9"));
                System.Text.EncodingProvider provider = System.Text.CodePagesEncodingProvider.Instance;
                Encoding.RegisterProvider(provider);
                StreamReader sr = new StreamReader(filePath, Encoding.GetEncoding("iso-8859-9"), false);
                string readText = sr.ReadToEnd();
                sr.Close();
                if (!string.IsNullOrEmpty(readText))
                {
                    ebml = ParseEblXml(readText);
                }

            }

            return ebml;
        }

        private Ebml ParseEblXml(string xml)
        {

            Ebml ebml = null;
            XmlSerializer serializer = new XmlSerializer(typeof(Ebml));
            using (StringReader reader = new StringReader(xml))
            {
                ebml = (Ebml)serializer.Deserialize(reader);
            }
            return ebml;
        }

    }
}
