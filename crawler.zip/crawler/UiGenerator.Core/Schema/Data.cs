using System.Xml.Serialization; 
using System.Collections.Generic; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="data")]
public class Data { 

	[XmlElement(ElementName="var")] 
	public List<Var> Var { get; set; } 
}

}