using System.Xml.Serialization; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="interface")]
public class Interface { 

	[XmlElement(ElementName="structure")] 
	public Structure Structure { get; set; } 

	[XmlElement(ElementName="events")] 
	public Events Events { get; set; } 
}

}