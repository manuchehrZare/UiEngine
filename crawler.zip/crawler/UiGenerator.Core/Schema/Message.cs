using System.Xml.Serialization;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "message")]
    public class Message
    {

        [XmlElement(ElementName = "var")]
        public Var Var { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "messageType")]
        public string MessageType { get; set; }

        [XmlAttribute(AttributeName = "title")]
        public string Title { get; set; }

        [XmlAttribute(AttributeName = "type")]
        public string Type { get; set; }

        [XmlText]
        public string Text { get; set; }
    }

}