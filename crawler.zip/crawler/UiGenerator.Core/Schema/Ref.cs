using System.Xml.Serialization;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "ref")]
    public class Ref
    {

        [XmlAttribute(AttributeName = "rule")]
        public string Rule { get; set; }

        [XmlText]
        public string Text { get; set; }
    }

}