using System.Xml.Serialization;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "p")]
    public class P
    {

        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }

        [XmlText]
        public string Text { get; set; }

        [XmlElement(ElementName = "columns")]
        public Columns Columns { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "m")]
        public string M { get; set; }

        [XmlElement(ElementName = "rule")]
        public Rule Rule { get; set; }

        [XmlElement(ElementName = "var")]
        public Var Var { get; set; }

        [XmlAttribute(AttributeName = "n")]
        public string N { get; set; }

        [XmlElement(ElementName = "comp")]
        public Comp Comp { get; set; }
    }

}