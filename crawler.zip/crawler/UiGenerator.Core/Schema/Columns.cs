using System.Xml.Serialization; 
using System.Collections.Generic; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="columns")]
public class Columns { 

	[XmlElement(ElementName="column")] 
	public List<Column> Column { get; set; } 
}

}