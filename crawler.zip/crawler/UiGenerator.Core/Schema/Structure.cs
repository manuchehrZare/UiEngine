using System.Xml.Serialization; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="structure")]
public class Structure { 

	[XmlElement(ElementName="bean")] 
	public Bean Bean { get; set; } 
}

}