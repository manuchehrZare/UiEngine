using System.Xml.Serialization; 
using System.Collections.Generic; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="events")]
public class Events { 

	[XmlElement(ElementName="lC")] 
	public List<LC> LC { get; set; } 
}

}