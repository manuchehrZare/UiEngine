using System.Xml.Serialization; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="rule")]
public class Rule { 

	[XmlAttribute(AttributeName="id")] 
	public string Id { get; set; } 

	[XmlAttribute(AttributeName="op")] 
	public string Op { get; set; } 

	[XmlAttribute(AttributeName="source")] 
	public string Source { get; set; } 

	[XmlAttribute(AttributeName="target")] 
	public string Target { get; set; } 
}

}