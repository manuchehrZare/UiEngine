using System.Xml.Serialization; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="rC")]
public class RC { 

	[XmlElement(ElementName="inputs")] 
	public Inputs Inputs { get; set; } 

	[XmlElement(ElementName="outputs")] 
	public Outputs Outputs { get; set; } 

	[XmlAttribute(AttributeName="s")] 
	public string S { get; set; } 

	[XmlAttribute(AttributeName="status")] 
	public int Status { get; set; } 
}

}