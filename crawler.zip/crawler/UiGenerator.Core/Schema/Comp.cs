using System.Xml.Serialization; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="comp")]
public class Comp { 

	[XmlAttribute(AttributeName="id")] 
	public string Id { get; set; } 

	[XmlAttribute(AttributeName="m")] 
	public string M { get; set; } 
}

}