using System.Xml.Serialization;
using System.Collections.Generic;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "lC")]
    public class LC
    {

        [XmlElement(ElementName = "ref")]
        public string Ref { get; set; }

        [XmlAttribute(AttributeName = "type")]
        public string Type { get; set; }

        [XmlText]
        public string Text { get; set; }

        [XmlElement(ElementName = "var")]
        public Var Var { get; set; }

        [XmlElement(ElementName = "rC")]
        public RC RC { get; set; }

        [XmlElement(ElementName = "p")]
        public List<P> P { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "n")]
        public string N { get; set; }
    }

}