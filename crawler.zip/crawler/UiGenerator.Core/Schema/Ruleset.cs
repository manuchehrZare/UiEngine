using System.Xml.Serialization; 
using System.Collections.Generic; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="ruleset")]
public class Ruleset { 

	[XmlElement(ElementName="message")] 
	public List<Message> Message { get; set; } 

	[XmlElement(ElementName="rule")] 
	public List<Rule> Rule { get; set; } 
}

}