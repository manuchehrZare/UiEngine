using System.Xml.Serialization;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "var")]
    public class Var
    {

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "n")]
        public string N { get; set; }

        [XmlElement(ElementName = "comp")]
        public Comp Comp { get; set; }

        [XmlText]
        public string Text { get; set; }

        [XmlAttribute(AttributeName = "rule")]
        public string Rule { get; set; }
    }

}


