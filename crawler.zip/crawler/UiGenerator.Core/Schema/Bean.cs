using System.Xml.Serialization;
using System.Collections.Generic;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "bean")]
    public class Bean
    {

        [XmlElement(ElementName = "style")]
        public Style Style { get; set; }

        [XmlAttribute(AttributeName = "class")]
        public string Class { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlText]
        public string Text { get; set; }

        [XmlElement(ElementName = "bean")]
        public List<Bean> SubBean { get; set; }
    }

}