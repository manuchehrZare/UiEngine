using System.Xml.Serialization; 
using System.Collections.Generic; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="style")]
public class Style { 

	[XmlElement(ElementName="p")] 
	public List<P> P { get; set; } 
}

}