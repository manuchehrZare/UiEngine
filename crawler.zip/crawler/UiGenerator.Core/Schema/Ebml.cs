using System.Xml.Serialization; 
namespace UiGenerator.Core.Schema { 

[XmlRoot(ElementName="ebml")]
public class Ebml { 

	[XmlElement(ElementName="interface")] 
	public Interface Interface { get; set; } 

	[XmlElement(ElementName="data")] 
	public Data Data { get; set; } 

	[XmlElement(ElementName="ruleset")] 
	public Ruleset Ruleset { get; set; } 

	[XmlElement(ElementName="methodset")] 
	public object Methodset { get; set; } 

	[XmlElement(ElementName="fork")] 
	public object Fork { get; set; } 

	[XmlElement(ElementName="script")] 
	public object Script { get; set; } 

	[XmlAttribute(AttributeName="language")] 
	public string Language { get; set; } 

	[XmlAttribute(AttributeName="pid")] 
	public string Pid { get; set; } 

	[XmlAttribute(AttributeName="size")] 
	public string Size { get; set; } 

	[XmlAttribute(AttributeName="techVersion")] 
	public string TechVersion { get; set; } 

	[XmlAttribute(AttributeName="type")] 
	public int Type { get; set; } 

	[XmlAttribute(AttributeName="v")] 
	public string V { get; set; } 

	[XmlText] 
	public string Text { get; set; } 
}

}