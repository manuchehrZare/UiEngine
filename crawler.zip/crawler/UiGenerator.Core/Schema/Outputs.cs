using System.Xml.Serialization; 
using System.Collections.Generic; 
namespace UiGenerator.Core.Schema{ 

[XmlRoot(ElementName="outputs")]
public class Outputs { 

	[XmlElement(ElementName="p")] 
	public List<P> P { get; set; } 

	[XmlElement(ElementName="var")] 
	public List<Var> Var { get; set; } 
}

}