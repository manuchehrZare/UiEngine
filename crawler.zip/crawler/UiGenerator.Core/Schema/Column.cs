using System.Drawing;
using System.Xml.Serialization;
namespace UiGenerator.Core.Schema
{

    [XmlRoot(ElementName = "column")]
    public class Column
    {

        [XmlElement(ElementName = "style")]
        public Style Style { get; set; }

        [XmlAttribute(AttributeName = "alignment")]
        public int Alignment { get; set; }

        //[XmlAttribute(AttributeName = "background")]
        //public object Background { get; set; }

        [XmlIgnore]
        public int[] Background { get; set; }
        [XmlAttribute(AttributeName = "background")]
        public string BackgroundStr
        {
            get => Background != null ? string.Join(",", Background) : "";
            set => Background = value.Split(',').Select(s => int.Parse(s.Trim())).ToArray();
        }


        [XmlAttribute(AttributeName = "editable")]
        public bool Editable { get; set; }

        [XmlIgnore]
        public int[] Foreground { get; set; }
        [XmlAttribute(AttributeName = "foreground")]
        public string ForegroundStr
        {
            get => Foreground != null ? string.Join(",", Foreground) : "";
            set => Foreground = value.Split(',').Select(s => int.Parse(s.Trim())).ToArray();
        }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "menuVisible")]
        public bool MenuVisible { get; set; }

        [XmlAttribute(AttributeName = "order")]
        public int Order { get; set; }

        [XmlAttribute(AttributeName = "title")]
        public string Title { get; set; }

        [XmlAttribute(AttributeName = "type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "visible")]
        public bool Visible { get; set; }

        [XmlAttribute(AttributeName = "width")]
        public int Width { get; set; }

        [XmlText]
        public string Text { get; set; }
    }

}