import { defineConfig, type PluginOption } from 'vite';
import react from '@vitejs/plugin-react';
import { nodePolyfills } from 'vite-plugin-node-polyfills';
import commonJs from 'vite-plugin-commonjs';
import svgr from 'vite-plugin-svgr';
import checker from 'vite-plugin-checker';
import inspect from 'vite-plugin-inspect';
import { visualizer } from 'rollup-plugin-visualizer';

// https://vite.dev/config/
export default defineConfig({
    build: { outDir: 'build' },
    server: { open: true, port: 8013 },
    preview: { port: 8013 },
    plugins: [
        nodePolyfills(),
        commonJs(),
        react(),
        checker({
            eslint: { lintCommand: 'eslint "./src/**/*.{ts,tsx,jsx}"', useFlatConfig: true },
            typescript: {
                tsconfigPath: 'tsconfig.json',
                buildMode: false,
            },
        }),
        svgr({ include: '**/*.svg', svgrOptions: { icon: false, exportType: 'named' } }),
        inspect(),
        visualizer({
            filename: 'stats.html',
            template: 'treemap',
            open: false,
            gzipSize: true,
            brotliSize: true,
        }) as PluginOption,
    ],
});
