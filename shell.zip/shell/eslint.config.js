import js from '@eslint/js';
import globals from 'globals';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';
import tseslint from 'typescript-eslint';
import importPlugin from 'eslint-plugin-import';
import stylisticPlugin from '@stylistic/eslint-plugin';
import reactPlugin from 'eslint-plugin-react';
import prettierPlugin from 'eslint-plugin-prettier';
import prettierConfig from 'eslint-config-prettier';

export default tseslint.config(
    { ignores: ['dist', 'build'] },
    {
        extends: [js.configs.recommended, ...tseslint.configs.recommended],
        files: ['**/*.{ts,tsx}'],
        languageOptions: {
            ecmaVersion: 2020,
            globals: globals.browser,
            parserOptions: {
                ecmaFeatures: {
                    jsx: true,
                },
            },
        },
        settings: { react: { version: 'detect' } },
        plugins: {
            'react-hooks': reactHooks,
            'react-refresh': reactRefresh,
            import: importPlugin,
            '@stylistic': stylisticPlugin,
            react: reactPlugin,
            prettier: prettierPlugin,
        },
        rules: {
            ...reactHooks.configs.recommended.rules,
            'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
            '@typescript-eslint/await-thenable': 'off',
            '@typescript-eslint/ban-ts-comment': 'off',
            '@typescript-eslint/consistent-type-assertions': [
                'off',
                { assertionStyle: 'as', objectLiteralTypeAssertions: 'allow-as-parameter' },
            ],
            '@typescript-eslint/consistent-type-definitions': 'off',
            '@typescript-eslint/explicit-module-boundary-types': [
                'error',
                { allowArgumentsExplicitlyTypedAsAny: true },
            ],
            '@typescript-eslint/member-ordering': ['error', { default: { order: 'alphabetically-case-insensitive' } }],
            '@typescript-eslint/restrict-template-expressions': 'off',
            '@typescript-eslint/no-empty-object-type': 'off', // for safe type define
            '@typescript-eslint/no-unsafe-function-type': 'error', // for safe type define
            '@typescript-eslint/no-wrapper-object-types': 'error', // for safe type define
            '@typescript-eslint/method-signature-style': ['error', 'property'], // for type define
            '@typescript-eslint/naming-convention': 'off',
            '@typescript-eslint/interface-name-prefix': 'off',
            '@typescript-eslint/no-empty-interface': ['off', { allowSingleExtends: true }], // empty interface using
            '@typescript-eslint/no-explicit-any': 'off', // any using
            '@typescript-eslint/no-unsafe-argument': 'off', // any using
            '@typescript-eslint/no-extra-non-null-assertion': 'error',
            '@typescript-eslint/no-inferrable-types': 'off',
            '@typescript-eslint/no-floating-promises': 'off', // for return promise
            '@typescript-eslint/no-unsafe-assignment': 'off', // any using
            '@typescript-eslint/no-unsafe-call': 'off', // any using
            '@typescript-eslint/no-unsafe-member-access': 'off', // any using
            '@typescript-eslint/no-unsafe-return': 'off', // any using
            '@typescript-eslint/unbound-method': 'off',
            '@typescript-eslint/prefer-find': 'off',
            '@typescript-eslint/prefer-includes': 'off',
            '@typescript-eslint/prefer-nullish-coalescing': 'off',
            '@typescript-eslint/no-unsafe-enum-comparison': 'off',
            '@typescript-eslint/no-var-requires': 'off',
            '@typescript-eslint/consistent-type-imports': ['error', { prefer: 'type-imports' }],
            // * last params default value
            'default-param-last': 'off', // last params default value
            '@typescript-eslint/default-param-last': ['error'], // last params default value
            // * unused-vars
            'no-unused-vars': 'off',
            '@typescript-eslint/no-unused-vars': ['error'],
            // * unused-expressions
            'no-unused-expressions': 'off',
            '@typescript-eslint/no-unused-expressions': 'off',
            // * duplicate imports
            'no-duplicate-imports': 'off',
            'import/no-duplicates': ['error', { considerQueryString: true }],
            // * redeclare
            'no-redeclare': 'off',
            '@typescript-eslint/no-redeclare': ['error'],
            // * shadow declare
            'no-shadow': 'off',
            '@typescript-eslint/no-shadow': ['warn'],
            // * use-before-define
            'no-use-before-define': 'off',
            '@typescript-eslint/no-use-before-define': 'warn',
            // * prefer-promise-reject-errors
            'prefer-promise-reject-errors': 'off',
            '@typescript-eslint/prefer-promise-reject-errors': 'off',
            // * await
            'require-await': 'off',
            '@typescript-eslint/require-await': 'off',
            '@typescript-eslint/no-misused-promises': 'off', // for await using
            'import/no-anonymous-default-export': 'off',
            '@stylistic/member-delimiter-style': 'error', // for type define
            '@stylistic/type-annotation-spacing': 'error',
            'react/button-has-type': 'error',
            'react/display-name': 'off',
            'react/no-array-index-key': 'warn', // Keylerde array indexlerin kullanılmamasını önerir.
            'react/no-deprecated': 'warn', // Deprecated metodların kullanılmamasını önerir
            'react/prop-types': 'error',
            'react/self-closing-comp': 'error',
            'react/jsx-boolean-value': ['warn', 'never', { always: [] }], // Boolean proplarda true değerlerinin kaldırılmasını önerir
            'react/jsx-closing-tag-location': 'error',
            'react/jsx-no-useless-fragment': 'warn',
            'react/jsx-pascal-case': 'off',
            'react/react-in-jsx-scope': 'off', // import React .... : Disable for new JSX Transform
            'no-alert': 'error',
            'no-debugger': 'error',
            'no-console': 'warn',
            'no-lone-blocks': 'error',
            'no-else-return': 'warn',
            'no-lonely-if': 'warn',
            'no-prototype-builtins': 'off',
            'no-undef': 'off',
            'prefer-template': 'warn', // String concat
            eqeqeq: 'error', // === and !==
            // * prettier
            'prettier/prettier': 'error',
            ...prettierConfig.rules,
        },
    },
);
