import { i18nInit } from './_i18nInstance';
import { i18nInit as i18nInitSekerUI } from 'seker-ui';
import { i18nInit as i18nInitSetUI } from 'set-ui';

export const i18nInitialize = async (): Promise<void> => {
    await i18nInitSekerUI();
    await i18nInitSetUI();
    await i18nInit();
};
