export default {
    copied: 'Kopyalandı!',
    navigateToLoginPage: 'Giriş ekranına yönlendirileceksiniz.',
    noData: 'Veri Bulunamadı!',
};
