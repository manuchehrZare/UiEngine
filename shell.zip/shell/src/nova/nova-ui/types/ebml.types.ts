/* eslint-disable */
/**
 * EBML Schema Type Definitions
 * These types represent the structure of EBML UI definitions from the legacy Java application
 */

export interface EbmlProperty {
    Name: string;
    Text: string;
    Columns?: any;
    Id?: string | null;
    M?: any;
    Rule?: any;
    Var?: any;
    N?: any;
    Comp?: any;
}

export interface EbmlStyle {
    P: EbmlProperty[];
}

export interface EbmlBean {
    Style: EbmlStyle;
    Class: string;
    Id: string;
    Text?: string | null;
    SubBean: EbmlBean[];
}

export interface EbmlStructure {
    Bean: EbmlBean;
}

export interface EbmlVar {
    Id: string;
    N?: string | null;
    Comp?: string | null;
    Text?: string | null;
    Rule?: string | null;
}

export interface EbmlData {
    Var: EbmlVar[];
}

export interface EbmlSimpleRule {
    Id: string;
    Op: string;
    Source: string;
    Target?: string;
    TargetType?: string;
}

export interface EbmlMessageRule {
    Id: string;
    Var?: string | null;
    MessageType: string;
    Title: string;
    Type: string;
    Text: string;
}

export interface EbmlCombinationRule {
    Id: string;
    Expression: string;
}

export interface EbmlRuleset {
    Rule?: EbmlSimpleRule[];
    Message?: EbmlMessageRule[];
    Combination?: EbmlCombinationRule[];
}

export interface EbmlEventParameter {
    Name?: string | null;
    Text?: string | null;
    Columns?: any;
    Id?: string | null;
    M?: string | null;
    Rule?: string | null;
    Var?: any;
    N?: string | null;
    Comp?: any;
}

export interface EbmlRemoteCall {
    S: string; // Service name
    Status?: number;
    Inputs?: {
        Var?: EbmlEventParameter[];
        P?: EbmlEventParameter[];
    };
    Outputs?: {
        Var?: EbmlEventParameter[];
        P?: EbmlEventParameter[];
    };
}

export interface EbmlEventDefinition {
    Id?: string | null;
    N?: string | null;
    Type?: string;
    Text?: string | null;
    Var?: any;
    Rule?: string | null;
    RC?: EbmlRemoteCall | null;
    P?: EbmlEventParameter[];
    Ref?: string[];
}

export interface EbmlEvents {
    [eventName: string]: EbmlEventDefinition[];
}

export interface EbmlInterface {
    Structure: EbmlStructure;
    Events?: EbmlEvents;
}

export interface EbmlContent {
    Interface: EbmlInterface;
    Data?: EbmlData;
    Ruleset?: EbmlRuleset;
}

export interface PageDefinition {
    Name: string;
    EbmlName: string;
    ModuleName: string;
    Type: 'page' | 'popup' | 'region' | 'screen';
    ScreenCode: string;
    MenuName: string;
    EbmlContent: EbmlContent;
}

/**
 * Component mapping types
 */
export interface ComponentBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface ParsedComponent {
    id: string;
    type: string;
    bounds: ComponentBounds;
    properties: Record<string, any>;
    children?: ParsedComponent[];
}

/**
 * Known EBML component classes and their React counterparts
 */
export enum EbmlComponentClass {
    // Container components
    PAGE = 'tr.com.cs.aurora.ebml.bean.swing.JCSPage',
    PANEL = 'tr.com.cs.aurora.ebml.bean.swing.JCSPanel',
    REGION = 'tr.com.cs.aurora.ebml.bean.swing.JCSRegion',
    TABBED_PANE = 'tr.com.cs.aurora.ebml.bean.swing.JCSTabbedPane',
    TAB = 'tr.com.cs.aurora.ebml.bean.swing.JCSTab',
    TAB_PAGE = 'tr.com.cs.aurora.ebml.bean.swing.JCSTabPage',

    // Form components
    TEXT_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSTextField',
    TEXT_AREA = 'tr.com.cs.aurora.ebml.bean.swing.JCSTextArea',
    NUMBER_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSNumberField',
    DATE_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSDateField',
    TIME_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSTimeField',
    DATETIME_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSDateTimeField',
    CHECKBOX = 'tr.com.cs.aurora.ebml.bean.swing.JCSCheckBox',
    RADIO = 'tr.com.cs.aurora.ebml.bean.swing.JCSRadioButton',
    COMBOBOX = 'tr.com.cs.aurora.ebml.bean.swing.JCSComboBox',
    CURRENCY_FIELD = 'tr.com.cs.aurora.ebml.bean.swing.JCSCurrencyField',

    // Display components
    LABEL = 'tr.com.cs.aurora.ebml.bean.swing.JCSLabel',
    TABLE = 'tr.com.cs.aurora.ebml.bean.swing.JCSTable',
    BUTTON = 'tr.com.cs.aurora.ebml.bean.swing.JCSButton',
    HANDLEBUTTON = 'tr.com.cs.aurora.ebml.bean.swing.JCSHandleButtonField',

    // Other components
    SEPARATOR = 'tr.com.cs.aurora.ebml.bean.swing.JSeparator',
}

export type EbmlComponentMap = {
    [key in EbmlComponentClass]?: string;
};

