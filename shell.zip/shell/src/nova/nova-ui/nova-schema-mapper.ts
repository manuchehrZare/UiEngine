/* eslint-disable */
import type { EbmlBean, EbmlContent, ParsedComponent, PageDefinition } from './types/ebml.types';
import type { NovaUiSchema } from './types/nova-schema.types';
import { parseBeanWithNesting } from './parser/ebml-parser';
import { COMPONENT_REGISTRY } from '../nova-studio/utils/componentRegistry';
import { resolveComponentType } from './utils/mappings';
import uiDefinitionsData from '../../assets/docs/ui-definition.json';
import type { DesignComponent } from '../nova-studio/context/DesignerContext';
import { convertEbmlToNovaSchema } from './EbmlConverter';

// Cast the imported JSON to the correct type
const uiDefinitions = uiDefinitionsData as PageDefinition[];

/**
 * Calculate Grid columns (1-12) based on width relative to parent
 */
const calculateGridSize = (width: number, parentWidth: number): number => {
    if (!parentWidth || parentWidth <= 0) return 12;
    const fraction = width / parentWidth;
    const columns = Math.round(fraction * 12);
    return Math.max(1, Math.min(12, columns));
};

/**
 * Sort components by Row (Y) then Column (X)
 */
const sortComponentsByGridOrder = (components: ParsedComponent[]) => {
    return [...components].sort((a, b) => {
        // Group by row with some tolerance (e.g. 10px)
        if (Math.abs(a.bounds.y - b.bounds.y) > 10) {
            return a.bounds.y - b.bounds.y;
    }
        // Within row, sort by X
        return a.bounds.x - b.bounds.x;
    });
};

/**
 * Map ParsedComponent (nested structure) to DesignComponent (Grid structure)
 */
const mapParsedComponentToDesign = (
    component: ParsedComponent,
    parentId: string | null
): DesignComponent => {
    // component.type is already resolved by ebml-parser, but we double check/fallback
    const designType = COMPONENT_REGISTRY[component.type] ? component.type : resolveComponentType(component.type) || component.type;
    
    const defaultProps = COMPONENT_REGISTRY[designType]?.defaultProps || {};
    const props: Record<string, any> = {
        ...defaultProps,
        ...component.properties,
        id: component.id,
        name: component.id,
        bounds: component.bounds, // Pass bounds to all components
        // Fix: Check for resolved type 'TableComponent' instead of Java class name
        xs: designType === 'TableComponent' ? 12 : undefined,
        // Fix: HandleButton renders its own GridItem if useAbsolutePositioning is false, so we force it to true to avoid double wrapping
        useAbsolutePositioning: designType === 'HandleButton' ? true : undefined,
    };

    let children: DesignComponent[] = [];

    // Special handling for Page (JCSPage)
    if (designType === 'Page') {
        // We create a Root Grid Container
        // Inside it, we put a GridItem which acts as the "Page" component holder (though Page is usually a layout itself)
        // But user requested: "use two component, a gridItem inside Grid and set property of bean to gridItem make root grid Container and direction to column"
        
        // 1. Map children first
        // Note: We use the same recursion logic for children
        if (component.children && component.children.length > 0) {
            const sortedChildren = sortComponentsByGridOrder(component.children);
            children = sortedChildren.map(child => {
                // For children of Page, we usually wrap them in GridItems because Page (now Root Grid) is a container
                const mappedChild = mapParsedComponentToDesign(child, component.id);
                // Calculate responsive width (xs) relative to page width
                const xs = calculateGridSize(child.bounds.width, component.bounds.width);
                const finalXs = mappedChild.type === 'TableComponent' ? 12 : xs;

                return {
                    id: `grid-item-${child.id}`,
                    type: 'GridItem',
                    props: { xs: finalXs, key: child.id },
                    children: [mappedChild],
                    parentId: component.id,
                };
            });
        }

        // 2. Create the GridItem that holds the Page properties
        // Wait, if the Root is Grid, and children are GridItems, where does the "bean property" go?
        // "set property of bean to gridItem". This implies there's a specific GridItem representing the Page itself?
        // Or does it mean the Page content is inside a GridItem?
        // "gridItem inside Grid" -> One GridItem inside One Grid?
        // If Page has many children, do they all go into ONE GridItem?
        // "use two component, a gridItem inside Grid" -> Singular.
        // So: Root Grid -> Single GridItem -> Children?
        
        // Let's assume the user wants to wrap the entire page content in a single GridItem, 
        // and that GridItem receives the Page properties (like background color etc?).
        
        const pageContentGridItem: DesignComponent = {
            id: `page-content-${component.id}`,
            type: 'GridItem',
            props: {
                ...props, // Bean properties go here
                xs: 12,   // Full width
                container: true,
                 spacing: 2,

            },
            children: children, // All mapped children go inside this single GridItem
            parentId: component.id
        };

        // 3. Create Root Grid
        return {
            id: component.id,
            type: 'Grid',
            props: {
                container: true,
                direction: 'column',
                spacing: 2,
                style: { height: '100%', width: '100%' },
                p:2,
            },
            children: [pageContentGridItem],
            parentId,
        };
    }

    // Special handling for Container (JCSPanel)
    if (designType === 'Container') {
        // "use four component, a Grid inside Paper inside gridItem and set property of bean to Grid, and then put childs as gridItem inside grid"

        // 1. Map children first
        if (component.children && component.children.length > 0) {
            const sortedChildren = sortComponentsByGridOrder(component.children);
            children = sortedChildren.map(child => {
                // Children go inside the inner Grid, so they need to be GridItems
                const mappedChild = mapParsedComponentToDesign(child, `grid-${component.id}`);
                // Calculate responsive width (xs) relative to panel width
                const xs = calculateGridSize(child.bounds.width, component.bounds.width);
                const finalXs = mappedChild.type === 'TableComponent' ? 12 : xs;

                return {
                    id: `grid-item-${child.id}`,
                    type: 'GridItem',
                    props: { xs: finalXs, key: child.id },
                    children: [mappedChild],
                    parentId: `grid-${component.id}`,
                };
            });
        }

        // If panel has a title, add Nav component as first child
        const panelTitle = component.properties?.title || component.properties?.label;
        if (panelTitle) {
            // Create Nav component with title
            const navComponent: DesignComponent = {
                id: `nav-${component.id}`,
                type: 'Nav',
                props: {
                    navTitleProps: { title: panelTitle }
                },
                children: [],
                parentId: `grid-${component.id}`
            };

            // Wrap Nav in GridItem
            const navGridItem: DesignComponent = {
                id: `grid-item-nav-${component.id}`,
                type: 'GridItem',
                props: { xs: 12, key: `nav-${component.id}` },
                children: [navComponent],
                parentId: `grid-${component.id}`
            };

            // Add Nav as first child
            children = [navGridItem, ...children];
        }

        // 2. Create Inner Grid (receives bean properties)
        const innerGrid: DesignComponent = {
            id: `grid-${component.id}`,
            type: 'Grid',
            props: {
                ...props, // Set property of bean to Grid
                container: true,
                spacing: 2,
                style: { height: '100%', width: '100%' }
            },
            children: children,
            parentId: `paper-${component.id}` // Parent is Paper
        };

        // 3. Create Paper Wrapper
        // Note: The parent logic (if this is inside a Grid) will wrap this Paper in a GridItem.
        return {
            id: component.id,
            type: 'Paper',
            props: {
                elevation: 1,
                style: { height: '100%', width: '100%', padding: '16px', overflow: 'hidden' }
            },
            children: [innerGrid],
            parentId
        };
    }

    // Handle children (Default logic for non-Page/non-Container)
    // Region Handling
    else if (designType === 'Paper' && component.properties?.regionName) {
        const regionName = component.properties.regionName;
        const regionDef = uiDefinitions.find(d => d.Name === regionName);
        if (regionDef?.EbmlContent?.Interface?.Structure?.Bean) {
            const regionRoot = parseBeanWithNesting(regionDef.EbmlContent.Interface.Structure.Bean);
            children.push(mapParsedComponentToDesign(regionRoot, component.id));
        }
    }
    // Standard Children Handling
    else if (component.children && component.children.length > 0) {
        const sortedChildren = sortComponentsByGridOrder(component.children);

        children = sortedChildren.map(child => {
            const isGridContainer = ['Grid', 'Container', 'Paper'].includes(designType) || COMPONENT_REGISTRY[designType]?.isContainer;
            const mappedChild = mapParsedComponentToDesign(child, component.id);

            // Special handling: TabbedPane and TabPage should NOT wrap their children in GridItem
            // - TabbedPane must receive TabPage components directly, not wrapped in GridItem
            // - TabPage children should be direct children, not wrapped in GridItem
            // BUT: TabbedPane itself CAN be wrapped in GridItem when it's a child of a Grid container
            const parentIsTabbedPaneOrTabPage = designType === 'TabbedPane' || designType === 'TabPage';

            if (isGridContainer && !parentIsTabbedPaneOrTabPage) {
                // Calculate responsive width (xs)
                const xs = calculateGridSize(child.bounds.width, component.bounds.width);

                // Force TableComponent and TabbedPane to full width for better display
                const finalXs = (mappedChild.type === 'TableComponent' || mappedChild.type === 'TabbedPane') ? 12 : xs;

                return {
                    id: `grid-item-${child.id}`,
                    type: 'GridItem',
                    props: { xs: finalXs, key: child.id },
                    children: [mappedChild],
                    parentId: component.id,
                };
            }
            return mappedChild;
        });
    }

    // If component is a container, ensure direction is row (default for Grid)
    if (designType === 'Grid') {
        props.container = true;
        props.spacing = 2;
    }

    return {
        id: component.id,
        type: designType,
        props,
        children,
        parentId,
    };
};

export const mapBeanToDesignComponent = (bean: EbmlBean, parentId: string | null = null): DesignComponent => {
    // This function is kept for compatibility but redirects to the new logic
    const parsed = parseBeanWithNesting(bean);
    return mapParsedComponentToDesign(parsed, parentId);
};

export const mapEbmlContentToDesignSchema = (content: EbmlContent): DesignComponent => {
    try {
        const rootBean = content?.Interface?.Structure?.Bean;
        if (!rootBean) {
            throw new Error('Invalid EBML content - no Bean found');
        }

        // 1. Parse and fix hierarchy based on bounds
        const parsedRoot = parseBeanWithNesting(rootBean);

        // 2. Convert to Design Component Tree with Grid System
        const result = mapParsedComponentToDesign(parsedRoot, null);

        return result;
    } catch (error) {
        console.error('❌ Error in mapEbmlContentToDesignSchema:', error);
        console.error('Stack trace:', error instanceof Error ? error.stack : 'No stack trace');
        throw error;
    }
};

/**
 * Map EBML Content to NovaUiSchema (NEW unified format)
 * This combines UI components with events, rules, and variables
 */
export const mapEbmlContentToNovaSchema = (content: EbmlContent): NovaUiSchema => {
    try {
        // 1. Convert using the comprehensive converter
        const novaSchema = convertEbmlToNovaSchema(content);

        // 2. If we have a Bean, override the UI with our enhanced mapping logic
        const rootBean = content?.Interface?.Structure?.Bean;
        if (rootBean) {
            // Use our existing mapping logic for better UI component structure
            const parsedRoot = parseBeanWithNesting(rootBean);
            const designComponent = mapParsedComponentToDesign(parsedRoot, null);
            novaSchema.ui = [designComponent];
        }

        return novaSchema;
    } catch (error) {
        console.error('❌ Error in mapEbmlContentToNovaSchema:', error);
        console.error('Stack trace:', error instanceof Error ? error.stack : 'No stack trace');
        throw error;
    }
};
