/* eslint-disable */
/**
 * EBML Converter
 * Converts legacy EBML content to internal Designer Schema
 * Includes components, rules, variables, and actions
 */

import type { EbmlContent, ParsedComponent } from './types/ebml.types';
import type { NovaUiSchema } from './types/nova-schema.types';
import { parseBeanWithNesting } from './parser/ebml-parser';
import { v4 as uuidv4 } from 'uuid';
import type { DesignComponent, Rule, Variable, Action } from '../nova-studio/context/DesignerContext';
import { parseEbmlRules, parseEbmlVariables, parseEbmlActions } from '../nova-studio/utils/ebmlParser';

/**
 * Complete design schema including all designer elements
 */
export interface CompleteDesignSchema {
    components: DesignComponent[];
    rules: Rule[];
    variables: Variable[];
    actions: Action[];
    jsCode?: string;
    cssCode?: string;
}

/**
 * Recursive helper to convert ParsedComponent to DesignComponent
 */
const convertParsedToDesign = (parsed: ParsedComponent, parentId: string | null = null): DesignComponent => {
    const id = parsed.id || uuidv4();
    const designComponent: DesignComponent = {
        id,
        type: parsed.type,
        props: {
            ...parsed.properties,
            // Preserve bounds if needed, though layout system handles it
            bounds: parsed.bounds
        },
        children: [],
        parentId
    };

    if (parsed.children && parsed.children.length > 0) {
        designComponent.children = parsed.children.map(child =>
            convertParsedToDesign(child, id)
        );
    }

    return designComponent;
};

/**
 * Convert EBML content to Designer Schema (DesignComponent only - legacy)
 * @deprecated Use convertEbmlToCompleteSchema instead for full design including rules, variables, actions
 */
export const convertEbmlToSchema = (content: EbmlContent): DesignComponent => {
    if (!content?.Interface?.Structure?.Bean) {
        throw new Error('Invalid EBML content structure');
    }

    const rootBean = content.Interface.Structure.Bean;
    const parsedComponent = parseBeanWithNesting(rootBean);

    return convertParsedToDesign(parsedComponent, 'root');
};

/**
 * Convert EBML content to Complete Designer Schema
 * Includes components, rules, variables, and actions
 */
export const convertEbmlToCompleteSchema = (content: EbmlContent): CompleteDesignSchema => {
    const result: CompleteDesignSchema = {
        components: [],
        rules: [],
        variables: [],
        actions: [],
        jsCode: '// Custom JS here',
        cssCode: '/* Custom CSS here */'
    };

    // Parse components if Interface.Structure.Bean exists
    if (content?.Interface?.Structure?.Bean) {
        try {
            const rootBean = content.Interface.Structure.Bean;
            const parsedComponent = parseBeanWithNesting(rootBean);
            const designComponent = convertParsedToDesign(parsedComponent, null);
            result.components = [designComponent];
        } catch (error) {
            console.warn('Failed to parse EBML components:', error);
        }
    }

    // Parse variables from Data.Var
    if (content?.Data?.Var) {
        result.variables = parseEbmlVariables(content.Data.Var);
    }

    // Parse rules from Ruleset
    if (content?.Ruleset) {
        result.rules = parseEbmlRules(content.Ruleset);
    }

    // Parse actions from Interface.Events
    if (content?.Interface?.Events) {
        result.actions = parseEbmlActions(content.Interface.Events);
    }

    return result;
};

/**
 * Convert EBML content to NovaUiSchema (NEW unified format)
 * This is the recommended format for Nova UI Studio
 */
export const convertEbmlToNovaSchema = (content: EbmlContent): NovaUiSchema => {
    const components: DesignComponent[] = [];
    const rules: Rule[] = [];
    const variables: Variable[] = [];
    const actions: Action[] = [];

    // Parse components if Interface.Structure.Bean exists
    if (content?.Interface?.Structure?.Bean) {
        try {
            const rootBean = content.Interface.Structure.Bean;
            const parsedComponent = parseBeanWithNesting(rootBean);
            const designComponent = convertParsedToDesign(parsedComponent, null);
            components.push(designComponent);
        } catch (error) {
            console.warn('Failed to parse EBML components:', error);
        }
    }

    // Parse variables from Data.Var
    if (content?.Data?.Var) {
        variables.push(...parseEbmlVariables(content.Data.Var));
    }

    // Parse rules from Ruleset
    if (content?.Ruleset) {
        rules.push(...parseEbmlRules(content.Ruleset));
    }

    // Parse actions from Interface.Events
    if (content?.Interface?.Events) {
        actions.push(...parseEbmlActions(content.Interface.Events));
    }

    return {
        ui: components,
        events: {
            actions
        },
        ruleset: {
            rules
        },
        variables: {
            vars: variables
        },
        jsCode: '// Custom JS here',
        cssCode: '/* Custom CSS here */',
        metadata: {
            version: '1.0',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        }
    };
};

/**
 * Convert CompleteDesignSchema to NovaUiSchema
 */
export const convertCompleteSchemaToNova = (schema: CompleteDesignSchema): NovaUiSchema => {
    return {
        ui: schema.components || [],
        events: {
            actions: schema.actions || []
        },
        ruleset: {
            rules: schema.rules || []
        },
        variables: {
            vars: schema.variables || []
        },
        jsCode: schema.jsCode || '// Custom JS here',
        cssCode: schema.cssCode || '/* Custom CSS here */',
        metadata: {
            version: '1.0',
            updatedAt: new Date().toISOString()
        }
    };
};

/**
 * Convert NovaUiSchema to CompleteDesignSchema (for backward compatibility)
 */
export const convertNovaToCompleteSchema = (schema: NovaUiSchema): CompleteDesignSchema => {
    return {
        components: schema.ui || [],
        rules: schema.ruleset?.rules || [],
        variables: schema.variables?.vars || [],
        actions: schema.events?.actions || [],
        jsCode: schema.jsCode,
        cssCode: schema.cssCode
    };
};
