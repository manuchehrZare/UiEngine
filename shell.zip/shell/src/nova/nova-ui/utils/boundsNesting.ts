/* eslint-disable */
/**
 * Bounds Nesting Utilities
 * Functions to build component hierarchy based on coordinate containment
 */

import type { ParsedComponent, ComponentBounds } from '../types/ebml.types';

const DEFAULT_PAGE_BOUNDS = { width: 960, height: 700 };

const parseSizeString = (size?: string): { width: number; height: number } | null => {
    if (!size || typeof size !== 'string') {
        return null;
    }

    const [rawWidth, rawHeight] = size.split(',').map((value) => Number(value.trim()));

    if (Number.isFinite(rawWidth) && Number.isFinite(rawHeight)) {
        return {
            width: rawWidth,
            height: rawHeight,
        };
    }

    return null;
};

const applyPageDimensions = (component: ParsedComponent): void => {
    if (!component) {
        return;
    }

    const sizeFromProps =
        parseSizeString(component.properties?.pageSize) ||
        parseSizeString(component.properties?.popupSize) ||
        parseSizeString(component.properties?.regionSize);

    const targetWidth = sizeFromProps?.width ?? component.bounds?.width ?? DEFAULT_PAGE_BOUNDS.width;
    const targetHeight = sizeFromProps?.height ?? component.bounds?.height ?? DEFAULT_PAGE_BOUNDS.height;

    component.bounds = {
        x: component.bounds?.x ?? 0,
        y: component.bounds?.y ?? 0,
        width: targetWidth,
        height: targetHeight,
    };
};

/**
 * Check if child bounds are loosely inside parent bounds
 * Uses Top-Left corner check + tolerance to handle components that might be slightly larger
 * or sticking out due to legacy sizing
 */
export const isInsideBounds = (childBounds: ComponentBounds, parentBounds: ComponentBounds, customTolerance?: number): boolean => {
    // Relaxed containment: Check if Top-Left corner is inside the parent
    // Added tolerance for legacy systems where components might be slightly off
    const tolerance = customTolerance ?? 5; 
    
    const topLeftInside = 
        childBounds.x >= (parentBounds.x - tolerance) && 
        childBounds.y >= (parentBounds.y - tolerance) && 
        childBounds.x < (parentBounds.x + parentBounds.width + tolerance) && 
        childBounds.y < (parentBounds.y + parentBounds.height + tolerance);

    return topLeftInside;
};

/**
 * Get bounds area for sorting
 */
const getBoundsArea = (bounds: ComponentBounds): number => {
    return bounds.width * bounds.height;
};

/**
 * Flatten component tree into an array with WORLD SPACE coordinates
 * IMPORTANT: TabPage children are NOT flattened - their original structure is preserved
 * because TabPages have identical overlapping bounds and geometric nesting would break them
 */
export const flattenComponentsWithWorldBounds = (component: ParsedComponent, parentAbsX = 0, parentAbsY = 0, preserveChildren = false): ParsedComponent[] => {
    const componentAbs: ParsedComponent = {
        ...component,
        bounds: {
            ...component.bounds,
            x: component.bounds.x + parentAbsX,
            y: component.bounds.y + parentAbsY
        },
        // For TabPage components, preserve original children structure
        children: preserveChildren ? component.children : []
    };

    const result: ParsedComponent[] = [componentAbs];

    // Don't flatten children if preserveChildren is true (for TabPage)
    if (component.children && !preserveChildren) {
        component.children.forEach(child => {
            // If this child is a TabPage, preserve its children
            const shouldPreserveGrandchildren = child.type === 'TabPage';
            result.push(...flattenComponentsWithWorldBounds(child, componentAbs.bounds.x, componentAbs.bounds.y, shouldPreserveGrandchildren));
        });
    }
    return result;
};

/**
 * Build a hierarchical tree of components based on bounds containment
 * using robust World Space logic
 */
export const buildComponentTree = (components: ParsedComponent[]): ParsedComponent[] => {
    if (!components || components.length === 0) {
        return [];
    }

    // 1. Determine if input is already flat or a tree. 
    // If it's a flat list from a DB or similar, assume they might be in world coordinates or relative to a single root.
    // If it's a list of roots, we might need to process each.
    // For safety, let's assume 'components' is a list of potential siblings/roots in the same coordinate space.

    // Store original World Bounds for containment checks
    const worldBoundsMap = new Map<string, ComponentBounds>();
    components.forEach(c => {
        worldBoundsMap.set(c.id, { ...c.bounds });
    });

    // 2. Identify potential containers
    // We treat everything as a potential container unless we have specific rules
    const containerTypes = ['Panel', 'Region', 'TabbedPane', 'TabPage', 'GroupBox', 'Page', 'Form', 'Grid', 'Box', 'Container'];
    // But really any component *could* contain others in some systems, but usually only these do.
    // Let's stick to known containers to avoid weird nesting (e.g. button inside label).
    const potentialContainers = components.filter(c => 
        containerTypes.includes(c.type)
    );

    // 3. Sort containers by area (Ascending) - smallest first
    potentialContainers.sort((a, b) => {
        const boundsA = worldBoundsMap.get(a.id)!;
        const boundsB = worldBoundsMap.get(b.id)!;
        return getBoundsArea(boundsA) - getBoundsArea(boundsB);
    });

    // 4. Initialize a map to hold children for each parent
    const childrenMap = new Map<string, ParsedComponent[]>();
    const roots: ParsedComponent[] = [];
    
    // Helper to add child to parent
    const addChild = (parentId: string, child: ParsedComponent) => {
        if (!childrenMap.has(parentId)) {
            childrenMap.set(parentId, []);
        }
        childrenMap.get(parentId)!.push(child);
    };

    // 5. Assign each component to a parent
    components.forEach(component => {
        const compBounds = worldBoundsMap.get(component.id)!;
        let assigned = false;
        
        // Check against all potential containers
        for (const container of potentialContainers) {
            if (container.id === component.id) continue; // Cannot contain itself
            
            const containerBounds = worldBoundsMap.get(container.id)!;
            
            // Special handling for TabPage -> TabbedPane relationship
            const isTabPair = component.type === 'TabPage' && container.type === 'TabbedPane';

            // Skip if component is larger than container (optimization)
            if (isTabPair) {
                 if (getBoundsArea(compBounds) > getBoundsArea(containerBounds) * 1.1) continue;
            } else {
                 if (getBoundsArea(compBounds) > getBoundsArea(containerBounds)) continue;
            }

            const tolerance = isTabPair ? 20 : undefined;

            if (isInsideBounds(compBounds, containerBounds, tolerance)) {
                addChild(container.id, component);
                assigned = true;
                break; // Found the smallest container (due to sorting), so stop
            }
        }
    });

    if (!assigned) {
        roots.push(component);
    }

    // 6. Reconstruct the tree
    const attachChildren = (component: ParsedComponent) => {
        const children = childrenMap.get(component.id) || [];
        
        // Sort children by position (Row-major order)
        children.sort((a, b) => {
            const boundsA = worldBoundsMap.get(a.id)!;
            const boundsB = worldBoundsMap.get(b.id)!;
            
            // Use row tolerance for sorting
            if (Math.abs(boundsA.y - boundsB.y) > 10) {
                return boundsA.y - boundsB.y;
            }
            return boundsA.x - boundsB.x;
        });

        component.children = children;

        // Update bounds to be relative to parent
        const parentWorldBounds = worldBoundsMap.get(component.id)!;

        children.forEach(child => {
            const childWorldBounds = worldBoundsMap.get(child.id)!;
            
            // Update child bounds to be relative to this parent
            child.bounds = {
                x: childWorldBounds.x - parentWorldBounds.x,
                y: childWorldBounds.y - parentWorldBounds.y,
                width: childWorldBounds.width,
                height: childWorldBounds.height
            };

            attachChildren(child);
        });
    };

    roots.forEach(attachChildren);

    // Sort roots as well
    roots.sort((a, b) => {
        const boundsA = worldBoundsMap.get(a.id)!;
        const boundsB = worldBoundsMap.get(b.id)!;
        if (Math.abs(boundsA.y - boundsB.y) > 10) {
            return boundsA.y - boundsB.y;
        }
        return boundsA.x - boundsB.x;
    });

    return roots;
};

/**
 * Get a unique key for a component
 */
export const getComponentKey = (component: ParsedComponent): string => {
    return component.id || `${component.type}-${component.bounds.x}-${component.bounds.y}-${component.bounds.width}-${component.bounds.height}`;
};

/**
 * Flatten all components including nested children into a single array
 * Used when we need to rebuild the hierarchy from scratch
 */
export const flattenComponents = (components: ParsedComponent[]): ParsedComponent[] => {
    const result: ParsedComponent[] = [];

    const flatten = (comps: ParsedComponent[]) => {
        comps.forEach(comp => {
            // Add the component without its children
            result.push({
                ...comp,
                children: [],
            });

            // Recursively flatten children
            if (comp.children && comp.children.length > 0) {
                flatten(comp.children);
            }
        });
    };

    flatten(components);
    return result;
};

/**
 * Build component tree from a flat list, nesting based on bounds
 * This is the main function to use for converting EBML structure to proper nesting
 */
export const buildNestedTree = (components: ParsedComponent[]): ParsedComponent[] => {
    // First flatten everything to remove existing hierarchy and treat as world space siblings
    // Note: This assumes 'components' passed in are either already flat world-space items
    // OR a tree where children are relative. If they are relative, we need 'flattenComponentsWithWorldBounds' logic first.
    // But typically this function is called with a raw list or we want to reset nesting.
    
    // For safety, if we suspect it's a tree with relative coords, we should use a flattening that respects that.
    // But here we just flatten structure.
    const flattened = flattenComponents(components);

    // Then rebuild based on bounds containment
    return buildComponentTree(flattened);
};

/**
 * Normalize component tree by reassigning children based on geometric containment
 * Ensures root bounds leverage pageSize metadata when available
 */
export const nestComponentsByBounds = (rootComponent: ParsedComponent): ParsedComponent => {
    if (!rootComponent) {
        return rootComponent;
    }

    applyPageDimensions(rootComponent);

    const flattened = flattenComponentsWithWorldBounds(rootComponent, 0, 0);
    const worldBoundsMap = new Map<string, ComponentBounds>();

    flattened.forEach((component) => {
        worldBoundsMap.set(component.id, { ...component.bounds });
    });

    const flattenedRoot = flattened.find((component) => component.id === rootComponent.id) || flattened[0];
    const containerTypes = ['Panel', 'Region', 'TabbedPane', 'TabPage', 'GroupBox', 'Page', 'Form', 'Grid', 'Box', 'Container'];
    const containers = flattened.filter(
        (component) => containerTypes.includes(component.type) && component.id !== flattenedRoot.id,
    );

    containers.sort((a, b) => {
        const boundsA = worldBoundsMap.get(a.id)!;
        const boundsB = worldBoundsMap.get(b.id)!;
        return getBoundsArea(boundsA) - getBoundsArea(boundsB);
    });

    const childrenMap = new Map<string, ParsedComponent[]>();
    const addChild = (parentId: string, child: ParsedComponent) => {
        if (!childrenMap.has(parentId)) {
            childrenMap.set(parentId, []);
        }
        childrenMap.get(parentId)!.push(child);
    };

    flattened.forEach((component) => {
        if (component.id === flattenedRoot.id) {
            return;
        }

        const compBounds = worldBoundsMap.get(component.id)!;
        let assignedParent = flattenedRoot.id;

        for (const container of containers) {
            if (container.id === component.id) continue;
            const containerBounds = worldBoundsMap.get(container.id)!;

            // Special handling for TabPage -> TabbedPane relationship
            // TabPages should strictly belong to TabbedPanes
            if (component.type === 'TabPage' && container.type !== 'TabbedPane') {
                continue;
            }

            const isTabPair = component.type === 'TabPage' && container.type === 'TabbedPane';

            // Skip if component is larger than container (optimization)
            // For TabPage -> TabbedPane, skip size check as TabPages might match parent size exactly or vary slightly
            if (!isTabPair) {
                 if (getBoundsArea(compBounds) > getBoundsArea(containerBounds)) continue;
            }

            // Use increased tolerance for TabPage components to ensure they snap to their parent TabbedPane
            // 50px tolerance handles cases where TabPage bounds are offset by header height or legacy positioning
            const tolerance = isTabPair ? 50 : undefined;

            if (isInsideBounds(compBounds, containerBounds, tolerance)) {
                assignedParent = container.id;
                break;
            }
        }

        addChild(assignedParent, component);
    });

    const attachChildren = (component: ParsedComponent) => {
        const children = childrenMap.get(component.id) || [];

        children.sort((a, b) => {
            const boundsA = worldBoundsMap.get(a.id)!;
            const boundsB = worldBoundsMap.get(b.id)!;

            if (Math.abs(boundsA.y - boundsB.y) > 10) {
                return boundsA.y - boundsB.y;
            }
            return boundsA.x - boundsB.x;
        });

        component.children = children;

        const parentWorldBounds = worldBoundsMap.get(component.id)!;

        children.forEach((child) => {
            const childWorldBounds = worldBoundsMap.get(child.id)!;
            child.bounds = {
                x: childWorldBounds.x - parentWorldBounds.x,
                y: childWorldBounds.y - parentWorldBounds.y,
                width: childWorldBounds.width,
                height: childWorldBounds.height,
            };

            // For TabPage components, children were preserved during flattening
            // so we need to recursively fix their bounds but NOT reorganize them
            if (child.type === 'TabPage' && child.children) {
                const fixTabPageChildBounds = (tabPageChild: ParsedComponent, tabPageWorldBounds: ComponentBounds) => {
                    // Child bounds in TabPage are already relative, but we need to ensure
                    // they're relative to the world bounds of the TabPage
                    if (tabPageChild.children) {
                        tabPageChild.children.forEach(grandchild => {
                            // Recursively fix bounds for nested children
                            fixTabPageChildBounds(grandchild, tabPageWorldBounds);
                        });
                    }
                };
                child.children.forEach(tabPageChild => fixTabPageChildBounds(tabPageChild, childWorldBounds));
            } else {
                // For non-TabPage components, continue normal reorganization
                attachChildren(child);
            }
        });
    };

    attachChildren(flattenedRoot);
    return flattenedRoot;
};

