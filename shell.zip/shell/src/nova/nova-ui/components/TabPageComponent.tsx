/* eslint-disable */
/**
 * TabPage Component
 * Renders EBML JCSTabPage components (individual tab page within TabbedPane)
 * Simply renders children without wrapper - the parent TabbedPane handles the tab structure
 */

import React from 'react';
import type { NovaComponentProps } from './types';

export const TabPageComponent: React.FC<NovaComponentProps> = ({
    children
}) => {
    // TabPage just renders its children - the TabbedPane parent handles positioning
    // PreviewRenderer will pass the rendered children as the children prop
    return <>{children}</>;
};
