/* eslint-disable */
/**
 * Radio Component
 * Renders EBML RadioButton components as Radio (for use inside RadioGroup)
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Radio } from 'seker-ui';
import type { NovaComponentProps } from './types';

export const RadioComponent: React.FC<NovaComponentProps> = ({
    id,
    text,
    label,
    value,
    helperText,
    enabled,
    useAbsolutePositioning = false,
    ...props
}) => {
    // Radio is typically used inside RadioGroup, so it doesn't need GridItem wrapper
    return (
        <Radio
            label={text || label || ''}
            value={value || id || ''}
            helperText={helperText}
            disabled={enabled === 'false'}
            {...props}
        />
    );
};
