/* eslint-disable */
/**
 * Component Registry Types
 * Types for the component registry system
 */

import type React from 'react';
import type { ComponentBounds, PageDefinition, ParsedComponent } from '../types/ebml.types';
import type { DesignComponent } from '../../nova-studio/context/DesignerContext';
 
/**
 * Common props passed to all registered components
 */
export interface NovaComponentProps {
    id: string;
    name?: string;
    type?: string;
    label?: string;
    text?: string;
    value?: any;
    placeholder?: string;
    enabled?: string | boolean;
    bounds?: ComponentBounds;
    parentBounds?: ComponentBounds;
    useAbsolutePositioning?: boolean;
    xs?: number;
    children?: React.ReactNode;
    designComponent?: DesignComponent;
    // Legacy or specific props
    component?: ParsedComponent; 
    componentKey?: string;
    allPages?: PageDefinition[];
    [key: string]: any;
}

export type BaseComponentProps = NovaComponentProps;

/**
 * Component renderer function type
 */
export type ComponentRenderer = (props: NovaComponentProps) => React.ReactNode;

/**
 * Component registry entry
 */
export interface ComponentRegistryEntry {
    type: string;
    renderer: ComponentRenderer;
}

/**
 * Component registry type
 */
export type ComponentRegistry = Map<string, ComponentRenderer>;
