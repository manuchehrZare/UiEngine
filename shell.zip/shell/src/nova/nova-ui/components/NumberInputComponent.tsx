/* eslint-disable */
/**
 * NumberInput Component Wrapper
 * Wraps the lib NumberInput component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { NumberInput } from 'seker-ui';
import type { NovaComponentProps } from './types';

export const NumberInputComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    ...props
}) => {
    // Ensure string properties are never undefined to prevent errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `numberinput_${Math.random().toString(36).substring(2, 11)}`;

    const safeProps = {
        ...props,
        label: label || name || 'Number',
        name: safeName,
        value: value !== undefined ? value : null, // NumberInput expects null for empty, not undefined
    };

    return <NumberInput {...safeProps} />;
};
