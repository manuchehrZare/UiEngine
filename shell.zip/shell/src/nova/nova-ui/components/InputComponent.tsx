/* eslint-disable */
/**
 * Input Component Wrapper
 * Wraps the lib Input component to handle EBML property conversions
 * and ensure all required properties have safe defaults
 */

import React from 'react';
import { Input } from 'seker-ui';
import type { NovaComponentProps } from './types';

export const InputComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    name,
    text,
    value,
    ...props
}) => {
    // Ensure string properties are never undefined to prevent .substring() errors
    const safeProps = {
        ...props,
        label: label || name || '',
        name: name || id || '',
        value: value !== undefined ? value : (text !== undefined ? text : ''),
    };

    return <Input {...safeProps} />;
};
