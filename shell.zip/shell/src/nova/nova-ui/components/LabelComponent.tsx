/* eslint-disable */
/**
 * Label Component
 * Renders EBML Label components for displaying text content
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Label, GridItem, Typography } from 'seker-ui';
import type { NovaComponentProps } from './types';
import { boundsToGridSize } from '../utils/positioningUtils';

export const LabelComponent: React.FC<NovaComponentProps> = ({
    text,
    label,
    required,
    color,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    xs,
    ...props
}) => {
    const containerWidth = parentBounds?.width || 960;
    const displayText = text || label || '';

    const labelContent = (
        <Typography variant="h6" gutterBottom
            sx={{
                color: color,
                width: 'auto',
                height: 'auto',
                display: 'flex',
                alignItems: 'center',
                ...props.sx,
            }}
        >
            {displayText}
        </Typography>
    );

    if (useAbsolutePositioning) {
        return labelContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {labelContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
        // xs={resolvedXs}
        // sx={{ minHeight: gridSize.minHeight }}
        >
            {labelContent}
        </GridItem>
    );
};
