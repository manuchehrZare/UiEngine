/* eslint-disable */
/**
 * Checkbox Component Wrapper
 * Wraps the lib Checkbox component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { Checkbox } from 'seker-ui';
import type { NovaComponentProps } from './types';

export const CheckboxComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    checked,
    ...props
}) => {
    // Ensure string properties are never undefined to prevent .substring() errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `checkbox_${Math.random().toString(36).substring(2, 11)}`;

    const safeProps = {
        ...props,
        label: label || name || 'Checkbox',
        name: safeName,
        checked: checked !== undefined ? checked : false,
    };

    return <Checkbox {...safeProps} />;
};
