/* eslint-disable */
/**
 * Page Component
 * Renders EBML Page components (root container)
 * Supports both absolute positioning (Windows Forms matching) and responsive grid layout
 */

import React from 'react';
import { Box, Grid, GridItem, Paper } from 'seker-ui';
import type { NovaComponentProps } from './types';
import { groupComponentsByRow, calculateRowGridSizes, normalizeLayout, type LayoutComponent } from '../utils/positioningUtils';
import { mapComponent } from '../mapper/component-mapper';
import { PreviewRenderer } from '../../nova-studio/components/PreviewRenderer';


export const PageComponent: React.FC<NovaComponentProps> = ({
    id,
    bounds,
    pageSize,
    pageWidth: propPageWidth,
    pageHeight: propPageHeight,
    backgroundColor,
    children,
    designComponent,
    component,
    allPages,
    useAbsolutePositioning = false,
    ...props
}) => {
    // Get page dimensions from properties or bounds
    // pageSize can be "width,height" format
    let pageWidth = 1024;
    let pageHeight = 768;

    // Use component structure if available (ParsedComponent or DesignComponent)
    const structuralComponent = normalizeLayout(component || designComponent);
    const actualBounds = bounds || structuralComponent?.bounds;

    if (pageSize) {
        const [w, h] = String(pageSize).split(',').map(Number);
        if (w && h) {
            pageWidth = w;
            pageHeight = h;
        }
    } else if (propPageWidth && propPageHeight) {
        pageWidth = Number(propPageWidth);
        pageHeight = Number(propPageHeight);
    } else if (actualBounds && actualBounds.width > 0 && actualBounds.height > 0) {
        pageWidth = actualBounds.width;
        pageHeight = actualBounds.height;
    }

    const pageBounds = actualBounds
        ? { ...actualBounds, width: pageWidth, height: pageHeight }
        : { x: 0, y: 0, width: pageWidth, height: pageHeight };

    // Special handling for responsive layout to distribute space in rows
    const renderResponsiveChildren = () => {
        if (React.Children.count(children) > 0) {
            return (
                <Grid container={false} spacing={2}>
                    {children}
                </Grid>
            );
        }

        if (!structuralComponent || !structuralComponent.children || structuralComponent.children.length === 0) {
            // If we have React children but no structure, render children directly
            // This happens if we are inside a pure React tree without data backing
            return children;
        }

        // Use normalized structure
        const rows = groupComponentsByRow(structuralComponent.children);

        return (
            <Grid container direction="column" spacing={2}>
                {rows.map((row, rowIndex) => {
                    const rowSizes = calculateRowGridSizes(row, pageBounds.width);

                    return (
                        <GridItem key={`row-${rowIndex}`} xs={12}>
                            <Grid container spacing={2}>
                                {row.map((childLayout: LayoutComponent) => {
                                    const placement = rowSizes.get(childLayout);
                                    const xs = placement?.xs;
                                    const gap = placement?.gap ?? 0;
                                    const child = childLayout.original;

                                    const elements: React.ReactNode[] = [];

                                    if (gap > 0) {
                                        elements.push(
                                            <GridItem
                                                key={`${child.id}-gap-${rowIndex}`}
                                                xs={gap}
                                                sx={{ p: 0, m: 0, visibility: 'hidden' }}
                                            />,
                                        );
                                    }

                                    if (designComponent) {
                                        const modifiedChild = {
                                            ...child,
                                            props: xs ? { ...child.props, xs } : child.props,
                                        };
                                        elements.push(<PreviewRenderer key={child.id} component={modifiedChild} />);
                                    } else {
                                        elements.push(
                                            <React.Fragment key={child.id}>
                                                {mapComponent(
                                                    child,
                                                    child.id,
                                                    false,
                                                    allPages,
                                                    pageBounds,
                                                    xs ? { xs } : {},
                                                )}
                                            </React.Fragment>,
                                        );
                                    }

                                    return elements;
                                })}
                            </Grid>
                        </GridItem>
                    );
                })}
            </Grid>
        );
    };

    if (useAbsolutePositioning) {
        // Absolute positioning mode - match Windows Forms layout exactly
        return (
            <Paper sx={{ width: '100%', overflow: 'auto' }}>
                <Grid
                    minHeight={pageHeight}
                    height="100%"
                    display="flex"
                    justifyContent="center"
                    alignItems="flex-start"
                >
                    <Box
                        sx={{
                            position: 'relative',
                            width: `${pageWidth}px`,
                            height: `${pageHeight}px`,
                            minHeight: `${pageHeight}px`,
                            backgroundColor: backgroundColor || '#ece9d8',
                            margin: '0 auto',
                        }}
                    >
                        {children}
                    </Box>
                </Grid>
            </Paper>
        );
    }

    // Responsive grid mode
    return (
        <Paper sx={{ width: '100%', p: 2 }}>
            <Grid
                minHeight={pageHeight}
                height="100%"
                display="flex"
                justifyContent="center"
                alignItems="flex-start"
            >
                <Box sx={{ width: '100%' }}>
                    {renderResponsiveChildren()}
                </Box>
            </Grid>
        </Paper>
    );
};
