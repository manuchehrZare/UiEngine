/* eslint-disable */
/**
 * Tab Component Wrapper
 * Wraps the lib Tab component (tab navigation container) to handle EBML properties
 */

import React from 'react';
import { Tab } from 'seker-ui';
import type { NovaComponentProps } from './types';

export const TabComponent: React.FC<NovaComponentProps> = ({
    id,
    name,
    value,
    children,
    variant,
    ...props
}) => {
    const [tabValue, setTabValue] = React.useState(value || 0);

    const handleChange = (newValue: number) => {
        setTabValue(newValue);
    };

    // Tab is the container for TabItem components
    return (
        <Tab
            value={tabValue}
            onChange={handleChange}
            variant={variant || 'scrollable'}
            sx={{ borderBottom: 1, borderColor: 'divider' }}
            {...props}
        >
            {children}
        </Tab>
    );
};
