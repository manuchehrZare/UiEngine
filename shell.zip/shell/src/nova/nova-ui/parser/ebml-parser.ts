/* eslint-disable */
/**
 * EBML Parser
 * Parses EBML bean structure and extracts properties
 */

import type { EbmlBean, EbmlProperty, ComponentBounds, ParsedComponent } from '../types/ebml.types';
import { nestComponentsByBounds } from '../utils/boundsNesting';
import { resolveComponentType } from '../utils/mappings';

/**
 * Parse bounds string (e.g., "15,40,110,20") to ComponentBounds object
 */
export const parseBounds = (boundsText: string): ComponentBounds => {
    const [x, y, width, height] = boundsText.split(',').map(Number);
    return { x, y, width, height };
};

/**
 * Extract properties from EBML Style object
 */
export const extractProperties = (bean: EbmlBean): Record<string, any> => {
    const properties: Record<string, any> = {};

    if (!bean.Style?.P) {
        return properties;
    }

    bean.Style.P.forEach((prop: EbmlProperty) => {
         if (prop.Name) {
      // For properties with Columns (like adapterInfo), use Columns instead of Text
      if (prop.Columns) {
                properties[prop.Name] = prop.Columns;
      } else if (prop.Text !== undefined) {
                properties[prop.Name] = prop.Text;
      }
    }
    });

    return properties;
};

/**
 * Get property value by name
 */
export const getProperty = (bean: EbmlBean, propertyName: string): string | undefined => {
    if (!bean.Style?.P) {
        return undefined;
    }

    const prop = bean.Style.P.find((p: EbmlProperty) => p.Name === propertyName);
    return prop?.Text;
};

/**
 * Get bounds property
 */
export const getBounds = (bean: EbmlBean): ComponentBounds | null => {
    const boundsText = getProperty(bean, 'bounds');
    if (!boundsText) {
        return null;
    }
    return parseBounds(boundsText);
};

/**
 * Parse EBML bean to ParsedComponent
 */
export const parseBean = (bean: EbmlBean): ParsedComponent => {
    const properties = extractProperties(bean);
    const bounds = getBounds(bean) || { x: 0, y: 0, width: 100, height: 20 };
    const type = resolveComponentType(bean.Class);

    // Preserve original class name for Unknown components so we can display it
    if (type === 'Unknown') {
        properties.originalClassName = bean.Class;
    }

    const component: ParsedComponent = {
        id: bean.Id,
        type,
        bounds,
        properties,
    };

    // Recursively parse children
    if (bean.SubBean && bean.SubBean.length > 0) {
        component.children = bean.SubBean.map(parseBean);
    }

    return component;
};

/**
 * Parse EBML bean and reorganize by bounds containment
 */
export const parseBeanWithNesting = (bean: EbmlBean): ParsedComponent => {
    // First parse normally
    const parsed = parseBean(bean);
    // Then reconstruct based on geometry
    // We pass a copy to avoid mutating the original parse result if needed, but here we want the transformation
     const deepCopy = JSON.parse(JSON.stringify(parsed));
     return nestComponentsByBounds(deepCopy);
  // return deepCopy;
};

/**
 * Parse page size property
 */
export const parsePageSize = (pageSizeText: string): { width: number; height: number } => {
    const [width, height] = pageSizeText.split(',').map(Number);
    return { width, height };
};

/**
 * Get all beans as flat array (depth-first traversal)
 */
export const flattenBeans = (bean: EbmlBean): EbmlBean[] => {
    const result: EbmlBean[] = [bean];

    if (bean.SubBean && bean.SubBean.length > 0) {
        bean.SubBean.forEach((subBean) => {
            result.push(...flattenBeans(subBean));
        });
    }

    return result;
};

/**
 * Find bean by ID
 */
export const findBeanById = (rootBean: EbmlBean, id: string): EbmlBean | null => {
    if (rootBean.Id === id) {
        return rootBean;
    }

    if (rootBean.SubBean && rootBean.SubBean.length > 0) {
        for (const subBean of rootBean.SubBean) {
            const found = findBeanById(subBean, id);
            if (found) {
                return found;
            }
        }
    }

    return null;
};
