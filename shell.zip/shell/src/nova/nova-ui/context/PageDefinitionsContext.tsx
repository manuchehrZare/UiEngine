/* eslint-disable */
import React, { createContext, useContext, useState, useEffect } from 'react';
import type { PageDefinition } from '../types/ebml.types';

interface PageDefinitionsContextType {
    pages: PageDefinition[];
    loading: boolean;
    error: Error | null;
}

const PageDefinitionsContext = createContext<PageDefinitionsContextType | undefined>(undefined);

export const usePageDefinitionsContext = () => {
    const context = useContext(PageDefinitionsContext);
    if (!context) {
        throw new Error('usePageDefinitionsContext must be used within a PageDefinitionsProvider');
    }
    return context;
};

export const useOptionalPageDefinitionsContext = () => {
    return useContext(PageDefinitionsContext);
};

export const PageDefinitionsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [pages, setPages] = useState<PageDefinition[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<Error | null>(null);

    useEffect(() => {
        const loadDefinitions = async () => {
            try {
                setLoading(true);
                // Load the ui-definition.json file
                const response = await fetch('/src/assets/docs/ui-definition.json');
                if (!response.ok) {
                    throw new Error('Failed to load page definitions');
                }
                const data = await response.json();
                setPages(data);
                setError(null);
            } catch (err) {
                console.error('Error loading page definitions:', err);
                setError(err instanceof Error ? err : new Error('Unknown error'));
            } finally {
                setLoading(false);
            }
        };

        loadDefinitions();
    }, []);

    return (
        <PageDefinitionsContext.Provider value={{ pages, loading, error }}>
            {children}
        </PageDefinitionsContext.Provider>
    );
};

