/* eslint-disable */
import React, { useState, useMemo, useEffect } from 'react';
import { Box, Paper, Typography, Grid, GridItem, Button } from 'seker-ui';
import { TextField } from '@mui/material';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import type { PageDefinition } from './types/ebml.types';
import type { NovaUiSchema } from './types/nova-schema.types';
import { DesignerProvider, useDesigner } from '../nova-studio/context/DesignerContext';
import { DesignArea } from '../nova-studio/components/DesignArea';
import { useNavigate } from 'react-router-dom';
import { mapEbmlContentToNovaSchema } from './nova-schema-mapper';
import { PageDefinitionsProvider, usePageDefinitionsContext } from './context/PageDefinitionsContext';


const EditInDesignerButton: React.FC<{ novaSchema: NovaUiSchema | null }> = ({ novaSchema }) => {
    const navigate = useNavigate();

    const handleOpenDesigner = () => {
        if (!novaSchema) return;
        navigate('/nova-studio', {
            state: {
                importedDesign: JSON.stringify(novaSchema),
            },
        });
    };

    return (
        <Button
            variant="contained"
            color="primary"
            size="small"
            disabled={!novaSchema}
            onClick={handleOpenDesigner}
            text="Edit in Designer"
            sx={{ mr: 1 }}
        />
    );
};

const DynamicRenderer: React.FC<{ novaSchema: NovaUiSchema }> = ({ novaSchema }) => {
    const { importDesign, setMode } = useDesigner();

    useEffect(() => {
        if (novaSchema) {
            // Import the complete NovaUiSchema (includes UI, events, rules, variables)
            importDesign(JSON.stringify(novaSchema));
            setMode('preview');
        }
    }, [novaSchema, importDesign, setMode]);

    return (
        <Box sx={{ height: '100%', overflow: 'hidden', bgcolor: '#f0f2f5' }}>
            <DesignArea />
        </Box>
    );
};

const GenericUiContent: React.FC = () => {
    const { pages, loading, error } = usePageDefinitionsContext();
    const [selectedPage, setSelectedPage] = useState<PageDefinition | null>(null);
    const [novaSchema, setNovaSchema] = useState<NovaUiSchema | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const handlePageSelect = (page: PageDefinition) => {
        setSelectedPage(page);
        try {
            // Use the new NovaUiSchema converter that includes UI, events, rules, and variables
            const convertedSchema = mapEbmlContentToNovaSchema(page.EbmlContent);
            setNovaSchema(convertedSchema);
        } catch (err) {
            console.error('Failed to convert page:', err);
            setNovaSchema(null);
        }
    };

    const filteredPages = useMemo(() => {
        const onlyPages = pages.filter((p) => p.Type === 'page');
        if (!searchTerm) return onlyPages;
        const term = searchTerm.toLowerCase();
        return onlyPages.filter(
            (p) =>
                p.MenuName?.toLowerCase().includes(term) ||
                p.ScreenCode?.toLowerCase().includes(term)
            // p.Name?.toLowerCase().includes(term)
            ,
        );
    }, [pages, searchTerm]);

    if (loading) {
        return <Box sx={{ p: 3 }}>Loading definitions...</Box>;
    }

    if (error) {
        return <Box sx={{ p: 3, color: 'error.main' }}>Error: {error.message}</Box>;
    }

    return (
        <DndProvider backend={HTML5Backend}>
            <DesignerProvider>
                <Grid container spacing={2} sx={{ height: 'calc(100vh - 64px)', overflow: 'hidden' }}>
                    <GridItem xs={12} md={2} sx={{ height: '100%', borderRight: '1px solid #eee', overflow: 'auto' }}>
                        <Typography variant="h6" gutterBottom>
                            NOVA UI Explorer
                        </Typography>

                        <Box sx={{ mb: 2 }}>
                            <TextField
                                fullWidth
                                placeholder="Search pages..."
                                value={searchTerm}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
                                size="small"
                            />
                        </Box>

                        <Box>
                            {filteredPages.map((page) => (
                                <Box
                                    key={page.Name}
                                    onClick={() => handlePageSelect(page)}
                                    sx={{
                                        p: 1.5,
                                        mb: 1,
                                        cursor: 'pointer',
                                        borderRadius: 1,
                                        bgcolor: selectedPage?.Name === page.Name ? 'action.selected' : 'transparent',
                                        '&:hover': {
                                            bgcolor: 'action.hover',
                                        },
                                        border: '1px solid',
                                        borderColor: selectedPage?.Name === page.Name ? 'primary.main' : 'divider',
                                    }}
                                >
                                    <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
                                        {page.MenuName || page.Name}
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary" display="block">
                                        Code: {page.ScreenCode} | Type: {page.Type}
                                    </Typography>
                                </Box>
                            ))}
                            {filteredPages.length === 0 && (
                                <Typography variant="body2" color="text.secondary" align="center">
                                    No pages found
                                </Typography>
                            )}
                        </Box>
                    </GridItem>

                    <GridItem xs={12} md={10} sx={{ height: '100%', p: 0, display: 'flex', flexDirection: 'column' }}>
                        {selectedPage ? (
                            <>
                                <Paper sx={{ p: 2, borderRadius: 0, borderBottom: '1px solid #eee' }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <Box>
                                            <Typography variant="h5">{selectedPage.MenuName}</Typography>
                                            <Typography variant="body2" color="text.secondary">
                                                {selectedPage.ScreenCode} - {selectedPage.ModuleName}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                            <EditInDesignerButton novaSchema={novaSchema} />
                                            <Button variant="outlined" size="small" onClick={() => {
                                                console.log("Selected Page EbmlContent:", selectedPage.EbmlContent);
                                                console.log('Current NovaSchema:', novaSchema);
                                            }} text="Log Schema" />
                                        </Box>
                                    </Box>
                                </Paper>

                                <Box sx={{ flexGrow: 1, overflow: 'hidden', position: 'relative', bgcolor: '#f5f5f5' }}>
                                    {novaSchema ? (
                                        <DynamicRenderer novaSchema={novaSchema} />
                                    ) : (
                                        <Box sx={{ p: 3, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                            <Typography color="error">Failed to convert schema or empty definition</Typography>
                                        </Box>
                                    )}
                                </Box>
                            </>
                        ) : (
                            <Box
                                sx={{
                                    height: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    bgcolor: '#fafafa',
                                }}
                            >
                                <Typography variant="h6" color="text.secondary">
                                    Select a page from the sidebar to render
                                </Typography>
                            </Box>
                        )}
                    </GridItem>
                </Grid>
            </DesignerProvider>
        </DndProvider>
    );
};

const GenericUi: React.FC = () => {
    return (
        <PageDefinitionsProvider>
            <GenericUiContent />
        </PageDefinitionsProvider>
    );
};

export default GenericUi;
