/* eslint-disable */
import { createSchema, type PropertySchema } from './schema';
import { commonProps } from './common';

const gridProps: PropertySchema[] = [
    ...commonProps,
    { name: 'container', type: 'boolean', label: 'Container', group: 'Layout', defaultValue: false },
    { name: 'item', type: 'boolean', label: 'Item', group: 'Layout', defaultValue: false },
    { name: 'spacing', type: 'number', label: 'Spacing', group: 'Layout', defaultValue: 0 },
    { name: 'xs', type: 'select', label: 'XS (Mobile)', group: 'Layout', options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 'auto', true, false] },
    { name: 'sm', type: 'select', label: 'SM (Tablet)', group: 'Layout', options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 'auto', true, false] },
    { name: 'md', type: 'select', label: 'MD (Desktop)', group: 'Layout', options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 'auto', true, false] },
    { name: 'lg', type: 'select', label: 'LG (Large)', group: 'Layout', options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 'auto', true, false] },
    { name: 'xl', type: 'select', label: 'XL (XLarge)', group: 'Layout', options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 'auto', true, false] },
    { name: 'direction', type: 'select', label: 'Direction', group: 'Layout', options: ['row', 'row-reverse', 'column', 'column-reverse'] },
    { name: 'justifyContent', type: 'select', label: 'Justify Content', group: 'Layout', options: ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'] },
    { name: 'alignItems', type: 'select', label: 'Align Items', group: 'Layout', options: ['flex-start', 'center', 'flex-end', 'stretch', 'baseline'] },
    { name: 'wrap', type: 'select', label: 'Wrap', group: 'Layout', options: ['nowrap', 'wrap', 'wrap-reverse'] },
    { name: 'spacingType', type: 'select', label: 'Spacing Type', group: 'Layout', options: ['common', 'button', 'form', 'joinedForm'] },
    { name: 'sizeType', type: 'select', label: 'Size Type', group: 'Layout', options: ['common', 'form'] },
];

export const LayoutSchemas = {
    Grid: createSchema('Grid', 'Layout', gridProps, { container: true, spacing: 2 }),
    GridItem: createSchema('GridItem', 'Layout', gridProps, { item: true, xs: 12, md: 6 }),
    Box: createSchema('Box', 'Layout', [
        ...commonProps,
        { name: 'component', type: 'string', label: 'HTML Component', defaultValue: 'div' },
        { name: 'clone', type: 'boolean', label: 'Clone' },
    ], { sx: { p: 2, border: '1px dashed grey' } }),

    Container: createSchema('Container', 'Layout', [
        ...commonProps,
        { name: 'maxWidth', type: 'select', label: 'Max Width', options: ['xs', 'sm', 'md', 'lg', 'xl', false] },
        { name: 'fixed', type: 'boolean', label: 'Fixed' },
        { name: 'disableGutters', type: 'boolean', label: 'Disable Gutters' },
    ]),

    Paper: createSchema('Paper', 'Layout', [
        ...commonProps,
        { name: 'elevation', type: 'number', label: 'Elevation', defaultValue: 1 },
        { name: 'variant', type: 'select', label: 'Variant', options: ['elevation', 'outlined'] },
        { name: 'square', type: 'boolean', label: 'Square' },
    ]),

    Divider: createSchema('Divider', 'Layout', [
        ...commonProps,
        { name: 'variant', type: 'select', label: 'Variant', options: ['fullWidth', 'inset', 'middle'] },
        { name: 'orientation', type: 'select', label: 'Orientation', options: ['horizontal', 'vertical'] },
        { name: 'textAlign', type: 'select', label: 'Text Align', options: ['center', 'left', 'right'] },
        { name: 'flexItem', type: 'boolean', label: 'Flex Item' },
        { name: 'children', type: 'string', label: 'Text Content' }
    ]),

    Break: createSchema('Break', 'Layout', [
        ...commonProps,
        { name: 'num', type: 'number', label: 'Number of Breaks', defaultValue: 1 }
    ]),
};
