/* eslint-disable */
export interface PropertySchema {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'select' | 'json' | 'array' | 'object';
    label?: string;
    options?: (string | number | { label: string; value: any })[];
    defaultValue?: any;
    description?: string;
    group?: string; // For grouping properties in the UI
    required?: boolean;
}

export interface ComponentSchema {
    name: string;
    category: string;
    properties: PropertySchema[];
    defaultProps?: Record<string, any>;
}

export const BASE_PROPERTIES: PropertySchema[] = [
    { name: 'id', type: 'string', label: 'ID', group: 'General' },
    { name: 'className', type: 'string', label: 'Class Name', group: 'Style' },
    { name: 'sx', type: 'json', label: 'SX (MUI Style)', group: 'Style', defaultValue: {} },
];

// Helper to create simple schema
export const createSchema = (
    name: string, 
    category: string, 
    specificProps: PropertySchema[] = [],
    defaultProps: Record<string, any> = {}
): ComponentSchema => ({
    name,
    category,
    properties: [...BASE_PROPERTIES, ...specificProps],
    defaultProps
});

