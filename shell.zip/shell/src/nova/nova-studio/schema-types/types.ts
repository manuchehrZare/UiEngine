export type { PropertySchema, ComponentSchema } from './schema';
