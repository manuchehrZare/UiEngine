/* eslint-disable */
import { createSchema } from './schema';
import { commonFormProps, commonProps } from './common';

export const FormSchemas = {
    Button: createSchema('Button', 'Form', [
        ...commonProps,
        { name: 'children', type: 'string', label: 'Label', group: 'Content' },
        { name: 'variant', type: 'select', label: 'Variant', options: ['text', 'contained', 'outlined'] },
        { name: 'color', type: 'select', label: 'Color', options: ['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning'] },
        { name: 'size', type: 'select', label: 'Size', options: ['small', 'medium', 'large'] },
        { name: 'fullWidth', type: 'boolean', label: 'Full Width' },
        { name: 'disabled', type: 'boolean', label: 'Disabled' },
        { name: 'type', type: 'select', label: 'Type', options: ['button', 'submit', 'reset'] },
        { name: 'loading', type: 'boolean', label: 'Loading' },
        { name: 'text', type: 'string', label: 'Text' },
        { name: 'href', type: 'string', label: 'Href' },
        { name: 'icon', type: 'string', label: 'Icon Name' }, // Simplified for string input
        { name: 'rounded', type: 'boolean', label: 'Rounded' },
    ], { children: 'Button', variant: 'contained', color: 'primary' }),
    
    ButtonGroup: createSchema('ButtonGroup', 'Form', [
        ...commonProps,
        { name: 'variant', type: 'select', label: 'Variant', options: ['text', 'contained', 'outlined'] },
        { name: 'color', type: 'select', label: 'Color', options: ['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning'] },
        { name: 'orientation', type: 'select', label: 'Orientation', options: ['horizontal', 'vertical'] },
        { name: 'size', type: 'select', label: 'Size', options: ['small', 'medium', 'large'] },
        { name: 'fullWidth', type: 'boolean', label: 'Full Width' },
        { name: 'disabled', type: 'boolean', label: 'Disabled' },
    ]),

    Input: createSchema('Input', 'Form', [
        ...commonFormProps,
        { name: 'type', type: 'select', label: 'Type', options: ['text', 'password', 'email', 'number', 'tel', 'url', 'search', 'file', 'hidden'] },
        { name: 'multiline', type: 'boolean', label: 'Multiline' },
        { name: 'rows', type: 'number', label: 'Rows' },
        { name: 'minRows', type: 'number', label: 'Min Rows' },
        { name: 'maxRows', type: 'number', label: 'Max Rows' },
        { name: 'maxLength', type: 'number', label: 'Max Length' },
        { name: 'minLength', type: 'number', label: 'Min Length' },
        { name: 'passwordVisibility', type: 'boolean', label: 'Password Visibility' },
        { name: 'mask', type: 'string', label: 'Mask' },
        { name: 'maskChar', type: 'string', label: 'Mask Char' },
        { name: 'capslockDetector', type: 'boolean', label: 'Capslock Detector' },
    ]),

    NumberInput: createSchema('NumberInput', 'Form', [
        ...commonFormProps,
        { name: 'min', type: 'number', label: 'Min' },
        { name: 'max', type: 'number', label: 'Max' },
        { name: 'step', type: 'number', label: 'Step' },
        { name: 'thousandSeparator', type: 'string', label: 'Thousand Separator' },
        { name: 'decimalSeparator', type: 'string', label: 'Decimal Separator' },
        { name: 'allowNegative', type: 'boolean', label: 'Allow Negative' },
        { name: 'fixedDecimalScale', type: 'boolean', label: 'Fixed Decimal Scale' },
    ]),

    Checkbox: createSchema('Checkbox', 'Form', [
        ...commonFormProps, // Checkbox usually extends common field props in this lib
        { name: 'checked', type: 'boolean', label: 'Checked' },
        { name: 'color', type: 'select', label: 'Color', options: ['primary', 'secondary', 'success', 'error', 'info', 'warning', 'default'] },
        { name: 'indeterminate', type: 'boolean', label: 'Indeterminate' },
    ]),

    Radio: createSchema('Radio', 'Form', [
        { name: 'value', type: 'string', label: 'Value', required: true },
        { name: 'label', type: 'string', label: 'Label' },
        { name: 'disabled', type: 'boolean', label: 'Disabled' },
        { name: 'color', type: 'select', label: 'Color', options: ['primary', 'secondary', 'success', 'error', 'info', 'warning', 'default'] },
        { name: 'size', type: 'select', label: 'Size', options: ['small', 'medium'] },
    ]),

    RadioGroup: createSchema('RadioGroup', 'Form', [
        ...commonFormProps,
        { name: 'row', type: 'boolean', label: 'Row', defaultValue: true },
    ]),

    Select: createSchema('Select', 'Form', [
        ...commonFormProps,
        { name: 'multiple', type: 'boolean', label: 'Multiple' },
        { name: 'native', type: 'boolean', label: 'Native' },
        { name: 'options', type: 'json', label: 'Options (JSON)', defaultValue: [] },
    ]),

    Switch: createSchema('Switch', 'Form', [
        ...commonFormProps,
        { name: 'checked', type: 'boolean', label: 'Checked' },
        { name: 'color', type: 'select', label: 'Color', options: ['primary', 'secondary', 'success', 'error', 'info', 'warning', 'default'] },
        { name: 'edge', type: 'select', label: 'Edge', options: ['start', 'end', false] },
    ]),

    DatePicker: createSchema('DatePicker', 'Form', [
        ...commonFormProps,
        { name: 'format', type: 'string', label: 'Format' },
        { name: 'views', type: 'array', label: 'Views' },
        { name: 'disableFuture', type: 'boolean', label: 'Disable Future' },
        { name: 'disablePast', type: 'boolean', label: 'Disable Past' },
    ]),

    DateTimePicker: createSchema('DateTimePicker', 'Form', [
        ...commonFormProps,
        { name: 'format', type: 'string', label: 'Format' },
        { name: 'ampm', type: 'boolean', label: 'AM/PM' },
        { name: 'disableFuture', type: 'boolean', label: 'Disable Future' },
        { name: 'disablePast', type: 'boolean', label: 'Disable Past' },
    ]),

    TimePicker: createSchema('TimePicker', 'Form', [
        ...commonFormProps,
        { name: 'ampm', type: 'boolean', label: 'AM/PM' },
        { name: 'disableFuture', type: 'boolean', label: 'Disable Future' },
        { name: 'disablePast', type: 'boolean', label: 'Disable Past' },
    ]),

    Autocomplete: createSchema('Autocomplete', 'Form', [
        ...commonFormProps,
        { name: 'multiple', type: 'boolean', label: 'Multiple' },
        { name: 'freeSolo', type: 'boolean', label: 'Free Solo' },
        { name: 'options', type: 'json', label: 'Options (JSON)', defaultValue: [] },
        { name: 'loading', type: 'boolean', label: 'Loading' },
        { name: 'groupBy', type: 'string', label: 'Group By (Property Name)' },
    ]),

    RangeInput: createSchema('RangeInput', 'Form', [
        ...commonFormProps,
        { name: 'min', type: 'number', label: 'Min' },
        { name: 'max', type: 'number', label: 'Max' },
        { name: 'step', type: 'number', label: 'Step' },
        { name: 'marks', type: 'boolean', label: 'Marks' },
        { name: 'valueLabelDisplay', type: 'select', label: 'Value Label Display', options: ['auto', 'on', 'off'] },
    ]),

    RichEditor: createSchema('RichEditor', 'Form', [
        ...commonFormProps,
        // RichEditor specific props if any, usually just common form props + helperText etc.
    ]),

    Upload: createSchema('Upload', 'Form', [
        ...commonFormProps,
        { name: 'multiple', type: 'boolean', label: 'Multiple' },
        { name: 'accept', type: 'string', label: 'Accept' },
        { name: 'maxSize', type: 'number', label: 'Max Size (Bytes)' },
        { name: 'maxFiles', type: 'number', label: 'Max Files' },
        { name: 'showPreview', type: 'boolean', label: 'Show Preview' },
    ]),

    FileSelector: createSchema('FileSelector', 'Form', [
        ...commonFormProps,
        { name: 'accept', type: 'string', label: 'Accept' },
        { name: 'buttonLabel', type: 'string', label: 'Button Label' },
        { name: 'multiple', type: 'boolean', label: 'Multiple' },
    ]),
};
