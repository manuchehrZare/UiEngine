/* eslint-disable */
import { createSchema, type PropertySchema } from './schema';

const commonFormProps: PropertySchema[] = [
    { name: 'name', type: 'string', label: 'Name', group: 'Form', defaultValue: '' },
    { name: 'label', type: 'string', label: 'Label', group: 'Form' },
];

export const OtherSchemas = {
    CardNumber: createSchema('CardNumber', 'Others', [
        ...commonFormProps,
        { name: 'variant', type: 'select', label: 'Variant', options: ['outlined', 'filled', 'standard'] },
        { name: 'fullWidth', type: 'boolean', label: 'Full Width' },
    ]),

    Currency: createSchema('Currency', 'Others', [
        ...commonFormProps,
        { name: 'currency', type: 'string', label: 'Currency Symbol', defaultValue: '$' },
        { name: 'decimalSeparator', type: 'string', label: 'Decimal Separator' },
        { name: 'thousandSeparator', type: 'string', label: 'Thousand Separator' },
        { name: 'component', type: 'select', label: 'Component Type', options: ['NumberInput', 'NumberFormat'], defaultValue: 'NumberInput' },
    ]),

    IBAN: createSchema('IBAN', 'Others', [
        ...commonFormProps,
        { name: 'input', type: 'boolean', label: 'Input Mode', defaultValue: true },
        { name: 'fullWidth', type: 'boolean', label: 'Full Width' },
    ]),

    PhoneNumber: createSchema('PhoneNumber', 'Others', [
        ...commonFormProps,
        { name: 'variant', type: 'select', label: 'Variant', options: ['outlined', 'filled', 'standard'] },
        { name: 'fullWidth', type: 'boolean', label: 'Full Width' },
        { name: 'defaultCountry', type: 'string', label: 'Default Country' },
    ]),
};

