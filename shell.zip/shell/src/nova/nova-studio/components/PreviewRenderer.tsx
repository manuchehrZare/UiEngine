/* eslint-disable */
import React from 'react';
import { COMPONENT_REGISTRY } from '../utils/componentRegistry';
import { type DesignComponent } from '../context/DesignerContext';

export const PreviewRenderer: React.FC<{ component: DesignComponent }> = ({ component }) => {
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';
    
    const renderChildren = () => {
         return component.children?.map((child) => (
            <PreviewRenderer key={child.id} component={child} />
        ));
    };

    // Pass designComponent only if the component explicitly requires it (e.g. TabbedPane)
    // This prevents React warnings about passing unrecognized props to DOM elements
    const extraProps: Record<string, any> = {};
    if (registryItem?.needsDesignComponent) {
        extraProps.designComponent = component;
    }

    return (
        <ActualComponent {...component.props} {...extraProps}>
            {registryItem?.isContainer ? renderChildren() : component.props.children}
        </ActualComponent>
    );
};

