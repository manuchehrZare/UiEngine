/* eslint-disable */
import React from 'react';
import { useDrop } from 'react-dnd';
import { useForm, FormProvider } from 'react-hook-form';
import { useDesigner } from '../context/DesignerContext';
import { ComponentRenderer } from './ComponentRenderer';
import { Box, Typography, Paper } from '@mui/material';

export const DesignArea: React.FC = () => {
    const { components, addComponent, selectComponent, moveComponent, mode } = useDesigner();
    const methods = useForm(); // Initialize dummy form context for designer

    const [{ isOver }, drop] = useDrop({
        accept: ['COMPONENT', 'COMPONENT_INSTANCE'],
        drop: (item: any, monitor) => {
            if (monitor.didDrop()) return; // Already handled by a child

            if (item.id) {
                // Reordering (Dropped on empty space or root)
                 // If dropped on root area, maybe move to end of root list?
                 moveComponent(item.id, null, 'inside'); // 'root' is not a real ID, logic in Context needs to handle this case or we treat root special
                 // Actually Context `moveComponent` expects a valid hoverId. 
                 // We can't easily "move to root" with current logic if hoverId is required to find parent.
                 // Let's skip "move to root" via D&D for now unless we update context.
            } else {
                // New Component dropped on root
                addComponent(item.type, null);
            }
        },
        collect: (monitor) => ({
            isOver: monitor.isOver({ shallow: true }),
        }),
    });

    const handleBackgroundClick = () => {
        selectComponent(null);
    };

    if (mode === 'preview') {
        // In preview, we just render components without wrappers
        // But ComponentRenderer has the wrapper logic built-in (selection, dnd).
        // Ideally we should have a separate renderer for preview or a prop.
        // For now, we'll just use the same renderer but it might look "edit-y".
        // Let's create a simple Recursive Preview Renderer
        return (
             <Box sx={{ bgcolor: '#f0f2f5', height: '100%', overflow: 'auto' }}>
                 <FormProvider {...methods}>
                    {components.map(comp => <PreviewRenderer key={comp.id} component={comp} />)}
                 </FormProvider>
             </Box>
        );
    }

    return (
        <Box 
            ref={drop} 
            onClick={handleBackgroundClick}
            sx={{ 
                height: '100%', 
                p: 4, 
                backgroundColor: isOver ? '#e3f2fd' : '#f0f2f5',
                overflow: 'auto',
                transition: 'background-color 0.2s'
            }}
        >
            <Paper 
                elevation={0}
                sx={{ 
                    minHeight: '100%', 
                    p: 2,
                    backgroundColor: 'white',
                    border: '1px solid #e0e0e0',
                    backgroundImage: isOver 
                    ? 'radial-gradient(#2196f3 1px, transparent 1px)' 
                    : 'radial-gradient(#e0e0e0 1px, transparent 1px)',
                    backgroundSize: '20px 20px', 

                }}
            >
                <FormProvider {...methods}>
                    {components.length === 0 ? (
                        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '300px', color: 'text.secondary' }}>
                            <Typography>Drag components here to start designing</Typography>
                        </Box>
                    ) : (
                        components.map(comp => (
                            <ComponentRenderer key={comp.id} component={comp} />
                        ))
                    )}
                </FormProvider>
            </Paper>
        </Box>
    );
};

import { COMPONENT_REGISTRY } from '../utils/componentRegistry';

// Simple renderer for Preview mode without D&D/Selection wrappers
const PreviewRenderer: React.FC<{ component: any }> = ({ component }) => {
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';

    const renderChildren = () => {
         return component.children?.map((child: any) => (
            <PreviewRenderer key={child.id} component={child} />
        ));
    };

    // Destructure to exclude 'key' from props spreading
    const { key, ...restProps } = component.props || {};

    return (
        <ActualComponent {...restProps} designComponent={component}>
            {registryItem?.isContainer ? renderChildren() : component.props.children}
        </ActualComponent>
    );
}

