/* eslint-disable */
import React from 'react';
import Editor from '@monaco-editor/react';
import { useDesigner } from '../../context/DesignerContext';

export const CssEditor: React.FC = () => {
    const { cssCode, setCssCode } = useDesigner();

    return (
        <Editor
            height="100%"
            defaultLanguage="css"
            value={cssCode}
            onChange={(value) => setCssCode(value || '')}
            options={{
                minimap: { enabled: false },
            }}
        />
    );
};

