/* eslint-disable */
import React from 'react';
import Editor from '@monaco-editor/react';
import { useDesigner } from '../../context/DesignerContext';

export const JavascriptEditor: React.FC = () => {
    const { jsCode, setJsCode } = useDesigner();

    return (
        <Editor
            height="100%"
            defaultLanguage="javascript"
            value={jsCode}
            onChange={(value) => setJsCode(value || '')}
            options={{
                minimap: { enabled: false },
            }}
        />
    );
};

