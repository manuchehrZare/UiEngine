/* eslint-disable */
import React from 'react';
import Editor from '@monaco-editor/react';
import { useDesigner } from '../../context/DesignerContext';

export const JsonEditor: React.FC = () => {
    const { exportDesign, importDesign } = useDesigner();
    const json = exportDesign();

    const handleChange = (value: string | undefined) => {
        if (value) {
            importDesign(value);
        }
    };

    return (
        <Editor
            height="100%"
            defaultLanguage="json"
            value={json}
            onChange={handleChange}
            options={{
                minimap: { enabled: false },
                formatOnPaste: true,
                formatOnType: true
            }}
        />
    );
};

