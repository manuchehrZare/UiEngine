/* eslint-disable */
import React, { useMemo, useState, useEffect } from 'react';
import { useDesigner } from '../context/DesignerContext';
import { ComponentSchemas, DefaultSchema } from '../schema-types';
import { 
    Box, Typography, TextField, Switch, FormControlLabel, 
    Divider, Select, MenuItem, FormControl, InputLabel, IconButton,
    Accordion, AccordionSummary, AccordionDetails
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import type { ComponentSchema, PropertySchema } from '../schema-types/schema';

const JsonInput: React.FC<{
    label: string;
    value: any;
    onChange: (val: any) => void;
}> = ({ label, value, onChange }) => {
    const [text, setText] = useState('');
    const [error, setError] = useState(false);

    useEffect(() => {
        setText(JSON.stringify(value, null, 2));
    }, [value]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newText = e.target.value;
        setText(newText);
        try {
            const parsed = JSON.parse(newText);
            setError(false);
            onChange(parsed);
        } catch (err) {
            setError(true);
        }
    };

    return (
        <TextField
            fullWidth
            multiline
            rows={4}
            label={label}
            value={text}
            onChange={handleChange}
            error={error}
            helperText={error ? "Invalid JSON" : ""}
            variant="outlined"
            size="small"
            sx={{ mb: 2, fontFamily: 'monospace' }}
            inputProps={{ style: { fontFamily: 'monospace', fontSize: 12 } }}
        />
    );
};

export const PropertiesPanel: React.FC = () => {
    const { selectedComponentId, getComponentById, updateComponentProps, deleteComponent } = useDesigner();
    
    // Only calculate component when ID changes
    const component = useMemo(() => 
        selectedComponentId ? getComponentById(selectedComponentId) : null, 
    [selectedComponentId, getComponentById]);

    // Derive schema directly from component type (memoized)
    const schema: ComponentSchema = useMemo(() => {
        if (!component) return DefaultSchema;
        // @ts-ignore
        return ComponentSchemas[component.type] || DefaultSchema;
    }, [component?.type]);

    const groupedProps = useMemo(() => {
        const groups: Record<string, PropertySchema[]> = {};
        schema.properties.forEach(prop => {
            const group = prop.group || 'General';
            if (!groups[group]) groups[group] = [];
            groups[group].push(prop);
        });
        
        // Ensure General is first if it exists
        const orderedGroups: Record<string, PropertySchema[]> = {};
        if (groups['General']) orderedGroups['General'] = groups['General'];
        Object.keys(groups).sort().forEach(key => {
            if (key !== 'General') orderedGroups[key] = groups[key];
        });
        
        return orderedGroups;
    }, [schema]);

    if (!selectedComponentId || !component) {
        return (
            <Box sx={{ p: 2 }}>
                <Typography color="text.secondary">Select a component to edit properties</Typography>
            </Box>
        );
    }

    const handleChange = (key: string, value: any) => {
        updateComponentProps(component.id, { [key]: value });
    };

    const renderInput = (propSchema: PropertySchema) => {
        const key = propSchema.name;
        const value = component.props[key];
        const currentValue = value ?? propSchema.defaultValue;

        switch (propSchema.type) {
            case 'boolean':
                return (
                    <FormControlLabel
                        key={key}
                        control={
                            <Switch 
                                checked={Boolean(currentValue)} 
                                onChange={(e) => handleChange(key, e.target.checked)} 
                            />
                        }
                        label={propSchema.label || key}
                        sx={{ mb: 1, display: 'block' }}
                    />
                );
            
            case 'select':
                return (
                    <FormControl fullWidth key={key} size="small" sx={{ mb: 2 }}>
                        <InputLabel>{propSchema.label || key}</InputLabel>
                        <Select
                            value={currentValue ?? ''}
                            label={propSchema.label || key}
                            onChange={(e) => handleChange(key, e.target.value)}
                        >
                            {propSchema.options?.map((opt: any) => {
                                const isObject = typeof opt === 'object';
                                const val = isObject ? opt.value : opt;
                                const label = isObject ? opt.label : opt;
                                return (
                                    <MenuItem key={String(val)} value={val}>{label}</MenuItem>
                                );
                            })}
                        </Select>
                    </FormControl>
                );

            case 'number':
                return (
                    <TextField
                        key={key}
                        label={propSchema.label || key}
                        type="number"
                        fullWidth
                        size="small"
                        value={currentValue ?? ''}
                        onChange={(e) => handleChange(key, Number(e.target.value))}
                        sx={{ mb: 2 }}
                    />
                );

            case 'json':
            case 'array':
            case 'object':
                return (
                    <JsonInput 
                        key={key}
                        label={propSchema.label || key}
                        value={currentValue}
                        onChange={(val) => handleChange(key, val)}
                    />
                );

            default: // string
                return (
                    <TextField
                        key={key}
                        label={propSchema.label || key}
                        fullWidth
                        size="small"
                        value={currentValue ?? ''}
                        onChange={(e) => handleChange(key, e.target.value)}
                        sx={{ mb: 2 }}
                    />
                );
        }
    };

    const handleDelete = () => {
        if (component) {
            deleteComponent(component.id);
        }
    };

    return (
        <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderLeft: '1px solid #ddd' }}>
            <Box sx={{ p: 2, borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography variant="h6">{component.type}</Typography>
                <IconButton onClick={handleDelete} color="error" size="small" title="Delete Component">
                    <DeleteIcon />
                </IconButton>
            </Box>

            <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
                {Object.entries(groupedProps).map(([group, props]) => (
                    <Accordion key={group} defaultExpanded disableGutters elevation={0} sx={{ '&:before': { display: 'none' }, borderBottom: '1px solid #eee' }}>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 48, px: 1, backgroundColor: '#f5f5f5' }}>
                            <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>{group}</Typography>
                        </AccordionSummary>
                        <AccordionDetails sx={{ p: 2 }}>
                            {props.map(prop => renderInput(prop))}
                        </AccordionDetails>
                    </Accordion>
                ))}
                
                {/* Fallback for un-grouped props if using DefaultSchema or minimal schema */}
                {Object.keys(groupedProps).length === 0 && (
                    <Typography variant="body2" color="text.secondary">No properties defined in schema.</Typography>
                )}
            </Box>
        </Box>
    );
};
