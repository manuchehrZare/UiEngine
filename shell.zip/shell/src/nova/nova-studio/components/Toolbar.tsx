/* eslint-disable */
import React from 'react';
import { useDrag } from 'react-dnd';
import { COMPONENT_REGISTRY } from '../utils/componentRegistry';
import { Box, Typography, Paper, Grid, GridItem } from 'seker-ui';

const DraggableItem = ({ type, name }: { type: string; name: string }) => {
    const [{ isDragging }, drag] = useDrag(() => ({
        type: 'COMPONENT', // Global type for dnd
        item: { type }, // What we are dragging
        collect: (monitor) => ({
            isDragging: !!monitor.isDragging(),
        }),
    }));

    return (
        <Paper
            ref={drag}
            sx={{
                p: 1,
                mb: 1,
                cursor: 'grab',
                opacity: isDragging ? 0.5 : 1,
                border: '1px solid #ccc',
                '&:hover': {
                    backgroundColor: '#f5f5f5'
                }
            }}
        >
            <Typography variant="body2">{name}</Typography>
        </Paper>
    );
};

export const Toolbar: React.FC = () => {
    const categories = ['Layout', 'Form', 'Set', 'Display', 'Others'];

    return (
        <Box sx={{ p: 2, height: '100%', overflowY: 'auto', borderRight: '1px solid #ddd' }}>
            <Typography variant="h6" gutterBottom>Components</Typography>

            {categories.map(category => {
                const categoryComponents = Object.entries(COMPONENT_REGISTRY)
                    .filter(([_, config]) => config.category === category && config.showInDesignerToolbar);

                if (categoryComponents.length === 0) return null;

                return (
                    <Box key={category} sx={{ mb: 2 }}>
                        <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary', fontWeight: 'bold' }}>
                            {category}
                        </Typography>
                        <Grid container spacing={1}>
                            {categoryComponents.map(([key, config]) => (
                                <GridItem xs={6} key={key}>
                                    <DraggableItem type={key} name={config.name} />
                                </GridItem>
                            ))}
                        </Grid>
                    </Box>
                );
            })}
        </Box>
    );
};

