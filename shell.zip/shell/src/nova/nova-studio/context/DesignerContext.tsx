/* eslint-disable */
import React, { createContext, useContext, useState, useCallback} from 'react';
import type { ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';

export interface DesignComponent {
    id: string;
    type: string; // Key in COMPONENT_REGISTRY
    props: Record<string, any>;
    children: DesignComponent[];
    parentId?: string | null;
}

// Rule, Variable, and Action types
export interface Rule {
    id: string;
    name: string;
    type: 'Simple' | 'Message' | 'Combination';
    // Simple rule fields
    source?: string;
    sourceMethod?: string;
    operator?: 'ISEMPTY' | 'GTE' | 'LTE' | 'NE' | 'LT' | 'GT' | 'EQ';
    target?: string;
    targetType?: 'constant' | 'variable' | 'component';
    targetMethod?: string;
    // Message rule fields
    messageTitle?: string;
    messageType?: 'OK' | 'OK_CANCEL' | 'YES_NO';
    messageAppearance?: 'INFO' | 'WARNING' | 'ERROR';
    messageContent?: string;
    messageContentType?: 'constant' | 'variable';
    // Combination rule fields
    combinationExpression?: string;
}

export interface Variable {
    id: string;
    name: string;
    initialValue?: string;
    valueType: 'string' | 'integer' | 'boolean' | 'object' | 'array';
    description?: string;
    scope?: 'page' | 'session' | 'global';
}

export interface SubAction {
    id: string;
    type: 'BeanAction' | 'RemoteCall' | 'ReferenceCall' | 'VariableSetting' | 'PageCall';
    rule?: string;
    // BeanAction fields
    beanValue?: string;
    method?: string;
    parameters?: Array<{ name: string; value: string; valueType: string; valueMethod?: string }>;
    // RemoteCall fields
    service?: string;
    inputs?: Array<{ bagKey: string; value: string; valueType: string }>;
    outputs?: Array<{ bagKey: string; targetVariable: string; targetType: string }>;
    // ReferenceCall fields
    referencedAction?: string;
    // VariableSetting fields
    variableName?: string;
    variableValue?: string;
    variableValueType?: 'constant' | 'variable' | 'component' | 'rule';
    variableValueMethod?: string;
    // PageCall fields
    pageName?: string;
    pageTitle?: string;
    returnAction?: string;
    pageParameters?: Array<{ variableName: string; value: string; valueMethod: string }>;
}

export interface Action {
    id: string;
    name: string;
    type?: string; // Event type from EBML (e.g., 'LC', 'ButtonClick', etc.)
    ref?: string; // Reference value from EBML events
    rule?: string;
    subActions: SubAction[];
}

interface DesignerContextType {
    components: DesignComponent[]; // Root components
    jsCode: string;
    cssCode: string;
    selectedComponentId: string | null;
    mode: 'design' | 'preview';
    // Rules, Variables, Actions
    rules: Rule[];
    variables: Variable[];
    actions: Action[];
    addRule: (rule: Rule) => void;
    updateRule: (id: string, rule: Partial<Rule>) => void;
    deleteRule: (id: string) => void;
    addVariable: (variable: Variable) => void;
    updateVariable: (id: string, variable: Partial<Variable>) => void;
    deleteVariable: (id: string) => void;
    addAction: (action: Action) => void;
    updateAction: (id: string, action: Partial<Action>) => void;
    deleteAction: (id: string) => void;
    // Original methods
    selectComponent: (id: string | null) => void;
    addComponent: (type: string, parentId?: string | null, index?: number) => void;
    moveComponent: (dragId: string, hoverId: string | null, position: 'before' | 'after' | 'inside') => void;
    updateComponentProps: (id: string, newProps: Record<string, any>) => void;
    deleteComponent: (id: string) => void;
    setMode: (mode: 'design' | 'preview') => void;
    setJsCode: (code: string) => void;
    setCssCode: (code: string) => void;
    exportDesign: () => string;
    importDesign: (json: string) => void;
    clearDesign: () => void;
    getComponentById: (id: string) => DesignComponent | null;
}

const DesignerContext = createContext<DesignerContextType | undefined>(undefined);

export const useDesigner = () => {
    const context = useContext(DesignerContext);
    if (!context) {
        throw new Error('useDesigner must be used within a DesignerProvider');
    }
    return context;
};

// Helper to find component in tree
const findComponent = (components: DesignComponent[], id: string): DesignComponent | null => {
    for (const comp of components) {
        if (comp.id === id) return comp;
        if (comp.children.length > 0) {
            const found = findComponent(comp.children, id);
            if (found) return found;
        }
    }
    return null;
};

// Helper to recursively update
const updateComponentInTree = (components: DesignComponent[], id: string, updater: (comp: DesignComponent) => DesignComponent): DesignComponent[] => {
    return components.map(comp => {
        if (comp.id === id) {
            return updater(comp);
        }
        if (comp.children.length > 0) {
            return { ...comp, children: updateComponentInTree(comp.children, id, updater) };
        }
        return comp;
    });
};

// Helper to recursively remove
const removeComponentFromTree = (components: DesignComponent[], id: string): { cleaned: DesignComponent[], removed: DesignComponent | null } => {
    let removed: DesignComponent | null = null;
    
    const filterRecursive = (list: DesignComponent[]): DesignComponent[] => {
        const result: DesignComponent[] = [];
        for (const comp of list) {
            if (comp.id === id) {
                removed = comp;
                continue;
            }
            const newChildren = filterRecursive(comp.children);
            if (newChildren !== comp.children) {
                result.push({ ...comp, children: newChildren });
            } else {
                result.push(comp);
            }
        }
        return result;
    };

    const cleaned = filterRecursive(components);
    return { cleaned, removed };
};

// Helper to insert
const insertComponentInTree = (components: DesignComponent[], parentId: string | null, component: DesignComponent, index?: number): DesignComponent[] => {
    if (parentId === null) {
        const newComponents = [...components];
        if (typeof index === 'number') {
            newComponents.splice(index, 0, component);
        } else {
            newComponents.push(component);
        }
        return newComponents;
    }

    return components.map(comp => {
        if (comp.id === parentId) {
            const newChildren = [...comp.children];
            if (typeof index === 'number') {
                newChildren.splice(index, 0, component);
            } else {
                newChildren.push(component);
            }
            return { ...comp, children: newChildren };
        }
        if (comp.children.length > 0) {
            return { ...comp, children: insertComponentInTree(comp.children, parentId, component, index) };
        }
        return comp;
    });
};

import { COMPONENT_REGISTRY } from '../utils/componentRegistry';
import { parseEbmlContent } from '../utils/ebmlParser';
import { convertEbmlToCompleteSchema, convertEbmlToNovaSchema, convertNovaToCompleteSchema } from '../../nova-ui/EbmlConverter';
import type { NovaUiSchema } from '../../nova-ui/types/nova-schema.types';

export const DesignerProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [components, setComponents] = useState<DesignComponent[]>([]);
    const [jsCode, setJsCode] = useState<string>('// Custom JS here');
    const [cssCode, setCssCode] = useState<string>('/* Custom CSS here */');
    const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
    const [mode, setMode] = useState<'design' | 'preview'>('design');

    // Rules, Variables, Actions state
    const [rules, setRules] = useState<Rule[]>([]);
    const [variables, setVariables] = useState<Variable[]>([]);
    const [actions, setActions] = useState<Action[]>([]);

    const addComponent = useCallback((type: string, parentId: string | null = null, index?: number) => {
        const registryItem = COMPONENT_REGISTRY[type];
        if (!registryItem) return;

        const newComponent: DesignComponent = {
            id: uuidv4(),
            type,
            props: { 
                ...registryItem.defaultProps,
                // Auto-generate name for form components if not present
                ...((registryItem.category === 'Form' || registryItem.category === 'Others') ? { name: `${type.toLowerCase()}_${uuidv4().slice(0, 8)}` } : {})
            },
            children: [],
            parentId
        };

        setComponents(prev => insertComponentInTree(prev, parentId, newComponent, index));
        setSelectedComponentId(newComponent.id);
    }, []);

    const selectComponent = useCallback((id: string | null) => {
        setSelectedComponentId(id);
    }, []);

    const updateComponentProps = useCallback((id: string, newProps: Record<string, any>) => {
        setComponents(prev => updateComponentInTree(prev, id, (comp) => ({
            ...comp,
            props: { ...comp.props, ...newProps }
        })));
    }, []);

    const deleteComponent = useCallback((id: string) => {
        setComponents(prev => removeComponentFromTree(prev, id).cleaned);
        if (selectedComponentId === id) setSelectedComponentId(null);
    }, [selectedComponentId]);

    // Rule CRUD methods
    const addRule = useCallback((rule: Rule) => {
        setRules(prev => [...prev, rule]);
    }, []);

    const updateRule = useCallback((id: string, updatedRule: Partial<Rule>) => {
        setRules(prev => prev.map(rule => rule.id === id ? { ...rule, ...updatedRule } : rule));
    }, []);

    const deleteRule = useCallback((id: string) => {
        setRules(prev => prev.filter(rule => rule.id !== id));
    }, []);

    // Variable CRUD methods
    const addVariable = useCallback((variable: Variable) => {
        setVariables(prev => [...prev, variable]);
    }, []);

    const updateVariable = useCallback((id: string, updatedVariable: Partial<Variable>) => {
        setVariables(prev => prev.map(variable => variable.id === id ? { ...variable, ...updatedVariable } : variable));
    }, []);

    const deleteVariable = useCallback((id: string) => {
        setVariables(prev => prev.filter(variable => variable.id !== id));
    }, []);

    // Action CRUD methods
    const addAction = useCallback((action: Action) => {
        setActions(prev => [...prev, action]);
    }, []);

    const updateAction = useCallback((id: string, updatedAction: Partial<Action>) => {
        setActions(prev => prev.map(action => action.id === id ? { ...action, ...updatedAction } : action));
    }, []);

    const deleteAction = useCallback((id: string) => {
        setActions(prev => prev.filter(action => action.id !== id));
    }, []);

    const clearDesign = useCallback(() => {
        setComponents([]);
        setJsCode('// Custom JS here');
        setCssCode('/* Custom CSS here */');
        setRules([]);
        setVariables([]);
        setActions([]);
        setSelectedComponentId(null);
    }, []);

    const moveComponent = useCallback((dragId: string, hoverId: string | null, position: 'before' | 'after' | 'inside') => {
        setComponents(prev => {
            // 0. Cycle check (Naive but necessary)
            // We need to check if hoverId is inside dragId's subtree.
            // But we don't have the full tree structure easily accessible in 'removed' yet.
            // Let's find drag component first to check.
            
            const findComp = (list: DesignComponent[], id: string): DesignComponent | null => {
                for (const comp of list) {
                    if (comp.id === id) return comp;
                    if (comp.children.length > 0) {
                        const res = findComp(comp.children, id);
                        if (res) return res;
                    }
                }
                return null;
            };

            const dragComponent = findComp(prev, dragId);
            if (!dragComponent) return prev;

            const draggedComp = findComp(prev, dragId);
            if (!draggedComp) return prev;

            const targetParentId = position === 'inside' 
                ? (hoverId === 'root' ? null : hoverId)
                : null; 

            // Cycle check: Cannot drop parent into child
            if (position === 'inside' && targetParentId) {
                 const isDescendant = (parent: DesignComponent, targetId: string): boolean => {
                    if (parent.id === targetId) return true;
                    return parent.children.some(child => isDescendant(child, targetId));
                };
                if (isDescendant(draggedComp, targetParentId)) {
                    return prev;
                }
            }

            // 1. Remove dragged component
            const { cleaned, removed } = removeComponentFromTree(prev, dragId);
            if (!removed) return prev;

            // 2. Insert component at new location
            if (position === 'inside') {
                 // Note: targetParentId is already resolved above for 'inside' case
                 return insertComponentInTree(cleaned, targetParentId, { ...removed, parentId: targetParentId });
            } else {
                 // Re-calculate location in cleaned tree
                 if (hoverId === null || hoverId === 'root') {
                     return insertComponentInTree(cleaned, null, { ...removed, parentId: null }, position === 'before' ? 0 : undefined);
                 }

                 const findLoc = (list: DesignComponent[], targetId: string, currentParentId: string | null): { parentId: string | null, index: number } | null => {
                     for (let i = 0; i < list.length; i++) {
                         if (list[i].id === targetId) {
                             return { parentId: currentParentId, index: i };
                         }
                         if (list[i].children.length > 0) {
                             const res = findLoc(list[i].children, targetId, list[i].id);
                             if (res) return res;
                         }
                     }
                     return null;
                 };

                 const loc = findLoc(cleaned, hoverId, null);
                 if (loc) {
                     const insertIndex = position === 'after' ? loc.index + 1 : loc.index;
                     return insertComponentInTree(cleaned, loc.parentId, { ...removed, parentId: loc.parentId }, insertIndex);
                 }
            }
            return prev; // Fallback if target not found
        });
    }, []);

    const exportDesign = useCallback(() => {
        // Export as NovaUiSchema (new unified format)
        const novaSchema: NovaUiSchema = {
            ui: components,
            events: {
                actions
            },
            ruleset: {
                rules
            },
            variables: {
                vars: variables
            },
            jsCode,
            cssCode,
            metadata: {
                version: '1.0',
                updatedAt: new Date().toISOString()
            }
        };
        return JSON.stringify(novaSchema, null, 2);
    }, [components, jsCode, cssCode, rules, variables, actions]);

    const importDesign = useCallback((json: string) => {
        try {
            const parsed = JSON.parse(json);

            // Check if this is NovaUiSchema (new unified format)
            if (parsed.ui && parsed.events && parsed.ruleset && parsed.variables) {
                 console.log('Importing NovaUiSchema format');
                 setComponents(parsed.ui || []);
                 setActions(parsed.events?.actions || []);
                 setRules(parsed.ruleset?.rules || []);
                 setVariables(parsed.variables?.vars || []);
                 setJsCode(parsed.jsCode || '// Custom JS here');
                 setCssCode(parsed.cssCode || '/* Custom CSS here */');
            }
            // Check if this is old CompleteDesignSchema format (has components property)
            else if (parsed.components) {
                 console.log('Importing CompleteDesignSchema format');
                 setComponents(parsed.components);
                 setJsCode(parsed.jsCode || '');
                 setCssCode(parsed.cssCode || '');
                 setRules(parsed.rules || []);
                 setVariables(parsed.variables || []);
                 setActions(parsed.actions || []);
            }
            // Check if this is legacy EBML format (has EbmlContent property)
            else if (parsed.EbmlContent || parsed.Data || parsed.Ruleset || parsed.Interface) {
                 console.log('Importing legacy EBML format');
                 // Use NovaUiSchema converter to parse all design elements
                 const ebmlContent = parsed.EbmlContent || parsed;
                 const novaSchema = convertEbmlToNovaSchema(ebmlContent);

                 console.log('Parsed legacy EBML content:', {
                     components: novaSchema.ui.length,
                     rules: novaSchema.ruleset.rules.length,
                     variables: novaSchema.variables.vars.length,
                     actions: novaSchema.events.actions.length
                 });

                 // Set all parsed data
                 setComponents(novaSchema.ui);
                 setRules(novaSchema.ruleset.rules);
                 setVariables(novaSchema.variables.vars);
                 setActions(novaSchema.events.actions);
                 setJsCode(novaSchema.jsCode || '// Custom JS here');
                 setCssCode(novaSchema.cssCode || '/* Custom CSS here */');
            }
            // Fallback: try to parse as component array
            else if (Array.isArray(parsed)) {
                 console.log('Importing component array');
                 setComponents(parsed);
            }
        } catch (e) {
            console.error("Failed to import design", e);
        }
    }, []);

    const getComponentById = useCallback((id: string) => {
        return findComponent(components, id);
    }, [components]);

    return (
        <DesignerContext.Provider value={{
            components,
            jsCode,
            cssCode,
            selectedComponentId,
            mode,
            rules,
            variables,
            actions,
            addRule,
            updateRule,
            deleteRule,
            addVariable,
            updateVariable,
            deleteVariable,
            addAction,
            updateAction,
            deleteAction,
            selectComponent,
            addComponent,
            moveComponent,
            updateComponentProps,
            deleteComponent,
            setMode,
            setJsCode,
            setCssCode,
            exportDesign,
            importDesign,
            clearDesign,
            getComponentById
        }}>
            {children}
        </DesignerContext.Provider>
    );
};

