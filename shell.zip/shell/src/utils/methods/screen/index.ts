import type { IMenuItem } from 'set-ui';
import { ShellProcessTypeEnum, generateGlobalsDataByMenuKey, isWebview, shellTrigger } from 'set-ui';
import { dispatch, store } from '../../../_store';
import { resetStoreScreen, setStoreScreen } from '../../../_store/slices/screen';
import { setAuthData } from '../auth';

export const setScreenData = (item: IMenuItem): void => {
    // For "screen" store value
    dispatch(setStoreScreen(item));
    // For "auth.globals" value
    setAuthData({
        ...store.getState().auth.data,
        globals: generateGlobalsDataByMenuKey({
            menuKey: item?.menuKey || null,
        }),
    });
};

export const resetScreenData = (): void => {
    // For "screen" store value
    dispatch(resetStoreScreen());
    // For "auth.globals" value
    setAuthData({
        ...store.getState().auth.data,
        globals: generateGlobalsDataByMenuKey({
            menuKey: null,
        }),
    });
};

export const navigateScreen = (item: IMenuItem): void => {
    // For "screen" value
    setScreenData(item);
    // Navigate Operations
    if (isWebview()) {
        // * For Shell View
        shellTrigger({
            processType: ShellProcessTypeEnum.Screen,
            data: item,
        });
    } else {
        // * For Not Shell
        // TODO : Ekran açılması sağlanacak.
        console.log('Open Screen For Not Shell on nova', item); // eslint-disable-line
    }
};
