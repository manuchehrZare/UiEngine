import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { removeSessionStorageItem, setSessionStorageItem } from 'seker-ui';
import type { IStore } from '../..';
import { constants } from '../../../utils';
import { type AppStore, initialAppStoreValue } from './type';

export const appSlice = createSlice({
    name: 'app',
    initialState: initialAppStoreValue,
    reducers: {
        setStoreApp: (state: AppStore, action: PayloadAction<AppStore>): AppStore => {
            const appStoreData: AppStore = {
                ...state,
                ...action.payload,
            };
            setSessionStorageItem(constants.key.SET_APP, appStoreData);
            return appStoreData;
        },
        resetStoreApp: (state: AppStore): AppStore => {
            removeSessionStorageItem(constants.key.SET_APP);
            return { ...state, ...initialAppStoreValue };
        },
    },
});

// Type export
export type { AppStore };

// Value export
export { initialAppStoreValue };
export const appValue = (state: IStore): AppStore => state.app;

// Actions exports
export const { setStoreApp, resetStoreApp } = appSlice.actions;

// Reducer export
export default appSlice.reducer;
