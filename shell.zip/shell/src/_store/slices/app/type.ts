import type { AppType } from 'set-ui';
import { initialAppValue } from 'set-ui';

export type AppStore = AppType;

export const initialAppStoreValue: AppStore = initialAppValue;
