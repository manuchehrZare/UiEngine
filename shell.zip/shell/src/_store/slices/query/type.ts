export type QueryStore = {
    ref: string | null;
};

export const initialQueryStoreValue: QueryStore = {
    ref: null,
};
