import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { removeSessionStorageItem, setSessionStorageItem } from 'seker-ui';
import type { IStore } from '../..';
import { constants } from '../../../utils';
import type { QueryStore } from './type';
import { initialQueryStoreValue } from './type';

export const querySlice = createSlice({
    name: 'query',
    initialState: initialQueryStoreValue,
    reducers: {
        setStoreQuery: (state: QueryStore, action: PayloadAction<QueryStore>): QueryStore => {
            const queryStoreData: QueryStore = {
                ...state,
                ...action.payload,
            };
            setSessionStorageItem(constants.key.SET_QUERY, queryStoreData);
            return queryStoreData;
        },
        resetStoreQuery: (state: QueryStore): QueryStore => {
            removeSessionStorageItem(constants.key.SET_QUERY);
            return { ...state, ...initialQueryStoreValue };
        },
    },
});

// Type export
export type { QueryStore };

// Value export
export { initialQueryStoreValue };
export const queryValue = (state: IStore): QueryStore => state.query;

// Actions exports
export const { setStoreQuery, resetStoreQuery } = querySlice.actions;

// Reducer export
export default querySlice.reducer;
