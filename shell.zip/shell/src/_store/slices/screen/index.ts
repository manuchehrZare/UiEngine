import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { removeSessionStorageItem, setSessionStorageItem } from 'seker-ui';
import type { IStore } from '../..';
import { constants } from '../../../utils';
import type { ScreenStore } from './type';
import { initialScreenStoreValue } from './type';

export const screenSlice = createSlice({
    name: 'screen',
    initialState: initialScreenStoreValue,
    reducers: {
        setStoreScreen: (_: ScreenStore, action: PayloadAction<ScreenStore>): ScreenStore => {
            const screenStoreData: ScreenStore = action.payload;
            setSessionStorageItem(constants.key.SET_SCREEN, screenStoreData);
            return screenStoreData;
        },
        // eslint-disable-next-line
        resetStoreScreen: (_: ScreenStore): ScreenStore => {
            removeSessionStorageItem(constants.key.SET_SCREEN);
            return initialScreenStoreValue;
        },
    },
});

// Type export
export type { ScreenStore };

// Value export
export { initialScreenStoreValue };
export const screenValue = (state: IStore): ScreenStore => state.screen;

// Actions exports
export const { setStoreScreen, resetStoreScreen } = screenSlice.actions;

// Reducer export
export default screenSlice.reducer;
