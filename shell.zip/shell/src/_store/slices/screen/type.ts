import type { ScreenType } from 'set-ui';
import { initialScreenValue } from 'set-ui';

export type ScreenStore = ScreenType;

export const initialScreenStoreValue: ScreenStore = initialScreenValue;
