import type { AuthenticateType } from 'set-ui';
import { initialAuthValue } from 'set-ui';

export type AuthStoreData = AuthenticateType | null;

export type AuthStore = {
    data: AuthStoreData;
    loggedIn: boolean;
};

export const initialAuthStoreValue: AuthStore = {
    data: initialAuthValue,
    loggedIn: false,
};
