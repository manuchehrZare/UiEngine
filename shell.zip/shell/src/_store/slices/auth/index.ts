import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { removeSessionStorageItem, setSessionStorageItem } from 'seker-ui';
import type { IStore } from '../..';
import { constants } from '../../../utils';
import type { AuthStore, AuthStoreData } from './type';
import { initialAuthStoreValue } from './type';

export const authSlice = createSlice({
    name: 'auth',
    initialState: initialAuthStoreValue,
    reducers: {
        setStoreAuth: (state: AuthStore, action: PayloadAction<AuthStore>): AuthStore => {
            const authStoreData: AuthStore = {
                ...state,
                ...action.payload,
            };
            setSessionStorageItem(constants.key.SET_AUTH, authStoreData.data);
            return authStoreData;
        },
        resetStoreAuth: (state: AuthStore): AuthStore => {
            removeSessionStorageItem(constants.key.SET_AUTH);
            return { ...state, ...initialAuthStoreValue };
        },
    },
});

// Type export
export type { AuthStore, AuthStoreData };

// Value export
export { initialAuthStoreValue };
export const authValue = (state: IStore): AuthStore => state.auth;

// Actions exports
export const { setStoreAuth, resetStoreAuth } = authSlice.actions;

// Reducer export
export default authSlice.reducer;
