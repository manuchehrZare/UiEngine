import { combineReducers } from '@reduxjs/toolkit';
import app from './app';
import auth from './auth';
import query from './query';
import screen from './screen';

export default combineReducers({ app, auth, query, screen });
