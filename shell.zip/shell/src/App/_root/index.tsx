import type { FC } from 'react';
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import PrivateRoute from './PrivateRoute';
import { RouteItemTypeEnum, routes, routesArray } from './routes';

const Root: FC = () => {
    return (
        <Router>
            <Routes>
                <Route path={routes.home.path} element={<Navigate to={routes.menuList.path} />} />
                {routesArray.map((route, index) => {
                    const ReactElement: any = route.element;
                    return ReactElement ? (
                        <Route
                            key={`${route.path}-${String(index)}`}
                            path={route.path}
                            element={
                                route.type === RouteItemTypeEnum.Private ? (
                                    <PrivateRoute>
                                        <ReactElement />
                                    </PrivateRoute>
                                ) : (
                                    <ReactElement />
                                )
                            }
                        />
                    ) : null;
                })}
            </Routes>
        </Router>
    );
};

export default Root;
