import { differenceWith, get } from 'lodash';
import type { RouteProps } from 'react-router-dom';
import { deepKeysAsArray } from 'seker-ui';
import { isWebview } from 'set-ui';
import { Load, lazyWithRetry } from '../LazyLoad';
import LayoutFooter from '../../pages/Layout/Footer';
import LayoutHeader from '../../pages/Layout/Header';
import LayoutSidebar from '../../pages/Layout/Sidebar';
import type { JSX } from 'react';

const Login = Load.Component({
    component: lazyWithRetry(() => import('../../pages/Auth/Login')),
});
const MenuList = Load.Component({
    component: lazyWithRetry(() => import('../../pages/MenuList')),
});
const Favourites = Load.Component({
    component: lazyWithRetry(() => import('../../pages/Favourites')),
});
const Notifications = Load.Component({
    component: lazyWithRetry(() => import('../../pages/Notifications')),
});
const Settings = Load.Component({
    component: lazyWithRetry(() => import('../../pages/Settings')),
});
const NotFound = Load.Component({
    component: lazyWithRetry(() => import('../../pages/Error/NotFound')),
});
const NovaUiStudio = Load.Component({
    component: lazyWithRetry(() => import('../../nova/nova-studio')),
});
const NovaUi = Load.Component({
    component: lazyWithRetry(() => import('../../nova/nova-page')),
});

export enum RouteItemTypeEnum {
    Public = 'public',
    Private = 'private',
}

export type RouteItem = Required<Pick<RouteProps, 'element' | 'path'>> & {
    type: `${RouteItemTypeEnum}`;
};

export const routes = {
    auth: {
        login: {
            path: '/auth/login',
            element: Login as unknown as JSX.Element,
            type: RouteItemTypeEnum.Public,
        } as RouteItem,
    },
    error: {
        notFound: {
            path: '*',
            element: NotFound as unknown as JSX.Element,
            type: RouteItemTypeEnum.Public,
        } as RouteItem,
    },
    layout: {
        footer: {
            path: '/layout/footer',
            element: LayoutFooter as unknown as JSX.Element,
            type: isWebview() ? RouteItemTypeEnum.Public : RouteItemTypeEnum.Private,
        } as RouteItem,
        header: {
            path: '/layout/header',
            element: LayoutHeader as unknown as JSX.Element,
            type: isWebview() ? RouteItemTypeEnum.Public : RouteItemTypeEnum.Private,
        } as RouteItem,
        sidebar: {
            path: '/layout/sidebar',
            element: LayoutSidebar as unknown as JSX.Element,
            type: isWebview() ? RouteItemTypeEnum.Public : RouteItemTypeEnum.Private,
        } as RouteItem,
    },
    home: {
        path: '/',
        element: null,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
    menuList: {
        path: '/menu-list',
        element: MenuList as unknown as JSX.Element,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
    favourites: {
        path: '/favourites',
        element: Favourites as unknown as JSX.Element,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
    novaUiStudio: {
        path: '/nova-studio',
        element: NovaUiStudio as unknown as JSX.Element,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
    novaUi: {
        path: '/nova-ui',
        element: NovaUi as unknown as JSX.Element,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
    notifications: {
        path: '/notifications',
        element: Notifications as unknown as JSX.Element,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
    settings: {
        path: '/settings',
        element: Settings as unknown as JSX.Element,
        type: RouteItemTypeEnum.Private,
    } as RouteItem,
};

const getRoutesArray = (): RouteItem[] => {
    const routesArray: RouteItem[] = [];
    const routesPathArray = deepKeysAsArray(routes, true).filter(
        (pathItem) => !pathItem.includes('path') && !pathItem.includes('element') && !pathItem.includes('type'),
    );
    routesPathArray.forEach((pathItem) => {
        const item: RouteItem = get(routes, pathItem);
        if (differenceWith(Object.keys(item), ['path', 'element', 'type']).length === 0) {
            routesArray.push(item);
        }
    });
    return routesArray;
};

export const routesArray = getRoutesArray();

export const isValidRoutePath = (path: string): boolean => {
    return routesArray.findIndex((item) => item.path === path) !== -1;
};
