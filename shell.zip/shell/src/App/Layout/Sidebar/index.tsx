import { LogoutOutlined, Menu, NotificationsNone, SettingsOutlined, StarOutline } from '@mui/icons-material';
import type { FC, JSX, ReactNode } from 'react';
import { forwardRef, memo, useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import type { IBoxProps } from 'seker-ui';
import { Box, Button, CustomScrollbar, DesignTypeEnum, useMeasure } from 'seker-ui';
import { constants, removeHrefFromLinkForShell, resetAuthData, useTranslation } from '../../../utils';
import { routes } from '../../_root/routes';
import { ReactComponent as Logo } from '../../../assets/images/logo_mini_white.svg';
import { dispatch, useSelector } from '../../../_store';
import { appValue, initialAppStoreValue, setStoreApp } from '../../../_store/slices/app';
import { isWebview, Logout, ShellProcessTypeEnum, shellTrigger } from 'set-ui';
import { v4 as uuidv4 } from 'uuid';
import type { LayoutMeasures } from '../type';

type SidebarProps = Pick<IBoxProps, 'ref'> & {
    layoutMeasures?: LayoutMeasures;
};

type SidebarMenuItem = {
    icon: ReactNode;
    isVisible: boolean;
    link: string;
    title: string;
};

const Sidebar: FC<SidebarProps> = forwardRef(({ layoutMeasures, ...rest }: SidebarProps, ref): JSX.Element => {
    const { t, locale } = useTranslation();
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const logoMeasure = useMeasure();
    const logoutMeasure = useMeasure();
    const listWrapperMeasure = useMeasure();
    const listMeasure = useMeasure();
    const appStoreValue = useSelector(appValue);
    const [sidebarScroll, setSidebarScroll] = useState<number>(0);
    const [activeSidebarIndex, setActiveSidebarIndex] = useState<number | null>(null);

    const menu: SidebarMenuItem[] = [
        {
            icon: <StarOutline />,
            link: routes.favourites.path,
            title: t(locale.pageTitles.favourites),
            isVisible: true,
        },
        {
            icon: <Menu />,
            link: routes.menuList.path,
            title: t(locale.pageTitles.menu),
            isVisible: true,
        },
        {
            icon: <NotificationsNone />,
            link: routes.notifications.path,
            title: t(locale.pageTitles.notifications),
            isVisible: import.meta.env.VITE_NODE_ENV === 'development',
        },
        {
            icon: <SettingsOutlined />,
            link: routes.settings.path,
            title: t(locale.pageTitles.settings),
            isVisible: isWebview(),
        },
    ];

    useEffect(() => {
        if (appStoreValue?.data?.sidebar) {
            if (appStoreValue?.data?.sidebar === -1) {
                setActiveSidebarIndex(null);
            } else {
                const menuActiveIndex = menu
                    .filter((item) => item.isVisible === true)
                    .findIndex((item) => item.link === appStoreValue?.data?.sidebar);
                menuActiveIndex &&
                    menuActiveIndex !== -1 &&
                    menuActiveIndex !== activeSidebarIndex &&
                    setActiveSidebarIndex(menuActiveIndex);
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [appStoreValue]);

    return (
        <Box
            ref={ref}
            className="sidebar"
            component="nav"
            position="fixed"
            left={0}
            sx={{
                ...(layoutMeasures?.footer?.height && layoutMeasures?.header?.height
                    ? {
                          height: `calc(100vh - ${layoutMeasures?.footer?.height + layoutMeasures?.header?.height}px)`,
                          top: layoutMeasures.header.height,
                      }
                    : { height: '100vh' }),
            }}
            width={
                isWebview()
                    ? constants.common.layout.SIDEBAR_WIDTH - 3 // This is how it is defined to make the shadow appear when in webview.
                    : constants.common.layout.SIDEBAR_WIDTH
            }
            pb={2}
            bgcolor={(theme) => theme.palette.common.white}
            boxShadow={2}
            zIndex={1}
            {...rest}>
            <Box textAlign="center">
                <Box
                    ref={logoMeasure.ref}
                    pt={2}
                    pb={1}
                    position="sticky"
                    top={0}
                    bgcolor={(theme) => theme.palette.common.white}
                    {...(sidebarScroll !== 0 && {
                        boxShadow: (theme) => `0px 15px 10px -15px ${theme.palette.grey[200]}`,
                    })}>
                    <Link
                        to={routes.home.path}
                        style={{ cursor: 'pointer' }}
                        {...removeHrefFromLinkForShell()}
                        onClick={(e) => {
                            e.preventDefault();
                            if (appStoreValue.isNova) {
                                // * For Shell View
                                shellTrigger({
                                    processType: ShellProcessTypeEnum.Sidebar,
                                    data: routes.menuList.path,
                                });
                            } else {
                                // * For Not Shell
                                navigate(routes.home.path);
                            }
                        }}>
                        <Box p={1}>
                            <Box mb={0.5}>
                                <Box
                                    display="inline-flex"
                                    justifyContent="center"
                                    alignItems="center"
                                    width={40}
                                    height={40}
                                    boxShadow={5}
                                    bgcolor={(theme) => theme.palette.secondary.main}
                                    borderRadius="50%">
                                    <Logo height={30} width={30} />
                                </Box>
                            </Box>
                            <Box fontWeight={700} sx={{ color: (theme) => theme.palette.secondary.main }}>
                                {import.meta.env.VITE_APP_TITLE}
                            </Box>
                        </Box>
                    </Link>
                </Box>
                <Box ref={listWrapperMeasure.ref}>
                    <CustomScrollbar
                        thickness={3}
                        height={
                            logoMeasure.node
                                ? layoutMeasures?.footer && layoutMeasures?.header
                                    ? `calc(100vh - ${
                                          (layoutMeasures?.footer?.height ?? 0) +
                                          (layoutMeasures?.header?.height ?? 0) +
                                          (logoMeasure?.values?.height ?? 0) +
                                          (logoutMeasure?.values?.height ?? 0)
                                      }px)`
                                    : `calc(100vh - ${logoMeasure.values.height}px)`
                                : '100vh'
                        }
                        onUpdate={(scrollValues) => {
                            setSidebarScroll(scrollValues.scrollTop);
                        }}>
                        <Box ref={listMeasure.ref} component="ul" pb={2}>
                            {menu
                                .filter((item) => item.isVisible === true)
                                .map(({ icon, link, title }, index) => (
                                    <Box component="li" key={uuidv4()}>
                                        <NavLink
                                            to={link}
                                            className={({ isActive }) =>
                                                isActive &&
                                                ((!appStoreValue.isNova && pathname === link) ||
                                                    (appStoreValue.isNova && activeSidebarIndex === index))
                                                    ? 'active'
                                                    : undefined
                                            }
                                            style={{ cursor: 'pointer' }}
                                            {...removeHrefFromLinkForShell()}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                if (appStoreValue.isNova) {
                                                    setActiveSidebarIndex(activeSidebarIndex === index ? null : index);
                                                    dispatch(
                                                        setStoreApp({
                                                            ...appStoreValue,
                                                            data: initialAppStoreValue.data,
                                                        }),
                                                    );
                                                    // * For Shell View
                                                    shellTrigger({
                                                        processType: ShellProcessTypeEnum.Sidebar,
                                                        data: activeSidebarIndex === index ? null : link,
                                                    });
                                                } else {
                                                    // * For Not Shell
                                                    navigate(link);
                                                }
                                            }}>
                                            <Box
                                                p={1}
                                                fontWeight={600}
                                                fontSize={16}
                                                bgcolor={(theme) =>
                                                    (!appStoreValue.isNova && pathname === link) ||
                                                    (appStoreValue.isNova && activeSidebarIndex === index)
                                                        ? theme.palette.grey[100]
                                                        : 'transparent'
                                                }
                                                sx={{
                                                    wordBreak: 'break-word',
                                                    color: (theme) =>
                                                        (!appStoreValue.isNova && pathname === link) ||
                                                        (appStoreValue.isNova && activeSidebarIndex === index)
                                                            ? theme.palette.secondary.main
                                                            : theme.palette.primary.light,
                                                    ':hover': {
                                                        backgroundColor: (theme) => theme.palette.grey[100],
                                                    },
                                                }}>
                                                <Box>{icon}</Box>
                                                <Box>{title}</Box>
                                            </Box>
                                        </NavLink>
                                    </Box>
                                ))}
                        </Box>
                    </CustomScrollbar>
                </Box>
                <Box
                    ref={logoutMeasure.ref}
                    bgcolor={(theme) => theme.palette.common.white}
                    p={1}
                    position="sticky"
                    bottom={layoutMeasures?.footer?.height || 0}
                    {...(listMeasure?.values?.height &&
                        listWrapperMeasure?.values?.height &&
                        listMeasure.values.height >= listWrapperMeasure.values.height && {
                            boxShadow: (theme) => `0px -15px 10px -15px ${theme.palette.grey[200]}`,
                        })}>
                    <Logout
                        component={
                            <Button
                                design={DesignTypeEnum.SET}
                                variant="outlined"
                                fullWidth
                                text={t(locale.buttons.exit)}
                                iconLeft={<LogoutOutlined />}
                            />
                        }
                        logoutConfirmModalProps={{
                            onConfirm: (status) => {
                                status && resetAuthData();
                            },
                        }}
                    />
                </Box>
            </Box>
        </Box>
    );
});

export default memo(Sidebar);
