import type { FC, JSX } from 'react';
import { forwardRef, memo } from 'react';
import type { IBoxProps } from 'seker-ui';
import { Box } from 'seker-ui';
import { constants } from '../../../utils';

interface IHeaderProps extends Pick<IBoxProps, 'ref'> {}

const Header: FC<IHeaderProps> = forwardRef((props: IHeaderProps, ref): JSX.Element => {
    return (
        <Box
            ref={ref}
            component="header"
            position="fixed"
            top={0}
            width="100%"
            height={constants.common.layout.HEADER_HEIGHT}
            bgcolor={(theme) => theme.palette.secondary.main}
            sx={{ color: (theme) => theme.palette.common.white }}
            zIndex={(theme) => (theme.zIndex as any).appBar}
            {...props}
        />
    );
});

export default memo(Header);
