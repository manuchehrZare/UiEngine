import { merge } from 'lodash';
import { constants } from 'set-ui';
import { nova } from './nova';

export const api = merge(constants.api.endpoints, { nova });
