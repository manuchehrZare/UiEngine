import { useQuery } from '@tanstack/react-query';
import { groupBy, keys, sortBy, sortedLastIndex, sum, toInteger } from 'lodash';
import type { FC, JSX } from 'react';
import { memo, useEffect, useState } from 'react';
import { Divider, Grid, GridItem, Label, scrollToElement, useMeasure, View } from 'seker-ui';
import type { AxiosError, IAuthorizeRequest, IAuthorizeResponse, IMenuItem } from 'set-ui';
import { axiosFetcher, QueryKeyEnum } from 'set-ui';
import { api } from '../../api/endpoints';
import type { LayoutMeasures } from '../../App';
import { Layout, routes } from '../../App';
import { AlphabetButtons, GridTitle, Group, Menu } from '../../components';
import { ScreenNameEnum, getSortedAlphabetList, useTranslation } from '../../utils';
import { useSelector } from '../../_store';
import { authValue } from '../../_store/slices/auth';
import { v4 as uuidv4 } from 'uuid';
import { useNavigate } from 'react-router-dom';

const MenuList: FC = (): JSX.Element => {
    const { t, locale } = useTranslation();
    const authStoreValue = useSelector(authValue);
    const gridTitleMeasure = useMeasure();
    const alphabetsMeasure = useMeasure();
    const navigate = useNavigate();
    const lastAlphabetGroupItemMeasure = useMeasure();
    const [menuList, setMenuList] = useState<IMenuItem[]>([]);
    const [layoutMeasures, setLayoutMeasures] = useState<LayoutMeasures | null>(null);
    const [alphabetsScrollTopValuesList, setAlphabetsScrollTopValuesList] = useState<number[]>([]);

    const getGroupId = (char: string) => `group-${char}`;
    const getButtonId = (char: string) => `button-${char}`;

    const authorizeQuery = useQuery<IAuthorizeResponse, AxiosError>({
        enabled: authStoreValue.loggedIn,
        queryKey: [QueryKeyEnum.AUTHORIZE_MENU],
        queryFn: () =>
            axiosFetcher<IAuthorizeResponse, IAuthorizeRequest>({
                ...api.nova.infra.admin.user.authorization.authorize.POST,
                data: { username: authStoreValue?.data?.loginUserName ?? '' },
            }),
    });

    const getAlphabets = (data: IMenuItem[]) => {
        return getSortedAlphabetList(keys(groupBy(data, (e) => e.menuName[0].toUpperCase())));
    };

    const navigatePage = (item: IMenuItem) => {
        navigate(`${routes.novaUi.path}?screen-code=${item.screenCode}`, { replace: true });
        // navigateScreen(item);
    };

    const getFlattenMenuList = (menuData: IMenuItem[]): IMenuItem[] => {
        const arr: IMenuItem[] = [];
        menuData.forEach((item) => {
            if (item.children && item.children.length > 0) {
                arr.push(...getFlattenMenuList(item.children));
            } else {
                arr.push(item);
            }
        });
        return arr;
    };

    const getMenuList = (menuData: IMenuItem[], parentItem?: IMenuItem): IMenuItem[] => {
        const arr: IMenuItem[] = [];
        menuData.forEach((item) => {
            if (item.children && item.children.length > 0) {
                item.children = getMenuList(item.children, item);
            }
            // The logout process can be done with the logout button in the sidebar menu.
            if (item?.screenName !== ScreenNameEnum.BANKING_EXIT) {
                arr.push(item);
            } else if (parentItem && parentItem?.children?.length === 1) {
                // Fake solution for ScreenCodeEnum.Logout control
                parentItem.screenName = ScreenNameEnum.BANKING_EXIT;
            }
        });
        return arr;
    };

    const setActiveCharButton = (char: string) => {
        const alphabetButtonGroup = document.getElementsByClassName('menu-alphabet-buttons')[0];
        if (alphabetButtonGroup) {
            const alphabetButtons = Array.from(alphabetButtonGroup.getElementsByTagName('button'));
            if (alphabetButtons.length > 0) {
                alphabetButtons.forEach((button) => {
                    if (button.id === getButtonId(char)) {
                        button.classList.add('active');
                    } else {
                        button.classList.remove('active');
                    }
                });
            }
        }
    };

    const getAlphabetsScrollTopValues = () => {
        const arr: number[] = [];
        getAlphabets(menuList).forEach((char) => {
            arr.push(
                toInteger(
                    sum([
                        document?.getElementById(getGroupId(char))?.getBoundingClientRect().y,
                        -1 *
                            sum([
                                gridTitleMeasure?.values?.height,
                                alphabetsMeasure?.values?.height,
                                layoutMeasures?.header.height,
                            ]),
                    ]),
                ),
            );
        });
        return arr;
    };

    useEffect(() => {
        if (authStoreValue.loggedIn && authorizeQuery?.data?.data && authorizeQuery.isFetched) {
            setMenuList(getMenuList(authorizeQuery.data?.data));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [authorizeQuery.data, authStoreValue.loggedIn]);

    useEffect(() => {
        if (
            menuList.length > 0 &&
            gridTitleMeasure?.values?.height &&
            alphabetsMeasure?.values?.height &&
            alphabetsScrollTopValuesList.length === 0
        ) {
            setAlphabetsScrollTopValuesList(getAlphabetsScrollTopValues());
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [menuList, gridTitleMeasure, alphabetsMeasure, layoutMeasures]);

    useEffect(() => {
        if (menuList.length > 0 && alphabetsScrollTopValuesList.length > 0) {
            setActiveCharButton(getAlphabets(menuList)[0]);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [menuList, alphabetsScrollTopValuesList]);

    return (
        <Layout
            title={t(locale.pageTitles.menuList)}
            onMeasureChange={(measures) => setLayoutMeasures(measures)}
            onContentScrollChange={(scrollValues) => {
                const arr = sortBy([...alphabetsScrollTopValuesList, scrollValues.scrollTop]);
                const char = getAlphabets(menuList)[sortedLastIndex(arr, scrollValues.scrollTop) - 2];
                setActiveCharButton(char);
            }}>
            <GridTitle
                ref={gridTitleMeasure.ref}
                title={t(locale.pageTitles.menuList)}
                searchProps={{
                    show: true,
                    options: {
                        data:
                            menuList.length > 0
                                ? getFlattenMenuList(menuList).map((item) => ({
                                      ...item,
                                      tmpDisplayField: `${item?.menuName}${
                                          item?.screenCode ? ` (${item?.screenCode})` : ''
                                      }`,
                                      tmpDisplayValue: `${item?.menuName}${
                                          item?.screenCode ? ` (${item?.screenCode})` : ''
                                      }`,
                                  }))
                                : [],
                        displayField: 'tmpDisplayField',
                        displayValue: 'tmpDisplayValue',
                    },
                    onOpenScreenClick: (selectedItem) => {
                        menuList.length > 0 &&
                            (() => {
                                const foundItem = getFlattenMenuList(menuList).find(
                                    (item) =>
                                        selectedItem.menuName.includes(item.menuName) &&
                                        item.screenCode === selectedItem.screenCode &&
                                        item.screenName === selectedItem.screenName &&
                                        item.menuKey === selectedItem.menuKey,
                                );
                                if (foundItem) {
                                    navigatePage(foundItem);
                                }
                            })();
                    },
                }}
            />
            <View
                show={Boolean(
                    authorizeQuery?.data?.data &&
                    !authorizeQuery.isFetching &&
                    menuList.length > 0 &&
                    getAlphabets(menuList).length > 0,
                )}>
                <Grid
                    ref={alphabetsMeasure.ref}
                    position="sticky"
                    top={gridTitleMeasure.values.height}
                    bgcolor={(theme) => theme.palette.common.white}
                    zIndex={(theme) => theme.zIndex.appBar}>
                    <GridItem textAlign="center" py={2}>
                        <AlphabetButtons
                            className="menu-alphabet-buttons"
                            alphabets={getAlphabets(menuList)}
                            buttonIdFormatter={getButtonId}
                            onClick={({ char }) => {
                                scrollToElement(getGroupId(char));
                            }}
                        />
                    </GridItem>
                    <GridItem>
                        <Divider />
                    </GridItem>
                </Grid>
                <Grid
                    mb={`calc(100vh - ${sum([
                        gridTitleMeasure?.values.height,
                        alphabetsMeasure?.values.height,
                        layoutMeasures?.footer.height,
                        layoutMeasures?.header.height,
                        lastAlphabetGroupItemMeasure?.values.height,
                    ])}px)`}>
                    {getAlphabets(menuList).map((char, index) => {
                        return (
                            <GridItem
                                key={uuidv4()}
                                {...(index === getAlphabets(menuList).length - 1 && {
                                    ref: lastAlphabetGroupItemMeasure.ref,
                                })}
                                sx={{
                                    scrollMarginTop: `${sum([
                                        gridTitleMeasure.values.height,
                                        alphabetsMeasure.values.height,
                                    ])}px`,
                                }}
                                position="relative"
                                id={getGroupId(char)}>
                                <Group title={char}>
                                    <Menu
                                        data={groupBy(menuList, (e) => e.menuName[0].toUpperCase())[char]}
                                        onClick={(item) => {
                                            navigatePage(item);
                                        }}
                                    />
                                </Group>
                                <View show={index !== getAlphabets(menuList).length - 1}>
                                    <Divider />
                                </View>
                            </GridItem>
                        );
                    })}
                </Grid>
            </View>
            <View show={Boolean(authorizeQuery?.data?.data && !authorizeQuery?.isFetching && menuList.length === 0)}>
                <Grid p={2} spacing={1}>
                    <GridItem>
                        <Label
                            text={t(locale.notifications.noData)}
                            align="center"
                            color={(theme) => theme.palette.error.main}
                        />
                    </GridItem>
                </Grid>
            </View>
        </Layout>
    );
};

export default memo(MenuList);
