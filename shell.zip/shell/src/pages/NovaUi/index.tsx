/* eslint-disable */
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Box, Typography } from 'seker-ui';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import type { PageDefinition } from '../../nova/nova-ui/types/ebml.types';
import type { NovaUiSchema } from '../../nova/nova-ui//types/nova-schema.types';
import { DesignerProvider, useDesigner } from '../../nova/nova-studio/context/DesignerContext';
import { DesignArea } from '../../nova/nova-studio/components/DesignArea';
import { mapEbmlContentToNovaSchema } from '../../nova/nova-ui/nova-schema-mapper';

/**
 * DynamicRenderer component that imports and renders a NovaUiSchema
 */
const DynamicRenderer: React.FC<{ novaSchema: NovaUiSchema }> = ({ novaSchema }) => {
    const { importDesign, setMode } = useDesigner();

    useEffect(() => {
        if (novaSchema) {
            // Import the complete NovaUiSchema (includes UI, events, rules, variables)
            importDesign(JSON.stringify(novaSchema));
            setMode('preview');
        }
    }, [novaSchema, importDesign, setMode]);

    return (
        <Box sx={{ height: '100vh', width: '100vw', overflow: 'hidden', bgcolor: '#f0f2f5' }}>
            <DesignArea />
        </Box>
    );
};

/**
 * NovaPage component that fetches and renders a page by screenCode from URL
 * Usage: /nova-page/:screenCode
 * This page does not show menu bar, only the rendered page
 */
const NovaPageContent: React.FC = () => {
    const { screenCode } = useParams<{ screenCode: string }>();
    const [pageDefinition, setPageDefinition] = useState<PageDefinition | null>(null);
    const [novaSchema, setNovaSchema] = useState<NovaUiSchema | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadPageByScreenCode = async () => {
            try {
                setLoading(true);
                setError(null);

                // Load the ui-definition.json file
                const response = await fetch('/src/assets/docs/ui-definition.json');
                if (!response.ok) {
                    throw new Error('Failed to load page definitions');
                }

                const pages: PageDefinition[] = await response.json();

                // Find the page by screenCode
                const page = pages.find((p) => p.ScreenCode === screenCode);

                if (!page) {
                    throw new Error(`Page with screenCode "${screenCode}" not found`);
                }

                setPageDefinition(page);

                // Convert EBML to NovaUiSchema
                try {
                    const convertedSchema = mapEbmlContentToNovaSchema(page.EbmlContent);
                    setNovaSchema(convertedSchema);
                } catch (conversionError) {
                    console.error('Failed to convert page schema:', conversionError);
                    throw new Error('Failed to convert page schema');
                }
            } catch (err) {
                console.error('Error loading page:', err);
                setError(err instanceof Error ? err.message : 'Unknown error occurred');
            } finally {
                setLoading(false);
            }
        };

        if (screenCode) {
            loadPageByScreenCode();
        } else {
            setError('No screenCode provided in URL');
            setLoading(false);
        }
    }, [screenCode]);

    if (loading) {
        return (
            <Box
                sx={{
                    height: '100vh',
                    width: '100vw',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    bgcolor: '#f5f5f5',
                }}
            >
                <Typography variant="h6" color="text.secondary">
                    Loading page "{screenCode}"...
                </Typography>
            </Box>
        );
    }

    if (error) {
        return (
            <Box
                sx={{
                    height: '100vh',
                    width: '100vw',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    bgcolor: '#f5f5f5',
                }}
            >
                <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h5" color="error" gutterBottom>
                        Error Loading Page
                    </Typography>
                    <Typography variant="body1" color="text.secondary">
                        {error}
                    </Typography>
                </Box>
            </Box>
        );
    }

    if (!novaSchema || !pageDefinition) {
        return (
            <Box
                sx={{
                    height: '100vh',
                    width: '100vw',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    bgcolor: '#f5f5f5',
                }}
            >
                <Typography variant="h6" color="text.secondary">
                    No schema available for page "{screenCode}"
                </Typography>
            </Box>
        );
    }

    return <DynamicRenderer novaSchema={novaSchema} />;
};

/**
 * Main NovaPage component with providers
 */
const NovaUi: React.FC = () => {
    return (
        <DndProvider backend={HTML5Backend}>
            <DesignerProvider>
                <NovaPageContent />
            </DesignerProvider>
        </DndProvider>
    );
};

export default NovaUi;
