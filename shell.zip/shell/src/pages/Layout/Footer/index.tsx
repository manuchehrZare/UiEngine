import type { FC, JSX } from 'react';
import { Footer } from '../../../App';

const LayoutFooterPage: FC = (): JSX.Element => {
    return <Footer />;
};

export default LayoutFooterPage;
