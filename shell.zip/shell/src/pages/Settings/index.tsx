import { isUndefined } from 'lodash';
import { type FC, useEffect, type JSX } from 'react';
import { Box, DesignTypeEnum, Grid, GridItem, Label, Switch, useForm, useIsFirstRender, useWatch } from 'seker-ui';
import { type AppSettings, ShellProcessTypeEnum, shellTrigger } from 'set-ui';
import { Layout } from '../../App';
import { GridTitle, ShellKeyValueList } from '../../components';
import { useTranslation } from '../../utils';
import { useSelector } from '../../_store';
import { appValue } from '../../_store/slices/app';

interface ISettingsFormValues extends AppSettings {}

const Settings: FC = (): JSX.Element => {
    const { t, locale } = useTranslation();
    const appStoreValue = useSelector(appValue);
    const isFirstRender = useIsFirstRender();

    const { control, setValue } = useForm<ISettingsFormValues>({
        defaultValues: {
            detailLog: false,
            signalRConsole: false,
        },
    });
    const detailLogWatch = useWatch({ control, fieldName: 'detailLog' });
    const signalRConsoleWatch = useWatch({ control, fieldName: 'signalRConsole' });

    useEffect(() => {
        if (appStoreValue?.app?.settings) {
            !isUndefined(appStoreValue?.app?.settings?.detailLog) &&
                setValue('detailLog', appStoreValue?.app?.settings?.detailLog);
            !isUndefined(appStoreValue?.app?.settings?.signalRConsole) &&
                setValue('signalRConsole', appStoreValue?.app?.settings?.signalRConsole);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [appStoreValue]);

    useEffect(() => {
        !isFirstRender &&
            shellTrigger<AppSettings>({
                processType: ShellProcessTypeEnum.Settings,
                data: { detailLog: detailLogWatch, signalRConsole: signalRConsoleWatch },
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [detailLogWatch, signalRConsoleWatch]);

    return (
        <Layout title={t(locale.pageTitles.settings)}>
            <GridTitle title={t(locale.pageTitles.settings)} />
            <Grid py={2} spacing={1}>
                <GridItem>
                    <Box px={2} py={1} border={1} borderColor={(theme) => theme.palette.grey[300]} borderRadius={2}>
                        <Box className="title" mb={1}>
                            <Label
                                design={DesignTypeEnum.Default}
                                text={t(locale.contentTitles.settings.log)}
                                fontSize={15}
                            />
                        </Box>
                        <Box className="detail">
                            <ShellKeyValueList
                                data={[
                                    {
                                        text: t(locale.labels.openDetailLog),
                                        value: <Switch name="detailLog" control={control} />,
                                    },
                                ]}
                            />
                        </Box>
                    </Box>
                </GridItem>
                <GridItem>
                    <Box px={2} py={1} border={1} borderColor={(theme) => theme.palette.grey[300]} borderRadius={2}>
                        <Box className="title" mb={1}>
                            <Label
                                design={DesignTypeEnum.Default}
                                text={t(locale.contentTitles.settings.console)}
                                fontSize={15}
                            />
                        </Box>
                        <Box className="detail">
                            <ShellKeyValueList
                                data={[
                                    {
                                        text: t(locale.labels.openSignalRConsole),
                                        value: <Switch name="signalRConsole" control={control} />,
                                    },
                                ]}
                            />
                        </Box>
                    </Box>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default Settings;
