import { lazy } from 'react';

/**
 * When the file is not imported, it tries to reload to import it again.
 */
export const lazyWithRetry: typeof lazy = (componentImport: any) =>
    lazy(async () => {
        const pageHasAlreadyBeenForceRefreshed =
            window.localStorage && JSON.parse(window.localStorage.getItem('page-has-been-force-refreshed') || 'false');
        try {
            const component = await componentImport();
            if (window.localStorage) {
                window.localStorage.setItem('page-has-been-force-refreshed', 'false');
            }
            return component;
        } catch (error) {
            if (!pageHasAlreadyBeenForceRefreshed) {
                if (window.localStorage) {
                    window.localStorage.setItem('page-has-been-force-refreshed', 'true');
                }
                return window.location.reload();
            }
            throw error;
        }
    });
