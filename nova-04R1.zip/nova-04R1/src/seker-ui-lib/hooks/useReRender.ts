import { useReducer } from 'react';

export type UseReRenderReturnType = {
    reRender: React.DispatchWithoutAction;
};

const reRenderReducer = (num: number): number => (num + 1) % 1_000_000;

const useReRender = (): UseReRenderReturnType => {
    const [, reRender] = useReducer(reRenderReducer, 0);

    return { reRender };
};

export default useReRender;
