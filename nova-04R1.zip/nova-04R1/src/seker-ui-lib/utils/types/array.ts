import type { Enumerate } from './number';

export type FixedSizeArray<N extends number, T = any> = N extends 0
    ? readonly T[]
    : //@ts-expect-error
      Record<Enumerate<N>, T> & { length: N } & readonly T[];
