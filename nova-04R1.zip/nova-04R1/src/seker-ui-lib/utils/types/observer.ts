// sharedObservers.ts

type ObserverCallback<T> = (entry: T) => void;

/**
 * Abstract base class for shared observer logic.
 */
abstract class BaseObserver<TEntry, TTarget extends Node> {
    protected callbackMap = new WeakMap<TTarget, Set<ObserverCallback<TEntry>>>();
    protected observedTargets = new Set<TTarget>();

    public disconnect(): void {
        this.callbackMap = new WeakMap();
        this.callbackMapClear();
    }

    public observe(target: TTarget, callback: ObserverCallback<TEntry>) {
        let callbacks = this.callbackMap.get(target);
        if (!callbacks) {
            callbacks = new Set();
            this.callbackMap.set(target, callbacks);
            this.observedTargets.add(target);
            this.observeTarget(target);
        }
        callbacks.add(callback);
    }

    public unobserve(target: TTarget, callback: ObserverCallback<TEntry>) {
        const callbacks = this.callbackMap.get(target);
        if (!callbacks) return;

        callbacks.delete(callback);

        if (callbacks.size === 0) {
            this.callbackMap.delete(target);
            this.observedTargets.delete(target);
            this.unobserveTarget(target);
        }

        if (this.observedTargets.size === 0) {
            this.callbackMapClear();
        }
    }

    protected callbackMapClear() {
        this.observedTargets.clear();
    }

    protected callbackMapSize(): number {
        return this.observedTargets.size;
    }

    protected abstract observeTarget(target: TTarget): void;
    protected abstract unobserveTarget(target: TTarget): void;
}

/**
 * Shared ResizeObserver - Observes size changes of elements.
 */
class SharedResizeObserver extends BaseObserver<ResizeObserverEntry, Element> {
    private static instance: SharedResizeObserver | null = null;
    private observer: ResizeObserver;

    constructor() {
        super();
        this.observer = new ResizeObserver((entries) => {
            entries.forEach((entry) => {
                const callbacks = this.callbackMap.get(entry.target);
                callbacks?.forEach((cb) => cb(entry));
            });
        });
    }

    public static getInstance(): SharedResizeObserver {
        if (!SharedResizeObserver.instance) {
            SharedResizeObserver.instance = new SharedResizeObserver();
        }
        return SharedResizeObserver.instance;
    }

    public override disconnect() {
        super.disconnect();
        this.observer.disconnect();
    }

    protected observeTarget(target: Element): void {
        this.observer.observe(target);
    }

    protected unobserveTarget(target: Element): void {
        this.observer.unobserve(target);
        if (this.callbackMapSize() === 0) {
            this.observer.disconnect();
        }
    }
}

/**
 * Shared MutationObserver - Observes DOM mutations (attributes, children).
 */
class SharedMutationObserver extends BaseObserver<MutationRecord, Node> {
    private static instance: SharedMutationObserver | null = null;
    private observer: MutationObserver;

    constructor() {
        super();
        this.observer = new MutationObserver((records) => {
            const handled = new WeakSet<Node>();
            records.forEach((record) => {
                const target = record.target;
                if (!handled.has(target)) {
                    const callbacks = this.callbackMap.get(target);
                    callbacks?.forEach((cb) => cb(record));
                    handled.add(target);
                }
            });
        });
    }

    public static getInstance(): SharedMutationObserver {
        if (!SharedMutationObserver.instance) {
            SharedMutationObserver.instance = new SharedMutationObserver();
        }
        return SharedMutationObserver.instance;
    }

    public override disconnect() {
        super.disconnect();
        this.observer.disconnect();
    }

    protected observeTarget(target: Node): void {
        this.observer.observe(target, {
            attributes: true,
            childList: true,
            subtree: true,
        });
    }

    // eslint-disable-next-line
    protected unobserveTarget(_: Node): void {
        this.observer.disconnect();

        if (this.callbackMapSize() === 0) {
            this.callbackMapClear();
            return;
        }

        // Re-observe all remaining targets
        for (const target of this.observedTargets) {
            this.observeTarget(target);
        }
    }
}

/**
 * Shared IntersectionObserver - Observes visibility changes of elements.
 */
class SharedIntersectionObserver extends BaseObserver<IntersectionObserverEntry, Element> {
    private static instance: SharedIntersectionObserver | null = null;
    private observer: IntersectionObserver;

    constructor() {
        super();
        this.observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    const callbacks = this.callbackMap.get(entry.target);
                    callbacks?.forEach((cb) => cb(entry));
                });
            },
            {
                threshold: [0, 1], // Notify when visible or fully hidden
            },
        );
    }

    public static getInstance(): SharedIntersectionObserver {
        if (!SharedIntersectionObserver.instance) {
            SharedIntersectionObserver.instance = new SharedIntersectionObserver();
        }
        return SharedIntersectionObserver.instance;
    }

    public override disconnect() {
        super.disconnect();
        this.observer.disconnect();
    }

    protected observeTarget(target: Element): void {
        this.observer.observe(target);
    }

    protected unobserveTarget(target: Element): void {
        this.observer.unobserve(target);
        if (this.callbackMapSize() === 0) {
            this.observer.disconnect();
        }
    }
}

// Export shared instances (Singletons)
export const sharedResizeObserver = SharedResizeObserver.getInstance();
export const sharedMutationObserver = SharedMutationObserver.getInstance();
export const sharedIntersectionObserver = SharedIntersectionObserver.getInstance();
