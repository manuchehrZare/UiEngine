import type { IPhoneNumberInputProps } from '../../../..';
import { constants } from '../../../constants';

export interface IPhoneNumberFormatterOptions extends Pick<
    IPhoneNumberInputProps,
    'withCountryCode' | 'withoutAreaCode' | 'withoutBrackets' | 'withZero'
> {
    format?: string;
    mask?: string;
}

/**
 * Provides the view of the phone number in the desired format.
 * @param phoneNumberValue The phone number value to be formatted.
 * @returns Returns the formatted version of the phone number.
 */
export const phoneNumberFormatter = (phoneNumberValue: string, options?: IPhoneNumberFormatterOptions): string => {
    const cleaned = phoneNumberValue.replace(/\D/g, '');
    let formattedNumber = '';
    let index = 0;
    const format =
        options?.format ||
        (options?.withoutAreaCode
            ? constants.format.design.phoneNumber.withoutAreacode
            : options?.withZero
              ? options?.withoutBrackets
                  ? options?.withCountryCode
                      ? constants.format.design.phoneNumber.withCountryCode.withoutBrackets
                      : constants.format.design.phoneNumber.withAreaCode.withoutBrackets.withZero
                  : options?.withCountryCode
                    ? constants.format.design.phoneNumber.withCountryCode.withBrackets
                    : constants.format.design.phoneNumber.withAreaCode.withBrackets.withZero
              : options?.withoutBrackets
                ? constants.format.design.phoneNumber.withAreaCode.withoutBrackets.withoutZero
                : constants.format.design.phoneNumber.withAreaCode.withBrackets.withoutZero);

    for (const char of format) {
        if (char === '#') {
            if (index < cleaned.length) {
                formattedNumber += cleaned[index];
                index++;
            } else {
                formattedNumber += options?.mask || constants.format.char.underscore;
            }
        } else {
            formattedNumber += char;
        }
    }
    return formattedNumber;
};
