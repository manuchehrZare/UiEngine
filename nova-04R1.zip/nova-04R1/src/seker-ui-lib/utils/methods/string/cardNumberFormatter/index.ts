/**
 * It ensures that the card number appears regularly in groups of four characters.
 * @param cardNumberValue It is the card number value to be formatted.
 * @returns Returns the formatted version of the card number value.
 */
export const cardNumberFormatter = (cardNumberValue: string): string => {
    if (cardNumberValue) {
        return (cardNumberValue.replace(/\s/g, '')?.match(new RegExp('.{1,4}', 'g')) || []).join(' ');
    }
    return '';
};
