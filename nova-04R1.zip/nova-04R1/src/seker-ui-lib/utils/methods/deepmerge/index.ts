import React from 'react';

interface DeepmergeOptions {
    clone?: boolean;
}

// Helper function to check if a value is a plain object
function isPlainObject(value: unknown): value is Record<string, unknown> {
    return (
        value !== null &&
        typeof value === 'object' &&
        !Array.isArray(value) &&
        !React.isValidElement(value as React.ReactElement)
    );
}

// Deep cloning function with type safety
function deepClone<T>(source: T): T | Record<string, unknown> {
    // Prevent cloning of React elements or non-plain objects
    if (React.isValidElement(source) || !isPlainObject(source)) {
        return source;
    }

    const output: Record<string, unknown> = {};

    // Recursively clone each key
    Object.keys(source).forEach((key) => {
        output[key] = deepClone(source[key]);
    });

    return output as T;
}

// Advanced style merging function
function mergeStyles(targetValue: unknown, sourceValue: unknown): unknown {
    // Merge two functions
    if (typeof targetValue === 'function' && typeof sourceValue === 'function') {
        return function mergedFunction(...args: any[]) {
            const result1 = targetValue(...args);
            const result2 = sourceValue(...args);
            return { ...result1, ...result2 };
        };
    }

    // Merge function with plain object
    if (typeof targetValue === 'function' && isPlainObject(sourceValue)) {
        return function mergedFunction(...args: any[]) {
            const result = targetValue(...args);
            return { ...result, ...sourceValue };
        };
    }

    // Merge plain object with function
    if (isPlainObject(targetValue) && typeof sourceValue === 'function') {
        return function mergedFunction(...args: any[]) {
            const result = sourceValue(...args);
            return { ...targetValue, ...result };
        };
    }

    // Merge two plain objects
    if (isPlainObject(targetValue) && isPlainObject(sourceValue)) {
        return { ...targetValue, ...sourceValue };
    }

    // Default: return source value
    return sourceValue;
}

// Deep merge function with enhanced type safety and flexibility
export function deepmerge<T>(target: T, source: unknown, options: DeepmergeOptions = { clone: true }): T {
    // Clone target if specified
    const output = options.clone ? { ...target } : target;

    // Only merge if both target and source are plain objects
    if (isPlainObject(target) && isPlainObject(source)) {
        Object.keys(source).forEach((key) => {
            const sourceValue = source[key];
            const targetValue = target[key];

            // Dynamic merging for any style override key
            if (isPlainObject(targetValue) && isPlainObject(sourceValue)) {
                // If both are objects (like style override keys), merge recursively
                (output as Record<keyof any, unknown>)[key] = deepmerge(targetValue, sourceValue, options);
            }
            // Handle function merging for style overrides
            else if (
                (typeof targetValue === 'function' || isPlainObject(targetValue)) &&
                (typeof sourceValue === 'function' || isPlainObject(sourceValue))
            ) {
                // Use custom merge styles for functions and objects
                (output as Record<keyof any, unknown>)[key] = mergeStyles(targetValue, sourceValue);
            }
            // Clone or assign based on options
            else if (options.clone) {
                (output as Record<keyof any, unknown>)[key] = isPlainObject(sourceValue)
                    ? deepClone(sourceValue)
                    : sourceValue;
            } else {
                (output as Record<keyof any, unknown>)[key] = sourceValue;
            }
        });
    }

    return output;
}
