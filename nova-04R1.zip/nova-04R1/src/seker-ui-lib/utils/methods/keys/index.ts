import { set } from 'lodash';
//@ts-ignore
import deepKeys from 'deep-keys';

/**
 * Returns the keys of an object as an array.
 * @param obj
 * @param intermediate
 * @returns string array
 */
export const deepKeysAsArray = <T>(obj: T, intermediate?: boolean): string[] => {
    return deepKeys(obj, intermediate);
};

/**
 * Returns the keys of an object as an object.
 * @param obj
 * @returns typeof object
 */
export const deepKeysAsObject = <T>(obj: T): Required<T> => {
    const keysArr: string[] = deepKeys(obj);
    const keysObj = {};
    keysArr.length > 0 &&
        keysArr.forEach((item) => {
            set(keysObj, item, item);
        });
    return keysObj as Required<typeof obj>;
};
