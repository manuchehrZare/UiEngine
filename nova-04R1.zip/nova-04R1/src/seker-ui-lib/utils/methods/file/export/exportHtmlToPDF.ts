import jsPDF from 'jspdf';
import './_Font_SourceSansPro-Regular-normal.js';
import { FileExtentionsEnum } from '../type';

interface RGB {
    ch1: number;
    ch2: number;
    ch3: number;
}

interface IText {
    fontColor?: RGB;
    fontSize?: number;
    text: string;
    xPosition?: number;
    yPosition?: number;
}

interface IImage {
    format: string;
    height: number;
    source: any;
    width: number;
    xPosition: number;
    yPosition: number;
}

export interface IExportPDFProps {
    data: string;
    fileName: string;
    fontSize?: number;
    images?: IImage[];
    margin?: number;
    marginLeft?: number;
    marginTop?: number;
    pageCount?: boolean;
    texts?: IText[];
}

export const exportHtmlToPDF = ({
    data,
    fileName,
    texts,
    images,
    pageCount,
    margin = 24,
    fontSize = 14,
    marginLeft = 0,
    marginTop = 0,
}: IExportPDFProps): void => {
    const doc = new jsPDF('p', 'pt', 'a4', true);
    const pageWidth = doc.internal.pageSize.width - margin * 2;
    doc.html(`<div style="font-family: SourceSansPro-Regular; font-size: ${fontSize}px;">${data}</div>`, {
        // eslint-disable-next-line
        callback: (doc) => {
            doc.setFont('SourceSansPro-Regular', 'normal');
            const totalPages = doc.internal.pages.length - 1;
            for (let i = 1; i <= totalPages; i++) {
                doc.setPage(i);
                if (texts) {
                    for (let j = 0; j < texts.length; j++) {
                        doc.setTextColor(
                            texts[j].fontColor?.ch1 || 0,
                            texts[j].fontColor?.ch2 || 0,
                            texts[j].fontColor?.ch3 || 0,
                        );
                        doc.setFontSize(texts[j].fontSize || 12);
                        doc.text(texts[j].text, texts[j].xPosition || 0, texts[j].yPosition || 0, {});
                        doc.setTextColor(0, 0, 0);
                    }
                }

                if (images) {
                    for (let j = 0; j < images.length; j++) {
                        const img = new Image();
                        img.src = images[j].source;
                        doc.addImage(
                            img,
                            images[j].format,
                            images[j].xPosition,
                            images[j].yPosition,
                            images[j].width,
                            images[j].height,
                        );
                    }
                }
                if (pageCount) {
                    doc.text(`${i} / ${totalPages}`, margin || 0, doc.internal.pageSize.getHeight() - 15);
                }
            }
            doc.save(`${fileName}.${FileExtentionsEnum.PDF}`);
        },
        autoPaging: 'text',
        width: pageWidth,
        windowWidth: pageWidth,
        margin: margin,
        x: marginLeft,
        y: marginTop,
    });
};
