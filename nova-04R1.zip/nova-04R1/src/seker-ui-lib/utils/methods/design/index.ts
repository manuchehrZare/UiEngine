import type { StorageValueType } from '../../../hooks/useStorage';
import { constants } from '../../constants';
import type { DesignType } from '../../types/common';
import { getSessionStorageItem, removeSessionStorageItem, setSessionStorageItem } from '../storage';

export const setProviderDesign = (design: DesignType): void => {
    setSessionStorageItem(constants.key.PROVIDER_DESIGN, design);
};

export const getProviderDesign = (): DesignType | undefined => {
    return getSessionStorageItem(constants.key.PROVIDER_DESIGN) || undefined;
};

export const removeProviderDesign = (): void => {
    return removeSessionStorageItem(constants.key.PROVIDER_DESIGN);
};

/**
 * Does not need to be documented. It is only used in component definitions.
 */
export const getComponentDesignProperty = (
    design?: DesignType,
    storageDesign?: StorageValueType<DesignType>,
): DesignType => design || storageDesign || constants.design.defaultType;

export const generateClass = (className: string): string => `${constants.common.library.prefix}-${className}`;
