export const format = {
    char: {
        asterisk: '*',
        hash: '#',
        underscore: '_',
    },
    design: {
        cardNo: '#### #### #### ####',
        iban: 'TR## #### #### #### #### #### ##',
        phoneNumber: {
            withAreaCode: {
                withBrackets: {
                    withZero: '#(###) ### ## ##',
                    withoutZero: '(###) ### ## ##',
                },
                withoutBrackets: {
                    withZero: '#### ### ## ##',
                    withoutZero: '### ### ## ##',
                },
            },
            withoutAreacode: '### ## ##',
            withCountryCode: {
                withBrackets: '##(###) ### ## ##',
                withoutBrackets: '##### ### ## ##',
            },
        },
    },
    regexp: {
        dataUri: /^data:([a-z]+\/[a-z0-9-+.]+)?;base64,([a-z0-9+/=\s]+)$/i,
        email: /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/gm, // eslint-disable-line
        ibanTr: /TR[a-zA-Z0-9]{2}\s?([0-9]{4}\s?){1}([0-9]{1})([a-zA-Z0-9]{3}\s?)([a-zA-Z0-9]{4}\s?){3}([a-zA-Z0-9]{2})/gm,
        number: /^[0-9]+$/gm,
        phoneNumber: /^([1-9][0-9]{9})$/gm,
        symbol: /[!"#$%&'()*+,-.\/:;<>=?@[\]{}\\^_`|é ~]+$|\?/gm, // eslint-disable-line
        trId: /^[1-9]{1}[0-9]{9}[02468]{1}$/gm,
        text: {
            letter: /^[a-zA-ZşŞÇçÖöüÜıIiİĞğ]+$/gm,
            letterWithSpace: /^[a-zA-ZşŞÇçÖöüÜıIiİĞğ ]+$/gm,
            letterNotTR: /^[a-zA-Z]+$/gm,
            letterWithNumberNotTR: /^[a-zA-Z0-9]+$/gm,
            letterWithNumberAndOneDotNotTR: /^[a-zA-Z0-9]*[a-zA-Z]+[a-zA-Z0-9]*[.][a-zA-Z0-9]*[a-zA-Z]+[a-zA-Z0-9]*$/gm,
            sentence: /^[a-zA-Z0-9şŞÇçÖöüÜıIiİĞğ '.,]+$/gm,
        },
    },
    length: {
        iban: {
            tr: 26,
        },
        trId: 11,
        phone: {
            tr: {
                withZero: 11,
                withoutZero: 10,
            },
        },
        // registryNo = userCode
        registryNo: {
            min: 3,
            max: 10,
        },
        password: {
            min: 8,
            max: 16,
        },
    },
};
