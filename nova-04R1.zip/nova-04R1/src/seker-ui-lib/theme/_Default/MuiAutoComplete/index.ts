import type { Components, Theme } from '@mui/material';
import { alpha, filledInputClasses, outlinedInputClasses } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';
import { importantStyle } from '../../../utils';

export const MuiAutocompleteTheme: Components = {
    MuiAutocomplete: {
        styleOverrides: {
            root: {
                [`& .${generateClass('selectedItems-summary')}`]: {
                    paddingRight: '0px',

                    [`&.outlined`]: {
                        paddingLeft: '8px',
                    },

                    [`&.filled`]: {
                        paddingLeft: '6px',
                    },
                },
                [`& .${filledInputClasses.root}`]: {
                    padding: '0px 0px 0px 10px',
                },
                [`.${outlinedInputClasses.root}`]: {
                    padding: importantStyle('0px'),
                },
            },
            input: ({ ownerState, theme }) => ({
                ...(ownerState.readOnly && {
                    color: alpha((theme as Theme).palette.common.black, 0.38),
                }),
            }),
            endAdornment: {
                '& .disablePopupIconRotate': {
                    transform: 'none',
                },
            },
            listbox: {
                maxHeight: '35vh',
                padding: 0,
            },
            option: ({ theme }) => ({
                minHeight: importantStyle('36px'),
                borderBottom: `1px solid ${(theme as Theme).palette.grey[400]}`,

                '&:last-child': {
                    borderBottom: 'none',
                },

                '&[aria-selected="true"]': {
                    backgroundColor: importantStyle(`${(theme as Theme).palette.grey[300]}`),
                },

                '&:hover[aria-selected="false"]': {
                    backgroundColor: importantStyle(`${alpha((theme as Theme).palette.green.main, 0.1)}`),
                },
            }),
            paper: ({ theme }) => ({
                border: `1px solid ${(theme as Theme).palette.grey[400]}`,
                boxShadow: 'none',
            }),
            popupIndicator: ({ theme }) => ({
                color: (theme as Theme).palette.secondary.main,
                '.Mui-error &': { color: (theme as Theme).palette.error.main },
            }),
            clearIndicator: ({ theme }) => ({
                color: (theme as Theme).palette.secondary.main,
                '.Mui-error &': { color: (theme as Theme).palette.error.main },
            }),
        },
    },
};
