import type { Components } from '@mui/material';

export const MuiCollapseTheme: Components = {
    MuiCollapse: {
        styleOverrides: {
            root: {
                maxWidth: '100%',
            },
        },
    },
};
