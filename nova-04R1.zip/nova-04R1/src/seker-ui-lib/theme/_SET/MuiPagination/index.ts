import type { Components } from '@mui/material';
import { paginationClasses, paginationItemClasses } from '../../..';
import { DesignTypeEnum } from '../../../utils';

export const MuiPaginationTheme: Components = {
    MuiPagination: {
        styleOverrides: {
            root: () => ({
                [`&.${DesignTypeEnum.SET}`]: {
                    padding: '2px',
                    [`.${paginationItemClasses.root}`]: {
                        borderRadius: '4px',
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        height: '22px',
                    },
                    [`.${paginationClasses.ul}`]: {
                        li: {
                            width: '32px',
                        },
                    },
                },
            }),
        },
    },
};
