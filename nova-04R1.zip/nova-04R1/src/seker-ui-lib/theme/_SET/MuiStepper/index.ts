import type { Components, Theme } from '@mui/material';
import { stepIconClasses } from '@mui/material';
import { DesignTypeEnum } from '../../../utils';

export const MuiStepperTheme: Components = {
    MuiStepConnector: {
        styleOverrides: {
            line: ({ theme }) => ({ borderColor: (theme as Theme).palette.grey[400] }),
        },
    },
    MuiStepLabel: {
        styleOverrides: {
            label: ({ theme }) => ({
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                '&.Mui-active, &.Mui-completed': {
                    color: (theme as Theme).palette.common.black,
                },
            }),
            iconContainer: ({ theme }) => ({
                [`.${stepIconClasses.root}`]: {
                    color: (theme as Theme).palette.grey[500],
                    '&.Mui-active, &.Mui-completed': {
                        color: (theme as Theme).palette.secondary.main,
                    },
                },
            }),
        },
    },
};
