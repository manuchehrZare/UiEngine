import type { Components, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

const themeConfig = {
    minWidth: 80,
    iconButton: {
        small: {
            padding: 1,
        },
        medium: {
            padding: 2.5,
        },
        large: {
            padding: 4.5,
        },
    },
    small: {
        minHeight: 20,
        paddingTop: '0.5px',
        paddingBottom: '0.5px',
    },
    medium: {
        minHeight: 24,
        paddingTop: '2.5px',
        paddingBottom: '2.5px',
    },
    large: {
        minHeight: 28,
        paddingTop: '4.5px',
        paddingBottom: '4.5px',
    },
    fontSize: `var(--button-font-size-${DesignTypeEnum.SET})`,
};

export const MuiButtonTheme: Components = {
    MuiButtonGroup: {
        styleOverrides: {
            root: {
                textTransform: 'none',
                fontWeight: 'bold',
                boxShadow: 'none',
            },
        },
    },
    MuiButton: {
        styleOverrides: {
            root: {
                textTransform: 'none',
                fontWeight: 'normal',
                fontSize: themeConfig.fontSize,
                borderRadius: 'var(--border-radius-2)',
                minWidth: themeConfig.minWidth,
                lineHeight: 'normal',
                boxShadow: '1px 3px 4px 0 var(--shadow-1)',
                alignSelf: 'flex-start',

                '&.rounded': {
                    borderRadius: 'var(--border-radius-full) !important',
                },

                '&.left-rounded': {
                    borderTopLeftRadius: 'var(--border-radius-full) !important',
                    borderBottomLeftRadius: 'var(--border-radius-full) !important',
                },

                '&.right-rounded': {
                    borderTopRightRadius: 'var(--border-radius-full) !important',
                    borderBottomRightRadius: 'var(--border-radius-full) !important',
                },

                ':hover': {
                    boxShadow: '1px 3px 4px 0 var(--shadow-1)',
                },
            },
            sizeSmall: {
                ...themeConfig.small,

                '&.MuiButtonGroup-grouped': {
                    paddingTop: themeConfig.small.paddingTop,
                    paddingBottom: themeConfig.small.paddingBottom,
                },

                svg: {
                    width: `calc(${themeConfig.fontSize} + 1px)`,
                    height: `calc(${themeConfig.fontSize} + 1px)`,
                    fontSize: `calc(${themeConfig.fontSize} + 1px) !important`,
                },

                '.btn-loading': {
                    margin: 1,
                    width: `${themeConfig.fontSize} !important`,
                    height: `${themeConfig.fontSize} !important`,

                    svg: {
                        width: `${themeConfig.fontSize} !important`,
                        height: `${themeConfig.fontSize} !important`,
                    },
                },

                '&.btn-no-text': {
                    svg: {
                        margin: 1,
                        width: `calc(${themeConfig.fontSize} + 1px)`,
                        height: `calc(${themeConfig.fontSize} + 1px)`,
                    },

                    '.btn-loading': {
                        svg: {
                            margin: 0,
                        },
                    },
                },

                '&.icon-button': {
                    minWidth: themeConfig.small.minHeight,
                    padding: themeConfig.iconButton.small.padding,
                    '&.MuiButton-outlined': {
                        padding: themeConfig.iconButton.small.padding - 0.5,
                    },
                },
            },
            sizeMedium: {
                ...themeConfig.medium,

                '&.MuiButtonGroup-grouped': {
                    paddingTop: themeConfig.medium.paddingTop,
                    paddingBottom: themeConfig.medium.paddingBottom,
                },

                svg: {
                    width: `calc(${themeConfig.fontSize} + 3px)`,
                    height: `calc(${themeConfig.fontSize} + 3px)`,
                    fontSize: `calc(${themeConfig.fontSize} + 3px) !important`,
                },

                '.btn-loading': {
                    margin: 0.5,
                    width: `calc(${themeConfig.fontSize} + 3px) !important`,
                    height: `calc(${themeConfig.fontSize} + 3px) !important`,

                    svg: {
                        width: `calc(${themeConfig.fontSize} + 3px)`,
                        height: `calc(${themeConfig.fontSize} + 3px)`,
                    },
                },

                '&.btn-no-text': {
                    svg: {
                        margin: 0.5,
                        width: `calc(${themeConfig.fontSize} + 3px)`,
                        height: `calc(${themeConfig.fontSize} + 3px)`,
                    },

                    '.btn-loading': {
                        svg: {
                            margin: 0,
                        },
                    },
                },

                '&.icon-button': {
                    minWidth: themeConfig.medium.minHeight,
                    padding: themeConfig.iconButton.medium.padding,
                },
            },
            sizeLarge: {
                ...themeConfig.large,

                '&.MuiButtonGroup-grouped': {
                    paddingTop: themeConfig.large.paddingTop,
                    paddingBottom: themeConfig.large.paddingBottom,
                },

                svg: {
                    width: `calc(${themeConfig.fontSize} + 4px)`,
                    height: `calc(${themeConfig.fontSize} + 4px)`,
                    fontSize: `calc(${themeConfig.fontSize} + 4px) !important`,
                },

                '.btn-loading': {
                    width: `calc(${themeConfig.fontSize} + 4px) !important`,
                    height: `calc(${themeConfig.fontSize} + 4px) !important`,

                    svg: {
                        width: `calc(${themeConfig.fontSize} + 4px)`,
                        height: `calc(${themeConfig.fontSize} + 4px)`,
                    },
                },

                '&.btn-no-text': {
                    svg: {
                        width: `calc(${themeConfig.fontSize} + 4px)`,
                        height: `calc(${themeConfig.fontSize} + 4px)`,
                    },
                },

                '&.icon-button': {
                    minWidth: themeConfig.large.minHeight,
                    padding: themeConfig.iconButton.large.padding,
                },
            },
            outlinedPrimary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.primary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.primary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.primary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.primary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.primary.light, 0.3),
                    },
                },
            }),
            outlinedSecondary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.secondary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.secondary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.secondary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.secondary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.secondary.light, 0.3),
                    },
                },
            }),
            outlinedError: ({ theme }) => ({
                borderColor: (theme as Theme).palette.error.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.error.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.error.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.error.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.error.light, 0.3),
                    },
                },
            }),
            outlinedInfo: ({ theme }) => ({
                borderColor: (theme as Theme).palette.info.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.info.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.info.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.info.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.info.light, 0.3),
                    },
                },
            }),
            outlinedWarning: ({ theme }) => ({
                borderColor: (theme as Theme).palette.warning.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.warning.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.warning.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.warning.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.warning.light, 0.3),
                    },
                },
            }),
            outlinedSuccess: ({ theme }) => ({
                borderColor: (theme as Theme).palette.success.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.success.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.success.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.success.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.success.light, 0.3),
                    },
                },
            }),
            outlinedInherit: ({ theme }) => ({
                borderColor: (theme as Theme).palette.grey[700],

                '.btn-loading': {
                    color: (theme as Theme).palette.grey[500],
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.grey[700], 0.6),
                    borderColor: alpha((theme as Theme).palette.grey[700], 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.grey[500], 0.3),
                    },
                },
            }),
            containedPrimary: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.primary.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.primary.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.primary.light, 0.4),
                    },
                },
            }),
            containedSecondary: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.secondary.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.secondary.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.secondary.light, 0.4),
                    },
                },
            }),
            containedError: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.error.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.error.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.error.light, 0.4),
                    },
                },
            }),
            containedInfo: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.info.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.info.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.info.light, 0.4),
                    },
                },
            }),
            containedWarning: ({ theme }) => ({
                color: (theme as Theme).palette.common.white,

                '.btn-loading': {
                    color: (theme as Theme).palette.warning.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.warning.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.warning.light, 0.4),
                    },
                },
            }),
            containedSuccess: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.success.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.common.white, 0.6),
                    backgroundColor: alpha((theme as Theme).palette.success.main, 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.success.light, 0.4),
                    },
                },
            }),
            containedInherit: ({ theme }) => ({
                '.btn-loading': {
                    color: (theme as Theme).palette.grey[500],
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.grey[700], 0.6),
                    backgroundColor: alpha((theme as Theme).palette.grey[500], 0.4),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.grey[500], 0.4),
                    },
                },
            }),
            text: {
                boxShadow: 'none',
                ':hover': {
                    boxShadow: 'none',
                },
            },
            textError: ({ theme }) => ({
                borderColor: (theme as Theme).palette.error.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.error.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.error.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.error.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.error.light, 0.4),
                    },
                },
            }),
            textPrimary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.primary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.primary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.primary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.primary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.primary.light, 0.3),
                    },
                },
            }),
            textSecondary: ({ theme }) => ({
                borderColor: (theme as Theme).palette.secondary.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.secondary.light,
                },

                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.secondary.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.secondary.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.secondary.light, 0.3),
                    },
                },
            }),
            textInfo: ({ theme }) => ({
                borderColor: (theme as Theme).palette.info.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.info.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.info.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.info.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.info.light, 0.4),
                    },
                },
            }),
            textWarning: ({ theme }) => ({
                borderColor: (theme as Theme).palette.warning.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.warning.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.warning.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.warning.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.warning.light, 0.4),
                    },
                },
            }),
            textSuccess: ({ theme }) => ({
                borderColor: (theme as Theme).palette.success.main,

                '.btn-loading': {
                    color: (theme as Theme).palette.success.light,
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.success.main, 0.6),
                    borderColor: alpha((theme as Theme).palette.success.main, 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.success.light, 0.4),
                    },
                },
            }),
            textInherit: ({ theme }) => ({
                borderColor: (theme as Theme).palette.grey[700],

                '.btn-loading': {
                    color: (theme as Theme).palette.grey[500],
                },
                '&.Mui-disabled': {
                    color: alpha((theme as Theme).palette.grey[700], 0.6),
                    borderColor: alpha((theme as Theme).palette.grey[700], 0.3),

                    '.btn-loading': {
                        color: alpha((theme as Theme).palette.grey[500], 0.4),
                    },
                },
            }),
        },
    },
};
