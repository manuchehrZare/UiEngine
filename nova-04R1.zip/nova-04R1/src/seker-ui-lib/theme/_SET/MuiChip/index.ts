import type { Components, Theme } from '@mui/material';
import { avatarClasses } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import { chipClasses } from '../../..';

export const MuiChipTheme: Components = {
    MuiChip: {
        defaultProps: {
            color: 'primary',
        },
        styleOverrides: {
            root: () => ({
                fontSize: 12,
                fontWeight: 'bold',
                height: 'auto',
                paddingTop: '0.5px',
                paddingBottom: '0.5px',
                borderRadius: 'var(--border-radius-full)',
                [`.${chipClasses.label}`]: {
                    display: 'block',
                    whiteSpace: 'normal',
                    paddingRight: '9px',
                },
                [`&.${chipClasses.corneredLeft}`]: {
                    borderTopLeftRadius: 'var(--border-radius-2)',
                    borderBottomLeftRadius: 'var(--border-radius-2)',
                },
                [`&.${chipClasses.corneredRight}`]: {
                    borderTopRightRadius: 'var(--border-radius-2)',
                    borderBottomRightRadius: 'var(--border-radius-2)',
                },
                [`&.${chipClasses.cornered}`]: {
                    borderRadius: 'var(--border-radius-2)',
                },
            }),
            sizeSmall: {
                minHeight: '20px',
                [`.${chipClasses.icon}`]: {
                    marginLeft: '8px',
                    marginRight: '-3px',
                },
                [`.${avatarClasses.circular}`]: {
                    width: '14px',
                    height: '14px',
                },
            },
            sizeMedium: {
                minHeight: '24px',
                [`.${chipClasses.icon}`]: {
                    marginLeft: '8px',
                    marginRight: '-6px',
                },
                [`.${avatarClasses.circular}`]: {
                    width: '18px',
                    height: '18px',
                },
            },
            icon: () => ({
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 5px) !important`,
            }),
            deleteIcon: () => ({
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 5px) !important`,
            }),
            filled: ({ theme, ownerState }) => ({
                color: (theme as Theme).palette.common.white,
                [`.${chipClasses.avatar}`]: {
                    color: ((theme as Theme).palette as any)[
                        (ownerState as any).color || (theme as Theme).components?.MuiChip?.defaultProps?.color
                    ].main,
                    backgroundColor: ((theme as Theme).palette as any)[
                        (ownerState as any).color || (theme as Theme).components?.MuiChip?.defaultProps?.color
                    ][100],
                    ...(ownerState.color === 'primary' && {
                        color: (theme as Theme).palette.primary.main,
                        backgroundColor: (theme as Theme).palette.primary[400],
                    }),
                },
                [`.${chipClasses.deleteIcon}`]: {
                    ...(ownerState.color === 'warning' && {
                        color: (theme as Theme).palette.warning[50],
                    }),
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    ...(ownerState.color === 'warning' && {
                        color: (theme as Theme).palette.common.white,
                    }),
                },
            }),
            outlined: ({ theme, ownerState }) => ({
                backgroundColor: (theme as Theme).palette.common.white,
                [`.${chipClasses.avatar}`]: {
                    color: ((theme as Theme).palette as any)[
                        (ownerState as any).color || (theme as Theme).components?.MuiChip?.defaultProps?.color
                    ].main,
                    backgroundColor: ((theme as Theme).palette as any)[
                        (ownerState as any).color || (theme as Theme).components?.MuiChip?.defaultProps?.color
                    ][100],
                    ...(ownerState.color === 'primary' && {
                        color: (theme as Theme).palette.primary.main,
                        backgroundColor: (theme as Theme).palette.primary[400],
                    }),
                },

                [`.${chipClasses.deleteIcon}`]: {
                    color: ((theme as Theme).palette as any)[
                        (ownerState as any).color || (theme as Theme).components?.MuiChip?.defaultProps?.color
                    ].main,
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    color: ((theme as Theme).palette as any)[
                        (ownerState as any).color || (theme as Theme).components?.MuiChip?.defaultProps?.color
                    ][200],
                    ...(ownerState.color === 'primary' && {
                        color: (theme as Theme).palette.primary[500],
                    }),
                },
            }),
            colorPrimary: ({ theme, ownerState }) => ({
                ...(ownerState.variant === 'standard' && {
                    color: (theme as Theme).palette.primary.main,
                    backgroundColor: (theme as Theme).palette.primary[300],
                }),
                [`.${chipClasses.deleteIcon}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.primary.main,
                    }),
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.primary[500],
                    }),
                },
                [`.${chipClasses.avatar}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.primary[300],
                        backgroundColor: (theme as Theme).palette.primary.main,
                    }),
                },
            }),
            colorError: ({ theme, ownerState }) => ({
                ...(ownerState.variant === 'standard' && {
                    color: (theme as Theme).palette.error.main,
                    backgroundColor: (theme as Theme).palette.error[50],
                }),
                [`.${chipClasses.deleteIcon}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.error.main,
                    }),
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.error[300],
                    }),
                },
                [`.${chipClasses.avatar}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.error[50],
                        backgroundColor: (theme as Theme).palette.error.main,
                    }),
                },
            }),
            colorInfo: ({ theme, ownerState }) => ({
                ...(ownerState.variant === 'standard' && {
                    color: (theme as Theme).palette.info.main,
                    backgroundColor: (theme as Theme).palette.info[50],
                }),
                [`.${chipClasses.deleteIcon}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.info.main,
                    }),
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.info[300],
                    }),
                },
                [`.${chipClasses.avatar}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.info[50],
                        backgroundColor: (theme as Theme).palette.info.main,
                    }),
                },
            }),
            colorSuccess: ({ theme, ownerState }) => ({
                ...(ownerState.variant === 'standard' && {
                    color: (theme as Theme).palette.success.main,
                    backgroundColor: (theme as Theme).palette.success[50],
                }),
                [`.${chipClasses.deleteIcon}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.success.main,
                    }),
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.success[300],
                    }),
                },
                [`.${chipClasses.avatar}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.success[50],
                        backgroundColor: (theme as Theme).palette.success.main,
                    }),
                },
            }),
            colorWarning: ({ theme, ownerState }) => ({
                ...(ownerState.variant === 'standard' && {
                    color: (theme as Theme).palette.warning.main,
                    backgroundColor: (theme as Theme).palette.warning[50],
                }),
                [`.${chipClasses.deleteIcon}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.warning.main,
                    }),
                },
                [`.${chipClasses.deleteIcon}:hover`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.warning[300],
                    }),
                },
                [`.${chipClasses.avatar}`]: {
                    ...(ownerState.variant === 'standard' && {
                        color: (theme as Theme).palette.warning[50],
                        backgroundColor: (theme as Theme).palette.warning.main,
                    }),
                },
            }),
        },
    },
};
