import type { PaletteColor, PaletteColorOptions, PaletteOptions } from '@mui/material';
//new palette type
declare module '@mui/material' {
    interface Palette {
        dark: Color;
        green: PaletteColor;
        lightGrey: PaletteColor;
        slateGreen: PaletteColor;
    }

    interface PaletteOptions {
        dark?: Partial<Color>;
        green?: PaletteColorOptions;
        lightGrey?: PaletteColorOptions;
        slateGreen?: PaletteColorOptions;
    }

    interface PaletteColor extends Omit<Partial<Color>, 'A100' | 'A200' | 'A400' | 'A700'> {}
}

export interface CustomPaletteColorOptions extends Omit<PaletteColor, 'contrastText'> {}

interface CustomPaletteOptions extends PaletteOptions {
    dark: Pick<CustomPaletteColorOptions, 50 | 100>;
    error: CustomPaletteColorOptions;
    green: CustomPaletteColorOptions;
    grey: Omit<CustomPaletteColorOptions, 'light' | 'main' | 'dark'>;
    info: CustomPaletteColorOptions;
    lightGrey: CustomPaletteColorOptions;
    primary: CustomPaletteColorOptions;
    secondary: CustomPaletteColorOptions;
    slateGreen: CustomPaletteColorOptions;
    success: CustomPaletteColorOptions;
    warning: CustomPaletteColorOptions;
}

export const palette: CustomPaletteOptions = {
    primary: {
        light: '#7f8489',
        main: '#4b4f54',
        dark: '#292d31',
        '50': '#f8fdff',
        '100': '#f3f8fe',
        '200': '#eef3f9',
        '300': '#e8edf3',
        '400': '#c7cbd1',
        '500': '#a9aeb4',
        '600': '#7f8489',
        '700': '#6b6f74',
        '800': '#4b4f54',
        '900': '#292d31',
    },
    secondary: {
        main: '#007a3d',
        dark: '#005b29',
        light: '#189d54',
        '50': '#e5f5eb',
        '100': '#c1e5cd',
        '200': '#99d5ad',
        '300': '#6ec58d',
        '400': '#4bb875',
        '500': '#21ac5e',
        '600': '#189d54',
        '700': '#0b8b48',
        '800': '#007a3d',
        '900': '#005b29',
    },
    info: {
        main: '#139db9',
        dark: '#006773',
        light: '#33CCEE',
        '50': '#e2f8ff',
        '100': '#b5edfb',
        '200': '#85e1f9',
        '300': '#55d5f3',
        '400': '#33CCEE',
        '500': '#23c3e9',
        '600': '#1db2d4',
        '700': '#139db9',
        '800': '#098aa0',
        '900': '#006773',
    },
    error: {
        main: '#D9191E',
        dark: '#be0007',
        light: '#f54843',
        '50': '#FCF4F4',
        '100': '#ffcbcf',
        '200': '#f49694',
        '300': '#eb6c6a',
        '400': '#f54843',
        '500': '#f93424',
        '600': '#eb2725',
        '700': '#D9191E',
        '800': '#cc0c18',
        '900': '#be0007',
    },
    success: {
        main: '#00993f',
        dark: '#00681f',
        light: '#4fc66f',
        '50': '#e6f7ea',
        '100': '#c4eacc',
        '200': '#9dddab',
        '300': '#72d089',
        '400': '#4fc66f',
        '500': '#22BB55',
        '600': '#16ab4b',
        '700': '#00993f',
        '800': '#008834',
        '900': '#00681f',
    },
    warning: {
        main: '#EE7700',
        dark: '#de4d01',
        light: '#f9a225',
        '50': '#fef2e0',
        '100': '#fddeb1',
        '200': '#fcc97e',
        '300': '#fab34b',
        '400': '#f9a225',
        '500': '#f89200',
        '600': '#f48700',
        '700': '#EE7700',
        '800': '#e86700',
        '900': '#de4d01',
    },
    grey: {
        '50': '#fafafa',
        '100': '#f4f4f4',
        '200': '#ececec',
        '300': '#dddddd',
        '400': '#DBDBDB',
        '500': '#9b9b9b',
        '600': '#727272',
        '700': '#5E5E5E',
        '800': '#3f3f3f',
        '900': '#1e1e1e',
    },
    lightGrey: {
        dark: '#bbc5d2',
        light: '#1f2831',
        main: '#606974',
        '50': '#f2fcff',
        '100': '#edf7ff',
        '200': '#e8f2ff',
        '300': '#dde7f5',
        '400': '#bbc5d2',
        '500': '#9da7b3',
        '600': '#747D89',
        '700': '#606974',
        '800': '#414954',
        '900': '#1f2831',
    },
    green: {
        main: '#7db900',
        dark: '#599600',
        light: '#c3da0d',
        '50': '#D3E6E0',
        '100': '#daeabc',
        '200': '#c0db91',
        '300': '#a7cd63',
        '400': '#92C33D',
        '500': '#7DB900',
        '600': '#6faa00',
        '700': '#599600',
        '800': '#438300',
        '900': '#146200',
    },
    slateGreen: {
        dark: '#3d4945',
        light: '#DAE2DE',
        main: '#5f746c',
        '50': '#EFF3F1',
        '100': '#DAE2DE',
        '200': '#c1cfc9',
        '300': '#a7bbb3',
        '400': '#92aaa1',
        '500': '#7d9a8f',
        '600': '#718a7f',
        '700': '#5f746c',
        '800': '#50605a',
        '900': '#3d4945',
    },
    dark: {
        '50': '#00000080',
        '100': '#000000b3',
    },
    common: {
        white: '#fff',
        black: '#000',
    },
};
