import type { Theme } from '@mui/material';
import { ThemeProvider as MuiThemeProvider } from '@mui/material';
import type { FC } from 'react';
import { memo } from 'react';
import { theme as DefaultTheme } from '../../../theme';
import DefaultComponentsTheme from '../../../theme/_Default';
import SETComponentsTheme from '../../../theme/_SET';
import type { DesignType, ICommonProps } from '../../../utils/types/common';
import { DesignTypeEnum } from '../../../utils/types/common';
import { deepmerge } from '../../../utils/methods';

interface IThemeProvider extends ICommonProps {
    children: any;
    theme?: Partial<Theme> | null;
}

const ThemeProvider: FC<IThemeProvider> = ({ children, design, theme }) => {
    const getTheme = (type: DesignType): Theme => {
        const themes = {
            [DesignTypeEnum.Default]: DefaultComponentsTheme,
            [DesignTypeEnum.SET]: SETComponentsTheme,
        };
        return deepmerge(DefaultTheme, deepmerge({ components: themes[type] }, theme));
    };

    // eslint-disable-next-line react/jsx-no-useless-fragment
    return design ? <MuiThemeProvider theme={getTheme(design)}>{children}</MuiThemeProvider> : <>{children}</>;
};

export default memo(ThemeProvider);
