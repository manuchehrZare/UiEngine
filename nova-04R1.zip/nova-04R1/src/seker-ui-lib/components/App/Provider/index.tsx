import { ErrorOutline, InfoOutlined, TaskAltOutlined, WarningAmberOutlined } from '@mui/icons-material';
import type { Theme } from '@mui/material';
import { CssBaseline } from '@mui/material';
import GlobalStyles from '@mui/material/GlobalStyles';
import { isNull, merge, omit } from 'lodash';
import type { SnackbarProviderProps } from 'notistack';
import type { FC, ReactNode } from 'react';
import { memo, useEffect } from 'react';
import type { ILoadingModalProps } from '../../..';
import {
    theme as DefaultTheme,
    LoadingModal,
    View,
    constants,
    removeProviderDesign,
    setProviderDesign,
    useIsFirstRender,
    useStorage,
} from '../../..';
import { getCssGlobal } from '../../../theme/_css_global';
import { getHelpers } from '../../../theme/_css_helper';
import { getRootStyle } from '../../../theme/_css_root';
import { getComponentDesignProperty } from '../../../utils';
import { removeProviderTheme, setProviderTheme } from '../../../utils/methods/theme';
import type { DesignType, ICommonProps } from '../../../utils/types/common';
import SnackbarProvider from '../SnackbarProvider';
import ThemeProvider from '../ThemeProvider';

export interface IProviderProps extends ICommonProps {
    children: ReactNode;
    globalStyles?: object;
    loadingProps?: ILoadingModalProps & { keepMounted?: boolean };
    messageProviderProps?: SnackbarProviderProps;
    theme?: Partial<Theme>;
}

const Provider: FC<IProviderProps> = ({
    children,
    design,
    globalStyles,
    loadingProps,
    messageProviderProps,
    theme,
}) => {
    const isFirstRender = useIsFirstRender();
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });

    useEffect(() => {
        /**
         * - StorageDesign degerinin silinme isleminde elde ettigi "null" degeri kontrolune gore oldValue setlenerek kaldigi yerden devam ettirilir.
         * - oldValue degeri de "null" ise design degeri setlenir. design degeri de tanimli degilse getComponentDesignProperty metodundan default design degeri setlenir.
         */
        if (isNull(storageDesign.newValue)) {
            setProviderDesign(getComponentDesignProperty(storageDesign.oldValue || design, storageDesign.newValue));
        }
    }, [design, storageDesign]);

    useEffect(() => {
        /**
         * - Design props degeri her degistiginde yeni bir design degeri setleniyor.
         * - Sayfa yenileme isleminde isFirstRender ile ilk render ani degilse ve her iki(old, new) storage degeri dolu ise props.design degeri yerine storage degeri setlenerek calisma kaldigi yerden devam ettirilir.
         * - design degeri undefined ise storageDesign.oldValue dolu ise o deger setlenir. storageDesign.oldValue dolu degilse getComponentDesignProperty metodundan defaultDesign degeri setlenir.
         */
        setProviderDesign(
            getComponentDesignProperty(
                !isFirstRender && !isNull(storageDesign.newValue) && !isNull(storageDesign.oldValue)
                    ? storageDesign.oldValue
                    : design,
                storageDesign.oldValue,
            ),
        );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [design]);

    useEffect(() => {
        theme ? setProviderTheme(theme) : removeProviderTheme();
    }, [theme]);

    useEffect(() => {
        return () => removeProviderDesign();
    }, []);

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue || storageDesign.oldValue)}
            theme={theme}>
            <CssBaseline />
            <GlobalStyles styles={{ ...merge(getRootStyle(), getCssGlobal(), getHelpers(), globalStyles) }} />
            <SnackbarProvider
                maxSnack={Infinity}
                iconVariant={{
                    error: <ErrorOutline fontSize="small" sx={{ marginInlineEnd: 1 }} />,
                    info: <InfoOutlined fontSize="small" sx={{ marginInlineEnd: 1 }} />,
                    success: <TaskAltOutlined fontSize="small" sx={{ marginInlineEnd: 1 }} />,
                    warning: <WarningAmberOutlined fontSize="small" sx={{ marginInlineEnd: 1 }} />,
                    ...messageProviderProps?.iconVariant,
                }}
                {...omit(messageProviderProps, ['iconVariant'])}>
                <View show={Boolean(loadingProps?.keepMounted)}>
                    <LoadingModal
                        id={constants.key.PROVIDER_LOADING_ID}
                        hidden
                        {...omit(loadingProps, ['keepMounted'])}
                    />
                </View>
                {children}
            </SnackbarProvider>
        </ThemeProvider>
    );
};

/* istanbul ignore next*/
if (typeof window !== 'undefined' && import.meta.env.NODE_ENV !== 'test') {
    // eslint-disable-next-line no-console
    console.log(
        `%cSekerUI \n%cThis library is developed by Şekerbank A.Ş. Software Development Team. \n`,
        `font-size: 35px; color: ${DefaultTheme.palette.green.main}; font-weight: bold; text-shadow: 2px 0 0 ${DefaultTheme.palette.secondary.main}, -2px 0 0 ${DefaultTheme.palette.secondary.main}, 0 2px 0 ${DefaultTheme.palette.secondary.main}, 0 -2px 0 ${DefaultTheme.palette.secondary.main}, 1px 1px ${DefaultTheme.palette.secondary.main}`,
        `font-size: 11px; color: ${DefaultTheme.palette.secondary.main}; font-weight: bold;`,
    );
}

export default memo(Provider);
