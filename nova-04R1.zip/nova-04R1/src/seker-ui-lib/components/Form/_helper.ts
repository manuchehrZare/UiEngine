import type { MenuProps } from '@mui/material';
import { DesignTypeEnum } from '../../utils/types/common';

export const SelectMenuProps: Partial<MenuProps> = {
    PaperProps: {
        className: 'select-dropdown-menu-container',
        style: { maxHeight: 300 },
    },
    anchorOrigin: {
        vertical: 'bottom',
        horizontal: 'left',
    },
    transformOrigin: {
        vertical: 'top',
        horizontal: 'left',
    },
};

export const defaultDatePickerSeparator = {
    [DesignTypeEnum.Default]: '.',
    [DesignTypeEnum.SET]: '.',
};

export const defaultTimePickerSeparator = {
    [DesignTypeEnum.Default]: ':',
    [DesignTypeEnum.SET]: ':',
};

export const pickerProps = {
    default: {
        datePicker: {
            dateSeparator: defaultDatePickerSeparator.default,
            mask: `__${defaultDatePickerSeparator.default}__${defaultDatePickerSeparator.default}____`,
            inputFormat: `dd${defaultDatePickerSeparator.default}MM${defaultDatePickerSeparator.default}yyyy`,
        },
        dateTimePicker: {
            dateSeparator: defaultDatePickerSeparator.default,
            timeSeparator: defaultTimePickerSeparator.default,
            mask: `__${defaultDatePickerSeparator.default}__${defaultDatePickerSeparator.default}____ __${defaultTimePickerSeparator.default}__${defaultTimePickerSeparator.default}__`,
            inputFormat: `dd${defaultDatePickerSeparator.default}MM${defaultDatePickerSeparator.default}yyyy HH${defaultTimePickerSeparator.default}mm`,
        },
        timePicker: {
            timeSeparator: defaultTimePickerSeparator.default,
            mask: `__${defaultTimePickerSeparator.default}__${defaultTimePickerSeparator.default}__`,
            inputFormat: `HH${defaultTimePickerSeparator.default}mm`,
        },
    },
    SET: {
        datePicker: {
            dateSeparator: defaultDatePickerSeparator.SET,
            mask: `__${defaultDatePickerSeparator.SET}__${defaultDatePickerSeparator.SET}____`,
            inputFormat: `dd${defaultDatePickerSeparator.SET}MM${defaultDatePickerSeparator.SET}yyyy`,
        },
        dateTimePicker: {
            dateSeparator: defaultDatePickerSeparator.SET,
            timeSeparator: defaultTimePickerSeparator.SET,
            mask: `__${defaultDatePickerSeparator.SET}__${defaultDatePickerSeparator.SET}____ __${defaultTimePickerSeparator.SET}__${defaultTimePickerSeparator.SET}__`,
            inputFormat: `dd${defaultDatePickerSeparator.SET}MM${defaultDatePickerSeparator.SET}yyyy HH${defaultTimePickerSeparator.SET}mm${defaultTimePickerSeparator.SET}ss`,
        },
        timePicker: {
            timeSeparator: defaultTimePickerSeparator.SET,
            mask: `__${defaultTimePickerSeparator.SET}__${defaultTimePickerSeparator.SET}__`,
            inputFormat: `HH${defaultTimePickerSeparator.SET}mm${defaultTimePickerSeparator.SET}ss`,
        },
    },
};
