import Default from './DefaultInput';
import SET from './SETInput';
import type { FC } from 'react';
import { memo } from 'react';
import type { IInputProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const Input: FC<IInputProps> = ({
    design,
    autoComplete = 'off',
    fullWidth = true,
    hidden = false,
    labelEllipsis = true,
    labelPlacement = 'top',
    maskChar = '_',
    readOnly = false,
    size = 'medium',
    variant = 'outlined',
    capslockDetector = false,
    ...rest
}: IInputProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: (
            <Default
                variant={variant}
                autoComplete={autoComplete}
                fullWidth={fullWidth}
                hidden={hidden}
                labelEllipsis={labelEllipsis}
                labelPlacement={labelPlacement}
                maskChar={maskChar}
                readOnly={readOnly}
                size={size}
                capslockDetector={capslockDetector}
                {...rest}
            />
        ),
        [DesignTypeEnum.SET]: (
            <SET
                autoComplete={autoComplete}
                fullWidth={fullWidth}
                hidden={hidden}
                labelEllipsis={labelEllipsis}
                labelPlacement={labelPlacement}
                maskChar={maskChar}
                readOnly={readOnly}
                size={size}
                variant={variant}
                capslockDetector={capslockDetector}
                {...rest}
            />
        ),
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default memo(Input);
