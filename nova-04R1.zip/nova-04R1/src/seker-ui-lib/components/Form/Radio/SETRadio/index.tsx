import type { FC } from 'react';
import { FormControl, FormHelperText, FormControlLabel, Radio as MuiRadio } from '@mui/material';
import type { IRadioProps } from '../type';
import { DesignTypeEnum } from '../../../../utils/types/common';
import { generateClass, manageClassNames } from '../../../../utils';

const Radio: FC<IRadioProps> = ({
    helperText,
    disabled,
    checkedIcon,
    icon,
    label,
    color,
    value,
    onChange,
    size,
    required,
    className,
    sx,
    ...rest
}: IRadioProps) => {
    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };
    return (
        <FormControl className={generateClass('Radio-formControl')} disabled={disabled} size={size} sx={sx}>
            <FormControlLabel
                disabled={disabled}
                value={value}
                label={getLabel()}
                className={manageClassNames(generateClass('Radio-label'), `${DesignTypeEnum.SET}`, className)}
                control={
                    <MuiRadio
                        className={DesignTypeEnum.SET}
                        color={color}
                        disabled={disabled}
                        inputProps={{ 'aria-label': label, role: 'radio' }}
                        size={size}
                        icon={icon || <span className={`icon-${DesignTypeEnum.SET}`} />}
                        checkedIcon={checkedIcon || <span className={`checked-icon-${DesignTypeEnum.SET}`} />}
                        onChange={(event, checked) => {
                            onChange?.(event, checked);
                        }}
                        {...rest}
                    />
                }
            />
            {helperText && (
                <FormHelperText
                    className={manageClassNames(generateClass('HelperText'), 'radio', DesignTypeEnum.SET, `${size}`)}>
                    {helperText}
                </FormHelperText>
            )}
        </FormControl>
    );
};

export default Radio;
