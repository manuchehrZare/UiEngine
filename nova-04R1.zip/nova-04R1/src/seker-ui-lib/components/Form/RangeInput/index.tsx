import type { FC } from 'react';
import { memo } from 'react';
import type { Theme } from '@mui/material';
import { FormControl, FormControlLabel, FormHelperText, Slider } from '@mui/material';
import type { IRangeInputProps } from './type';
import { useController } from 'react-hook-form';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';
import { isNumber } from 'lodash';

const RangeInput: FC<IRangeInputProps> = ({
    name,
    control,
    size,
    label,
    color = 'secondary',
    design,
    helperText,
    labelPlacement = 'top',
    labelEllipsis = true,
    labelWidth,
    orientation,
    sx,
    className,
    deps,
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const {
        field,
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const getLabelWidth = () => {
        return labelWidth !== 'auto' && labelWidth
            ? isNumber(labelWidth)
                ? `${labelWidth}px`
                : labelWidth
            : `var(--field-label-width-${[getComponentDesignProperty(design, storageDesign.newValue)]})`;
    };

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <FormControl
                fullWidth={orientation === 'vertical' ? false : true}
                className={manageClassNames(generateClass('RangeInput'), className, {
                    [constants.classNames.labelEllipsis]: labelEllipsis,
                })}
                size={size}
                error={Boolean(error) && validationControl}
                sx={sx}>
                <FormControlLabel
                    label={label}
                    title={label}
                    labelPlacement={labelPlacement}
                    className={manageClassNames(
                        generateClass('RangeInput-label'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                        className,
                        { [constants.classNames.labelEllipsis]: labelEllipsis },
                    )}
                    componentsProps={{
                        typography: { className: generateClass('RangeInput-label-label') },
                    }}
                    sx={{
                        [`.${generateClass('RangeInput-label-label')}`]: {
                            ...(labelPlacement === 'start' && {
                                minWidth: getLabelWidth(),
                                width: getLabelWidth(),
                            }),
                        },
                    }}
                    control={<Slider {...field} size={size} orientation={orientation} color={color} {...rest} />}
                />
                {(error?.message || helperText) && (
                    <FormHelperText
                        className={manageClassNames(
                            generateClass('HelperText'),
                            'range-input',
                            getComponentDesignProperty(design, storageDesign.newValue),
                        )}
                        sx={{
                            ml: 0,
                            ...(labelPlacement === 'start' && {
                                ml: getLabelWidth(),
                            }),
                            ...(orientation === 'vertical' && {
                                mt: 1.25,
                            }),
                        }}>
                        {(validationControl && error?.message) || helperText}
                    </FormHelperText>
                )}
            </FormControl>
        </ThemeProvider>
    );
};

export default memo(RangeInput);
