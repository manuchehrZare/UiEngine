import type { SxProps, Theme } from '@mui/material';
import type { FilePondErrorDescription, FilePondFile } from 'filepond';
import type { UseFormReturnType } from '../../../hooks/useForm';
import type { ICommonFieldProps, IFormCommonControl } from '../commonTypes';

export interface IDocumentDetail {
    Extension: string;
    FileName: string;
    FolderId: string;
    Id: string;
    LatestVersion: any;
    Path: string;
    Size: number;
    UserList: any;
}

export interface IUploadDocument {
    Date?: number;
    DMSId: string;
    DocumentName: string;
    DocumentPath: string;
    DocumentSize: number;
    Version?: string;
}

export interface IUploadProps
    extends
        IFormCommonControl<any>,
        Pick<ICommonFieldProps, 'design' | 'labelEllipsis' | 'variant' | 'helperText' | 'name'>,
        Required<Pick<UseFormReturnType<any>, 'setValue'>> {
    acceptedFileTypes?: any[];
    allowImagePreview?: boolean;
    apiUrl: string;
    button?: string;
    chunkForce?: boolean;
    chunkRetryDelays?: number[];
    chunkSize?: number;
    chunkUploads?: boolean;
    destroy?: boolean;
    errorText?: string;
    fileName?: string;
    getPath?: (path: string) => void;
    id?: any;
    instantUpload?: boolean;
    itemInsertLocation?: 'before' | 'after';
    label?: string;
    maxSize?: number;
    multiple?: boolean;
    onChange?: (document: IUploadDocument) => void;
    onError?: (err: FilePondErrorDescription, file?: FilePondFile) => void;
    onRef?: (e: any) => void;
    onRemove?: (document: IUploadDocument) => void;
    path?: string;
    required?: boolean;
    sx?: SxProps<Theme>;
    token: string;
    type?: string;
}

export enum FileInsertLocationEnum {
    AFTER = 'after',
    BEFORE = 'before',
}

export enum FileGenerateTypeEnum {
    LOCAL = 0,
    FORM = 1,
}
