import type { FC } from 'react';
import { memo } from 'react';
import { useController } from 'react-hook-form';
import type { Theme } from '@mui/material';
import { FormControl, FormHelperText, FormLabel, RadioGroup as MuiRadioGroup } from '@mui/material';
import type { IRadioGroupProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import { isNumber } from 'lodash';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const RadioGroup: FC<IRadioGroupProps> = ({
    helperText,
    name,
    label,
    labelPlacement = 'top',
    labelEllipsis = true,
    labelWidth,
    control,
    children,
    onChange,
    design,
    sx,
    deps,
    fullWidth,
    ...rest
}: IRadioGroupProps) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const {
        field,
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <FormControl
                className={manageClassNames(
                    generateClass('RadioGroup-formControl'),
                    { 'label-active': Boolean(label) },
                    `radio-group-labelPlacement-${labelPlacement}`,
                    {
                        [`${labelWidth}`]: Boolean(labelWidth),
                        [constants.classNames.labelEllipsis]: labelEllipsis,
                    },
                )}
                error={Boolean(error) && validationControl}
                fullWidth={fullWidth}
                sx={sx}>
                {label && (
                    <FormLabel
                        sx={{
                            width:
                                /* istanbul ignore next */
                                labelPlacement === 'top'
                                    ? labelWidth || '100%'
                                    : labelWidth || `var(--field-label-width-${[DesignTypeEnum.SET]})`,
                        }}
                        className={manageClassNames(
                            generateClass('RadioGroup-label'),
                            'custom-radio-group-label',
                            getComponentDesignProperty(design, storageDesign.newValue),
                            { [constants.classNames.labelEllipsis]: labelEllipsis },
                        )}
                        title={label}>
                        {label}
                    </FormLabel>
                )}
                <MuiRadioGroup
                    {...field}
                    {...rest}
                    onChange={(event, value) => {
                        onChange?.(event, value);
                        field.onChange(value);
                    }}>
                    {children}
                </MuiRadioGroup>
                {(error || helperText) && (
                    <FormHelperText
                        sx={{
                            marginLeft:
                                /* istanbul ignore next */
                                label && labelPlacement === 'start'
                                    ? labelWidth
                                        ? isNumber(labelWidth)
                                            ? `${labelWidth}px !important`
                                            : `${labelWidth} !important`
                                        : `var(--field-label-width-${[DesignTypeEnum.SET]}) !important`
                                    : '0',
                        }}
                        className={manageClassNames(
                            generateClass('HelperText'),
                            'radio-group',
                            getComponentDesignProperty(design, storageDesign.newValue),
                        )}>
                        {(validationControl && error?.message) || helperText}
                    </FormHelperText>
                )}
            </FormControl>
        </ThemeProvider>
    );
};

export default memo(RadioGroup);
