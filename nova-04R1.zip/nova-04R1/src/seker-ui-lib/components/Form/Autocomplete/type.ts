import type { TextFieldProps, AutocompleteProps } from '@mui/material';
import type { ISelectOptions } from '../Select/type';
import type { ICommonFieldProps } from '../commonTypes';
import type { ReactNode } from 'react';

export interface IAutocompleteOptions<T> extends ISelectOptions<T> {}
export interface IAutocompleteProps<T>
    extends
        Pick<
            TextFieldProps,
            | 'autoComplete'
            | 'autoFocus'
            | 'className'
            | 'color'
            | 'disabled'
            | 'fullWidth'
            | 'id'
            | 'inputRef'
            | 'label'
            | 'multiline'
            | 'onBlur'
            | 'onFocus'
            | 'onKeyPress'
            | 'placeholder'
            | 'ref'
            | 'required'
            | 'sx'
        >,
        Omit<ICommonFieldProps, 'startAdornment' | 'endAdornment'>,
        Pick<
            AutocompleteProps<any, any, any, any>,
            'componentsProps' | 'ChipProps' | 'renderTags' | 'onChange' | 'getOptionDisabled'
        > {
    closeText?: string;
    disableCloseOnSelect?: boolean;
    disablePopupIconRotate?: boolean;
    groupPath?: string;
    loadingText?: ReactNode;
    multiple?: boolean;
    noOptionsDataText?: string;
    open?: boolean;
    openText?: string;
    options: IAutocompleteOptions<T>;
    popupIcon?: ReactNode;
    showSelectedItemsSummary?: boolean | ((count: number) => React.ReactNode);
}
