import { type JSX, type ReactNode, useEffect, useMemo } from 'react';
import { useController } from 'react-hook-form';
import { v4 as uuidv4 } from 'uuid';
import { FormControl, FormHelperText, InputAdornment, InputLabel, MenuItem, Select as MuiSelect } from '@mui/material';
import type { ISelectProps } from '../type';
import { SelectMenuProps } from '../../_helper';
import { Box, DesignTypeEnum, manageClassNames, useWatch } from '../../../..';
import { isBoolean, isNumber, isUndefined, isNull, omit, difference } from 'lodash';
import { CloseRounded } from '@mui/icons-material';
import { generateClass } from '../../../../utils';

const Select = <T,>({
    helperText,
    name,
    id = uuidv4(),
    label,
    displayEmpty,
    startAdornment,
    options,
    hiddenItems,
    disabledItems,
    onChange,
    control,
    required,
    disabled,
    setValue,
    size,
    fullWidth,
    variant,
    multiple,
    readOnly,
    className,
    native,
    nativeProps,
    onFocus,
    deps,
    sx,
    ...rest
}: ISelectProps<T>): JSX.Element => {
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);
    const watchVal = useWatch({ control, fieldName: name });
    const nativeTextareaId = 'textarea-nativeSelectedItems';

    const optionsData = useMemo<T[]>(() => {
        if (options?.data?.length) {
            return options?.dataFormatter ? options.dataFormatter(options.data) : options.data;
        }
        return [];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [options?.data, options?.dataFormatter]);

    const handleChangeMultiple = (event: any) => {
        const { options: eventOptions } = event.target;
        const value: string[] = [];
        for (let i = 0, l = eventOptions.length; i < l; i += 1) {
            if (eventOptions[i].selected) {
                value.push(eventOptions[i].value);
            }
        }
        field.onChange(value);
    };

    const setSelectedItemsToTextarea = () => {
        if (native && field.value.length) {
            //copy
            let selectedDisplayField = '';
            field.value.forEach((item: any) => {
                selectedDisplayField += `${
                    optionsData.filter((itm) => itm[options.displayValue] === item)[0]?.[options?.displayField]
                }\n`;
            });
            const textArea = document.createElement('textarea');
            textArea.value = selectedDisplayField;
            // make the textarea out of viewport
            textArea.id = nativeTextareaId;
            textArea.style.position = 'fixed';
            textArea.style.zIndex = '-1';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
        }
    };

    useEffect(() => {
        setSelectedItemsToTextarea();
        return () => {
            document.querySelector(`#${nativeTextareaId}`) &&
                document.body.removeChild(document.querySelector(`#${nativeTextareaId}`) as Node);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [field.value]);

    const renderItems = () => {
        if (optionsData?.length) {
            return optionsData.map((item: any, i: number) => {
                const hidden =
                    hiddenItems && hiddenItems?.length > 0 && hiddenItems.indexOf(item[options?.displayValue]) > -1;
                const props = {
                    key: `single_select_${String(i)}`,
                    value: item[options?.displayValue],
                    onClick: () => onChange?.(item[options?.displayValue]),
                    disabled:
                        multiple && Number(multiple) && field.value.length && field.value.length === multiple
                            ? difference(
                                  optionsData.map((itm) => itm[options?.displayValue]),
                                  field.value,
                              ).indexOf(item[options?.displayValue]) > -1
                            : disabledItems &&
                              disabledItems?.length > 0 &&
                              disabledItems.indexOf(item[options?.displayValue]) > -1,
                    children: options.renderDisplayList ? options.renderDisplayList(item) : item[options?.displayField],
                };
                return (
                    !hidden &&
                    (native ? (
                        <option key={props?.key} {...omit(props, ['children', 'key'])}>
                            {props.children}
                        </option>
                    ) : (
                        <MenuItem key={props?.key} {...omit(props, ['children', 'key'])}>
                            {props.children}
                        </MenuItem>
                    ))
                );
            });
        }
        return null;
    };

    const getEndAdornObj = () => {
        if (
            optionsData?.length > 0 &&
            displayEmpty &&
            !native &&
            !disabled &&
            !readOnly &&
            (multiple
                ? watchVal.length
                : !isUndefined(watchVal) && (isBoolean(watchVal) || isNumber(watchVal))
                  ? true
                  : watchVal)
        ) {
            return {
                endAdornment: (
                    <CloseRounded
                        className={`select-svg ${DesignTypeEnum.Default}`}
                        onClick={() => {
                            setValue(
                                name,
                                multiple
                                    ? []
                                    : isNull(control._defaultValues[name]) || isNumber(control._defaultValues[name])
                                      ? null
                                      : '',
                            );
                            field.onChange(
                                multiple
                                    ? []
                                    : isNull(control._defaultValues[name]) || isNumber(control._defaultValues[name])
                                      ? null
                                      : '',
                            );
                            onChange?.(null);
                        }}
                    />
                ),
            };
        }
        return {};
    };

    const getValue = () => {
        const defaultValue = multiple ? [] : '';
        return optionsData?.length > 0
            ? field.value === false
                ? false
                : field.value === 0
                  ? 0
                  : field.value || defaultValue
            : defaultValue;
    };

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    return (
        <FormControl
            variant={variant}
            disabled={disabled}
            error={Boolean(error) && validationControl}
            size={size}
            fullWidth={fullWidth}
            className={manageClassNames(DesignTypeEnum.Default, 'select-input-base')}
            sx={sx}>
            <InputLabel
                className={DesignTypeEnum.Default}
                htmlFor={id}
                {...(native && { shrink: true })}
                title={typeof getLabel() === 'string' ? `${getLabel()}` : ''}>
                {getLabel()}
            </InputLabel>
            <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
                <MuiSelect
                    {...field}
                    renderValue={(value) => {
                        return multiple
                            ? options?.renderDisplayField
                                ? (optionsData
                                      ?.filter((item) => value.includes(item[options.displayValue]))
                                      ?.map((item) => options?.renderDisplayField?.(item))
                                      ?.join(', ') as ReactNode)
                                : (optionsData
                                      ?.filter((item) => value.includes(item[options.displayValue]))
                                      ?.map((item) => item[options.displayField])
                                      ?.join(', ') as ReactNode)
                            : options?.renderDisplayField
                              ? (options?.renderDisplayField(
                                    optionsData?.filter((item) => item[options.displayValue] === value)[0],
                                ) as ReactNode)
                              : (optionsData?.filter((item) => item[options.displayValue] === value)[0][
                                    options.displayField
                                ] as ReactNode);
                    }}
                    inputRef={ref}
                    variant={variant}
                    className={manageClassNames(DesignTypeEnum.Default, 'select-input-base', variant, {
                        [`${className}`]: Boolean(className),
                    })}
                    value={getValue()}
                    label={getLabel()}
                    size={size}
                    fullWidth={fullWidth}
                    displayEmpty={!displayEmpty}
                    readOnly={readOnly}
                    multiple={multiple ? true : false}
                    disabled={native && readOnly ? true : disabled}
                    inputProps={{
                        size: nativeProps?.row || 4,
                    }}
                    native={native}
                    onFocus={(e) => {
                        setSelectedItemsToTextarea();
                        onFocus?.(e);
                    }}
                    onChange={(e) => {
                        multiple && native ? handleChangeMultiple(e) : field.onChange(e);
                    }}
                    onClose={() => {
                        setTimeout(() => {
                            (document.activeElement as HTMLElement).blur();
                        }, 0);
                    }}
                    {...getEndAdornObj()}
                    MenuProps={{
                        ...SelectMenuProps,
                        PaperProps: {
                            className: manageClassNames(DesignTypeEnum.Default, generateClass('Select-Paper')),
                        },
                        MenuListProps: { className: generateClass('Select-MenuList') },
                    }}
                    {...(startAdornment
                        ? {
                              startAdornment: <InputAdornment position="start">{startAdornment}</InputAdornment>,
                          }
                        : {})}
                    {...omit(rest, ['labelPlacement', 'labelWidth', 'labelEllipsis'])}>
                    {renderItems()}
                </MuiSelect>
                {(error?.message || helperText) && (
                    <FormHelperText className={manageClassNames(generateClass('HelperText'), 'select')}>
                        {(validationControl && error?.message) || helperText}
                    </FormHelperText>
                )}
            </Box>
        </FormControl>
    );
};

export default Select;
