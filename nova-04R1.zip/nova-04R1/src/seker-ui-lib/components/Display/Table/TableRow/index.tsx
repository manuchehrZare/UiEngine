import { TableRow as MuiTableRow } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { ITableRowProps } from './type';

const TableRow: FC<ITableRowProps> = forwardRef(({ children, ...rest }: ITableRowProps, ref) => {
    return (
        <MuiTableRow ref={ref} {...rest}>
            {children}
        </MuiTableRow>
    );
});

export default TableRow;
