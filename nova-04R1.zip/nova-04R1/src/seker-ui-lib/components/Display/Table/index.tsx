import type { FC } from 'react';
import { forwardRef } from 'react';
import type { ITableProps } from './type';
import type { Theme } from '@mui/material';
import { Table as MuiTable, TableContainer } from '@mui/material';
import type { DesignType } from '../../..';
import { constants, useStorage } from '../../..';
import ThemeProvider from '../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty, getProviderTheme, manageClassNames } from '../../../utils';

const Table: FC<ITableProps> = forwardRef(
    ({ containerProps, children, className, design, noBorder, size = 'small', ...rest }: ITableProps, ref) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <TableContainer {...containerProps} ref={ref}>
                    <MuiTable
                        size={size}
                        className={manageClassNames(
                            generateClass('Table'),
                            getComponentDesignProperty(design, storageDesign.newValue),
                            className,
                            { 'no-border': noBorder },
                        )}
                        {...rest}>
                        {children}
                    </MuiTable>
                </TableContainer>
            </ThemeProvider>
        );
    },
);

export default Table;
