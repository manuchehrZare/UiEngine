import { TableHead as MuiTableHead } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { ITableHeadProps } from './type';

const TableHead: FC<ITableHeadProps> = forwardRef(({ children, ...rest }: ITableHeadProps, ref) => {
    return (
        <MuiTableHead ref={ref} {...rest}>
            {children}
        </MuiTableHead>
    );
});

export default TableHead;
