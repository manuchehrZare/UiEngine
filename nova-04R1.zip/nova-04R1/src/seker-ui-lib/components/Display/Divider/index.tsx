import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IDividerProps } from './type';
import type { Theme } from '@mui/material';
import { Divider as MuiDivider } from '@mui/material';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';

const Divider: FC<IDividerProps> = forwardRef(({ children, className, design, ...rest }: IDividerProps, ref) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiDivider
                className={manageClassNames(
                    generateClass('Divider'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                {...rest}
                ref={ref}>
                {children}
            </MuiDivider>
        </ThemeProvider>
    );
});

export default Divider;
