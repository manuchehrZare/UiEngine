import {
    AddBoxOutlined,
    CheckBox,
    CheckBoxOutlineBlank,
    IndeterminateCheckBox,
    IndeterminateCheckBoxOutlined,
} from '@mui/icons-material';
import type { TreeItem2SlotProps } from '@mui/x-tree-view';
import { TreeItem2 } from '@mui/x-tree-view';
import { SimpleTreeView as MuiTreeView } from '@mui/x-tree-view/SimpleTreeView';
import { difference, isEqual } from 'lodash';
import type { FC } from 'react';
import React, { memo, useEffect, useState } from 'react';
import type { DesignType } from '../../..';
import { constants, findDeep, manageClassNames, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';
import ThemeProvider from '../../App/ThemeProvider';
import type { ITreeViewOptionsData, ITreeViewProps } from './type';
import type { Theme } from '@mui/material';

const TreeView: FC<ITreeViewProps> = ({
    collapseIcon,
    expandIcon,
    endIcon,
    selected,
    expanded,
    disableSelection,
    options,
    small,
    onToggle,
    onFocus,
    onSelect,
    design,
    checkboxSelection,
    multiSelect = false,
    className,
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const { data, displayLabel, displayId, displayChildren, displayDisabled }: ITreeViewOptionsData = {
        displayChildren: 'children',
        displayDisabled: 'disabled',
        ...options,
    };

    const [focusedItem, setFocusedItem] = useState<any>();
    const [expandedItems, setExpandedItems] = useState<string[]>(expanded || []);
    const [selectedItems, setSelectedItems] = useState<string[]>(selected || []);

    const getTreeViewItemData = (nodeId: string) => findDeep(data, nodeId, displayId, displayChildren);

    const getTreeItems = (itemIds: string | string[]): any[] => {
        const treeItems: any[] = [];
        if (typeof itemIds === 'string') {
            treeItems.push(getTreeViewItemData(itemIds));
        } else {
            itemIds.forEach((itemId: string) => {
                treeItems.push(getTreeViewItemData(itemId));
            });
        }
        return treeItems.reverse();
    };

    const getTreeItemChildNodeIds = (treeData: any[]): string[] => {
        const resultArr: string[] = [];
        for (const treeItem of treeData) {
            resultArr.push(String(treeItem.id));
            if (displayChildren && treeItem) {
                if (treeItem[displayChildren] && treeItem[displayChildren].length > 0) {
                    getTreeItemChildNodeIds(treeItem[displayChildren]);
                }
            }
        }
        return resultArr;
    };

    const getChildNodeIds = (treeItem?: any): string[] => {
        if (displayChildren && treeItem) {
            if (treeItem?.[displayChildren] && treeItem?.[displayChildren].length > 0) {
                return getTreeItemChildNodeIds(treeItem[displayChildren]);
            }
            return [];
        }
        return [];
    };

    const handleToggle = (_: any, itemIds: string[]) => {
        let newItemIds: string[] = [];
        if (
            displayChildren &&
            displayId &&
            Array.isArray(itemIds) &&
            itemIds.length > 0 &&
            itemIds.findIndex((item: string) => item === focusedItem[displayId]) === -1
        ) {
            newItemIds = difference(itemIds, getChildNodeIds(focusedItem));
        } else {
            newItemIds = itemIds;
        }
        setExpandedItems(newItemIds);
        onToggle?.(getTreeItems(itemIds), newItemIds);
    };

    const getAllChildIds = (treeItem: any): string[] => {
        let childIds: string[] = [];
        if (displayChildren && treeItem[displayChildren]) {
            childIds = treeItem[displayChildren]?.map((child: any) => String(child[displayId]));
            treeItem[displayChildren].forEach((child: any) => {
                childIds = [...childIds, ...getAllChildIds(child)];
            });
        }
        return childIds;
    };

    function getAllParentIds(items: any[], id: string): string[] {
        const parentIds: string[] = [];
        function findParent(currentItems: any[]): boolean {
            for (const item of currentItems) {
                if (item[displayId] === id) {
                    return true;
                }
                if (item[displayChildren as any] && item[displayChildren as any].length > 0) {
                    if (findParent(item[displayChildren as any])) {
                        parentIds.push(item[displayId]);
                        return true;
                    }
                }
            }
            return false;
        }

        findParent(items);
        return parentIds;
    }

    const isIndeterminate = (itemId: string): boolean => {
        const item = getTreeViewItemData(itemId);
        if (!item?.[displayChildren]) return false;

        const childIds = getAllChildIds(item);
        const selectedChildIds = childIds.filter((id) => selectedItems.includes(id));

        return selectedChildIds.length > 0 && selectedChildIds.length < childIds.length;
    };

    const handleSelect = (_: React.SyntheticEvent<Element, Event>, itemIds: string[] | string | null) => {
        if (itemIds === null) {
            setSelectedItems([]);
            onSelect?.([], []);
        } else {
            let newItemIds: string[] = typeof itemIds === 'string' ? [itemIds] : itemIds;
            let indeterminateItemIds: string[] = [];
            if (multiSelect && checkboxSelection) {
                const addedItems = newItemIds.filter((id) => !selectedItems.includes(id));
                const removedItems = selectedItems.filter((id) => !newItemIds.includes(id));

                addedItems.forEach((itemId) => {
                    const item = getTreeViewItemData(itemId);
                    if (item) {
                        const childIds = getAllChildIds(item);
                        newItemIds = [...new Set([...newItemIds, ...childIds])];
                    }
                });

                removedItems.forEach((itemId) => {
                    const item = getTreeViewItemData(itemId);
                    if (item) {
                        const childIds = getAllChildIds(item);
                        newItemIds = newItemIds.filter((id) => id !== itemId && !childIds.includes(id));
                    }
                    const parentIds = getAllParentIds(data, itemId);
                    newItemIds = newItemIds.filter((id) => !parentIds.includes(id));
                });
                // Check if all children of a parent are selected, if so, select the parent and its ancestors
                // Check if item is indeterminate
                const checkAndSelectParent = (items: any[]): { allSelected: boolean; someSelected: boolean } => {
                    let allChildrenSelected = true;
                    let someChildrenSelected = false;

                    items.forEach((item) => {
                        if (
                            item[displayChildren] &&
                            Array.isArray(item[displayChildren]) &&
                            item[displayChildren].length > 0
                        ) {
                            const { allSelected, someSelected } = checkAndSelectParent(item[displayChildren]);

                            if (allSelected && !newItemIds.includes(String(item[displayId]))) {
                                newItemIds.push(String(item[displayId]));
                            } else if (someSelected && !allSelected) {
                                indeterminateItemIds.push(String(item[displayId]));
                            }

                            allChildrenSelected = allChildrenSelected && allSelected;
                            someChildrenSelected = someChildrenSelected || allSelected || someSelected;
                        } else {
                            const isSelected = newItemIds.includes(String(item[displayId]));
                            allChildrenSelected = allChildrenSelected && isSelected;
                            someChildrenSelected = someChildrenSelected || isSelected;
                        }
                    });

                    return {
                        allSelected: allChildrenSelected,
                        someSelected: someChildrenSelected,
                    };
                };

                checkAndSelectParent(data);
                // Remove any IDs that are in both lists
                indeterminateItemIds = indeterminateItemIds.filter((id) => !newItemIds.includes(id));
            }

            if (!isEqual(selectedItems, newItemIds)) {
                setSelectedItems(newItemIds);
                onSelect?.(getTreeItems(newItemIds), newItemIds, indeterminateItemIds);
            }
        }
    };

    const handleFocus = (_: React.SyntheticEvent | null, itemId: string) => {
        const treeItem = getTreeViewItemData(itemId);
        !isEqual(treeItem, focusedItem) && setFocusedItem(treeItem);
    };

    useEffect(() => {
        focusedItem && onFocus?.(focusedItem);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [focusedItem]);

    /* istanbul ignore next */
    useEffect(() => {
        if (expanded && !isEqual(expanded, expandedItems)) {
            setExpandedItems(expanded);
            onToggle?.(getTreeItems(expanded), expanded);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [expanded]);

    /* istanbul ignore next */
    useEffect(() => {
        if (selected && !isEqual(selected, selectedItems)) {
            setSelectedItems(selected);
            onSelect?.(getTreeItems(selected), selected);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selected]);

    const renderTree = (treeItem: any) => {
        const isItemIndeterminate = isIndeterminate(String(treeItem[displayId]));
        return (
            <TreeItem2
                key={String(treeItem[displayId])}
                itemId={String(treeItem[displayId])}
                label={treeItem[displayLabel]}
                {...(multiSelect &&
                    checkboxSelection && {
                        slotProps: {
                            checkbox: {
                                size: 'small',
                                icon: isItemIndeterminate ? <IndeterminateCheckBox /> : <CheckBoxOutlineBlank />,
                                checkedIcon: <CheckBox />,
                            },
                        } as TreeItem2SlotProps,
                    })}
                disabled={displayDisabled && treeItem[displayDisabled]}>
                {displayChildren &&
                    Array.isArray(treeItem[displayChildren]) &&
                    treeItem[displayChildren]?.map((childNode: any) => renderTree(childNode))}
            </TreeItem2>
        );
    };

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiTreeView
                className={manageClassNames(
                    generateClass('Treeview'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    { small: small },
                    className,
                )}
                multiSelect={multiSelect}
                slots={{
                    expandIcon: expandIcon || AddBoxOutlined,
                    collapseIcon: collapseIcon || IndeterminateCheckBoxOutlined,
                    endIcon: endIcon,
                }}
                disableSelection={disableSelection}
                selectedItems={selectedItems as any}
                onSelectedItemsChange={handleSelect}
                expandedItems={expandedItems}
                onExpandedItemsChange={handleToggle}
                onItemFocus={handleFocus}
                checkboxSelection={checkboxSelection}
                {...rest}>
                {data.map((item) => renderTree(item))}
            </MuiTreeView>
        </ThemeProvider>
    );
};

export default memo(TreeView);
