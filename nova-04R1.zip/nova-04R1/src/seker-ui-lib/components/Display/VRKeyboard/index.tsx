import { isNull } from 'lodash';
import type { FC, MutableRefObject } from 'react';
import { cloneElement, memo, useEffect, useRef, useState } from 'react';
import type { SimpleKeyboard } from 'react-simple-keyboard';
import ReactKeyboard from 'react-simple-keyboard';
import 'react-simple-keyboard/build/css/index.css';
import useWatch from '../../../hooks/useWatch';
import type { DisplayButtonsType, IVRKeyboardProps, LayoutNameType } from './type';
import { DisplayButtonsEnum, LayoutNameTypeEnum } from './type';
import { numeric } from './_layouts/numeric';
import { trLayout } from './_layouts/turkish';
import { useController } from 'react-hook-form';
import ThemeProvider from '../../App/ThemeProvider';
import Tooltip from '../Tooltip';
import type { DesignType } from '../../..';
import { Box, constants, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, manageClassNames } from '../../../utils';

const VRKeyboard: FC<IVRKeyboardProps> = ({
    anchorEl,
    sx,
    className,
    numPad = false,
    open = false,
    placement = 'bottom-start',
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const anchorRef: MutableRefObject<HTMLElement | undefined> = useRef(undefined);
    const keyboard: MutableRefObject<SimpleKeyboard | undefined> = useRef(undefined);
    const [layoutName, setLayoutName] = useState<LayoutNameType>(LayoutNameTypeEnum.default);
    const watchValue = useWatch({ control: anchorEl.props.control, fieldName: anchorEl.props.name });
    const {
        field: { onChange },
    } = useController({ name: anchorEl.props.name, control: anchorEl.props.control });
    /* istanbul ignore next */
    useEffect(() => {
        if (keyboard) {
            keyboard?.current?.setInput(String(!isNull(watchValue) ? watchValue : ''), anchorEl.props.name);
        }
    }, [watchValue, keyboard, anchorEl.props.name, open]);

    /* istanbul ignore next */
    const handleChangeLayoutName = (button: DisplayButtonsType) => {
        switch (button) {
            case DisplayButtonsEnum.Shift:
                setLayoutName(
                    layoutName === LayoutNameTypeEnum.shift ? LayoutNameTypeEnum.default : LayoutNameTypeEnum.shift,
                );
                break;
            case DisplayButtonsEnum.CapsLock:
                setLayoutName(
                    layoutName === LayoutNameTypeEnum.lock ? LayoutNameTypeEnum.default : LayoutNameTypeEnum.lock,
                );
                break;
            default:
                setLayoutName(LayoutNameTypeEnum.default);
                break;
        }
    };

    /* istanbul ignore next */
    const handleClear = () => {
        if (keyboard) {
            keyboard?.current?.clearInput(anchorEl.props.name);
        }
    };

    const renderAnchorEl = () => (
        <Box component="div" ref={anchorRef}>
            {cloneElement(anchorEl)}
        </Box>
    );

    return (
        <ThemeProvider design={getComponentDesignProperty(undefined, storageDesign.newValue)}>
            <Tooltip
                show={open}
                className={manageClassNames(generateClass('VRKeyboard-tooltip'), className)}
                componentsProps={{
                    tooltip: {
                        className: manageClassNames(generateClass('VRKeyboard-tooltip'), {
                            numeric: numPad,
                            trLayout: !numPad,
                        }),
                    },
                    popper: {
                        className: generateClass('VRKeyboard-popper'),
                    },
                }}
                placement={placement}
                title={
                    <Box sx={sx}>
                        <ReactKeyboard
                            inputName={anchorEl.props.name}
                            baseClass={`vr-keyboard-${anchorEl.props.name}`}
                            layoutName={layoutName}
                            layout={numPad ? numeric : trLayout}
                            onChange={(value) => {
                                onChange({ target: { name: anchorEl.props.name, value } });
                            }}
                            keyboardRef={(r) => (keyboard.current = r)}
                            mergeDisplay
                            onKeyPress={(button: any) => {
                                if (button === DisplayButtonsEnum.Clear) {
                                    handleClear();
                                }
                                if (button === DisplayButtonsEnum.Shift || button === DisplayButtonsEnum.CapsLock) {
                                    handleChangeLayoutName(button);
                                }
                            }}
                            display={{
                                [DisplayButtonsEnum.Enter]: 'Enter ↵',
                                [DisplayButtonsEnum.CapsLock]: 'Caps Lock ⇪',
                                [DisplayButtonsEnum.Space]: ' ',
                                [DisplayButtonsEnum.Tab]: 'Tab ⇥',
                                [DisplayButtonsEnum.Shift]: 'Shift ⇧',
                                [DisplayButtonsEnum.Clear]: 'Clear',
                                [DisplayButtonsEnum.Backspace]: 'Backspace ⌫',
                            }}
                            buttonTheme={[
                                {
                                    class: 'vr-keyboard-btn',
                                    buttons: DisplayButtonsEnum.Enter,
                                },
                                {
                                    class: 'vr-keyboard-btn',
                                    buttons: DisplayButtonsEnum.CapsLock,
                                },
                                {
                                    class: 'vr-keyboard-btn',
                                    buttons: DisplayButtonsEnum.Tab,
                                },
                                {
                                    class: 'vr-keyboard-btn',
                                    buttons: DisplayButtonsEnum.Backspace,
                                },
                                {
                                    class: 'vr-keyboard-btn',
                                    buttons: DisplayButtonsEnum.Clear,
                                },
                                {
                                    class: 'vr-keyboard-btn',
                                    buttons: DisplayButtonsEnum.Shift,
                                },
                            ]}
                            {...rest}
                        />
                    </Box>
                }>
                {renderAnchorEl()}
            </Tooltip>
        </ThemeProvider>
    );
};

export default memo(VRKeyboard);
