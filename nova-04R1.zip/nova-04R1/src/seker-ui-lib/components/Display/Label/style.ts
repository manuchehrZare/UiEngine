import type { SxProps, Theme } from '@mui/material';
import type { ILabelProps } from '../../..';
import { DesignTypeEnum } from '../../../utils/types/common';

interface IParams extends Pick<ILabelProps, 'design' | 'align' | 'color'> {}

const LabelSxProps = ({ align, design, color }: IParams): SxProps<Theme> => {
    return {
        color: color ? color : (theme) => theme.palette.primary.main,
        position: 'relative',
        display: 'flex',
        ...(align === 'right' && {
            justifyContent: 'flex-end',
            textAlign: 'right',
        }),
        ...(align === 'center' && {
            justifyContent: 'center',
            textAlign: 'center',
        }),
        ...(align === 'left' && {
            justifyContent: 'flex-start',
            textAlign: 'left',
        }),

        ...(design === DesignTypeEnum.SET && {
            color: color ? color : (theme) => theme.palette.green?.main,
        }),
    };
};

export default LabelSxProps;
