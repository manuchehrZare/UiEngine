import type { FC } from 'react';
import { forwardRef } from 'react';
import { DialogContent } from '@mui/material';
import type { IModalBodyProps } from './type';
import { manageClassNames } from '../../..';
import { generateClass } from '../../../utils';

const ModalBody: FC<IModalBodyProps> = forwardRef(({ children, className, ...rest }: IModalBodyProps, ref) => {
    return (
        <DialogContent className={manageClassNames(generateClass('Modal-Body'), className)} ref={ref} {...rest}>
            {children}
        </DialogContent>
    );
});

export default ModalBody;
