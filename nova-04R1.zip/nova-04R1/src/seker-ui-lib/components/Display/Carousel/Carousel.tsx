import type { FC } from 'react';
import Slider from 'react-material-ui-carousel';
import type { ICarouselProps } from './type';
import { generateClass, manageClassNames } from '../../../utils';
import { MuiCarouselSxProps } from './style';
import { omit } from 'lodash';

const Carousel: FC<ICarouselProps> = ({
    children,
    prevNav,
    nextNav,
    indicatorIcon,
    indicatorContainerProps,
    navButtonsProps,
    navButtonsWrapperProps,
    indicatorIconButtonProps,
    activeIndicatorIconButtonProps,
    sx,
    height,
    className,
    animation = 'slide',
    autoPlay = false,
    changeOnFirstRender = false,
    cycleNavigation = true,
    duration = 500,
    fullHeightHover = true,
    index = 0,
    indicators = false,
    indicatorsPosition = 'in',
    interval = 4000,
    navButtonsAlwaysInvisible = true,
    navButtonsAlwaysVisible = false,
    stopAutoPlayOnHover = true,
    strictIndexing = true,
    swipe = true,
    ...rest
}) => {
    return (
        <Slider
            className={manageClassNames(generateClass('Carousel'), className)}
            NextIcon={nextNav}
            PrevIcon={prevNav}
            indicators={indicators}
            IndicatorIcon={indicatorIcon}
            navButtonsAlwaysVisible={navButtonsAlwaysVisible}
            navButtonsAlwaysInvisible={navButtonsAlwaysVisible ? false : navButtonsAlwaysInvisible}
            indicatorIconButtonProps={{
                className: manageClassNames(
                    generateClass('Carousel-indicator-iconButton'),
                    indicatorIconButtonProps?.className,
                ),
                ...omit(indicatorIconButtonProps, ['className']),
            }}
            activeIndicatorIconButtonProps={{
                className: manageClassNames('active', activeIndicatorIconButtonProps?.className),
                ...omit(activeIndicatorIconButtonProps, ['className']),
            }}
            navButtonsProps={{
                className: manageClassNames(generateClass('Carousel-NavButton'), navButtonsProps?.className),
                ...omit(navButtonsProps, ['className']),
            }}
            navButtonsWrapperProps={{
                className: manageClassNames(
                    generateClass('Carousel-NavButtonsWrapper'),
                    navButtonsWrapperProps?.className,
                ),
                ...omit(navButtonsWrapperProps, ['className']),
            }}
            indicatorContainerProps={{
                className: manageClassNames(generateClass('Carousel-indicator'), indicatorContainerProps?.className),
                ...omit(indicatorContainerProps, ['className']),
            }}
            sx={{
                ...(MuiCarouselSxProps({ height, indicatorsPosition }) as any),
                ...sx,
            }}
            height={height}
            animation={animation}
            swipe={swipe}
            strictIndexing={strictIndexing}
            stopAutoPlayOnHover={stopAutoPlayOnHover}
            interval={interval}
            index={index}
            fullHeightHover={fullHeightHover}
            duration={duration}
            cycleNavigation={cycleNavigation}
            changeOnFirstRender={changeOnFirstRender}
            autoPlay={autoPlay}
            {...rest}>
            {children}
        </Slider>
    );
};

export default Carousel;
