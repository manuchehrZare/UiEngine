import type { AccordionProps } from '@mui/material';
import type { ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';

export interface IAccordionProps
    extends
        ICommonProps,
        Pick<AccordionProps, 'id' | 'className' | 'expanded' | 'onChange' | 'disabled' | 'sx' | 'defaultExpanded'> {
    content?: ReactNode;
    icon?: ReactNode;
    title?: ReactNode;
}
