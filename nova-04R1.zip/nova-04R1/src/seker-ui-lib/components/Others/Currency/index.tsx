import { omit } from 'lodash';
import type { FC } from 'react';
import type { ICurrencyProps } from './type';
import { NumberInput, NumberFormat, manageClassNames } from '../../../../seker-ui-lib';
import { generateClass } from '../../../utils';

const Currency: FC<ICurrencyProps> = (props: ICurrencyProps) => {
    const {
        className,
        component,
        currency,
        decimalSeparator = ',',
        thousandSeparator = '.',
        fixedDecimalScale = true,
        decimalScale = 2,
    } = props;

    const getCommonProps = (): Pick<ICurrencyProps, 'className' | 'currency'> => ({
        className: manageClassNames(generateClass('Currency'), className),
        ...(currency && { suffix: ` ${currency}` }),
    });

    if (component === 'NumberFormat') {
        return (
            <NumberFormat
                {...getCommonProps()}
                decimalSeparator={decimalSeparator}
                thousandSeparator={thousandSeparator}
                fixedDecimalScale={fixedDecimalScale}
                decimalScale={decimalScale}
                {...omit(props, ['className', 'component', 'currency'])}
            />
        );
    }
    return (
        <NumberInput
            {...getCommonProps()}
            decimalSeparator={decimalSeparator}
            thousandSeparator={thousandSeparator}
            fixedDecimalScale={fixedDecimalScale}
            decimalScale={decimalScale}
            {...omit(props, ['className', 'component', 'currency'])}
        />
    );
};

export default Currency;
