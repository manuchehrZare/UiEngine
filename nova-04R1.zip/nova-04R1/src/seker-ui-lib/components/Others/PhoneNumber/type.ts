import type { INumberFormatBaseProps } from '../../Display/NumberFormat/type';
import type { INumberInputProps } from '../../Form/NumberInput/type';

export interface IPhoneNumberInputProps extends Pick<
    INumberInputProps,
    | 'autoComplete'
    | 'autoFocus'
    | 'className'
    | 'control'
    | 'deps'
    | 'design'
    | 'disabled'
    | 'endAdornment'
    | 'focused'
    | 'format'
    | 'fullWidth'
    | 'helperText'
    | 'hidden'
    | 'id'
    | 'inputRef'
    | 'label'
    | 'labelEllipsis'
    | 'labelPlacement'
    | 'labelWidth'
    | 'mask'
    | 'name'
    | 'onBlur'
    | 'onFocus'
    | 'onKeyPress'
    | 'placeholder'
    | 'prefix'
    | 'readOnly'
    | 'ref'
    | 'removeFormatting'
    | 'renderText'
    | 'required'
    | 'returnValue'
    | 'size'
    | 'startAdornment'
    | 'suffix'
    | 'sx'
    | 'tabIndex'
    | 'textAlign'
    | 'variant'
> {
    component: 'NumberInput';
    withCountryCode?: boolean;
    withoutAreaCode?: boolean;
    withoutBrackets?: boolean;
    withZero?: boolean;
}

export interface IPhoneNumberFormatProps extends Omit<
    INumberFormatBaseProps,
    'decimalScale' | 'decimalSeparator' | 'fixedDecimalScale' | 'thousandSeparator'
> {
    component: 'NumberFormat';
    withCountryCode?: boolean;
    withoutAreaCode?: boolean;
    withoutBrackets?: boolean;
    withZero?: boolean;
}

export type IPhoneNumberProps = IPhoneNumberInputProps | IPhoneNumberFormatProps;
