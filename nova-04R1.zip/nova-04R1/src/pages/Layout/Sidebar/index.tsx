import type { FC, JSX } from 'react';
import { Sidebar } from '../../../App';

const LayoutSidebarPage: FC = (): JSX.Element => {
    return <Sidebar />;
};

export default LayoutSidebarPage;
