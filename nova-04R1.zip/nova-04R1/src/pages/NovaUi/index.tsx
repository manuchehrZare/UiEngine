/* eslint-disable */
import React from 'react';
import GenericUi from '../../nova/nova-ui';
import { Grid, GridItem } from '../../seker-ui-lib';
import { Layout } from '../../App';
const NovaUi: React.FC = () => {
    return (
          <Layout title="Nova Ui Studio">
                    <Grid>
                        <GridItem>
                                    <GenericUi />
                        </GridItem>
                    </Grid>
                </Layout>

    );
};

export default NovaUi;
