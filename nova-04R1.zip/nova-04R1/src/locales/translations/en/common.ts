export default {
    pageNotFound: 'The screen you are looking for does not exist.',
    welcome: 'Welcome',
};
