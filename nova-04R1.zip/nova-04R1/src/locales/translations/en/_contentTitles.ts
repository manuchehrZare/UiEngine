export default {
    settings: {
        console: 'Console',
        log: 'Log',
    },
};
