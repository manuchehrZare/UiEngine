/* eslint-disable */
// import React, { useMemo, useEffect } from 'react';
// import { useDrop } from 'react-dnd';
// import { FormProvider } from 'react-hook-form';
// import useForm from '../../../seker-ui-lib/hooks/useForm';
// import { ComponentRenderer } from './ComponentRenderer';
// import { Box, Typography, Paper } from '@mui/material';
// import { buildFormDefaultValues } from '../../nova-core/utils/formUtils';
// import { COMPONENT_REGISTRY, useNova } from '../../nova-core';

import React from 'react';
import { COMPONENT_REGISTRY } from '../../nova-core/registry/component-registry';
import { NovaRuntimeWrapper } from '../../nova-core/components/NovaRuntimeWrapper';
import type { DesignComponent } from '../../nova-core';


export const PreviewRenderer: React.FC<{ component: DesignComponent }> = ({ component }) => {
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';

    const renderChildren = () => {
         return component.children?.map((child) => (
            <PreviewRenderer key={child.id} component={child} />
        ));
    };

    // Extract key and designComponent from component.props to avoid React warnings
    // React keys must be passed directly, not spread
    // designComponent should not be passed to DOM elements
    const { key: _, designComponent: __, ...propsWithoutKey } = component.props || {};

    // Pass designComponent only if the component explicitly requires it (e.g. TabbedPane)
    // This prevents React warnings about passing unrecognized props to DOM elements
    const extraProps: Record<string, any> = {};
    if (registryItem?.needsDesignComponent) {
        extraProps.designComponent = component;
    }

    // Wrap with runtime features (method registration, event handlers)
    return (
        <NovaRuntimeWrapper component={component}>
            <ActualComponent {...propsWithoutKey} {...extraProps}>
                {registryItem?.isContainer ? renderChildren() : component.props?.children}
            </ActualComponent>
        </NovaRuntimeWrapper>
    );
};


// Simple renderer for Preview mode without D&D/Selection wrappers
/* export const PreviewRenderer: React.FC<{ component: any }> = ({ component }) => {
    const registryItem = COMPONENT_REGISTRY[component.type];
    const ActualComponent = registryItem?.component || 'div';

    const renderChildren = () => {
         return component.children?.map((child: any) => (
            <PreviewRenderer key={child.id} component={child} />
        ));
    };

    // Destructure to exclude 'key' from props spreading
    const { key, ...restProps } = component.props || {};

    return (
        <ActualComponent {...restProps} designComponent={component}>
            {registryItem?.isContainer ? renderChildren() : component.props.children}
        </ActualComponent>
    );
}**/

