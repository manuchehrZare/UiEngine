/* eslint-disable */
import React, { useState } from 'react';
import { Box, Paper, Button, Typography, Divider,
     Chip, useForm, Input, Select } from '../../../../seker-ui-lib';
import {
    List, ListItem, ListItemText, IconButton,
    Stack, ToggleButton, ToggleButtonGroup, TextField
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import CodeIcon from '@mui/icons-material/Code';
import ViewListIcon from '@mui/icons-material/ViewList';
import Editor from '@monaco-editor/react';
import { useNova, type Variable } from '../../../nova-core';

interface DataFormValues {
    name: string;
    type: string;
    initialValue: any;
}

export const DataDesigner: React.FC = () => {
    const { data = [], addData, updateData, deleteData } = useNova();
    const [selectedData, setSelectedData] = useState<Variable | null>(null);
    const [isCreating, setIsCreating] = useState(false);
    const [viewMode, setViewMode] = useState<'visual' | 'json'>('visual');

    const [formData, setFormData] = useState<Partial<Variable>>({
        name: '',
        type: 'string',
        initialValue: ''
    });

    const { control, handleSubmit, reset, setValue } = useForm<DataFormValues>({
        defaultValues: {
            name: '',
            type: 'string',
            initialValue: ''
        }
    });

    const handleSelectData = (dataItem: Variable) => {
        setSelectedData(dataItem);
        setIsCreating(false);
        setFormData(dataItem);
        reset({
            name: dataItem.name || '',
            type: dataItem.type || 'string',
            initialValue: dataItem.initialValue || ''
        });
    };

    const handleNewData = () => {
        setSelectedData(null);
        setIsCreating(true);
        setFormData({
            name: '',
            type: 'string',
            initialValue: ''
        });
        reset({
            name: '',
            type: 'string',
            initialValue: ''
        });
    };

    const handleCancelEdit = () => {
        setSelectedData(null);
        setIsCreating(false);
        setFormData({
            name: '',
            type: 'string',
            initialValue: ''
        });
        reset();
    };

    const handleSave = handleSubmit((values: any) => {
        if (!values.name || !values.type) {
            alert('Please fill in required fields: Name and Type');
            return;
        }

        const dataItem: Variable = {
            name: values.name,
            type: values.type,
            initialValue: values.initialValue
        };

        if (selectedData) {
            updateData(selectedData.name, dataItem);
        } else {
            addData(dataItem);
        }
        handleCancelEdit();
    });

    const handleDelete = (name: string) => {
        if (window.confirm('Are you sure you want to delete this data item?')) {
            deleteData(name);
        }
    };

    const handleJsonChange = (value: string | undefined) => {
        // For JSON view in future enhancement
    };

    const builtInVariables = [
        { name: '$today', description: 'Current date' },
        { name: '$menuKey', description: 'Menu key property from menu definition' },
        { name: '$clienthostname', description: 'Client\'s host name' },
        { name: '$clientosname', description: 'Operating system name' },
        { name: '$securitylevel', description: 'Security level of current user' },
        { name: '$RC_ERROR_ID', description: 'Remote call error ID (-1 if successful)' }
    ];

    return (
        <Box sx={{ display: 'flex', height: '100%' }}>
            {/* Left Panel - Data List */}
            <Box sx={{ width: 300, borderRight: 1, borderColor: 'divider', display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Data</Typography>
                        <Button
                            size="small"
                            variant="contained"
                            iconLeft={<AddIcon />}
                            onClick={handleNewData}
                            text="New"
                        />
                    </Stack>
                </Box>
                <List sx={{ flexGrow: 1, overflow: 'auto' }}>
                    {data.map((dataItem) => (
                        <ListItem
                            key={dataItem.name}
                            selected={selectedData?.name === dataItem.name}
                            button
                            onClick={() => handleSelectData(dataItem)}
                            secondaryAction={
                                <IconButton edge="end" size="small" onClick={(e) => {
                                    e.stopPropagation();
                                    handleDelete(dataItem.name);
                                }}>
                                    <DeleteIcon fontSize="small" />
                                </IconButton>
                            }
                        >
                            <ListItemText
                                primary={dataItem.name}
                                secondary={`Type: ${dataItem.type}`}
                            />
                        </ListItem>
                    ))}
                </List>
            </Box>

            {/* Right Panel - Details/JSON View */}
            <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="h6">Data Designer</Typography>
                        <ToggleButtonGroup
                            value={viewMode}
                            exclusive
                            onChange={(_, newMode) => newMode && setViewMode(newMode)}
                            size="small"
                        >
                            <ToggleButton value="visual">
                                <ViewListIcon sx={{ mr: 1 }} /> Visual
                            </ToggleButton>
                            <ToggleButton value="json">
                                <CodeIcon sx={{ mr: 1 }} /> JSON
                            </ToggleButton>
                        </ToggleButtonGroup>
                    </Stack>
                </Box>

                {viewMode === 'visual' ? (
                    <Box sx={{ p: 3, overflow: 'auto' }}>
                        {!isCreating && !selectedData ? (
                            <>
                                {/* <Typography variant="body2" color="text.secondary" paragraph>
                                    Data items are used for storing values in the page. Data can be assigned to components,
                                    used in rule definitions, passed to services, and used as input/output for popups.
                                </Typography>

                                <Divider sx={{ my: 3 }}>
                                    <Chip label="Built-in Variables (Read-only)" />
                                </Divider>

                                <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                                    <List dense>
                                        {builtInVariables.map((builtIn) => (
                                            <ListItem key={builtIn.name}>
                                                <ListItemText
                                                    primary={<Typography variant="body2" fontFamily="monospace">{builtIn.name}</Typography>}
                                                    secondary={builtIn.description}
                                                />
                                            </ListItem>
                                        ))}
                                    </List>
                                </Paper>

                                {data.length === 0 && (
                                    <Box sx={{ mt: 4, textAlign: 'center' }}>
                                        <Typography variant="body1" color="text.secondary">
                                            No data items defined. Click "New" to create a data item.
                                        </Typography>
                                    </Box>
                                )} */}
                            </>
                        ) : (
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom>
                                    {selectedData ? 'Edit Data' : 'New Data'}
                                </Typography>
                                <Stack spacing={2} sx={{ mt: 2 }}>
                                    <Input
                                        label="Name *"
                                        name="name"
                                        control={control}
                                    />

                                    <Select
                                        label="Type *"
                                        name="type"
                                        control={control}
                                        options={{
                                            data: [
                                                { value: 'string', label: 'String' },
                                                { value: 'integer', label: 'Integer' },
                                                { value: 'boolean', label: 'Boolean' },
                                                { value: 'object', label: 'Object' },
                                                { value: 'array', label: 'Array' }
                                            ],
                                            displayField: 'label',
                                            displayValue: 'value',
                                        }}
                                        setValue={setValue}
                                    />

                                    <Input
                                        label="Initial Value"
                                        name="initialValue"
                                        control={control}
                                    />

                                    <Stack direction="row" spacing={2} justifyContent="flex-end">
                                        <Button onClick={handleCancelEdit} text="Cancel" />
                                        <Button onClick={handleSave} variant="contained" text="Save" />
                                    </Stack>
                                </Stack>
                            </Paper>
                        )}
                    </Box>
                ) : (
                    <Box sx={{ flexGrow: 1 }}>
                        <Editor
                            height="100%"
                            defaultLanguage="json"
                            value={JSON.stringify({ data }, null, 2)}
                            onChange={handleJsonChange}
                            options={{
                                minimap: { enabled: false },
                                readOnly: true
                            }}
                        />
                    </Box>
                )}
            </Box>

        </Box>
    );
};
