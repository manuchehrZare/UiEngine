/* eslint-disable */
import React, { useState, useMemo, useEffect } from 'react';
import { Box, Paper, Typography, Grid, GridItem, Button } from '../../seker-ui-lib';
import { TextField } from '@mui/material';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import type { NovaUiSchema } from '../nova-core/types/nova-ui-schema.types';
import { DesignArea } from '../nova-studio/components/DesignArea';
import { useNavigate } from 'react-router-dom';
import { NovaProvider, useNova } from '../nova-core/context/NovaContext';
import { LogCenterProvider } from '../nova-core/context/LogCenterContext';
import { EngineDebugPanel } from '../nova-core/components';
import { ArchitectureOutlined, SchemaOutlined } from '@mui/icons-material';
import { menuDefinitions } from '../nova-core/nova-ebml/menu-definitions';
import { getScreenEbmlSchema } from '../nova-core/nova-ebml/ebml-schema-provider';
import { convertNovaEbmlToNovaUiSchema } from '../nova-core/nova-ebml/nova-ebml-converter';


const EditInDesignerButton: React.FC<{ novaSchema: NovaUiSchema | null }> = ({ novaSchema }) => {
    const navigate = useNavigate();

    const handleOpenDesigner = () => {
        if (!novaSchema) return;
        navigate('/nova-studio', {
            state: {
                importedDesign: JSON.stringify(novaSchema),
            },
        });
    };

    return (
        <Button
            variant="contained"
            size="medium"
            iconRight={<ArchitectureOutlined/>}
            disabled={!novaSchema}
            onClick={handleOpenDesigner}
            text="Edit in Designer"
               sx={{ mr: 1, whiteSpace: 'nowrap' }}
        />
    );
};
 
const DynamicRenderer: React.FC<{ novaSchema: NovaUiSchema }> = ({ novaSchema }) => {
    const { setMode,loadSchema } = useNova();

    // Create a stable string representation for comparison
    const schemaKey = useMemo(() => {
        return novaSchema ? JSON.stringify(novaSchema.metadata || novaSchema.ui?.[0]?.id || Math.random()) : '';
    }, [novaSchema]);

    useEffect(() => {
        if (novaSchema) {
            loadSchema(novaSchema);
            setMode('preview');
        }
    }, [schemaKey]); // Only re-run when schema actually changes

    return (
        <Box sx={{ height: '100%', overflow: 'hidden', bgcolor: '#f0f2f5' }}>
            <DesignArea  />
        </Box>
    );
};

const GenericUiContent: React.FC = () => {
    const { error } = useNova();
    const [selectedPage, setSelectedPage] = useState<any>(null);
    const [novaSchema, setNovaSchema] = useState<NovaUiSchema | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    
    const handlePageSelect = (page: any) => {
        setSelectedPage(page);
        try {
            getScreenEbmlSchema(page.screenCode).then(screenEbml=>{
                if(screenEbml)
                {
                    const convertedSchema = convertNovaEbmlToNovaUiSchema(screenEbml);
                    setNovaSchema(convertedSchema);
                }
                else setNovaSchema(null);
            });
        } catch (err) {
            console.error('Failed to convert page:', err);
            setNovaSchema(null);
        }
    };

    const filteredPages = useMemo(() => {
        const onlyPages = menuDefinitions.filter((p) => p.screenCode !== '');
        if (!searchTerm) return onlyPages;
        const term = searchTerm.toLowerCase();
        return onlyPages.filter(
            (p) =>
                p.menuName?.toLowerCase().includes(term) ||
                p.screenCode?.toLowerCase().includes(term)  
        );
    }, [searchTerm]);
    if (error) {
        return <Box sx={{ p: 3, color: 'error.main' }}>Error: {error.message}</Box>;
    }

    return (
     <>
                <Grid container spacing={2} sx={{ height: 'calc(100vh - 64px)', overflow: 'hidden' }}>
                    <GridItem xs={12} md={2} sx={{ height: '100%', borderRight: '1px solid #eee', overflow: 'auto' }}>
                        <Typography variant="h6" gutterBottom>
                            NOVA UI Explorer
                        </Typography>

                        <Box sx={{ mb: 2 }}>
                            <TextField
                                fullWidth
                                placeholder="Search pages..."
                                value={searchTerm}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
                                size="small"
                            />
                        </Box>

                        <Box>
                            {filteredPages.map((page) => (
                                <Box
                                    key={page.screenName+ page.menuName}
                                    onClick={() => handlePageSelect(page)}
                                    sx={{
                                        p: 1.5,
                                        mb: 1,
                                        cursor: 'pointer',
                                        borderRadius: 1,
                                        bgcolor: selectedPage?.menuName === page.menuName ? 'action.selected' : 'transparent',
                                        '&:hover': {
                                            bgcolor: 'action.hover',
                                        },
                                        border: '1px solid',
                                        borderColor: selectedPage?.menuName === page.menuName ? 'primary.main' : 'divider',
                                    }}
                                >
                                    <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
                                        {page.menuName || page.menuName}
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary" display="block">
                                        Code: {page.screenCode}
                                    </Typography>
                                </Box>
                            ))}
                            {filteredPages.length === 0 && (
                                <Typography variant="body2" color="text.secondary" align="center">
                                    No pages found
                                </Typography>
                            )}
                        </Box>
                    </GridItem>

                    <GridItem xs={12} md={10} sx={{ height: '100%', p: 0, display: 'flex', flexDirection: 'column' }}>
                        {selectedPage ? (
                            <>
                                <Paper sx={{ p: 2, borderRadius: 0, borderBottom: '1px solid #eee' }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <Box>
                                            <Typography variant="h5">{selectedPage.menuName}</Typography>
                                            <Typography variant="body2" color="text.secondary">
                                                {selectedPage.screenCode} - {selectedPage.screenDescription}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                            <EditInDesignerButton novaSchema={novaSchema} />
                                              <EngineDebugPanel /> 
                                            <Button 
                                                variant="outlined"
                                                size="medium"
                                                iconRight={<SchemaOutlined/>}
                                                sx={{ mr: 1, whiteSpace: 'nowrap' }}
                                                onClick={() => {
                                                    console.log('Current NovaSchema:', novaSchema);}} text="Log Schema" />
                                        </Box>
                                    </Box>
                                </Paper>

                                <Box sx={{ flexGrow: 1, overflow: 'hidden', position: 'relative', bgcolor: '#f5f5f5' }}>
                                    {novaSchema ? (
                                        <DynamicRenderer novaSchema={novaSchema} />
                                    ) : (
                                        <Box sx={{ p: 3, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                            <Typography color="error">No schema For Rendering or empty definition</Typography>
                                        </Box>
                                    )}
                                </Box>
                            </>
                        ) : (
                            <Box
                                sx={{
                                    height: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    bgcolor: '#fafafa',
                                }}
                            >
                                <Typography variant="h6" color="text.secondary">
                                    Select a page from the sidebar to render
                                </Typography>
                            </Box>
                        )}
                    </GridItem>
                </Grid>
      </>
    );
};

const GenericUi: React.FC = () => {
    const navigate = useNavigate();

    // Handle page navigation
    const handleNavigate = (pageName: string, pageTitle?: string, params?: any) => {
        console.log(`[Engine] Navigate to page: ${pageName}`, { pageTitle, params });

        // Navigate using React Router
        navigate(`/nova-page/${pageName}`, {
            state: {
                pageTitle,
                params
            }
        });
    };

    // Handle popup dialogs
    const handleShowPopup = async (popupName: string, data: any): Promise<any> => {
        console.log(`[Engine] Show popup: ${popupName}`, data);

        // TODO: Implement popup/modal display logic
        // For now, return empty object
        return new Promise((resolve) => {
            // You can implement a modal dialog here
            // For demonstration, we'll just log and resolve
            console.log(`[Engine] Popup ${popupName} would show with data:`, data);

            // Simulate user interaction
            setTimeout(() => {
                resolve({
                    // Return data from popup
                    closed: true
                });
            }, 100);
        });
    };

    return (
         <LogCenterProvider>
            <NovaProvider
                workingMode='generator'
                onNavigate={handleNavigate}
                onShowPopup={handleShowPopup}>
                    <DndProvider backend={HTML5Backend}>
                        <GenericUiContent />
                    </DndProvider>
            </NovaProvider>
         </LogCenterProvider>
    );
};

export default GenericUi;
