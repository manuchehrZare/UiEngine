/* eslint-disable */
/**
 * ReportViewer Component
 * Renders PDF reports using PdfViewer component
 * Supports both absolute positioning and responsive grid layout
 */

import React, { useState, useEffect } from 'react';
import { GridItem, PdfViewer, Box } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { boundsToGridSize } from '..';

export const ReportViewerComponent: React.FC<NovaComponentProps> = ({
    id,
    name,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    xs,
    value,
    ...props
}) => {
    const containerWidth = parentBounds?.width || 960;
    const [pdfData, setPdfData] = useState<string | undefined>(undefined);

    // Update PDF data when value changes
    useEffect(() => {
        if (value) {
            setPdfData(value as string);
        }
    }, [value]);

    // Filter out props that shouldn't be passed to PdfViewer
    const {
        type,
        enabled,
        designComponent,
        component,
        componentKey,
        allPages,
        regionName,
        label,
        fieldLabel,
        text,
        popup,
        placeholder,
        children,
        ...pdfViewerProps
    } = props;

    const reportViewerContent = (
        <Box
            sx={{
                width: '100%',
                height: '100%',
                minHeight:  400,
                display: 'flex',
                flexDirection: 'column'
            }}
        >
            <PdfViewer
                source={pdfData}
                {...pdfViewerProps}
            />
        </Box>
    );

    if (useAbsolutePositioning) {
        return reportViewerContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12} minHeight={400}>
                {reportViewerContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
            xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}
             minHeight={400}>
            {reportViewerContent}
        </GridItem>
    );
};
