/* eslint-disable */
/**
 * DateTimePicker Component Wrapper
 * Wraps the lib DateTimePicker component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { DateTimePicker } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const DateTimePickerComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;

    // Ensure string properties are never undefined to prevent .substring() errors
    const safeProps = {
        ...props,
        label: label || '',
        name: name || id || 'datetimepicker',
        value: value || null, // DateTimePicker expects null for empty date, not undefined
        control: control as any,
    };

    return <DateTimePicker {...safeProps} />;
};
