/* eslint-disable */
/**
 * Table Component
 * Renders EBML Table components with DataGrid
 * Supports both absolute positioning and responsive grid layout
 */

import React, { useMemo } from 'react';
import { DataGrid, GridItem, Box }  from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { boundsToGridSize, useNova } from '..';

// Column definition from EBML adapterInfo
interface Column {
    Id?: string;
    Title?: string;
    Type?: string;
    Visible?: boolean;
    Editable?: boolean;
    Order?: number;
    Alignment?: string;
    Width?: number;
}

// Map EBML column type to DataGrid column type
const mapColumnType = (type?: string): string => {
    if (!type) return 'string';

    const typeMap: Record<string, string> = {
        'String': 'string',
        'Number': 'number',
        'Integer': 'number',
        'Decimal': 'number',
        'Date': 'date',
        'DateTime': 'dateTime',
        'Boolean': 'boolean',
    };

    return typeMap[type] || 'string';
};

// Map EBML alignment to DataGrid alignment
const mapAlignment = (alignment?: string): 'left' | 'center' | 'right' => {
    if (!alignment) return 'left';

    const alignmentMap: Record<string, 'left' | 'center' | 'right'> = {
        'Left': 'left',
        'Center': 'center',
        'Right': 'right',
        'LEADING': 'left',
        'TRAILING': 'right',
    };

    return alignmentMap[alignment] || 'left';
};

// Parse background color from EBML format (e.g., "255,255,255")
const parseColor = (color?: string): string => {
    if (!color) return '#ffffff';

    const parts = color.split(',').map(p => parseInt(p.trim()));
    if (parts.length === 3) {
        return `rgb(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }

    return color;
};

export const TableComponent: React.FC<NovaComponentProps> = ({
    id,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    adapterInfo,
    background,
    xs,
    ...props
}) => {
    const bgColor = parseColor(background);
    const engine = useNova();

    // Calculate grid size based on parent container width
    const containerWidth = parentBounds?.width || 960;

    // Get rows from component state (set by remote call actions)
    const componentState = engine.getComponentState(id);
    const rows = useMemo(() => {
        // Priority: rows property > value property > empty array
        const stateRows = componentState?.rows || componentState?.value || [];

        // Ensure each row has an id (required by DataGrid)
        if (Array.isArray(stateRows)) {
            return stateRows.map((row, index) => ({
                ...row,
                id: row.id ?? index + 1
            }));
        }

        return [];
    }, [componentState?.rows, componentState?.value]);

    // Parse columns from adapterInfo
    const columns = useMemo(() => {
        let tableColumns: Column[] = [];
        let dataGridColumns: any[] = [];

        if (adapterInfo) {
            try {
                const adapter = typeof adapterInfo === 'string' ? JSON.parse(adapterInfo) : adapterInfo;
                if (Array.isArray(adapter)) {
                    tableColumns = adapterInfo.map((col: any) => ({
                        Id: col.id,
                        Title:  col.title,
                        Type: col.type || col.Type,
                        Visible: col.visible !== false && col.Visible !== false,
                        Editable: col.editable || col.Editable || false,
                        Order: col.order || col.Order,
                        Alignment: col.align || col.Alignment,
                        Width: col.width || col.Width,
                    }));
                }
                //else if (adapter.Column && Array.isArray(adapter.Column)) {
                //     tableColumns = adapter.Column;
                // } else if (adapter.columns && Array.isArray(adapter.columns)) {
                //     tableColumns = adapter.columns.map((col: any) => ({
                //         Id: col.field || col.name || col.columnName || col.Id,
                //         Title: col.headerName || col.label || col.title || col.Title,
                //         Type: col.type || col.Type,
                //         Visible: col.visible !== false && col.Visible !== false,
                //         Editable: col.editable || col.Editable || false,
                //         Order: col.order || col.Order,
                //         Alignment: col.align || col.Alignment,
                //         Width: col.width || col.Width,
                //     }));
                // }

                if (tableColumns.length > 0) {
                    dataGridColumns = tableColumns
                        .filter((col) => col.Visible !== false)
                        .sort((a, b) => (a.Order || 0) - (b.Order || 0))
                        .map((col) => ({
                            field: col.Id || col.Title || 'field',
                            headerName: col.Title || col.Id || 'Column',
                            editable: col.Editable || false,
                            type: mapColumnType(col.Type),
                            align: mapAlignment(col.Alignment),
                            headerAlign: mapAlignment(col.Alignment),
                            flex: 1,
                        }));
                }
            } catch (error) {
                console.error('Error parsing table adapterInfo:', error);
            }
        }

        // If no columns defined, use default columns
        if (dataGridColumns.length === 0) {
            dataGridColumns = [
                { field: 'id', headerName: 'ID', width: 100 },
                { field: 'value', headerName: 'Value', flex: 1 },
            ];
        }
        return dataGridColumns;
    }, [adapterInfo]);

    const tableContent = (
        <Box
            sx={{
                width: '100%',
                height: useAbsolutePositioning ? '100%' : bounds?.height || 400,
                backgroundColor: bgColor,
                display: 'flex',
                flexDirection: 'column',
            }}
            minHeight={200}
        >
            <DataGrid
                rows={rows}
                columns={columns}
                pagination
                pageSizeOptions={[5, 10, 25, 50]}
                
                sx={{
                    border: '1px solid #ddd',
                    '& .MuiDataGrid-cell': {
                        borderColor: '#ddd',
                    },
                    '& .MuiDataGrid-columnHeaders': {
                        backgroundColor: '#f5f5f5',
                        borderColor: '#ddd',
                    },
                }}
                {...props}
            />
        </Box>
    );

    if (useAbsolutePositioning) {
        return tableContent;
    }

    if (!bounds) {
        return (
            <GridItem xs={12}>
                {tableContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs ?? 12;
    return (
        <GridItem
            xs={resolvedXs}
            sm={resolvedXs}
            md={resolvedXs}
            lg={resolvedXs}
            sx={{ display: 'flex', flexDirection: 'column', minHeight: gridSize.minHeight }}
        >
            {tableContent}
        </GridItem>
    );
};
