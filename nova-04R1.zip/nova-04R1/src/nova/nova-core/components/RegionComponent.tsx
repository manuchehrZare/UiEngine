/* eslint-disable */
/**
 * Region Component
 * Renders EBML Region components (references to reusable sub-pages)
 * Supports both absolute positioning and responsive grid layout
 */

import React, { useState, useEffect } from 'react';
import { Box, Label } from '../../../seker-ui-lib';
import { GridItem } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import type { NovaUiSchema } from '../types/nova-ui-schema.types';
import { PreviewRenderer } from '../../nova-studio/components/PreviewRenderer';
import { getScreenEbmlSchema } from '../nova-ebml/ebml-schema-provider';
import { convertNovaEbmlToNovaUiSchema } from '../nova-ebml/nova-ebml-converter';

export const RegionComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    regionName,
    xs,
    component,
    componentKey,
    allPages,
    designComponent,
    name,
    type,
    text,
    value,
    placeholder,
    enabled,
    children,
    ...gridProps
}) => {
    const gridSize = { xs: 12, minHeight: 0 };
    const [regionSchema, setRegionSchema] = useState<NovaUiSchema | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadRegionSchema = async () => {
            setIsLoading(true);
            try {
                const regionEbml = await getScreenEbmlSchema(regionName);
                if (regionEbml) {
                    const convertedSchema = convertNovaEbmlToNovaUiSchema(regionEbml);
                    setRegionSchema(convertedSchema);
                } else {
                    setRegionSchema(null);
                }
            } catch (error) {
                setRegionSchema(null);
            } finally {
                setIsLoading(false);
            }
        };

        if (regionName) {
            loadRegionSchema();
        } else {
            setRegionSchema(null);
            setIsLoading(false);
        }
    }, [regionName]);

    // Helper function to wrap content based on positioning mode
    const wrapContent = (content: React.ReactNode) => {
        if (useAbsolutePositioning) {
            return content;
        }

        const resolvedXs = xs ?? gridSize.xs;
        return (
            <GridItem xs={resolvedXs} sx={{ minHeight: gridSize.minHeight }} {...gridProps}>
                {content}
            </GridItem>
        );
    };

    // No region name specified
    if (!regionName) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #ff9800',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text="[Region: No name specified]" />
            </Box>
        );
    }

    // Loading state
    if (isLoading) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #2196f3',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <Label text={`[Loading region: ${regionName}...]`} />
            </Box>
        );
    }

    // Region not found or error loading
    if (!regionSchema) {
        return wrapContent(
            <Box sx={{
                border: '2px dashed #f44336',
                p: 1,
                width: '100%',
                height: '100%',
                boxSizing: 'border-box'
            }}>
                <Label text={`[Region not found: ${regionName}]`} />
            </Box>
        );
    }

    // Successfully loaded region - render it without additional grid container
    // The region's internal layout should control its own structure
    const content = (
        <Box sx={{
            width: '100%',
            height: '100%',
            position: useAbsolutePositioning ? 'relative' : undefined,
            display: 'flex',
            flexDirection: 'column'
        }}>
        <PreviewRenderer component={regionSchema.ui[0]} />
        </Box>
    );

    return wrapContent(content);
};
