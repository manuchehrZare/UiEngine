/* eslint-disable */
/**
 * useComponentRuntime Hook
 * Registers component methods and event handlers with the Nova runtime system
 *
 * This hook should be used by all Nova components to enable:
 * 1. Method execution via BeanAction
 * 2. Event triggering and action execution
 * 3. Automatic event binding setup
 */

import { useEffect, useMemo } from 'react';
import { useNova } from '../context/NovaContext';
import { registerAllComponentMethods } from '../execution/componentMethodMapper';
import { wrapComponentPropsWithEventHandlers } from '../execution/componentEventMapper';

/**
 * Hook that registers component methods and sets up event handlers
 */
export function useComponentRuntime(
    componentId: string,
    componentType: string,
    props: any
) {
    const {
        registerComponentMethod,
        getComponentState,
        setComponentState,
        invokeComponentMethod,
        getVariable,
        setVariable,
        fireEvent,
        schema,
    } = useNova();

    // Register all component methods on mount
    useEffect(() => {
        registerAllComponentMethods(
            componentId,
            componentType,
            registerComponentMethod,
            getComponentState,
            setComponentState,
            invokeComponentMethod,
            getVariable,
            setVariable
        );

        // Cleanup: Unregister methods on unmount (optional)
        return () => {
            // Methods are stored in a Map, so they'll be naturally cleaned up
            // when the component unmounts if we remove the component's entry
            // For now, we'll leave them registered for simplicity
        };
    }, [componentId, componentType]);

    // Get event bindings for this component from schema
    const eventBindings = useMemo(() => {
        if (!schema?.events?.actions) return [];

        const bindings: Array<{ eventName: string; actionId: string; rule?: string }> = [];

        schema.events.actions.forEach(action => {
            // Check if this action is bound to this component
            if (action.componentId === componentId) {
                bindings.push({
                    eventName: action.eventName || '',
                    actionId: action.id,
                    rule: action.rule,
                });
            }
        });

        return bindings;
    }, [schema, componentId]);

    // Wrap props with event handlers
    const wrappedProps = useMemo(() => {
        if (eventBindings.length === 0) {
            return props;
        }

        return wrapComponentPropsWithEventHandlers(
            componentId,
            componentType,
            props,
            eventBindings,
            fireEvent
        );
    }, [componentId, componentType, props, eventBindings, fireEvent]);

    return wrappedProps;
}

/**
 * Hook for lifecycle events (Page component)
 * Handles pageLoad, pageClose, etc.
 */
export function usePageLifecycle(componentId: string) {
    const { fireEvent } = useNova();

    useEffect(() => {
        // Fire pageLoad event on mount
        fireEvent(componentId, 'pageLoad');

        // Fire pageClose event on unmount
        return () => {
            fireEvent(componentId, 'pageClose');
        };
    }, [componentId, fireEvent]);
}

/**
 * Hook for automatic component state synchronization
 * Keeps component local state in sync with Nova component state
 */
export function useComponentState<T = any>(componentId: string, initialValue?: T): [T, (value: T) => void] {
    const { getComponentState, setComponentState } = useNova();

    const value = getComponentState(componentId)?.value ?? initialValue;

    const setValue = (newValue: T) => {
        setComponentState(componentId, { value: newValue });
    };

    return [value, setValue];
}

/**
 * Hook for component visibility control
 * Returns whether component should be visible based on Nova state
 */
export function useComponentVisibility(componentId: string, defaultVisible: boolean = true): boolean {
    const { getComponentState } = useNova();
    const state = getComponentState(componentId);
    return state?.visible ?? defaultVisible;
}

/**
 * Hook for component enabled/disabled state
 */
export function useComponentEnabled(componentId: string, defaultEnabled: boolean = true): boolean {
    const { getComponentState } = useNova();
    const state = getComponentState(componentId);
    return !(state?.disabled ?? !defaultEnabled);
}

/**
 * Simplified hook that just returns component state with runtime features
 * Use this in components to get enhanced props with event handlers
 */
export function useNovaComponent(componentId: string, componentType: string, props: any) {
    const wrappedProps = useComponentRuntime(componentId, componentType, props);
    const visible = useComponentVisibility(componentId, true);

    return {
        ...wrappedProps,
        style: {
            ...wrappedProps.style,
            display: visible ? undefined : 'none',
        },
    };
}
