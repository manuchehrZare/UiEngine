/* eslint-disable */
/**
 * useReferenceData Hook
 * Hook for fetching reference data for Select components on page load
 */

import { useEffect, useState } from 'react';
import axios from 'axios';
import { useNova } from '../context/NovaContext';
import type { DesignComponent } from '../types';

export interface ReferenceDataItem {
    name: string;
    items: any[];
}

export interface ReferenceDataResponse {
    resultList: ReferenceDataItem[];
}

export interface ReferenceDataRequest {
    requestList: Array<{ name: string }>;
}

/**
 * Collects all Select components with referenceDataName property
 * Also collects referenceDataName from Table columns
 */
const collectReferenceDataNames = (components: DesignComponent[]): string[] => {
    const names = new Set<string>();

    const traverse = (component: DesignComponent) => {
        // Collect from Select components
        if (component.type === 'Select' && component.props?.referenceDataName) {
            names.add(component.props.referenceDataName);
        }

        // Collect from Table component columns
        if (component.type === 'TableComponent' && component.props?.adapterInfo) {
            const columns = component.props.adapterInfo;
            if (Array.isArray(columns)) {
                columns.forEach((column: any) => {
                    if (column.type ==='COMBO_ADAPTER') {
                        column.style.properties.forEach((propery: any) => {
                            if (propery.name ==='referenceDataName') {
                                names.add(propery.text);
                            }

                        });
                    }
                });
            }
        }

        if (component.children) {
            component.children.forEach(traverse);
        }
    };

    components.forEach(traverse);
    return Array.from(names);
};

/**
 * Hook for fetching and managing reference data
 *
 * @example
 * ```typescript
 * import { useReferenceData } from '@nova/hooks';
 *
 * const MyPage = ({ novaSchema }) => {
 *   const { referenceData, loading, error } = useReferenceData(novaSchema.ui);
 *
 *   return <div>...</div>;
 * };
 * ```
 */
export const useReferenceData = (
    components: DesignComponent[],
) => {

    const engine = useNova();
    const [referenceData, setReferenceData] = useState<ReferenceDataResponse | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<Error | null>(null);

    useEffect(() => {
        const fetchReferenceData = async () => {
            if (!components || components.length === 0) {
                return;
            }

            // Collect all referenceDataName values from Select components
            const nameList = collectReferenceDataNames(components);
            if (nameList.length === 0) {
                return;
            }

            try {
                setLoading(true);
                setError(null);

                // Prepare request
                const request: ReferenceDataRequest = {
                    requestList: nameList.map(name => ({ name })),
                };

                // Fetch reference data in a single request using hardcoded endpoint
                const response = await axios.post('/api/nova/gateway/reference-data', request);

                const data: ReferenceDataResponse = response.data;
                setReferenceData(data);

                // Set options for each Select component
                if (data?.resultList) {
                    components.forEach(component => {
                        if (component.type === 'Select' && component.props?.referenceDataName) {
                            const refDataName = component.props.referenceDataName;
                            const refData = data.resultList.find(item => item.name === refDataName);

                            if (refData && component.props.id) {
                                // Set options using component state
                                engine.setComponentState(component.props.id, {
                                    options: {
                                        data: refData.items || [],
                                        displayField: component.props.displayField || 'value',
                                        displayValue: component.props.displayValue || 'key',
                                    }
                                });
                            }
                        }
                    });
                }
            } catch (err) {
                const errorMessage = axios.isAxiosError(err)
                    ? err.response?.data?.message || err.message
                    : 'Failed to fetch reference data';
                const newError = new Error(errorMessage);
                setError(newError);
                console.error('Error fetching reference data:', err);
            } finally {
                setLoading(false);
            }
        };

        // Only fetch when engine is ready
        if (engine.lifecyclePhase === 'ready') {
            fetchReferenceData();
        }
    }, [components, engine, engine.lifecyclePhase]);

    return { referenceData, loading, error };
};

/**
 * Generate reference data request list from name array
 */
export const generateReferenceDataRequestList = (params: { nameList: string[] }) => {
    return params.nameList.map(name => ({ name }));
};
