/* eslint-disable */
export const menuDefinitions =[
  {
    "menuName": "Bireysel Kredi Kartı Başvuru",
    "screenName": "CPS001_APPLICATION_TEST",
    "screenCode": "CPS001",
    "screenDescription": "ALFA'DA HIZLI BAŞVURU OLUŞTURABİLMEK ADINA KULLANILACAK EKRANDIR."
  },
  {
    "menuName": "Karekod CVM Parametre Tanımlama",
    "screenName": "CPS100_CCC_CVM_PARAMETER",
    "screenCode": "CPS100",
    "screenDescription": "CVM PARAMETRELERİNİN TANIMLARININ YAPILMASI İÇİN KULLANILAN EKRAN"
  },
  {
    "menuName": "Şifre Atama ve Kart Detay Gözlem",
    "screenName": "CPS002_CARD_INFO_TEST",
    "screenCode": "CPS002",
    "screenDescription": "ALFA'DA KULLANILACAK OLAN KART BILGILERINI GOSTEREN EKRANDIR"
  },
  {
    "menuName": "Kısıt Kaldırma",
    "screenName": "MEV004_DEPOSIT_HOLD_RELEASE",
    "screenCode": "MEV004"
  },
  {
    "menuName": "Kısıt Koyma",
    "screenName": "MEV003_DEPOSIT_HOLD_MONEY",
    "screenCode": "MEV003"
  },
  {
    "menuName": "Bloke Koyma",
    "screenName": "MEV007_DEPOSIT_MONEY_BLOCKING",
    "screenCode": "MEV007"
  },
  {
    "menuName": "Bloke Çözme",
    "screenName": "MEV008_DEPOSIT_BLOCK_RELEASE",
    "screenCode": "MEV008"
  },
  {
    "menuName": "Gece Gündüz Hesap Tanımlama/ Güncelleme Ekranı",
    "screenName": "MEV221_DEPOSIT_DAY_NIGHT_ACC",
    "screenCode": "MEV221"
  },
  {
    "menuName": "Birçok Para Birimli Rezervasyon Gerçekleştirme",
    "screenName": "MEV124_TIME_DEPOSIT_REZERVATION_REALIZING",
    "screenCode": "MEV124"
  },
  {
    "menuName": "Vadeli Hesap Parametre Yönetimi",
    "screenName": "MEV119_TIME_DEPOSIT_PRODUCT_PARAMETER_DEFINITION",
    "screenCode": "MEV119",
    "screenDescription": "ÜRÜN PARAMETRE YÖNETİMİ"
  },
  {
    "menuName": "Vadeli Hesap Temdit Edilen Hesap İşlemleri",
    "screenName": "MEV122_TIME_DEPOSIT_RENEWAL_LIST_NEW",
    "screenCode": "MEV122"
  },
  {
    "menuName": "Kısıt Koyma",
    "screenName": "MEV067_TIME_DEPOSIT_HOLD",
    "screenCode": "MEV067"
  },
  {
    "menuName": "Devlet Katkısı Gözlem",
    "screenName": "MEV126_TIME_DEPOSIT_STATE_SUBSIDY_ACCOUNT_LIST",
    "screenCode": "MEV126"
  },
  {
    "menuName": "Gece Gündüz Parametre Girişi",
    "screenName": "MEV202_DEPOSIT_DAY_NIGHT_PARAMETERS_DEF",
    "screenCode": "MEV202",
    "screenDescription": "GECE-GÜNDÜZ HESAP PARAMETRE TANIMLAMA"
  },
  {
    "menuName": "Vadeli Hesap Faiz Güncelleme",
    "screenName": "MEV059_TIME_DEPOSIT_INTEREST_UPDATE",
    "screenCode": "MEV059"
  },
  {
    "menuName": "Kur Korumalı Mevduat Merkez Bankası Bildirimleri",
    "screenName": "MEV136_TIME_DEPOSIT_KKM_NOTIFICATION",
    "menuKey": "KKM",
    "screenCode": "MEV136",
    "screenDescription": "KUR KORUMALI MEVDUAT MERKEZ BANKASI BİLDİRİMLERİ"
  },
  {
    "menuName": "Vadeli Hesap Tutar Limiti Tanımlama - Fon",
    "screenName": "MEV115_TIME_DEPOSIT_FUND_AMOUNT_LIMIT_PARAMETERS_DEFINITION",
    "screenCode": "MEV115",
    "screenDescription": "VADELI MEVDUAT FON TUTAR LIMITI TANIMLAMA EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Açma - Güncelleme",
    "screenName": "MEV050_TIME_DEPOSIT_ACCOUNT_DEFINITION",
    "screenCode": "MEV050"
  },
  {
    "menuName": "Devlet Katkısı Talep ve Ödeme",
    "screenName": "MEV125_TIME_DEPOSIT_SUBSIDY_REQUEST",
    "screenCode": "MEV125"
  },
  {
    "menuName": "Vadeli Hesap Parametre Tanımlama Fon",
    "screenName": "MEV058_TIME_DEPOSIT_PARAMETERS",
    "screenCode": "MEV058"
  },
  {
    "menuName": "Vadeli Hesap Kampanya Grup Tanımlama",
    "screenName": "MEV118_TIME_DEPOSIT_CAMPAIGN_GROUP_DEFINITION",
    "screenCode": "MEV118",
    "screenDescription": "KAMPANYA GRUP TANIMLAMA EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Kapama - Kısmi Ödeme",
    "screenName": "MEV054_TIME_DEPOSIT_PAYMENT_CLOSE",
    "screenCode": "MEV054"
  },
  {
    "menuName": "Vadeli Hesap Manuel Faiz Verme",
    "screenName": "MEV052_TIME_DEPOSIT_MANUEL_INTEREST_ASSESMENT",
    "screenCode": "MEV052"
  },
  {
    "menuName": "Vadeli Hesap Simülasyon",
    "screenName": "MEV060_TIME_DEPOSIT_SIMULATION",
    "screenCode": "MEV060"
  },
  {
    "menuName": "Vadeli Taahhütlü İstisna Tanımlama",
    "screenName": "MEV120_TIME_DEPOSIT_CONTRACTED_EXCEPTION",
    "screenCode": "MEV120",
    "screenDescription": "VADELİ MEVDUAT İSTİSNA EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Kampanya Tanımlama",
    "screenName": "MEV061_TIME_DEPOSIT_CAMPAIGN",
    "screenCode": "MEV061"
  },
  {
    "menuName": "Kısıt Kaldırma",
    "screenName": "MEV057_TIME_DEPOSIT_HOLD_RELEASE",
    "screenCode": "MEV057"
  },
  {
    "menuName": "Vadeli Mevduat Ajandam",
    "screenName": "MEV121_TIME_DEPOSIT_DAYBOOK",
    "screenCode": "MEV121"
  },
  {
    "menuName": "Vadeli Hesap Marj Tanımlama - İş Kolu",
    "screenName": "MEV117_TIME_DEPOSIT_PROFIT_CENTER_MARGIN_PARAMETERS_DEFINITION",
    "screenCode": "MEV117",
    "screenDescription": "VADELI MEVDUAT IS KOLU MARJ TANIMLAMA EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Parametre Tanımlama Mevduat",
    "screenName": "MEV066_TIME_DEPOSIT_PARAMETERS_NEW",
    "screenCode": "MEV066"
  },
  {
    "menuName": "Fiyatlama Data Set Tanımlama",
    "screenName": "MEV129_TIME_DEPOSIT_PRICING_DATA_SET_DEF",
    "screenCode": "MEV129",
    "screenDescription": "FİYATLAMA DATA SET TANIMLAMA"
  },
  {
    "menuName": "Mevduat Takip Raporu",
    "screenName": "MEV134_TIME_DEPOSIT_PRICING_REPORT",
    "screenCode": "MEV134",
    "screenDescription": "MEVDUAT TAKİP RAPORU"
  },
  {
    "menuName": "Fiyatlama Kota Bilgileri Tanımlama",
    "screenName": "MEV128_TIME_DEPOSIT_PRICING_QUOTA",
    "screenCode": "MEV128",
    "screenDescription": "FİYATLAMA KOTA GİRİŞ EKRANI"
  },
  {
    "menuName": "Fiyatlama Parametre Tanımlama",
    "screenName": "MEV130_TIME_DEPOSIT_PRICING_PARAMETER_DEF",
    "screenCode": "MEV130",
    "screenDescription": "FİYATLAMA PARAMETRE TANIMLAMA"
  },
  {
    "menuName": "Fiyatlama Kural Tanımlama",
    "screenName": "MEV127_TIME_DEPOSIT_PRICING_RULE_DEF",
    "screenCode": "MEV127",
    "screenDescription": "FİYATLAMA KURAL TANIMLAMA"
  },
  {
    "menuName": "Müşteri İstisna Tanımlama",
    "screenName": "MEV132_TIME_DEPOSIT_PRICING_CUST_EXCEPTION_DEF",
    "screenCode": "MEV132",
    "screenDescription": "MÜŞTERİ İSTİSNA TANIMLAMA"
  },
  {
    "menuName": "Stratejik Kota Performans Takip Raporu",
    "screenName": "MEV135_TIME_DEPOSIT_PRICING_STRATAGIC_RATE_REPORT",
    "screenCode": "MEV135",
    "screenDescription": "STRATEJİK KOTA PERFORMANS TAKİP RAPORU"
  },
  {
    "menuName": "Ortak Mevduat Kurma",
    "screenName": "MEV131_TIME_DEPOSIT_PRICING_CUST_REL",
    "screenCode": "MEV131",
    "screenDescription": "ORTAK MEVDUAT KURMA"
  },
  {
    "menuName": "Fiyatlama Onay Parametre Tanımlama",
    "screenName": "MEV133_TIME_DEPOSIT_PRICING_AUTH_DEF",
    "screenCode": "MEV133",
    "screenDescription": "FİYATLAMA ONAY PARAMETRE EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Temdit İşlemleri",
    "screenName": "MEV051_TIME_DEPOSIT_RENEWAL_LIST",
    "screenCode": "MEV051"
  },
  {
    "menuName": "Vadeli Hesap Marj Tanımlama - Fon",
    "screenName": "MEV116_TIME_DEPOSIT_FUND_MARGIN_PARAMETERS_DEFINITION",
    "screenCode": "MEV116",
    "screenDescription": "VADELI MEVDUAT FON MARJ TANIMLAMA EKRANI"
  },
  {
    "menuName": "Birikimli Gelecek / Şeker Çocuk Hesap Aylık Tahsilat",
    "screenName": "MEV068_TIME_DEPOSIT_CUMULATIVE_PAYMENT",
    "screenCode": "MEV068",
    "screenDescription": "BİRİKİMLİ VADELİ HESAP AYLIK ÖDEME EKRANI"
  },
  {
    "menuName": "Kısıt Gözlem Raporu",
    "screenName": "MEV038_DEPOSIT_HOLD_LIST",
    "screenCode": "MEV038",
    "screenDescription": "MEV038_DEPOSIT_HOLD_LIST"
  },
  {
    "menuName": "Bloke Gözlem Raporu",
    "screenName": "MEV027_DEPOSIT_BLOCK_LIST",
    "screenCode": "MEV027",
    "screenDescription": "MEV027_DEPOSIT_BLOCK_LIST"
  },
  {
    "menuName": "KMH Gecikme Listesi",
    "screenName": "MEV026_DEPOSIT_KRM_BKS_CHASING",
    "screenCode": "MEV026"
  },
  {
    "menuName": "KMH Tahakkuk Listesi",
    "screenName": "MEV017_DEPOSIT_KRM_ASSESSMENT_LIST",
    "screenCode": "MEV017"
  },
  {
    "menuName": "KMH Hesapları Gözlem",
    "screenName": "MEV047_DEPOSIT_KRM_ACCOUNT_LIST",
    "screenCode": "MEV047"
  },
  {
    "menuName": "Vadesiz Hesap Tarihçe Gözlem",
    "screenName": "MEV010_DEPOSIT_ACCOUNT_HISTORY",
    "screenCode": "MEV010"
  },
  {
    "menuName": "KMH Hareketleri",
    "screenName": "MEV019_DEPOSIT_KRM_TRANSACTIONS",
    "screenCode": "MEV019"
  },
  {
    "menuName": "KMH Reeskont Listesi",
    "screenName": "MEV015_DEPOSIT_KRM_REESKONT_LIST",
    "screenCode": "MEV015"
  },
  {
    "menuName": "Vadesiz Hesap Tahakkuk Gözlem",
    "screenName": "MEV023_DEPOSIT_ASSESSMENT_LIST",
    "screenCode": "MEV023"
  },
  {
    "menuName": "Vadesiz Hesap Reeskont Gözlem",
    "screenName": "MEV022_DEPOSIT_REESKONT_LIST",
    "screenCode": "MEV022"
  },
  {
    "menuName": "Vadesiz Hesap Hareketleri",
    "screenName": "MEV002_DEPOSIT_ACCOUNT_TRANSACTIONS",
    "screenCode": "MEV002"
  },
  {
    "menuName": "Vadesiz Hesap Bakiye Gözlem",
    "screenName": "MEV200_DEPOSIT_CURRENT_BALANCE_LIST",
    "screenCode": "MEV200",
    "screenDescription": "VADESİZ HESAP BAKİYE GÖZLEM EKRANI"
  },
  {
    "menuName": "Vadesiz Hesap Listesi",
    "screenName": "MEV012_DEPOSIT_ACCOUNT_LIST",
    "screenCode": "MEV012"
  },
  {
    "menuName": "Hesap işletim/Ekstre/Geçmiş ekstre/Gecikme ücreti Gözlem",
    "screenName": "MEV013_DEPOSIT_CHARGE_LIST",
    "screenCode": "MEV013"
  },
  {
    "menuName": "Kampanya Müşteri Listesi",
    "screenName": "MEV049_DEPOSIT_CAMPAIGN_CUST_LIST",
    "screenCode": "MEV049"
  },
  {
    "menuName": "Birikimli Gelecek / Şeker Çocuk Hesap Tahsil Edilmemiş Dönemler Listesi",
    "screenName": "MEV069_TIME_DEPOSIT_CUMULATIVE_UNPAID_MONTH_PAYMENT",
    "screenCode": "MEV069",
    "screenDescription": "BİRİKİMLİ VADELİ ÖDENMEMİŞ DÖNEM GÖZLEM EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Ekstresi",
    "screenName": "MEV087_TIME_DEPOSIT_EKSTRE",
    "screenCode": "MEV087"
  },
  {
    "menuName": "Vadeli Hesap Kar Zarar Raporu",
    "screenName": "MEV073_TIME_DEPOSIT_BENEFIT_AND_LOSS_REPORT",
    "screenCode": "MEV073"
  },
  {
    "menuName": "Vadeli Hesap Fark Raporu",
    "screenName": "MEV078_TIME_DEPOSIT_DIFFERENCE_REPORT",
    "screenCode": "MEV078"
  },
  {
    "menuName": "Vadeli Hesap Maliyet Raporu",
    "screenName": "MEV071_TIME_DEPOSIT_COST_REPORT",
    "screenCode": "MEV071"
  },
  {
    "menuName": "VADELI HESAP BATCH TEST",
    "screenName": "MEV099_TIME_DEPOSIT_TEST",
    "screenCode": "MEV099"
  },
  {
    "menuName": "Birikimli Gelecek / Şeker Çocuk Hesap Aylık Tahsilat Gözlem",
    "screenName": "MEV110_TIME_DEPOSIT_CUMULATIVE_PAYMENT_REPORT",
    "screenCode": "MEV110",
    "screenDescription": "BİRİKİMLİ VADELİ HESAP ÖDEME GÖZLEM EKRANI"
  },
  {
    "menuName": "Vadeli Hesap Faiz Gelirleri Raporu",
    "screenName": "MEV084_TIME_DEPOSIT_INTEREST_INCOME_REPORT",
    "screenCode": "MEV084"
  },
  {
    "menuName": "Vadeli Hesap Tarihçe Gözlem",
    "screenName": "MEV056_TIME_DEPOSIT_HISTORY",
    "screenCode": "MEV056"
  },
  {
    "menuName": "Vadeli Hesap Reeskont Gözlem",
    "screenName": "MEV063_TIME_DEPOSIT_REESKONT_LIST",
    "screenCode": "MEV063"
  },
  {
    "menuName": "Vadeli Hesap Parametre Gözlem Raporu",
    "screenName": "MEV081_TIME_DEPOSIT_PARAMETER_REPORT",
    "screenCode": "MEV081"
  },
  {
    "menuName": "Vadeli Hesap Adedi Raporu",
    "screenName": "MEV075_TIME_DEPOSIT_COUNT_REPORT",
    "screenCode": "MEV075"
  },
  {
    "menuName": "Manuel Faiz Verme Gözlem",
    "screenName": "MEV065_TIME_DEPOSIT_MANUEL_INT_LIST",
    "screenCode": "MEV065"
  },
  {
    "menuName": "Vadeli Hesap Listesi",
    "screenName": "MEV053_TIME_DEPOSIT_LIST",
    "screenCode": "MEV053"
  },
  {
    "menuName": "Vadeli Hesap Hacim-Ortalama Raporu",
    "screenName": "MEV076_TIME_DEPOSIT_CAPACITY_REPORT",
    "screenCode": "MEV076"
  },
  {
    "menuName": "Vadeli Hesap Gün Sonu Onay Kontrol Raporu",
    "screenName": "MEV072_TIME_DEPOSIT_EOD_APPROVE_CONTROL_REPORT",
    "screenCode": "MEV072"
  },
  {
    "menuName": "Vadeli Hesap Temdit Raporu"
  },
  {
    "menuName": "Vadeli Hesap Hareket Gözlem",
    "screenName": "MEV055_TIME_DEPOSIT_TRANSACTIONS_LIST",
    "screenCode": "MEV055"
  },
  {
    "menuName": "Erken Ödenen Vadeli Hesaplar Listesi",
    "screenName": "MEV074_TIME_DEPOSIT_EARLY_PAYMENT_REPORT",
    "screenCode": "MEV074"
  },
  {
    "menuName": "Vadeli Mevduat SDMH SBN Raporu",
    "screenName": "MEV123_TIME_DEPOSIT_PARTIAL_PAYMENT_LIST_FOR_SBN",
    "screenCode": "MEV123"
  },
  {
    "menuName": "Vadeli Hesap Ortalama Gün Sayısı Raporu",
    "screenName": "MEV080_TIME_DEPOSIT_AVERAGE_DAY_COUNT_REPORT",
    "screenCode": "MEV080"
  },
  {
    "menuName": "Vadeli Hesap Migrasyonu",
    "screenName": "MEV098_TIME_DEPOSIT_MIGRATION",
    "screenCode": "MEV098"
  },
  {
    "menuName": "Geri Valörlü Açılan Vadeli Hesaplar Raporu",
    "screenName": "MEV086_TIME_DEPOSIT_BACK_VALOR_REPORT",
    "screenCode": "MEV086"
  },
  {
    "menuName": "Vadeli Hesap Yüksek Hacimli Müşteriler Raporu",
    "screenName": "MEV085_TIME_DEPOSIT_TOP_N_CUSTOMER_REPORT",
    "screenCode": "MEV085"
  },
  {
    "menuName": "Vadeli Hesap Ağırlıklı Ortalama Mevduat Raporu",
    "screenName": "MEV077_TIME_DEPOSIT_AVERAGE_DEPOSIT_REPORT",
    "screenCode": "MEV077"
  },
  {
    "menuName": "Vadeli Hesap Parametre Log Raporu",
    "screenName": "MEV082_TIME_DEPOSIT_PARAMETER_LOG_REPORT",
    "screenCode": "MEV082"
  },
  {
    "menuName": "Vade Aralığına Göre Fark Raporu",
    "screenName": "MEV079_TIME_DEPOSIT_DIFFERENCE_BY_TERM_REPORT",
    "screenCode": "MEV079"
  },
  {
    "menuName": "Vadeli Hesap Tahakkuk Gözlem",
    "screenName": "MEV064_TIME_DEPOSIT_ASSESSMENT_LIST",
    "screenCode": "MEV064"
  },
  {
    "menuName": "Kısmi Ödeme Yapılan Vadeli Hesaplar Listesi",
    "screenName": "MEV083_TIME_DEPOSIT_PARTIAL_PAYMENT_REPORT",
    "screenCode": "MEV083"
  },
  {
    "menuName": "Dekont Listesi",
    "screenName": "IDC002_STATEMENTS_LIST",
    "screenCode": "IDC002",
    "screenDescription": "DEKONT LISTESI"
  },
  {
    "menuName": "ArtanHesap Tanımlama/Güncelleme",
    "screenName": "MEV100_SEKERHESAP_DEFINITION",
    "screenCode": "MEV100"
  },
  {
    "menuName": "ArtanHesap Fon İşlemleri Gözlem",
    "screenName": "MEV101_SEKERHESAP_FUND_TRANSACTIONS",
    "screenCode": "MEV101"
  },
  {
    "menuName": "ArtanHesap Ödeme Talimatları Gözlem",
    "screenName": "MEV102_SEKERHESAP_PAY_ORDERS_LIST",
    "screenCode": "MEV102"
  },
  {
    "menuName": "ArtanHesap Fon İşlemleri",
    "screenName": "MEV103_SEKERHESAP_FUND_OPERATIONS",
    "screenCode": "MEV103"
  },
  {
    "menuName": "Hesap Gizlilik Profil İlişkisi",
    "screenName": "MEV037_DEPOSIT_CURRENT_ACC_PRIVACY",
    "screenCode": "MEV037"
  },
  {
    "menuName": "Ekstre Bilgileri Tanımlama",
    "screenName": "MEV041_DEPOSIT_EKSTRE_INFORMATION",
    "screenCode": "MEV041",
    "screenDescription": "EKSTE BİLGİLERİ"
  },
  {
    "menuName": "Manuel Ekstre Üretme",
    "screenName": "MEV025_DEPOSIT_CREATE_EKSTRE",
    "screenCode": "MEV025"
  },
  {
    "menuName": "Hesap işletim/Ekstre/Geçmiş ekstre/Gecikme ücreti iptal",
    "screenName": "MEV028_DEPOSIT_CANCEL_CHARGE",
    "screenCode": "MEV028"
  },
  {
    "menuName": "Yeni Gece Gündüz Parametre Düzenleme",
    "screenName": "MEV227_DEPOSIT_GG_PARAMETERS",
    "screenCode": "MEV227",
    "screenDescription": "YENİ GECE GÜNDÜZ PARAMETRE EKRANI"
  },
  {
    "menuName": "Hesap İşletim Ücreti Parametre Tanımlama",
    "screenName": "MEV215_DEPOSIT_ACC_MAN_FEE_PARAMETERS_DEF",
    "screenCode": "MEV215",
    "screenDescription": "HESAP İŞLETİM ÜCRETİ PARAMETRE TANIMLAMA EKRANI"
  },
  {
    "menuName": "KMH Nakit Kullandırım Gözlem",
    "screenName": "MEV203_DEPOSIT_KRM_USAGE_CHARGE_LIST",
    "screenCode": "MEV203",
    "screenDescription": "KMH NAKİT KULLANDIRIM GÖZLEM EKRANI"
  },
  {
    "menuName": "Bankalar Hesabı Açma",
    "screenName": "MEV039_DEPOSIT_CURRENT_BANK_ACCOUNT",
    "screenCode": "MEV039",
    "screenDescription": "BANKA KRM HESABI AÇMA/GÜNCELLEME"
  },
  {
    "menuName": "TKMH Yönetsel",
    "screenName": "MEV030_DEPOSIT_KRM_INSTALLMENT",
    "screenCode": "MEV030"
  },
  {
    "menuName": "KMH Manuel Tahakkuk Hesapla",
    "screenName": "MEV018_DEPOSIT_KRM_MANUEL_ASSESSMENT",
    "screenCode": "MEV018"
  },
  {
    "menuName": "KMH kampanya Müşteri Ekleme/Çıkarma",
    "screenName": "MEV218_DEPOSIT_KRM_ACC_CAMPAIGN_UPDATE",
    "screenCode": "MEV218"
  },
  {
    "menuName": "Kampanya Müşteri Ekleme",
    "screenName": "MEV043_DEPOSIT_CAMPAIGN_CUST_ADDITION",
    "screenCode": "MEV043"
  },
  {
    "menuName": "Kampanya Tanımlama/Güncelleme",
    "screenName": "MEV042_DEPOSIT_CAMPAIGN_DEFINITION",
    "screenCode": "MEV042"
  },
  {
    "menuName": "KMH Kampanya Tanımlama Parametre Ekranı",
    "screenName": "MEV219_DEPOSIT_KRM_CAMPAIGN_DEF",
    "screenCode": "MEV219"
  },
  {
    "menuName": "KMH Hesap İşletim Ücreti İstisnası Düzenleme",
    "screenName": "MEV029_DEPOSIT_CURRENT_BRANCH_KRM",
    "screenCode": "MEV029"
  },
  {
    "menuName": "Vadesiz Hesap Açma/Güncelleme",
    "screenName": "MEV001_DEPOSIT_CURRENT_ACC_DEFINITION",
    "screenCode": "MEV001"
  },
  {
    "menuName": "Vadesiz Hesap Süpürme",
    "screenName": "MEV216_DEPOSIT_SWEEP_CREATE",
    "screenCode": "MEV216"
  },
  {
    "menuName": "Taksitli KMH Tanımlama ve Güncelleme",
    "screenName": "MEV031_DEPOSIT_KRM_INSTALLMENT_ACCOUNT",
    "screenCode": "MEV031"
  },
  {
    "menuName": "Koruma Hesabı Bloke Talimat Gözlem",
    "screenName": "MEV224_DEPOSIT_PROTECTED_ACC_BLOCK_ORDER_LIST",
    "screenCode": "MEV224"
  },
  {
    "menuName": "KMH Nakit Kullandırım İptal",
    "screenName": "MEV204_DEPOSIT_KRM_CANCEL_USAGE_CHARGE",
    "screenCode": "MEV204",
    "screenDescription": "KMH NAKİT KULLANDIRIM İPTAL EKRANI"
  },
  {
    "menuName": "Koruma Hesabı İstisna Bloke Talimatı",
    "screenName": "MEV223_DEPOSIT_RATE_PROTECTED_ACC_BLOCK_ORDER",
    "screenCode": "MEV223"
  },
  {
    "menuName": "Bütçem Taksitli Debit KMH Virman/Virman İptali",
    "screenName": "MEV210_DEPOSIT_BUDGET_TKMH_VIRMAN_OPERATIONS",
    "screenCode": "MEV210",
    "screenDescription": "BÜTÇEM TAKSİTLİ DEBİT KMH VİRMAN / VİRMAN İPTALİ"
  },
  {
    "menuName": "Bütçem Debit KMH Toplu Tahsilat",
    "screenName": "MEV212_DEPOSIT_KRM_BUDGET_COLLECTIVE_PAYMENT",
    "screenCode": "MEV212",
    "screenDescription": "BÜTÇEM DEBİT KMH TOPLU TAHSİLAT"
  },
  {
    "menuName": "Bütçem Taksitli Debit KMH Gözlem",
    "screenName": "MEV211_DEPOSIT_KRM_BUDGET_TKMH_ACC_INFO",
    "screenCode": "MEV211",
    "screenDescription": "BÜTÇEM TAKSİTLİ DEBİT KMH GÖZLEM EKRANI"
  },
  {
    "menuName": "Taksitli KMH İptal",
    "screenName": "MEV034_DEPOSIT_KRM_CANCEL_INSTALLMENT_PAYMENT",
    "screenCode": "MEV034",
    "screenDescription": "TKMH İPTAL EKRANI"
  },
  {
    "menuName": "KMH Limit Dondurma",
    "screenName": "MEV048_DEPOSIT_KRM_LIMIT_CANCEL",
    "screenCode": "MEV048"
  },
  {
    "menuName": "KMH İşlem Listesi",
    "screenName": "MEV046_DEPOSIT_KRM_PROCESS_LIST",
    "screenCode": "MEV046"
  },
  {
    "menuName": "KMH Limitinden Tahsilat Yönetimi",
    "screenName": "MEV006_DEPOSIT_KRM_COLLECT_MANAGEMENT",
    "screenCode": "MEV006"
  },
  {
    "menuName": "Taksitli KMH Simülasyon",
    "screenName": "MEV201_DEPOSIT_KRM_INSTALLMENT_SIMULATION",
    "screenCode": "MEV201"
  },
  {
    "menuName": "KMH Tahakkuk Tarihi Güncelleme",
    "screenName": "MEV044_DEPOSIT_KRM_UPDATE_ASSESSMENT_DATE",
    "screenCode": "MEV044"
  },
  {
    "menuName": "Vadesiz Mevduat Taahhüt Giriş/Gözlem",
    "screenName": "MEV220_DEPOSIT_CURRENT_ACC_CONTRACT",
    "screenCode": "MEV220",
    "screenDescription": "MÜŞTERİ MEVDUAT ORTALAMA"
  },
  {
    "menuName": "Taksitli KMH Ödeme",
    "screenName": "MEV032_DEPOSIT_KRM_INSTALLMENT_PAYMENT",
    "screenCode": "MEV032"
  },
  {
    "menuName": "Eşit Taksitli KMH Ödeme",
    "screenName": "MEV206_DEPOSIT_TKMH_PAYMENT",
    "screenCode": "MEV206",
    "screenDescription": "YENİ TKMH TAKSİT ÖDEME"
  },
  {
    "menuName": "Eşit Taksitli KMH Tanımlama / Güncelleme",
    "screenName": "MEV205_DEPOSIT_TKMH_ACCOUNT",
    "screenCode": "MEV205",
    "screenDescription": "YENİ TKMH TANIMLAMA / GÜNCELLEME"
  },
  {
    "menuName": "Eşit Taksitli KMH Simülasyon",
    "screenName": "MEV209_DEPOSIT_TKMH_SIMULATION",
    "screenCode": "MEV209",
    "screenDescription": "TAKSİTLİ KMH SİMULASYON"
  },
  {
    "menuName": "Eşit Taksitli KMH Tahsilat İptal",
    "screenName": "MEV208_DEPOSIT_TKMH_CANCEL_PAYMENT",
    "screenCode": "MEV208",
    "screenDescription": "TAKSİTLİ KMH TAHSİLAT İPTAL"
  },
  {
    "menuName": "Eşit Taksitli KMH Kullandırım İptal",
    "screenName": "MEV207_DEPOSIT_TKMH_CANCEL_CREATE",
    "screenCode": "MEV207",
    "screenDescription": "YENİ TKMH KULLANDIRIM İPTAL"
  },
  {
    "menuName": "Vadesiz Hesap Faiz Güncelleme",
    "screenName": "MEV020_DEPOSIT_CURRENT_ACC_UPDATE_INT_RATE",
    "screenCode": "MEV020"
  },
  {
    "menuName": "KMH Ürün Parametreleri Tanımlama-Bireysel",
    "screenName": "MEV014_DEPOSIT_KRM_DEFINITION",
    "menuKey": "BKS",
    "screenCode": "MEV014"
  },
  {
    "menuName": "Banka Hesapları Açma",
    "screenName": "MEV001_DEPOSIT_CURRENT_ACC_DEFINITION",
    "menuKey": "GM",
    "screenCode": "MEV001"
  },
  {
    "menuName": "Koruma Hesabı Bloke Talimatı",
    "screenName": "MEV222_DEPOSIT_RATE_PROTECTED_ACC_BLOCK_ORDER",
    "screenCode": "MEV222"
  },
  {
    "menuName": "KMH Ürün Parametreleri Tanımlama-Ticari",
    "screenName": "MEV014_DEPOSIT_KRM_DEFINITION",
    "menuKey": "CCS",
    "screenCode": "MEV014"
  },
  {
    "menuName": "Kurumsal KMH Güncelleme",
    "screenName": "MEV033_DEPOSIT_KRM_UPDATE_EXPIRED_CORPORATE_KRM",
    "screenCode": "MEV033",
    "screenDescription": "KURUMSAL KMH GÜNCELLEME"
  },
  {
    "menuName": "Vadesiz Hesap Parametre Tanımlama",
    "screenName": "MEV005_DEPOSIT_PARAMETERS",
    "screenCode": "MEV005"
  },
  {
    "menuName": "KMH Tahakkuk İptal",
    "screenName": "MEV024_DEPOSIT_KRM_CANCEL_ASSESSMENT",
    "screenCode": "MEV024"
  },
  {
    "menuName": "Cüzdan Yazdır",
    "screenName": "IDC004_PASSBOOK_PRINT",
    "screenCode": "IDC004"
  },
  {
    "menuName": "POS Kıbrıs Üye İşyeri Hesap Bilgileri Güncelleme",
    "screenName": "POS002_POS_MERCHANT_ACCOUNT_UPDATE",
    "screenCode": "POS002",
    "screenDescription": "KIBRIS POS ÜYE İŞ YERİ HESAP BİLGİLERİ GÜNCELLEME"
  },
  {
    "menuName": "ATM İşlem Gözlem",
    "screenName": "ATM002_ATM_TRANSACTION_INFO",
    "screenCode": "ATM002"
  },
  {
    "menuName": "ATM Gişeden Masraf İade İşlemi",
    "screenName": "ATM064_ATM_COMMISSION_REFUND_CASH",
    "screenCode": "ATM064",
    "screenDescription": "ATM NAKİT MASRAF İADE İŞLEMLERİNDE ŞUBELERİN İŞLEM YAPACAĞI EKRAN."
  },
  {
    "menuName": "ATM Masraf İade İşlemleri Gözlem",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM063",
    "screenCode": "ATM063",
    "screenDescription": "ATM KOMİSYON İŞLEMLERİNİ LİSTELEYEN EKRAN."
  },
  {
    "menuName": "ATM İşlem Aktivite Gözlem",
    "screenName": "ATM057_ATM_TRANSACTION_ACTIVITY_LOG",
    "screenCode": "ATM057",
    "screenDescription": "HAREKET İŞLEMLERİ LOG GÖZLEM EKRANI"
  },
  {
    "menuName": "ATM FTP Hata Gözlem",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM054",
    "screenCode": "ATM054",
    "screenDescription": "ATM FTP HATA GÖZLEM"
  },
  {
    "menuName": "ATM Alıkonulan Kartlar",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM004",
    "screenCode": "ATM004"
  },
  {
    "menuName": "ATM Gözlem",
    "screenName": "ATM001_ATM_MONITORING",
    "screenCode": "ATM001"
  },
  {
    "menuName": "ATM Arıza Raporu (NCR'a Bildirilen)",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM092",
    "screenCode": "ATM092"
  },
  {
    "menuName": "ATM Masraf İade İşlemi",
    "screenName": "ATM062_ATM_COMMISSION_REFUND",
    "screenCode": "ATM062",
    "screenDescription": "ATM MASRAF İADE İŞLEMLERİNİN GİRİLECEĞİ EKRAN."
  },
  {
    "menuName": "ATM Online Hareket Görüntüleme",
    "screenName": "ATM030_ATM_ONLINE_ACTION_MONITORING",
    "screenCode": "ATM030"
  },
  {
    "menuName": "ATM Hat Durumu İzleme Ekran",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM009",
    "screenCode": "ATM009"
  },
  {
    "menuName": "ATM Gün Sonu Bilgi Görüntüleme",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM056",
    "screenCode": "ATM056"
  },
  {
    "menuName": "ATM Manuel Takas İşlemleri",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM024",
    "screenCode": "ATM024",
    "screenDescription": "ATM MANUEL TAKAS İŞLEMLERİ"
  },
  {
    "menuName": "ATM Response Kod İzleme",
    "screenName": "ATM049_ATM_RESPONSE_CODE_MONITORING",
    "screenCode": "ATM049",
    "screenDescription": "ATM RESPONSE KOD İZLEME"
  },
  {
    "menuName": "ATM Arıza Raporu (NCR'a Bildirilmeyen)",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM091",
    "screenCode": "ATM091"
  },
  {
    "menuName": "ATM Gider Verileri",
    "screenName": "ATM095_ATM_COSTS",
    "screenCode": "ATM095",
    "screenDescription": "ATM GİDER VERİLERİNİN TUTULDUĞU SAYFA"
  },
  {
    "menuName": "ATM Kontrol Formu",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM026",
    "screenCode": "ATM026"
  },
  {
    "menuName": "ATM Hareket Görüntüleme",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM003",
    "screenCode": "ATM003"
  },
  {
    "menuName": "ATM-Fatura Kurumları Tanımlama",
    "screenName": "ATM047_ATM_PAYMENT_INSTITUTION",
    "screenCode": "ATM047"
  },
  {
    "menuName": "Memo Log Gözlem",
    "screenName": "ATM017_ATM_MEMO_LOG",
    "screenCode": "ATM017"
  },
  {
    "menuName": "ATM Domestic Bin Tanımlama",
    "screenName": "ATM032_ATM_DOMESTIC_BIN_DEFINITION",
    "screenCode": "ATM032"
  },
  {
    "menuName": "ATM Bin Sorgulama",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM043 ",
    "screenCode": "ATM043",
    "screenDescription": "VISA MASTER BIN SORGULAMA"
  },
  {
    "menuName": "ATM Tanımlama",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM011",
    "screenCode": "ATM011"
  },
  {
    "menuName": "ATM Sunucu Yönetim",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM060",
    "screenCode": "ATM060",
    "screenDescription": "ATMCOMM SUNUCULARININ BİLGİLERİNİN YÖNETİLDİĞİ EKRAN"
  },
  {
    "menuName": "ATM Organizasyon Bilgileri Teknik Tanımlar",
    "screenName": "ATM021_ATM_ORGANIZATION_TECH_INFO",
    "screenCode": "ATM021"
  },
  {
    "menuName": "ATM Sistem Parametreleri Ekle/Güncelle",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM052",
    "screenCode": "ATM052"
  },
  {
    "menuName": "ATM Kampanya Tanımlama",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM053",
    "screenCode": "ATM053"
  },
  {
    "menuName": "ATM Response Kod/İşlem Kod Tanımlama",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM046",
    "screenCode": "ATM046",
    "screenDescription": "RESPONSE KOD İŞLEM KOD TANIMLAMA"
  },
  {
    "menuName": "ATM Test",
    "screenName": "ATM999_ATM_TEST_SERVICE",
    "screenCode": "ATM999"
  },
  {
    "menuName": "ATM E-Journal Görüntüleme",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM042",
    "screenCode": "ATM042"
  },
  {
    "menuName": "ATM'e Komut ve Veri Gönderim İşlemleri",
    "screenName": "ATM040_ATM_SEND_CUSTOMISATION_DATA",
    "screenCode": "ATM040"
  },
  {
    "menuName": "Fraud  Kart İşlemleri",
    "screenName": "ATM036_ATM_FRAUD_CARD_ENTRY_AND_MONITORING",
    "screenCode": "ATM036"
  },
  {
    "menuName": "ATM'lere Komut Gönderme Log Gözlem",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM051",
    "screenCode": "ATM051"
  },
  {
    "menuName": "ATM İşlem Yönetimi",
    "screenName": "ATM013_ATM_PROCESS_DEFINITION",
    "screenCode": "ATM013"
  },
  {
    "menuName": "ATM Monitoring",
    "screenName": "ATM010_ATM_STATUS",
    "screenCode": "ATM010"
  },
  {
    "menuName": "ATM Arıza - NCR Çağrı Gözlem",
    "screenName": "ATM090_ATM_NCR_CALL_LIST",
    "screenCode": "ATM090"
  },
  {
    "menuName": "ATM İstisna Parametre Tanımlama",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM014",
    "screenCode": "ATM014"
  },
  {
    "menuName": "Arama",
    "screenName": "DMS013_SEARCH_ICM",
    "screenCode": "DMS013",
    "screenDescription": "TEMEL ARAMA"
  },
  {
    "menuName": "Müşteri Kimlik Foto İzleme",
    "screenName": "DMS029_SEARCH_CUST_IDENTITY_PHOTO",
    "screenCode": "DMS029"
  },
  {
    "menuName": "Müşteri Dokümanları Raporu",
    "screenName": "DMS028_SEARCH_ATTR_WITH_MULTI_USER",
    "screenCode": "DMS028",
    "screenDescription": "MÜŞTERİLERİN KAYITLI DOKÜMANLARINI VE ÖZNİTELİKLERİNİ LİSTELER"
  },
  {
    "menuName": "Doküman Tip İstatistikleri",
    "screenName": "DMS027_DOC_STATS_ICM",
    "screenCode": "DMS027",
    "screenDescription": "DMS TİP VE DOKÜMAN İSTATİSTİKLERİ EKRANI"
  },
  {
    "menuName": "Tipler Arası Doküman Migrasyonu",
    "screenName": "DMS026_DOC_BULK_TYPE_MIGRATION",
    "screenCode": "DMS026",
    "screenDescription": "TİPLER ARASI DOKÜMAN MİGRASYON EKRANI"
  },
  {
    "menuName": "Döküman Tip Ekleme",
    "screenName": "DMS007_STRUCT_EDIT_TYPE_ICM",
    "screenCode": "DMS007",
    "screenDescription": "TİP EKLEME VE GÜNCELLEME"
  },
  {
    "menuName": "Döküman Formatları Tanımlama",
    "screenName": "DMS009_DOC_FORMAT",
    "screenCode": "DMS009",
    "screenDescription": "DOKÜMAN FORMATLARI"
  },
  {
    "menuName": "Sigortacılık Poliçe Ekleme",
    "screenName": "UTL099_INSDOC_EDIT",
    "screenCode": "UTL099",
    "screenDescription": "SİGORTA POLİÇE EVRAK YÜKLEME"
  },
  {
    "menuName": "Çoklu Döküman Ekleme",
    "screenName": "DMS018_DOC_ADD_MULTIPLE_ICM",
    "screenCode": "DMS018",
    "screenDescription": "ÇOKLU DOSYA EKLEME"
  },
  {
    "menuName": "Sigortacılık Poliçe Excel Yükleme",
    "screenName": "UTL100_INSURANCEPOLICY_UPLOAD_FROM_EXCEL",
    "screenCode": "UTL100",
    "screenDescription": "SİGORTA POLİÇELERİ ATTRİBUTE YÜKLEME EKRANI"
  },
  {
    "menuName": "Döküman Ekleme",
    "screenName": "DMS002_DOC_EDIT_ICM",
    "screenCode": "DMS002",
    "screenDescription": "DOKÜMAN EKLEME / GÜNCELLEME / GÖRÜNTÜLEME"
  },
  {
    "menuName": "Kapanan Provizyonlar",
    "screenName": "AMS006_CLOSED_AUTHORIZATION",
    "screenCode": "AMS006"
  },
  {
    "menuName": "Issuer Provizyon İsteği",
    "screenName": "AMS051_ISSUER_AUTHORIZATION_REQUEST",
    "screenCode": "AMS051"
  },
  {
    "menuName": "Manuel Reversal",
    "screenName": "AMS102_MANUAL_REVERSAL",
    "screenCode": "AMS102"
  },
  {
    "menuName": "Bekleyen Provizyonlar",
    "screenName": "AMS002_OUTSTANDING_AUTHORIZATION",
    "screenCode": "AMS002"
  },
  {
    "menuName": "Pin By Pass - Pin Block",
    "screenName": "AMS038_MCC_FILTER_FOR_PIN_BYPASS",
    "screenCode": "AMS038"
  },
  {
    "menuName": "Provizyon Filtre Parametreleri",
    "screenName": "AMS037_PROVISION_FILTER_PARAMETERS",
    "screenCode": "AMS037"
  },
  {
    "menuName": "Provizyon Parametreleri Log Görüntüleme",
    "screenName": "AMS032_AUTHORIZATION_PROCESS_LOG",
    "screenCode": "AMS032"
  },
  {
    "menuName": "Parametre Yükleme",
    "screenName": "AMS031_AMS_LOAD_AUTH_PARAMS",
    "screenCode": "AMS031"
  },
  {
    "menuName": "Birincil Parametreler",
    "screenName": "AMS021_PRIMARY_AUTHORIZATION_PARAMETERS",
    "screenCode": "AMS021"
  },
  {
    "menuName": "Limit Aşım Parametreleri",
    "screenName": "AMS026_OVERLIMIT_PARAMETERS",
    "screenCode": "AMS026"
  },
  {
    "menuName": "İşyeri Tanımlama",
    "screenName": "AMS030_MERCHANT_DEFINITIONS",
    "screenCode": "AMS030"
  },
  {
    "menuName": "Çip Parametreleri",
    "screenName": "AMS029_CHIP_PROVISION_PARAMETERS",
    "screenCode": "AMS029"
  },
  {
    "menuName": "Decline Codes",
    "screenName": "AMS036_DECLINE_CODES",
    "screenCode": "AMS036"
  },
  {
    "menuName": "Kart Bazlı Parametreler",
    "screenName": "AMS035_CARD_BASED_PARAMETERS",
    "screenCode": "AMS035"
  },
  {
    "menuName": "Provizyon Log Görüntüleme",
    "screenName": "https://nova-cps-ams-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/AMS/AMS003",
    "screenCode": "AMS003"
  },
  {
    "menuName": "Şekerbonus Limit Değişikliği",
    "screenName": "SKBNS019_SKBNS_LIMIT_INCREASE",
    "screenCode": "SKBNS019"
  },
  {
    "menuName": "Şekerkart Limit Değişikliği PC",
    "screenName": "CCMS109_CCMS_LIMIT_INCREASE",
    "screenCode": "CCMS109",
    "screenDescription": "PC ÜZERİNDEN YAPILAN LİMİT ARTTIRIMLARI"
  },
  {
    "menuName": "Limit Sorgulama",
    "screenName": "CCMS102_CCMS_LIMIT_QUERY",
    "screenCode": "CCMS102"
  },
  {
    "menuName": "Şekerkart Limit Değişikliği",
    "screenName": "CCMS101_CCMS_LIMIT_INCREASE",
    "screenCode": "CCMS101",
    "screenDescription": "CCMS LIMIT DEĞİŞİKLİK EKRANI"
  },
  {
    "menuName": "Kredi Kartları Yenileme Başvuru",
    "screenName": "CCMS110_CCMS_CARD_RENEW_DIFFERENCE",
    "screenCode": "CCMS110",
    "screenDescription": "KART YENILEME EKRANI"
  },
  {
    "menuName": "Acil Giriş",
    "screenName": "CCMS103_CCMS_LIMIT_QUICK_MANAGE",
    "screenCode": "CCMS103",
    "screenDescription": "ACİL GİRİŞ EKRANI"
  },
  {
    "menuName": "Toplu Limit Arttırımı",
    "screenName": "CCMS108_LIMIT_INCREASE",
    "screenCode": "CCMS108",
    "screenDescription": "TOPLU LİMİT ARTTIRIM GİRİŞ EKRANI"
  },
  {
    "menuName": "Business Kart Limit Değişikliği",
    "screenName": "CCMS106_CCMS_BUSINESS_CARD_LIMIT_INCREASE",
    "screenCode": "CCMS106",
    "screenDescription": "BUSİNESS KARTLARIN LİMİT GÜNCELLEMELERİ"
  },
  {
    "menuName": "Limit Düzenleme",
    "screenName": "CONS115_ADMIN_LIMIT_DEFINITION",
    "menuKey": "01",
    "screenCode": "CONS115",
    "screenDescription": "LİMİT TANIMLAMA EKRANI"
  },
  {
    "menuName": "TCC Limit Tanımlama",
    "screenName": "CCMS508_TCC_LIMIT_DEFINITIONS",
    "screenCode": "CCMS508",
    "screenDescription": "TCC_LIMIT TANIMLARININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Ticari Kart Logo Tanımlama",
    "screenName": "CCMS117_LOGO_MANAGEMENT",
    "screenCode": "CCMS117",
    "screenDescription": "TİCARİ KART LOGO BASIM TANIMLARI"
  },
  {
    "menuName": "MCC-TCC Eşleştirme",
    "screenName": "CCMS507_MCC_TCC_MAPPING",
    "screenCode": "CCMS507",
    "screenDescription": "TCC MCC MAPPING ININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Puan Aktarılacak Kart Tanımlama",
    "screenName": "CCMS509_BC_DEFINE_REWARDED_CARD",
    "screenCode": "CCMS509",
    "screenDescription": "BUSINESS CARD PUAN ALACAK MÜŞTERİ TANIMLAMA"
  },
  {
    "menuName": "TCC Tanımlama",
    "screenName": "CCMS506_TCC_DESCRIPTION",
    "screenCode": "CCMS506",
    "screenDescription": "TCC TANIMLAMALARININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Mutabakat Raporları",
    "screenName": "RPT002_MUTABAKAT_RAPORLARI",
    "screenCode": "RPT002"
  },
  {
    "menuName": "Outgoing Dataları Özeti",
    "screenName": "ITS032_OUTGOING_SEARCH",
    "screenCode": "ITS032",
    "screenDescription": "OUTGOING DATALARI GÖRÜNTÜLEME EKRANI"
  },
  {
    "menuName": "Takas Arama_Ekleme",
    "screenName": "ITS001_EXCEPTION_ITEM_SEARCH",
    "screenCode": "ITS001",
    "screenDescription": "KULLANICI TARAFINDAN VE BATCH'DE TANIMLANAN TÜM AKSİYONLARIN LİSTELENDİĞİ EKRAN"
  },
  {
    "menuName": "Gelen/Giden Takas Dosyaları Özeti",
    "screenName": "TMS011_FILE_DETAIL_SEARCH",
    "screenCode": "TMS011",
    "screenDescription": "INCOMING VE OUTGOING DATA'LARIN ÖZET BİLGİLERİNİN VE DETAYININ GÖSTERİLDİĞİ EKRAN"
  },
  {
    "menuName": "Takas Hata Alan Kayıtlar",
    "screenName": "https://nova-cps-interchange-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/interChange/TMS020",
    "screenCode": "TMS020",
    "screenDescription": "TAKAS HATA ALAN KAYITLAR LİSTESİ"
  },
  {
    "menuName": "TMS Arama",
    "screenName": "TMS010_ACTION_SEARCH",
    "screenCode": "TMS010"
  },
  {
    "menuName": "Bonusnet Takas Muhasebesi",
    "screenName": "CCMS215_INTCHNG_ACCOUNTING_BNS",
    "screenCode": "CCMS215",
    "screenDescription": "BONUS NET TAKAS MUHASEBE EKRANI"
  },
  {
    "menuName": "Bkm Takas Muhasebesi",
    "screenName": "CCMS216_INTCHNG_ACCOUNTING_BKM",
    "screenCode": "CCMS216",
    "screenDescription": "BKM TAKAS MUHASEBESİ  EKRANI"
  },
  {
    "menuName": "Batch Ve Post Tarihleri Şeması",
    "screenName": "TMS002_BATCH_POST_PROCESSING_SCHEDULE_RECORD",
    "screenCode": "TMS002"
  },
  {
    "menuName": "Takas Dosya Yükleme",
    "screenName": "TMS001_FILE_UPLOAD",
    "screenCode": "TMS001"
  },
  {
    "menuName": "Reject Olmuş Kayıt Arama",
    "screenName": "TMS006_COMMON_INPUT_SEARCH_REJECTED",
    "screenCode": "TMS006"
  },
  {
    "menuName": "Takas Komisyon Oranları",
    "screenName": "CLR001_CLEARING_COMM_RATE",
    "screenCode": "CLR001",
    "screenDescription": "TAKAS KOMİSYON ORANLARI"
  },
  {
    "menuName": "Batch İşi İptal Etme",
    "screenName": "TMS008_BATCH_JOBS",
    "screenCode": "TMS008"
  },
  {
    "menuName": "Common Input Kolon Eşleştirme",
    "screenName": "TMS004_COMMON_INPUT_MATCH_COLONS",
    "screenCode": "TMS004"
  },
  {
    "menuName": "Mastercard Member ID Tablosu",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/TMS014",
    "screenCode": "TMS014"
  },
  {
    "menuName": "Mastercard Issuer Accont Range Tablosu",
    "screenName": "TMS012_MASTERCARD_ISSUER_ACCOUNT_RANGE",
    "screenCode": "TMS012"
  },
  {
    "menuName": "Mastercard Acquirer Bin Tablosu",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/TMS013",
    "screenCode": "TMS013"
  },
  {
    "menuName": "Visa Bin Tablosu",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/TMS016",
    "screenCode": "TMS016"
  },
  {
    "menuName": "Visa Account Range Tablosu",
    "screenName": "TMS017_VISA_ACCOUNT_RANGE",
    "screenCode": "TMS017"
  },
  {
    "menuName": "Domestic Bin Tablosu",
    "screenName": "TMS003_DOMESTIC_BIN",
    "screenCode": "TMS003"
  },
  {
    "menuName": "Domestic Bin",
    "screenName": "TMS003_DOMESTIC_BIN",
    "screenCode": "TMS003"
  },
  {
    "menuName": "Takas Dosya Geri Alma",
    "screenName": "TMS009_TMS_REVERSAL",
    "screenCode": "TMS009"
  },
  {
    "menuName": "Reject Kayıt Yetkilendirme",
    "screenName": "TMS005_COMMON_INPUT_UPDATE_REJECT_DEFINITIONS",
    "screenCode": "TMS005"
  },
  {
    "menuName": "Aktif Satış Personeli",
    "screenName": "CCA025_ACTIVE_SALES_MANAGEMENT",
    "screenCode": "CCA025"
  },
  {
    "menuName": "Başvuru Kontrolü",
    "screenName": "CCA007_APPLICATION_CONTROL",
    "screenCode": "CCA007",
    "screenDescription": "BAŞVURU KONTROL EKRANI"
  },
  {
    "menuName": "Belge Geçmişi",
    "screenName": "CCA840_DOCUMENT_BRANCH_HISTORY",
    "screenCode": "CCA840",
    "screenDescription": "BELGE GEÇMİŞİ TAKİP EKRANI"
  },
  {
    "menuName": "Bireysel Giriş",
    "screenName": "CCA900_APPLICATION_CREATE",
    "screenCode": "CCA900",
    "screenDescription": "KK BASVURU ILK GIRIS"
  },
  {
    "menuName": "Bilgi ve Belge Tamamlama",
    "screenName": "CCA800_COMPLETE_MISSING_INFO",
    "screenCode": "CCA800",
    "screenDescription": "BİLGİ VE BELGE TAMAMLAMA EKRANI"
  },
  {
    "menuName": "ADK Kanalı Başvuru Giriş",
    "screenName": "CCA003_ADK_APP_INFO",
    "screenCode": "CCA003",
    "screenDescription": "ÇAĞRI MERKEZİ BAŞVURU BİLGİLERİ GİRİŞ EKRANI"
  },
  {
    "menuName": "İade Yönetimi",
    "screenName": "CCA008_APPLICATION_RETURN_MANAGEMENT",
    "screenCode": "CCA008",
    "screenDescription": "İADE YÖNETİMİ EKRANI"
  },
  {
    "menuName": "Şekerbonus Business Ek kart",
    "screenName": "CCA910_BUSINESS_APP_SUPPLEMENTARY_CARD",
    "screenCode": "CCA910"
  },
  {
    "menuName": "Bireysel Kredi Kartı Başvuru",
    "screenName": "CCA916_CREDIT_CARD_APPLICATION",
    "screenCode": "CCA916",
    "screenDescription": "ŞUBE KANALI KREDİ KART BAŞVURU EKRANI"
  },
  {
    "menuName": "Bağımsız Ek Kart",
    "screenName": "CCA002_APPLICATION_SUPPLEMENTARY_CARD",
    "screenCode": "CCA002",
    "screenDescription": "BAĞIMSIZ EK KART BAŞVURU GİRİŞİ"
  },
  {
    "menuName": "ÇM Kanalından KK Başvuru Talebi Alma",
    "screenName": "CCA027_ADK_CM_INSERT",
    "screenCode": "CCA027",
    "screenDescription": "ÇM  KANALINDAN KK BAŞVURU TALEBİ ALMA"
  },
  {
    "menuName": "Şube İade Canlandırma",
    "screenName": "CCA843_BRANCH_RETURNED_APP_RECREATE",
    "screenCode": "CCA843",
    "screenDescription": "ŞUBE İADE DURUMUNDAKİ BAŞVURUY YENİDEN CANLANDIRMA EKRANI"
  },
  {
    "menuName": "Bireysel Değişiklik",
    "screenName": "CCA901_APP_INFO",
    "screenCode": "CCA901",
    "screenDescription": "KK BAŞVURU DÜZENLEME"
  },
  {
    "menuName": "Bireysel Karar",
    "screenName": "CCA031_APPLICATION_DECISION_INDIVIDUAL",
    "screenCode": "CCA031",
    "screenDescription": "BİREYSEL BASVURULAR ICIN KARAR EKRANI"
  },
  {
    "menuName": "Bağımsız Ek Kart Değerlendirme",
    "screenName": "CCA032_SUPP_CARD_DECISION",
    "screenCode": "CCA032",
    "screenDescription": "BAGIMSIZ EK KART DEGERLENDIRME"
  },
  {
    "menuName": "İptal Başvuru Canlandırma",
    "screenName": "CCA037_CANCELED_APPLICATION_RECREATE",
    "screenCode": "CCA037"
  },
  {
    "menuName": "KKTC Ön Değerlendirme",
    "screenName": "CCA092_KKTC_APP_DECISION",
    "screenCode": "CCA092"
  },
  {
    "menuName": "Ret Başvuru Canlandırma",
    "screenName": "CCA033_REJECTED_APPLICATION_RECREATE",
    "screenCode": "CCA033",
    "screenDescription": "RED EDİLMİŞ BİR BAŞVURUYU YENİDEN CANLANDIRMA"
  },
  {
    "menuName": "Bildirim Metni Düzenleme",
    "screenName": "CCA051_APPLICATION_NOTIFICATION_FORMATS",
    "screenCode": "CCA051",
    "screenDescription": "BILDIRIM FORMATLARI"
  },
  {
    "menuName": "Tahsis Kuralları Gözlem",
    "screenName": "CCA030_POLICY_CONTROL_RESULT",
    "screenCode": "CCA030"
  },
  {
    "menuName": "Başvuru Süreç İzleme",
    "screenName": "CCA061_APPLICATION_INQUIRY",
    "screenCode": "CCA061",
    "screenDescription": "BAŞVURU İZLEME EKRANI"
  },
  {
    "menuName": "Başvuru Gözlem",
    "screenName": "CCA060_APPLICATION_MONITORING",
    "screenCode": "CCA060",
    "screenDescription": "YAPILAN BASVURULARI GOZLEMİNİN YAPILDIGI EKRAN"
  },
  {
    "menuName": "Kayıt İzleme",
    "screenName": "CCA062_APPLICATION_LOG_MONITORING",
    "screenCode": "CCA062"
  },
  {
    "menuName": "Koop kart Ödeme Bilgisi Düzenleme",
    "screenName": "CCMS_112_COOPCARD_PAYMENT_INFO",
    "screenCode": "CCMS112",
    "screenDescription": "KOOP KART ÖDEME BİLGİSİ DÜZENLEME"
  },
  {
    "menuName": "Tahsis Kuralları Yönetimi",
    "screenName": "CCA009_POLICY_CONTROL_ADMIN",
    "screenCode": "CCA009"
  },
  {
    "menuName": "Müşteri Bankacılık Talepleri",
    "screenName": "CCA034_BANKING_APPLICATION_REQUEST",
    "screenCode": "CCA034",
    "screenDescription": "BASVURU SIRASINDA ALINAN MÜŞTERİ TALEPLERİNİN TAKİP EKRANIDIR. (ATM,İNTERNET BANK., TEL.BANKACILIGI)"
  },
 {
    "menuName": "Müşteri Ana Grup Öncelik Düzenleme",
    "screenName": "PRD025_PROD_DEDUCTION_CUSTOMER_MAIN_GROUP_ORDER",
    "screenCode": "PRD025",
    "screenDescription": "MÜŞTERİ ANA GRUPLARININ ÖNCELİKLENDİRİLMESİ"
  },
]

