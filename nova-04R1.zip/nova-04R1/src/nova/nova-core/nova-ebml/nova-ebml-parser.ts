/* eslint-disable */

import { XMLParser } from 'fast-xml-parser';
import type {
    NovaEbml,
    NovaEbmlInterface,
    NovaEbmlStructure,
    NovaEbmlBean,
    NovaEbmlEvent,
    NovaEbmlRemoteCall,
    NovaEbmlManipulation,
    NovaEbmlRuleset,
    NovaEbmlProperty,
    NovaEbmlData,
    NovaEbmlColumn,
} from './types';

/**
 * Parses raw EBML XML content into a structured TypeScript object.
 * @param xmlContent The raw XML string from an .ebml file.
 * @returns The parsed NovaEbmlConfig object.
 */
export function parseEbml(xmlContent: string): NovaEbml {
    const parser = new XMLParser({
        ignoreAttributes: false,
        attributeNamePrefix: '@_',
        textNodeName: '#text',
        processEntities: true,
        htmlEntities: true,
        attributeValueProcessor: (name, val) => {
            return  val;
        },
        tagValueProcessor: (name, val) => {
            return val;
        },
        isArray: (name) => {
            return ['bean','p', 'lC', 'd', 'data', 'ref', 'input', 'output', 'rC','rule','message','combination','var', 'column'].indexOf(name) !== -1;}
    });

    const raw = parser.parse(xmlContent);
    const root = raw.ebml;

    if (!root) {
        throw new Error('Invalid EBML file: Missing <ebml> root.');
    }

    return {
        language: root['@_language'],
        pid: root['@_pid'],
        size: root['@_size'],
        techVersion: root['@_techVersion'],
        type: root['@_type'],
        v: root['@_v'],
        interface: parseInterface(root.interface),
        data: root.data ? parseDataSection(root.data[0]) : undefined,
        ruleset: root.ruleset ? parseRuleset(root.ruleset) : undefined
    };
}

function parseInterface(rawInterface: any): NovaEbmlInterface {
    return {
        structure: parseStructure(rawInterface.structure),
        events: rawInterface.events && rawInterface.events.lC ? rawInterface.events.lC.map(parseEvent) : [],
    };
}

function parseStructure(rawStructure: any): NovaEbmlStructure {
    if (!rawStructure || !rawStructure.bean || rawStructure.bean.length === 0) {
        throw new Error('Invalid structure: Missing root bean.');
    }
    return {
        rootBean: parseBean(rawStructure.bean[0]),
    };
}

function parseBean(rawBean: any): NovaEbmlBean {
    const bean: NovaEbmlBean = {
        id: rawBean['@_id'],
        class: rawBean['@_class'],
        text: rawBean['@_text'] || rawBean['#text'],
        children: [],
    };

    // Parse Style properties
    if (rawBean.style && rawBean.style.p) {
        bean.style = { properties: [] };
        rawBean.style.p.forEach((p: any) => {
            if (p) bean.style?.properties.push(parseProperty(p));
        });
    }

    // Parse nested beans (children)
    if (rawBean.bean) {
        bean.children = rawBean.bean.map((child: any) => parseBean(child));
    }

    return bean;
}

function parseProperty(p: any): NovaEbmlProperty {
    const prop: NovaEbmlProperty = {
        name: p['@_n'] || p['@_name'] || '',
        text: p['#text'] || '',
        id: p['@_id'] || null,
        m: p['@_m'],
        rule: p['@_rule'],
        var: p['@_var'],
        n: p['@_n'],
        comp: p['@_comp'],
        columns: p['@_columns'],
    };

    if (p.columns && p.columns.column) {
        prop.columns =  p.columns.column.map((c: any) => parseColumn(c)) ;
    }

    return prop;
}

function parseColumn(c: any): NovaEbmlColumn {
    const col: NovaEbmlColumn = {
        id: c["@_id"],
        title: c["@_title"],
        type: c["@_type"],
        width: c["@_width"],
        editable: c["@_editable"] === "true",
        visible: c["@_visible"] !== "false", // Default true usually
        order: parseInt(c["@_order"] || "0"),
    };

    if (c.style && c.style.p) {
        col.style = { properties: [] };
        // Assuming style.p is array (parser config handles 'p')
        const props = Array.isArray(c.style.p) ? c.style.p : [c.style.p];
        col.style.properties = props.map((p: any) => parseProperty(p));
    }

    return col;
}

function parseEvent(rawLc: any): NovaEbmlEvent {
    const event: NovaEbmlEvent = {
        id: rawLc['@_id'] ??rawLc['@_ref'],
        name: rawLc['@_n']??rawLc['@_ref'],
        type: rawLc['@_type'],
        refId: rawLc['@_ref'],
        actions: [],
    };

    // <ref>
    if (rawLc.ref) {
        rawLc.ref.forEach((r: any) => {
            event.actions.push({
                type: 'reference',
                refId: typeof r === 'string' ? r : r['#text'] || r,
            });
        });
    }

    // <rC> (Remote Calls)
    if (rawLc.rC) {
        rawLc.rC.forEach((rc: any) => {
            event.actions.push({
                type: 'remoteCall',
                call: parseRemoteCall(rc),
            });
        });
    }

    // <p> (Manipulations)
    if (rawLc.p) {
        rawLc.p.forEach((p: any) => {
            event.actions.push({
                type: 'manipulation',
                manipulaton: parseManipulation(p),
            });
        });
    }

    return event;
}

function parseRemoteCall(rawRc: any): NovaEbmlRemoteCall {
    const rc: NovaEbmlRemoteCall = {
        serviceName: rawRc['@_s'],
        status: rawRc['@_status'],
    };

    // Inputs
    if (rawRc.inputs) {
        rc.inputs = {};
        if (rawRc.inputs.p) {
            rc.inputs.p = rawRc.inputs.p.map((p: any) => parseProperty(p));
        }
        if (rawRc.inputs.var) {
            rc.inputs.var = rawRc.inputs.var.map((v: any) => parseProperty(v));
        }
    }

    // Outputs
    if (rawRc.outputs) {
        rc.outputs = {};
        if (rawRc.outputs.p) {
            rc.outputs.p = rawRc.outputs.p.map((p: any) => parseProperty(p));
        }
        if (rawRc.outputs.var) {
            rc.outputs.var = rawRc.outputs.var.map((v: any) => parseProperty(v));
        }
    }

    return rc;
}

function parseManipulation(rawP: any): NovaEbmlManipulation {
    const manip: NovaEbmlManipulation = {
        targetId: rawP['@_id'],
        method: rawP['@_m'],
        property: rawP['@_n'],
    };

    if (rawP['#text']) {
        manip.value = rawP['#text'];
    }
    // <var>
    if (rawP.var) {
        const v = Array.isArray(rawP.var) ? rawP.var[0] : rawP.var;
        if (v) {
            manip.sourceVar = v['@_id'] || v['#text'];
        }
    }

    return manip;
}

function parseDataSection(rawData: any): NovaEbmlData {
    // rawData is an array of data sections because "data" is in isArray list
    const section: NovaEbmlData = { variables: [], definitions: [] };
    const dataItems = Array.isArray(rawData) ? rawData : [rawData];
    let vars: any[] = [];
    let defs: any[] = [];

    dataItems.forEach((item: any) => {
        if (item.var) {
            vars = vars.concat(item.var);
        }
        if (item.d) {
            // 'd' elements represent definitions for components (e.g. ComboBox selections)
            defs = defs.concat(item.d);
        }
    });
    
    section.variables = vars.map((v: any) => ({
        id: v["@_id"],
        n: v["@_n"],
        comp: v["@_comp"],
        text: v["#text"],
        rule: v["@_rule"]
    }));

    section.definitions = defs.map((d: any) => {
        const definition: any = {
            id: d["@_id"],
            options: [],
            columnDefinitions: []
        };

        // Check if this has direct data elements (simple definition)
        if (d.data && d.data.length > 0) {
            definition.options = d.data.map((opt: any) => ({
                value: opt["@_n"],
                text: opt["#text"]
            }));
        }

        // Check if this has nested d elements (table column definitions)
        if (d.d && d.d.length > 0) {
            definition.columnDefinitions = d.d.map((nestedD: any) => ({
                columnId: nestedD["@_id"],
                options: (nestedD.data || []).map((opt: any) => ({
                    value: opt["@_n"],
                    text: opt["#text"]
                }))
            }));
        }

        return definition;
    });
    return section;
}

function parseRuleset(rawRuleset: any): NovaEbmlRuleset {
    const ruleset: NovaEbmlRuleset = {
        rules: [],
        messages: [],
        combinations: [],
    };

    if (rawRuleset.rule) {
        ruleset.rules = rawRuleset.rule.map((r: any) => ({
            id: r['@_id'],
            op: r['@_op'],
            source: r['@_source'],
            target: r['@_target'],
            targetType: r['@_targetType'],
        }));
    }

    if (rawRuleset.message) {
        ruleset.messages = rawRuleset.message.map((m: any) => ({
            id: m['@_id'],
            var: m['@_var'],
            messageType: m['@_messageType'],
            title: m['@_title'],
            type: m['@_type'],
            text: m['#text'] || m['@_text'] || '',
        }));
    }

    if (rawRuleset.combination) {
        ruleset.combinations = rawRuleset.combination.map((c: any) => ({
            id: c['@_id'],
            expression: c['#text'] || c['@_expression'],
        }));
    }

    return ruleset;
}
