/* eslint-disable */
import { parseEbml } from './nova-ebml-parser';
import type { NovaEbml } from './types';

/**
 * Retrieves and parses the EBML schema for a given screen code.
 * Note: This function is async because it uses fetch() to retrieve file content in the browser.
 * Make sure the EBML files are served and accessible via the URL constructed below.
 * 
 * @param screenCode The screen code to look up (e.g., "UTC007").
 * @returns The parsed NovaEbml object, or null if not found or an error occurs.
 */
export async function getScreenEbmlSchema(screenCode: string): Promise<NovaEbml | null> {
    // Find the definition entry matching the screen code
    const ebmlDefinitions=JSON.parse(await (await fetch('/src/assets/docs/ebml-definitions.json')).text());
    const definition = ebmlDefinitions.find((d:any )=> d.screenCode === screenCode);
    if (!definition) {
        console.warn(`EbmlSchemaProvider: No definition found for screenCode '${screenCode}'`);
        return null;
    }
    // In a browser environment, we cannot read absolute file paths (like "E:/...") directly using fs.
    // Instead, we must fetch the file via HTTP. 
    // This assumes the file is available at a URL. You may need to configure your Vite server 
    // to serve these files or copy them to the public folder.
    // Example: fetching from a hypothetical '/ebml/' directory.
    const url = `/src/assets/EBML/${definition.filePath}`; 
    try {
        const response = await fetch(url);
        
        if (!response.ok) {
            return null;
        }

        const buffer = await response.arrayBuffer();
        // Try UTF-8 first (most common), then fall back to ISO-8859-9 (Turkish)
        let fileContent: string;
        try {
            const utf8Decoder = new TextDecoder('utf-8', { fatal: true });
            fileContent = utf8Decoder.decode(buffer);
        } catch {
            // If UTF-8 fails, try ISO-8859-9 (Turkish encoding)
            const isoDecoder = new TextDecoder('iso-8859-9');
            fileContent = isoDecoder.decode(buffer);
        }
        let parsedEbml=parseEbml(fileContent);
        return parsedEbml;


    } catch (error) {
        return null;
    }
}
