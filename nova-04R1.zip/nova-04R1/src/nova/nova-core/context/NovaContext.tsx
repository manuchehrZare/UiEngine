/* eslint-disable */
/**
 * Nova Context
 * Unified context merging PageDefinitionsContext and PageEngineContext
 * Manages page definitions loading, lifecycle, events, actions, rules, and variables
 *
 * Key Features:
 * 1. Loads page definitions from ui-definition.json
 * 2. Bean actions can be assigned to UI components
 * 3. Context can send data to popup windows or region sub-pages
 * 4. Root component is the page
 */

import React, { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react';
import type { ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { Action, Rule, Variable, SubAction, DesignComponent } from '../types';
import type { NovaUiSchema } from '../types/nova-ui-schema.types';
// import type { PageDefinition } from '../types';
import { useAxios } from '../../../set-lib/hooks/useAxios';
import { getGenericSetCaller } from '../../../set-lib/utils/methods';
import { HttpStatusCode as HttpStatusCodeEnum } from 'axios';
import { message } from '../../../seker-ui-lib';
import { COMPONENT_REGISTRY } from '../registry/component-registry';
// import { convertEbmlToNovaSchema } from '../converters/EbmlConverter';
import { useReferenceData } from '../hooks/useReferenceData';
import { useLogger } from './LogCenterContext';
/**
 * Component state management
 */
export interface ComponentState {
    id: string;
    value: any;
    enabled: boolean;
    visible: boolean;
    [key: string]: any;
}

/**
 * Page lifecycle phases
 */
export type PageLifecyclePhase = 'initializing' | 'loading' | 'loaded' | 'ready' | 'unloading' | 'unloaded';

/**
 * Event subscription
 */
export interface EventSubscription {
    componentId: string;
    eventName: string;
    action: Action;
    rule?: string;
}

/**
 * Page data passed to popup or region
 */
export interface PageData {
    [key: string]: any;
}

/**
 * Remote call status
 */
export interface RemoteCallStatus {
    pending: boolean;
    error?: Error;
    errorId?: string;
}


/**
 * Nova Context Type - Merged from PageDefinitionsContext, PageEngineContext, and DesignerContext
 */
interface NovaContextType {
    // From PageDefinitionsContext
    // pages: PageDefinition[];
    loading: boolean;
    error: Error | null;

    // Lifecycle
    lifecyclePhase: PageLifecyclePhase;
    setLifecyclePhase: (phase: PageLifecyclePhase) => void;

    // Schema
    schema: NovaUiSchema | null;
    loadSchema: (schema: NovaUiSchema) => void;

    // Component state management (Runtime)
    componentStates: Map<string, ComponentState>;
    getComponentState: (componentId: string) => ComponentState | undefined;
    setComponentState: (componentId: string, state: Partial<ComponentState>) => void;
    registerComponent: (componentId: string, initialState?: Partial<ComponentState>) => void;
    unregisterComponent: (componentId: string) => void;

    // Variables (Runtime) - Map for efficient lookup
    variablesMap: Map<string, any>;
    getVariable: (name: string) => any;
    setVariable: (name: string, value: any) => void;

    // Built-in variables
    getBuiltInVariable: (name: string) => any;

    // Rules (Runtime)
    evaluateRule: (ruleId: string) => Promise<boolean>;

    // Actions (Runtime)
    executeAction: (actionId: string, eventData?: any) => Promise<void>;

    // Events
    addEventListener: (componentId: string, eventName: string, actionId: string, ruleId?: string) => void;
    removeEventListener: (componentId: string, eventName: string) => void;
    fireEvent: (componentId: string, eventName: string, eventData?: any) => Promise<void>;

    // Component methods (Bean Actions)
    registerComponentMethod: (componentId: string, methodName: string, method: Function) => void;
    invokeComponentMethod: (componentId: string, methodName: string, ...args: any[]) => any;

    // Remote calls
    remoteCallStatus: RemoteCallStatus;
    setRemoteCallStatus: (status: RemoteCallStatus) => void;

    // Page data (for popup/region communication)
    pageData: PageData;
    setPageData: (data: PageData) => void;
    sendDataToPopup: (popupName: string, data: PageData) => void;
    receiveDataFromPopup: (data: PageData) => void;

    // Navigation
    navigateToPage: (pageName: string, pageTitle?: string, params?: PageData) => void;
    returnAction?: string;
    setReturnAction: (actionId?: string) => void;

    // Designer-specific features (Design-time)
    components: DesignComponent[]; // Root components for designer
    jsCode: string;
    cssCode: string;
    selectedComponentId: string | null;
    mode: 'design' | 'preview'| 'generator';

    // Rules, Variables, Actions (Design-time management)
    // Note: Event bindings are now embedded in actions via componentId/eventName fields
    rules: Rule[];
    variables: Variable[]; // Array for designer UI (deprecated, use data instead)
    data: Variable[]; // Array for designer UI (new data structure)
    actions: Action[];
    addRule: (rule: Rule) => void;
    updateRule: (id: string, rule: Partial<Rule>) => void;
    deleteRule: (id: string) => void;
    addVariable: (variable: Variable) => void;
    updateVariable: (id: string, variable: Partial<Variable>) => void;
    deleteVariable: (id: string) => void;
    addData: (data: Variable) => void;
    updateData: (name: string, data: Partial<Variable>) => void;
    deleteData: (name: string) => void;
    addAction: (action: Action) => void;
    updateAction: (id: string, action: Partial<Action>) => void;
    deleteAction: (id: string) => void;
    getActionsForComponent: (componentId: string, eventName?: string) => Action[];

    // Designer component tree manipulation
    selectComponent: (id: string | null) => void;
    addComponent: (type: string, parentId?: string | null, index?: number) => void;
    moveComponent: (dragId: string, hoverId: string | null, position: 'before' | 'after' | 'inside') => void;
    updateComponentProps: (id: string, newProps: Record<string, any>) => void;
    deleteComponent: (id: string) => void;
    setMode: (mode: 'design' | 'preview'| 'generator') => void;
    setJsCode: (code: string) => void;
    setCssCode: (code: string) => void;
    exportDesign: () => string;
    importDesign: (json: string) => void;
    clearDesign: () => void;
    getComponentById: (id: string) => DesignComponent | null;
}

const NovaContext = createContext<NovaContextType | undefined>(undefined);

export const useNova = () => {
    const context = useContext(NovaContext);
    if (!context) {
        throw new Error('useNova must be used within a NovaProvider');
    }
    return context;
};

/**
 * Optional version that returns null if provider is not available
 * Use this for components that may render outside NovaProvider
 */
export const useNovaOptional = () => {
    return useContext(NovaContext);
};

/**
 * Internal component to handle reference data loading
 * This component is rendered inside NovaProvider and uses the useReferenceData hook
 */
const ReferenceDataLoader: React.FC = () => {
    const { schema } = useNova();
    const components = schema?.ui || [];

    // Automatically fetch reference data when components are available
    useReferenceData(components);

    return null; // This component doesn't render anything
};

/**
 * Nova Provider Props
 */
interface NovaProviderProps {
    children: ReactNode;
    onNavigate?: (pageName: string, pageTitle?: string, params?: PageData) => void;
    onShowPopup?: (popupName: string, data: PageData) => Promise<PageData>;
    workingMode:'design' | 'preview'| 'generator';
}

export const NovaProvider: React.FC<NovaProviderProps> = ({
    children,
    onNavigate,
    onShowPopup,
    workingMode
}) => {
    const logger = useLogger('NovaContext');

    // From PageDefinitionsContext
    // const [pages, setPages] = useState<PageDefinition[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<Error | null>(null);

    // From PageEngineContext
    const [lifecyclePhase, setLifecyclePhase] = useState<PageLifecyclePhase>('initializing');
    const [schema, setSchema] = useState<NovaUiSchema | null>(null);
    const [componentStates, setComponentStates] = useState<Map<string, ComponentState>>(new Map());
    const [variables, setVariables] = useState<Map<string, any>>(new Map());
    const [pageData, setPageData] = useState<PageData>({});
    const [remoteCallStatus, setRemoteCallStatus] = useState<RemoteCallStatus>({ pending: false });
    const [returnAction, setReturnAction] = useState<string | undefined>();

    // From DesignerContext
    const [components, setComponents] = useState<DesignComponent[]>([]);
    const [jsCode, setJsCode] = useState<string>('// Custom JS here');
    const [cssCode, setCssCode] = useState<string>('/* Custom CSS here */');
    const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
    const [mode, setMode] = useState<'design' | 'preview'| 'generator'>(workingMode ?? 'design');
    const [rules, setRules] = useState<Rule[]>([]);
    const [actions, setActions] = useState<Action[]>([]);
    const [variablesArray, setVariablesArray] = useState<Variable[]>([]); // For designer UI (deprecated)
    const [dataArray, setDataArray] = useState<Variable[]>([]); // For designer UI (new data structure)

    // Component method registry
    const componentMethodsRef = useRef<Map<string, Map<string, Function>>>(new Map());

    // Event subscriptions
    const eventSubscriptionsRef = useRef<EventSubscription[]>([]);

    // Axios hook for generic service calls
    const [, callGenericService] = useAxios<any, any>({ url: '', method: 'POST' }, { manual: true });

    // Internal remote call implementation
    const handleRemoteCall = useCallback(async (serviceName: string, inputs: any) => {
        logger.info('Remote call to service', { serviceName, inputs });

        try {
            const serviceConfig = getGenericSetCaller(serviceName);
            const response = await callGenericService({
                ...serviceConfig,
                data: inputs
            });

            if (response.status === HttpStatusCodeEnum.Ok) {
                logger.info('Service response received', { serviceName, data: response.data });
                return response.data;
            } else {
                throw new Error(`Service call failed with status ${response.status}`);
            }
        } catch (error) {
            logger.error('Service call error', { serviceName, error: error instanceof Error ? error.message : 'Unknown error' });
            // Return error structure that can be checked via $RC_ERROR_ID
            return {
                ERROR: true,
                ERROR_ID: '1',
                ERROR_MESSAGE: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }, [callGenericService]);

    // Load schema
    const loadSchema = useCallback((newSchema: NovaUiSchema) => {
        setSchema(newSchema);

        // Initialize data from schema (new structure)
        if (newSchema.data?.var) {
            const newVars = new Map<string, any>();
            newSchema.data.var.forEach(dataItem => {
                newVars.set(dataItem.name, dataItem.initialValue ?? null);
            });
            setVariables(newVars);
            // Also set array for designer
            setDataArray(newSchema.data.var);
        }
        // Backward compatibility: support old variables structure
        else if ((newSchema as any).variables?.vars) {
            const newVars = new Map<string, any>();
            (newSchema as any).variables.vars.forEach((variable: Variable) => {
                newVars.set(variable.name, variable.initialValue || null);
            });
            setVariables(newVars);
            // Also set array for designer (old structure)
            setVariablesArray((newSchema as any).variables.vars);
        }

        // Also update designer state when loading schema
        setComponents(newSchema.ui || []);
        setRules(newSchema.ruleset?.rules || []);
        setActions(newSchema.events?.actions || []);
        setJsCode(newSchema.jsCode || '// Custom JS here');
        setCssCode(newSchema.cssCode || '/* Custom CSS here */');

        setLifecyclePhase('loaded');
    }, []);

    // Component state management
    const registerComponent = useCallback((componentId: string, initialState?: Partial<ComponentState>) => {
        setComponentStates(prev => {
            const newMap = new Map(prev);
            newMap.set(componentId, {
                id: componentId,
                value: null,
                enabled: true,
                visible: true,
                ...initialState
            });
            return newMap;
        });
    }, []);

    const unregisterComponent = useCallback((componentId: string) => {
        setComponentStates(prev => {
            const newMap = new Map(prev);
            newMap.delete(componentId);
            return newMap;
        });

        // Clean up component methods
        componentMethodsRef.current.delete(componentId);
    }, []);

    const getComponentState = useCallback((componentId: string): ComponentState | undefined => {
        return componentStates.get(componentId);
    }, [componentStates]);

    const setComponentState = useCallback((componentId: string, state: Partial<ComponentState>) => {
        setComponentStates(prev => {
            const newMap = new Map(prev);
            const currentState = newMap.get(componentId);
            if (currentState) {
                newMap.set(componentId, { ...currentState, ...state });
            }
            return newMap;
        });
    }, []);

    // Variable management
    const getVariable = useCallback((name: string): any => {
        return variables.get(name);
    }, [variables]);

    const setVariable = useCallback((name: string, value: any) => {
        setVariables(prev => {
            const newMap = new Map(prev);
            newMap.set(name, value);
            return newMap;
        });
    }, []);

    // =========================================================================
    // Designer-specific methods (Component tree manipulation)
    // =========================================================================

    // Helper to find component in tree
    const findComponent = useCallback((comps: DesignComponent[], id: string): DesignComponent | null => {
        for (const comp of comps) {
            if (comp.id === id) return comp;
            if (comp.children.length > 0) {
                const found = findComponent(comp.children, id);
                if (found) return found;
            }
        }
        return null;
    }, []);

    // Helper to recursively update
    const updateComponentInTree = useCallback((comps: DesignComponent[], id: string, updater: (comp: DesignComponent) => DesignComponent): DesignComponent[] => {
        return comps.map(comp => {
            if (comp.id === id) {
                return updater(comp);
            }
            if (comp.children.length > 0) {
                return { ...comp, children: updateComponentInTree(comp.children, id, updater) };
            }
            return comp;
        });
    }, []);

    // Helper to recursively remove
    const removeComponentFromTree = useCallback((comps: DesignComponent[], id: string): { cleaned: DesignComponent[], removed: DesignComponent | null } => {
        let removed: DesignComponent | null = null;

        const filterRecursive = (list: DesignComponent[]): DesignComponent[] => {
            const result: DesignComponent[] = [];
            for (const comp of list) {
                if (comp.id === id) {
                    removed = comp;
                    continue;
                }
                const newChildren = filterRecursive(comp.children);
                if (newChildren !== comp.children) {
                    result.push({ ...comp, children: newChildren });
                } else {
                    result.push(comp);
                }
            }
            return result;
        };

        const cleaned = filterRecursive(comps);
        return { cleaned, removed };
    }, []);

    // Helper to insert
    const insertComponentInTree = useCallback((comps: DesignComponent[], parentId: string | null, component: DesignComponent, index?: number): DesignComponent[] => {
        if (parentId === null) {
            const newComponents = [...comps];
            if (typeof index === 'number') {
                newComponents.splice(index, 0, component);
            } else {
                newComponents.push(component);
            }
            return newComponents;
        }

        return comps.map(comp => {
            if (comp.id === parentId) {
                const newChildren = [...comp.children];
                if (typeof index === 'number') {
                    newChildren.splice(index, 0, component);
                } else {
                    newChildren.push(component);
                }
                return { ...comp, children: newChildren };
            }
            if (comp.children.length > 0) {
                return { ...comp, children: insertComponentInTree(comp.children, parentId, component, index) };
            }
            return comp;
        });
    }, []);

    const addComponent = useCallback((type: string, parentId: string | null = null, index?: number) => {
        const registryItem = COMPONENT_REGISTRY[type];
        if (!registryItem) return;

        const componentId = uuidv4();
        const newComponent: DesignComponent = {
            id: componentId,
            type,
            props: {
                ...registryItem.defaultProps,
                // Auto-fill Id property for all components
                id: `${type.toLowerCase()}_${componentId.slice(0, 8)}`
            },
            children: [],
            parentId
        };

        setComponents(prev => insertComponentInTree(prev, parentId, newComponent, index));
        setSelectedComponentId(newComponent.id);
    }, [insertComponentInTree]);

    const selectComponent = useCallback((id: string | null) => {
        setSelectedComponentId(id);
    }, []);

    const updateComponentProps = useCallback((id: string, newProps: Record<string, any>) => {
        setComponents(prev => updateComponentInTree(prev, id, (comp) => {
            // Separate eventBindings from regular props
            const { eventBindings, ...regularProps } = newProps;
            return {
                ...comp,
                props: { ...comp.props, ...regularProps },
                // Update eventBindings if provided
                ...(eventBindings !== undefined ? { eventBindings } : {})
            };
        }));
    }, [updateComponentInTree]);

    const deleteComponent = useCallback((id: string) => {
        setComponents(prev => removeComponentFromTree(prev, id).cleaned);
        if (selectedComponentId === id) setSelectedComponentId(null);
    }, [selectedComponentId, removeComponentFromTree]);

    const moveComponent = useCallback((dragId: string, hoverId: string | null, position: 'before' | 'after' | 'inside') => {
        setComponents(prev => {
            const dragComponent = findComponent(prev, dragId);
            if (!dragComponent) return prev;

            const targetParentId = position === 'inside'
                ? (hoverId === 'root' ? null : hoverId)
                : null;

            // Cycle check: Cannot drop parent into child
            if (position === 'inside' && targetParentId) {
                const isDescendant = (parent: DesignComponent, targetId: string): boolean => {
                    if (parent.id === targetId) return true;
                    return parent.children.some(child => isDescendant(child, targetId));
                };
                if (isDescendant(dragComponent, targetParentId)) {
                    return prev;
                }
            }

            // 1. Remove dragged component
            const { cleaned, removed } = removeComponentFromTree(prev, dragId);
            if (!removed) return prev;

            // 2. Insert component at new location
            if (position === 'inside') {
                return insertComponentInTree(cleaned, targetParentId, { ...removed, parentId: targetParentId });
            } else {
                if (hoverId === null || hoverId === 'root') {
                    return insertComponentInTree(cleaned, null, { ...removed, parentId: null }, position === 'before' ? 0 : undefined);
                }

                const findLoc = (list: DesignComponent[], targetId: string, currentParentId: string | null): { parentId: string | null, index: number } | null => {
                    for (let i = 0; i < list.length; i++) {
                        if (list[i].id === targetId) {
                            return { parentId: currentParentId, index: i };
                        }
                        if (list[i].children.length > 0) {
                            const res = findLoc(list[i].children, targetId, list[i].id);
                            if (res) return res;
                        }
                    }
                    return null;
                };

                const loc = findLoc(cleaned, hoverId, null);
                if (loc) {
                    const insertIndex = position === 'after' ? loc.index + 1 : loc.index;
                    return insertComponentInTree(cleaned, loc.parentId, { ...removed, parentId: loc.parentId }, insertIndex);
                }
            }
            return prev;
        });
    }, [findComponent, removeComponentFromTree, insertComponentInTree]);

    const getComponentById = useCallback((id: string) => {
        return findComponent(components, id);
    }, [components, findComponent]);

    // Rule CRUD methods
    const addRule = useCallback((rule: Rule) => {
        setRules(prev => [...prev, rule]);
        // Also update schema to keep it in sync
        setSchema(prev => prev ? {
            ...prev,
            ruleset: {
                ...prev.ruleset,
                rules: [...(prev.ruleset?.rules || []), rule]
            }
        } : prev);
    }, []);

    const updateRule = useCallback((id: string, updatedRule: Partial<Rule>) => {
        setRules(prev => prev.map(rule => rule.id === id ? { ...rule, ...updatedRule } : rule));
        // Also update schema to keep it in sync
        setSchema(prev => prev ? {
            ...prev,
            ruleset: {
                ...prev.ruleset,
                rules: (prev.ruleset?.rules || []).map(rule =>
                    rule.id === id ? { ...rule, ...updatedRule } : rule
                )
            }
        } : prev);
    }, []);

    const deleteRule = useCallback((id: string) => {
        setRules(prev => prev.filter(rule => rule.id !== id));
        // Also update schema to keep it in sync
        setSchema(prev => prev ? {
            ...prev,
            ruleset: {
                ...prev.ruleset,
                rules: (prev.ruleset?.rules || []).filter(rule => rule.id !== id)
            }
        } : prev);
    }, []);

    // Variable CRUD methods (Designer)
    const addVariable = useCallback((variable: Variable) => {
        // Add to array for designer
        setVariablesArray(prev => [...prev, variable]);

        // Add to map for runtime
        setVariables(prev => {
            const newMap = new Map(prev);
            newMap.set(variable.name, variable.initialValue || null);
            return newMap;
        });
    }, []);

    const updateVariable = useCallback((name: string, updatedVariable: Partial<Variable>) => {
        // Update in array for designer
        setVariablesArray(prev =>
            prev.map(v => v.name === name ? { ...v, ...updatedVariable } : v)
        );

        // Update in map for runtime
        if (updatedVariable.name !== undefined && updatedVariable.name !== null) {
            setVariables(prev => {
                const newMap = new Map(prev);
                // Find old variable to remove if name changed
                const oldVar = variablesArray.find(v => v.name === name);
                if (oldVar && oldVar.name !== updatedVariable.name) {
                    newMap.delete(oldVar.name);
                }
                newMap.set(updatedVariable.name!, updatedVariable.initialValue || null);
                return newMap;
            });
        } else if (updatedVariable.initialValue !== undefined) {
            // Just update the value
            const variable = variablesArray.find(v => v.name === name);
            if (variable) {
                setVariables(prev => {
                    const newMap = new Map(prev);
                    newMap.set(variable.name, updatedVariable.initialValue);
                    return newMap;
                });
            }
        }
    }, [variablesArray]);

    const deleteVariable = useCallback((name: string) => {
        // Find variable to get its name
        const variable = variablesArray.find(v => v.name === name);

        // Remove from array for designer
        setVariablesArray(prev => prev.filter(v => v.name !== name));

        // Remove from map for runtime
        if (variable) {
            setVariables(prev => {
                const newMap = new Map(prev);
                newMap.delete(variable.name);
                return newMap;
            });
        }
    }, [variablesArray]);

    // Data CRUD methods (New structure)
    const addData = useCallback((data: Variable) => {
        // Add to array for designer
        setDataArray(prev => [...prev, data]);

        // Add to map for runtime
        setVariables(prev => {
            const newMap = new Map(prev);
            newMap.set(data.name, data.initialValue ?? null);
            return newMap;
        });
    }, []);

    const updateData = useCallback((name: string, updatedData: Partial<Variable>) => {
        // Update in array for designer
        setDataArray(prev =>
            prev.map(d => d.name === name ? { ...d, ...updatedData } : d)
        );

        // Update in map for runtime
        if (updatedData.name !== undefined && updatedData.name !== null && updatedData.name !== name) {
            // Name changed, need to remove old key
            setVariables(prev => {
                const newMap = new Map(prev);
                newMap.delete(name);
                newMap.set(updatedData.name!, updatedData.initialValue ?? null);
                return newMap;
            });
        } else if (updatedData.initialValue !== undefined) {
            // Just update the value
            setVariables(prev => {
                const newMap = new Map(prev);
                newMap.set(name, updatedData.initialValue);
                return newMap;
            });
        }
    }, []);

    const deleteData = useCallback((name: string) => {
        // Remove from array for designer
        setDataArray(prev => prev.filter(d => d.name !== name));

        // Remove from map for runtime
        setVariables(prev => {
            const newMap = new Map(prev);
            newMap.delete(name);
            return newMap;
        });
    }, []);

    // Action CRUD methods
    const addAction = useCallback((action: Action) => {
        setActions(prev => [...prev, action]);
        // Also update schema to keep it in sync
        setSchema(prev => prev ? {
            ...prev,
            events: {
                ...prev.events,
                actions: [...(prev.events?.actions || []), action]
            }
        } : prev);
    }, []);

    const updateAction = useCallback((id: string, updatedAction: Partial<Action>) => {
        setActions(prev => prev.map(action => action.id === id ? { ...action, ...updatedAction } : action));
        // Also update schema to keep it in sync
        setSchema(prev => prev ? {
            ...prev,
            events: {
                ...prev.events,
                actions: (prev.events?.actions || []).map(action =>
                    action.id === id ? { ...action, ...updatedAction } : action
                )
            }
        } : prev);
    }, []);

    const deleteAction = useCallback((id: string) => {
        setActions(prev => prev.filter(action => action.id !== id));
        // Also update schema to keep it in sync
        setSchema(prev => prev ? {
            ...prev,
            events: {
                ...prev.events,
                actions: (prev.events?.actions || []).filter(action => action.id !== id)
            }
        } : prev);
    }, []);

    // Get actions for a specific component and optionally filter by event name
    const getActionsForComponent = useCallback((componentId: string, eventName?: string): Action[] => {
        const componentActions = actions.filter(action => action.componentId === componentId);
        if (eventName) {
            return componentActions.filter(action => action.eventName === eventName);
        }
        return componentActions;
    }, [actions]);

    const clearDesign = useCallback(() => {
        setComponents([]);
        setJsCode('// Custom JS here');
        setCssCode('/* Custom CSS here */');
        setRules([]);
        setVariables(new Map());
        setVariablesArray([]);
        setDataArray([]);
        setActions([]);
        setSelectedComponentId(null);
    }, []);

    const exportDesign = useCallback(() => {
        // Export as NovaUiSchema (new unified format)
        logger.debug('Exporting schema data definitions', { definitions: schema?.data });
        const novaSchema: NovaUiSchema = {
            ui: components,
            events: {
                actions // Actions now contain embedded binding info (componentId, eventName, eventType)
            },
            ruleset: {
                rules
            },
            data: {
                var: dataArray,
                definitions: schema?.data?.definitions // Include definitions from loaded schema
            },
            jsCode,
            cssCode,
            metadata: {
                version: '1.0',
                updatedAt: new Date().toISOString()
            }
        };
        return JSON.stringify(novaSchema, null, 2);
    }, [components, jsCode, cssCode, rules, dataArray, actions, schema]);

    const importDesign = useCallback((json: string) => {
        try {
            const parsed = JSON.parse(json);

            // Check if this is NovaUiSchema with new data structure
            if (parsed.ui && parsed.events && parsed.ruleset && parsed.data?.var) {
                logger.info('Importing NovaUiSchema format', { format: 'new data structure' });
                setSchema(parsed);
                setComponents(parsed.ui || []);
                setActions(parsed.events?.actions || []);
                setRules(parsed.ruleset?.rules || []);

                // Convert data array to Map for runtime
                const newVars = new Map<string, any>();
                (parsed.data?.var || []).forEach((d: Variable) => {
                    newVars.set(d.name, d.initialValue ?? null);
                });
                setVariables(newVars);
                // Set array for designer
                setDataArray(parsed.data?.var || []);

                setJsCode(parsed.jsCode || '// Custom JS here');
                setCssCode(parsed.cssCode || '/* Custom CSS here */');
            }
            // Check if this is NovaUiSchema with old variables structure (backward compatibility)
            // else if (parsed.ui && parsed.events && parsed.ruleset && parsed.variables) {
            //     console.log('Importing NovaUiSchema format (old variables structure)');
            //     setSchema(parsed);
            //     setComponents(parsed.ui || []);
            //     setActions(parsed.events?.actions || []);
            //     setRules(parsed.ruleset?.rules || []);

            //     // Convert variables array to Map for runtime
            //     const newVars = new Map<string, any>();
            //     (parsed.variables?.vars || []).forEach((v: Variable) => {
            //         newVars.set(v.name, v.initialValue || null);
            //     });
            //     setVariables(newVars);
            //     // Set array for designer
            //     setVariablesArray(parsed.variables?.vars || []);

            //     setJsCode(parsed.jsCode || '// Custom JS here');
            //     setCssCode(parsed.cssCode || '/* Custom CSS here */');
            // }
            // Check if this is old CompleteDesignSchema format (has components property)
            else
                if (parsed.components) {
                logger.info('Importing CompleteDesignSchema format');
                setSchema(parsed);
                setComponents(parsed.components);
                setJsCode(parsed.jsCode || '');
                setCssCode(parsed.cssCode || '');
                setRules(parsed.rules || []);

                const newVars = new Map<string, any>();
                const varsArray = parsed.variables || [];
                varsArray.forEach((v: Variable) => {
                    newVars.set(v.name, v.initialValue || null);
                });
                setVariables(newVars);
                setVariablesArray(varsArray);

                setActions(parsed.actions || []);
            }
            // Check if this is legacy EBML format
            // else if (parsed.EbmlContent || parsed.Data || parsed.Ruleset || parsed.Interface) {
            //     console.log('Importing legacy EBML format');
            //     const ebmlContent = parsed.EbmlContent || parsed;
            //     const novaSchema = convertEbmlToNovaSchema(ebmlContent);

            //     setComponents(novaSchema.ui);
            //     setRules(novaSchema.ruleset.rules);
            //     setActions(novaSchema.events.actions);

            //     const newVars = new Map<string, any>();
            //     novaSchema.data.var.forEach(v => {
            //         newVars.set(v.name, v.initialValue || null);
            //     });
            //     setVariables(newVars);
            //     setVariablesArray(novaSchema.data.var);

            //     setJsCode(novaSchema.jsCode || '// Custom JS here');
            //     setCssCode(novaSchema.cssCode || '/* Custom CSS here */');
            // }
            // Fallback: try to parse as component array
            else if (Array.isArray(parsed)) {
                logger.info('Importing component array');
                setComponents(parsed);
            }
        } catch (e) {
            logger.error('Failed to import design', { error: e instanceof Error ? e.message : 'Unknown error' });
        }
    }, []);

    // Built-in variables
    const getBuiltInVariable = useCallback((name: string): any => {
        switch (name) {
            case '$today':
                return new Date().toISOString().split('T')[0];
            case '$menuKey':
                return sessionStorage.getItem('menuKey') || '';
            case '$clienthostname':
                return window.location.hostname;
            case '$clientosname':
                return navigator.platform;
            case '$securitylevel':
                return sessionStorage.getItem('securityLevel') || '0';
            case '$RC_ERROR_ID':
                return remoteCallStatus.errorId || '-1';
            default:
                return undefined;
        }
    }, [remoteCallStatus.errorId]);

    // Component method registry
    const registerComponentMethod = useCallback((componentId: string, methodName: string, method: Function) => {
        let componentMethods = componentMethodsRef.current.get(componentId);
        if (!componentMethods) {
            componentMethods = new Map();
            componentMethodsRef.current.set(componentId, componentMethods);
        }
        componentMethods.set(methodName, method);
    }, []);

    const invokeComponentMethod = useCallback((componentId: string, methodName: string, ...args: any[]): any => {
        const componentMethods = componentMethodsRef.current.get(componentId);
        if (!componentMethods) {
            logger.warn('Component not found in method registry', { componentId });
            return undefined;
        }

        const method = componentMethods.get(methodName);
        if (!method) {
            logger.warn('Method not found for component', { componentId, methodName });
            return undefined;
        }

        return method(...args);
    }, []);

    // Rule evaluation
    const evaluateRule = useCallback(async (ruleId: string): Promise<boolean> => {
        if (!schema?.ruleset?.rules) return true;
        const rule = schema.ruleset.rules.find(r => r.id === ruleId || r.name === ruleId);
        if (!rule) {
            logger.warn('Rule not found', { ruleId });
            return true;
        }

        switch (rule.type) {
            case 'Simple':
                return evaluateSimpleRule(rule);
            case 'Message':
                return await evaluateMessageRule(rule);
            case 'Combination':
                return await evaluateCombinationRule(rule);
            default:
                return true;
        }
    }, [schema]);

    const evaluateSimpleRule = useCallback((rule: Rule): boolean => {
        const sourceValue = getValueFromSource(rule.source, rule.sourceMethod);
        const targetValue = rule.targetType === 'constant'
            ? rule.target
            : getValueFromSource(rule.target, rule.targetMethod);

        switch (rule.operator) {
            case 'ISEMPTY':
                return !sourceValue || sourceValue === '';
            case 'EQ':
                return sourceValue == targetValue;
            case 'NE':
                return sourceValue != targetValue;
            case 'GT':
                return sourceValue > targetValue;
            case 'LT':
                return sourceValue < targetValue;
            case 'GTE':
                return sourceValue >= targetValue;
            case 'LTE':
                return sourceValue <= targetValue;
            default:
                return true;
        }
    }, [componentStates, variables]);

    const getValueFromSource = useCallback((source?: string, method?: string): any => {
        if (!source) return null;

        // Check if it's a variable
        if (variables.has(source)) {
            return variables.get(source);
        }

        // Check if it's a built-in variable
        if (source.startsWith('$')) {
            return getBuiltInVariable(source);
        }

        // Check if it's a component
        if (method) {
            return invokeComponentMethod(source, method);
        }

        // Otherwise return as constant
        return source;
    }, [variables, getBuiltInVariable, invokeComponentMethod]);

    const evaluateMessageRule = useCallback(async (rule: Rule): Promise<boolean> => {
        logger.debug('Rule message execution', { rule });
        const messageContent = rule.messageContentType === 'variable'
            ? getVariable(rule.messageContent || '')
            : rule.messageContent || '';
      
            return new Promise((resolve) => {
            if (rule.messageType === 'OK') {
                 message({variant:'warning', message:messageContent });
                resolve(true);
            } else if (rule.messageType === 'OK_CANCEL') {
                resolve(confirm(messageContent));
            } else if (rule.messageType === 'YES_NO') {
                resolve(confirm(messageContent));
            } else {
                resolve(true);
            }
        });
    }, [getVariable]);

    const evaluateCombinationRule = useCallback(async (rule: Rule): Promise<boolean> => {
        if (!rule.combinationExpression) return true;

        // Parse and evaluate combination expression
        // This is a simplified implementation
        let expression = rule.combinationExpression;

        // Find all rule references in the expression
        const ruleMatches = expression.match(/\w+/g) || [];

        for (const ruleRef of ruleMatches) {
            if (ruleRef === 'AND' || ruleRef === 'OR') continue;
            const ruleResult = await evaluateRule(ruleRef);
            expression = expression.replace(new RegExp(`\\b${ruleRef}\\b`, 'g'), String(ruleResult));
        }

        // Replace logical operators
        expression = expression.replace(/AND/g, '&&').replace(/OR/g, '||').replace(/!/g, '!');

        try {
            return eval(expression);
        } catch (error) {
            logger.error('Error evaluating combination rule', { error: error instanceof Error ? error.message : 'Unknown error' });
            return false;
        }
    }, [evaluateRule]);

    // Action execution
    const executeAction = useCallback(async (actionId: string, eventData?: any) => {
        if (!schema?.events?.actions) return;

        const action = schema.events.actions.find(a => a.id === actionId || a.name === actionId);
        if (!action) {
            logger.warn('Action not found', { actionId });
            return;
        }

        // Check action rule
        if (action.rule) {
            const ruleResult = await evaluateRule(action.rule);
            if (!ruleResult) {
                logger.debug('Action skipped due to rule', { actionId, rule: action.rule });
                return;
            }
        }

        // Execute sub-actions sequentially
        for (const subAction of action.subActions) {
            await executeSubAction(subAction, eventData);
        }
    }, [schema, evaluateRule]);

    const executeSubAction = useCallback(async (subAction: SubAction, eventData?: any) => {
        // Check sub-action rule
        if (subAction.rule) {
            const ruleResult = await evaluateRule(subAction.rule);
            if (!ruleResult) {
                logger.debug('Sub-action skipped due to rule', { subActionId: subAction.id, rule: subAction.rule });
                return;
            }
        }

        switch (subAction.type) {
            case 'BeanAction':
                await executeBeanAction(subAction);
                break;
            case 'RemoteCall':
                await executeRemoteCall(subAction);
                break;
            case 'ReferenceCall':
                if (subAction.referencedAction) {
                    await executeAction(subAction.referencedAction, eventData);
                }
                break;
            case 'VariableSetting':
                executeVariableSetting(subAction);
                break;
            case 'PageCall':
                executePageCall(subAction);
                break;
        }
    }, [evaluateRule, executeAction]);

    const executeBeanAction = useCallback(async (subAction: SubAction) => {
        if (!subAction.beanValue || !subAction.method) return;

        // Resolve parameters
        const args = subAction.parameters?.map(param => {
            if (param.valueType === 'constant') {
                return param.value;
            } else if (param.valueType === 'variable') {
                return getVariable(param.value);
            } else if (param.valueType === 'component' && param.valueMethod) {
                return invokeComponentMethod(param.value, param.valueMethod);
            } else if (param.valueType === 'rule') {
                return evaluateRule(param.value);
            }
            return param.value;
        }) || [];

        // Invoke component method
        invokeComponentMethod(subAction.beanValue, subAction.method, ...args);
    }, [getVariable, invokeComponentMethod, evaluateRule]);

    const executeRemoteCall = useCallback(async (subAction: SubAction) => {
        if (!subAction.service) return;

        setRemoteCallStatus({ pending: true });

        try {
            // Prepare inputs
            const inputs: any = {};
            subAction.inputs?.forEach(input => {
                if (input.valueType === 'variable') {
                    inputs[input.bagKey] = getVariable(input.value);
                } else if (input.valueType === 'component') {
                    inputs[input.bagKey] = getComponentState(input.value)?.value;
                } else {
                    inputs[input.bagKey] = input.value;
                }
            });

            // Execute remote call
            const result = await handleRemoteCall(subAction.service, inputs);

            // Process outputs
            subAction.outputs?.forEach(output => {
                const value = result[output.bagKey];
                if (output.targetType === 'variable') {
                    setVariable(output.targetVariable, value);
                } else if (output.targetType === 'component') {
                    // Get the component to determine its type
                    const component = findComponent(components, output.targetVariable);
                    const componentType = component?.type;

                    // Special handling for DataTable/Table components
                    if (componentType === 'TableComponent' || componentType === 'DataTable') {
                        // Set rows property for DataTable
                        setComponentState(output.targetVariable, {
                            value,
                            rows: value  // Also set rows property for DataTable
                        });
                    }
                    // Special handling for Select component
                    else if (componentType === 'Select') {
                        // Set options property for Select
                        setComponentState(output.targetVariable, {
                            value,
                            options: {
                                data: value,
                                displayField: 'label',
                                displayValue: 'value'
                            }
                        });
                    }
                    // Default handling for other components
                    else {
                        setComponentState(output.targetVariable, { value });
                    }
                }
            });

            setRemoteCallStatus({ pending: false, errorId: '-1' });
        } catch (error) {
            logger.error('Remote call error', { error: error instanceof Error ? error.message : 'Unknown error' });
            setRemoteCallStatus({
                pending: false,
                error: error as Error,
                errorId: (error as any).id || '1'
            });
        }
    }, [handleRemoteCall, getVariable, getComponentState, setVariable, setComponentState]);

    const executeVariableSetting = useCallback((subAction: SubAction) => {
        if (!subAction.variableName) return;

        let value: any;
        if (subAction.variableValueType === 'constant') {
            value = subAction.variableValue;
        } else if (subAction.variableValueType === 'variable') {
            value = getVariable(subAction.variableValue || '');
        } else if (subAction.variableValueType === 'component' && subAction.variableValueMethod) {
            value = invokeComponentMethod(subAction.variableValue || '', subAction.variableValueMethod);
        } else if (subAction.variableValueType === 'rule') {
            value = evaluateRule(subAction.variableValue || '');
        }

        setVariable(subAction.variableName, value);
    }, [getVariable, invokeComponentMethod, evaluateRule, setVariable]);

    const executePageCall = useCallback((subAction: SubAction) => {
        if (!subAction.pageName || !onNavigate) return;

        // Prepare parameters
        const params: PageData = {};
        subAction.pageParameters?.forEach(param => {
            if (param.valueMethod) {
                params[param.variableName] = invokeComponentMethod(param.value, param.valueMethod);
            } else {
                params[param.variableName] = getVariable(param.value);
            }
        });

        // Set return action
        if (subAction.returnAction) {
            setReturnAction(subAction.returnAction);
        }

        // Navigate
        onNavigate(subAction.pageName, subAction.pageTitle, params);
    }, [onNavigate, getVariable, invokeComponentMethod]);

    // Event management
    const addEventListener = useCallback((componentId: string, eventName: string, actionId: string, ruleId?: string) => {
        const action = schema?.events?.actions.find(a => a.id === actionId || a.name === actionId);
        if (!action) {
            logger.warn('Action not found for event listener', { actionId });
            return;
        }

        eventSubscriptionsRef.current.push({
            componentId,
            eventName,
            action,
            rule: ruleId
        });
    }, [schema]);

    const removeEventListener = useCallback((componentId: string, eventName: string) => {
        eventSubscriptionsRef.current = eventSubscriptionsRef.current.filter(
            sub => !(sub.componentId === componentId && sub.eventName === eventName)
        );
    }, []);

    const fireEvent = useCallback(async (componentId: string, eventName: string, eventData?: any) => {
        logger.info('fireEvent called', { componentId, eventName });

        // Check for subscriptions (old system)
        const subscriptions = eventSubscriptionsRef.current.filter(
            sub => sub.componentId === componentId && sub.eventName === eventName
        );

        // Check for actions in schema (new system - event bindings)
        const schemaActions = schema?.events?.actions?.filter(
            a => a.componentId === componentId && a.eventName === eventName
        ) || [];

        const totalHandlers = subscriptions.length + schemaActions.length;
        logger.info('Found event handlers', {
            componentId,
            eventName,
            totalHandlers,
            subscriptions: subscriptions.length,
            schemaActions: schemaActions.length
        });

        // Execute subscriptions first (old system)
        for (const subscription of subscriptions) {
            logger.debug('Executing action from subscription', { actionId: subscription.action.id });

            // Check rule if present
            if (subscription.rule) {
                const ruleResult = await evaluateRule(subscription.rule);
                if (!ruleResult) {
                    logger.debug('Event skipped due to rule', { componentId, eventName, rule: subscription.rule });
                    continue;
                }
            }

            // Execute action
            await executeAction(subscription.action.id, eventData);
        }

        // Execute schema actions (new system - event bindings from EBML or designer)
        for (const action of schemaActions) {
            logger.debug('Executing action from schema binding', { actionId: action.id, actionName: action.name });

            // Check rule if present
            if (action.rule) {
                const ruleResult = await evaluateRule(action.rule);
                if (!ruleResult) {
                    logger.debug('Event skipped due to rule', { componentId, eventName, rule: action.rule });
                    continue;
                }
            }

            // Execute action
            await executeAction(action.id, eventData);
        }
    }, [evaluateRule, executeAction, schema]);

    // Popup communication
    const sendDataToPopup = useCallback((popupName: string, data: PageData) => {
        if (onShowPopup) {
            onShowPopup(popupName, data).then(returnData => {
                receiveDataFromPopup(returnData);
            });
        }
    }, [onShowPopup]);

    const receiveDataFromPopup = useCallback((data: PageData) => {
        // Process return data from popup
        Object.keys(data).forEach(key => {
            setVariable(key, data[key]);
        });
    }, [setVariable]);

    // Navigation
    const navigateToPage = useCallback((pageName: string, pageTitle?: string, params?: PageData) => {
        if (params) {
            setPageData(params);
        }
        if (onNavigate) {
            onNavigate(pageName, pageTitle, params);
        }
    }, [onNavigate]);

    // Initialize lifecycle on mount
    useEffect(() => {
        if (lifecyclePhase === 'loaded') {
            setLifecyclePhase('ready');
        }
    }, [lifecyclePhase]);

    const value: NovaContextType = {
        // From PageDefinitionsContext
        // pages,
        loading,
        error,

        // From PageEngineContext
        lifecyclePhase,
        setLifecyclePhase,
        schema,
        loadSchema,
        componentStates,
        getComponentState,
        setComponentState,
        registerComponent,
        unregisterComponent,
        variablesMap: variables,
        getVariable,
        setVariable,
        getBuiltInVariable,
        evaluateRule,
        executeAction,
        addEventListener,
        removeEventListener,
        fireEvent,
        registerComponentMethod,
        invokeComponentMethod,
        remoteCallStatus,
        setRemoteCallStatus,
        pageData,
        setPageData,
        sendDataToPopup,
        receiveDataFromPopup,
        navigateToPage,
        returnAction,
        setReturnAction,

        // From DesignerContext
        components,
        jsCode,
        cssCode,
        selectedComponentId,
        mode,
        rules,
        variables: variablesArray,
        data: dataArray,
        actions,
        addRule,
        updateRule,
        deleteRule,
        addVariable,
        updateVariable,
        deleteVariable,
        addData,
        updateData,
        deleteData,
        addAction,
        updateAction,
        deleteAction,
        getActionsForComponent,
        selectComponent,
        addComponent,
        moveComponent,
        updateComponentProps,
        deleteComponent,
        setMode,
        setJsCode,
        setCssCode,
        exportDesign,
        importDesign,
        clearDesign,
        getComponentById
    };

    return (
        <NovaContext.Provider value={value}>
            <ReferenceDataLoader />
            {children}
        </NovaContext.Provider>
    );
};
