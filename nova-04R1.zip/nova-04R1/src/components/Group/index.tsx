import type { FC, ReactNode, JSX } from 'react';
import { Box } from '../../seker-ui-lib';

type GroupProps = {
    children: ReactNode | JSX.Element;
    title: string;
};

const Group: FC<GroupProps> = ({ title, children }) => {
    return (
        <Box className="group-item" display="flex" py={2}>
            <Box
                className="group-item__title"
                display="inline-block"
                textAlign="center"
                fontSize={32}
                fontWeight={600}
                mt={-0.9}
                minWidth={40}>
                {title}
            </Box>
            <Box flexGrow={1} px={1}>
                {children}
            </Box>
        </Box>
    );
};

export default Group;
