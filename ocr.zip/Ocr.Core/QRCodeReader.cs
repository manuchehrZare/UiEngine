
using OpenCvSharp;
using ZXing;
using ZXing.Common;

namespace Ocr.Core;

public class QRCodeReader
{
    public static ChequeQrResult? ReadQrCodes(Mat image)
    {
        Console.WriteLine($"[DEBUG] ReadQrCodes started. Image: {image.Cols}x{image.Rows}");
        using var gray = new Mat();
        Cv2.CvtColor(image, gray, ColorConversionCodes.BGR2GRAY);

        int height = gray.Rows;
        double[] scales;
        
        if (height < 200) scales = new[] { 3.0, 4.0, 2.0, 5.0 };
        else if (height < 600) scales = new[] { 2.0, 3.0, 4.0, 1.0 };
        else if (height < 1200) scales = new[] { 1.0, 0.75, 0.5, 2.0 };
        else scales = new[] { 1.0, 0.5, 0.25 }; // For very large images

        var reader = new BarcodeReaderGeneric
        {
            Options = new DecodingOptions
            {
                PossibleFormats = new[] { BarcodeFormat.DATA_MATRIX },
                TryHarder = true,
                PureBarcode = false
            },
            AutoRotate = true
        };

        foreach (var scale in scales)
        {
            Console.WriteLine($"[DEBUG] Trying Scale: {scale} for Height: {height}");
            Mat? scaled = null;
            try 
            {
                if (Math.Abs(scale - 1.0) > 0.01)
                {
                    scaled = new Mat();
                    Cv2.Resize(gray, scaled, new Size(0, 0), scale, scale, InterpolationFlags.Cubic);
                }
                else
                {
                    scaled = gray; // Don't dispose gray if we assign it here, but scaled is used temporarily.
                                   // Be careful with disposing logic. 
                    // Let's just clone for safety in current scope or handle carefully.
                    // For logic simplicity, referencing is fine but we musn't dispose 'gray' via 'scaled'.
                }

                // 1. Try Grayscale
                var source = new OpenCvLuminanceSource(scaled ?? gray);
                var result = reader.Decode(source);

                if (result != null && !string.IsNullOrWhiteSpace(result.Text))
                {
                    Console.WriteLine($"[DEBUG] Found Text at Scale {scale} (Grayscale): {result.Text}");
                    var parsed = ParseQrData(result.Text);
                    if (parsed != null) return parsed;
                }

                // 2. Try Binary (Otsu) - helps with high contrast background noise
                using var binary = new Mat();
                Cv2.Threshold(scaled ?? gray, binary, 0, 255, ThresholdTypes.Binary | ThresholdTypes.Otsu);
                var sourceBin = new OpenCvLuminanceSource(binary);
                result = reader.Decode(sourceBin);
                
                if (result != null && !string.IsNullOrWhiteSpace(result.Text))
                {
                    var parsed = ParseQrData(result.Text);
                    if (parsed != null) return parsed;
                }

                // 3. Try Adaptive Threshold
                using var adaptive = new Mat();
                Cv2.AdaptiveThreshold(scaled ?? gray, adaptive, 255, AdaptiveThresholdTypes.GaussianC, ThresholdTypes.Binary, 15, 10);
                var sourceAdapt = new OpenCvLuminanceSource(adaptive);
                result = reader.Decode(sourceAdapt);

                if (result != null && !string.IsNullOrWhiteSpace(result.Text))
                {
                    var parsed = ParseQrData(result.Text);
                    if (parsed != null) return parsed;
                }

                // 4. Try Inverted (Negative)
                using var inverted = new Mat();
                Cv2.BitwiseNot(scaled ?? gray, inverted);
                var sourceInv = new OpenCvLuminanceSource(inverted);
                result = reader.Decode(sourceInv);

                if (result != null && !string.IsNullOrWhiteSpace(result.Text))
                {
                    var parsed = ParseQrData(result.Text);
                    if (parsed != null) return parsed;
                }
                
            }
            finally 
            {
                if (Math.Abs(scale - 1.0) > 0.01) scaled?.Dispose();
            }
        }

        return null;
    }

    private static ChequeQrResult? ParseQrData(string rawData)
    {
        // Expected format: "KKB 00 SERIAL BANK BRANCH ACCOUNT TC_TAX MERSIS HASH"
        if (string.IsNullOrWhiteSpace(rawData))
            return null;

        rawData = rawData.Trim();
        var parts = rawData.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        if (parts.Length < 8 || parts[0] != "KKB")
            return null;

        return new ChequeQrResult
        {
            RawQr = rawData,
            SerialNumber = parts[2],
            BankCode = parts[3],
            BranchCode = parts[4],
            AccountNumber = parts[5],
            TcTaxNo = parts[6],
            MersisNo = parts[7]
        };
    }
}
