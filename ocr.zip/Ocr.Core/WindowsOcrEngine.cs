using System.Diagnostics;
using System.Text;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage;

namespace Ocr.Core;

public class WindowsOcrEngine : IOcrEngine
{
    public string Name => "Windows Media OCR";

    public async Task<OcrResult> ProcessImageAsync(string imagePath)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            // Windows OCR requires a StorageFile or SoftwareBitmap
            // Note: GetFileFromPathAsync requires absolute path
            var file = await StorageFile.GetFileFromPathAsync(Path.GetFullPath(imagePath));
            using var stream = await file.OpenAsync(FileAccessMode.Read);
            var decoder = await BitmapDecoder.CreateAsync(stream);
            
            // Transform to supported pixel format (usually Bgra8 or similar) if needed, 
            // but GetSoftwareBitmapAsync usually handles it if we ask, or OcrEngine might handle it.
            // OcrEngine supports Nv12, Yuy2, Bgra8, Rgba8, Gray8
            using var softwareBitmap = await decoder.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);

            var ocrEngine = OcrEngine.TryCreateFromUserProfileLanguages();
            if (ocrEngine == null)
            {
                 return new OcrResult 
                 { 
                     EngineName = Name, 
                     Success = false, 
                     ErrorMessage = "Could not create Windows OcrEngine. Ensure your system has language packs installed." 
                 };
            }

            var result = await ocrEngine.RecognizeAsync(softwareBitmap);
            sw.Stop();

            var sb = new StringBuilder();
            foreach (var line in result.Lines)
            {
                sb.AppendLine(line.Text);
            }

            return new OcrResult
            {
                EngineName = Name,
                Text = sb.ToString(),
                Success = true,
                ExecutionTime = sw.Elapsed
            };
        }
        catch (Exception ex)
        {
            return new OcrResult
            {
                EngineName = Name,
                Success = false,
                ErrorMessage = ex.Message,
                ExecutionTime = sw.Elapsed
            };
        }
    }
}
