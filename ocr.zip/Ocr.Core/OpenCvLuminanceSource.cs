using OpenCvSharp;
using ZXing;

namespace Ocr.Core;

public class OpenCvLuminanceSource : BaseLuminanceSource
{
    private readonly byte[] _luminances;

    public OpenCvLuminanceSource(Mat startMatrix) 
        : base(startMatrix.Width, startMatrix.Height)
    {
        // Ensure it is 8-bit grayscale
        Mat gray = startMatrix;
        bool shouldDispose = false;

        if (startMatrix.Type() != MatType.CV_8UC1)
        {
            gray = new Mat();
            if (startMatrix.Channels() > 1)
                Cv2.CvtColor(startMatrix, gray, ColorConversionCodes.BGR2GRAY);
            else
                startMatrix.ConvertTo(gray, MatType.CV_8UC1);
            shouldDispose = true;
        }

        try
        {
            int width = gray.Width;
            int height = gray.Height;
            long step = gray.Step();
            
            _luminances = new byte[width * height];

            // Copy row by row to handle potential padding (stride)
            IntPtr rawData = gray.Data;
            for (int y = 0; y < height; y++)
            {
                // Calculate source address for the row
                IntPtr rowPtr = IntPtr.Add(rawData, (int)(y * step));
                // Copy strictly 'width' bytes to the destination array
                System.Runtime.InteropServices.Marshal.Copy(rowPtr, _luminances, y * width, width);
            }
        }
        finally
        {
            if (shouldDispose)
                gray.Dispose();
        }
    }

    protected OpenCvLuminanceSource(byte[] luminances, int width, int height) 
        : base(width, height)
    {
        _luminances = luminances;
    }

    public override byte[] Matrix => _luminances;

    public override byte[] getRow(int y, byte[]? row)
    {
        if (y < 0 || y >= Height)
        {
            throw new ArgumentException("Requested row is outside the image: " + y);
        }

        int width = Width;
        if (row == null || row.Length < width)
        {
            row = new byte[width];
        }

        Array.Copy(_luminances, y * width, row, 0, width);
        return row;
    }

    public override LuminanceSource rotateCounterClockwise()
    {
        var rotatedLuminances = new byte[Width * Height];
        int newWidth = Height;
        int newHeight = Width;

        for (int yOriginal = 0; yOriginal < Height; yOriginal++)
        {
            for (int xOriginal = 0; xOriginal < Width; xOriginal++)
            {
                rotatedLuminances[(newWidth - 1 - yOriginal) + (xOriginal * newWidth)] = 
                    _luminances[xOriginal + yOriginal * Width];
            }
        }

        return new OpenCvLuminanceSource(rotatedLuminances, newWidth, newHeight);
    }

    protected override LuminanceSource CreateLuminanceSource(byte[] newLuminances, int width, int height)
    {
        return new OpenCvLuminanceSource(newLuminances, width, height);
    }
}
