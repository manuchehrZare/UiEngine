﻿using Ocr.Core;
using System;

Console.WriteLine("Starting Test...");

string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\OcrApp\cheques\qr10.jpg");
if (!File.Exists(imagePath))
{
    Console.WriteLine($"Error: File not found at {imagePath}");
    return;
}

Console.WriteLine($"Processing: {imagePath}");

// Setup Tesseract path manually for test context if needed
// Assuming bin/Debug/net9.0-windows.../tessdata exists or we point to OcrApp's one
string tessDataPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\OcrApp\bin\Debug\net9.0-windows10.0.19041.0\tessdata");
Console.WriteLine($"TessData Path: {tessDataPath}");

var processor = new ChequeProcessor(tessDataPath);
var result = processor.ProcessCheque(imagePath);

Console.WriteLine($"Success: {result.Success}");
if (!result.Success)
{
    Console.WriteLine($"Error Msg: {result.ErrorMessage}");
}

if (result.QrData != null)
{
    Console.WriteLine("QR FOUND:");
    Console.WriteLine($"Raw: {result.QrData.RawQr}");
}
else
{
    Console.WriteLine("QR NOT FOUND");
}

if (result.MicrData != null)
{
    Console.WriteLine("MICR FOUND:");
    Console.WriteLine($"Raw: {result.MicrData.RawMicr}");
}
else
{
    Console.WriteLine("MICR NOT FOUND");
}
