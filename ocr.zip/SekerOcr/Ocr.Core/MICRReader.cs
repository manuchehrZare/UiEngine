
using OpenCvSharp;
using Tesseract;
using System.Text;

namespace Ocr.Core;

public class MICRReader
{
    private readonly string _tessDataPath;

    public MICRReader(string? tessDataPath = null)
    {
        _tessDataPath = tessDataPath ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tessdata");
    }

    public ChequeMicrResult? ReadMicr(Mat image)
    {
        int height = image.Rows;
        int width = image.Cols;

        // MICR is at the bottom 20%
        int micrYStart = (int)(height * 0.80);
        if (height - micrYStart < 10)
            return null;

        var roi = new OpenCvSharp.Rect(0, micrYStart, width, height - micrYStart);
        using var micrRegion = new Mat(image, roi);

        // Preprocess
        // gray -> resize 4x -> clahe -> binary otsu
        using var gray = new Mat();
        Cv2.CvtColor(micrRegion, gray, ColorConversionCodes.BGR2GRAY);

        using var scaled = new Mat();
        Cv2.Resize(gray, scaled, new Size(0, 0), 4, 4, InterpolationFlags.Cubic);

        // CLAHE
        using var clahe = Cv2.CreateCLAHE(clipLimit: 3.0, tileGridSize: new Size(4, 4));
        using var enhanced = new Mat();
        clahe.Apply(scaled, enhanced);

        using var binary = new Mat();
        Cv2.Threshold(enhanced, binary, 0, 255, ThresholdTypes.Binary | ThresholdTypes.Otsu);

        // Convert Matrix to Pix for Tesseract
        // Easiest is to encode as PNG/BMP in memory
        byte[] imgBytes = binary.ToBytes(".bmp");

        try 
        {
            if (!Directory.Exists(_tessDataPath))
                 return null; // Or throw

            // Ensure e13b.traineddata exists
            // If not, might crash or fail init.
            using var engine = new TesseractEngine(_tessDataPath, "e13b", EngineMode.Default);
            engine.SetVariable("tessedit_pageseg_mode", "6"); // PSM 6

            using var img = Pix.LoadFromMemory(imgBytes);
            using var page = engine.Process(img);

            string text = page.GetText();
            // Post process text
            text = text.ToUpper().Replace(" ", "").Replace("\n", "").Replace("\r", "");
            
            return ParseMicrData(text);

        }
        catch (Exception)
        {
            // Logging would be good here
            return null;
        }
    }

    private ChequeMicrResult? ParseMicrData(string text)
    {
        // Parse E13B string
        // Format: C<serial>C<bank>D<branch>A<account>C
        // A separates routing from account
        string? micrText = ParseE13BMicr(text);
        if (micrText != null)
        {
             return ParseMicrParts(micrText);
        }
        return null;
    }

    private string? ParseE13BMicr(string text)
    {
        if (!text.Contains('A'))
             return null;
        
        // Find all 'A' positions
        for (int i = 0; i < text.Length; i++)
        {
            if (text[i] == 'A')
            {
                string before = text.Substring(0, i);
                string after = text.Substring(i + 1);

                string routingDigits = new string(before.Where(char.IsDigit).ToArray());
                string accountDigits = new string(after.Where(char.IsDigit).ToArray());

                string routing;
                if (routingDigits.Length >= 14)
                    routing = routingDigits.Substring(routingDigits.Length - 14);
                else
                    routing = routingDigits;

                string account;
                if (accountDigits.Length >= 16)
                    account = accountDigits.Substring(0, 16);
                else
                    account = accountDigits;

                if (routing.Length >= 13 && account.Length >= 15)
                {
                    return $"{routing}:{account}";
                }
            }
        }
        return null;
    }

    private ChequeMicrResult? ParseMicrParts(string rawMicr)
    {
        // rawMicr is routing:account
        if (string.IsNullOrEmpty(rawMicr) || !rawMicr.Contains(':'))
            return null;

        var parts = rawMicr.Split(':');
        if (parts.Length < 2) return null;

        string routing = parts[0];
        string account = parts[1];

        if (routing.Length == 13) routing = "0" + routing;
        else if (routing.Length > 14) routing = routing.Substring(routing.Length - 14);

        if (routing.Length < 14 || account.Length < 16) return null;

        return new ChequeMicrResult
        {
            RawMicr = $"{routing}:{account.Substring(0, 16)}",
            SerialNumber = routing.Substring(0, 7),
            BankCode = routing.Substring(7, 3), // length 3
            BranchCode = routing.Substring(10, 4), // length 4. 7+3=10. 10+4=14. Correct.
            AccountNumber = account.Substring(0, 16),
            Valid = true
        };
    }
}
