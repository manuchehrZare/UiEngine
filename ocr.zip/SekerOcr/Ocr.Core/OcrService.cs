namespace Ocr.Core;

public class OcrService
{
    private readonly List<IOcrEngine> _engines;

    public OcrService()
    {
        _engines = new List<IOcrEngine>
        {
            new WindowsOcrEngine(),     // Built-in powerful Windows OCR
            new TesseractOcrEngine()    // Open Source Tesseract
        };
    }

    public IEnumerable<IOcrEngine> GetEngines()
    {
        return _engines;
    }

    public IOcrEngine GetEngine(string name)
    {
        return _engines.FirstOrDefault(e => e.Name == name) 
               ?? throw new ArgumentException($"Engine '{name}' not found.");
    }
}
