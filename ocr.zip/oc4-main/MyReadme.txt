
I want to get cheque information from the images.

I cheque image can be in a image file as a single cheque data like in qr01.jpg to qr10.jpg, or in a image file with more than one cheques like in a4_01 to a4_04.

The most important data in the cheque is a qr_code in which data are included. It usually takes place on the top middle of the image.

The seocond important data is MICR data, usually takes place on the bottom of the image.

Look for the sample images and write me an application that;

- reads the image
- finds every single cheque image in the image
- get data from the qrcode of each cheque
- get data from the micr data of each cheque

The output data should be an array including cheque data as below for qr01.jpg:
[
  {
    "qr_code": {
      "raw_qr": "KKB 00 0000080053 0205 00070 0000000006097803 06210090102 0621009010200012 vdGUZC0eKbhI4pFW ",
      "serial_number": "0000080053",
      "bank_code": "0205",
      "branch_code": "00070",
      "account_number": "0000000006097803",
      "tc_tax_no": "06210090102",
      "mersis_no": "0621009010200012"
    },
    "micr": {
      "serial_number": "0080053",
      "bank_code": "205",
      "branch_code": "0070",
      "account_number": "0000000006097803",
      "raw_micr": "00800532050070:0000000006097803",
      "valid": true
    }
  }
]

The application should have the quality.
Read the qrcode and micr data seperately, don't use one's data for reading the other. I will compare each result data bymyself for approving the quality.

Write me the necessary code for my application.

----------
  Options to improve MICR accuracy:

  1. Train a custom Tesseract model for E13B MICR font
  2. Use a commercial MICR OCR SDK (e.g., ABBYY, Kofax)
  3. Use a deep learning approach with a model trained on MICR characters
  4. Use template matching for the specific E13B character shapes


----

 Here are the best MICR OCR SDK options:

  Commercial MICR OCR SDKs

  1. UltimateMICR SDK (Doubango Telecom) - Recommended

  - https://github.com/DoubangoTelecom/ultimateMICR-SDK
  - Deep learning based - specifically designed for E-13B & CMC-7
  - Free to test - no registration or license key needed to get started
  - Runs locally (no data sent to cloud)
  - Used in Remote Deposit Capture (RDC) applications
  - Python bindings available

  2. LEADTOOLS

  - https://www.leadtools.com/sdk/ocr/micr
  - https://www.leadtools.com/help/sdk/tutorials/python-detect-and-extract-micr.html
  - Enterprise-grade, supports multiple platforms
  - Python support with detailed tutorials
  - Commercial license required

  3. GDPicture

  - https://www.gdpicture.com/ocr-sdk/micr/
  - Claims up to 30 checks/second processing
  - Commercial license

  4. X9Ware E13B-OCR

  - https://x9ware.com/x9ware-e13b-ocr/
  - Uses dual recognition algorithms for high accuracy
  - Specialized for check processing

  5. ampLIB MICR OCR SDK

  - https://www.allmypapers.com/amplib/
  - Reads E13B even upside down
  - Includes image repair and skew correction

  Open Source Option

  - https://github.com/sclaflin/MICR-scanner - Basic OCR for E13B font

  ---
  My recommendation: Start with UltimateMICR SDK since it's free to evaluate and uses deep learning specifically trained for MICR. Would you like me to integrate it into the application?

─────────────────────────────────────────────────────────────────

llama3.2-vision:11b                                        6f2f9757ae97    7.8 GB    54 seconds ago
llava:7b                                                   8dd30f6b0cb1    4.7 GB    4 minutes ago
-----------

*****   FastOCR
*****   Tesseract with MICR traineddata **********

opencv-python>=4.5.0
numpy>=1.19.0
zxing-cpp>=2.0.0
pytesseract>=0.3.8

