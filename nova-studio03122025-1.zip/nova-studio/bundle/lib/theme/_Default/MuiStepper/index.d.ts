import type { Components } from '@mui/material';
export declare const MuiStepperTheme: Components;
//# sourceMappingURL=index.d.ts.map