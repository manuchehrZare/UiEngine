import type { Components } from '@mui/material';
export declare const MuiListTheme: Components;
//# sourceMappingURL=index.d.ts.map