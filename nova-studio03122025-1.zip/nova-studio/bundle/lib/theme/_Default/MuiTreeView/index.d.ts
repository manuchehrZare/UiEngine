import type { Components } from '@mui/material';
export declare const MuiTreeViewTheme: Components;
//# sourceMappingURL=index.d.ts.map