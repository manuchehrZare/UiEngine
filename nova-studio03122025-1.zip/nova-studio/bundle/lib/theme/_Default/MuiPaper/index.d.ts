import type { Components } from '@mui/material';
export declare const MuiPaperTheme: Components;
//# sourceMappingURL=index.d.ts.map