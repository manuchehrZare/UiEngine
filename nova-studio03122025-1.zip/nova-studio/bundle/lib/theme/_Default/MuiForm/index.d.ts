import type { Components } from '@mui/material';
export declare const MuiFormTheme: Components;
//# sourceMappingURL=index.d.ts.map