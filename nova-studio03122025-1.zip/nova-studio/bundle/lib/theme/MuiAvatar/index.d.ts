import type { Components } from '@mui/material';
export declare const MuiAvatarTheme: Components;
//# sourceMappingURL=index.d.ts.map