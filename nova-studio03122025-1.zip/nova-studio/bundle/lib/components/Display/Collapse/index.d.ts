import type { FC } from 'react';
import type { ICollapseProps } from './type';
declare const Collapse: FC<ICollapseProps>;
export default Collapse;
//# sourceMappingURL=index.d.ts.map