import type { SxProps, Theme } from '@mui/material';
export declare const MuiLoadingModalSxProps: () => SxProps<Theme>;
//# sourceMappingURL=style.d.ts.map