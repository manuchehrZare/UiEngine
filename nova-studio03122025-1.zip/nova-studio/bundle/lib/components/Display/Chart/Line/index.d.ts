import type { FC } from 'react';
import type { ILineChartProps } from './type';
declare const LineChart: FC<ILineChartProps>;
export default LineChart;
//# sourceMappingURL=index.d.ts.map