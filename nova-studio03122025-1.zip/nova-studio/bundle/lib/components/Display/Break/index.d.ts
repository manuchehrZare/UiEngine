import type { FC } from 'react';
import type { IBoxProps } from '../../..';
export interface IBreakProps extends Pick<IBoxProps, 'display' | 'hidden' | 'id' | 'ref' | 'style' | 'sx' | 'visibility'> {
}
declare const Break: FC<IBreakProps>;
export default Break;
//# sourceMappingURL=index.d.ts.map