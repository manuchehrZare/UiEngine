import type { PaperProps } from '@mui/material';
import type { PopoverOrigin, PopoverPosition } from '@mui/material/Popover/Popover';
import type { JSX, ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';
export interface IPopupProperty {
    anchorOrigin?: PopoverOrigin;
    anchorPosition?: PopoverPosition;
    transformOrigin?: PopoverOrigin;
}
export declare enum PopupAnchorTriggerEnum {
    CLICK = "click",
    HOVER = "hover"
}
export interface IPopupProps extends ICommonProps, Pick<PaperProps, 'sx' | 'id'> {
    anchorEl: JSX.Element;
    anchorTrigger?: `${PopupAnchorTriggerEnum}`;
    children: ReactNode;
    onClose?: () => void;
    onOpen?: () => void;
    popupPosition?: IPopupProperty;
    tooltip?: string;
    tooltipPosition?: 'bottom-end' | 'bottom-start' | 'bottom' | 'left-end' | 'left-start' | 'left' | 'right-end' | 'right-start' | 'right' | 'top-end' | 'top-start' | 'top';
}
export declare const defaultAnchorPosition: IPopupProperty;
//# sourceMappingURL=type.d.ts.map