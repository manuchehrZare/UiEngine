import type { PaperProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
export interface IPaperProps extends ICommonProps, Omit<PaperProps, 'classes' | 'elevation'> {
    borderBox?: boolean;
}
//# sourceMappingURL=type.d.ts.map