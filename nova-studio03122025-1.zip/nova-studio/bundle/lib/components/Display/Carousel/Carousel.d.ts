import type { FC } from 'react';
import type { ICarouselProps } from './type';
declare const Carousel: FC<ICarouselProps>;
export default Carousel;
//# sourceMappingURL=Carousel.d.ts.map