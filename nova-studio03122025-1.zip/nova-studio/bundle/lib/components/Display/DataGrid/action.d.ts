import type { GridColumnVisibilityModel } from '@mui/x-data-grid-pro';
import type { ICommonProps } from '../../../utils/types/common';
import type { pageSizeOptionsType } from './type';
export declare const getInitialLocalPageSize: (pageSize?: number, rowsPerPageOptions?: pageSizeOptionsType[]) => any;
export declare const generateRowsPerPageOptions: (rowsPerPageOptions?: pageSizeOptionsType[], pageSize?: number) => pageSizeOptionsType[];
export declare const generateHiddenColumns: (columns: any, hiddenColumns: string[]) => GridColumnVisibilityModel;
export declare const getDefaultHeight: (options?: Pick<ICommonProps, "design">) => {
    columnHeaderHeight: number;
    rowHeight: number;
};
export declare const getDataIndexes: (data: any[], rows: readonly any[]) => number[];
//# sourceMappingURL=action.d.ts.map