import type { IKeyValueListProps } from './type';
declare const _default: import("react").NamedExoticComponent<IKeyValueListProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map