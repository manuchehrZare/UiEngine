import type { TreeViewProps } from '@mui/x-tree-view';
import type { ICommonProps } from '../../../utils/types/common';
export interface ITreeViewOptionsData {
    data: any[];
    displayChildren?: string;
    displayDisabled?: string;
    displayId: string;
    displayLabel: string;
}
export interface ITreeViewProps extends ICommonProps, Pick<TreeViewProps<undefined>, 'className' | 'sx' | 'disableSelection'> {
    checkboxSelection?: boolean;
    collapseIcon?: React.ElementType;
    endIcon?: React.ElementType;
    expanded?: string[];
    expandIcon?: React.ElementType;
    multiSelect?: boolean;
    onFocus?: (treeItem: any) => void;
    onSelect?: (treeItems: any[], nodeIds: string[], indeterminateItemIds?: string[]) => void;
    onToggle?: (treeItems: any[], nodeIds: string[]) => void;
    options: ITreeViewOptionsData;
    selected?: string[];
    small?: boolean;
}
//# sourceMappingURL=type.d.ts.map