import type { FC } from 'react';
import type { ITableBodyProps } from './type';
declare const TableBody: FC<ITableBodyProps>;
export default TableBody;
//# sourceMappingURL=index.d.ts.map