import type { FC } from 'react';
import type { ITableProps } from './type';
declare const Table: FC<ITableProps>;
export default Table;
//# sourceMappingURL=index.d.ts.map