import type { FC } from 'react';
import type { ILinearProgressProps } from './type';
declare const CustomLinearProgress: FC<ILinearProgressProps>;
export default CustomLinearProgress;
//# sourceMappingURL=index.d.ts.map