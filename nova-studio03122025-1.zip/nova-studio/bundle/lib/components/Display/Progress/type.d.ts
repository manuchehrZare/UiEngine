import type { TypographyProps } from '@mui/material';
export declare enum ProgressTypeEnum {
    Circular = "circular",
    Linear = "linear"
}
export interface IProgressLabel extends Pick<TypographyProps, 'color'> {
    fontSize?: number;
    fontWeight?: number;
}
export interface IProgressProps extends Pick<TypographyProps, 'color' | 'className'> {
    label?: boolean | IProgressLabel;
    rounded?: boolean;
    thickness?: number;
    type: `${ProgressTypeEnum}`;
    value?: number;
}
//# sourceMappingURL=type.d.ts.map