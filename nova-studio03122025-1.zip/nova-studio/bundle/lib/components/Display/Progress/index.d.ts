import type { IProgressProps } from './type';
declare const _default: import("react").NamedExoticComponent<IProgressProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map