import type { ILabelProps } from './type';
declare const _default: import("react").NamedExoticComponent<ILabelProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map