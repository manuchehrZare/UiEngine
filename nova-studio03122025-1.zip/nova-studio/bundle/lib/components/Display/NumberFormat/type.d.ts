import type { TypographyProps } from '@mui/material';
import type { NumberFormatProps } from 'react-number-format';
import type { IBoxProps } from '../../..';
import type { ICommonProps } from '../../../utils/types/common';
export interface IStyledValueComponentProps {
    fractionalPartProps?: TypographyProps;
    integerFirstPartProps?: TypographyProps;
    integerPartProps?: TypographyProps;
}
export interface INumberFormatComponentProps {
    prefixProps?: TypographyProps;
    styledValueProps?: IStyledValueComponentProps;
    suffixProps?: TypographyProps;
    valueProps?: TypographyProps;
    valueWrapperProps?: Omit<IBoxProps, 'component'>;
}
export interface INumberFormatBaseProps extends ICommonProps, Pick<NumberFormatProps, 'className' | 'decimalScale' | 'fixedDecimalScale' | 'format' | 'prefix' | 'removeFormatting' | 'renderText' | 'suffix' | 'value'>, Pick<IBoxProps, 'sx'> {
    componentProps?: INumberFormatComponentProps;
    decimalSeparator?: ',' | '.';
    thousandSeparator?: boolean | ',' | '.' | ' ';
}
export interface IStyledValueProps extends Pick<IBoxProps, 'className'>, Pick<INumberFormatBaseProps, 'decimalSeparator' | 'design' | 'thousandSeparator'> {
    componentProps?: IStyledValueComponentProps;
    value: number | string;
}
export interface INumberFormatWithRenderTextProps extends INumberFormatBaseProps {
    styledValue?: never;
}
export interface INumberFormatWithoutRenderTextProps extends Omit<INumberFormatBaseProps, 'renderText'> {
    renderText?: never;
    styledValue?: true;
}
export type INumberFormatProps = INumberFormatWithRenderTextProps | INumberFormatWithoutRenderTextProps;
//# sourceMappingURL=type.d.ts.map