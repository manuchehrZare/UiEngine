import type { IStyledValueProps } from './type';
import type { FC } from 'react';
declare const StyledValue: FC<IStyledValueProps>;
export default StyledValue;
//# sourceMappingURL=StyledValue.d.ts.map