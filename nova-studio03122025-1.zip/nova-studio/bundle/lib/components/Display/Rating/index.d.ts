import type { IRatingProps } from './type';
declare const _default: import("react").NamedExoticComponent<IRatingProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map