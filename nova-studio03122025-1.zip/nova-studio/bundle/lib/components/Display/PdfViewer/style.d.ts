import type { SxProps, Theme } from '@mui/material';
import type { IPDFViewerProps } from './type';
interface IParams extends Pick<IPDFViewerProps, 'design' | 'width'> {
}
export declare const MuiPDFViewerSxProps: ({ design, width }: IParams) => SxProps<Theme>;
export {};
//# sourceMappingURL=style.d.ts.map