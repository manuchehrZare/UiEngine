import type { IAutocompleteProps } from '../type';
import { type JSX } from 'react';
declare const Autocomplete: <T>({ helperText, name, autoComplete, disabled, readOnly, required, label, hidden, autoFocus, open, noOptionsDataText, loadingText, disableCloseOnSelect, options, multiple, control, size, fullWidth, variant, onFocus, onKeyPress, onBlur, onChange, className, placeholder, popupIcon, openText, closeText, disablePopupIconRotate, componentsProps, deps, ChipProps, renderTags, showSelectedItemsSummary, getOptionDisabled, ...rest }: IAutocompleteProps<T>) => JSX.Element;
export default Autocomplete;
//# sourceMappingURL=index.d.ts.map