import type { IAutocompleteProps } from './type';
declare const Autocomplete: <T>({ design, autoComplete, disableCloseOnSelect, fullWidth, hidden, labelPlacement, labelEllipsis, loadingText, multiple, readOnly, size, variant, ...rest }: IAutocompleteProps<T>) => import("react/jsx-runtime").JSX.Element;
export default Autocomplete;
//# sourceMappingURL=index.d.ts.map