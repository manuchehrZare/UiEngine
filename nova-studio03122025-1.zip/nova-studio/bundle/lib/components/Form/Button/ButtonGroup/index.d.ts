import type { IButtonGroupProps } from '../type';
declare const _default: import("react").NamedExoticComponent<IButtonGroupProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map