import type { FC } from 'react';
import type { IDatePickerProps } from '../type';
declare const DatePicker: FC<IDatePickerProps>;
export default DatePicker;
//# sourceMappingURL=index.d.ts.map