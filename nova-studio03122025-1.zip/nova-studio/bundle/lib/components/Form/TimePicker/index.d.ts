import type { ITimePickerProps } from './type';
declare const _default: import("react").NamedExoticComponent<ITimePickerProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map