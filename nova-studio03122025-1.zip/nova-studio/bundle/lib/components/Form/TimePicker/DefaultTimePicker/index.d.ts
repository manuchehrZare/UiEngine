import type { FC } from 'react';
import type { ITimePickerProps } from '../type';
declare const TimePicker: FC<ITimePickerProps>;
export default TimePicker;
//# sourceMappingURL=index.d.ts.map