import 'froala-editor/css/froala_style.min.css';
import 'froala-editor/css/froala_editor.pkgd.min.css';
import 'froala-editor/js/froala_editor.pkgd.min.js';
import 'froala-editor/js/plugins.pkgd.min.js';
import type { IRichEditorProps } from './type';
declare const _default: import("react").NamedExoticComponent<IRichEditorProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map