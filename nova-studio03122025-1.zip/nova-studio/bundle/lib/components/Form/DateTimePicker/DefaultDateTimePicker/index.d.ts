import type { FC } from 'react';
import type { IDateTimePickerProps } from '../type';
declare const DateTimePicker: FC<IDateTimePickerProps>;
export default DateTimePicker;
//# sourceMappingURL=index.d.ts.map