import type { FC } from 'react';
import type { INumberInputProps } from '../type';
declare const NumberInput: FC<INumberInputProps>;
export default NumberInput;
//# sourceMappingURL=index.d.ts.map