import type { FC } from 'react';
import type { ICardNumberProps } from './type';
declare const CardNumber: FC<ICardNumberProps>;
export default CardNumber;
//# sourceMappingURL=index.d.ts.map