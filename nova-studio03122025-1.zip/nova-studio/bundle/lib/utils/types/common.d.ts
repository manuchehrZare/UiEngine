export declare enum DesignTypeEnum {
    Default = "default",
    SET = "SET"
}
export type DesignType = `${DesignTypeEnum}`;
export interface ICommonProps {
    design?: DesignType;
}
//# sourceMappingURL=common.d.ts.map