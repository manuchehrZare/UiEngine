import type { StorageValueType } from '../../../hooks/useStorage';
import type { DesignType } from '../../types/common';
export declare const setProviderDesign: (design: DesignType) => void;
export declare const getProviderDesign: () => DesignType | undefined;
export declare const removeProviderDesign: () => void;
/**
 * Does not need to be documented. It is only used in component definitions.
 */
export declare const getComponentDesignProperty: (design?: DesignType, storageDesign?: StorageValueType<DesignType>) => DesignType;
export declare const generateClass: (className: string) => string;
//# sourceMappingURL=index.d.ts.map