import type { INumberFormatOptions } from '..';
export declare const currency: (number: string | number, options?: Omit<INumberFormatOptions, "suffix" | "prefix"> & {
    currency?: string;
}) => string;
//# sourceMappingURL=index.d.ts.map