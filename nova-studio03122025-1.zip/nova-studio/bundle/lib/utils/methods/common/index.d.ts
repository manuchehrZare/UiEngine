import type { CleanOptions } from 'clean-deep';
import convert from 'xml-js';
export declare const cleanDeep: <T>(obj: T, options?: CleanOptions) => Partial<T>;
export declare function deepCopy<T>(objectValue: T): T;
export declare const sleep: (delay?: number) => any;
/**
 * It is the method that returns the only object that matches according to the unique value of a particular key.
 * @param array source array
 * @param value object searched key's value
 * @param key object searched key
 * @param childKey object children key
 * @returns T type object
 */
export declare const findDeep: <T>(array: T[], value: any, key: string, childKey?: string) => T;
/**
 * This method clears the HTML from the string.
 * @param text string param
 * @returns clean text
 */
export declare const stripHtmlFromText: (text: string) => string;
export declare const asyncForEach: <T>(array: T[], callback: (item: T, index: number) => Promise<void>) => Promise<any>;
/**
 *  This function determines is string can parse.
 */
export declare const isParsableToJson: (str: string) => boolean;
export declare const isDataUri: (text: string) => boolean;
/**
 * Returns boolen after string check completed for xml.
 * @param xmlString Given string for xml string check.
 * @returns boolean after check complete, if the given string is xml, then the function returns true.
 */
export declare const isXmlString: (xmlString: string) => boolean;
export declare const xmlToJs: (data: string, options?: convert.Options.XML2JS) => convert.Element | convert.ElementCompact;
/**
 * Convert JSON format or JS Object to XML Format
 */
export declare const jsToXml: (data: string | object, options?: convert.Options.JS2XML) => string;
//# sourceMappingURL=index.d.ts.map