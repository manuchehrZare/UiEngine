import type { IConfirmMessageModalProps } from './ConfirmMessageModal';
export interface IConfirm extends Omit<IConfirmMessageModalProps, 'proceed' | 'show'> {
}
export declare const confirm: (options?: IConfirm) => Promise<unknown>;
//# sourceMappingURL=index.d.ts.map