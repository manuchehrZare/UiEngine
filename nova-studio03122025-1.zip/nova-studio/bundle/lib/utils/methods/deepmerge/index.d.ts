interface DeepmergeOptions {
    clone?: boolean;
}
export declare function deepmerge<T>(target: T, source: unknown, options?: DeepmergeOptions): T;
export {};
//# sourceMappingURL=index.d.ts.map