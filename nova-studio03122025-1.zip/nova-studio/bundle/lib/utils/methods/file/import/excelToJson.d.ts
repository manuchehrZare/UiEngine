import type { FileExtentionsEnum } from '../type';
export interface IExcelToJsonSheetRangeValues {
    end: number;
    start: number;
}
export type ExcelToJsonSheetRangeType = {
    cell: IExcelToJsonSheetRangeValues;
    row: IExcelToJsonSheetRangeValues;
};
export interface IExcelToJsonSheetCell {
    cellIndex?: number;
    colSpan?: number;
    rowSpan?: number;
    value?: any;
}
export type ExcelToJsonSheetRowsType = IExcelToJsonSheetCell[];
interface IExcelToJsonSheet {
    sheetHtml: string;
    sheetIndex: number;
    sheetName: string;
    sheetRange: ExcelToJsonSheetRangeType;
    sheetRows: ExcelToJsonSheetRowsType[];
    sheetTxt: string;
}
export type ExcelToJsonReturnType = IExcelToJsonSheet[];
export type ExcelToJsonAcceptType = `${Extract<FileExtentionsEnum, FileExtentionsEnum.CSV | FileExtentionsEnum.XLS | FileExtentionsEnum.XLSX>}`;
export interface IExcelToJsonOptions {
    accept?: ExcelToJsonAcceptType[];
}
export declare const excelToJson: (file: File, options?: IExcelToJsonOptions) => Promise<ExcelToJsonReturnType>;
export {};
//# sourceMappingURL=excelToJson.d.ts.map