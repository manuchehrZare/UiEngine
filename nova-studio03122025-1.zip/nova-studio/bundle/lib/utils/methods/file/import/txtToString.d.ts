export interface IOption {
    accept?: 'txt'[];
}
export declare const txtToString: (file: File) => Promise<string>;
//# sourceMappingURL=txtToString.d.ts.map