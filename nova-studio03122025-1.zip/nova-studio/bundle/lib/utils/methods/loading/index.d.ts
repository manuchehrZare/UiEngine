/**
 * If the Provider's 'keepMounted' property in loadingProps is set to true, it will run actively.
 * They are used to manage the LoadingModal component in the Provider.
 * LoadingModal must have hidden={true} property.
 */
export declare const showLoading: (id?: string) => void;
/**
 * If the Provider's 'keepMounted' property in loadingProps is set to true, it will run actively.
 * They are used to manage the LoadingModal component in the Provider.
 * LoadingModal must have hidden={true} property.
 */
export declare const hideLoading: (id?: string) => void;
//# sourceMappingURL=index.d.ts.map