export declare const iban: (value: string, options?: {
    formatted?: boolean;
}) => string;
//# sourceMappingURL=index.d.ts.map