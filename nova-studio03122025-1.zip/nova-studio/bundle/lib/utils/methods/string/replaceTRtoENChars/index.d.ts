export type ReplaceTRtoEnCharsConfig = {
    joinSeperator?: '-' | '_' | ' ' | '' | '.';
};
/**
 * Replaces Turkish characters in the text to English characters.
 * @param str Text value to replace Turkish characters.
 * @param config control values that can be applied to the text.
 * @returns Returns the edited text value.
 */
export declare const replaceTRtoENChars: (str: string | string[], config?: ReplaceTRtoEnCharsConfig) => string;
//# sourceMappingURL=index.d.ts.map