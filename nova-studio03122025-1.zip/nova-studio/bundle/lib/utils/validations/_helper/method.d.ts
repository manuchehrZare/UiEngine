interface IGetVerbProps {
    fieldLabel: string;
    labelCapitalize?: boolean;
    verb: string;
}
export declare const getVerb: ({ fieldLabel, verb, labelCapitalize }: IGetVerbProps) => {
    field: string;
    verb: string;
};
/**
 * For Boolean Validation
 */
export declare const getJustVerbForBoolValidation: ({ verb }: Pick<IGetVerbProps, "verb">) => string;
export {};
//# sourceMappingURL=method.d.ts.map