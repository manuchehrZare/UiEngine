export declare const constants: {
    classNames: {
        labelEllipsis: string;
    };
    common: {
        company: {
            NAME: string;
            WEBSITE_LINK: string;
        };
        library: {
            documentation: string;
            prefix: string;
            localization: {
                defaultLng: string;
                defaultFallbackLng: string[];
            };
        };
    };
    design: {
        defaultType: import("..").DesignTypeEnum;
        border: {
            paper: {
                common: {
                    SET: {
                        width: number;
                    };
                };
                borderBox: {
                    default: {
                        width: number;
                    };
                    SET: {
                        width: number;
                    };
                };
            };
        };
        gap: {
            button: {
                default: {
                    unit: number;
                    pixel: number;
                };
                SET: {
                    unit: number;
                    pixel: number;
                };
            };
        };
        grid: {
            spacing: {
                common: {
                    default: {
                        unit: number;
                        pixel: number;
                    };
                    SET: {
                        unit: number;
                        pixel: number;
                    };
                };
                button: {
                    default: {
                        unit: number;
                        pixel: number;
                    };
                    SET: {
                        unit: number;
                        pixel: number;
                    };
                };
                form: {
                    column: {
                        default: {
                            unit: number;
                            pixel: number;
                        };
                        SET: {
                            unit: number;
                            pixel: number;
                        };
                    };
                    row: {
                        default: {
                            unit: number;
                            pixel: number;
                        };
                        SET: {
                            unit: number;
                            pixel: number;
                        };
                    };
                };
                joinedForm: {
                    column: {
                        default: {
                            unit: number;
                            pixel: number;
                        };
                        SET: {
                            unit: number;
                            pixel: number;
                        };
                    };
                };
            };
        };
        gridItem: {
            sizeType: {
                common: {
                    xs: number;
                };
                form: {
                    default: {
                        xs: number;
                    };
                    SET: {
                        xs: number;
                        sm: number;
                        md: number;
                        lg: number;
                        xl: number;
                        xxl: number;
                    };
                };
            };
        };
    };
    format: {
        char: {
            asterisk: string;
            hash: string;
            underscore: string;
        };
        design: {
            cardNo: string;
            iban: string;
            phoneNumber: {
                withAreaCode: {
                    withBrackets: {
                        withZero: string;
                        withoutZero: string;
                    };
                    withoutBrackets: {
                        withZero: string;
                        withoutZero: string;
                    };
                };
                withoutAreacode: string;
                withCountryCode: {
                    withBrackets: string;
                    withoutBrackets: string;
                };
            };
        };
        regexp: {
            dataUri: RegExp;
            email: RegExp;
            ibanTr: RegExp;
            number: RegExp;
            phoneNumber: RegExp;
            symbol: RegExp;
            trId: RegExp;
            text: {
                letter: RegExp;
                letterWithSpace: RegExp;
                letterNotTR: RegExp;
                letterWithNumberNotTR: RegExp;
                letterWithNumberAndOneDotNotTR: RegExp;
                sentence: RegExp;
            };
        };
        length: {
            iban: {
                tr: number;
            };
            trId: number;
            phone: {
                tr: {
                    withZero: number;
                    withoutZero: number;
                };
            };
            registryNo: {
                min: number;
                max: number;
            };
            password: {
                min: number;
                max: number;
            };
        };
    };
    IBANFormats: {
        TR: {
            length: number;
            regex: RegExp;
        };
        DE: {
            length: number;
            regex: RegExp;
        };
        GB: {
            length: number;
            regex: RegExp;
        };
        FR: {
            length: number;
            regex: RegExp;
        };
        IT: {
            length: number;
            regex: RegExp;
        };
        ES: {
            length: number;
            regex: RegExp;
        };
        NL: {
            length: number;
            regex: RegExp;
        };
        BE: {
            length: number;
            regex: RegExp;
        };
    };
    key: {
        PROVIDER_DESIGN: string;
        PROVIDER_THEME: string;
        PROVIDER_LOADING_ID: string;
        SekerUI_LANGUAGE: string;
        StorageEventName: string;
    };
};
//# sourceMappingURL=index.d.ts.map