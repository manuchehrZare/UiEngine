export declare const format: {
    char: {
        asterisk: string;
        hash: string;
        underscore: string;
    };
    design: {
        cardNo: string;
        iban: string;
        phoneNumber: {
            withAreaCode: {
                withBrackets: {
                    withZero: string;
                    withoutZero: string;
                };
                withoutBrackets: {
                    withZero: string;
                    withoutZero: string;
                };
            };
            withoutAreacode: string;
            withCountryCode: {
                withBrackets: string;
                withoutBrackets: string;
            };
        };
    };
    regexp: {
        dataUri: RegExp;
        email: RegExp;
        ibanTr: RegExp;
        number: RegExp;
        phoneNumber: RegExp;
        symbol: RegExp;
        trId: RegExp;
        text: {
            letter: RegExp;
            letterWithSpace: RegExp;
            letterNotTR: RegExp;
            letterWithNumberNotTR: RegExp;
            letterWithNumberAndOneDotNotTR: RegExp;
            sentence: RegExp;
        };
    };
    length: {
        iban: {
            tr: number;
        };
        trId: number;
        phone: {
            tr: {
                withZero: number;
                withoutZero: number;
            };
        };
        registryNo: {
            min: number;
            max: number;
        };
        password: {
            min: number;
            max: number;
        };
    };
};
//# sourceMappingURL=index.d.ts.map