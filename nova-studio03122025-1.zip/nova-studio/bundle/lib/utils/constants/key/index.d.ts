export declare const key: {
    PROVIDER_DESIGN: string;
    PROVIDER_THEME: string;
    PROVIDER_LOADING_ID: string;
    SekerUI_LANGUAGE: string;
    StorageEventName: string;
};
//# sourceMappingURL=index.d.ts.map