import type { Ref, RefObject } from 'react';
export type MeasureValues = Partial<Pick<DOMRect, 'bottom' | 'height' | 'left' | 'right' | 'top' | 'width' | 'x' | 'y'>>;
export type UseMeasureOptions = {
    /**
     * Optional external dependencies for the effect
     */
    effectDeps?: any[];
};
/**
 * Return type for the `useMeasure` hook.
 * @template T - Type of the target HTML element (defaults to HTMLDivElement).
 */
export type UseMeasureReturnType<T extends HTMLElement = HTMLDivElement> = {
    /**
     * The actual DOM element instance that the ref is attached to.
     * It will be `null` until the element mounts.
     */
    node: T | null;
    /**
     * A React ref that should be attached to the target DOM element.
     */
    ref: Ref<T> | RefObject<T>;
    /**
     * Computed measurement values of the referenced element, updated reactively.
     */
    values: MeasureValues;
};
/**
 * A custom React hook that observes and returns the computed measurement values of a DOM element in real-time.
 *
 * It uses a combination of:
 * - `ResizeObserver` for size changes,
 * - `MutationObserver` for DOM mutations,
 * - Media queries and window events for environmental changes. (resize, scroll, reset, matchMedia-change)
 *
 * The hook returns a `ref` to be attached to a DOM element and the latest computed measurement values for that element.
 *
 * @param options - Contains parameters that will affect Hook's operation.
 * @template T - The type of HTML element being observed (e.g., HTMLDivElement).
 * @returns {UseMeasureReturnType<T>} An object containing the ref and up-to-date computed measurement values.
 */
declare const useMeasure: <T extends HTMLElement = HTMLDivElement>(options?: UseMeasureOptions) => UseMeasureReturnType<T>;
export default useMeasure;
//# sourceMappingURL=useMeasure.d.ts.map