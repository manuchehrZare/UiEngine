import type { MutableRefObject } from 'react';
import type { IReactToPrintProps } from 'react-to-print';
export interface IUsePrintProps extends Omit<IReactToPrintProps, 'removeAfterPrint' | 'nonce' | 'fonts' | 'suppressErrors' | 'trigger' | 'content'> {
}
export type UsePrintReturnType = {
    handlePrint: () => void;
    ref: MutableRefObject<null>;
};
declare const usePrint: (props?: IUsePrintProps) => UsePrintReturnType;
export default usePrint;
//# sourceMappingURL=usePrint.d.ts.map