declare const useDebounce: <T>(value: T, delay?: number) => T;
export default useDebounce;
//# sourceMappingURL=useDebounce.d.ts.map