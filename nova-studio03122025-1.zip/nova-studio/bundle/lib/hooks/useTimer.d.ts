import type { DeepRequired, Enumerate, PositiveRange, Time, TimeReturnValues } from '..';
export declare enum UseTimerErrorEnum {
    AlreadyStarted = 0,
    AlreadyStopped = 1,
    CountdownValues = 2,
    NegativeValues = 3,
    ReachedLimit = 4,
    PositiveSpeedMultiplier = 5,
    WithoutCountdownValues = 6
}
export type UseTimerBaseOptions = {
    /**
     * Whether the timer should count down instead of up
     * @default false
     */
    isCountdown?: boolean;
    /**
     * Controls which time units are returned
     * @default all true
     * { hours: true, milliseconds: true, minutes: true, seconds: true }
     */
    returnValues?: TimeReturnValues;
    /**
     * Speed of the timer
     * - 1 = real time
     * - Max: 50
     * @default 1
     */
    speedMultiplier?: PositiveRange<1, 51>;
    /**
     * Initial time when the timer starts
     * @default { hours: 0, milliseconds: 0, minutes: 0, seconds: 0 }
     */
    startValues?: Partial<Time>;
    /**
     * Target time at which the timer stops
     * @default { hours: 0, milliseconds: 0, minutes: 0, seconds: 0 }
     */
    stopValues?: Partial<Time>;
};
export type UseTimerError = {
    /**
     * Helper: UseTimerErrorEnum
     */
    code: Enumerate<7>;
    message: string;
};
export type UseTimerCallbackOptions = {
    onError?: (error: UseTimerError) => void;
    onReset?: (lastTime: Time, newOptions: DeepRequired<UseTimerBaseOptions>) => void;
    onStart?: (options: UseTimerBaseOptions) => void;
    onStop?: (stoppedTime: Time, options: DeepRequired<UseTimerBaseOptions>) => void;
};
export type UseTimerOptions = UseTimerBaseOptions & UseTimerCallbackOptions;
export type UseTimerReturn = Time & {
    /**
     * Updates the speed multiplier
     */
    changeSpeedMultiplier: (newSpeed: PositiveRange<1, 51>) => void;
    /**
     * When the counter is finished, it becomes true.
     * @default false
     */
    isCompleted: boolean;
    /**
     * Indicates whether the timer is currently running
     */
    isRunning: boolean;
    /**
     * Percentage of progress from start to stop time (0–100)
     */
    progress: number;
    /**
     * In the meter mode, it gives the remaining time in the countdown.
     */
    remainingTime: Time;
    /**
     * Resets the timer with optional new values
     */
    reset: (newOptions?: UseTimerBaseOptions) => void;
    start: () => void;
    stop: () => void;
};
/**
 * useTimer React hook for managing a customizable countdown or stopwatch
 * @param options - Configuration options and callbacks for the timer
 * @returns Object containing timer state, controls, and utility functions
 */
declare const useTimer: (options?: UseTimerOptions) => UseTimerReturn;
export default useTimer;
//# sourceMappingURL=useTimer.d.ts.map