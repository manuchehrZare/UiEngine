import type { Control, DefaultValues, FieldErrors, FieldValues, Path, PathValue, UseFormClearErrors, UseFormGetValues, UseFormProps, UseFormReturn as UseHookFormReturn } from 'react-hook-form';
export interface IUseFormProps<TFields> extends Pick<UseFormProps, 'mode' | 'reValidateMode' | 'criteriaMode' | 'delayError'> {
    defaultValues: TFields;
    validationSchema?: any;
}
interface IUseForm<TFields extends FieldValues = FieldValues> extends Pick<UseHookFormReturn<TFields>, 'control' | 'handleSubmit' | 'resetField' | 'setValue' | 'watch' | 'getValues' | 'clearErrors' | 'reset' | 'setFocus' | 'trigger' | 'formState'> {
    setFieldError: (fieldName: Path<TFields>, errorMsg: string) => void;
}
export type UseFormReturnType<T extends FieldValues = FieldValues> = IUseForm<T>;
export type { Control, DefaultValues, FieldErrors, FieldValues, Path, PathValue, UseFormClearErrors, UseFormGetValues };
declare const useForm: <TFields extends FieldValues = FieldValues>({ validationSchema, defaultValues, mode, reValidateMode, criteriaMode, delayError, }: IUseFormProps<TFields>) => UseFormReturnType<TFields>;
export default useForm;
//# sourceMappingURL=useForm.d.ts.map