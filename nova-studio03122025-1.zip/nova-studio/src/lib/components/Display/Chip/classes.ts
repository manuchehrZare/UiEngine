import { chipClasses as MuiChipClasses } from '@mui/material';

export const MuiChipShapeClasses = {
    cornered: 'cornered',
    corneredLeft: 'cornered-left',
    corneredRight: 'cornered-right',
};

export const chipClasses = { ...MuiChipClasses, ...MuiChipShapeClasses };
