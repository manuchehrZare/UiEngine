import type { FC } from 'react';
import type { ICollapseProps } from './type';
import { Collapse as MuiCollapse } from '@mui/material';
import { generateClass, manageClassNames } from '../../../utils';

const Collapse: FC<ICollapseProps> = ({ children, className, ...rest }) => {
    return (
        <MuiCollapse className={manageClassNames(generateClass('Collapse'), className)} {...rest}>
            {children}
        </MuiCollapse>
    );
};

export default Collapse;
