import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IModalTitleProps } from './type';
import { DialogTitle } from '@mui/material';
import { manageClassNames } from '../../..';
import { generateClass } from '../../../utils';

const ModalTitle: FC<IModalTitleProps> = forwardRef(({ children, className, ...rest }: IModalTitleProps, ref) => {
    return (
        <DialogTitle className={manageClassNames(generateClass('Modal-Title'), className)} ref={ref} {...rest}>
            {children}
        </DialogTitle>
    );
});

export default ModalTitle;
