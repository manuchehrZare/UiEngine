import type { ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';
import type { StepperProps } from '@mui/material';

export interface IStepType {
    /**
     * The main content displayed for the step.
     **/
    content: ReactNode;
    /**
     * The title or label of the step, shown in the stepper header.
     **/
    label: string;
    /**
     * Callback triggered when navigating back from this step.
     **/
    onBack?: () => void;
    /**
     * Callback called before proceeding to the next step. Return true to continue, or false to block navigation.
     **/
    onNext?: () => Promise<boolean> | boolean;
}

export interface IStepperProps
    extends ICommonProps,
        Pick<StepperProps, 'alternativeLabel' | 'className' | 'orientation' | 'sx'> {
    /**
     * Called when the stepper process is fully completed.
     **/
    onCompleted?: () => void;
    /**
     * Triggered when the final step is reached via the "Finish" button.
     **/
    onFinish?: () => void;
    /**
     * FCalled whenever the active step changes.
     **/
    onStepChange?: (currentIndex: number, isFirst: boolean, isLast: boolean) => void;
    /**
     * Determines whether navigation buttons ("Next", "Back", "Finish") are displayed.
     **/
    showButtons?: boolean;
    /**
     * An array of step definitions, each containing a label, content, and optional callbacks.
     **/
    stepItems: IStepType[];
}

export interface IStepStepperRef {
    /**
     * Navigates directly to the specified step by index.
     **/
    goToStep: (index: number) => void;
    /**
     * Moves to the next step. If it's the last step, triggers completion logic.
     **/
    next: () => Promise<void>;
    /**
     * Moves back to the previous step.
     **/
    prev: () => void;
    /**
     * Resets the stepper to the first step and clears completion state.
     **/
    reset: () => void;
}
