import type { GridApiPro } from '@mui/x-data-grid-pro';
import { gridPageCountSelector, gridPageSelector, GridPagination } from '@mui/x-data-grid-pro';
import type { FC, JSX } from 'react';
import { generateClass, manageClassNames } from '../../../utils';
import { Pagination } from '../../..';
import type { IPaginationProps } from '../Pagination/type';

interface ICustomPaginationProps extends IPaginationProps {
    apiRef: React.MutableRefObject<GridApiPro>;
}
const CustomPagination: FC<ICustomPaginationProps> = ({ apiRef, className, ...rest }): JSX.Element => {
    return (
        <GridPagination
            ActionsComponent={() => {
                return (
                    <Pagination
                        className={manageClassNames(generateClass('DataGrid-pagination'), className)}
                        count={gridPageCountSelector(apiRef)} // Total pages
                        page={gridPageSelector(apiRef) + 1}
                        onChange={(_: React.ChangeEvent<unknown>, value: number) => {
                            if (apiRef?.current) {
                                apiRef.current.setPage(value - 1); // Set the new page (zero-based indexing)
                            }
                        }}
                        {...rest}
                    />
                );
            }}
        />
    );
};

export default CustomPagination;
