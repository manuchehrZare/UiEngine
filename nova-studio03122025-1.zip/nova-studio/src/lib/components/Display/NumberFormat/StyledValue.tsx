import type { TypographyProps } from '@mui/material';
import { Typography } from '@mui/material';
import type { IStyledValueProps } from './type';
import type { FC, JSX } from 'react';
import { generateClass, manageClassNames } from '../../../utils';
import { Box } from '../../../';

const StyledValue: FC<IStyledValueProps> = ({
    design,
    value,
    className,
    decimalSeparator = ',',
    thousandSeparator,
    componentProps,
}): JSX.Element => {
    // Convert value to string
    const normalizeValue = (val: string | number): string => {
        return typeof val === 'number' ? val.toString() : val;
    };

    // Split value into integer and fractional parts
    const splitDecimalParts = (val: string) => {
        const lastComma = val.lastIndexOf(',');
        const lastDot = val.lastIndexOf('.');
        const splitIndex = Math.max(lastComma, lastDot);

        if (splitIndex === -1) {
            return {
                integerPart: val,
                fractionalPart: '',
            };
        }

        return {
            integerPart: val.slice(0, splitIndex),
            fractionalPart: val.slice(splitIndex + 1),
        };
    };

    // Split integer part by thousand separator
    const splitIntegerParts = (integerPart: string) => {
        if (!thousandSeparator || !componentProps?.integerFirstPartProps) {
            return {
                firstPartInteger: undefined,
                restPartInteger: undefined,
            };
        }

        const firstSeparatorIndex = integerPart.indexOf(
            typeof thousandSeparator === 'boolean' ? ',' : thousandSeparator,
        );

        if (firstSeparatorIndex === -1) {
            return {
                firstPartInteger: undefined,
                restPartInteger: undefined,
            };
        }

        return {
            firstPartInteger: integerPart.slice(0, firstSeparatorIndex),
            restPartInteger: integerPart.slice(firstSeparatorIndex),
        };
    };

    // Render integer part with or without first part styling
    const renderIntegerPart = (
        integerPart: string,
        firstPartInteger: string | undefined,
        restPartInteger: string | undefined,
        showDecimalSeparator: boolean,
    ) => {
        const renderIntegerPartElement = (children: TypographyProps['children']) => (
            <Typography
                component="span"
                {...componentProps?.integerPartProps}
                className={manageClassNames(
                    generateClass('NumberFormat-styledValue-integerPart'),
                    design,
                    componentProps?.integerPartProps?.className,
                )}>
                {children}
            </Typography>
        );

        if (firstPartInteger !== undefined && componentProps?.integerFirstPartProps) {
            return (
                <>
                    <Typography
                        component="span"
                        {...componentProps?.integerFirstPartProps}
                        className={manageClassNames(
                            generateClass('NumberFormat-styledValue-integerFirstPart'),
                            design,
                            componentProps?.integerFirstPartProps?.className,
                        )}>
                        {firstPartInteger}
                    </Typography>
                    {renderIntegerPartElement(restPartInteger + (showDecimalSeparator ? decimalSeparator : ''))}
                </>
            );
        }
        return renderIntegerPartElement(integerPart + (showDecimalSeparator ? decimalSeparator : ''));
    };

    const strValue = normalizeValue(value);
    const { integerPart, fractionalPart } = splitDecimalParts(strValue);
    const { firstPartInteger, restPartInteger } = splitIntegerParts(integerPart);

    return (
        <Box display="inline-block" className={className}>
            {renderIntegerPart(integerPart, firstPartInteger, restPartInteger, Boolean(fractionalPart))}
            {fractionalPart && (
                <Typography
                    component="span"
                    {...componentProps?.fractionalPartProps}
                    className={manageClassNames(
                        generateClass('NumberFormat-styledValue-fractionalPart'),
                        design,
                        componentProps?.fractionalPartProps?.className,
                    )}>
                    {fractionalPart}
                </Typography>
            )}
        </Box>
    );
};

export default StyledValue;
