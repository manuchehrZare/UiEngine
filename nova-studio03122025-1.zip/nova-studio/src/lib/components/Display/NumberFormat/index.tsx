import type { FC, JSX } from 'react';
import ReactNumberFormat from 'react-number-format';
import StyledValue from './StyledValue';
import type { INumberFormatProps } from './type';
import type { DesignType, Theme } from '../../..';
import { Box, constants, manageClassNames, Typography, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme } from '../../../utils';
import ThemeProvider from '../../App/ThemeProvider';

const NumberFormat: FC<INumberFormatProps> = ({
    className,
    componentProps,
    design,
    prefix,
    renderText,
    styledValue,
    suffix,
    sx,
    fixedDecimalScale = false,
    ...rest
}): JSX.Element => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <ReactNumberFormat
                displayType="text"
                renderText={(formattedValue) => {
                    const value = formattedValue.replace(prefix || '', '').replace(suffix || '', '');
                    return (
                        <Box
                            className={manageClassNames(
                                generateClass('NumberFormat'),
                                getComponentDesignProperty(design, storageDesign.newValue),
                                className,
                                { styledValue: Boolean(styledValue) },
                            )}
                            display="inline-block"
                            sx={sx}>
                            {prefix && (
                                <Typography
                                    component="span"
                                    className={manageClassNames(
                                        generateClass('NumberFormat-prefix'),
                                        getComponentDesignProperty(design, storageDesign.newValue),
                                        componentProps?.prefixProps?.className,
                                    )}
                                    {...componentProps?.prefixProps}>
                                    {prefix}
                                </Typography>
                            )}
                            <Box
                                component="div"
                                display="inline-block"
                                className={manageClassNames(
                                    generateClass('NumberFormat-value-wrapper'),
                                    componentProps?.valueWrapperProps?.className,
                                    { styledValue: Boolean(styledValue) },
                                )}
                                {...componentProps?.valueWrapperProps}>
                                {renderText ? (
                                    renderText(value)
                                ) : styledValue ? (
                                    <StyledValue
                                        design={getComponentDesignProperty(design, storageDesign.newValue)}
                                        value={value}
                                        className={manageClassNames(generateClass('NumberFormat-styledValue'))}
                                        decimalSeparator={rest?.decimalSeparator}
                                        thousandSeparator={
                                            typeof rest?.thousandSeparator === 'boolean' ? ',' : rest?.thousandSeparator
                                        }
                                        componentProps={componentProps?.styledValueProps}
                                    />
                                ) : (
                                    <Typography
                                        component="span"
                                        className={manageClassNames(
                                            generateClass('NumberFormat-value'),
                                            getComponentDesignProperty(design, storageDesign.newValue),
                                            componentProps?.valueProps?.className,
                                        )}
                                        {...componentProps?.valueProps}>
                                        {value}
                                    </Typography>
                                )}
                            </Box>
                            {suffix && (
                                <Typography
                                    component="span"
                                    className={manageClassNames(
                                        generateClass('NumberFormat-suffix'),
                                        getComponentDesignProperty(design, storageDesign.newValue),
                                        componentProps?.suffixProps?.className,
                                    )}
                                    {...componentProps?.suffixProps}>
                                    {suffix}
                                </Typography>
                            )}
                        </Box>
                    );
                }}
                fixedDecimalScale={fixedDecimalScale}
                {...rest}
            />
        </ThemeProvider>
    );
};

export default NumberFormat;
