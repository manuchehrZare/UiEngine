import type { BoxProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
import type { IButtonProps } from '../../Form/Button/type';
import type { IDividerProps } from '../Divider/type';
import type { IGridProps } from '../Grid/type';
import type { IBoxProps } from '../../..';

export interface INavContainerProps extends ICommonProps, Omit<IGridProps, 'classes' | 'color' | 'fontFamily'> {
    dividerProps?: Omit<IDividerProps, 'design'>;
    navContainerWrapperProps?: Omit<IBoxProps, 'component'>;
    small?: boolean;
    stickyBottom?: boolean;
    stickyTop?: boolean;
}

export interface INavRowProps extends ICommonProps, Omit<IGridProps, 'classes' | 'color' | 'fontFamily'> {}

export interface INavItemProps extends ICommonProps, Omit<IGridProps, 'classes' | 'color' | 'fontFamily'> {}

export interface IBackButtonProps extends Omit<IButtonProps, 'design' | 'type' | 'name' | 'fullWidth'> {
    show?: boolean;
    tooltipTitle?: NonNullable<React.ReactNode>;
}

export interface INavTitleProps extends ICommonProps, Pick<BoxProps, 'sx'> {
    backButtonProps?: IBackButtonProps;
    isView?: boolean;
    label?: string;
    subTitle?: string;
    title: string;
}

export interface INavProps extends ICommonProps, Pick<INavContainerProps, 'ref'> {
    navContainerProps?: Omit<INavContainerProps, 'design' | 'ref'>;
    navItemProps?: Omit<INavItemProps, 'design'>;
    navRowProps?: Omit<INavRowProps, 'design'>;
    navTitleProps?: Omit<INavTitleProps, 'design'>;
}
