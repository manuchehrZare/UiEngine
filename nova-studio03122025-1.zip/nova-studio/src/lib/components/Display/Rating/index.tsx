import type { Theme } from '@mui/material';
import { Rating as MuiRating } from '@mui/material';
import type { IRatingProps } from './type';
import type { FC } from 'react';
import { memo } from 'react';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme, manageClassNames } from '../../../utils';
import { omit } from 'lodash';

const Rating: FC<IRatingProps> = ({
    defaultValue,
    value,
    precision,
    emptyIcon,
    max,
    icon,
    size,
    sx,
    design,
    className,
    color = 'secondary',
    readOnly = true,
    ...rest
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiRating
                className={manageClassNames(
                    generateClass('Rating'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                value={value}
                defaultValue={defaultValue}
                precision={precision}
                icon={icon}
                emptyIcon={emptyIcon}
                max={max}
                size={size}
                readOnly={readOnly}
                sx={{ color, ...sx }}
                {...omit(rest, ['name'])}
            />
        </ThemeProvider>
    );
};

export default memo(Rating);
