import type { ICommonProps } from '../../../utils/types/common';
import type { IBoxProps, IModalBodyProps, IModalProps, IModalTitleProps } from '../../..';
import type { DocumentProps, PageProps } from 'react-pdf';
import type { JSX } from 'react';

export interface IToolsProps {
    label?: string;
    order?: number;
    passive?: boolean;
}

export interface IToolbarToolsProps {
    actualSize?: IToolsProps;
    fitPage?: IToolsProps;
    fitWidth?: IToolsProps;
    menu?: Pick<IToolsProps, 'label'>;
    more?: Pick<IToolsProps, 'label'>;
    nextPage?: Pick<IToolsProps, 'label'>;
    previousPage?: Pick<IToolsProps, 'label'>;
    print?: IToolsProps;
    rotate?: Pick<IToolsProps, 'label'>;
    save?: IToolsProps;
    zoomIn?: Pick<IToolsProps, 'label'>;
    zoomOut?: Pick<IToolsProps, 'label'>;
}

export interface IToolbarButtonProps extends IToolsProps {
    disabled?: boolean;
    icon: JSX.Element;
    onClick: (e: any) => void;
}

export interface ICustomToolsProps extends Omit<IToolbarButtonProps, 'onClick' | 'disabled' | 'label'> {
    label: string;
    onClick: (doc: any) => void;
}

export interface IPDFViewerComponentsProps {
    documentProps?: Omit<DocumentProps, 'children' | 'file' | 'inputRef'>;
    /**
     * Filename to download.
     **/
    fileName?: string;
    pageProps?: Omit<PageProps, 'pageIndex' | 'pageNumber' | 'scale'>;
    toolbarProps?: {
        customTools?: ICustomToolsProps[];
        onSave?: (e: any) => void;
        tools?: IToolbarToolsProps;
        zoomIncrement?: number;
    };
}

export interface IPDFViewerModalProps extends Omit<IModalProps, 'children'> {
    modalBodyProps?: IModalBodyProps;
    modalTitleProps?: Omit<IModalTitleProps, 'title'>;
    title?: string;
}

export type ToolbarFormValues = {
    zoomRatio: number;
};

type PDFComponentViewProps =
    | {
          modal: true;
          /**
           * Enabled if the modal value is true.
           */
          modalProps: IPDFViewerModalProps;
      }
    | { modal?: false; modalProps?: undefined };

interface IPDFViewerCommonProps extends ICommonProps, Pick<IBoxProps, 'className' | 'id'> {
    height?: number | string;
    /**
     * PDF file source.
     **/
    source: any;
    width?: number | string;
}

export interface IPDFBrowserViewerProps extends IPDFViewerCommonProps {
    /**
     * BrowserViewer allows you to use the pdf view feature of the browser that you have opened your project.
     * Their appearance may change depending on the browser you have entered.
     * The componentsProps property is ignored when the browserViewer and componentsProps properties are sent at the same time
     **/
    browserViewer?: true;
}

export interface IPDFCustomViewerProps extends IPDFViewerCommonProps, Pick<IBoxProps, 'sx'> {
    /**
     * BrowserViewer allows you to use the pdf view feature of the browser that you have opened your project.
     * Their appearance may change depending on the browser you have entered.
     * The componentsProps property is ignored when the browserViewer and componentsProps properties are sent at the same time
     **/
    browserViewer?: false;
    componentProps?: IPDFViewerComponentsProps;
}

export type IPDFViewerProps = (IPDFCustomViewerProps | IPDFBrowserViewerProps) & PDFComponentViewProps;

export enum ActiveTabEnum {
    Preview = '1',
    Titles = '2',
}
