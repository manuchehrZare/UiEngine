import { Legend } from 'recharts';
import type { ILegend } from './type';
import type { JSX } from 'react';

const CustomLegend = (legend: boolean | ILegend): JSX.Element => {
    const renderColorfulLegendText = (value: string) => {
        return (
            <span
                style={{
                    color: (legend as ILegend)?.color || 'var(--color-text)',
                    paddingTop: 20,
                    fontSize: (legend as ILegend)?.fontSize || 14,
                }}>
                {value}
            </span>
        );
    };

    return (
        <Legend
            wrapperStyle={{
                ...(typeof legend !== 'boolean' && legend?.position === 'bottom'
                    ? { bottom: 20 - (legend?.margin || 0) }
                    : typeof legend !== 'boolean' && legend?.position === 'top'
                      ? { top: 20 - (legend?.margin || 0) }
                      : legend && {
                            bottom: 20 - ((legend as ILegend)?.margin || 0),
                        }),
            }}
            iconSize={(legend as ILegend)?.iconSize || 8}
            formatter={renderColorfulLegendText}
            {...(typeof legend !== 'boolean'
                ? {
                      verticalAlign: legend.position || 'bottom',
                      layout: legend.layout,
                      iconType: legend.iconType || 'circle',
                  }
                : { iconType: 'circle' })}
        />
    );
};

export default CustomLegend;
