import { useEffect } from 'react';

const useTitle = (title: string): void => {
    useEffect(() => {
        if (document.title !== title.trim()) document.title = title.trim();
    }, [title]);
};

export default useTitle;
