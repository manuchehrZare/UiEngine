import { useState, useEffect, useRef, useCallback, useMemo } from 'react';

interface IUseAudioOptions {
    autoplay?: boolean;
    loop?: boolean;
    muted?: boolean;
    onPlayError?: (error: string) => void;
    playbackRate?: number;
    volume?: number;
}

interface IAudioState {
    currentTime: number;
    duration: number;
    error: string | null;
    loop: boolean;
    muted: boolean;
    playbackRate: number;
    playing: boolean;
    volume: number;
}

interface IAuidoControls {
    pause: () => void;
    play: () => void;
    seek: (time: number) => void;
    setLoop: (loop: boolean) => void;
    setMuted: (muted: boolean) => void;
    setPlaybackRate: (rate: number) => void;
    setVolume: (volume: number) => void;
    stop: () => void;
}

interface IUseAudioReturn extends IAudioState, IAuidoControls {}

const useAudio = (src: string, options: IUseAudioOptions = {}): IUseAudioReturn => {
    const audioRef = useRef<HTMLAudioElement | null>(null);
    const [state, setState] = useState<IAudioState>({
        playing: false,
        duration: 0,
        currentTime: 0,
        volume: options.volume ?? 1,
        muted: options.muted ?? false,
        playbackRate: options.playbackRate ?? 1,
        error: null,
        loop: options.loop ?? false,
    });

    const setPartialState = useCallback((partialState: Partial<IAudioState>) => {
        setState((prevState) => ({ ...prevState, ...partialState }));
    }, []);

    useEffect(() => {
        audioRef.current = new Audio(src);
        const audio = audioRef.current;

        const handleLoadedMetadata = () => setPartialState({ duration: audio.duration });
        const handleEnded = () => setPartialState({ playing: false });
        const handleError = (e: ErrorEvent) => setPartialState({ error: e.message });
        const handleTimeUpdate = () => setPartialState({ currentTime: audio.currentTime });

        audio.addEventListener('loadedmetadata', handleLoadedMetadata);
        audio.addEventListener('ended', handleEnded);
        audio.addEventListener('error', handleError);
        audio.addEventListener('timeupdate', handleTimeUpdate);

        if (options.autoplay) {
            audio.play().catch((e) =>
                setPartialState({
                    error: e.message,
                    playing: false,
                }),
            );
            setPartialState({ playing: true, error: null });
        }

        return () => {
            audio.pause();
            audio.currentTime = 0;
            audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
            audio.removeEventListener('ended', handleEnded);
            audio.removeEventListener('error', handleError);
            audio.removeEventListener('timeupdate', handleTimeUpdate);
        };
    }, [src, options.autoplay, setPartialState]);

    useEffect(() => {
        if (audioRef.current) {
            audioRef.current.volume = state.volume;
            audioRef.current.muted = state.muted;
            audioRef.current.playbackRate = state.playbackRate;
            audioRef.current.loop = state.loop;
        }
    }, [state.volume, state.muted, state.playbackRate, state.loop]);

    useEffect(() => {
        state.error && state.error !== undefined && options?.onPlayError?.(state.error);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [state.error]);

    const controls = useMemo((): IAuidoControls => {
        const audio = audioRef.current;
        return {
            play: () => {
                if (audio) {
                    audio.play().catch((e) =>
                        setPartialState({
                            error: e.message,
                            playing: false,
                        }),
                    );
                    setPartialState({ playing: true, error: null });
                }
            },
            pause: () => {
                if (audio) {
                    audio.pause();
                    setPartialState({ playing: false });
                }
            },
            stop: () => {
                if (audio) {
                    audio.pause();
                    audio.currentTime = 0;
                    setPartialState({ playing: false, currentTime: 0 });
                }
            },
            setVolume: (volume: number) => setPartialState({ volume: Math.max(0, Math.min(1, volume)) }),
            setMuted: (muted: boolean) => setPartialState({ muted }),
            setPlaybackRate: (rate: number) => setPartialState({ playbackRate: Math.max(0.5, Math.min(2, rate)) }),
            seek: (time: number) => {
                if (audio && time >= 0 && time <= state.duration) {
                    audio.currentTime = time;
                    setPartialState({ currentTime: time });
                }
            },
            setLoop: (loop: boolean) => setPartialState({ loop }),
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [state.playing, state.duration, setPartialState]);

    return useMemo(
        () => ({
            ...state,
            ...controls,
        }),
        [state, controls],
    );
};

export default useAudio;
