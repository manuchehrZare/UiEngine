import { useCallback, useEffect, useRef, useState } from 'react';
import type { Now } from '..';
import { getNow } from '..';

/**
 * Hook: useNow
 *
 * Returns a live, real-time breakdown of the current date and time.
 * Uses requestAnimationFrame (not setInterval or setTimeout) to update smoothly.
 *
 * @returns {Now} An object containing year, month, day, hours, minutes, seconds, and milliseconds.
 */
const useNow = (): Now => {
    const [now, setNow] = useState<Now>(getNow());
    const animationFrameRef = useRef<number | null>(null);

    /**
     * Updates the time state and recursively schedules the next animation frame.
     * Wrapped with useCallback to avoid re-creating the function on every render.
     */
    const update = useCallback(() => {
        setNow(getNow());
        // eslint-disable-next-line react-hooks/immutability
        animationFrameRef.current = requestAnimationFrame(update);
    }, []);

    useEffect(() => {
        animationFrameRef.current = requestAnimationFrame(update); // Begin the recursive update loop
        // Cleanup: Cancel the animation frame when the component unmounts
        return () => {
            if (animationFrameRef.current !== null) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, [update]);

    return now;
};

export default useNow;
