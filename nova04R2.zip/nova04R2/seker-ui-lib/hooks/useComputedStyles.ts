import { isEqual } from 'lodash';
import type { RefObject, Ref } from 'react';
import { useState, useRef, useLayoutEffect, useCallback } from 'react';
import type { ComputedStyles } from '..';
import {
    getComputedStyles,
    sharedEventListener,
    sharedIntersectionObserver,
    sharedMutationObserver,
    sharedResizeObserver,
} from '..';

export type UseComputedStylesOptions = {
    /**
     * Optional external dependencies for the effect
     */
    effectDeps?: any[];
};

/**
 * Return type for the `useComputedStyles` hook.
 * @template T - Type of the target HTML element (defaults to HTMLDivElement).
 */
export type UseComputedStylesReturnType<T extends HTMLElement = HTMLDivElement> = {
    /**
     * The actual DOM element instance that the ref is attached to.
     * It will be `null` until the element mounts.
     */
    node: T | null;
    /**
     * A React ref that should be attached to the target DOM element.
     */
    ref: Ref<T> | RefObject<T>;
    /**
     * Computed styles of the referenced element, updated reactively.
     */
    styles: ComputedStyles;
};

/**
 * A custom React hook that observes and returns the computed styles of a DOM element in real-time.
 *
 * It uses a combination of:
 * - `ResizeObserver` for size changes,
 * - `MutationObserver` for DOM mutations,
 * - Media queries and window events for environmental changes. (resize, scroll, reset, matchMedia-change)
 *
 * The hook returns a `ref` to be attached to a DOM element and the latest computed styles for that element.
 *
 * @param options - Contains parameters that will affect Hook's operation.
 * @template T - The type of HTML element being observed (e.g., HTMLDivElement).
 * @returns {UseComputedStylesReturnType<T>} An object containing the ref and up-to-date computed styles.
 */
const useComputedStyles = <T extends HTMLElement = HTMLDivElement>(
    options?: UseComputedStylesOptions,
): UseComputedStylesReturnType<T> => {
    const ref = useRef<T | null>(null); // Internal ref to attach to the target element
    const [styles, setStyles] = useState<ComputedStyles>({} as ComputedStyles); // State to store computed styles
    const animationFrameRef = useRef<number | null>(null); // Reference to store the ID of the requestAnimationFrame
    const prevStylesRef = useRef<ComputedStyles | null>(null);

    // Media Query
    const mediaQuery = window.matchMedia('(min-width: 0px)');

    /**
     * Updates the computed styles and triggers a state change if styles have changed.
     */
    const updateStyles = useCallback(() => {
        if (!ref.current) return;

        const newStyles = getComputedStyles(ref.current);
        // Compare previous styleMap with the new one, and only update if they differ
        if (!isEqual(newStyles, prevStylesRef.current)) {
            prevStylesRef.current = newStyles;
            setStyles(newStyles);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ref.current]);

    // Asynchronous update with requestAnimationFrame
    const rafUpdateStyles = useCallback(() => {
        if (animationFrameRef.current !== null) return;
        // Schedule a new update for the next frame
        animationFrameRef.current = requestAnimationFrame(() => {
            animationFrameRef.current = null;
            updateStyles();
        });
    }, [updateStyles]);

    /**
     * Cancels any pending animation frame requests to avoid unnecessary updates.
     */
    const cancelProcessForAnimationFrame = useCallback(() => {
        if (animationFrameRef.current !== null) {
            cancelAnimationFrame(animationFrameRef.current);
            animationFrameRef.current = null;
        }
    }, []);

    const intersectionCallback = (entry: IntersectionObserverEntry) => {
        entry.isIntersecting && rafUpdateStyles();
    };

    const addListeners = useCallback(() => {
        sharedEventListener.add(mediaQuery, 'change', rafUpdateStyles);
        sharedEventListener.add(window, 'resize', rafUpdateStyles);
        sharedEventListener.add(window, 'scroll', rafUpdateStyles, { capture: false });
        sharedEventListener.add(window, 'reset', rafUpdateStyles);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const removeListeners = useCallback(() => {
        sharedEventListener.remove(mediaQuery, 'change', rafUpdateStyles);
        sharedEventListener.remove(window, 'resize', rafUpdateStyles);
        sharedEventListener.remove(window, 'scroll', rafUpdateStyles);
        sharedEventListener.remove(window, 'reset', rafUpdateStyles);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const setRef = useCallback(
        (node: T | null) => {
            ref.current = node;
            if (node) rafUpdateStyles();
        },
        [rafUpdateStyles],
    );

    useLayoutEffect(() => {
        const element = ref.current;
        // @ts-ignore
        if (!element) return;

        // Observe size changes of the element
        sharedResizeObserver.observe(element, rafUpdateStyles);

        // Observe changes to element's attributes or children (DOM mutations)
        sharedMutationObserver.observe(element, rafUpdateStyles);

        sharedIntersectionObserver.observe(element, intersectionCallback);

        // Listeners
        addListeners();

        // Initial style update when the component mounts
        rafUpdateStyles();

        // Cleanup observers and event listeners on unmount
        return () => {
            sharedResizeObserver.unobserve(element, rafUpdateStyles);
            sharedMutationObserver.unobserve(element, rafUpdateStyles);
            sharedIntersectionObserver.unobserve(element, intersectionCallback);
            removeListeners();
            cancelProcessForAnimationFrame();
            prevStylesRef.current = null;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [...(options?.effectDeps || [])]);

    return { ref: setRef, styles, node: ref.current }; // Return the ref and the styles
};

export default useComputedStyles;
