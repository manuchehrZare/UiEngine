import { useState, useRef, useCallback, useEffect } from 'react';
import type { DeepRequired, Enumerate, PositiveRange, Time, TimeReturnValues } from '..';
import { deepmerge, millisecondsToTime, timeToMilliseconds, useTranslation } from '..';
import { isEmpty, isNaN, isUndefined, omit } from 'lodash';

export enum UseTimerErrorEnum {
    AlreadyStarted = 0,
    AlreadyStopped = 1,
    CountdownValues = 2,
    NegativeValues = 3,
    ReachedLimit = 4,
    PositiveSpeedMultiplier = 5,
    WithoutCountdownValues = 6,
}

export type UseTimerBaseOptions = {
    /**
     * Whether the timer should count down instead of up
     * @default false
     */
    isCountdown?: boolean;
    /**
     * Controls which time units are returned
     * @default all true
     * { hours: true, milliseconds: true, minutes: true, seconds: true }
     */
    returnValues?: TimeReturnValues;
    /**
     * Speed of the timer
     * - 1 = real time
     * - Max: 50
     * @default 1
     */
    speedMultiplier?: PositiveRange<1, 51>; // 1–50
    /**
     * Initial time when the timer starts
     * @default { hours: 0, milliseconds: 0, minutes: 0, seconds: 0 }
     */
    startValues?: Partial<Time>;
    /**
     * Target time at which the timer stops
     * @default { hours: 0, milliseconds: 0, minutes: 0, seconds: 0 }
     */
    stopValues?: Partial<Time>;
};

export type UseTimerError = {
    /**
     * Helper: UseTimerErrorEnum
     */
    code: Enumerate<7>; // 0–6
    message: string;
};

export type UseTimerCallbackOptions = {
    onError?: (error: UseTimerError) => void;
    onReset?: (lastTime: Time, newOptions: DeepRequired<UseTimerBaseOptions>) => void;
    onStart?: (options: UseTimerBaseOptions) => void;
    onStop?: (stoppedTime: Time, options: DeepRequired<UseTimerBaseOptions>) => void;
};

export type UseTimerOptions = UseTimerBaseOptions & UseTimerCallbackOptions;

export type UseTimerReturn = Time & {
    /**
     * Updates the speed multiplier
     */
    changeSpeedMultiplier: (newSpeed: PositiveRange<1, 51>) => void;
    /**
     * When the counter is finished, it becomes true.
     * @default false
     */
    isCompleted: boolean;
    /**
     * Indicates whether the timer is currently running
     */
    isRunning: boolean;
    /**
     * Percentage of progress from start to stop time (0–100)
     */
    progress: number;
    /**
     * In the meter mode, it gives the remaining time in the countdown.
     */
    remainingTime: Time;
    /**
     * Resets the timer with optional new values
     */
    reset: (newOptions?: UseTimerBaseOptions) => void;
    start: () => void;
    stop: () => void;
};

type UseTimerInitialOptions = DeepRequired<UseTimerBaseOptions>;

// Default configuration values for the timer hook
const defaultOptions: UseTimerInitialOptions = {
    isCountdown: false,
    returnValues: { hours: true, milliseconds: true, minutes: true, seconds: true },
    speedMultiplier: 1,
    startValues: { hours: 0, milliseconds: 0, minutes: 0, seconds: 0 },
    stopValues: { hours: 0, milliseconds: 0, minutes: 0, seconds: 0 },
};

/**
 * useTimer React hook for managing a customizable countdown or stopwatch
 * @param options - Configuration options and callbacks for the timer
 * @returns Object containing timer state, controls, and utility functions
 */
const useTimer = (options?: UseTimerOptions): UseTimerReturn => {
    const { t, locale } = useTranslation();
    const initialOptions = deepmerge(defaultOptions, omit(options, ['onError', 'onReset', 'onStart', 'onStop']));
    const optionsRef = useRef(initialOptions);
    const resetNewOptionsRef = useRef<UseTimerBaseOptions | null>(null);
    const { speedMultiplier, startValues, stopValues } = optionsRef.current;

    const startTimeMsRef = useRef(timeToMilliseconds(startValues as Time));
    const stopTimeMsRef = useRef(timeToMilliseconds(stopValues as Time));
    const elapsedMsRef = useRef(startTimeMsRef.current);

    const [currentTimeMs, setCurrentTimeMs] = useState(startTimeMsRef.current);
    const [isRunning, setIsRunning] = useState(false);

    const isRunningRef = useRef(false);
    const isFirstRunningRef = useRef(true);
    const isResettingRef = useRef(false);
    const isCompletedRef = useRef(false);
    const animationFrameRef = useRef<number | null>(null);
    const lastFrameTimeRef = useRef<number | null>(null);
    const speedMultiplierRef = useRef<number>(speedMultiplier);

    // Helper to check if stopValues were defined and not empty
    const hasStopValues = () =>
        !isUndefined(options?.stopValues || resetNewOptionsRef?.current?.stopValues) &&
        !isEmpty(options?.stopValues || resetNewOptionsRef?.current?.stopValues);

    const handleError = (error: UseTimerError) => {
        options?.onError?.(error);
        // eslint-disable-next-line
        console.error(error);
    };

    /**
     * Validates timer boundaries before starting
     * @param startMs - Start time in milliseconds
     * @param stopMs - Stop time in milliseconds
     * @param elapsedMs - Current time in milliseconds
     * @returns Whether the timer configuration is valid
     */
    const isValidTime = (startMs: number, stopMs: number, elapsedMs: number): boolean => {
        if (startMs < 0 || stopMs < 0) {
            handleError({
                code: UseTimerErrorEnum.NegativeValues,
                message: t(locale.labels.useTimerNegativeValuesError),
            });
            return false;
        }

        if (optionsRef.current.isCountdown && startMs <= stopMs) {
            handleError({
                code: UseTimerErrorEnum.CountdownValues,
                message: t(locale.labels.useTimerCountdownError),
            });
            return false;
        }

        if (!optionsRef.current.isCountdown && startMs >= stopMs && hasStopValues()) {
            handleError({
                code: UseTimerErrorEnum.WithoutCountdownValues,
                message: t(locale.labels.useTimerWithoutCountdownValuesError),
            });
            return false;
        }

        if (elapsedMs === stopMs && !isFirstRunningRef.current) {
            handleError({
                code: UseTimerErrorEnum.ReachedLimit,
                message: t(locale.labels.useTimerReachedLimitError),
            });
            return false;
        }
        return true;
    };

    /**
     * Stops the timer and triggers onStop callback
     */
    const stop = useCallback(() => {
        if (!isRunningRef.current) {
            !isResettingRef.current &&
                handleError({
                    code: UseTimerErrorEnum.AlreadyStopped,
                    message: t(locale.labels.useTimerAlreadyStoppedError),
                });
            return;
        }
        isRunningRef.current = false;
        setIsRunning(false);
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
        }
        lastFrameTimeRef.current = null;

        const stoppedTime = millisecondsToTime(elapsedMsRef.current, optionsRef.current.returnValues);
        options?.onStop?.(stoppedTime, optionsRef.current);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [options?.onStop]);

    /**
     * Core update loop using requestAnimationFrame for smooth time tracking
     */
    const updateTimer = useCallback(() => {
        if (!isRunningRef.current || isCompletedRef.current || lastFrameTimeRef.current === null) return;

        const now = performance.now();
        const delta = (now - lastFrameTimeRef.current) * speedMultiplierRef.current;
        lastFrameTimeRef.current = now;

        let newElapsed = optionsRef.current.isCountdown ? elapsedMsRef.current - delta : elapsedMsRef.current + delta;

        const reachedLimit = optionsRef.current.isCountdown
            ? newElapsed <= stopTimeMsRef.current
            : newElapsed >= stopTimeMsRef.current && hasStopValues();

        if (reachedLimit) {
            isCompletedRef.current = true;
            resetNewOptionsRef.current = null;
            newElapsed = stopTimeMsRef.current;
            elapsedMsRef.current = newElapsed;
            setCurrentTimeMs(newElapsed);
            stop();
            return;
        }

        elapsedMsRef.current = newElapsed;
        setCurrentTimeMs(newElapsed);
        animationFrameRef.current = requestAnimationFrame(updateTimer);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [optionsRef.current.isCountdown]);

    /**
     * Starts the timer, validating the input first
     */
    const start = useCallback(() => {
        if (isRunningRef.current) {
            handleError({
                code: UseTimerErrorEnum.AlreadyStarted,
                message: t(locale.labels.useTimerAlreadyStartedError),
            });
            return;
        }

        const startMs = startTimeMsRef.current;
        const stopMs = stopTimeMsRef.current;
        const elapsedMs = elapsedMsRef.current;

        if (isValidTime(startMs, stopMs, elapsedMs)) {
            isRunningRef.current = true;
            isFirstRunningRef.current = false;
            setIsRunning(true);
            lastFrameTimeRef.current = performance.now();
            animationFrameRef.current = requestAnimationFrame(updateTimer);
            options?.onStart?.(optionsRef.current);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [updateTimer, options?.onStart]);

    /**
     * Resets the timer with optional new configuration
     * @param newOptions - Optional new timer values and configuration
     */
    const reset = useCallback(
        (newOptions?: UseTimerBaseOptions) => {
            resetNewOptionsRef.current = newOptions || null;
            isCompletedRef.current = false;
            isResettingRef.current = true;
            stop();
            isFirstRunningRef.current = true;

            const combinedNewOptions = deepmerge(initialOptions, newOptions);

            const startMs = timeToMilliseconds(combinedNewOptions?.startValues as Time);
            const stopMs = timeToMilliseconds(combinedNewOptions?.stopValues as Time);
            const tmpElapsed = elapsedMsRef.current;
            elapsedMsRef.current = startMs;
            const elapsedMs = elapsedMsRef.current;
            const tmpOptions = optionsRef.current;
            optionsRef.current = combinedNewOptions;

            if (isValidTime(startMs, stopMs, elapsedMs)) {
                startTimeMsRef.current = startMs;
                stopTimeMsRef.current = stopMs;
                speedMultiplierRef.current = optionsRef.current.speedMultiplier;

                setCurrentTimeMs(startMs);
                options?.onReset?.(
                    millisecondsToTime(currentTimeMs, optionsRef.current.returnValues),
                    optionsRef.current,
                );
            } else {
                elapsedMsRef.current = tmpElapsed;
                optionsRef.current = tmpOptions;
            }
            isResettingRef.current = false;
        },
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [optionsRef.current.isCountdown, options?.onReset, currentTimeMs, options?.onError],
    );

    /**
     * Dynamically updates the speed of the timer
     * @param newSpeed - New speed multiplier (> 0)
     */
    const changeSpeedMultiplier = useCallback(
        (newSpeed: number) => {
            if (speedMultiplierRef.current !== newSpeed) {
                if (newSpeed <= 0) {
                    handleError({
                        code: UseTimerErrorEnum.PositiveSpeedMultiplier,
                        message: t(locale.labels.useTimerPositiveSpeedMultiplierError),
                    });
                    return;
                }
                speedMultiplierRef.current = newSpeed;
                optionsRef.current = deepmerge(optionsRef.current, { speedMultiplier: newSpeed });
            }
        },
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [options?.onError],
    );

    /**
     * Calculates percentage of elapsed time relative to total time range
     * @returns Progress value from 0 to 100
     */
    const calculateProgress = (): number => {
        const result =
            hasStopValues() || (optionsRef.current.isCountdown && !hasStopValues())
                ? ((currentTimeMs - startTimeMsRef.current) / (stopTimeMsRef.current - startTimeMsRef.current)) * 100
                : 0;
        return Math.min(100, Math.max(0, isNaN(result) ? 0 : result));
    };

    // Cleanup effect to cancel animation when component unmounts
    useEffect(() => {
        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
            isRunningRef.current = false;
            lastFrameTimeRef.current = null;
        };
    }, []);

    return {
        ...millisecondsToTime(currentTimeMs, optionsRef.current.returnValues),
        changeSpeedMultiplier,
        isCompleted: isCompletedRef.current,
        isRunning,
        progress: calculateProgress(),
        remainingTime: millisecondsToTime(
            Math.max(
                0,
                optionsRef.current.isCountdown
                    ? elapsedMsRef.current - stopTimeMsRef.current
                    : stopTimeMsRef.current - elapsedMsRef.current,
            ),
            optionsRef.current.returnValues,
        ),
        reset,
        start,
        stop,
    };
};

export default useTimer;
