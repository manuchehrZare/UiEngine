import type { Control, UseFieldArrayReturn } from 'react-hook-form';
import { useFieldArray } from 'react-hook-form';
export interface IUseArrayFieldProps {
    control: Control;
    key?: any;
    name: any;
}

const useArrayField = ({ control, name, key }: IUseArrayFieldProps): UseFieldArrayReturn => {
    const { fields, append, insert, move, prepend, remove, replace, swap, update } = useFieldArray({
        control,
        name,
        keyName: key,
    });

    return { fields, append, insert, move, prepend, remove, replace, swap, update };
};

export default useArrayField;
