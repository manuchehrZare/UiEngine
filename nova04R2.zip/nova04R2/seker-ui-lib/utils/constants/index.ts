import { classNames } from './classNames';
import { common } from './common';
import { design } from './design';
import { format } from './format';
import { IBANFormats } from './IBAN';
import { key } from './key';

export const constants = { classNames, common, design, format, IBANFormats, key };
