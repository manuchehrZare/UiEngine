import type { FileExtentionsEnum } from '../../../..';
import { mimeTypes } from '../../../..';

/**
 * Returns the result of whether the data is base64.
 * @param data base64 or not base64 string value.
 * @returns true or false
 */
export const isBase64 = (data: string): boolean => {
    if (data && data.length > 0 && data.trim().length > 0) {
        try {
            return btoa(atob(data) || '') === data;
            // eslint-disable-next-line
        } catch (e) {
            return false;
        }
    }
    return false;
};

export const base64ToDataUri = (base64String: string, sourceType: `${FileExtentionsEnum}`): string => {
    // Make sure your Base64 string is clean.
    const cleanBase64 = base64String.replace(/[\s\r\n]+/g, '');

    // If it is already Data URI, return it directly.
    if (cleanBase64.startsWith('data:')) {
        return cleanBase64;
    }

    // Merge in DataURI format.
    return `data:${(mimeTypes as any)[sourceType as keyof typeof FileExtentionsEnum]};base64,${cleanBase64}`;
};

export { base64Decryption } from './_decryption';
export { base64Encryption } from './_encryption';
