import type { CleanOptions } from 'clean-deep';
import cleanDeepProperty from 'clean-deep';
import convert from 'xml-js';
import { constants, FileExtentionsEnum, mimeTypes } from '../../..';

export const cleanDeep = <T>(obj: T, options?: CleanOptions): Partial<T> => {
    return cleanDeepProperty(obj, { NaNValues: true, ...options });
};

export function deepCopy<T>(objectValue: T): T {
    return objectValue ? JSON.parse(JSON.stringify(objectValue)) : objectValue;
}

export const sleep = (delay = 0): any => {
    return new Promise((resolve) => {
        setTimeout(resolve, delay);
    });
};

/**
 * It is the method that returns the only object that matches according to the unique value of a particular key.
 * @param array source array
 * @param value object searched key's value
 * @param key object searched key
 * @param childKey object children key
 * @returns T type object
 */
export const findDeep = <T>(array: T[], value: any, key: string, childKey?: string): T => {
    let o: any = undefined;
    if (childKey && array.some((item: any) => item[childKey] !== undefined)) {
        array.some(function iter(a: any) {
            if (a[key] === value) {
                o = a;
                return true;
            }
            return Array.isArray(a[childKey]) && a[childKey].some(iter);
        });
    } else {
        o = array.find((item: any) => item[key] === value);
    }
    return o;
};

/**
 * This method clears the HTML from the string.
 * @param text string param
 * @returns clean text
 */
export const stripHtmlFromText = (text: string): string => {
    const decodeEntities = (tmpText: string): string => {
        if (typeof document !== 'undefined') {
            // Browser Environment
            const el = document.createElement('textarea');
            el.innerHTML = tmpText;
            return el.value;
        }
        // Node.js Environment
        return tmpText
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&apos;/g, "'")
            .replace(/&amp;/g, '&')
            .replace(/&#39;/g, "'")
            .replace(/&#x2F;/g, '/');
    };
    const decodedText = decodeEntities(text);
    if (typeof document !== 'undefined') {
        // Browser Environment
        const el = document.createElement('div');
        el.innerHTML = decodedText;
        return el.textContent || el.innerText || '';
    }
    // Node.js Environment
    return decodedText.replace(/<\/?[^>]+(>|$)/g, '');
};

export const asyncForEach = async <T>(
    array: T[],
    callback: (item: T, index: number) => Promise<void>,
): Promise<any> => {
    for (let index = 0; index < array.length; index++) {
        await callback(array[index], index);
    }
};

/**
 *  This function determines is string can parse.
 */
export const isParsableToJson = (str: string): boolean => {
    if (typeof str !== 'string') return false;
    try {
        JSON.parse(str);
        // eslint-disable-next-line
    } catch (e) {
        return false;
    }
    return true;
};

export const isDataUri = (text: string): boolean => {
    // Data URI format: data:[<mediatype>][;base64],<data>
    const dataUriPattern = constants.format.regexp.dataUri;

    try {
        if (!text || typeof text !== 'string') {
            return false;
        }

        // Base Format Control
        if (!dataUriPattern.test(text)) {
            return false;
        }

        // Extract the Base64 part and decode it.
        const base64String = text.split(',')[1];

        // Base64 decode control
        return btoa(atob(base64String)) === base64String;
    } catch {
        return false;
    }
};

/**
 * Returns boolen after string check completed for xml.
 * @param xmlString Given string for xml string check.
 * @returns boolean after check complete, if the given string is xml, then the function returns true.
 */
export const isXmlString = (xmlString: string): boolean => {
    // string xml veya htmli DOM document olarak parse eder
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlString, (mimeTypes as any)[FileExtentionsEnum.XML]);

    // parse edilen döküman hatalı şekilde parse edildiyse tespit edilir
    const parserError = doc.getElementsByTagName('parsererror').length > 0;

    // hata olup olmadığı kontrol edilir ve elimizdeki string xml <?xml ile mi başlıyor bakılır, tüm koşullar sağlandıysa true döner
    return !parserError && xmlString.trim().startsWith('<?xml');
};

export const xmlToJs = (data: string, options?: convert.Options.XML2JS): convert.Element | convert.ElementCompact => {
    return convert.xml2js(data, { compact: true, ...options });
};

/**
 * Convert JSON format or JS Object to XML Format
 */
export const jsToXml = (data: string | object, options?: convert.Options.JS2XML): string => {
    // Parse JSON if the input is a JSON string, otherwise use the input as is
    const jsObject = typeof data === 'string' && isParsableToJson(data) ? JSON.parse(data) : data;
    try {
        return convert.js2xml(jsObject, {
            compact: true,
            ...options,
        });
    } catch (error) {
        // eslint-disable-next-line
        console.error('Error in XML conversion:', error);
        throw new Error('Error in XML conversion');
    }
};
