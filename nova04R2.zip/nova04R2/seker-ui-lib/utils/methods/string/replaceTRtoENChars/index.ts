import { isString } from 'lodash';

export type ReplaceTRtoEnCharsConfig = {
    joinSeperator?: '-' | '_' | ' ' | '' | '.';
};

/**
 * Replaces Turkish characters in the text to English characters.
 * @param str Text value to replace Turkish characters.
 * @param config control values that can be applied to the text.
 * @returns Returns the edited text value.
 */
export const replaceTRtoENChars = (str: string | string[], config?: ReplaceTRtoEnCharsConfig): string => {
    const localeStrArray: string[] = [];
    let resultStr = '';
    if (str.length > 0) {
        const trMap: any = {
            ç: 'c',
            Ç: 'C',
            ğ: 'g',
            Ğ: 'G',
            ş: 's',
            Ş: 'S',
            ü: 'u',
            Ü: 'U',
            ı: 'i',
            İ: 'I',
            ö: 'o',
            Ö: 'O',
        };

        const replaceChars = (strItem: string): string => {
            if (strItem && strItem.length > 0) {
                for (const key in trMap) {
                    strItem = strItem?.replace(new RegExp(`[${key}]`, 'g'), trMap[key]);
                }
            }
            return strItem;
        };

        if (isString(str)) {
            resultStr = replaceChars(str);
        } else {
            str.forEach((strItem) => {
                localeStrArray.push(replaceChars(strItem));
            });
            resultStr = localeStrArray.join(' ');
        }

        if (config) {
            if (isString(config?.joinSeperator)) {
                resultStr = resultStr.replace(/\s+/gi, config?.joinSeperator);
            }
        }
        return resultStr;
    }
    return resultStr;
};
