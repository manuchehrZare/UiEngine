type RandomNumberOptions = {
    precision?: number;
};
// Function type definition: generates a number between min and max, with optional settings
type RandomNumberType = (min: number, max: number, options?: RandomNumberOptions) => number;

/**
 * Generates a cryptographically secure random number.
 *
 * - Returns a number between `min` and `max` (inclusive).
 * - If `precision` is 0 or not provided, it returns an integer.
 * - If `precision` > 0, it returns a floating-point number with the specified number of decimal places.
 * - Uses `window.crypto.getRandomValues()` for secure randomness.
 *
 * @param min - Minimum value (inclusive)
 * @param max - Maximum value (inclusive)
 * @param options - Optional settings (e.g., `precision`)
 * @returns A secure random number between `min` and `max`
 */
export const randomNumber: RandomNumberType = (min, max, options = { precision: 0 }) => {
    if (min > max) {
        throw new Error('min value cannot be greater than max');
    }
    const range = max - min;
    if (options?.precision === 0) {
        const rangeInt = Math.floor(range) + 1;
        const randomBuffer = new Uint32Array(1);
        window.crypto.getRandomValues(randomBuffer);
        const rndNumber = randomBuffer[0] % rangeInt;
        return min + rndNumber;
    }
    // Ondalıklı sayı üretmek için 32-bit rastgele sayıyı [0,1) aralığına ölçeklendiriyoruz
    const randomBuffer = new Uint32Array(1);
    window.crypto.getRandomValues(randomBuffer);
    const random01 = randomBuffer[0] / (0xffffffff + 1); // 0xFFFFFFFF = 2^32 - 1
    const result = min + random01 * range;
    return Number(result.toFixed(options?.precision));
};
