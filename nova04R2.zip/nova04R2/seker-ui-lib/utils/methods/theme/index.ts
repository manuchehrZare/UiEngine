import type { Theme } from '@mui/material';
import { constants } from '../../constants';
import { getSessionStorageItem, removeSessionStorageItem, setSessionStorageItem } from '../storage';

// Daha spesifik tip tanımları
type ThemeValue = string | number | Record<string, unknown>;
type ThemeFunction = (props: { theme: Theme }) => Record<string, ThemeValue>;

const functionToString = (fn: ThemeFunction): string => {
    try {
        // Execute the function with a mock theme to get the style object
        const styleObject = fn({ theme: {} as Theme });
        return JSON.stringify(styleObject);
    } catch {
        return '{}';
    }
};

const stringToFunction = (str: string): ThemeFunction => {
    // Remove the @@Function: prefix if present
    const cleanStr = str.replace('@@Function:', '');
    // Create a safe function using closure
    return () => {
        // Parse the function body as a JSON object
        try {
            const styleObject = JSON.parse(cleanStr);
            return typeof styleObject === 'object' ? styleObject : {};
        } catch {
            return {};
        }
    };
};

// theme cache management
const THEME_CACHE = new Map<string, ThemeFunction>();

export const setProviderTheme = (theme: Partial<Theme>): void => {
    try {
        const serializedTheme = JSON.stringify(theme, (_, value) => {
            if (typeof value === 'function') {
                const fnString = functionToString(value as ThemeFunction);
                const cacheKey = `theme_fn_${fnString}`;
                THEME_CACHE.set(cacheKey, value as ThemeFunction);
                return `@@Function:${cacheKey}`;
            }
            return value;
        });

        setSessionStorageItem(constants.key.PROVIDER_THEME, serializedTheme);
    } catch (error) {
        // eslint-disable-next-line
        console.error('Failed to save theme:', error);
    }
};

export const getProviderTheme = (theme?: Partial<Theme> | null): Partial<Theme> | null => {
    try {
        // If no theme provided, get from sessionStorage
        let localTheme: Partial<Theme> | string | null = theme || getSessionStorageItem(constants.key.PROVIDER_THEME);
        // If theme is an object, convert it to string
        if (localTheme && typeof localTheme === 'object') {
            localTheme = JSON.stringify(localTheme);
        }
        if (!localTheme) return null;

        if (typeof localTheme === 'string') {
            return JSON.parse(localTheme, (_, value) => {
                if (typeof value === 'string' && value.startsWith('@@Function:')) {
                    const cacheKey = value.slice(11);
                    const cachedFn = THEME_CACHE.get(cacheKey);
                    if (cachedFn) return cachedFn;

                    return stringToFunction(value.slice(11));
                }
                return value;
            });
        }
        return localTheme;
    } catch (error) {
        // eslint-disable-next-line
        console.error('Failed to load theme:', error);
        return null;
    }
};

export const removeProviderTheme = (): void => {
    return removeSessionStorageItem(constants.key.PROVIDER_THEME);
};
