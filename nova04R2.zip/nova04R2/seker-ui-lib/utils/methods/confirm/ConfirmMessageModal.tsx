import { confirmable } from 'react-confirm';
import { ConfirmModal, useTranslation } from '../../..';
import type { IConfirmModalProps } from '../../../components/Display/Confirm/type';

export interface IConfirmMessageModalProps extends Omit<IConfirmModalProps, 'onConfirm'> {
    proceed: any;
}

// eslint-disable-next-line react-refresh/only-export-components
const ConfirmMessageModal = ({
    show,
    proceed,
    cancelText,
    okText,
    body,
    title,
    actionProps,
    ...rest
}: IConfirmMessageModalProps) => {
    const { t, locale } = useTranslation();

    return (
        <ConfirmModal
            show={show}
            title={title || t(locale.contents.warning)}
            body={body || t(locale.contents.areYouSureYouWantToContinueWithThisProcess)}
            actionProps={{
                cancelProps: {
                    color: 'error',
                    variant: 'outlined',
                },
                ...actionProps,
            }}
            cancelText={cancelText || t(locale.buttons.no)}
            okText={okText || t(locale.buttons.yes)}
            onConfirm={(status) => {
                if (status) {
                    proceed(true);
                } else {
                    proceed(false);
                }
            }}
            {...rest}
        />
    );
};

// eslint-disable-next-line react-refresh/only-export-components
export default confirmable(ConfirmMessageModal);
