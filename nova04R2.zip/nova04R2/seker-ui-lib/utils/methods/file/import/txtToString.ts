import { uniq } from 'lodash';
import { i18n, locale } from '../../../locales';
import { FileAcceptValues, FileTypes } from '../type';

export interface IOption {
    accept?: 'txt'[];
}

interface ILocalOptions extends Required<Pick<IOption, 'accept'>>, Omit<IOption, 'accept'> {}

export const txtToString = (file: File): Promise<string> => {
    // Initial Options
    const localOptions: ILocalOptions = {
        accept: FileAcceptValues.TXT,
    };
    const errorInformations = {
        fileType: { code: 0, description: i18n.t(locale.contents.invalidFileType) },
    };

    // Generate Accept <-> FileTypes control for valid file type
    const getActiveFileTypes = (): string[] => {
        const arr: string[] = [];
        localOptions.accept.forEach((item: string) => {
            let key: string = '';
            Object.values(FileAcceptValues).forEach((a, index) => {
                if (a.includes(item)) {
                    key = Object.keys(FileAcceptValues)[index];
                    return;
                }
            });
            key !== '' && arr.push(...FileTypes[key as keyof typeof FileAcceptValues]);
        });
        return uniq(arr);
    };
    return new Promise((resolve, reject) => {
        if (getActiveFileTypes().includes(file.type)) {
            let text: any = '';
            const fileReader = new FileReader();
            fileReader.onloadend = (e) => {
                text = e?.target?.result;
                // Return
                resolve(text);
            };
            fileReader.onerror = reject;
            fileReader.readAsText(file);
        } else {
            reject(errorInformations.fileType);
        }
    });
};
