import type { Components } from '@mui/material';
import { paginationItemClasses } from '../../..';

export const MuiPaginationTheme: Components = {
    MuiPagination: {
        styleOverrides: {
            root: () => ({
                padding: '2px',
                marginLeft: 'auto',
                fontSize: 'var(--field-font-size)',
                [`.${paginationItemClasses.root}`]: {
                    borderRadius: '4px',
                },
            }),
        },
    },
};
