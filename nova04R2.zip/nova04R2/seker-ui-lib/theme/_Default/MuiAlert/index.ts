import type { Components, Theme } from '@mui/material';
import { alertClasses } from '@mui/material';

export const MuiAlertTheme: Components = {
    MuiAlert: {
        styleOverrides: {
            root: {},
            icon: ({ theme, ownerState }) => ({
                padding: '8px 0',
                fontSize: 'calc(var(--field-label-font-size) + 6px) !important',

                [`.${alertClasses.outlined} &`]: {
                    ...(ownerState.severity === 'primary' && {
                        color: (theme as Theme).palette.secondary.main,
                    }),
                },
            }),
            message: {
                fontSize: 'var(--field-label-font-size)',
            },
            action: {
                marginRight: 0,
                fontSize: 'var(--field-label-font-size)',
            },
            filled: ({ theme }) => ({
                color: (theme as Theme).palette.common.white,
            }),
            outlinedError: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.error.light,
            }),
            outlinedInfo: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.info.light,
            }),
            outlinedSuccess: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.success.light,
            }),
            outlinedWarning: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.warning.light,
            }),
            standardError: ({ theme }) => ({
                color: (theme as Theme).palette.error.dark,
            }),
            standardInfo: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
            standardSuccess: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
            standardWarning: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
        },
    },
    MuiAlertTitle: {
        styleOverrides: {
            root: ({ theme }) => ({
                margin: 0,
                fontSize: 'var(--field-label-font-size)',
                fontWeight: 600,

                [`.${alertClasses.filled} &`]: {
                    color: (theme as Theme).palette.common.white,
                },
            }),
        },
    },
};
