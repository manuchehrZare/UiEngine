import type { Components, Theme } from '@mui/material';
import { alertClasses } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiAlertTheme: Components = {
    MuiAlert: {
        styleOverrides: {
            root: ({ theme }) => ({
                padding: `${(theme as Theme).spacing(0.5)} ${(theme as Theme).spacing(1)}`,
                boxShadow: '1px 3px 4px 0 var(--shadow-1)',
            }),
            icon: ({ theme, ownerState }) => ({
                marginRight: (theme as Theme).spacing(1),
                padding: `${(theme as Theme).spacing(0.5)} ${(theme as Theme).spacing(0)}`,
                fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) + 6px) !important`,

                [`.${alertClasses.outlined} &`]: {
                    ...(ownerState.severity === 'primary' && {
                        color: (theme as Theme).palette.secondary.main,
                    }),
                },
            }),
            message: ({ theme }) => ({
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                padding: `${(theme as Theme).spacing(0.5)} ${(theme as Theme).spacing(0)}`,
            }),
            action: {
                marginRight: 0,
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
            },
            filled: ({ theme }) => ({
                color: (theme as Theme).palette.common.white,
            }),
            outlinedError: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.error.light,
            }),
            outlinedInfo: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.info.light,
            }),
            outlinedSuccess: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.success.light,
            }),
            outlinedWarning: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
                borderColor: (theme as Theme).palette.warning.light,
            }),
            standardError: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
            standardInfo: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
            standardSuccess: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
            standardWarning: ({ theme }) => ({
                color: (theme as Theme).palette.common.black,
            }),
        },
    },
    MuiAlertTitle: {
        styleOverrides: {
            root: ({ theme }) => ({
                margin: 0,
                fontSize: `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                fontWeight: 600,

                [`.${alertClasses.filled} &`]: {
                    color: (theme as Theme).palette.common.white,
                },
            }),
        },
    },
};
