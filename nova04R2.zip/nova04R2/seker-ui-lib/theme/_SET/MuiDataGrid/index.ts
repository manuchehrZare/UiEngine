import type { Components, Theme } from '@mui/material';
import { autocompleteClasses, inputBaseClasses } from '@mui/material';
import type {} from '@mui/x-data-grid-pro/themeAugmentation';
import { checkboxClasses, dataGridClasses, tablePaginationClasses } from '../../..';
import { DesignTypeEnum } from '../../../utils/types/common';
import { palette } from '../../_palette';
import { importantStyle } from '../../../utils/methods/style';
import { generateClass } from '../../../utils/methods/design';

const themeConfig = {
    common: {
        color: palette.common?.black,
        border: {
            color: palette.slateGreen[50],
            radius: 4,
            width: 1,
            style: 'solid',
        },
    },
    seperator: {
        border: {
            color: palette.common?.white,
            width: 2,
            style: 'solid',
        },
    },
    header: {
        backgroundColor: palette.slateGreen[100],
        fontWeight: 600,
        fontSize: `calc(var(--field-label-font-size-${DesignTypeEnum.SET}) - 1px)`,
    },
    cell: {
        fontWeight: 400,
        checkbox: { height: '14px', width: '14px' },
    },
    row: {
        default: {
            backgroundColor: palette.grey[50],
        },
        selected: {
            backgroundColor: palette.green[50],
        },
        hover: {
            backgroundColor: palette.grey[400],
        },
    },
    strippedRows: {
        even: {
            backgroundColor: palette.slateGreen[50],
        },
        selected: {
            backgroundColor: palette.green[50],
        },
        hover: {
            backgroundColor: palette.grey[400],
        },
    },
    footer: {
        borderColor: '',
    },
};

export const MuiDataGridTheme: Components = {
    MuiDataGrid: {
        styleOverrides: {
            root: ({ ownerState }) => ({
                borderRadius: themeConfig.common.border.radius,
                border: `${themeConfig.common.border.width}px ${themeConfig.common.border.style}`,
                ...(!ownerState?.slots?.toolbar && { borderTop: 'none' }),
                borderColor: themeConfig.common.border.color,
                minHeight: '100%',
                color: themeConfig.common.color,
                [`.${dataGridClasses.scrollbarFiller}`]: {
                    backgroundColor: themeConfig.header.backgroundColor,
                    border: importantStyle('none'),
                },
                [`.${dataGridClasses.filler}`]: {
                    display: 'none',
                },
                [`.${dataGridClasses.main}`]: {
                    [`.${dataGridClasses.virtualScroller}`]: {
                        [`&.${dataGridClasses['virtualScroller--hasScrollX']}`]: {
                            paddingBottom: 'var(--DataGrid-scrollbarSize)',
                        },
                    },
                },
                '&.strippedRows': {
                    [`.${dataGridClasses.row}`]: {
                        ':nth-of-type(even)': {
                            backgroundColor: themeConfig.strippedRows.even.backgroundColor,
                        },
                        ':hover': {
                            backgroundColor: importantStyle(themeConfig.strippedRows.hover.backgroundColor || ''),
                            [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                                backgroundColor: 'inherit',
                            },
                            [`.${dataGridClasses['cell--pinnedRight']}`]: {
                                backgroundColor: 'inherit',
                            },
                        },
                        '&.Mui-selected, &.Mui-selected:hover': {
                            backgroundColor: themeConfig.strippedRows.selected.backgroundColor,
                            [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                                backgroundColor: 'inherit',
                            },
                            [`.${dataGridClasses['cell--pinnedRight']}`]: {
                                backgroundColor: 'inherit',
                            },
                        },
                    },
                },

                '&.disableMultipleRowSelection': {
                    [`.${dataGridClasses.columnHeaderCheckbox} .${dataGridClasses.columnHeaderTitleContainer}`]: {
                        display: importantStyle('none'),
                    },
                },

                [`&.${DesignTypeEnum.SET}`]: {
                    fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,

                    '.MuiLinearProgress-root': {
                        height: 2,
                    },

                    '.MuiSvgIcon-root': {
                        fontSize: `calc(var(--field-font-size-${DesignTypeEnum.SET}) + 3px)`,
                    },
                },

                '.MuiBadge-badge': { top: '-7px', height: '15px', minWidth: '15px' },

                '.MuiButtonBase-root': { paddingTop: '3px', paddingBottom: '3px' },

                '.MuiSvgIcon-root': {
                    position: 'initial',
                },
            }),

            columnSeparator: () => ({
                visibility: 'visible',
                backgroundColor: themeConfig.seperator.border.color,
                width: themeConfig.seperator.border.width,
                right: 0,

                svg: {
                    display: 'none',
                },
                ':before': {
                    content: '""',
                    position: 'absolute',
                    width: themeConfig.seperator.border.width,
                    height: '100%',
                    backgroundColor: themeConfig.seperator.border.color,
                },
                [`&.${dataGridClasses['columnSeparator--sideLeft']}`]: {
                    ':before': {
                        left: 12,
                    },
                },
                [`&.${dataGridClasses['columnSeparator--sideRight']}`]: {
                    ':before': {
                        right: 12,
                    },
                },
            }),
            columnHeaders: {
                [`[role="row"]`]: {
                    [`.${dataGridClasses.filler}`]: {
                        display: 'block',
                        backgroundColor: themeConfig.header.backgroundColor,
                    },
                },
            },
            columnHeader: {
                backgroundColor: themeConfig.header.backgroundColor,
                border: importantStyle('none'),
                fontWeight: themeConfig.header.fontWeight,
                [`&.${dataGridClasses['columnHeader--last']}`]: {
                    [`.${dataGridClasses['columnSeparator--sideRight']}`]: {
                        display: 'none',
                    },
                    [`.${dataGridClasses['columnSeparator--sideLeft']}`]: {
                        display: 'none',
                    },
                },

                [`&.${dataGridClasses['columnHeader--pinnedLeft']},`]: {
                    [`.${dataGridClasses['columnSeparator--sideLeft']},${dataGridClasses['columnSeparator--sideRight']}`]:
                        {
                            opacity: importantStyle('1'),
                            right: 0,
                            ':before': {
                                left: 12,
                            },
                        },
                    [`.${dataGridClasses['columnSeparator--sideRight']}`]: {
                        opacity: importantStyle('1'),
                        right: 0,
                        ':before': {
                            right: importantStyle('0'),
                        },
                    },
                },

                [`&.${dataGridClasses['columnHeader--pinnedRight']}`]: {
                    [`.${dataGridClasses['columnSeparator--sideLeft']}`]: {
                        opacity: importantStyle('1'),
                        left: 0,
                        ':before': {
                            left: 12,
                        },
                    },
                    [`.${dataGridClasses['columnSeparator--sideRight']}`]: {
                        opacity: importantStyle('1'),
                        right: 0,
                        ':before': {
                            right: importantStyle('0'),
                        },
                    },
                },

                [`&.${dataGridClasses['columnHeader--alignLeft']}`]: {
                    [`.${dataGridClasses.menuIcon}`]: {
                        marginRight: '-6px',
                    },
                },
                [`&.${dataGridClasses['columnHeader--alignRight']}`]: {
                    [`.${dataGridClasses.menuIcon}`]: {
                        marginLeft: '-8px',
                    },
                },
            },
            menuIcon: {
                marginRight: -6,
            },
            columnHeaderTitle: {
                fontWeight: themeConfig.header.fontWeight,
                [`.${DesignTypeEnum.SET} &`]: {
                    fontSize: themeConfig.header.fontSize,
                },
            },
            row: () => ({
                backgroundColor: themeConfig.row.default.backgroundColor,
                ':hover': {
                    backgroundColor: themeConfig.row.hover.backgroundColor,
                },
                '&.Mui-selected, &.Mui-selected:hover': {
                    backgroundColor: themeConfig.row.selected.backgroundColor,
                    [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                        backgroundColor: themeConfig.strippedRows.selected.backgroundColor,
                    },
                    [`.${dataGridClasses['cell--pinnedRight']}`]: {
                        backgroundColor: themeConfig.strippedRows.selected.backgroundColor,
                    },
                },

                [`.${dataGridClasses['cell--pinnedLeft']}`]: {
                    backgroundColor: 'inherit',
                    border: 'none',
                    borderRight: importantStyle(
                        `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                    ),

                    boxShadow: '2px 0px 4px -2px rgba(0, 0, 0, 0.21)',
                    [`[role="gridcell"]`]: {
                        border: 'none',
                        borderRight: importantStyle(
                            `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                        ),
                    },
                },
                [`.${dataGridClasses['cell--pinnedRight']}`]: {
                    backgroundColor: 'inherit',
                    border: 'none',
                    borderRight: importantStyle(
                        `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                    ),
                    boxShadow: '-2px 0px 4px -2px rgba(0, 0, 0, 0.21)',
                    [`[role="gridcell"]`]: {
                        border: 'none',
                        borderLeft: importantStyle(
                            `${themeConfig.seperator.border.width}px ${themeConfig.seperator.border.style} ${themeConfig.seperator.border.color} `,
                        ),
                    },
                },
                '.MuiDataGrid-cellEmpty': {
                    border: 'none',
                },
            }),
            cell: ({ ownerState, theme }) => {
                const getColumnsLength = (): number => {
                    let result = ownerState?.columns?.length || 0;
                    result -= result - (ownerState?.apiRef?.current?.getVisibleColumns().length || 0);

                    return result;
                };

                return {
                    borderTop: 0,
                    borderBottom: 0,
                    borderWidth: themeConfig.seperator.border.width,
                    borderColor: themeConfig.seperator.border.color,
                    borderRightStyle: 'solid',
                    display: 'flex',
                    alignItems: 'center',

                    [`&[role="gridcell"]:nth-of-type(${getColumnsLength() + 1})`]: {
                        border: 'none',
                    },
                    '&--textCenter': {
                        [`.MuiFormControl-root`]: {
                            alignItems: 'center',
                            justifContent: 'center',
                            display: 'flex',
                        },
                    },
                    [`.${checkboxClasses.root}`]: {
                        [`&.${checkboxClasses.checked}`]: {
                            color: (theme as Theme).palette.secondary.main,
                        },
                    },
                    [`&.${dataGridClasses.cellCheckbox}`]: {
                        [`.${checkboxClasses.root}`]: {
                            svg: {
                                width: themeConfig.cell.checkbox.width,
                                height: themeConfig.cell.checkbox.height,
                            },
                        },
                    },
                    [`.${generateClass('checkbox')}`]: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: importantStyle('100%'),
                        svg: {
                            width: themeConfig.cell.checkbox.width,
                            height: themeConfig.cell.checkbox.height,
                            color: (theme as Theme).palette.primary.main,
                        },
                        '&.checked': {
                            svg: { color: (theme as Theme).palette.secondary.main },
                        },
                    },
                    [`.${autocompleteClasses.root}`]: {
                        [`.${inputBaseClasses.root}`]: { marginBottom: '20px' },
                    },

                    fontWeight: themeConfig.cell.fontWeight,
                    color: themeConfig.common.color,

                    [`.${DesignTypeEnum.SET} &`]: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                    },
                };
            },
            footerContainer: () => ({
                [`&.${DesignTypeEnum.SET}`]: {
                    fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                    borderColor: themeConfig.common.border.color,

                    [`& .${tablePaginationClasses.root}`]: {
                        display: 'flex',
                        overflow: 'hidden',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        [`.${tablePaginationClasses.spacer}`]: {
                            display: 'none',
                        },
                        [`.${tablePaginationClasses.displayedRows}`]: {
                            fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        },
                        '.MuiTablePagination-selectLabel': {
                            fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        },

                        '.MuiInputBase-root': {
                            padding: 0,
                            fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        },
                        [`.${tablePaginationClasses.actions}`]: {
                            '.MuiButtonBase-root': {
                                '.MuiSvgIcon-root': {
                                    fontSize: `calc(var(--field-font-size-${DesignTypeEnum.SET}) * 1.5)`,
                                },
                            },
                        },
                    },
                },
            }),
            menu: () => ({
                [`&.${DesignTypeEnum.SET}`]: {
                    '.MuiList-root': {
                        '.MuiMenuItem-root': {
                            fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                            color: themeConfig.common.color,
                        },
                    },
                },
                '.MuiMenuItem-root': {
                    paddingTop: '3px',
                    paddingBottom: '3px',
                    '.MuiSvgIcon-root': {
                        fontSize: `calc(var(--field-font-size-${DesignTypeEnum.SET}) + 3)`,
                    },
                    '.MuiTypography-root': {
                        fontSize: `calc(var(--field-font-size-${DesignTypeEnum.SET}) + 3)`,
                    },
                },
            }),
            paper: {
                minWidth: 200,
            },
            panelHeader: () => ({
                [`.${DesignTypeEnum.SET} &`]: {
                    label: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        color: themeConfig.common.color,
                    },
                    input: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        color: themeConfig.common.color,
                    },
                },
            }),
            panel: {
                '.MuiDataGrid-filterForm > *': { width: 'auto', paddingRight: '5px', paddingLeft: '5px' },
                '.MuiInputBase-root': { marginTop: '0' },
                '.MuiFormLabel-root': { width: 'auto' },
                '.MuiNativeSelect-select': { width: '50px' },
                '.MuiInput-underline': { paddingRight: '20px' },
                '.MuiBadge-badge': { top: '-7px', height: '15px', minWidth: '15px' },
                '.MuiInput-root:before': {
                    borderBottom: 'none',
                },
                '.MuiInput-root:after': {
                    borderBottom: 'none',
                },
                '.MuiInput-root:hover:not(.Mui-disabled, .Mui-error):before': {
                    borderBottom: 'none',
                },
                '.MuiOutlinedInput-root': {
                    padding: '0 !important',
                },
                '.Mui-disabled:before': {
                    borderBottomStyle: 'none !important',
                },
            },
            panelContent: () => ({
                [`.${DesignTypeEnum.SET} &`]: {
                    span: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        color: themeConfig.common.color,
                    },
                },
            }),
            panelFooter: {
                [`.${DesignTypeEnum.SET} &`]: {
                    '.MuiButton-root ': {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                    },
                },
            },
            filterForm: () => ({
                [`.${DesignTypeEnum.SET} &`]: {
                    label: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        color: themeConfig.common.color,
                    },
                    input: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        color: themeConfig.common.color,
                    },
                    select: {
                        fontSize: `var(--field-font-size-${DesignTypeEnum.SET})`,
                        color: themeConfig.common.color,
                    },
                },
            }),
            pinnedColumns: {
                [`&.${dataGridClasses.pinnedColumns}`]: { backgroundColor: 'transparent' },
            },
        },
    },
};
