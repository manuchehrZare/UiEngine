import type { Components } from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';

export const MuiIconButtonTheme: Components = {
    MuiIconButton: {
        styleOverrides: {
            root: {
                borderRadius: 0,
                height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 2px)`,
                width: `var(--field-height-${DesignTypeEnum.SET})`,
                minWidth: `var(--field-height-${DesignTypeEnum.SET})`,

                '& svg': {
                    height: `calc(var(--field-height-${DesignTypeEnum.SET}) - 6px) !important`,
                    width: `calc(var(--field-height-${DesignTypeEnum.SET}) - 6px) !important`,
                },

                '&.select': {
                    // For Select Component
                    marginRight: `calc((var(--field-height-${DesignTypeEnum.SET}) / 5) * 3)`,
                },
            },
        },
    },
};
