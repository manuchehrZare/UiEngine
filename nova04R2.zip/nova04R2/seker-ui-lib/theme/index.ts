import { createTheme } from '@mui/material';
import { trTR as coreTrTR } from '@mui/material/locale';
import { trTR as dataGridTrTR } from '@mui/x-data-grid-pro/locales';
import { trTR as pickersTrTR } from '@mui/x-date-pickers';
import { MuiAppbarTheme } from './MuiAppbar';
import { MuiAvatarTheme } from './MuiAvatar';
import { MuiBottomNavTheme } from './MuiBottomNav';
import { MuiCollapseTheme } from './MuiCollapse';
import { MuiMasonryTheme } from './MuiMasonry';
import { MuiPopoverTheme } from './MuiPopover';
import { MuiProgressTheme } from './MuiProgress';
import { MuiTableTheme } from './MuiTable';
import { MuiTypographyTheme } from './MuiTypography';
import { palette } from './_palette';
import { Mui_CssBaseline } from './MuiCssBaseLine';
import { GlobalFont } from './_css_global';
import type { HTMLAttributes } from 'react';

declare module '@mui/material' {
    interface AlertPropsColorOverrides {
        primary: true;
    }
    interface BreakpointOverrides {
        xxl: true;
    }
    interface FormControlPropsSizeOverrides {
        large: true;
    }
    interface ChipPropsVariantOverrides {
        standard: true;
    }
    interface ChipOwnProps {
        cornered?: boolean;
        leftCornered?: boolean;
        rightCornered?: boolean;
    }

    interface ChipClasses {
        cornered?: string;
        corneredLeft?: string;
        corneredRight?: string;
    }
    interface InputHTMLAttributes<T> extends HTMLAttributes<T> {
        webkitdirectory?: string;
    }
}

const theme = createTheme(
    {
        palette: {
            ...palette,
        },
        spacing: 8,
        typography: {
            fontFamily: GlobalFont,
        },
        breakpoints: {
            values: {
                xs: 0, // MUI-default
                sm: 600, // MUI-default
                md: 900, // MUI-default
                lg: 1200, // MUI-default
                xl: 1536, // MUI-default
                xxl: 1800, // Custom
            },
        },
        components: {
            ...Mui_CssBaseline,
            ...MuiAppbarTheme,
            ...MuiAvatarTheme,
            ...MuiBottomNavTheme,
            ...MuiCollapseTheme,
            ...MuiMasonryTheme,
            ...MuiPopoverTheme,
            ...MuiProgressTheme,
            ...MuiTableTheme,
            ...MuiTypographyTheme,
        },
    },
    dataGridTrTR,
    pickersTrTR,
    coreTrTR,
);

export { theme };
