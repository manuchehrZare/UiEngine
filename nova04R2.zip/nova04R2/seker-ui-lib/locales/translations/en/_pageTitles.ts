export default {
    home: 'Home',
    notFound: 'Page Not Found!',
    auth: {
        login: 'Login',
    },
};
