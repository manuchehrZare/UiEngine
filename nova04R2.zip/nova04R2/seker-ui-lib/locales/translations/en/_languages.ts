export default {
    en: 'English',
    tr: 'Türkçe',
};
