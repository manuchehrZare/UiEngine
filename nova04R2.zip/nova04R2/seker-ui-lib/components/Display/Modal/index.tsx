import type { FC } from 'react';
import { forwardRef, memo, useEffect, useRef, useState } from 'react';
import type { PaperProps, Theme } from '@mui/material';
import { Dialog, IconButton, Paper } from '@mui/material';
import type { IModalProps, ModalCloseReasonType } from './type';
import { ModalCloseReasonEnum } from './type';
import { CloseRounded as CloseRoundedIcon, OpenWith as OpenWithIcon } from '@mui/icons-material';
import ThemeProvider from '../../App/ThemeProvider';
import { manageClassNames, useIsFirstRender, useStorage, View } from '../../..';
import Draggable from 'react-draggable';
import type { DesignType } from '../../../utils';
import { constants, generateClass, getComponentDesignProperty, getProviderTheme, useTranslation } from '../../../utils';

const Modal: FC<IModalProps> = forwardRef(
    (
        {
            onBackdropClick,
            onClose,
            show,
            children,
            closeIcon = true,
            design,
            draggable = false,
            className,
            fullWidth = false,
            fullScreen = false,
            fullHeight = false,
            maxWidth = false,
            disableEscapeKeyDown = true,
            disableBackdropClick = true,
            scroll = 'paper',
            allowClose = true,
            loading = false,
            ...rest
        }: IModalProps,
        ref,
    ) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        const [isShow, setIsShow] = useState<boolean>(show || false);
        const isFirstRender = useIsFirstRender();
        const { t, locale } = useTranslation();

        /* istanbul ignore next */
        const handleClose = (reason: ModalCloseReasonType) => {
            if (
                allowClose &&
                (reason === ModalCloseReasonEnum.CloseIconClick ||
                    (reason === ModalCloseReasonEnum.EscapeKeyDown && !disableEscapeKeyDown) ||
                    (reason === ModalCloseReasonEnum.BackdropClick && !disableBackdropClick))
            ) {
                setIsShow(false);
            }
            reason === ModalCloseReasonEnum.BackdropClick && onBackdropClick?.();
        };

        const DraggablePaper = (props: PaperProps) => {
            const draggableRef = useRef(null);
            return (
                <Draggable
                    handle="#draggable-dialog-button"
                    cancel={'[class*="MuiDialogContent-root"]'}
                    bounds="body"
                    nodeRef={draggableRef}>
                    <Paper {...props} ref={draggableRef} />
                </Draggable>
            );
        };

        useEffect(() => {
            !isFirstRender && !show && isShow && onClose?.();
            setIsShow(show);
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [show]);

        useEffect(() => {
            !isFirstRender && show && !isShow && onClose?.();
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [isShow]);

        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <Dialog
                    className={manageClassNames(
                        generateClass('Modal'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                        className,
                    )}
                    ref={ref}
                    PaperProps={{
                        className: manageClassNames(
                            generateClass('Modal-Paper'),
                            getComponentDesignProperty(design, storageDesign.newValue),
                            {
                                'close-icon': closeIcon,
                                'drag-icon': draggable && closeIcon,
                                'confirm-icon': draggable && !closeIcon,
                                fullHeight: fullHeight,
                            },
                        ),
                    }}
                    fullWidth={maxWidth ? true : fullWidth || false}
                    fullScreen={fullScreen}
                    maxWidth={maxWidth}
                    open={isShow}
                    scroll={scroll}
                    onClose={
                        /* istanbul ignore next */ (_, reason) => {
                            handleClose(reason);
                        }
                    }
                    disableEnforceFocus
                    disableEscapeKeyDown={disableEscapeKeyDown}
                    {...(draggable && { PaperComponent: DraggablePaper })}
                    {...rest}>
                    <View show={closeIcon}>
                        <IconButton
                            disabled={loading}
                            className="custom modal-close-icon"
                            onClick={() => handleClose(ModalCloseReasonEnum.CloseIconClick)}>
                            <CloseRoundedIcon />
                        </IconButton>
                    </View>
                    <View show={draggable}>
                        <IconButton
                            disabled={loading}
                            className={manageClassNames({
                                'custom modal-drag-icon': closeIcon,
                                'custom confirm-drag-icon': !closeIcon,
                            })}
                            title={t(locale.labels.holdAndDrag)}
                            id="draggable-dialog-button">
                            <OpenWithIcon />
                        </IconButton>
                    </View>
                    {children}
                </Dialog>
            </ThemeProvider>
        );
    },
);

export default memo(Modal);
