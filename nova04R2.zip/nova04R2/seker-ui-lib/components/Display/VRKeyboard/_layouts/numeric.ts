import type { KeyboardLayoutObject } from 'react-simple-keyboard';

export const numeric: KeyboardLayoutObject = {
    default: ['1 2 3', '4 5 6', '7 8 9', ', 0 -', '{clear} {bksp}'],
};
