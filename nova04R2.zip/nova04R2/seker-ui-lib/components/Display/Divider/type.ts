import type { DividerProps } from '@mui/material';
import type { Ref, RefObject } from 'react';
import type { ICommonProps } from '../../../utils/types/common';

export interface IDividerProps
    extends
        ICommonProps,
        Pick<
            DividerProps,
            'absolute' | 'children' | 'className' | 'flexItem' | 'id' | 'orientation' | 'sx' | 'textAlign' | 'variant'
        > {
    ref?: Ref<any> | RefObject<any>;
}
