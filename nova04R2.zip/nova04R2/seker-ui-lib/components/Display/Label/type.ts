import type { TypographyProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
import type { IBoxProps } from '../../..';

export interface ILabelProps
    extends
        ICommonProps,
        Pick<IBoxProps, 'className' | 'id' | 'sx' | 'ref'>,
        Pick<TypographyProps, 'color' | 'fontSize' | 'fontWeight'> {
    align?: 'left' | 'center' | 'right';
    text: string;
}
