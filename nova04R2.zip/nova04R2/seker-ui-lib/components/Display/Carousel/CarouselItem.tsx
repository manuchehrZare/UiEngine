import type { FC } from 'react';
import type { ICarouselItemProps } from './type';
import { MuiCarouselItemSxProps } from './style';
import { generateClass, manageClassNames } from '../../../utils';
import { Box } from '../../..';

const CarouselItem: FC<ICarouselItemProps> = ({ contentPosition = 'top-start', image, content, sx }) => {
    return (
        <Box
            className={manageClassNames(generateClass('CarouselItem'))}
            sx={{
                ...(MuiCarouselItemSxProps({ contentPosition, image }) as any),
                ...sx,
            }}>
            {image && <Box className={generateClass('CarouselItem-image')} />}
            <Box className={generateClass('CarouselItem-content')}>{content}</Box>
        </Box>
    );
};

export default CarouselItem;
