import type { TabProps, TabsProps } from '@mui/material';
import type { ReactNode } from 'react';
import type { ICommonProps } from '../../../utils/types/common';

export interface ITabProps
    extends ICommonProps, Pick<TabsProps, 'children' | 'className' | 'orientation' | 'variant' | 'sx' | 'ref'> {
    onChange?: (val: any) => void;
    small?: boolean;
    value: string | number;
}

export interface ITabItemProps extends Pick<TabProps, 'disabled' | 'disableFocusRipple' | 'value' | 'className'> {
    text: ReactNode;
}
