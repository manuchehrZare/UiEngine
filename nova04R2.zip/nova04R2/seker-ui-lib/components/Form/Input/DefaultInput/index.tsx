import { KeyboardCapslock, Visibility, VisibilityOff } from '@mui/icons-material';
import { InputAdornment, TextField } from '@mui/material';
import { isBoolean, isUndefined, omit } from 'lodash';
import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { useController } from 'react-hook-form';
import useCapsLockDetector from '../../../../hooks/useCapsLockDetector';
import { DesignTypeEnum, generateClass, manageClassNames, useTranslation } from '../../../../utils';
import Button from '../../Button/Button';
import TextMaskCustom from '../MaskInput';
import type { ICapslockDetectorProps, IInputProps } from '../type';
import Tooltip from '../../../Display/Tooltip';

const Input: FC<IInputProps> = ({
    name,
    control,
    helperText,
    autoComplete,
    startAdornment,
    endAdornment,
    maxLength,
    minLength,
    fullWidth,
    readOnly,
    type,
    mask,
    variant,
    size,
    label,
    required,
    maskLazy,
    accept,
    placeholder,
    maskChar,
    deps,
    passwordVisibility,
    capslockDetector,
    className,
    ...rest
}: IInputProps) => {
    const { t, locale } = useTranslation();
    const [maskView, setMaskView] = useState<boolean>(true);
    const [isFocused, setIsFocused] = useState<boolean>(false);
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const {
        field: { ref, ...field },
        fieldState: { error, isDirty, isTouched },
        formState: { isSubmitted },
    } = useController({ name, control, rules: { deps } });

    const showCapslockStatus =
        capslockDetector &&
        Boolean(rest?.inputRef) &&
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useCapsLockDetector(rest?.inputRef as React.RefObject<HTMLInputElement | HTMLTextAreaElement>);

    const validationControl = isSubmitted || isDirty || isTouched || Boolean(field?.value);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const renderMaskInput = () => {
        if (mask) {
            return {
                inputComponent: TextMaskCustom as any,
                inputProps: {
                    mask,
                    lazy: field.value && !isFocused ? false : maskView,
                    placeholderChar: maskChar,
                },
            };
        }

        return {};
    };

    const getLabel = () => {
        return label ? (required ? `${label} *` : label) : '';
    };

    useEffect(() => {
        isBoolean(showCapslockStatus) &&
            !isBoolean(capslockDetector) &&
            capslockDetector?.onCapslockDetector?.(
                showCapslockStatus,
                capslockDetector?.Tooltip?.title || t(locale.labels.capsLockActive),
            );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [showCapslockStatus]);

    return (
        <TextField
            {...field}
            inputRef={ref}
            variant={variant}
            autoComplete={autoComplete}
            fullWidth={fullWidth}
            label={getLabel()}
            spellCheck={false}
            error={Boolean(error) && validationControl}
            size={size}
            helperText={(validationControl && error?.message) || helperText}
            placeholder={placeholder}
            InputLabelProps={{
                className: `${manageClassNames(
                    generateClass('Mui-InputBase-Capslock'),
                    { [`capslockDetector`]: capslockDetector },
                    className,
                )}`,
                title: typeof getLabel() === 'string' ? `${getLabel()}` : '',
                ...(mask && {
                    shrink:
                        placeholder && (!field.value || field.value) && isFocused
                            ? true
                            : field.value && !isFocused
                              ? true
                              : !maskView,
                }),
            }}
            onChange={
                /* istanbul ignore next */ (e: any) => {
                    const maskReplace: string = mask?.replace(/[a0_*.,-]/g, maskChar).replace(/[/{/}]/g, '');
                    const value = e.target?.value;
                    field.onChange(value);
                    if (placeholder && isUndefined(maskLazy) && value === maskReplace) {
                        setMaskView(true);
                    } else if (placeholder && isUndefined(maskLazy) && value.length && value !== maskReplace) {
                        setMaskView(false);
                    } else if (placeholder && isUndefined(maskLazy) && !field.value) {
                        setMaskView(false);
                    }
                }
            }
            onFocus={
                /* istanbul ignore next */ () => {
                    setIsFocused(true);
                    if (!placeholder && isUndefined(maskLazy)) {
                        setMaskView(false);
                    }
                }
            }
            onBlur={
                /* istanbul ignore next */ () => {
                    const maskReplace: string = mask?.replace(/[a0_*.,-]/g, maskChar).replace(/[/{/}]/g, '');
                    setIsFocused(false);
                    if (
                        (!placeholder || placeholder) &&
                        isUndefined(maskLazy) &&
                        (!field.value || field.value === maskReplace)
                    ) {
                        setMaskView(true);
                        field.onChange('');
                    }
                }
            }
            InputProps={{
                ...(startAdornment
                    ? {
                          startAdornment: <InputAdornment position="start">{startAdornment}</InputAdornment>,
                      }
                    : {}),
                ...(endAdornment || passwordVisibility || capslockDetector
                    ? {
                          endAdornment:
                              type === 'password' || capslockDetector ? (
                                  <InputAdornment position="end">
                                      {type === 'password' && passwordVisibility && (
                                          <Button
                                              iconButton
                                              rounded
                                              variant="text"
                                              color="primary"
                                              icon={showPassword ? <VisibilityOff /> : <Visibility />}
                                              onMouseDown={(e) => e.preventDefault()}
                                              onClick={handleClickShowPassword}
                                              {...(!endAdornment && { sx: { mr: -0.75 } })}
                                          />
                                      )}
                                      {showCapslockStatus && (
                                          <Tooltip
                                              show
                                              title={t(locale.labels.capsLockActive)}
                                              placement="bottom-end"
                                              {...(capslockDetector as ICapslockDetectorProps)?.Tooltip}
                                              className={manageClassNames(
                                                  generateClass('Detector-Tooltip'),
                                                  DesignTypeEnum.Default,
                                              )}
                                              design={DesignTypeEnum.Default}>
                                              <KeyboardCapslock
                                                  color="primary"
                                                  onMouseDown={(e) => e.preventDefault()}
                                              />
                                          </Tooltip>
                                      )}
                                      {endAdornment}
                                  </InputAdornment>
                              ) : (
                                  <InputAdornment position="end">{endAdornment}</InputAdornment>
                              ),
                      }
                    : {}),
                readOnly,
                type: String(type),
                componentsProps: {
                    input: { accept: accept?.map(/* istanbul ignore next */ (a) => `.${a}`)?.join(',') },
                },
                ...renderMaskInput(),
                label,
                ...(capslockDetector
                    ? {
                          className: `${manageClassNames(generateClass('Mui-InputBase-Capslock'), {
                              [`capslockDetector`]: capslockDetector,
                          })}`,
                      }
                    : {}),
            }}
            inputProps={{
                type: type === 'password' ? (showPassword ? undefined : 'password') : String(type),
                maxLength,
                minLength,
            }}
            {...omit(rest, ['labelPlacement', 'labelWidth', 'labelEllipsis'])}
        />
    );
};

export default Input;
