import type { SelectProps } from '@mui/material';
import type { UseFormReturnType } from '../../../hooks/useForm';
import type { ICommonFieldProps } from '../commonTypes';
import type { ReactElement, ReactNode } from 'react';

export interface ISelectOptions<T> {
    data: T[];
    dataFormatter?: (data: T[]) => T[];
    displayField: keyof T;
    displayValue: keyof T;
    renderDisplayField?: (params: T) => ReactNode;
    renderDisplayList?: (params: T) => ReactElement | string;
}

export interface INativeSelectProps {
    row?: number;
}

export interface IBaseSelectProps<T>
    extends
        Pick<
            SelectProps,
            | 'autoWidth'
            | 'children'
            | 'className'
            | 'disabled'
            | 'displayEmpty'
            | 'inputRef'
            | 'label'
            | 'native'
            | 'onBlur'
            | 'onClose'
            | 'onFocus'
            | 'onKeyDown'
            | 'onKeyUp'
            | 'onOpen'
            | 'open'
            | 'required'
            | 'sx'
        >,
        Omit<ICommonFieldProps, 'endAdornment'>,
        Required<Pick<UseFormReturnType<any>, 'setValue'>> {
    disabledItems?: any[];
    displayEmptyValue?: string;
    hiddenItems?: any[];
    multiple?: number | boolean;
    nativeProps?: INativeSelectProps;
    onChange?: (id: any) => void;
    options: ISelectOptions<T>;
}

// For single selection
interface ISingleSelectOptions<T> extends ISelectOptions<T> {
    renderDisplayField?: (params: T) => ReactNode;
}

// For multiple selection
interface IMultipleSelectOptions<T> extends ISelectOptions<T> {
    renderDisplayField?: (params: T) => string;
}

interface ISingleSelectProps<T> extends Omit<IBaseSelectProps<T>, 'options'> {
    multiple?: false;
    options: ISingleSelectOptions<T>;
}

interface IMultipleSelectProps<T> extends Omit<IBaseSelectProps<T>, 'options'> {
    multiple?: true | number;
    options: IMultipleSelectOptions<T>;
}

export type ISelectProps<T> = ISingleSelectProps<T> | IMultipleSelectProps<T>;
