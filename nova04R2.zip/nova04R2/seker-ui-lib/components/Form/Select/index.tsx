import Default from './DefaultSelect';
import SET from './SETSelect';
import type { ISelectProps } from './type';
import ThemeProvider from '../../App/ThemeProvider';
import type { ComponentDesignType } from '../commonTypes';
import type { DesignType } from '../../..';
import { DesignTypeEnum, constants, useStorage } from '../../..';
import { getComponentDesignProperty, getProviderTheme } from '../../../utils';
import type { Theme } from '@mui/material';

const Select = <T,>({
    design,
    disabled = false,
    displayEmpty = true,
    fullWidth = true,
    hidden = false,
    labelPlacement = 'top',
    labelEllipsis = true,
    readOnly = false,
    required = false,
    size = 'medium',
    variant = 'outlined',
    ...rest
    // eslint-disable-next-line
}: ISelectProps<T>) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const Component: ComponentDesignType = {
        [DesignTypeEnum.Default]: (
            <Default<T>
                variant={variant}
                disabled={disabled}
                displayEmpty={displayEmpty}
                fullWidth={fullWidth}
                hidden={hidden}
                labelPlacement={labelPlacement}
                labelEllipsis={labelEllipsis}
                readOnly={readOnly}
                required={required}
                size={size}
                {...rest}
            />
        ),
        [DesignTypeEnum.SET]: (
            <SET<T>
                variant={variant}
                disabled={disabled}
                displayEmpty={displayEmpty}
                fullWidth={fullWidth}
                hidden={hidden}
                labelPlacement={labelPlacement}
                labelEllipsis={labelEllipsis}
                readOnly={readOnly}
                required={required}
                size={size}
                {...rest}
            />
        ),
    };
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            {Component[getComponentDesignProperty(design, storageDesign.newValue)]}
        </ThemeProvider>
    );
};

export default Select;
