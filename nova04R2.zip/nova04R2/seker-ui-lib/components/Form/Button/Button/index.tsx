import type { Theme } from '@mui/material';
import { Button as MuiButton, CircularProgress } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IButtonProps } from '../type';
import ThemeProvider from '../../../App/ThemeProvider';
import type { DesignType } from '../../../../utils';
import { constants, generateClass, getComponentDesignProperty, manageClassNames } from '../../../../utils';
import { useStorage } from '../../../..';
import { getProviderTheme } from '../../../../utils/methods/theme';

const Button: FC<IButtonProps> = forwardRef(
    (
        {
            id,
            name,
            className,
            iconLeft,
            iconRight,
            icon,
            iconButton,
            text,
            loading = false,
            color = 'secondary',
            variant = 'contained',
            rounded = false,
            leftRounded = false,
            rightRounded = false,
            design,
            ...rest
        }: IButtonProps,
        ref,
    ) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <MuiButton
                    ref={ref}
                    id={id}
                    name={name}
                    className={manageClassNames(generateClass('Button'), className, design, color, {
                        'btn-no-text': Boolean(icon),
                        'icon-button': iconButton,
                        rounded: rounded,
                        'left-rounded': leftRounded,
                        'right-rounded': rightRounded,
                    })}
                    endIcon={!loading && iconRight}
                    startIcon={!loading && iconLeft}
                    variant={variant}
                    disableRipple
                    color={color}
                    disableElevation
                    {...rest}>
                    {loading ? <CircularProgress className="btn-loading" /> : icon || text}
                </MuiButton>
            </ThemeProvider>
        );
    },
);

export default Button;
