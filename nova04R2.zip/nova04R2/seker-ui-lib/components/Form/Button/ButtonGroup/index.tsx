import type { FC } from 'react';
import { memo } from 'react';
import { ButtonGroup as MuiButtonGroup } from '@mui/material';
import type { IButtonGroupProps } from '../type';

const ButtonGroup: FC<IButtonGroupProps> = ({ children, ...rest }: IButtonGroupProps) => {
    return <MuiButtonGroup {...rest}>{children}</MuiButtonGroup>;
};

export default memo(ButtonGroup);
