import buttons from './_buttons';
import common from './common';
import contentTitles from './_contentTitles';
import labels from './_labels';
import languages from './_languages';
import notifications from './_notifications';
import pageTitles from './_pageTitles';

export default {
    buttons,
    common,
    contentTitles,
    labels,
    languages,
    notifications,
    pageTitles,
};
