export default {
    tr: 'Türkçe',
    en: 'English',
};
