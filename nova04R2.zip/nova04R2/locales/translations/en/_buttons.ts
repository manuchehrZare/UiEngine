export default {
    backHomePage: 'Back to Home Page',
    backMenuList: 'Back to $t(pageTitles:menuList)',
    close: 'Close',
    copy: 'Copy',
    exit: 'Exit',
    login: '$t(pageTitles:auth.login)',
    no: 'No',
    open: 'Open',
    openScreen: '$t(buttons:open) Screen',
    reportError: 'Report Error',
    yes: 'Yes',
};
