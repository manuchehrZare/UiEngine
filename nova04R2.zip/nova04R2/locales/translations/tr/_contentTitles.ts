export default {
    settings: {
        console: 'Konsol',
        log: 'Log',
    },
};
