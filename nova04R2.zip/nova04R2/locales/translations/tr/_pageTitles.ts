export default {
    auth: {
        login: 'Giriş',
    },
    favourites: 'Favoriler',
    menu: 'Menü',
    menuList: 'Menü Listesi',
    notFound: 'Sayfa Bulunamadı!',
    notifications: 'Bildirimler',
    settings: 'Ayarlar',
};
