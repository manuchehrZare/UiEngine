export default {
    openDetailLog: 'Detay Logu Aç',
    openSignalRConsole: 'SignalR Konsolu Aç',
    search: 'Arama',
};
