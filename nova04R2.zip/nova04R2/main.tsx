import './polyfills';
import App from './App';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Provider as StoreProvider } from 'react-redux';
import { store } from './_store';
import { createRoot } from 'react-dom/client';
import { i18nInitialize } from './locales/i18n';
import { isWebview, shellListener } from './set-lib';
import { handleShellListenerCallback } from './utils';

const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            refetchOnMount: false,
            refetchOnWindowFocus: false,
            gcTime: 1000 * 60 * 60 * 24,
            retry: false, // when it gets an error it runs the request again.
        },
    },
});

const renderAsync = async () => {
    isWebview() && shellListener(handleShellListenerCallback);
    await i18nInitialize();
    createRoot(document.getElementById('root')!).render(
        <StoreProvider store={store}>
            <QueryClientProvider client={queryClient}>
                <App />
                <ReactQueryDevtools initialIsOpen={false} buttonPosition="bottom-left" />
            </QueryClientProvider>
        </StoreProvider>,
    );
};

renderAsync();
