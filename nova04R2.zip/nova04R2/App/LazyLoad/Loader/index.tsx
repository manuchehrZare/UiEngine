import { Suspense, type JSX } from 'react';
import { LoadingModal } from '../../../seker-ui-lib';
import type { ChildrenLoaderProps, ComponentLoaderProps } from './type';

const ComponentLoader = ({ component: Component, componentProps, fallback }: ComponentLoaderProps) => {
    // eslint-disable-next-line
    return () => (
        <Suspense fallback={fallback ?? <LoadingModal />}>
            <Component {...(componentProps ?? {})} />
        </Suspense>
    );
};

const ChildrenLoader = ({ children, fallback }: ChildrenLoaderProps): JSX.Element => {
    return <Suspense fallback={fallback ?? <LoadingModal />}>{children}</Suspense>;
};

const Load = {
    Component: ComponentLoader,
    Children: ChildrenLoader,
};

export { Load };
