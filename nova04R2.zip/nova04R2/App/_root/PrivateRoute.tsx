import { Navigate, Outlet } from 'react-router-dom';
import { getSessionStorageItem, useStorage } from '../../seker-ui-lib';
import { isWebview } from '../../set-lib';
import { constants } from '../../utils';
import type { AuthStoreData } from '../../_store/slices/auth';
import type { QueryStore } from '../../_store/slices/query';
import type { RouteItem } from './routes';
import { routes } from './routes';

type PrivateRouteProps = {
    children?: RouteItem['element'];
    outlet?: true;
};

const PrivateRoute = ({ children, outlet }: PrivateRouteProps): any => {
    const authStorageValue = useStorage<AuthStoreData>({ key: constants.key.SET_AUTH, source: 'session' });
    const queryStorageValue = getSessionStorageItem<QueryStore>(constants.key.SET_QUERY);

    return authStorageValue.newValue || isWebview() ? (
        outlet ? (
            <Outlet />
        ) : (
            children
        )
    ) : (
        <Navigate
            to={`${routes.auth.login.path}${
                queryStorageValue?.ref ? `${constants.key.LINK_REF}${queryStorageValue.ref}` : ''
            }`}
        />
    );
};

export default PrivateRoute;
