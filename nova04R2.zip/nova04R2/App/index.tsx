import '@fontsource/source-sans-pro';
import { isEmpty } from 'lodash';
import { type FC, type JSX, useEffect } from 'react';
import { getSessionStorageItem, queryStringToJSON, theme } from '../seker-ui-lib';
import { type ProcessEnvType, SETProvider, isWebview } from '../set-lib';
import { constants, resetAuthData, setAuthData } from '../utils';
import { dispatch, store, useSelector } from '../_store';
import { type AppStore, appValue, initialAppStoreValue, resetStoreApp, setStoreApp } from '../_store/slices/app';
import { type AuthStoreData, authValue, initialAuthStoreValue } from '../_store/slices/auth';
import {
    initialQueryStoreValue,
    type QueryStore,
    queryValue,
    resetStoreQuery,
    setStoreQuery,
} from '../_store/slices/query';
import Root from './_root';
import { RouteItemTypeEnum, routes } from './_root/routes';
import {
    type ScreenStore,
    initialScreenStoreValue,
    resetStoreScreen,
    screenValue,
    setStoreScreen,
} from '../_store/slices/screen';

const App: FC = (): JSX.Element => {
    const authStoreValue = useSelector(authValue);
    const appStoreValue = useSelector(appValue);
    const queryStoreValue = useSelector(queryValue);
    const screenStoreValue = useSelector(screenValue);
    const authStorageValue = getSessionStorageItem<AuthStoreData>(constants.key.SET_AUTH);
    const appStorageValue = getSessionStorageItem<AppStore>(constants.key.SET_APP);
    const queryStorageValue = getSessionStorageItem<QueryStore>(constants.key.SET_QUERY);
    const screenStorageValue = getSessionStorageItem<ScreenStore>(constants.key.SET_SCREEN);

    const queryParamsControl = () => {
        const queryParams: any = queryStringToJSON(window.location.search);
        if (!isEmpty(queryParams)) {
            const refKey = constants.key.LINK_REF.replace(constants.format.regexp.symbol, '');
            queryParams[refKey] && dispatch(setStoreQuery({ ref: queryParams[refKey] }));
        } else dispatch(resetStoreQuery());
    };

    useEffect(() => {
        if (authStorageValue) {
            authStoreValue.data !== authStorageValue && setAuthData(authStorageValue);
        } else authStoreValue !== initialAuthStoreValue && resetAuthData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (appStorageValue) {
            appStoreValue !== appStorageValue && dispatch(setStoreApp(appStorageValue));
        } else appStoreValue !== initialAppStoreValue && dispatch(resetStoreApp());
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (!isWebview()) {
            if (queryStorageValue) {
                queryStoreValue !== queryStorageValue && dispatch(setStoreQuery(queryStorageValue));
            } else queryStoreValue !== initialQueryStoreValue && dispatch(resetStoreQuery());
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (screenStorageValue) {
            screenStoreValue !== screenStorageValue && dispatch(setStoreScreen(screenStorageValue));
        } else screenStoreValue !== initialScreenStoreValue && dispatch(resetStoreScreen());
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        /**
         * For Shell Wrapper
         * * WebView OR Web
         */
        dispatch(setStoreApp({ ...store.getState().app, isNova: isWebview() }));
        /** End - For Shell Wrapper */
        // Removed queryClient.clear() - let React Query handle cache naturally
    }, []);

    useEffect(() => {
        !isWebview() && queryParamsControl();
    }, []);

    return (
        <SETProvider
            projectProps={{
                env: import.meta.env.VITE_APP_ENV as ProcessEnvType,
                routeProps: { paths: { home: routes.home.path, login: routes.auth.login.path } },
                serviceProps: {
                    baseURL: import.meta.env.VITE_APP_BASE_URL,
                },
            }}
            globalStyles={{ body: { backgroundColor: theme.palette.common.white } }}>
            <Root />
        </SETProvider>
    );
};
export { default as Layout, Footer, Header, Sidebar } from './Layout';
export type { LayoutMeasures, initialLayoutMeasure } from './Layout/type';
// eslint-disable-next-line react-refresh/only-export-components
export { RouteItemTypeEnum, routes };
export default App;
