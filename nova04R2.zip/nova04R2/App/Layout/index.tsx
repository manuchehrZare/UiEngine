/* eslint-disable */
import { Box, CustomScrollbar, useMeasure, useTitle, View } from '../../seker-ui-lib';
import type { FC, JSX } from 'react';
import { memo, useCallback, useEffect, useRef } from 'react';
import Sidebar from './Sidebar';
import Footer from './Footer';
import Header from './Header';
import { useSelector } from '../../_store';
import { ReactComponent as Logo } from '../../assets/images/logo_mini_lightgrey.svg';
import { authValue } from '../../_store/slices/auth';
import { constants } from '../../utils';
import type { LayoutProps } from './type';

const Layout: FC<LayoutProps> = ({
    children,
    title,
    sx,
    onMeasureChange,
    onContentScrollChange,
    showFooter = true,
    showHeader = true,
    showSidebar = true,
}): JSX.Element => {
    const sidebarMeasure = useMeasure();
    const headerMeasure = useMeasure();
    const footerMeasure = useMeasure();
    const contentMeasure = useMeasure();
    const authStoreValue = useSelector(authValue);
    const measureTimeoutRef = useRef<number | null>(null);

    const debouncedMeasureChange = useCallback(
        (measures: any) => {
            if (measureTimeoutRef.current !== null) {
                clearTimeout(measureTimeoutRef.current);
            }

            measureTimeoutRef.current = window.setTimeout(() => {
                onMeasureChange?.(measures);
                measureTimeoutRef.current = null;
            }, 50); // 50ms debounce
        },
        [onMeasureChange],
    );

    useEffect(() => {
        debouncedMeasureChange({
            content: contentMeasure.values,
            footer: footerMeasure.values || constants.common.layout.FOOTER_HEIGHT,
            header: headerMeasure.values || constants.common.layout.HEADER_HEIGHT,
            sidebar: sidebarMeasure.values || constants.common.layout.SIDEBAR_WIDTH,
        });
         
    }, [sidebarMeasure.values, footerMeasure.values, headerMeasure.values, contentMeasure.values, debouncedMeasureChange]);

    useEffect(() => {
        return () => {
            if (measureTimeoutRef.current !== null) {
                clearTimeout(measureTimeoutRef.current);
            }
        };
    }, []);

    useTitle(`${import.meta.env.VITE_APP_TITLE}${title ? ` | ${title}` : ''}`);
    return (
        <>
            <View show={showHeader}>
                <Header ref={headerMeasure.ref} />
            </View>
            <View show={showSidebar}>
                <Sidebar
                    ref={sidebarMeasure.ref}
                    layoutMeasures={{
                        content: contentMeasure.values,
                        footer: footerMeasure.values || constants.common.layout.FOOTER_HEIGHT,
                        header: headerMeasure.values || constants.common.layout.HEADER_HEIGHT,
                        sidebar: sidebarMeasure.values || constants.common.layout.SIDEBAR_WIDTH,
                    }}
                />
            </View>
            <Box
                ref={contentMeasure.ref}
                className="content"
                component="div"
                sx={{
                    position: 'relative',
                    ...(sidebarMeasure?.node && {
                        width: `calc(100% - ${sidebarMeasure.values.width || constants.common.layout.SIDEBAR_WIDTH}px)`,
                        left: sidebarMeasure.values.width || constants.common.layout.SIDEBAR_WIDTH,
                    }),
                    ...(headerMeasure?.node && {
                        top: headerMeasure.values.height || constants.common.layout.HEADER_HEIGHT,
                    }),
                    backgroundColor: (theme) => theme.palette.common.white,
                    ...sx,
                }}>
                <View show={Boolean(authStoreValue.loggedIn && authStoreValue.data)}>
                    <Box
                        width={{ xs: '40%', md: 'auto' }}
                        sx={{
                            position: 'fixed',
                            left: `calc(50% + ${constants.common.layout.SIDEBAR_WIDTH / 2}px)`,
                            top: '50%',
                            translate: '-50% -50%',
                            zIndex: 0,
                        }}>
                        <Logo width="100%" />
                    </Box>
                </View>
                <CustomScrollbar
                    className="content-scroll"
                    thickness={0}
                    onUpdate={(values) => {
                        onContentScrollChange && onContentScrollChange(values);
                    }}
                    viewProps={{
                        sx: {
                            ...((showFooter || showHeader || showSidebar) && {
                                px: constants.design.padding.common.unit,
                            }),
                        },
                    }}
                    height={
                        headerMeasure?.node && footerMeasure?.node
                            ? `calc(100vh - ${(headerMeasure?.values?.height ?? constants.common.layout.HEADER_HEIGHT) + (footerMeasure?.values?.height ?? constants.common.layout.FOOTER_HEIGHT)}px)`
                            : '100vh'
                    }>
                    {children}
                </CustomScrollbar>
            </Box>
            <View show={showFooter}>
                <Footer ref={footerMeasure.ref} />
            </View>
        </>
    );
};

export { Footer, Header, Sidebar };
export default memo(Layout);
