import type { FC, JSX } from 'react';
import { forwardRef, Fragment, memo } from 'react';
import type { IBoxProps } from '../../../seker-ui-lib';
import { Box, Divider, Grid, GridItem, View } from '../../../seker-ui-lib';
import { getGlobalsData, GlobalsItemEnum } from '../../../set-lib';
import { constants } from '../../../utils';
import { useSelector } from '../../../_store';
import { appValue } from '../../../_store/slices/app';
import { authValue } from '../../../_store/slices/auth';
import { v4 as uuidv4 } from 'uuid';
import Clock from './Clock';

interface IFooterProps extends Pick<IBoxProps, 'ref'> {}

const Footer: FC<IFooterProps> = forwardRef((props: IFooterProps, ref): JSX.Element => {
    const authStoreValue = useSelector(authValue);
    const appStoreValue = useSelector(appValue);
    const footerGlobalKeys = [
        GlobalsItemEnum.ChargedOrgUnitCode,
        GlobalsItemEnum.Version,
        GlobalsItemEnum.UserName,
        GlobalsItemEnum.OrganizationCode,
        GlobalsItemEnum.UserFullName,
        GlobalsItemEnum.EnvironmentType,
    ];

    return (
        <Box
            ref={ref}
            component="footer"
            position="fixed"
            display="flex"
            alignItems="center"
            px={2}
            bottom={0}
            width="100%"
            height={constants.common.layout.FOOTER_HEIGHT}
            bgcolor={(theme) => theme.palette.secondary.main}
            sx={{ color: (theme) => theme.palette.common.white }}
            zIndex={(theme) => theme.zIndex.appBar}
            {...props}>
            <View show={Boolean(authStoreValue.loggedIn && authStoreValue.data)}>
                <Grid spacing={0.75} width="100%">
                    {footerGlobalKeys.map((footerGlobalKey, index) => {
                        return (
                            <Fragment key={uuidv4()}>
                                <View
                                    show={
                                        !(footerGlobalKey === GlobalsItemEnum.Version && !appStoreValue?.app?.version)
                                    }>
                                    <GridItem xs={false}>
                                        {footerGlobalKey === GlobalsItemEnum.Version
                                            ? appStoreValue?.app?.version || ''
                                            : getGlobalsData({ key: footerGlobalKey })}
                                    </GridItem>
                                </View>
                                <View
                                    show={Boolean(
                                        index !== footerGlobalKeys.length - 1 &&
                                        !(footerGlobalKey === GlobalsItemEnum.Version && !appStoreValue?.app?.version),
                                    )}>
                                    <GridItem xs={false}>
                                        <Divider orientation="vertical" />
                                    </GridItem>
                                </View>
                            </Fragment>
                        );
                    })}
                    <GridItem xs={false} ml="auto">
                        <Clock />
                    </GridItem>
                </Grid>
            </View>
        </Box>
    );
});

export default memo(Footer);
