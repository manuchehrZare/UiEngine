import { format } from 'date-fns';
import { memo } from 'react';
import { pickerProps, useNow } from '../../../seker-ui-lib';

const Clock = memo(() => {
    const { days, hours, milliseconds, minutes, months, seconds, years } = useNow();
    const formattedNow = format(
        new Date(years, months, days, hours, minutes, seconds, milliseconds),
        pickerProps.SET.dateTimePicker.inputFormat.replace(':ss', ''),
    );
    return formattedNow;
});

Clock.displayName = 'Clock';
export default Clock;
