import type { FC, JSX } from 'react';
import { useEffect, useState } from 'react';
import { Grid, GridItem, Label, View, base64Decryption, importantStyle } from '../../seker-ui-lib';
import type { AxiosError, IFavouritesItem, IGetFavouritesRequest, IGetFavouritesResponse } from '../../set-lib';
import { axiosFetcher, QueryKeyEnum } from '../../set-lib';
import { api } from '../../api/endpoints';
import { Layout } from '../../App';
import { GridTitle, Menu } from '../../components';
import { ScreenNameEnum, navigateScreen, useTranslation } from '../../utils';
import { useSelector } from '../../_store';
import { authValue } from '../../_store/slices/auth';
import { useQuery } from '@tanstack/react-query';

const Favourites: FC = (): JSX.Element => {
    const { t, locale } = useTranslation();
    const authStoreValue = useSelector(authValue);
    const [favourites, setFavourites] = useState<IFavouritesItem[]>([]);

    const getFavouritesQuery = useQuery<IGetFavouritesResponse, AxiosError>({
        enabled: authStoreValue.loggedIn,
        queryKey: [QueryKeyEnum.GET_FAVOURITES],
        queryFn: () =>
            axiosFetcher<IGetFavouritesResponse, IGetFavouritesRequest>({
                ...api.nova.infra.utility.user.userMenuFavorites.getFavourites.POST,
                data: { username: authStoreValue?.data?.loginUserName ?? '' },
            }),
    });

    const handleGetFavourites = async () => {
        const getFavouritesResponse = await getFavouritesQuery.refetch();

        if (getFavouritesResponse.isSuccess && getFavouritesResponse.data) {
            // * For Shell Trigger
            if (getFavouritesResponse.data.favoritesObject) {
                setFavourites(
                    base64Decryption<IFavouritesItem[]>(getFavouritesResponse?.data?.favoritesObject)?.data?.filter(
                        // The logout process can be done with the logout button in the sidebar menu.
                        (item) => item.screenName !== ScreenNameEnum.BANKING_EXIT,
                    ) ?? [],
                );
            }
        }
    };

    const navigatePage = (item: IFavouritesItem) => {
        navigateScreen(item);
    };

    useEffect(() => {
        authStoreValue.loggedIn && handleGetFavourites();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [authStoreValue.loggedIn]);

    return (
        <Layout title={t(locale.pageTitles.favourites)}>
            <GridTitle<IFavouritesItem>
                title={t(locale.pageTitles.favourites)}
                searchProps={{
                    show: true,
                    options: {
                        data: favourites,
                        displayField: 'screenCode',
                        displayValue: 'menuName',
                        renderDisplayField: (item) =>
                            `${item?.menuName}${item.screenCode ? ` (${item.screenCode})` : ''}`,
                        renderDisplayList: (item) =>
                            `${item?.menuName}${item.screenCode ? ` (${item.screenCode})` : ''}`,
                    },
                    onOpenScreenClick: (selectedItem) => {
                        const foundItem = favourites?.find(
                            (item) =>
                                selectedItem?.menuName?.includes(item.menuName) &&
                                item.screenCode === selectedItem.screenCode &&
                                item.screenName === selectedItem.screenName &&
                                item.menuKey === selectedItem.menuKey,
                        );
                        if (foundItem) {
                            navigatePage(foundItem);
                        }
                    },
                }}
            />
            <Grid py={2} spacing={1}>
                <View
                    show={Boolean(favourites.length > 0 && !getFavouritesQuery.isFetching && getFavouritesQuery.data)}>
                    <GridItem md={6} lg={4}>
                        <Menu
                            data={favourites}
                            onClick={(item) => {
                                navigatePage(item);
                            }}
                            sx={{
                                display: 'block',
                                '.shell-menu__item': {
                                    width: importantStyle('100%'),
                                },
                            }}
                        />
                    </GridItem>
                </View>
                <View
                    show={Boolean(
                        favourites.length === 0 && !getFavouritesQuery.isFetching && getFavouritesQuery.data,
                    )}>
                    <GridItem>
                        <Label
                            text={t(locale.notifications.noData)}
                            align="center"
                            color={(theme) => theme.palette.error.main}
                        />
                    </GridItem>
                </View>
            </Grid>
        </Layout>
    );
};

export default Favourites;
