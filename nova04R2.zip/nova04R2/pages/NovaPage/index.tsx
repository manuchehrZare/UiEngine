import type { FC, JSX } from 'react';
import { Layout } from '../../App';
import { Grid, GridItem } from '../../seker-ui-lib';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import NovaPageRenderer from '../../nova/nova-page';
import { NovaProvider } from '../../nova/nova-core';
const NovaPage: FC = (): JSX.Element => {
    return (
        <Layout title="Nova Ui Studio">
            <Grid py={2} spacing={1}>
                <GridItem>
                    <DndProvider backend={HTML5Backend}>
                        <NovaProvider workingMode="generator">
                            <NovaPageRenderer />
                        </NovaProvider>
                    </DndProvider>
                </GridItem>
            </Grid>
        </Layout>
    );
};

export default NovaPage;
