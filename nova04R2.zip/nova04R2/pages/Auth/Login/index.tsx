import type { FC, JSX } from 'react';
import { useEffect } from 'react';
import { getSessionStorageItem } from '../../../seker-ui-lib';
import { Layout, routes } from '../../../App';
import { constants, resetAuthData, setAuthData, useTranslation } from '../../../utils';
import { ReactComponent as Logo } from '../../../assets/images/logo_mini_lightgreen.svg';
import { useLocation, useNavigate } from 'react-router-dom';
import { dispatch, useSelector } from '../../../_store';
import type { AuthStoreData } from '../../../_store/slices/auth';
import { authValue, initialAuthStoreValue, resetStoreAuth, setStoreAuth } from '../../../_store/slices/auth';
import { appValue } from '../../../_store/slices/app';
import { useQueryClient } from '@tanstack/react-query';
import { resetStoreQuery } from '../../../_store/slices/query';
import { Login as SETLogin, getLoginNavigateRoute } from '../../../set-lib';

const Login: FC = (): JSX.Element => {
    const { t, locale } = useTranslation();
    const navigate = useNavigate();
    const { search: locationSearch } = useLocation();
    const queryClient = useQueryClient();
    const authStoreValue = useSelector(authValue);
    const appStoreValue = useSelector(appValue);
    const authStorageValue = getSessionStorageItem<AuthStoreData>(constants.key.SET_AUTH);

    const navigateLogin = (route: string) => {
        navigate(route);
    };

    const resetQuery = () => {
        dispatch(resetStoreQuery());
    };

    useEffect(() => {
        if (authStorageValue) {
            authStoreValue.data !== authStorageValue &&
                dispatch(setStoreAuth({ loggedIn: true, data: authStorageValue }));
            if (!appStoreValue.isNova) {
                navigateLogin(getLoginNavigateRoute({ homeRoute: routes.home.path, locationSearch, resetQuery }));
            }
        } else {
            authStoreValue !== initialAuthStoreValue && dispatch(resetStoreAuth());
            if (!locationSearch.includes(constants.key.LINK_REF)) {
                if (!appStoreValue.isNova) {
                    navigate(routes.auth.login.path);
                }
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        // * Onceki Cache'lenen datalarin silinmesi. Ilk ekran login olduğu icin burada bu islem yapilmaktadir
        queryClient.clear();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Layout
            title={t(locale.pageTitles.auth.login)}
            sx={{ backgroundColor: (theme) => theme.palette.grey[200] }}
            showFooter={false}
            showHeader={false}
            showSidebar={false}>
            <SETLogin
                logo={<Logo height="100%" width="100%" />}
                navigateProps={{ routes: { home: routes.home.path } }}
                onSetAuth={(data) => {
                    setAuthData(data);
                }}
                onResetAuth={() => {
                    resetAuthData();
                }}
                onResetQuery={resetQuery}
                onNavigate={navigateLogin}
            />
        </Layout>
    );
};

export default Login;
