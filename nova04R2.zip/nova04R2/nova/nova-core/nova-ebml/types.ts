/* eslint-disable */
// EBML Types Definition

export interface NovaEbml {
    language?: string;
    pid: string;
    size?: string;
    techVersion?: string;
    type?: string;
    v?: string;
    interface: NovaEbmlInterface;
    data?: NovaEbmlData;
    ruleset?: NovaEbmlRuleset; 
}

export interface NovaEbmlInterface {
    structure: NovaEbmlStructure;
    events: NovaEbmlEvent[]; // Keeping linear list for now unless map is preferred
}

export interface NovaEbmlStructure {
    rootBean: NovaEbmlBean;
}

export interface NovaEbmlBean {
    id: string;
    class: string;
    style?: NovaEbmlStyle; // Style definition with properties
    text?: string | null;
    children: NovaEbmlBean[]; // Mapped from SubBean
}

export interface NovaEbmlStyle {
    properties: NovaEbmlProperty[]; // Mapped from P
}

export interface NovaEbmlProperty {
    name: string;
    text: string;
    columns?: NovaEbmlColumn[];
    id?: string | null;
    m?: any;
    rule?: any;
    var?: any;
    n?: any;
    comp?: any;
 }

export interface NovaEbmlColumn {
    id: string;
    title: string;
    type: string;
    width?: string;
    editable?: boolean;
    visible?: boolean;
    order?: number;
    style?: NovaEbmlStyle;
}

// Rules Definitions
export interface NovaEbmlRuleset {
    rules?: NovaEbmlSimpleRule[];
    messages?: NovaEbmlMessageRule[];
    combinations?: NovaEbmlCombinationRule[];
}

export interface NovaEbmlSimpleRule {
    id: string;
    op: string; // Operator
    source: string;
    target?: string;
    targetType?: string;
}

export interface NovaEbmlMessageRule {
    id: string;
    var?: string | null;
    messageType: string;
    title: string;
    type: string;
    text: string;
}

export interface NovaEbmlCombinationRule {
    id: string;
    expression: string;
}

// Data/Var Definitions
export interface NovaEbmlData {
    variables : NovaEbmlVar[];
    definitions?: NovaEbmlDataDefinition[];
}

export interface NovaEbmlDataDefinition {
    id: string;
    options: NovaEbmlDataOption[];
    /** Nested column definitions for table components */
    columnDefinitions?: NovaEbmlColumnDefinition[];
}

export interface NovaEbmlColumnDefinition {
    columnId: string;
    options: NovaEbmlDataOption[];
}

export interface NovaEbmlDataOption {
    value: string;
    text: string;
}

export interface NovaEbmlVar {
    id: string;
    n?: string | null;
    comp?: string | null;
    text?: string | null;
    rule?: string | null;
    options?: NovaEbmlOption[];
}

export interface NovaEbmlOption {
    n: string;
    value: string;
    id?: string;
}

// Event & Action Definitions

export interface NovaEbmlEvent {
    id?: string;
    name?: string; // 'n' attribute
    type: string; // 'action' or 'event'
    refId?: string; // 'ref' attribute or child <ref>
    actions: NovaEbmlActionStep[];
}


export type NovaEbmlActionStep = 
    | { type: 'BeanAction', action: NovaEbmlBeanAction }
    | { type: 'RemoteCall', call: NovaEbmlRemoteCall }
    | { type: 'ReferenceCall', reference: string }
    | { type: 'VariableSetting', setting: NovaEbmlVariableSetting }
    | { type: 'PageCall', call: NovaEbmlPageCall };

export interface NovaEbmlBeanAction {
    targetId: string; // p.@_id
    method: string;   // p.@_m
    value?: string | number | boolean;   // p.#text
    property?: string;
    sourceVar?: string;
    description?: string;
}

export interface NovaEbmlRemoteCall {
    serviceName: string;
    status?: string | number;
    inputs?: NovaEbmlIOCollection;
    outputs?: NovaEbmlIOCollection;
    description?: string;
}

export interface NovaEbmlVariableSetting {
    variableId: string; // var.@_id
    value?: string | number | boolean;
    rule?: string;
    sourceComp?: {
        componentId: string;
        method: string;
    };
    description?: string;
}

export interface NovaEbmlPageCall {
    pageName?: string;
    method?: string; // e.g. 'showPopup', 'open'
    params?: any[];
    description?: string;
}

export interface NovaEbmlIOCollection {
    var?: NovaEbmlProperty[]; // Mapped from <var>
    p?: NovaEbmlProperty[]; // Mapped from <p>
}

// Using NovaEbmlProperty for EventParameter as they share similar structure
export type NovaEbmlEventParameter = NovaEbmlProperty;

export interface NovaEbmlManipulation {
    targetId: string;
    method?: string;
    property?: string;
    value?: string; // from var or text
    sourceVar?: string; // from var
}


/**
 * Component mapping types
 */
export interface NovaComponentBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface NovaParsedComponent {
    id: string;
    type: string;
    bounds: NovaComponentBounds;
    properties: Record<string, any>;
    children?: NovaParsedComponent[];
}
 