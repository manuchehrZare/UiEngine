/* eslint-disable */
import type { ParsedComponent } from '../types';
import { COMPONENT_REGISTRY } from '../registry/component-registry';
import { resolveComponentType } from '../utils/mappings';
// import uiDefinitionsData from '../../../assets/docs/ui-definition.json';
import type { DesignComponent } from '../types';
// import { convertEbmlToNovaSchema } from './EbmlConverter';

// Cast the imported JSON to the correct type
// const uiDefinitions = uiDefinitionsData as PageDefinition[];

/**
 * Calculate Grid columns (1-12) based on width relative to parent
 */
const calculateGridSize = (width: number, parentWidth: number): number => {
    if (!parentWidth || parentWidth <= 0) return 12;
    const fraction = width / parentWidth;
    const columns = Math.round(fraction * 12);
    return Math.max(1, Math.min(12, columns));
};

/**
 * Get the effective width of a component, considering both bounds and pageSize
 * @param component - The parsed component
 * @returns The width in pixels
 */
const getEffectiveWidth = (component: ParsedComponent): number => {
    // First check if bounds has a valid width
    if (component.bounds && component.bounds.width > 0) {
        return component.bounds.width;
    }

    // If bounds is 0, check for pageSize property (format: "width,height")
    if (component.properties?.pageSize) {
        const pageSize = String(component.properties.pageSize);
        const [width] = pageSize.split(',').map(Number);
        if (width && width > 0) {
            return width;
        }
    }

    // Fallback to bounds width (even if 0)
    return component.bounds?.width || 0;
};

/**
 * Sort components by Row (Y) then Column (X)
 */
const sortComponentsByGridOrder = (components: ParsedComponent[]) => {
    return [...components].sort((a, b) => {
        // Group by row with some tolerance (e.g. 10px)
        if (Math.abs(a.bounds.y - b.bounds.y) > 10) {
            return a.bounds.y - b.bounds.y;
    }
        // Within row, sort by X
        return a.bounds.x - b.bounds.x;
    });
};

/**
 * Map ParsedComponent (nested structure) to DesignComponent (Grid structure)
 */
export const mapParsedComponentToDesign = (
    component: ParsedComponent,
    parentId: string | null
): DesignComponent => {
    // component.type is already resolved by ebml-parser, but we double check/fallback
    const designType = COMPONENT_REGISTRY[component.type] ? component.type : resolveComponentType(component.type) || component.type;
    
    const defaultProps = COMPONENT_REGISTRY[designType]?.defaultProps || {};
    const props: Record<string, any> = {
        ...defaultProps,
        ...component.properties,
        // Map component Id to both id prop and name prop for backward compatibility
        id: component.properties.id || component.id,
        name: component.properties.id || component.id,
        bounds: component.bounds, // Pass bounds to all components
        // Fix: Check for resolved type 'TableComponent' instead of Java class name
        xs: designType === 'TableComponent' ? 12 : undefined,
        // Fix: HandleButton renders its own GridItem if useAbsolutePositioning is false, so we force it to true to avoid double wrapping
        useAbsolutePositioning: designType === 'HandleButton' ? true : undefined,
    };

    let children: DesignComponent[] = [];

    // Special handling for Page (JCSPage)
    if (designType === 'Page') {
        // We create a Root Grid Container
        // Inside it, we put a GridItem which acts as the "Page" component holder (though Page is usually a layout itself)
        // But user requested: "use two component, a gridItem inside Grid and set property of bean to gridItem make root grid Container and direction to column"
        
        // 1. Map children first
        // Note: We use the same recursion logic for children
        if (component.children && component.children.length > 0) {
            const sortedChildren = sortComponentsByGridOrder(component.children);
            children = sortedChildren.map(child => {
                // For children of Page, we usually wrap them in GridItems because Page (now Root Grid) is a container
                const mappedChild = mapParsedComponentToDesign(child, component.id);
                // Calculate responsive width (xs) relative to page width
                // Use getEffectiveWidth to handle both bounds and pageSize
                const parentWidth = getEffectiveWidth(component);
                const childWidth = getEffectiveWidth(child);
                const xs = calculateGridSize(childWidth, parentWidth);
                const finalXs = mappedChild.type === 'TableComponent' ? 12 : xs;

                return {
                    id: `grid-item-${child.id}`,
                    type: 'GridItem',
                    props: { xs: finalXs, key: child.id },
                    children: [mappedChild],
                    parentId: component.id,
                };
            });
        }

        // 2. Create the GridItem that holds the Page properties
        // Wait, if the Root is Grid, and children are GridItems, where does the "bean property" go?
        // "set property of bean to gridItem". This implies there's a specific GridItem representing the Page itself?
        // Or does it mean the Page content is inside a GridItem?
        // "gridItem inside Grid" -> One GridItem inside One Grid?
        // If Page has many children, do they all go into ONE GridItem?
        // "use two component, a gridItem inside Grid" -> Singular.
        // So: Root Grid -> Single GridItem -> Children?
        
        // Let's assume the user wants to wrap the entire page content in a single GridItem, 
        // and that GridItem receives the Page properties (like background color etc?).
        
        const pageContentGridItem: DesignComponent = {
            id: `page-content-${component.id}`,
            type: 'GridItem',
            props: {
                ...props, // Bean properties go here
                xs: 12,   // Full width
                container: true,
                 spacing: 2,

            },
            children: children, // All mapped children go inside this single GridItem
            parentId: component.id
        };

        // 3. Create Root Grid
        return {
            id: component.id,
            type: 'Grid',
            props: {
                container: true,
                direction: 'column',
                spacing: 2,
                style: { height: '100%', width: '100%' },
                p:2,
            },
            children: [pageContentGridItem],
            parentId,
        };
    }

    // Special handling for Container (JCSPanel)
    if (designType === 'Container') {
        // "use four component, a Grid inside Paper inside gridItem and set property of bean to Grid, and then put childs as gridItem inside grid"

        // 1. Map children first
        if (component.children && component.children.length > 0) {
            const sortedChildren = sortComponentsByGridOrder(component.children);
            children = sortedChildren.map(child => {
                // Children go inside the inner Grid, so they need to be GridItems
                const mappedChild = mapParsedComponentToDesign(child, `grid-${component.id}`);
                // Calculate responsive width (xs) relative to panel width
                // Use getEffectiveWidth to handle both bounds and pageSize
                const parentWidth = getEffectiveWidth(component);
                const childWidth = getEffectiveWidth(child);
                const xs = calculateGridSize(childWidth, parentWidth);
                const finalXs = mappedChild.type === 'TableComponent' ? 12 : xs;

                return {
                    id: `grid-item-${child.id}`,
                    type: 'GridItem',
                    props: { xs: finalXs, key: child.id },
                    children: [mappedChild],
                    parentId: `grid-${component.id}`,
                };
            });
        }

        // If panel has a title, add Nav component as first child
        const panelTitle = component.properties?.title || component.properties?.label;
        if (panelTitle) {
            // Create Nav component with title
            const navComponent: DesignComponent = {
                id: `nav-${component.id}`,
                type: 'Nav',
                props: {
                    navTitleProps: { title: panelTitle }
                },
                children: [],
                parentId: `grid-${component.id}`
            };

            // Wrap Nav in GridItem
            const navGridItem: DesignComponent = {
                id: `grid-item-nav-${component.id}`,
                type: 'GridItem',
                props: { xs: 12, key: `nav-${component.id}` },
                children: [navComponent],
                parentId: `grid-${component.id}`
            };

            // Add Nav as first child
            children = [navGridItem, ...children];
        }

        // 2. Create Inner Grid (receives bean properties)
        const innerGrid: DesignComponent = {
            id: `grid-${component.id}`,
            type: 'Grid',
            props: {
                ...props, // Set property of bean to Grid
                container: true,
                spacing: 2,
                style: { height: '100%', width: '100%' }
            },
            children: children,
            parentId: `paper-${component.id}` // Parent is Paper
        };

        // 3. Create Paper Wrapper
        // Note: The parent logic (if this is inside a Grid) will wrap this Paper in a GridItem.
        return {
            id: component.id,
            type: 'Paper',
            props: {
                elevation: 1,
                style: { height: '100%', width: '100%', padding: '16px', overflow: 'hidden' }
            },
            children: [innerGrid],
            parentId
        };
    }

    // Handle children (Default logic for non-Page/non-Container)
    // Region Handling
    else if (designType === 'Paper' && component.properties?.regionName) {
        // const regionName = component.properties.regionName;
        // const regionDef = uiDefinitions.find(d => d.Name === regionName);
        // if (regionDef?.EbmlContent?.Interface?.Structure?.Bean) {
        //     const regionRoot = parseBeanWithNesting(regionDef.EbmlContent.Interface.Structure.Bean);
        //     children.push(mapParsedComponentToDesign(regionRoot, component.id));
        // }
    }
    // Standard Children Handling
    else if (component.children && component.children.length > 0) {
        const sortedChildren = sortComponentsByGridOrder(component.children);

        children = sortedChildren.map(child => {
            const isGridContainer = ['Grid', 'Container', 'Paper'].includes(designType) || COMPONENT_REGISTRY[designType]?.isContainer;
            const mappedChild = mapParsedComponentToDesign(child, component.id);

            // Special handling: TabbedPane and TabPage should NOT wrap their children in GridItem
            // - TabbedPane must receive TabPage components directly, not wrapped in GridItem
            // - TabPage children should be direct children, not wrapped in GridItem
            // BUT: TabbedPane itself CAN be wrapped in GridItem when it's a child of a Grid container
            const parentIsTabbedPaneOrTabPage = designType === 'TabbedPane' || designType === 'TabPage';

            if (isGridContainer && !parentIsTabbedPaneOrTabPage) {
                // Calculate responsive width (xs)
                // Use getEffectiveWidth to handle both bounds and pageSize
                const parentWidth = getEffectiveWidth(component);
                const childWidth = getEffectiveWidth(child);
                const xs = calculateGridSize(childWidth, parentWidth);

                // Force TableComponent and TabbedPane to full width for better display
                const finalXs = (mappedChild.type === 'TableComponent' || mappedChild.type === 'TabbedPane') ? 12 : xs;

                return {
                    id: `grid-item-${child.id}`,
                    type: 'GridItem',
                    props: { xs: finalXs, key: child.id },
                    children: [mappedChild],
                    parentId: component.id,
                };
            }
            return mappedChild;
        });
    }

    // If component is a container, ensure direction is row (default for Grid)
    if (designType === 'Grid') {
        props.container = true;
        props.spacing = 2;
    }

    return {
        id: component.id,
        type: designType,
        props,
        children,
        parentId,
    };
};
