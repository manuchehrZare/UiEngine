/* eslint-disable */
import React, { useState, useRef, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Toolbar } from './components/Toolbar';
import { DesignArea } from './components/DesignArea';
import { PropertiesPanel } from './components/PropertiesPanel';
import { JsonEditor } from './components/Editors/JsonEditor';
import { JavascriptEditor } from './components/Editors/JavascriptEditor';
import { CssEditor } from './components/Editors/CssEditor';
import { ActionDesigner } from './components/Designers/ActionDesigner';
import { RuleDesigner } from './components/Designers/RuleDesigner';
import { DataDesigner } from './components/Designers/DataDesigner';
import { EngineDebugPanel } from '../nova-core/components/EngineDebugPanel';
import { NovaProvider, useNova } from '../nova-core/context/NovaContext';
import { LogCenterProvider } from '../nova-core/context/LogCenterContext';
import {
    Box, AppBar, Tabs, Tab, Stack, Typography
} from '@mui/material';

import PreviewIcon from '@mui/icons-material/Preview';
import EditIcon from '@mui/icons-material/Edit';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '../../seker-ui-lib';

const DesignerContent: React.FC = () => {
    const [activeTab, setActiveTab] = useState(0);
    const { mode, setMode, exportDesign, importDesign, clearDesign } = useNova();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const location = useLocation();
    const navigate = useNavigate();
    const hasImportedFromState = useRef(false);

    const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
        setActiveTab(newValue);
    };

    const handleExport = () => {
        const json = exportDesign();
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `design-${new Date().toISOString()}.json`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const content = e.target?.result as string;
            if (content) {
                importDesign(content);
            }
        };
        reader.readAsText(file);
        // Reset input
        event.target.value = '';
    };

    useEffect(() => {
        const importedDesign = (location.state as { importedDesign?: string } | null)?.importedDesign;
        if (!hasImportedFromState.current && importedDesign) {
            importDesign(importedDesign);
            setMode('design');
            hasImportedFromState.current = true;
            navigate(location.pathname, { replace: true });
        }
    }, [location, importDesign, setMode, navigate]);

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
            {/* Header / Tabs */}
            <AppBar position="static" color="default" elevation={1} sx={{ zIndex: 1201 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', px: 2 }}>
                    <Typography variant="h6" sx={{ mr: 4 }}>UI Designer</Typography>
                    <Tabs value={activeTab} onChange={handleTabChange} sx={{ flexGrow: 1 }}>
                        <Tab label="Visual Designer" />
                        <Tab label="Schema (JSON)"  />
                        <Tab label="JS Code" />
                        <Tab label="CSS Code" />
                        <Tab label="Action Designer" />
                        <Tab label="Rule Designer" />
                        <Tab label="Data Designer" />
                         
                    </Tabs>
                    <Stack direction="row" spacing={1}>
                        <input
                            type="file"
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                            accept=".json"
                            onChange={handleFileChange}
                        />
                        {mode === 'design' && <> <Button
                            iconRight={<DeleteSweepIcon />}
                            variant="outlined"
                            color="error"
                            onClick={() => {
                                if (window.confirm('Are you sure you want to clear the current design? This action cannot be undone.')) {
                                    clearDesign();
                                }
                            }}
                            text="Clear"
                        />
                       <Button
                            iconRight={<FileUploadIcon />}
                            variant="outlined"
                            onClick={handleImportClick}
                            text="Import"
                        />
                        <Button
                            iconRight={<FileDownloadIcon />}
                            variant="outlined"
                            onClick={handleExport}
                            text="Export"
                        /></>}
                        {activeTab === 0 && (
                            <>
                            <EngineDebugPanel />
                                <Button
                                    iconRight={mode === 'design' ? <PreviewIcon /> : <EditIcon />}
                                    variant="outlined"
                                    onClick={() => setMode(mode === 'design' ? 'preview' : 'design')}
                                    text={mode === 'design' ? 'Preview' : 'Edit'}
                                />
                            </>
                        )}
                    </Stack>
                </Box>
            </AppBar>

            {/* Main Content */}
            <Box sx={{ flexGrow: 1, display: 'flex', overflow: 'hidden' }}>
                
                {/* Tab 0: Visual Designer */}
                {activeTab === 0 && (
                    <>
                        {/* Left: Toolbar (Only in Design Mode) */}
                        {mode === 'design' && (
                            <Box sx={{ width: 280, flexShrink: 0, bgcolor: 'background.paper', borderRight: 1, borderColor: 'divider' }}>
                                <Toolbar />
                            </Box>
                        )}

                        {/* Center: Design Area */}
                        <Box sx={{ flexGrow: 1, bgcolor: '#f0f2f5', overflow: 'hidden' }}>
                            <DesignArea />
                        </Box>

                        {/* Right: Properties (Only in Design Mode) */}
                        {mode === 'design' && (
                            <Box sx={{ width: 300, flexShrink: 0, bgcolor: 'background.paper', borderLeft: 1, borderColor: 'divider' }}>
                                <PropertiesPanel />
                            </Box>
                        )}
                    </>
                )}

                {/* Tab 1: JSON Editor */}
                {activeTab === 1 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <JsonEditor />
                    </Box>
                )}

                {/* Tab 2: JS Editor */}
                {activeTab === 2 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <JavascriptEditor />
                    </Box>
                )}

                {/* Tab 3: CSS Editor */}
                {activeTab === 3 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <CssEditor />
                    </Box>
                )}

                {/* Tab 4: Action Designer */}
                {activeTab === 4 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <ActionDesigner />
                    </Box>
                )}

                {/* Tab 5: Rule Designer */}
                {activeTab === 5 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <RuleDesigner />
                    </Box>
                )}

                {/* Tab 6: Data Designer */}
                {activeTab === 6 && (
                    <Box sx={{ flexGrow: 1 }}>
                        <DataDesigner />
                    </Box>
                )}
            </Box>
        </Box>
    );
};

export const DesignerPage: React.FC = () => {
    return (
        <LogCenterProvider>
            <NovaProvider workingMode='design'>
                <DndProvider backend={HTML5Backend}>
                    <DesignerContent />
                </DndProvider>
            </NovaProvider>
        </LogCenterProvider>
    );
};

export default DesignerPage;

