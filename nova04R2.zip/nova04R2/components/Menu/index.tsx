import { NavigateNext } from '@mui/icons-material';
import type { FC, JSX, ReactNode } from 'react';
import { memo } from 'react';
import { Link } from 'react-router-dom';
import type { IBoxProps } from '../../seker-ui-lib';
import {
    Box,
    DesignTypeEnum,
    importantStyle,
    Label,
    Popup,
    PopupAnchorTriggerEnum,
    typographyClasses,
    View,
} from '../../seker-ui-lib';
import { removeHrefFromLinkForShell } from '../../utils';
import type { IMenuItem } from '../../set-lib';
import { v4 as uuidv4 } from 'uuid';

interface IMenuProps extends Pick<IBoxProps, 'sx'> {
    data: IMenuItem[];
    onClick: (menuItem: IMenuItem) => void;
}

const Menu: FC<IMenuProps> = ({ data, onClick, sx }): JSX.Element => {
    const parentIconSize = 22;
    const renderItemWrapper = (childNode: ReactNode) => {
        return (
            <Box
                className="shell-menu__item__wrapper"
                display="flex"
                alignItems="center"
                sx={{
                    position: 'relative',
                    cursor: 'pointer',
                    borderRadius: '2px',
                    border: 1,
                    borderColor: (theme) => theme.palette.grey[600],
                    backgroundColor: (theme) => theme.palette.common.white,
                    pl: 1,
                    pr: `${parentIconSize}px`,
                    py: '5px',
                    '.sekerUI-Label': {
                        [`.${typographyClasses.root}`]: {
                            fontSize: 12,
                            color: (theme) => theme.palette.primary.main,
                        },
                    },
                    ':hover': {
                        backgroundColor: (theme) => theme.palette.secondary.main,
                        borderColor: (theme) => theme.palette.secondary.main,
                        '.sekerUI-Label': {
                            [`.${typographyClasses.root}`]: {
                                color: (theme) => importantStyle(theme.palette.common.white),
                            },
                        },
                        svg: { fill: (theme) => importantStyle(theme.palette.common.white) },
                    },
                    ':focus, &[aria-controls]': {
                        borderColor: (theme) => theme.palette.secondary.main,
                        '.sekerUI-Label': {
                            [`.${typographyClasses.root}`]: {
                                color: (theme) => theme.palette.secondary.main,
                            },
                        },
                        svg: { fill: (theme) => theme.palette.secondary.main },
                    },
                }}>
                {childNode}
            </Box>
        );
    };
    const renderParentItem = (item: IMenuItem) => {
        return renderItemWrapper(
            <>
                <Label design={DesignTypeEnum.Default} text={item.menuName} />
                <NavigateNext
                    sx={{ position: 'absolute', right: 0, ml: 'auto', height: parentIconSize, width: parentIconSize }}
                />
            </>,
        );
    };

    const renderLinkItem = (item: IMenuItem) => {
        return (
            <Link
                to="#"
                style={{ cursor: 'pointer' }}
                {...removeHrefFromLinkForShell()}
                onClick={(e) => {
                    e.preventDefault();
                    onClick && onClick(item);
                }}>
                {renderItemWrapper(
                    <Label
                        design={DesignTypeEnum.Default}
                        text={`${item.menuName}${item.screenCode ? ` (${item.screenCode})` : ''}`}
                    />,
                )}
            </Link>
        );
    };

    const renderMenu = (menu: IMenuItem[]) => {
        return menu?.map((item, index) => (
            <Box
                key={uuidv4()}
                className="shell-menu__item"
                sx={{
                    '.shell-menu__item__children &': {
                        minWidth: 150,
                        maxWidth: 234,
                    },
                    ':not(.shell-menu__item__children &)': {
                        width: 234,

                        ':not(:last-of-type)': {
                            mb: 0.5,
                        },
                    },
                }}>
                <View show={Boolean(item.children && item.children.length > 0)}>
                    <Popup
                        id={`${item.menuName}_${index}_${item?.children?.length}`}
                        anchorTrigger={PopupAnchorTriggerEnum.HOVER}
                        anchorEl={renderParentItem(item)}
                        popupPosition={{ anchorOrigin: { horizontal: 'right', vertical: 'top' } }}
                        sx={{
                            borderRadius: '2px',
                            boxShadow: (theme) => theme.shadows[4],
                            backgroundColor: 'transparent',
                        }}>
                        <View show={Boolean(item.children && item.children.length > 0)}>
                            <Box className="shell-menu__item__children">{renderMenu(item?.children ?? [])}</Box>
                        </View>
                    </Popup>
                </View>
                <View show={Boolean(!item.children || item.children.length === 0)}>{renderLinkItem(item)}</View>
            </Box>
        ));
    };
    return data.length > 0 ? (
        <Box display="inline-block" className="shell-menu" sx={sx}>
            {renderMenu(data)}
        </Box>
    ) : (
        <Box display="none" />
    );
};

export default memo(Menu);
