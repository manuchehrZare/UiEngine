import type { Theme } from '@mui/material';
import { styled } from '@mui/material';
import type { SnackbarProviderProps } from 'notistack';
import { SnackbarProvider as NotistackSnackbarProvider } from 'notistack';
import { theme } from '../../..';
import type { StyledComponent } from '@emotion/styled';
import type { MUIStyledCommonProps } from '@mui/system';
import type { Ref } from 'react';

const SnackbarProvider: StyledComponent<
    SnackbarProviderProps & MUIStyledCommonProps<Theme>,
    {},
    {
        ref?: Ref<NotistackSnackbarProvider> | undefined;
    }
> = styled(NotistackSnackbarProvider)`
    &.notistack-MuiContent {
        word-break: break-word;
        svg {
            align-self: flex-start;
        }
        &-default {
            background-color: ${theme.palette.primary.main};
        }
        &-success {
            background-color: ${theme.palette.success.main};
        }
        &-error {
            background-color: ${theme.palette.error.main};
        }
        &-info {
            background-color: ${theme.palette.info.main};
        }
        &-warning {
            background-color: ${theme.palette.warning.main};
        }
    }
`;

export default SnackbarProvider;
