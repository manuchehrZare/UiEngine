import type { IProgressProps } from '../type';

export interface ICircularProgressProps extends Omit<IProgressProps, 'type'> {}
