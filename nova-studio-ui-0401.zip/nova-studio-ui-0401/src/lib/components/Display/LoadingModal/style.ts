import type { SxProps, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { generateClass } from '../../../utils/methods/design';

export const MuiLoadingModalSxProps = (): SxProps<Theme> => ({
    [`&.${generateClass('LoadingModal')}`]: {
        '&:not([hidden])': {
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            display: 'flex',
            zIndex: 2000000002,
            position: 'fixed',
            alignItems: 'center',
            touchAction: 'none',
            justifyContent: 'center',
            color: (theme) => theme.palette.common.white,
            bgcolor: (theme) => alpha(theme.palette.common.black, 0.5),
            WebkitTapHighlightColor: 'transparent',
            flexDirection: 'column',

            [`.${generateClass('LoadingModal-progress')}`]: {
                height: 57,
                backgroundColor: (theme) => alpha(theme.palette.common.black, 0.3),
                borderRadius: '50%',
                p: 1,
                display: 'flex',
                alignItems: 'center',
            },

            [`.${generateClass('LoadingModal-text')}`]: {
                pl: 1,
            },
        },
    },
});
