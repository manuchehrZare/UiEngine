import type { IBoxProps } from '../../..';

export interface ILoadingModalProps extends Pick<IBoxProps, 'sx' | 'id' | 'className' | 'hidden'> {
    text?: string;
}
