import type { FC } from 'react';
import { memo } from 'react';
import type { IAccordionProps } from './type';
import type { Theme } from '@mui/material';
import { Accordion as MuiAccordion, AccordionSummary, AccordionDetails } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ThemeProvider from '../../App/ThemeProvider';
import type { DesignType } from '../../..';
import { constants, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme, manageClassNames } from '../../../utils';

const Accordion: FC<IAccordionProps> = ({ title, icon, content, design, className, ...rest }) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiAccordion className={manageClassNames(generateClass('Acordion'), className)} {...rest}>
                <AccordionSummary
                    className={manageClassNames(generateClass('AccordionSummary'))}
                    expandIcon={icon || <ExpandMoreIcon />}>
                    {title}
                </AccordionSummary>
                <AccordionDetails className={manageClassNames(generateClass('AccordionDetails'))}>
                    {content}
                </AccordionDetails>
            </MuiAccordion>
        </ThemeProvider>
    );
};

export default memo(Accordion);
