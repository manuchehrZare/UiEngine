import { Unstable_Grid2 as MuiGrid } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IGridItemProps } from '../type';
import type { DesignType } from '../../../..';
import { constants, useStorage } from '../../../..';
import { generateClass, getComponentDesignProperty, manageClassNames } from '../../../../utils';

const GridItem: FC<IGridItemProps> = forwardRef(
    ({ children, className, design, xs = 12, sizeType, ...rest }: IGridItemProps, ref) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });

        const getSizeType = () => {
            const activeDesign = getComponentDesignProperty(design, storageDesign.newValue);
            switch (sizeType) {
                case 'common':
                    return constants.design.gridItem.sizeType.common;
                case 'form':
                    return constants.design.gridItem.sizeType.form[activeDesign];
                default:
                    return {};
            }
        };
        return (
            <MuiGrid
                className={manageClassNames(
                    generateClass('GridItem'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                ref={ref}
                xs={xs}
                {...getSizeType()}
                {...rest}>
                {children}
            </MuiGrid>
        );
    },
);

export default GridItem;
