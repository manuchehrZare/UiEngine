import type { FC } from 'react';
import { forwardRef, memo } from 'react';
import type { INavContainerProps } from '../type';
import Divider from '../../Divider';
import type { DesignType } from '../../../..';
import { Box, DesignTypeEnum, Grid, constants, manageClassNames, useStorage } from '../../../..';
import ThemeProvider from '../../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty } from '../../../../utils';
import type { Theme } from '@mui/material';
import { getProviderTheme } from '../../../../utils/methods/theme';

const NavContainer: FC<INavContainerProps> = forwardRef(
    (
        {
            children,
            stickyTop,
            stickyBottom,
            className,
            design,
            small,
            dividerProps,
            navContainerWrapperProps,
            ...rest
        }: INavContainerProps,
        ref,
    ) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <Box
                    className={generateClass('NavContainerWrapper')}
                    ref={ref}
                    {...(getComponentDesignProperty(design, storageDesign.newValue) === DesignTypeEnum.SET && {
                        pb: 0.5,
                    })}
                    {...navContainerWrapperProps}>
                    <Grid
                        container
                        className={manageClassNames(
                            generateClass('NavContainer'),
                            getComponentDesignProperty(design, storageDesign.newValue),
                            className,
                            {
                                'sticky-top': stickyTop,
                                'sticky-bottom': stickyBottom,
                                small: small,
                            },
                        )}
                        {...rest}>
                        {children}
                    </Grid>
                    <Divider
                        className={manageClassNames(generateClass('NavContainer-divider'))}
                        design={getComponentDesignProperty(design, storageDesign.newValue)}
                        {...dividerProps}
                    />
                </Box>
            </ThemeProvider>
        );
    },
);

export default memo(NavContainer);
