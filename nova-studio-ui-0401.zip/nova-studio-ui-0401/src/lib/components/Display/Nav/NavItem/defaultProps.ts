import type { INavItemProps } from '../../../..';
import { DesignTypeEnum } from '../../../../utils/types/common';

export const getDefaultProps = ({
    design,
    sx,
}: Pick<INavItemProps, 'design' | 'sx'>): Pick<INavItemProps, 'py' | 'pb' | 'sx'> => {
    switch (design) {
        case DesignTypeEnum.Default:
            return {
                py: 2,
                sx: {
                    '.small &': {
                        py: 1,
                    },
                    ...sx,
                },
            };
        case DesignTypeEnum.SET:
            return {
                pb: 0.5,
                sx: {
                    '.small &': {
                        pb: 0.25,
                    },
                    ...sx,
                },
            };
        default:
            return {};
    }
};
