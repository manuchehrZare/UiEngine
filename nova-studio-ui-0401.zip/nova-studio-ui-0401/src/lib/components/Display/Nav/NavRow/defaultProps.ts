import type { INavRowProps } from '../../../..';
import { DesignTypeEnum } from '../../../../utils/types/common';

export const getDefaultProps = ({ design }: Pick<INavRowProps, 'design'>): Pick<INavRowProps, 'px'> => {
    switch (design) {
        case DesignTypeEnum.Default:
            return {
                px: 3,
            };
        case DesignTypeEnum.SET:
            return {
                px: 0,
            };
        default:
            return {};
    }
};
