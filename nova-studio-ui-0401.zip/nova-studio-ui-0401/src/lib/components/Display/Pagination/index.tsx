import type { Theme } from '@mui/material';
import { Pagination as MuiPagination } from '@mui/material';
import type { FC } from 'react';
import { memo } from 'react';
import type { DesignType } from '../../..';
import { constants, useStorage } from '../../..';
import { generateClass, getComponentDesignProperty, getProviderTheme, manageClassNames } from '../../../utils';
import ThemeProvider from '../../App/ThemeProvider';
import type { IPaginationProps } from './type';

const Pagination: FC<IPaginationProps> = ({ className, design, ...rest }) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });

    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <MuiPagination
                className={manageClassNames(
                    generateClass('Pagination'),
                    getComponentDesignProperty(design, storageDesign.newValue),
                    className,
                )}
                {...rest}
            />
        </ThemeProvider>
    );
};

export default memo(Pagination);
