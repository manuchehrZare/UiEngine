import type { FC } from 'react';
import { memo } from 'react';
import type { DesignType } from '../../..';
import { Modal, ModalBody, ModalFooter, ModalTitle, Button, GridItem, Grid, constants, useStorage } from '../../..';
import { i18n, locale } from '../../../utils/locales';
import type { IConfirmModalProps } from './type';
import type { Theme } from '@mui/material';
import { Typography } from '@mui/material';
import { omit } from 'lodash';
import ThemeProvider from '../../App/ThemeProvider';
import { generateClass, getComponentDesignProperty, getProviderTheme, manageClassNames } from '../../../utils';

const ConfirmModal: FC<IConfirmModalProps> = ({
    onConfirm,
    body,
    onClose,
    show,
    title,
    design,
    okText = i18n.t(locale.buttons.ok),
    cancelText = i18n.t(locale.buttons.cancel),
    maxWidth = 'xs',
    loading,
    actionProps,
    modalTitleProps,
    modalBodyProps,
    modalFooterProps,
    draggable = false,
    fullHeight = false,
    fullScreen = false,
    fullWidth = false,
    className,
    sx,
}) => {
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    return (
        <ThemeProvider
            design={getComponentDesignProperty(design, storageDesign.newValue)}
            theme={getProviderTheme(storageTheme.newValue)}>
            <Modal
                className={manageClassNames(generateClass('Confirm-Modal'), className)}
                maxWidth={maxWidth}
                fullHeight={fullHeight}
                fullScreen={fullScreen}
                fullWidth={fullWidth}
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                show={show}
                onClose={onClose}
                closeIcon={false}
                draggable={draggable}
                sx={sx}>
                <>
                    {title && (
                        <ModalTitle
                            {...modalTitleProps}
                            className={manageClassNames(
                                generateClass('Confirm-Modal-Title'),
                                modalTitleProps?.className,
                            )}>
                            {title}
                        </ModalTitle>
                    )}
                    <ModalBody
                        {...modalBodyProps}
                        className={manageClassNames(generateClass('Confirm-Modal-Body'), modalBodyProps?.className)}>
                        <Grid display="block" textAlign="center" p={2}>
                            <GridItem xs="auto">
                                <Typography
                                    className={manageClassNames(
                                        getComponentDesignProperty(design, storageDesign.newValue),
                                    )}
                                    variant="body1">
                                    {body}
                                </Typography>
                            </GridItem>
                        </Grid>
                    </ModalBody>
                    <ModalFooter
                        {...modalFooterProps}
                        className={manageClassNames(
                            generateClass('Confirm-Modal-Footer'),
                            modalFooterProps?.className,
                        )}>
                        <Grid spacing={1} justifyContent="center" {...actionProps?.gridProps}>
                            <GridItem xs="auto" {...actionProps?.cancelGridItemProps}>
                                <Button
                                    design={getComponentDesignProperty(design, storageDesign.newValue)}
                                    text={cancelText}
                                    variant="text"
                                    disabled={
                                        loading ||
                                        actionProps?.cancelProps?.disabled ||
                                        actionProps?.cancelProps?.loading
                                    }
                                    onClick={() => {
                                        onConfirm(false);
                                    }}
                                    {...omit(actionProps?.cancelProps, ['disabled', 'loading'])}
                                />
                            </GridItem>
                            <GridItem xs="auto" {...actionProps?.okGridItemProps}>
                                <Button
                                    design={getComponentDesignProperty(design, storageDesign.newValue)}
                                    text={okText}
                                    disabled={
                                        loading || actionProps?.okProps?.disabled || actionProps?.okProps?.loading
                                    }
                                    onClick={() => {
                                        onConfirm(true);
                                    }}
                                    {...omit(actionProps?.okProps, ['disabled', 'loading'])}
                                />
                            </GridItem>
                        </Grid>
                    </ModalFooter>
                </>
            </Modal>
        </ThemeProvider>
    );
};

export default memo(ConfirmModal);
