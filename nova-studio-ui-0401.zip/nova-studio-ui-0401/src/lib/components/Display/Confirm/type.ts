import type { ICommonProps } from '../../../utils/types/common';
import type { IButtonProps } from '../../Form/Button/type';
import type { IGridProps } from '../Grid/type';
import type { IModalBodyProps, IModalFooterProps, IModalProps, IModalTitleProps } from '../Modal/type';

export interface IConfirmModalActionProps<T = Omit<IButtonProps, 'design' | 'href' | 'onClick' | 'text' | 'type'>> {
    cancelGridItemProps?: IGridProps;
    cancelProps?: T;
    gridProps?: IGridProps;
    okGridItemProps?: IGridProps;
    okProps?: T;
}

export interface IConfirmModalProps
    extends ICommonProps,
        Pick<
            IModalProps,
            | 'className'
            | 'show'
            | 'maxWidth'
            | 'onClose'
            | 'loading'
            | 'draggable'
            | 'fullHeight'
            | 'fullScreen'
            | 'fullWidth'
            | 'sx'
        > {
    actionProps?: IConfirmModalActionProps;
    body: IModalBodyProps['children'];
    cancelText?: string;
    modalBodyProps?: Partial<Omit<IModalBodyProps, 'children'>>;
    modalFooterProps?: Partial<Omit<IModalFooterProps, 'children'>>;
    modalTitleProps?: Partial<Omit<IModalTitleProps, 'title'>>;
    okText?: string;
    onConfirm: (status: boolean) => void;
    title?: IModalTitleProps['children'];
}
