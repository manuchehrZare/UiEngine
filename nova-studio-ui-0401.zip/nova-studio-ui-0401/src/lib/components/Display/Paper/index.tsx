import type { Theme } from '@mui/material';
import { Paper as MuiPaper } from '@mui/material';
import type { FC } from 'react';
import { forwardRef } from 'react';
import type { IPaperProps } from './type';
import type { DesignType } from '../../../utils';
import {
    constants,
    generateClass,
    getComponentDesignProperty,
    getProviderTheme,
    manageClassNames,
} from '../../../utils';
import ThemeProvider from '../../App/ThemeProvider';
import useStorage from '../../../hooks/useStorage';

const Paper: FC<IPaperProps> = forwardRef(
    ({ children, borderBox = false, design, className, ...rest }: IPaperProps, ref) => {
        const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
        const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <MuiPaper
                    className={manageClassNames(
                        generateClass('Paper'),
                        getComponentDesignProperty(design, storageDesign.newValue),
                        className,
                        { 'border-box': Boolean(borderBox) },
                    )}
                    ref={ref}
                    {...rest}>
                    {children}
                </MuiPaper>
            </ThemeProvider>
        );
    },
);

export default Paper;
