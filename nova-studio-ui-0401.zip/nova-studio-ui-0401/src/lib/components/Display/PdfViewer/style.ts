import type { SxProps, Theme } from '@mui/material';
import {
    alpha,
    buttonBaseClasses,
    inputBaseClasses,
    tabsClasses,
    typographyClasses,
    collapseClasses,
} from '@mui/material';
import { DesignTypeEnum } from '../../../utils/types/common';
import type { IPDFViewerProps } from './type';
import { treeItemClasses } from '@mui/x-tree-view';
import { generateClass } from '../../../utils/methods/design';
import { importantStyle } from '../../../utils/methods/style';

interface IParams extends Pick<IPDFViewerProps, 'design' | 'width'> {}

const themeConfig = {
    hambergerMenu: {
        width: {
            SET: '220px',
            Default: '245px',
        },
    },
    preview: {
        page: {
            width: '152px',
            height: '215px',
        },
    },
};

export const MuiPDFViewerSxProps = ({ design, width }: IParams): SxProps<Theme> => ({
    height: '100%',
    width: width || '100%',
    ...(design === DesignTypeEnum.SET && {
        border: (theme) => `1px solid ${theme.palette.grey[200]}`,
    }),
    [`& .${generateClass('PDFViewer-Document-wrapper')}`]: (theme) => ({
        boxShadow: `0px 1px 10px 0px ${alpha(theme.palette.common.black, 0.06)}`,
        backgroundColor: design === DesignTypeEnum.SET ? theme.palette.grey[200] : theme.palette.grey[100],
        '.PDFViewer-menu': {
            position: 'relative',
            backgroundColor: importantStyle(
                design === DesignTypeEnum.SET ? theme.palette.grey[200] : theme.palette.grey[100],
            ),
            boxShadow: `5px 0 5px -2px  ${alpha(theme.palette.common.black, 0.06)}`,
            zIndex: 1,
            width:
                design === DesignTypeEnum.SET
                    ? importantStyle(themeConfig.hambergerMenu.width.SET)
                    : importantStyle(themeConfig.hambergerMenu.width.Default),
            height: '100%',
            '.activePage': {
                '.react-pdf__Page__canvas': {
                    border: importantStyle(`2px solid ${theme.palette.secondary.main}`),
                },
            },
            '.react-pdf__Document': {
                minWidth: importantStyle(themeConfig.preview.page.width),
                minHeight: importantStyle(themeConfig.preview.page.height),
            },
            '.react-pdf__Page': {
                '.react-pdf__Page__canvas, .react-pdf__message': {
                    borderRadius: '1px',
                    border: `2px solid ${theme.palette.grey[200]}`,
                    width: importantStyle(themeConfig.preview.page.width),
                    height: importantStyle(themeConfig.preview.page.height),
                    backgroundColor: theme.palette.common.white,
                },
            },
            [`.${tabsClasses.root}`]: {
                mb: 0,
                ...(design === DesignTypeEnum.SET && {
                    borderBottom: 'none',
                }),
                [`.${tabsClasses.flexContainer}`]: {
                    backgroundColor: theme.palette.common.white,
                    [`.${typographyClasses.root}`]: {
                        color: theme.palette.secondary.main,
                    },
                    ...(design === DesignTypeEnum.SET && {
                        pt: '8px',
                    }),
                    [`.${buttonBaseClasses.root}`]: {
                        ...(design === DesignTypeEnum.Default && {
                            alignItems: 'center',
                            svg: {
                                width: '24px',
                                height: '24px',
                            },
                        }),
                        color: theme.palette.secondary.main,
                    },
                },
            },
            '.PDFViewer-menu-titles': {
                paddingTop: design === DesignTypeEnum.SET ? '6px' : '12px',
                [`.${treeItemClasses.root}`]: {
                    [`.${treeItemClasses.content}`]: {
                        display: 'flex',
                        alignItems: 'start',
                        paddingY: importantStyle(design === DesignTypeEnum.SET ? '3px' : '6px'),
                        [`.${treeItemClasses.iconContainer}`]: {
                            paddingTop: '3px',
                        },
                        [`.${treeItemClasses.label}`]: {
                            fontWeight: 'bold',
                        },
                        [`&.${treeItemClasses.selected}`]: {
                            backgroundColor:
                                design === DesignTypeEnum.SET ? theme.palette?.grey[300] : theme.palette?.grey[200],
                        },
                        [`&:not(.${treeItemClasses.disabled}):hover`]: {
                            backgroundColor:
                                design === DesignTypeEnum.SET ? theme.palette?.grey[300] : theme.palette?.grey[200],
                        },
                    },
                    [`.${collapseClasses.wrapperInner}`]: {
                        [`.${treeItemClasses.label}`]: {
                            fontWeight: importantStyle('normal'),
                        },
                    },
                },
            },
        },
    }),
    '& .react-pdf__Page__canvas': {
        boxShadow: (theme) => `0px 1px 10px 0px ${alpha(theme.palette.common.black, 0.06)}`,
    },
    '.showMenu': {
        '.react-pdf__Document': {
            width: `calc(100% - ${
                design === DesignTypeEnum.SET
                    ? themeConfig.hambergerMenu.width.SET
                    : themeConfig.hambergerMenu.width.Default
            } - 5px)`,
        },
    },
    '& .react-pdf__Document': {
        minHeight: '100%',
        height: '100%',
        ml: 'auto',
        mr: 'auto',
        backgroundColor: (theme) => (design === DesignTypeEnum.SET ? theme.palette.grey[200] : theme.palette.grey[100]),
        '.react-pdf__Page': {
            backgroundColor: (theme) =>
                importantStyle(design === DesignTypeEnum.SET ? theme.palette.grey[200] : theme.palette.grey[100]),
            display: 'flex',
            justifyContent: 'center',
            padding: design === DesignTypeEnum.SET ? '8px' : '16px',
            '.textLayer': {
                mx: 'auto',
                mt: design === DesignTypeEnum.SET ? '8px' : '16px',
            },
        },
        '.react-pdf__message': {
            padding: 1,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '100%',
            height: '100%',
            fontSize:
                design === DesignTypeEnum.Default
                    ? 'var(--field-label-font-size)'
                    : `var(--field-label-font-size-${DesignTypeEnum.SET})`,
        },
        '.react-pdf__Page__annotations': {
            left: '50%',
            transform: design === DesignTypeEnum.SET ? 'translate(-50%, 8px)' : 'translate(-50%, 16px)',
        },
    },

    [`& .${generateClass('PDFViewer-toolbar')}`]: (theme) => ({
        position: 'relative',
        zIndex: 2,
        display: 'flex',
        background: theme.palette.common.white,
        height: design === DesignTypeEnum.SET ? '40px' : '64px',
        boxShadow: `0 5px 5px -2px ${alpha(theme.palette.common.black, 0.06)}`,
        ...(design === DesignTypeEnum.SET && {
            borderBottom: `1px solid ${theme.palette.grey[200]}`,
        }),
        padding: design === DesignTypeEnum.SET ? '4px 8px' : '10px 20px',
        gap: design === DesignTypeEnum.SET ? '16px' : '32px',
        [`.${buttonBaseClasses.root}`]: {
            width: design === DesignTypeEnum.SET ? '20px' : '30px',
            height: design === DesignTypeEnum.SET ? '20px' : '30px',
            minWidth: design === DesignTypeEnum.SET ? '20px' : '30px',
            padding: 0,
            ...(design === DesignTypeEnum.Default && {
                svg: {
                    width: '24px',
                    height: '24px',
                },
            }),
        },
        '.menuButtons, .mainButtons, .zoomControl, .fileControl': {
            display: 'flex',
            alignItems: 'center',
        },
        '.mainButtons': {
            position: 'absolute',
            left: '50%',
            transform: design === DesignTypeEnum.SET ? 'translate(-50%, 4px)' : 'translate(-50%, 1px)',
            '.navButtons': {
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                gap: '4px',
                minWidth: design === DesignTypeEnum.SET ? '105px' : '140px',
                fontSize:
                    design === DesignTypeEnum.Default
                        ? 'var(--field-label-font-size)'
                        : `var(--field-label-font-size-${DesignTypeEnum.SET})`,
                input: {
                    textAlign: 'center',
                    height: design === DesignTypeEnum.SET ? '24px !important' : '30px !important',
                    width: design === DesignTypeEnum.SET ? '40px !important' : '52px !important',
                    border: `1px solid ${theme.palette.grey[400]}`,
                    borderRadius: 'var(--border-radius-2)',
                    '&:disabled': {
                        borderColor: theme.palette.lightGrey[400],
                        color: alpha(theme.palette.common.black, 0.6),
                    },
                    '&:focus': {
                        borderColor: theme.palette.secondary.main,
                    },
                },
            },
            '.zoomControl': {
                gap: '4px',
                [`.${inputBaseClasses.input}`]: {
                    padding: design === DesignTypeEnum.Default && importantStyle('3.5px 32px 3.5px 10.5px'),
                },
                [`.${typographyClasses.root}`]: {
                    color: theme.palette.primary.main,
                    fontWeight: 'normal',
                    width: '35px',
                    textAlign: 'center',
                },
            },
            '.separator': {
                width: '0.5px',
                height: design === DesignTypeEnum.SET ? '24px' : '44px',
                backgroundColor: theme.palette.primary.main,
                marginX: design === DesignTypeEnum.SET ? '16px' : '32px',
            },
        },
        '.fileControl': {
            gap: '10px',
        },
    }),
});
