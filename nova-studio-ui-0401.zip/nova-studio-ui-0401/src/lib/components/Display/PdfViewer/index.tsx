import type { FC, ReactNode } from 'react';
import { useState, useEffect, memo, useRef, Children, useMemo } from 'react';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import { Document, Page, pdfjs } from 'react-pdf';
import type { IPDFViewerComponentsProps, IPDFViewerModalProps, IPDFViewerProps, IToolbarButtonProps } from './type';
import { ActiveTabEnum } from './type';
import type { DesignType } from '../../..';
import {
    Button,
    Box,
    Tooltip,
    useTranslation,
    constants,
    useStorage,
    Modal,
    ModalTitle,
    ModalBody,
    useMeasure,
    printer,
    View,
    CustomScrollbar,
    Label,
    Collapse,
    TreeView,
    Tab,
    TabItem,
} from '../../..';
import { MuiPDFViewerSxProps } from './style';
import NumberFormat from 'react-number-format';
import {
    AddRounded,
    CloseRounded,
    FileCopyOutlined,
    FileDownloadOutlined,
    KeyboardArrowDownOutlined,
    KeyboardArrowRightOutlined,
    LocalPrintshopRounded,
    MenuRounded,
    MoreHorizRounded,
    NavigateNextOutlined,
    NavigateNextRounded,
    RemoveRounded,
    RotateLeftRounded,
    TocOutlined,
} from '@mui/icons-material';
import ThemeProvider from '../../App/ThemeProvider';
import {
    DesignTypeEnum,
    fileDownloader,
    generateClass,
    getComponentDesignProperty,
    getProviderTheme,
    isBase64,
    manageClassNames,
} from '../../../utils';
// @ts-ignore
import type { DocumentCallback } from 'react-pdf/dist/cjs/shared/types';
import { isArray, isNull, isNumber, isString, isUndefined, omit, sortBy, sum } from 'lodash';
import type { Theme } from '@mui/material';
import { Menu, MenuItem, tabsClasses } from '@mui/material';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

const zoomRatioArr = [
    { field: '%25', value: 0.5 },
    { field: '%50', value: 0.75 },
    { field: '%75', value: 1 },
    { field: '%100', value: 1.25 },
    { field: '%125', value: 1.5 },
    { field: '%150', value: 1.75 },
    { field: '%175', value: 2 },
    { field: '%200', value: 2.25 },
    { field: '%250', value: 2.5 },
];

const rotateArr = [270, 180, 90, 0];

const PdfViewer: FC<IPDFViewerProps> = ({
    source,
    browserViewer = false,
    className,
    design,
    height,
    id,
    modal = false,
    width,
    ...rest
}) => {
    const { t, locale } = useTranslation();
    const storageDesign = useStorage<DesignType>({ key: constants.key.PROVIDER_DESIGN, source: 'session' });
    const storageTheme = useStorage<Partial<Theme>>({ key: constants.key.PROVIDER_THEME, source: 'session' });
    const toolbarMeasure = useMeasure();
    const tabMeasure = useMeasure();
    const pdfViewerBoxRef = useRef<HTMLDivElement>(null);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const [rotate, setRotate] = useState<number>(0);
    const [pageNumber, setPageNumber] = useState(0);
    const [scale, setScale] = useState(zoomRatioArr[3].value);
    const [currentPage, setCurrentPage] = useState(1);
    const [showMenu, setShowMenu] = useState<boolean>(false);
    const [document, setDocument] = useState<any>(null);
    const [activeTab, setActiveTab] = useState<ActiveTabEnum>(ActiveTabEnum.Preview);
    const [outline, setOutline] = useState<any[]>([]);
    const pdfViewerClasses = {
        pageRendered: 'page-rendered',
    };
    const storeDesign = getComponentDesignProperty(design, storageDesign.newValue);
    const heightCalc = toolbarMeasure?.values?.height || 0 - 16;
    const hambergerMenuWidth = storeDesign === DesignTypeEnum.SET ? '220px' : '245px';

    const sourceTypeControl = (): string => {
        return isBase64(source) ? `data:application/pdf;base64,${source}` : source;
    };

    // eslint-disable-next-line react-hooks/exhaustive-deps
    const sourceData = useMemo(() => sourceTypeControl(), [source]);

    /* istanbul ignore next */
    const onDocumentLoadSuccess = async (doc: DocumentCallback) => {
        if (doc) {
            const out = await doc.getOutline();
            setOutline(out);
            setDocument(doc);
            setPageNumber(1);
            !browserViewer &&
                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps?.onLoadSuccess &&
                (rest as any)?.componentProps?.documentProps?.onLoadSuccess(doc);
        } else {
            setDocument(null);
            setPageNumber(0);
        }
    };

    /* istanbul ignore next */
    const changePage = (offset: number) => {
        setPageNumber((prevPageNumber) => prevPageNumber + offset);
    };

    /* istanbul ignore next */
    const previousPage = () => {
        changePage(-1);
    };

    /* istanbul ignore next */
    const nextPage = () => {
        changePage(1);
    };

    const handlePrint = () => {
        printer({
            printable: source,
            base64: isBase64(source) ? true : false,
            type: 'pdf',
        });
    };

    const getBlob = async (file: any) => {
        const response = await fetch(file);
        const blob = await response.blob();
        return blob;
    };

    /* istanbul ignore next */
    const onDownload = async () => {
        const pdfBlob = await getBlob(sourceData);
        fileDownloader({
            source: pdfBlob,
            fileName: ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.fileName || 'Document',
            sourceType: 'pdf',
        });
    };

    const getClassNameAndId = (): Pick<IPDFViewerProps, 'className' | 'id'> => {
        return {
            className: manageClassNames(generateClass('PDFViewer'), className),
            id,
        };
    };

    useEffect(() => {
        if (isNull(source) || isUndefined(source)) {
            setPageNumber(0);
            setDocument(null);
            scale !== zoomRatioArr[3].value && setScale(zoomRatioArr[3].value);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [source]);

    const toolbarData: IToolbarButtonProps[] = [
        {
            label:
                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools?.save?.label ||
                t(locale.buttons.save),
            icon: <FileDownloadOutlined fontSize="small" />,
            onClick: async (e): Promise<void> => {
                await onDownload();
                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.onSave &&
                    (rest as any)?.componentProps?.toolbarProps?.onSave(e);
            },
            disabled: !document?.numPages,
            ...((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools?.save,
        },
        {
            label:
                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools?.print?.label ||
                t(locale.buttons.print),
            icon: <LocalPrintshopRounded fontSize="small" />,
            onClick: (): void => handlePrint(),
            disabled: !document?.numPages,
            ...((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools?.print,
        },
        ...(((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.customTools?.map((item) => ({
            ...item,
            onClick: (): void => item?.onClick?.(document),
            disabled: !document?.numPages,
        })) || []),
    ];

    const usedOrders = sortBy(
        toolbarData.map((v) => v?.order).filter((order) => isNumber(order)),
        ['order'],
    );

    const getNextOrder = () => {
        let nextAvaibleOrder = 1;
        while (usedOrders?.includes(nextAvaibleOrder)) {
            nextAvaibleOrder++;
        }
        usedOrders.push(nextAvaibleOrder);
        return nextAvaibleOrder;
    };

    const filteredToolbarButtons = toolbarData
        ?.filter((item) => !item?.passive)
        ?.map((item) => ({
            ...item,
            order: item.order || getNextOrder(),
        }))
        ?.sort((a, b) => a?.order - b?.order);

    const renderMoreActionsMenu = () => {
        return (
            <Menu
                className={generateClass('PDFViewer-toolbar-more-actions-menu')}
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                }}
                transformOrigin={{
                    horizontal: 'right',
                    vertical: 'top',
                }}
                slotProps={{ paper: { className: generateClass('PDFViewer-toolbar-more-actions-menu') } }}>
                {Children.toArray(
                    filteredToolbarButtons.slice(3)?.map((item) => {
                        if (!item.passive) {
                            return (
                                <MenuItem
                                    className={generateClass('PDFViewer-toolbar-more-actions-menu-item')}
                                    onClick={item.onClick}
                                    disabled={item.disabled}
                                    sx={{
                                        minWidth: storeDesign === DesignTypeEnum.SET ? '150px' : '200px',
                                        padding: storeDesign === DesignTypeEnum.SET ? '8px 12px' : '12px 16px',
                                        gap: '10px',
                                        fontSize:
                                            storeDesign === DesignTypeEnum.SET
                                                ? `var(--field-label-font-size-${DesignTypeEnum.SET})`
                                                : 'calc(var(--field-label-font-size) + 2px) !important',
                                        svg: {
                                            fontSize: storeDesign === DesignTypeEnum.SET ? '16px' : '24px',
                                            color: (theme) => theme.palette.secondary.main,
                                        },
                                    }}>
                                    {item.icon}
                                    {item.label}
                                </MenuItem>
                            );
                        }
                        return null;
                    }),
                )}
            </Menu>
        );
    };

    const renderPreview = () => {
        return (
            <CustomScrollbar
                height={
                    storeDesign === DesignTypeEnum.SET
                        ? `calc(100% - ${sum([tabMeasure?.values?.height || 0])}px)`
                        : `calc(100% - ${sum([tabMeasure?.values?.height])}px)`
                }
                thickness={4}
                style={{ display: activeTab === ActiveTabEnum.Titles ? 'none' : 'block' }}>
                <Document
                    file={sourceData}
                    onLoadSuccess={({ numPages }) => {
                        if (currentPage !== numPages) {
                            setCurrentPage(numPages);
                        }
                    }}>
                    {Array.from(new Array(currentPage), (_, index) => (
                        <Box key={index + 1} onClick={() => setPageNumber(index + 1)} sx={{ cursor: 'pointer' }}>
                            <Page
                                pageNumber={index + 1}
                                renderTextLayer={false}
                                renderAnnotationLayer={false}
                                {...(pageNumber === index + 1 && { className: 'activePage' })}
                            />
                        </Box>
                    ))}
                </Document>
            </CustomScrollbar>
        );
    };

    const renderTitles = (titles: any) => {
        if (titles) {
            return (
                <CustomScrollbar
                    height={
                        storeDesign === DesignTypeEnum.SET
                            ? `calc(100% - ${sum([tabMeasure?.values?.height || 0])}px)`
                            : `calc(100% - ${sum([tabMeasure?.values?.height])}px)`
                    }
                    thickness={4}>
                    <TreeView
                        className="PDFViewer-menu-titles"
                        options={{
                            data: titles,
                            displayChildren: 'items',
                            displayId: 'title',
                            displayLabel: 'title',
                        }}
                        expandIcon={KeyboardArrowRightOutlined}
                        collapseIcon={KeyboardArrowDownOutlined}
                        onSelect={async (treeItem: any) => {
                            let ref;
                            const dest = treeItem[0].dest;
                            if (isArray(dest)) {
                                ref = dest[0];
                            } else if (isString(dest)) {
                                const getDest = await document.getDestination(dest);
                                ref = getDest[0];
                            }

                            if (!ref) return;

                            const pageIndex = await document.getPageIndex(ref);
                            setPageNumber(pageIndex + 1);
                        }}
                    />
                </CustomScrollbar>
            );
        }
        return null;
    };

    const renderMenu = () => {
        return (
            <Collapse in={showMenu} orientation="horizontal">
                <Box className="PDFViewer-menu">
                    <Tab
                        value={activeTab}
                        onChange={(val) => setActiveTab(val)}
                        ref={tabMeasure.ref}
                        variant="fullWidth"
                        sx={{
                            ...(Boolean(outline) === false && {
                                pointerEvents: 'none',
                                [`.${tabsClasses.indicator}`]: {
                                    display: 'none',
                                },

                                [`.${generateClass('menu-tab-titles')} `]: {
                                    background: 'red',
                                    display: 'none',
                                },
                            }),
                        }}>
                        <TabItem
                            text={
                                <Box gap="4px" display="flex">
                                    <FileCopyOutlined fontSize="small" />
                                    <Label text={t(locale.buttons.preview)} />
                                </Box>
                            }
                            value={ActiveTabEnum.Preview}
                        />
                        <TabItem
                            className={generateClass('menu-tab-titles')}
                            text={
                                <Box gap="4px" display="flex">
                                    <TocOutlined fontSize="small" />
                                    <Label text={t(locale.buttons.titles)} />
                                </Box>
                            }
                            value={ActiveTabEnum.Titles}
                        />
                    </Tab>
                    {renderPreview()}
                    {activeTab === ActiveTabEnum.Titles && outline && renderTitles(outline)}
                </Box>
            </Collapse>
        );
    };

    /* istanbul ignore next */
    const renderToolBar = () => {
        return (
            <Box ref={toolbarMeasure.ref} className={generateClass('PDFViewer-toolbar')}>
                <Box mr="auto" className="menuButtons">
                    <Tooltip
                        title={
                            ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools
                                ?.previousPage?.label || t(locale.buttons.menu)
                        }>
                        <Button
                            variant="text"
                            icon={showMenu ? <CloseRounded fontSize="small" /> : <MenuRounded fontSize="small" />}
                            disabled={!document?.numPages}
                            onClick={() => setShowMenu((prevState) => !prevState)}
                        />
                    </Tooltip>
                </Box>
                <Box className="mainButtons">
                    <Box className="navButtons">
                        <Tooltip
                            title={
                                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools
                                    ?.previousPage?.label || t(locale.buttons.previousPage)
                            }>
                            <Button
                                variant="text"
                                icon={<NavigateNextRounded fontSize="small" sx={{ transform: 'rotate(180deg)' }} />}
                                disabled={pageNumber <= 1}
                                onClick={previousPage}
                            />
                        </Tooltip>
                        <NumberFormat
                            className="goToPageInput"
                            allowNegative={false}
                            decimalScale={0}
                            disabled={!document?.numPages}
                            value={pageNumber}
                            onValueChange={(values) => {
                                setPageNumber(
                                    values?.floatValue === 0 || values?.floatValue === undefined
                                        ? 0
                                        : values.floatValue >= document?.numPages
                                          ? document?.numPages
                                          : values?.floatValue,
                                );
                            }}
                        />
                        <Box> / {document?.numPages || 0}</Box>
                        <Tooltip
                            title={
                                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools
                                    ?.nextPage?.label || t(locale.buttons.nextPage)
                            }>
                            <Button
                                variant="text"
                                icon={<NavigateNextOutlined fontSize="small" />}
                                disabled={
                                    pageNumber >= document?.numPages || !document?.numPages || document?.numPages === 1
                                        ? true
                                        : false
                                }
                                onClick={nextPage}
                            />
                        </Tooltip>
                    </Box>
                    <Box className="separator" />
                    <Box className="zoomControl">
                        <Tooltip
                            title={
                                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools
                                    ?.zoomOut?.label || t(locale.buttons.zoomOut)
                            }>
                            <Button
                                variant="text"
                                icon={<RemoveRounded fontSize="small" />}
                                disabled={Boolean(!document?.numPages || scale <= zoomRatioArr[0].value)}
                                onClick={() => {
                                    let zoom: number;
                                    if (scale) {
                                        zoom =
                                            scale -
                                            (((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps
                                                ?.zoomIncrement || 0.25);
                                    }
                                    setScale(() => (scale <= zoomRatioArr[0].value ? scale : zoom));
                                }}
                            />
                        </Tooltip>
                        <Label
                            text={zoomRatioArr.find((item) => item.value === scale)?.field || zoomRatioArr[3].field}
                            fontWeight="normal"
                            color={(theme) => theme.palette.primary.main}
                        />
                        <Tooltip
                            title={
                                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools
                                    ?.zoomIn?.label || t(locale.buttons.zoomIn)
                            }>
                            <Button
                                variant="text"
                                icon={<AddRounded fontSize="small" />}
                                disabled={Boolean(!document?.numPages || scale >= 2.5)}
                                onClick={() => {
                                    let zoom: number = scale;
                                    if (scale) {
                                        zoom =
                                            scale +
                                            (((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps
                                                ?.zoomIncrement || 0.25);
                                    }
                                    setScale(scale >= zoomRatioArr[8].value ? scale : zoom);
                                }}
                            />
                        </Tooltip>
                    </Box>
                    <Box className="separator" />
                    <Box>
                        <Tooltip
                            title={
                                (((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools
                                    ?.rotate as ReactNode) || t(locale.buttons.rotate)
                            }>
                            <Button
                                variant="text"
                                icon={<RotateLeftRounded fontSize="small" />}
                                disabled={!document?.numPages}
                                onClick={() => {
                                    const currentIndex = rotateArr.indexOf(rotate);
                                    const nextIndex = (currentIndex + 1) % rotateArr.length;
                                    setRotate(rotateArr[nextIndex]);
                                }}
                            />
                        </Tooltip>
                    </Box>
                </Box>
                <Box className="fileControl" ml="auto">
                    {Children.toArray(
                        filteredToolbarButtons?.slice(0, filteredToolbarButtons?.length > 4 ? 3 : 4).map((item) => {
                            if (!item.passive) {
                                return (
                                    <Tooltip title={item.label}>
                                        <Button
                                            variant="text"
                                            icon={item.icon}
                                            onClick={item.onClick}
                                            disabled={item.disabled}
                                        />
                                    </Tooltip>
                                );
                            }
                            return null;
                        }),
                    )}
                    <View show={Boolean(filteredToolbarButtons?.length > 4)}>
                        <Tooltip
                            title={
                                ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.toolbarProps?.tools?.more
                                    ?.label || t(locale.buttons.more)
                            }>
                            <Button
                                variant="text"
                                icon={<MoreHorizRounded fontSize="small" />}
                                onClick={(e) => setAnchorEl(e.currentTarget)}
                                disabled={Boolean(!document?.numPages)}
                            />
                        </Tooltip>
                        {renderMoreActionsMenu()}
                    </View>
                </Box>
            </Box>
        );
    };

    const renderCustomView = () => {
        return (
            <ThemeProvider
                design={getComponentDesignProperty(design, storageDesign.newValue)}
                theme={getProviderTheme(storageTheme.newValue)}>
                <Box
                    {...getClassNameAndId()}
                    ref={pdfViewerBoxRef}
                    sx={
                        getComponentDesignProperty(design, storageDesign.newValue) && {
                            ...(MuiPDFViewerSxProps({
                                design: getComponentDesignProperty(design, storageDesign.newValue),
                                width,
                            }) as any),
                            ...(rest as any)?.sx,
                        }
                    }>
                    {renderToolBar()}
                    <Box
                        className={manageClassNames(generateClass('PDFViewer-Document-wrapper'), {
                            'show-menu': showMenu,
                        })}
                        height={
                            height
                                ? typeof height === 'number'
                                    ? height - heightCalc
                                    : `calc(${height} - ${heightCalc}px)`
                                : `calc(100% - ${heightCalc}px)`
                        }
                        width={width}
                        display="flex">
                        {renderMenu()}
                        <Box height="100%" width={showMenu ? `calc(100% - ${hambergerMenuWidth} - 2px)` : '100%'}>
                            <CustomScrollbar height="100%" width="100%" thickness={4}>
                                <Document
                                    {...((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps}
                                    className={manageClassNames(
                                        generateClass('PDFViewer-Document'),
                                        ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps
                                            ?.className,
                                    )}
                                    noData={
                                        ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps
                                            ?.noData || t(locale.contents.PDFFileWasNotTransmitted)
                                    }
                                    file={sourceData}
                                    error={
                                        ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps
                                            ?.error || t(locale.contents.failedToLoadPDFFile)
                                    }
                                    loading={
                                        ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps
                                            ?.loading || t(locale.contents.loading)
                                    }
                                    onLoadSuccess={onDocumentLoadSuccess}>
                                    <Page
                                        {...((rest as any)?.componentProps as IPDFViewerComponentsProps)?.pageProps}
                                        className={manageClassNames(
                                            generateClass('PDFViewer-Page'),
                                            ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.pageProps
                                                ?.className,
                                        )}
                                        noData=""
                                        onRenderSuccess={() => {
                                            if (pdfViewerBoxRef?.current) {
                                                pdfViewerBoxRef?.current?.classList?.add?.(
                                                    pdfViewerClasses.pageRendered,
                                                );
                                            }
                                        }}
                                        onRenderError={() => {
                                            if (pdfViewerBoxRef?.current) {
                                                pdfViewerBoxRef?.current?.classList &&
                                                    pdfViewerBoxRef?.current?.classList?.contains(
                                                        pdfViewerClasses.pageRendered,
                                                    ) &&
                                                    pdfViewerBoxRef?.current?.classList?.remove(
                                                        pdfViewerClasses.pageRendered,
                                                    );
                                            }
                                        }}
                                        rotate={
                                            ((rest as any)?.componentProps as IPDFViewerComponentsProps)?.documentProps
                                                ?.rotate || rotate
                                        }
                                        scale={scale}
                                        pageNumber={pageNumber}
                                    />
                                </Document>
                            </CustomScrollbar>
                        </Box>
                    </Box>
                </Box>
            </ThemeProvider>
        );
    };

    const renderBrowserView = () => {
        return (
            <object
                {...getClassNameAndId()}
                data={sourceData}
                type="application/pdf"
                width={width || '100%'}
                height={height || '100%'}
            />
        );
    };

    const renderPDFViewer = () => {
        return browserViewer ? renderBrowserView() : renderCustomView();
    };

    const renderPDFViewerModal = () => {
        return (
            <Modal
                className={generateClass('PDFViewer-Modal')}
                fullWidth
                fullHeight={!height}
                sx={((rest as any).modalProps as IPDFViewerModalProps)?.sx}
                show={((rest as any).modalProps as IPDFViewerModalProps)?.show}
                {...omit((rest as any).modalProps as IPDFViewerModalProps, [
                    'modalTitleProps',
                    'modalBodyProps',
                    'sx',
                    'show',
                ])}>
                <ModalTitle {...omit(((rest as any).modalProps as IPDFViewerModalProps)?.modalTitleProps, ['title'])}>
                    {((rest as any).modalProps as IPDFViewerModalProps)?.title || ''}
                </ModalTitle>
                <ModalBody
                    {...omit(((rest as any).modalProps as IPDFViewerModalProps)?.modalBodyProps, ['sx'])}
                    sx={{
                        p: constants.design.grid.spacing.common[
                            getComponentDesignProperty(design, storageDesign.newValue)
                        ].unit,
                        ...((rest as any).modalProps as IPDFViewerModalProps)?.modalBodyProps?.sx,
                    }}>
                    <Box
                        height="100%"
                        pt={
                            constants.design.grid.spacing.common[
                                getComponentDesignProperty(design, storageDesign.newValue)
                            ].unit
                        }>
                        {renderPDFViewer()}
                    </Box>
                </ModalBody>
            </Modal>
        );
    };

    return modal ? renderPDFViewerModal() : renderPDFViewer();
};

export default memo(PdfViewer);
