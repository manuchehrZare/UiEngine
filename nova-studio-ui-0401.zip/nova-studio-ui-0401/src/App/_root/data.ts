// Form Imports
import AutocompletePage from '../../pages/Components/Form/Autocomplete';
import ButtonPage from '../../pages/Components/Form/Button';
import ButtonGroupPage from '../../pages/Components/Form/ButtonGroup';
import ButtonWithIconPage from '../../pages/Components/Form/ButtonWithIcon';
import CheckBoxPage from '../../pages/Components/Form/Checkbox';
import DatePickerPage from '../../pages/Components/Form/DatePicker';
import DateTimePickerPage from '../../pages/Components/Form/DateTimePicker';
import FileSelectorPage from '../../pages/Components/Form/FileSelector';
import InputPage from '../../pages/Components/Form/Input';
import NumberInputPage from '../../pages/Components/Form/NumberInput';
import RadioPage from '../../pages/Components/Form/Radio';
import RangeInputPage from '../../pages/Components/Form/RangeInput';
import RichEditorPage from '../../pages/Components/Form/RichEditor';
import SelectPage from '../../pages/Components/Form/Select';
import SwitchPage from '../../pages/Components/Form/Switch';
import TimePickerPage from '../../pages/Components/Form/TimePicker';
import UploadPage from '../../pages/Components/Form/Upload';

// Display Imports
import AccordionPage from '../../pages/Components/Display/Accordion';
import AlertPage from '../../pages/Components/Display/Alert';
import BreadcrumbsPage from '../../pages/Components/Display/Breadcrumbs';
import BreakPage from '../../pages/Components/Display/Break';
import CarouselPage from '../../pages/Components/Display/Carousel';
import BarChartPage from '../../pages/Components/Display/Chart/BarChart';
import LineChartPage from '../../pages/Components/Display/Chart/LineChart';
import PieChartPage from '../../pages/Components/Display/Chart/PieChart';
import ChipPage from '../../pages/Components/Display/Chip';
import CollapsePage from '../../pages/Components/Display/Collapse';
import ConfirmPage from '../../pages/Components/Display/Confirm';
import CustomScrollbarPage from '../../pages/Components/Display/CustomScrollbar';
import DataGridPage from '../../pages/Components/Display/DataGrid';
import DividerPage from '../../pages/Components/Display/Divider';
import EmptyPage from '../../pages/Components/Display/Empty';
import GridPage from '../../pages/Components/Display/Grid';
import KeyValueListPage from '../../pages/Components/Display/KeyValueList';
import LabelPage from '../../pages/Components/Display/Label';
import LoadingModalPage from '../../pages/Components/Display/LoadingModal';
import MasonryPage from '../../pages/Components/Display/Masonry';
import ModalPage from '../../pages/Components/Display/Modal';
import NavPage from '../../pages/Components/Display/Nav';
import NavContainerPage from '../../pages/Components/Display/NavContainer';
import NumberFormatPage from '../../pages/Components/Display/NumberFormat';
import PaperPage from '../../pages/Components/Display/Paper';
import PdfViewerPage from '../../pages/Components/Display/PdfViewer';
import PopupPage from '../../pages/Components/Display/Popup';
import ProgressPage from '../../pages/Components/Display/Progress';
import RatingPage from '../../pages/Components/Display/Rating';
import StepperPage from '../../pages/Components/Display/Stepper';
import TabPage from '../../pages/Components/Display/Tab';
import TablePage from '../../pages/Components/Display/Table';
import TooltipPage from '../../pages/Components/Display/Tooltip';
import TreeViewPage from '../../pages/Components/Display/TreeView';
import VRKeyboardPage from '../../pages/Components/Display/VRKeyboard';
import PhoneNumberFormatterPage from '../../pages/Utils/methods/string/phoneNumberFormatter';

// Others Imports
import CardNumberPage from '../../pages/Components/Others/CardNumber';
import CurrencyPage from '../../pages/Components/Others/Currency';
import IBANPage from '../../pages/Components/Others/IBAN';
import PhoneNumberPage from '../../pages/Components/Others/PhoneNumber';

// Hooks Imports
import UseArrayFieldPage from '../../pages/Hooks/useArrayField';
import UseAudioPage from '../../pages/Hooks/useAudio';
import UseComputedStylesPage from '../../pages/Hooks/useComputedStyles';
import UseDevicePage from '../../pages/Hooks/useDevice';
import UseFormPage from '../../pages/Hooks/useForm';
import UseMeasurePage from '../../pages/Hooks/useMeasure';
import UsePrintPage from '../../pages/Hooks/usePrint';
import UseTimerPage from '../../pages/Hooks/useTimer';
import UseWatchPage from '../../pages/Hooks/useWatch';
import UseWidthPage from '../../pages/Hooks/useWidth';
import UseWindowOpenPage from '../../pages/Hooks/useWindowOpen';
import useCapsLockDetectorPage from '../../pages/Hooks/useCapsLockDetector';
import useClipboardPage from '../../pages/Hooks/useClipboard';
import useDebouncePage from '../../pages/Hooks/useDebounce';
import useIsFirstRenderPage from '../../pages/Hooks/useIsFirstRender';
import useNowPage from '../../pages/Hooks/useNow';
import useReRenderPage from '../../pages/Hooks/useReRender';
import useStoragePage from '../../pages/Hooks/useStorage';
import useTitlePage from '../../pages/Hooks/useTitle';

// Utils Imports
import AsyncForEachPage from '../../pages/Utils/methods/common/asyncForEach';
import Base64DecryptionPage from '../../pages/Utils/methods/crypto/base64/base64Decryption';
import Base64EncryptionPage from '../../pages/Utils/methods/crypto/base64/base64Encryption';
import BooleanValidationsPage from '../../pages/Utils/validations/booleanValidations';
import CardNumberFormatterPage from '../../pages/Utils/methods/string/cardNumberFormatter';
import CleanDeepPage from '../../pages/Utils/methods/common/cleanDeep';
import ConfirmMethodPage from '../../pages/Utils/methods/confirm';
import CurrencyMethodPage from '../../pages/Utils/methods/currency';
import DateValidationsPage from '../../pages/Utils/validations/dateValidations';
import DeepCopyPage from '../../pages/Utils/methods/common/deepCopy';
import DeepKeysAsArrayPage from '../../pages/Utils/methods/keys/deepKeysAsArray';
import DeepKeysAsObjectPage from '../../pages/Utils/methods/keys/deepKeysAsObject';
import DeepMergePage from '../../pages/Utils/methods/deepmerge';
import ExcelToJsonPage from '../../pages/Utils/methods/file/import/excelToJson';
import ExportPDFPage from '../../pages/Utils/methods/file/export/exportPDF';
import ExportTablePage from '../../pages/Utils/methods/file/export/exportTable';
import ExportWordPage from '../../pages/Utils/methods/file/export/exportWord';
import FileDownloaderPage from '../../pages/Utils/methods/file/fileDownloader';
import FindDeepPage from '../../pages/Utils/methods/common/findDeep';
import GetComputedStylesPage from '../../pages/Utils/methods/style/getComputedStyles';
import GetCookiePage from '../../pages/Utils/methods/cookies/getCookie';
import GetDateFromExcelDatePage from '../../pages/Utils/methods/file/excelDate/getDateFromExcelDate';
import GetExcelDateFromDatePage from '../../pages/Utils/methods/file/excelDate/getExcelDateFromDate';
import GetFileSizePage from '../../pages/Utils/methods/file/getFileSize';
import GetLocalStorageItemPage from '../../pages/Utils/methods/storage/getLocalStorageItem';
import GetNowPage from '../../pages/Utils/methods/time/getNow';
import GetSessionStorageItemPage from '../../pages/Utils/methods/storage/getSessionStorageItem';
import GroupStringPage from '../../pages/Utils/methods/string/groupString';
import HelperFormPropsPage from '../../pages/Utils/types/HelperFormProps';
import IBANMethodPage from '../../pages/Utils/methods/string/iban';
import IsBase64Page from '../../pages/Utils/methods/crypto/base64/isBase64';
import IsNumericPage from '../../pages/Utils/methods/number/isNumeric';
import IsParsableToJsonPage from '../../pages/Utils/methods/common/isParsableToJson';
import JsToXmlPage from '../../pages/Utils/methods/common/jsToXml';
import JsonToQueryStringPage from '../../pages/Utils/methods/query/jsonToQueryString';
import MessagePage from '../../pages/Utils/methods/message';
import MillisecondsToTimePage from '../../pages/Utils/methods/time/millisecondsToTime';
import NumberDateValidationsPage from '../../pages/Utils/validations/numberDateValidations';
import NumberFormatMethodPage from '../../pages/Utils/methods/number/numberFormat';
import NumberValidationsPage from '../../pages/Utils/validations/numberValidations';
import OtherValidationsPage from '../../pages/Utils/validations/otherValidations';
import PaginationPage from '../../pages/Components/Display/Pagination';
import PrinterPage from '../../pages/Utils/methods/printer';
import ProviderLoadingMethodsPage from '../../pages/Utils/methods/loading/ProviderLoadingMethods';
import QueryStringToJsonPage from '../../pages/Utils/methods/query/queryStringToJson';
import RandomNumberPage from '../../pages/Utils/methods/number/randomNumber';
import RemoveCookiePage from '../../pages/Utils/methods/cookies/removeCookie';
import RemoveLocalStorageItemPage from '../../pages/Utils/methods/storage/removeLocalStorageItem';
import RemoveSessionStorageItemPage from '../../pages/Utils/methods/storage/removeSessionStorageItem';
import ReplaceTRtoENCharsPage from '../../pages/Utils/methods/string/replaceTRtoENChars';
import SanitizeHTMLPage from '../../pages/Utils/methods/HTML/sanitizeHTML';
import ScrollToElementPage from '../../pages/Utils/methods/scroll/scrollToElement';
import ScrollToTopPage from '../../pages/Utils/methods/scroll/scrollToTop';
import SetCookiePage from '../../pages/Utils/methods/cookies/setCookie';
import SetLocalStorageItemPage from '../../pages/Utils/methods/storage/setLocalStorageItem';
import SetSessionStorageItemPage from '../../pages/Utils/methods/storage/setSessionStorageItem';
import SleepPage from '../../pages/Utils/methods/common/sleep';
import StringHTMLToJSXPage from '../../pages/Utils/methods/HTML/stringHTMLToJSX';
import StringValidationsPage from '../../pages/Utils/validations/stringValidations';
import StripHtmlFromTextPage from '../../pages/Utils/methods/common/stripHtmlFromText';
import ThemeProviderMethodsPage from '../../pages/Utils/methods/theme';
import TimeToMillisecondsPage from '../../pages/Utils/methods/time/timeToMilliseconds';
import TxtToStringPage from '../../pages/Utils/methods/file/import/txtToString';
import XmlToJsonPage from '../../pages/Utils/methods/common/xmlToJs';

// Example Imports
import GeneralExamplePage from '../../pages/_Example/General';

export enum MenuGroupEnum {
    DISPLAY = 'DISPLAY',
    EXAMPLE = 'EXAMPLE',
    FORM = 'FORM',
    HOOKS = 'HOOKS',
    OTHERS = 'OTHERS',
    UTILS = 'UTILS',
}

export interface IMenuData {
    element: any;
    group: keyof typeof MenuGroupEnum;
    text: string;
}

interface IMenu {
    display: IMenuData[];
    example: IMenuData[];
    form: IMenuData[];
    hooks: IMenuData[];
    others: IMenuData[];
    utils: IMenuData[];
}

export const menu: IMenu = {
    form: [
        {
            text: 'Autocomplete',
            group: MenuGroupEnum.FORM,
            element: AutocompletePage,
        },
        {
            text: 'Button',
            group: MenuGroupEnum.FORM,
            element: ButtonPage,
        },
        {
            text: 'Button with Icon',
            group: MenuGroupEnum.FORM,
            element: ButtonWithIconPage,
        },
        {
            text: 'Button Group',
            group: MenuGroupEnum.FORM,
            element: ButtonGroupPage,
        },
        {
            text: 'Checkbox',
            group: MenuGroupEnum.FORM,
            element: CheckBoxPage,
        },
        {
            text: 'DatePicker',
            group: MenuGroupEnum.FORM,
            element: DatePickerPage,
        },
        {
            text: 'DateTimePicker',
            group: MenuGroupEnum.FORM,
            element: DateTimePickerPage,
        },
        {
            text: 'TimePicker',
            group: MenuGroupEnum.FORM,
            element: TimePickerPage,
        },
        {
            text: 'Input',
            group: MenuGroupEnum.FORM,
            element: InputPage,
        },
        {
            text: 'NumberInput',
            group: MenuGroupEnum.FORM,
            element: NumberInputPage,
        },
        {
            text: 'Radio',
            group: MenuGroupEnum.FORM,
            element: RadioPage,
        },
        {
            text: 'RangeInput',
            group: MenuGroupEnum.FORM,
            element: RangeInputPage,
        },
        {
            text: 'RichEditor',
            group: MenuGroupEnum.FORM,
            element: RichEditorPage,
        },
        {
            text: 'Select',
            group: MenuGroupEnum.FORM,
            element: SelectPage,
        },
        {
            text: 'Switch',
            group: MenuGroupEnum.FORM,
            element: SwitchPage,
        },
        {
            text: 'Upload',
            group: MenuGroupEnum.FORM,
            element: UploadPage,
        },
        {
            text: 'FileSelector',
            group: MenuGroupEnum.FORM,
            element: FileSelectorPage,
        },
    ],
    display: [
        {
            text: 'Accordion',
            group: MenuGroupEnum.DISPLAY,
            element: AccordionPage,
        },
        {
            text: 'Alert',
            group: MenuGroupEnum.DISPLAY,
            element: AlertPage,
        },
        {
            text: 'Breadcrumbs',
            group: MenuGroupEnum.DISPLAY,
            element: BreadcrumbsPage,
        },
        {
            text: 'Break',
            group: MenuGroupEnum.DISPLAY,
            element: BreakPage,
        },
        {
            text: 'Carousel',
            group: MenuGroupEnum.DISPLAY,
            element: CarouselPage,
        },
        {
            text: 'Chart - Bar Chart',
            group: MenuGroupEnum.DISPLAY,
            element: BarChartPage,
        },
        {
            text: 'Chart - Line Chart',
            group: MenuGroupEnum.DISPLAY,
            element: LineChartPage,
        },
        {
            text: 'Chart - Pie Chart',
            group: MenuGroupEnum.DISPLAY,
            element: PieChartPage,
        },
        {
            text: 'Chip',
            group: MenuGroupEnum.DISPLAY,
            element: ChipPage,
        },
        {
            text: 'Collapse',
            group: MenuGroupEnum.DISPLAY,
            element: CollapsePage,
        },
        {
            text: 'Confirm',
            group: MenuGroupEnum.DISPLAY,
            element: ConfirmPage,
        },
        {
            text: 'CustomScrollbar',
            group: MenuGroupEnum.DISPLAY,
            element: CustomScrollbarPage,
        },
        {
            text: 'DataGrid',
            group: MenuGroupEnum.DISPLAY,
            element: DataGridPage,
        },
        {
            text: 'Divider',
            group: MenuGroupEnum.DISPLAY,
            element: DividerPage,
        },
        {
            text: 'Empty Box',
            group: MenuGroupEnum.DISPLAY,
            element: EmptyPage,
        },
        {
            text: 'Grid',
            group: MenuGroupEnum.DISPLAY,
            element: GridPage,
        },
        {
            text: 'KeyValueList',
            group: MenuGroupEnum.DISPLAY,
            element: KeyValueListPage,
        },
        {
            text: 'Label',
            group: MenuGroupEnum.DISPLAY,
            element: LabelPage,
        },
        {
            text: 'Loading Modal',
            group: MenuGroupEnum.DISPLAY,
            element: LoadingModalPage,
        },
        {
            text: 'Masonry',
            group: MenuGroupEnum.DISPLAY,
            element: MasonryPage,
        },
        {
            text: 'Modal',
            group: MenuGroupEnum.DISPLAY,
            element: ModalPage,
        },
        {
            text: 'Nav',
            group: MenuGroupEnum.DISPLAY,
            element: NavPage,
        },
        {
            text: 'NavContainer',
            group: MenuGroupEnum.DISPLAY,
            element: NavContainerPage,
        },
        {
            text: 'NumberFormat',
            group: MenuGroupEnum.DISPLAY,
            element: NumberFormatPage,
        },
        {
            text: 'Pagination',
            group: MenuGroupEnum.DISPLAY,
            element: PaginationPage,
        },
        {
            text: 'Paper',
            group: MenuGroupEnum.DISPLAY,
            element: PaperPage,
        },
        {
            text: 'PDF Viewer',
            group: MenuGroupEnum.DISPLAY,
            element: PdfViewerPage,
        },
        {
            text: 'Popup',
            group: MenuGroupEnum.DISPLAY,
            element: PopupPage,
        },
        {
            text: 'Progress',
            group: MenuGroupEnum.DISPLAY,
            element: ProgressPage,
        },
        {
            text: 'Rating',
            group: MenuGroupEnum.DISPLAY,
            element: RatingPage,
        },
        {
            text: 'Stepper',
            group: MenuGroupEnum.DISPLAY,
            element: StepperPage,
        },
        {
            text: 'Tab',
            group: MenuGroupEnum.DISPLAY,
            element: TabPage,
        },
        {
            text: 'Table',
            group: MenuGroupEnum.DISPLAY,
            element: TablePage,
        },
        {
            text: 'TreeView',
            group: MenuGroupEnum.DISPLAY,
            element: TreeViewPage,
        },
        {
            text: 'Tooltip',
            group: MenuGroupEnum.DISPLAY,
            element: TooltipPage,
        },
        {
            text: 'VRKeyboard',
            group: MenuGroupEnum.DISPLAY,
            element: VRKeyboardPage,
        },
    ],
    others: [
        {
            text: 'CardNumber',
            group: MenuGroupEnum.OTHERS,
            element: CardNumberPage,
        },
        {
            text: 'PhoneNumber',
            group: MenuGroupEnum.OTHERS,
            element: PhoneNumberPage,
        },
        {
            text: 'Currency',
            group: MenuGroupEnum.OTHERS,
            element: CurrencyPage,
        },
        {
            text: 'IBAN',
            group: MenuGroupEnum.OTHERS,
            element: IBANPage,
        },
    ],
    hooks: [
        {
            text: 'useArrayField',
            group: MenuGroupEnum.HOOKS,
            element: UseArrayFieldPage,
        },
        {
            text: 'useAudio',
            group: MenuGroupEnum.HOOKS,
            element: UseAudioPage,
        },
        {
            text: 'useCapsLockDetector',
            group: MenuGroupEnum.HOOKS,
            element: useCapsLockDetectorPage,
        },
        {
            text: 'useClipboard',
            group: MenuGroupEnum.HOOKS,
            element: useClipboardPage,
        },
        {
            text: 'useDebounce',
            group: MenuGroupEnum.HOOKS,
            element: useDebouncePage,
        },
        {
            text: 'useDevice',
            group: MenuGroupEnum.HOOKS,
            element: UseDevicePage,
        },
        {
            text: 'useForm',
            group: MenuGroupEnum.HOOKS,
            element: UseFormPage,
        },
        {
            text: 'useIsFirstRender',
            group: MenuGroupEnum.HOOKS,
            element: useIsFirstRenderPage,
        },
        {
            text: 'useComputedStyles',
            group: MenuGroupEnum.HOOKS,
            element: UseComputedStylesPage,
        },
        {
            text: 'useMeasure',
            group: MenuGroupEnum.HOOKS,
            element: UseMeasurePage,
        },
        {
            text: 'useNow',
            group: MenuGroupEnum.HOOKS,
            element: useNowPage,
        },
        {
            text: 'usePrint',
            group: MenuGroupEnum.HOOKS,
            element: UsePrintPage,
        },
        {
            text: 'useReRender',
            group: MenuGroupEnum.HOOKS,
            element: useReRenderPage,
        },
        {
            text: 'useStorage',
            group: MenuGroupEnum.HOOKS,
            element: useStoragePage,
        },
        {
            text: 'useTimer',
            group: MenuGroupEnum.HOOKS,
            element: UseTimerPage,
        },
        {
            text: 'useTitle',
            group: MenuGroupEnum.HOOKS,
            element: useTitlePage,
        },
        {
            text: 'useWatch',
            group: MenuGroupEnum.HOOKS,
            element: UseWatchPage,
        },
        {
            text: 'useWidth',
            group: MenuGroupEnum.HOOKS,
            element: UseWidthPage,
        },
        {
            text: 'useWindowOpen',
            group: MenuGroupEnum.HOOKS,
            element: UseWindowOpenPage,
        },
    ],
    utils: [
        {
            text: 'asyncForEach',
            group: MenuGroupEnum.UTILS,
            element: AsyncForEachPage,
        },
        {
            text: 'cleanDeep',
            group: MenuGroupEnum.UTILS,
            element: CleanDeepPage,
        },
        {
            text: 'stripHtmlFromText',
            group: MenuGroupEnum.UTILS,
            element: StripHtmlFromTextPage,
        },
        {
            text: 'deepCopy',
            group: MenuGroupEnum.UTILS,
            element: DeepCopyPage,
        },
        {
            text: 'deepKeysAsArray',
            group: MenuGroupEnum.UTILS,
            element: DeepKeysAsArrayPage,
        },
        {
            text: 'deepKeysAsObject',
            group: MenuGroupEnum.UTILS,
            element: DeepKeysAsObjectPage,
        },
        {
            text: 'deepMerge',
            group: MenuGroupEnum.UTILS,
            element: DeepMergePage,
        },
        {
            text: 'excelToJson',
            group: MenuGroupEnum.UTILS,
            element: ExcelToJsonPage,
        },
        {
            text: 'txtToString',
            group: MenuGroupEnum.UTILS,
            element: TxtToStringPage,
        },
        {
            text: 'exportPDF',
            group: MenuGroupEnum.UTILS,
            element: ExportPDFPage,
        },
        {
            text: 'exportTable',
            group: MenuGroupEnum.UTILS,
            element: ExportTablePage,
        },
        {
            text: 'exportWord',
            group: MenuGroupEnum.UTILS,
            element: ExportWordPage,
        },
        {
            text: 'fileDownloader',
            group: MenuGroupEnum.UTILS,
            element: FileDownloaderPage,
        },
        {
            text: 'findDeep',
            group: MenuGroupEnum.UTILS,
            element: FindDeepPage,
        },
        {
            text: 'getComputedStyles',
            group: MenuGroupEnum.UTILS,
            element: GetComputedStylesPage,
        },
        {
            text: 'getCookie',
            group: MenuGroupEnum.UTILS,
            element: GetCookiePage,
        },
        {
            text: 'getDateFromExcelDate',
            group: MenuGroupEnum.UTILS,
            element: GetDateFromExcelDatePage,
        },
        {
            text: 'getExcelDateFromDate',
            group: MenuGroupEnum.UTILS,
            element: GetExcelDateFromDatePage,
        },
        {
            text: 'getFileSize',
            group: MenuGroupEnum.UTILS,
            element: GetFileSizePage,
        },
        {
            text: 'getLocalStorageItem',
            group: MenuGroupEnum.UTILS,
            element: GetLocalStorageItemPage,
        },
        {
            text: 'sanitizeHTML',
            group: MenuGroupEnum.UTILS,
            element: SanitizeHTMLPage,
        },
        {
            text: 'getNow',
            group: MenuGroupEnum.UTILS,
            element: GetNowPage,
        },
        {
            text: 'millisecondsToTime',
            group: MenuGroupEnum.UTILS,
            element: MillisecondsToTimePage,
        },
        {
            text: 'timeToMilliseconds',
            group: MenuGroupEnum.UTILS,
            element: TimeToMillisecondsPage,
        },
        {
            text: 'getSessionStorageItem',
            group: MenuGroupEnum.UTILS,
            element: GetSessionStorageItemPage,
        },
        {
            text: 'groupString',
            group: MenuGroupEnum.UTILS,
            element: GroupStringPage,
        },
        {
            text: 'iban',
            group: MenuGroupEnum.UTILS,
            element: IBANMethodPage,
        },
        {
            text: 'base64Decryption',
            group: MenuGroupEnum.UTILS,
            element: Base64DecryptionPage,
        },
        {
            text: 'base64Encryption',
            group: MenuGroupEnum.UTILS,
            element: Base64EncryptionPage,
        },
        {
            text: 'isBase64',
            group: MenuGroupEnum.UTILS,
            element: IsBase64Page,
        },
        {
            text: 'message',
            group: MenuGroupEnum.UTILS,
            element: MessagePage,
        },
        {
            text: 'numberFormat',
            group: MenuGroupEnum.UTILS,
            element: NumberFormatMethodPage,
        },
        {
            text: 'currency',
            group: MenuGroupEnum.UTILS,
            element: CurrencyMethodPage,
        },
        {
            text: 'phoneNumberFormatter',
            group: MenuGroupEnum.UTILS,
            element: PhoneNumberFormatterPage,
        },
        {
            text: 'isNumeric',
            group: MenuGroupEnum.UTILS,
            element: IsNumericPage,
        },
        {
            text: 'ProviderLoadingMethods',
            group: MenuGroupEnum.UTILS,
            element: ProviderLoadingMethodsPage,
        },
        {
            text: 'removeCookie',
            group: MenuGroupEnum.UTILS,
            element: RemoveCookiePage,
        },
        {
            text: 'removeLocalStorageItem',
            group: MenuGroupEnum.UTILS,
            element: RemoveLocalStorageItemPage,
        },
        {
            text: 'removeSessionStorageItem',
            group: MenuGroupEnum.UTILS,
            element: RemoveSessionStorageItemPage,
        },
        {
            text: 'replaceTRtoENChars',
            group: MenuGroupEnum.UTILS,
            element: ReplaceTRtoENCharsPage,
        },
        {
            text: 'cardNumberFormatter',
            group: MenuGroupEnum.UTILS,
            element: CardNumberFormatterPage,
        },
        {
            text: 'scrollToElement',
            group: MenuGroupEnum.UTILS,
            element: ScrollToElementPage,
        },
        {
            text: 'scrollToTop',
            group: MenuGroupEnum.UTILS,
            element: ScrollToTopPage,
        },
        {
            text: 'setLocalStorageItem',
            group: MenuGroupEnum.UTILS,
            element: SetLocalStorageItemPage,
        },
        {
            text: 'setSessionStorageItem',
            group: MenuGroupEnum.UTILS,
            element: SetSessionStorageItemPage,
        },
        {
            text: 'stringHTMLToJSX',
            group: MenuGroupEnum.UTILS,
            element: StringHTMLToJSXPage,
        },
        {
            text: 'setCookie',
            group: MenuGroupEnum.UTILS,
            element: SetCookiePage,
        },
        {
            text: 'sleep',
            group: MenuGroupEnum.UTILS,
            element: SleepPage,
        },
        {
            text: 'ThemeProviderMethods',
            group: MenuGroupEnum.UTILS,
            element: ThemeProviderMethodsPage,
        },
        {
            text: 'queryStringToJson',
            group: MenuGroupEnum.UTILS,
            element: QueryStringToJsonPage,
        },
        {
            text: 'jsonToQueryString',
            group: MenuGroupEnum.UTILS,
            element: JsonToQueryStringPage,
        },
        {
            text: 'xmlToJs',
            group: MenuGroupEnum.UTILS,
            element: XmlToJsonPage,
        },
        {
            text: 'jsToXml',
            group: MenuGroupEnum.UTILS,
            element: JsToXmlPage,
        },
        {
            text: 'stringValidations',
            group: MenuGroupEnum.UTILS,
            element: StringValidationsPage,
        },
        {
            text: 'numberValidations',
            group: MenuGroupEnum.UTILS,
            element: NumberValidationsPage,
        },
        {
            text: 'numberDateValidations',
            group: MenuGroupEnum.UTILS,
            element: NumberDateValidationsPage,
        },
        {
            text: 'dateValidations',
            group: MenuGroupEnum.UTILS,
            element: DateValidationsPage,
        },
        {
            text: 'booleanValidations',
            group: MenuGroupEnum.UTILS,
            element: BooleanValidationsPage,
        },
        {
            text: 'Other Validations',
            group: MenuGroupEnum.UTILS,
            element: OtherValidationsPage,
        },
        {
            text: 'HelperFormProps',
            group: MenuGroupEnum.UTILS,
            element: HelperFormPropsPage,
        },
        {
            text: 'Printer',
            group: MenuGroupEnum.UTILS,
            element: PrinterPage,
        },
        {
            text: 'isParsableToJson',
            group: MenuGroupEnum.UTILS,
            element: IsParsableToJsonPage,
        },
        {
            text: 'confirm',
            group: MenuGroupEnum.UTILS,
            element: ConfirmMethodPage,
        },
        {
            text: 'randomNumber',
            group: MenuGroupEnum.UTILS,
            element: RandomNumberPage,
        },
    ],
    example: [
        {
            text: 'General',
            group: MenuGroupEnum.EXAMPLE,
            element: GeneralExamplePage,
        },
    ],
};

export const menuData: IMenuData[] = [
    ...menu.form,
    ...menu.display,
    ...menu.others,
    ...menu.hooks,
    ...menu.utils,
    ...menu.example,
];
