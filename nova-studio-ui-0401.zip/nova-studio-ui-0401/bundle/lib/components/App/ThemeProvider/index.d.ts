import type { Theme } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
interface IThemeProvider extends ICommonProps {
    children: any;
    theme?: Partial<Theme> | null;
}
declare const _default: import("react").NamedExoticComponent<IThemeProvider>;
export default _default;
//# sourceMappingURL=index.d.ts.map