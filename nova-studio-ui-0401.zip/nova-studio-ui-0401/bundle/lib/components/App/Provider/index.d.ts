import type { Theme } from '@mui/material';
import type { SnackbarProviderProps } from 'notistack';
import type { ReactNode } from 'react';
import type { ILoadingModalProps } from '../../..';
import type { ICommonProps } from '../../../utils/types/common';
export interface IProviderProps extends ICommonProps {
    children: ReactNode;
    globalStyles?: object;
    loadingProps?: ILoadingModalProps & {
        keepMounted?: boolean;
    };
    messageProviderProps?: SnackbarProviderProps;
    theme?: Partial<Theme>;
}
declare const _default: import("react").NamedExoticComponent<IProviderProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map