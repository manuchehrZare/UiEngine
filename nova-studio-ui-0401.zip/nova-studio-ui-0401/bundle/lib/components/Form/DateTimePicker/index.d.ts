import type { IDateTimePickerProps } from './type';
declare const _default: import("react").NamedExoticComponent<IDateTimePickerProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map