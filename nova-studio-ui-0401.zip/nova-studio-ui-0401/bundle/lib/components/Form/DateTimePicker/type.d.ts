import type { DateTimePickerSlotsComponents, DateTimePickerProps, DateTimePickerSlotsComponentsProps } from '@mui/x-date-pickers';
import type { TextFieldProps } from '@mui/material';
import type { ICommonFieldProps } from '../commonTypes';
export interface IDateTimePickerProps extends Pick<DateTimePickerProps<any>, 'ampmInClock' | 'autoFocus' | 'className' | 'disableHighlightToday' | 'disableIgnoringDatePartForTimeValidation' | 'disableOpenPicker' | 'disablePast' | 'disabled' | 'displayWeekNumber' | 'format' | 'formatDensity' | 'label' | 'loading' | 'localeText' | 'maxDate' | 'maxDateTime' | 'maxTime' | 'minDate' | 'minDateTime' | 'minTime' | 'minutesStep' | 'onClose' | 'onMonthChange' | 'onOpen' | 'onViewChange' | 'onYearChange' | 'shouldDisableDate' | 'shouldDisableTime' | 'shouldDisableYear' | 'views'>, Omit<ICommonFieldProps, 'startAdornment' | 'endAdornment'>, Pick<TextFieldProps, 'placeholder' | 'sx' | 'onKeyPress' | 'onFocus' | 'onBlur'> {
    analogClock?: boolean;
    clearable?: boolean | undefined;
    clearText?: any;
    disableCloseOnSelect?: boolean;
    required?: boolean;
    showTodayButton?: boolean | undefined;
    slotProps?: Omit<DateTimePickerSlotsComponentsProps<any>, 'textField' | 'desktopPaper' | 'openPickerButton' | 'actionBar' | 'inputAdornment'>;
    slots?: Omit<DateTimePickerSlotsComponents<any>, 'textField' | 'field' | 'TextField' | 'Field'>;
    todayText?: any;
    unixTime?: boolean;
}
export declare enum DateTimeTypeEnum {
    day = "day",
    month = "month",
    year = "year",
    hours = "hours",
    minutes = "minutes",
    seconds = "seconds"
}
export type DateTimeType = keyof typeof DateTimeTypeEnum;
export declare const placeholderFormat: (data: string) => string;
//# sourceMappingURL=type.d.ts.map