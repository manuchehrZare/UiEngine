import type { ICheckboxProps } from './type';
declare const _default: import("react").NamedExoticComponent<ICheckboxProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map