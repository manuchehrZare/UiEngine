import type { SliderProps } from '@mui/material';
import type { ICommonFieldProps, IFormCommonControl } from '../commonTypes';
export interface IRangeInputProps extends IFormCommonControl<any>, Pick<SliderProps, 'color' | 'components' | 'disabled' | 'disableSwap' | 'marks' | 'max' | 'min' | 'orientation' | 'scale' | 'step' | 'sx' | 'tabIndex' | 'track' | 'getAriaValueText' | 'valueLabelDisplay' | 'valueLabelFormat' | 'className' | 'onChange'>, Pick<ICommonFieldProps, 'name' | 'size' | 'design' | 'helperText' | 'labelPlacement' | 'labelEllipsis' | 'labelWidth'> {
    label?: string;
}
//# sourceMappingURL=type.d.ts.map