import type { FC } from 'react';
import type { IInputProps } from '../type';
declare const Input: FC<IInputProps>;
export default Input;
//# sourceMappingURL=index.d.ts.map