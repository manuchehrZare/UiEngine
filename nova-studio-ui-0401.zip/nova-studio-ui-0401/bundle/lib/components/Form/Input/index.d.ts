import type { IInputProps } from './type';
declare const _default: import("react").NamedExoticComponent<IInputProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map