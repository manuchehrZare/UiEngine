import type { ISwitchProps } from './type';
declare const _default: import("react").NamedExoticComponent<ISwitchProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map