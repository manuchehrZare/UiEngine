import type { ISelectProps } from './type';
declare const Select: <T>({ design, disabled, displayEmpty, fullWidth, hidden, labelPlacement, labelEllipsis, readOnly, required, size, variant, ...rest }: ISelectProps<T>) => import("react/jsx-runtime").JSX.Element;
export default Select;
//# sourceMappingURL=index.d.ts.map