import type { FC } from 'react';
import type { ICurrencyProps } from './type';
declare const Currency: FC<ICurrencyProps>;
export default Currency;
//# sourceMappingURL=index.d.ts.map