import type { INumberFormatProps } from '../../Display/NumberFormat/type';
import type { INumberInputProps } from '../../Form/NumberInput/type';
interface ICurrencyBaseProps {
    component: 'NumberFormat' | 'NumberInput';
    currency?: string;
}
export interface ICurrencyFormatProps extends Omit<INumberFormatProps, 'suffix' | 'renderText'>, Omit<ICurrencyBaseProps, 'component'> {
    component: 'NumberFormat';
}
export interface ICurrencyInputProps extends Omit<INumberInputProps, 'suffix'>, Omit<ICurrencyBaseProps, 'component'> {
    component: 'NumberInput';
}
export type ICurrencyProps = ICurrencyInputProps | ICurrencyFormatProps;
export {};
//# sourceMappingURL=type.d.ts.map