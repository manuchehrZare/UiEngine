import type { FC } from 'react';
import type { IPhoneNumberProps } from './type';
declare const PhoneNumber: FC<IPhoneNumberProps>;
export default PhoneNumber;
//# sourceMappingURL=index.d.ts.map