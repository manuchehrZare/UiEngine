import type { ICustomScrollbarProps } from './type';
declare const CustomScrollbar: import("react").ForwardRefExoticComponent<Omit<ICustomScrollbarProps, "ref"> & import("react").RefAttributes<any>>;
export default CustomScrollbar;
//# sourceMappingURL=index.d.ts.map