import type { FC } from 'react';
import type { IModalBodyProps } from './type';
declare const ModalBody: FC<IModalBodyProps>;
export default ModalBody;
//# sourceMappingURL=Body.d.ts.map