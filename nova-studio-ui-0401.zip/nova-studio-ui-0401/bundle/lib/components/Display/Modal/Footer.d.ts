import type { FC } from 'react';
import type { IModalFooterProps } from './type';
declare const ModalFooter: FC<IModalFooterProps>;
export default ModalFooter;
//# sourceMappingURL=Footer.d.ts.map