import 'react-pdf/dist/esm/Page/TextLayer.css';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import type { IPDFViewerProps } from './type';
declare const _default: import("react").NamedExoticComponent<IPDFViewerProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map