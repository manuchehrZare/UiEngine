import type { FC } from 'react';
import type { IDividerProps } from './type';
declare const Divider: FC<IDividerProps>;
export default Divider;
//# sourceMappingURL=index.d.ts.map