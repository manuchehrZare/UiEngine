import type { FC } from 'react';
import type { IChipProps } from './type';
declare const Chip: FC<IChipProps>;
export default Chip;
//# sourceMappingURL=index.d.ts.map