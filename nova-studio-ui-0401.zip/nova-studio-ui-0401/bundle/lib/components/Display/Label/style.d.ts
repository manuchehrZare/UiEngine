import type { SxProps, Theme } from '@mui/material';
import type { ILabelProps } from '../../..';
interface IParams extends Pick<ILabelProps, 'design' | 'align' | 'color'> {
}
declare const LabelSxProps: ({ align, design, color }: IParams) => SxProps<Theme>;
export default LabelSxProps;
//# sourceMappingURL=style.d.ts.map