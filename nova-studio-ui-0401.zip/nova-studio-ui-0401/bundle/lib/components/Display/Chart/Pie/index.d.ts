import type { FC } from 'react';
import type { IPieChartProps } from './type';
declare const PieChart: FC<IPieChartProps>;
export default PieChart;
//# sourceMappingURL=index.d.ts.map