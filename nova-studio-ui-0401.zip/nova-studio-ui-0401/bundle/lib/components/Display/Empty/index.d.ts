import type { IEmptyProps } from './type';
declare const _default: import("react").NamedExoticComponent<IEmptyProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map