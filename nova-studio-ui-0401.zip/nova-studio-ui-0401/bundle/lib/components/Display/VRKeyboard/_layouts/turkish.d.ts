import type { KeyboardLayoutObject } from 'react-simple-keyboard';
export declare const trLayout: KeyboardLayoutObject;
//# sourceMappingURL=turkish.d.ts.map