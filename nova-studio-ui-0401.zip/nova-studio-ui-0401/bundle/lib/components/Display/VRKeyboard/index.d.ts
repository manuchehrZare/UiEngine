import 'react-simple-keyboard/build/css/index.css';
import type { IVRKeyboardProps } from './type';
declare const _default: import("react").NamedExoticComponent<IVRKeyboardProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map