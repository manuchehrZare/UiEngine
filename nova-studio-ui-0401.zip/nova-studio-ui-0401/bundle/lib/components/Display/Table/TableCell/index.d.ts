import type { FC } from 'react';
import type { ITableCellProps } from './type';
declare const TableCell: FC<ITableCellProps>;
export default TableCell;
//# sourceMappingURL=index.d.ts.map