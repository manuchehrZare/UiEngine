import type { INavItemProps } from '../type';
declare const _default: import("react").NamedExoticComponent<INavItemProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map