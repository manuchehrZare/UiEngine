import React from 'react';
import type { ITreeViewProps } from './type';
declare const _default: React.NamedExoticComponent<ITreeViewProps>;
export default _default;
//# sourceMappingURL=index.d.ts.map