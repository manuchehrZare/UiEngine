import type { PopperProps, TooltipProps } from '@mui/material';
import type { ICommonProps } from '../../../utils/types/common';
export interface ITooltipProps extends ICommonProps, Pick<TooltipProps, 'arrow' | 'children' | 'className' | 'componentsProps' | 'enterDelay' | 'followCursor' | 'leaveDelay' | 'onClose' | 'onOpen' | 'placement' | 'sx' | 'title'>, Pick<PopperProps, 'keepMounted'> {
    show?: boolean | undefined;
}
//# sourceMappingURL=type.d.ts.map