import type { FC } from 'react';
export interface IScrollPageTopProps {
    children: any;
    scrollElement: string | null;
}
declare const ScrollPageTop: FC<IScrollPageTopProps>;
export default ScrollPageTop;
//# sourceMappingURL=index.d.ts.map