import type { FC } from 'react';
import type { IGridProps } from '../type';
declare const Grid: FC<IGridProps>;
export default Grid;
//# sourceMappingURL=index.d.ts.map