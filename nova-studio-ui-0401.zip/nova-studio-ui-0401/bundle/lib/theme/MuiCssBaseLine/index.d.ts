import type { Components } from '@mui/material';
export declare const Mui_CssBaseline: Components;
//# sourceMappingURL=index.d.ts.map