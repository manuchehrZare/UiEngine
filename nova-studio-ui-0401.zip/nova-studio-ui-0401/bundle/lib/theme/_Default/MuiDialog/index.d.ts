import type { Components } from '@mui/material';
export declare const MuiDialogTheme: Components;
//# sourceMappingURL=index.d.ts.map