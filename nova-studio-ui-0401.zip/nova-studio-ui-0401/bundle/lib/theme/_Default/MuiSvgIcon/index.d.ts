import type { Components } from '@mui/material';
export declare const MuiSvgIconTheme: Components;
//# sourceMappingURL=index.d.ts.map