import type { Components } from '@mui/material';
export declare const MuiChipTheme: Components;
//# sourceMappingURL=index.d.ts.map