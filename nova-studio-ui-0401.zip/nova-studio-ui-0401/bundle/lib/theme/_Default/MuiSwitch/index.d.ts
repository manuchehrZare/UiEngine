import type { Components } from '@mui/material';
export declare const MuiSwitchTheme: Components;
//# sourceMappingURL=index.d.ts.map