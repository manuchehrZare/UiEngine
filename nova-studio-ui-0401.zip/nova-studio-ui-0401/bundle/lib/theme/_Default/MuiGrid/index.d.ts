import type { Components } from '@mui/material';
export declare const MuiGridTheme: Components;
//# sourceMappingURL=index.d.ts.map