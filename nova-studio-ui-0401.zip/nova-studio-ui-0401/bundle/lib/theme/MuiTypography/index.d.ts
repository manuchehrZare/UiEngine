import type { Components } from '@mui/material';
export declare const MuiTypographyTheme: Components;
//# sourceMappingURL=index.d.ts.map