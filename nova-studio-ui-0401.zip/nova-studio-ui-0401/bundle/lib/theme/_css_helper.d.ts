export declare const getHelpers: () => any;
//# sourceMappingURL=_css_helper.d.ts.map