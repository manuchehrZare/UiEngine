import type { Components } from '@mui/material';
export declare const MuiPopoverTheme: Components;
//# sourceMappingURL=index.d.ts.map