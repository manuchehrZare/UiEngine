export declare const getRootStyle: () => object;
//# sourceMappingURL=_css_root.d.ts.map