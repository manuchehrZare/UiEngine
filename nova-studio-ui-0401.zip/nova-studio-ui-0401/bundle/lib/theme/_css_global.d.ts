import '@fontsource/source-sans-pro';
export declare const GlobalFont = "Source Sans Pro";
export declare const getCssGlobal: () => object;
//# sourceMappingURL=_css_global.d.ts.map