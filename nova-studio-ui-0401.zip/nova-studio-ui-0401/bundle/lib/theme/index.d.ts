import type { HTMLAttributes } from 'react';
declare module '@mui/material' {
    interface AlertPropsColorOverrides {
        primary: true;
    }
    interface BreakpointOverrides {
        xxl: true;
    }
    interface FormControlPropsSizeOverrides {
        large: true;
    }
    interface ChipPropsVariantOverrides {
        standard: true;
    }
    interface ChipOwnProps {
        cornered?: boolean;
        leftCornered?: boolean;
        rightCornered?: boolean;
    }
    interface ChipClasses {
        cornered?: string;
        corneredLeft?: string;
        corneredRight?: string;
    }
    interface InputHTMLAttributes<T> extends HTMLAttributes<T> {
        webkitdirectory?: string;
    }
}
declare const theme: import("@mui/material").Theme;
export { theme };
//# sourceMappingURL=index.d.ts.map