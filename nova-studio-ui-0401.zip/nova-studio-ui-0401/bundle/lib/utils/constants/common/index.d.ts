export declare const common: {
    company: {
        NAME: string;
        WEBSITE_LINK: string;
    };
    library: {
        documentation: string;
        prefix: string;
        localization: {
            defaultLng: string;
            defaultFallbackLng: string[];
        };
    };
};
//# sourceMappingURL=index.d.ts.map