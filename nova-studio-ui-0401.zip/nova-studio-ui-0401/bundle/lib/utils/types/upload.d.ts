export interface IUploadDocument {
    Date?: number;
    DMSId: string;
    DocumentName: string;
    DocumentPath: string;
    DocumentSize: number;
}
//# sourceMappingURL=upload.d.ts.map