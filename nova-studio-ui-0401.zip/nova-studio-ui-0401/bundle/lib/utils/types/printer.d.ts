export declare enum PrinterTypeEnum {
    html = "html",
    pdf = "pdf",
    json = "json",
    rawHtml = "raw-html",
    image = "image"
}
//# sourceMappingURL=printer.d.ts.map