type ObserverCallback<T> = (entry: T) => void;
/**
 * Abstract base class for shared observer logic.
 */
declare abstract class BaseObserver<TEntry, TTarget extends Node> {
    protected callbackMap: WeakMap<TTarget, Set<ObserverCallback<TEntry>>>;
    protected observedTargets: Set<TTarget>;
    disconnect(): void;
    observe(target: TTarget, callback: ObserverCallback<TEntry>): void;
    unobserve(target: TTarget, callback: ObserverCallback<TEntry>): void;
    protected callbackMapClear(): void;
    protected callbackMapSize(): number;
    protected abstract observeTarget(target: TTarget): void;
    protected abstract unobserveTarget(target: TTarget): void;
}
/**
 * Shared ResizeObserver - Observes size changes of elements.
 */
declare class SharedResizeObserver extends BaseObserver<ResizeObserverEntry, Element> {
    private static instance;
    private observer;
    constructor();
    static getInstance(): SharedResizeObserver;
    disconnect(): void;
    protected observeTarget(target: Element): void;
    protected unobserveTarget(target: Element): void;
}
/**
 * Shared MutationObserver - Observes DOM mutations (attributes, children).
 */
declare class SharedMutationObserver extends BaseObserver<MutationRecord, Node> {
    private static instance;
    private observer;
    constructor();
    static getInstance(): SharedMutationObserver;
    disconnect(): void;
    protected observeTarget(target: Node): void;
    protected unobserveTarget(_: Node): void;
}
/**
 * Shared IntersectionObserver - Observes visibility changes of elements.
 */
declare class SharedIntersectionObserver extends BaseObserver<IntersectionObserverEntry, Element> {
    private static instance;
    private observer;
    constructor();
    static getInstance(): SharedIntersectionObserver;
    disconnect(): void;
    protected observeTarget(target: Element): void;
    protected unobserveTarget(target: Element): void;
}
export declare const sharedResizeObserver: SharedResizeObserver;
export declare const sharedMutationObserver: SharedMutationObserver;
export declare const sharedIntersectionObserver: SharedIntersectionObserver;
export {};
//# sourceMappingURL=observer.d.ts.map