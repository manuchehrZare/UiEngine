export declare const getFileSize: (bytes: number, dp?: number) => string;
//# sourceMappingURL=_common.d.ts.map