import type { INumberFormatProps } from '../../../../components/Form/NumberInput/type';
export interface INumberFormatOptions extends Pick<INumberFormatProps, 'decimalSeparator' | 'prefix' | 'suffix'> {
    maximumFractionDigits?: number;
    minimumFractionDigits?: number;
    minimumIntegerDigits?: number;
    thousandSeparator?: ',' | '.' | ' ';
}
export declare const numberFormat: (number: string | number, options?: INumberFormatOptions) => string;
//# sourceMappingURL=index.d.ts.map