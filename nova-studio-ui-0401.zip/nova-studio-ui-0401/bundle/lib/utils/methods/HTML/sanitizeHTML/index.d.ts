import type { SanitizeOptions } from '../../../..';
/**
 * Sanitizes a given string of HTML with the specified DOMPurify settings.
 * @param dirtyHTML - The potentially unsafe HTML to be sanitized.
 * @param options - The configuration object to be passed to DOMPurify.
 * @returns The sanitized HTML.
 */
export declare const sanitizeHTML: (dirtyHTML: string | null | undefined, options?: SanitizeOptions) => string | null;
//# sourceMappingURL=index.d.ts.map