export declare const setCookie: (cookieName: string, cvalue: any, expiredTime?: number) => void;
export declare const getCookie: (cookieName: string) => string;
export declare const removeCookie: (cookieName: string) => void;
//# sourceMappingURL=index.d.ts.map