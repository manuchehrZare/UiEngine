import type { IPhoneNumberInputProps } from '../../../..';
export interface IPhoneNumberFormatterOptions extends Pick<IPhoneNumberInputProps, 'withCountryCode' | 'withoutAreaCode' | 'withoutBrackets' | 'withZero'> {
    format?: string;
    mask?: string;
}
/**
 * Provides the view of the phone number in the desired format.
 * @param phoneNumberValue The phone number value to be formatted.
 * @returns Returns the formatted version of the phone number.
 */
export declare const phoneNumberFormatter: (phoneNumberValue: string, options?: IPhoneNumberFormatterOptions) => string;
//# sourceMappingURL=index.d.ts.map