import * as yup from 'yup';
import type { FieldValues } from '../../..';
import type { IDateOptions } from '../type';
export declare const dateValidation: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: IDateOptions<T>) => yup.DateSchema<Date | null | undefined, yup.AnyObject, undefined, "">;
//# sourceMappingURL=index.d.ts.map