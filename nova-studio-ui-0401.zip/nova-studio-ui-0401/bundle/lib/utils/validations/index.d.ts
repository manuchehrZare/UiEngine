import type { IStringOptions } from './type';
import { ValidationsCompareTypeEnum } from './type';
import type { FieldValues } from 'react-hook-form';
export declare const validation: {
    string: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: IStringOptions<T>) => import("yup").StringSchema<string | undefined, import("yup").AnyObject, undefined, "">;
    number: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: import("./type").INumberOptions<T>) => import("yup").NumberSchema<number | null | undefined, import("yup").AnyObject, undefined, "">;
    date: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: import("./type").IDateOptions<T>) => import("yup").DateSchema<Date | null | undefined, import("yup").AnyObject, undefined, "">;
    boolean: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: import("./type").IBooleanOptions<T>) => import("yup").BooleanSchema<boolean | undefined, import("yup").AnyObject, undefined, "">;
    trId: <TFormValues extends FieldValues>(options?: IStringOptions<TFormValues> & {
        fieldLabel?: string;
    }) => import("yup").StringSchema<string | undefined, import("yup").AnyObject, undefined, "">;
    iban: <TFormValues extends FieldValues>(options?: import("./type").IIBANOptions<TFormValues>) => import("yup").StringSchema<string | undefined, import("yup").AnyObject, undefined, "">;
    file: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: import("./type").IFileOptions<T>) => import("yup").MixedSchema<{} | undefined, import("yup").AnyObject, undefined, "">;
    /**
     * registryNo = userCode
     */
    registryNo: <TFormValues extends FieldValues>(options?: IStringOptions<TFormValues> & {
        fieldLabel?: string;
    }) => import("yup").StringSchema<string | undefined, import("yup").AnyObject, undefined, "">;
    password: <TFormValues extends FieldValues>(options?: IStringOptions<TFormValues> & {
        fieldLabel?: string;
    }) => import("yup").StringSchema<string | undefined, import("yup").AnyObject, undefined, "">;
};
export { ValidationsCompareTypeEnum };
//# sourceMappingURL=index.d.ts.map