import * as yup from 'yup';
import type { INumberOptions } from '../type';
import type { FieldValues } from '../../../hooks/useForm';
export declare const numberValidation: <T extends FieldValues = FieldValues>(fieldLabel: string, options?: INumberOptions<T>) => yup.NumberSchema<number | null | undefined, yup.AnyObject, undefined, "">;
//# sourceMappingURL=index.d.ts.map