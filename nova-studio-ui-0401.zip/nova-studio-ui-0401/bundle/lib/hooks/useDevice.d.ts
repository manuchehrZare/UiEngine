export type UseDeviceReturn = {
    isDesktop: boolean | null;
    isMobile: boolean | null;
    isTablet: boolean | null;
    lg: boolean;
    md: boolean;
    sm: boolean;
    xl: boolean;
    xs: boolean;
};
declare const useDevice: () => UseDeviceReturn;
export default useDevice;
//# sourceMappingURL=useDevice.d.ts.map