export type UseReRenderReturnType = {
    reRender: React.DispatchWithoutAction;
};
declare const useReRender: () => UseReRenderReturnType;
export default useReRender;
//# sourceMappingURL=useReRender.d.ts.map