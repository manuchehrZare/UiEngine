declare const useCapsLockDetector: (inputRef: React.RefObject<HTMLInputElement | HTMLTextAreaElement>) => boolean;
export default useCapsLockDetector;
//# sourceMappingURL=useCapsLockDetector.d.ts.map