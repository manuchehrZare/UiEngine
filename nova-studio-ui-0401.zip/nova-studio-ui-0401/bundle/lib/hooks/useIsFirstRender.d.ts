declare const useIsFirstRender: () => boolean;
export default useIsFirstRender;
//# sourceMappingURL=useIsFirstRender.d.ts.map