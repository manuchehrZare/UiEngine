import type { Control, FieldPath, FieldPathValue, FieldPathValues, FieldValues } from 'react-hook-form';
export interface IUseWatchProps<TFields extends FieldValues> {
    control: Control<TFields>;
    defaultValue?: any;
    fieldName: FieldPath<TFields> | FieldPath<TFields>[];
}
export type UseWatchReturnType<TFields extends FieldValues> = FieldPathValue<TFields, any> | FieldPathValues<TFields, any>;
declare const useWatch: <TFields extends FieldValues>({ control, defaultValue, fieldName, }: IUseWatchProps<TFields>) => UseWatchReturnType<TFields>;
export default useWatch;
//# sourceMappingURL=useWatch.d.ts.map