export type CallbackSuccessType<T> = (value: T) => void;
export type CallbackErrorType = (err?: any) => void;
export interface IUseClipboardReturn<T> {
    copiedValue: T | null;
    copy: (value: T, onSuccess?: CallbackSuccessType<T>, onError?: CallbackErrorType) => any;
    isCopied: boolean;
}
export type UseClipboardReturnType<T> = IUseClipboardReturn<T>;
export type UseClipboardOptions<T> = {
    onError?: CallbackErrorType;
    onSuccess?: CallbackSuccessType<T>;
    successDuration?: number;
};
declare const useClipboard: <T = any>(options?: UseClipboardOptions<T>) => UseClipboardReturnType<T>;
export default useClipboard;
//# sourceMappingURL=useClipboard.d.ts.map