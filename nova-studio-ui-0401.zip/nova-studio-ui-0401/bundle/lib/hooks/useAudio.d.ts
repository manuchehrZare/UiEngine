interface IUseAudioOptions {
    autoplay?: boolean;
    loop?: boolean;
    muted?: boolean;
    onPlayError?: (error: string) => void;
    playbackRate?: number;
    volume?: number;
}
interface IAudioState {
    currentTime: number;
    duration: number;
    error: string | null;
    loop: boolean;
    muted: boolean;
    playbackRate: number;
    playing: boolean;
    volume: number;
}
interface IAuidoControls {
    pause: () => void;
    play: () => void;
    seek: (time: number) => void;
    setLoop: (loop: boolean) => void;
    setMuted: (muted: boolean) => void;
    setPlaybackRate: (rate: number) => void;
    setVolume: (volume: number) => void;
    stop: () => void;
}
interface IUseAudioReturn extends IAudioState, IAuidoControls {
}
declare const useAudio: (src: string, options?: IUseAudioOptions) => IUseAudioReturn;
export default useAudio;
//# sourceMappingURL=useAudio.d.ts.map