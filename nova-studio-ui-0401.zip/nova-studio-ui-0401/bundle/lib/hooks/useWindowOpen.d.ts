export declare enum WindowOpenProcessTypeEnum {
    WindowClosed = "windowClosed",
    WindowMessage = "windowMessage",
    WindowReady = "windowReady"
}
export type WindowOpenMessageType<TMessagePayload = any> = {
    payload?: TMessagePayload;
    processType: `${WindowOpenProcessTypeEnum}`;
};
export type WindowOpenFeatures = {
    /**
     * @default false
     */
    fullscreen?: boolean;
    height?: number;
    left?: number;
    /**
     * @default false
     */
    location?: boolean;
    /**
     * @default false
     */
    menubar?: boolean;
    /**
     * @default false
     */
    noopener?: boolean;
    /**
     * @default false
     */
    noreferrer?: boolean;
    /**
     * @default false
     */
    resizable?: boolean;
    screenX?: number;
    screenY?: number;
    /**
     * @default false
     */
    scrollbars?: boolean;
    /**
     * @default false
     */
    status?: boolean;
    /**
     * @default false
     */
    toolbar?: boolean;
    top?: number;
    width?: number;
};
export declare enum WindowOpenTargetEnum {
    Blank = "_blank",
    Parent = "_parent",
    Self = "_self",
    Top = "_top"
}
export type WindowOpenTarget = `${WindowOpenTargetEnum}` | string;
export type UseWindowOpenBaseOptions = {
    /** Custom window features */
    features?: WindowOpenFeatures;
    /**
     * Callback triggered when window is closed
     * @returns void
     */
    onClose?: () => void;
    /**
     * Callback triggered when window opens
     * @returns void
     */
    onOpen?: () => void;
    /**
     * Custom can be used as window.name with the expressions.
     * * **Enum :** Custom string value can be valued with **WindowOpenTargetEnum**.
     */
    target?: WindowOpenTarget;
    /**
     * Target origin for postMessage (security)
     */
    targetOrigin?: string;
    /**
     * URL to open
     */
    url: string;
};
export type WithExpectedMessageUseWindowOpenOptions<TReceivedData> = UseWindowOpenBaseOptions & {
    /**
     * Indicates that the opened window will communicate back using postMessage.
     *
     * When set to `true`:
     * - `onMessage` will be used to handle incoming messages from the opened window.
     * - `onWindowReady` will be called when the window sends a "ready" message.
     * - `sendMessage` and `isWindowReady` will be available in the returned API.
     *
     * This enables type-safe postMessage integration between the two windows.
     */
    expectMessage: true;
    /**
     * Called when a postMessage is received from the child window.
     * Callback triggered when message is received from the window
     */
    onMessage?: (data: WindowOpenMessageType<TReceivedData>, event: MessageEvent<WindowOpenMessageType<TReceivedData>>) => void;
    /**
     * Callback triggered when opened window signals it's ready
     * Called when the child window sends a "WindowReady" message.
     * @returns void
     */
    onWindowReady?: () => void;
};
export type WithoutExpectedMessageUseWindowOpenOptions = UseWindowOpenBaseOptions & {
    /**
     * Indicates that the opened window will not communicate back using postMessage.
     *
     * When set to `false`:
     * - `sendMessage`, `isWindowReady`, `onMessage`, and `onWindowReady` will NOT be available.
     * - The hook will behave as a simple window opener.
     */
    expectMessage: false;
};
export type UseWindowOpenOptions<TReceivedData> = WithExpectedMessageUseWindowOpenOptions<TReceivedData> | WithoutExpectedMessageUseWindowOpenOptions;
type WindowHookErrorType = 'WindowOpenError' | 'MessageSendError' | 'UnknownError';
export type WindowOpenError = {
    message: string;
    type: WindowHookErrorType;
};
type WindowOpenResultBase = {
    /**
     * Method to close the opened window
     */
    close: () => void;
    /**
     * Error if window failed to open
     */
    error: WindowOpenError | null;
    /**
     * Indicates window is opened
     */
    isOpen: boolean;
    /**
     * Method to open the window
     */
    open: () => void;
    /**
     * Reference to the opened window
     */
    windowRef: Window | null;
};
type MessageEnabledResult<TSentData> = WindowOpenResultBase & {
    /**
     * Indicates if the opened window is ready
     */
    isWindowReady: boolean;
    /**
     * Method to send data to the window
     */
    sendMessage: (data: TSentData) => void;
};
type MessageDisabledResult = WindowOpenResultBase;
export type UseWindowOpenResult<TSentData, ExpectMessage extends boolean> = ExpectMessage extends true ? MessageEnabledResult<TSentData> : MessageDisabledResult;
declare const useWindowOpen: <TSentData = any, TReceivedData = any, ExpectMessage extends boolean = true>(options: UseWindowOpenOptions<TReceivedData>) => UseWindowOpenResult<TSentData, ExpectMessage>;
export default useWindowOpen;
//# sourceMappingURL=useWindowOpen.d.ts.map