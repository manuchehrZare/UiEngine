import type { Breakpoint } from '@mui/material';
export type WidthSize = Breakpoint | null;
declare const useWidth: () => WidthSize;
export default useWidth;
//# sourceMappingURL=useWidth.d.ts.map