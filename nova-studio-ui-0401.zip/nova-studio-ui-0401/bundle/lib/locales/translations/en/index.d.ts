declare const _default: {
    buttons: {
        actualSize: string;
        cancel: string;
        finish: string;
        fitPage: string;
        goToFirstPage: string;
        goToLastPage: string;
        menu: string;
        more: string;
        next: string;
        nextPage: string;
        no: string;
        ok: string;
        prev: string;
        preview: string;
        previousPage: string;
        print: string;
        rotate: string;
        save: string;
        suitableWidth: string;
        titles: string;
        yes: string;
        zoomIn: string;
        zoomOut: string;
    };
    contents: {
        PDFFileWasNotTransmitted: string;
        areYouSureYouWantToContinueWithThisProcess: string;
        csv: string;
        errorDuringFileTransport: string;
        export: string;
        failedToLoadPDFFile: string;
        file: string;
        import: string;
        invalidFileType: string;
        loading: string;
        thereWereNoResults: string;
        warning: string;
        xls: string;
        xlsx: string;
    };
    labels: {
        cancel: string;
        cancel_2: string;
        capsLockActive: string;
        cardNo: string;
        clickToTryAgain: string;
        design: string;
        dragAndDropFileIntoThisArea: string;
        dragAndDropFilesIntoThisArea: string;
        errorDuringUpload: string;
        errorWhileReturning: string;
        errorWhileUninstalling: string;
        goToFirstPage: string;
        goToLastPage: string;
        goToNextPage: string;
        goToPreviousPage: string;
        holdAndDrag: string;
        iban: string;
        ibanFullReplaceFailed: string;
        ibanInsertFailedError: string;
        ibanNo: string;
        imageIsTooBig: string;
        imageIsTooSmall: string;
        imageTypeNotSupported: string;
        invalidDefaultValue: string;
        invalidTypeFile: string;
        language: string;
        languageSelection: string;
        load: string;
        loading: string;
        maximumSizeExceeded: string;
        membersSelected: string;
        or: string;
        password: string;
        registryNo: string;
        remove: string;
        selectFile: string;
        selectedFiles: string;
        sizeNotAvailable: string;
        sizeWaiting: string;
        tapToCancel: string;
        tapToUndo: string;
        tcId: string;
        telephoneNumber: string;
        theFieldContainsInvalidFiles: string;
        theFileIsTooLarge: string;
        tryAgain: string;
        undo: string;
        uploadCanceled: string;
        uploadComplete: string;
        uploadMaximumFileSize: string;
        uploadMaximumSize: string;
        uploadMaximummResolution: string;
        uploadMinimumResolution: string;
        uploadMinimumSize: string;
        uploadResolutionTooHigh: string;
        uploadResolutionTooLow: string;
        useTimerAlreadyStartedError: string;
        useTimerAlreadyStoppedError: string;
        useTimerCountdownError: string;
        useTimerNegativeValuesError: string;
        useTimerPositiveSpeedMultiplierError: string;
        useTimerReachedLimitError: string;
        useTimerWithoutCountdownValuesError: string;
        waitingForUploadType: string;
    };
    languages: {
        en: string;
        tr: string;
    };
    pageTitles: {
        home: string;
        notFound: string;
        auth: {
            login: string;
        };
    };
    validations: {
        common: {
            verb: {
                entry: string;
                choosing: string;
                mustBe: string;
            };
            required: string;
            matches: string;
            typeError: string;
            min: string;
            max: string;
            length: string;
        };
        length: {
            char: string;
            length: string;
            minLength: string;
            maxLength: string;
        };
        compare: {
            greaterThan: string;
            lessThan: string;
            equal: string;
            notEqual: string;
            greaterThanOrEqual: string;
            lessThanOrEqual: string;
        };
        range: {
            message: string;
        };
        iban: {
            iban: string;
        };
        file: {
            accept: string;
            max: string;
            min: string;
            maxFileSize: string;
        };
    };
};
export default _default;
//# sourceMappingURL=index.d.ts.map