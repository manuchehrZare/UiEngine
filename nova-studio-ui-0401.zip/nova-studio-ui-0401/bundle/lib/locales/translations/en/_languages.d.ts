declare const _default: {
    en: string;
    tr: string;
};
export default _default;
//# sourceMappingURL=_languages.d.ts.map