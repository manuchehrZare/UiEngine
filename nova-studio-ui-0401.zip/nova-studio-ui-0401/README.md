# Seker UI Library

This library has reusable components developed for rapid project development.

## Getting Started

### Installation

Branch name can be specified with the "#" symbol at the end of the remote path in the command.

**Command structure:** `{packageManagementCommand} {installCommand} {remotePath#branchName}`

**Command example:** `pnpm i git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/sekerui.git#branchName`

**npm**

`npm i git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/sekerui.git`

`npm i git+ssh://git@bitbucket.cb.sekerbank.com.tr:7999/erp/sekerui.git`

**pnpm**

`pnpm add git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/sekerui.git`

`pnpm add git+ssh://git@bitbucket.cb.sekerbank.com.tr:7999/erp/sekerui.git`

**yarn**

`yarn add git+https://bitbucket.cb.sekerbank.com.tr:8443/scm/erp/sekerui.git`

`yarn add git+ssh://git@bitbucket.cb.sekerbank.com.tr:7999/erp/sekerui.git`

### Setup

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In order to ensure that seker-ui library can be used correctly in a project, the relevant project should be wrapped with the **Provider**
component under seker-ui.<br/>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Provider** component includes: the theme we've defined as `<ThemeProvider />`, css as `<CssBaseline />`, global styles as `<GlobalStyles /> ` and `<SnackbarProvider />` which is needed for notification ( a message method ) to work.<br/>
Only after the project is wrapped with setup, the seker-ui components used in the page can be displayed correctly.
Otherwise, it does not provide the correct interface, the console may throw an error.

#### Integration and Example Usage

```javascript
import { FC } from 'react';
// Import
import { Provider } from 'seker-ui';

// Component Usage
const App: FC = () => {
    return (
        <Provider>
            <App />
        </Provider>
    );
};
export default App;
```

```javascript
import { FC } from 'react';
// Import
import { Button } from 'seker-ui';

// Component Usage
const App: FC = () => {
    return <Button text="Button" onClick={() => console.log('click')} />;
};
export default App;
```

## Documentation

Developed using **Material-UI** components structured according to needs.<br/>
Library components documentation provided with [Storybook](https://storybook.js.org/).

## Supported Languages

A well-known JavaScript internationalization framework i18next is used as language support library within our projects. Currently supported languages are:

- English
- Turkish

## Library Information

- [React](https://reactjs.org/)
- [Create React App](https://github.com/facebook/create-react-app)
- [Typescript](https://www.typescriptlang.org/)
- [MUI](https://mui.com/)
- [Froala Editor](https://froala.com/), [react-froala-wysiwyg](https://github.com/froala/react-froala-wysiwyg)
- [Filepond](https://pqina.nl/filepond/), [react-filepond](https://github.com/pqina/react-filepond)
- [Notistack](https://notistack.com/)
- [React Hook Form](https://react-hook-form.com/)
- [i18next](https://www.i18next.com/), [react-i18next](https://react.i18next.com/)
- [Lodash](https://lodash.com/)
- [Recharts](https://recharts.org/)
- [React-PDF](https://github.com/wojtekmaj/react-pdf)
- [React-Simple-Keyboard](https://virtual-keyboard.js.org/)
- [React-to-Print](https://github.com/gregnb/react-to-print)
- [ESLint](https://eslint.org/)
- [Storybook](https://storybook.js.org/)

## Browser Support

- Google Chrome
- Mozilla Firefox
- Microsoft Edge
- Safari

## Contributors

- Kurumsal Önyüz YG

##

Developed by the **Şekerbank Software Development** team.<br/>
You can contact us for your suggestions and support requests.
