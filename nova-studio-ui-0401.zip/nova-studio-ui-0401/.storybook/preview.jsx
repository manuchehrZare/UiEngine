import '@fontsource/source-sans-pro';
import { ThemeProvider } from 'storybook/theming';
import { i18nInitialize, theme, Provider } from '../src/lib';

i18nInitialize();

const preview = {
    parameters: {
        backgrounds: { grid: { disable: true }, disabled: true },
        measure: { disable: true },
        outline: { disable: true },
    },
    decorators: [
        (Story) => (
            <ThemeProvider theme={theme}>
                <Provider loadingProps={{ keepMounted: false }}>
                    <Story />
                </Provider>
            </ThemeProvider>
        ),
    ],
    initialGlobals: { backgrounds: { value: 'light' } },
};
