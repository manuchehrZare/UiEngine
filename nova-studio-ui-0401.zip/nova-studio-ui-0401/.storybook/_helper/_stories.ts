export const editCode = (source: any, storyContext: any): string | null => {
    if (source.includes('control={{')) {
        let baseCode = storyContext.parameters.storySource.source;
        baseCode = baseCode.replace(baseCode.match(/args/g)[0], '');

        while (source.includes('control={{')) {
            source = source.replace(source.match(/control={{([\S\s]*?)}}/i)[0], 'control={control}');
        }

        if (source.includes('setValue')) {
            source = source.replace(source.match(/setValue={([\S\s]*?){}}/i)[0], 'setValue={setValue}');
        }

        if (baseCode.includes('handleSubmit ')) {
            source = source.replace(source.match(/onSubmit={([\S\s]*?){}}/i)[0], 'onSubmit={handleSubmit(onSubmit)}');
        }
        if (baseCode.includes('onUpdateFile')) {
            source = source.replace(
                source.match(/onUpdateFile={([\S\s]*?){}}/i)[0],
                'onUpdateFile={(files: FileList) => {}}',
            );
        }

        // sourceCode is array of main code row by row
        const sourceCode = source.split('\n').map((codeRow: any) => {
            if (codeRow.includes('noRefCheck')) {
                return '';
            } else if (codeRow.includes('[object Object]')) {
                return `\t${codeRow.replace('[object Object]', 'IconComponent')}\n`;
            } else if (codeRow !== '</form>') {
                return `\t${String(codeRow)}\n`;
            }
            return `    ${String(codeRow)}`;
        });
        return baseCode.replace(/return\b[^>]*>(.*?);/g, `return (\n${String(sourceCode.join(''))}\n    );`);
    }
    return null;
};

export const editIcon = (source: any): string | null => {
    if (!source.includes('args')) {
        const sourceCode = source.split('\n').map((codeRow: any) => {
            if (codeRow.includes('[object Object]')) {
                return `${codeRow.replace('[object Object]', 'IconComponent')}\n`;
            } else if (codeRow !== '/>') {
                return `${String(codeRow)}\n`;
            }
            return `${String(codeRow)}`;
        });
        return String(sourceCode.join(''));
    }
    return null;
};
