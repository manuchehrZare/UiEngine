/* eslint-disable */
/**
 * Select Component Wrapper
 * Wraps the lib Select component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React, { useMemo } from 'react';
import { useFormContext } from 'react-hook-form';
import { Select } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { useNova } from '..';

export const SelectComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    data,
    displayField,
    displayValue,
    options,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;
    const setValue = context ? context.setValue : undefined;
    const engine = useNova();

    // Ensure string properties are never undefined to prevent .substring() errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `select_${Math.random().toString(36).substring(2, 11)}`;

    // Get options from component state (set by remote call actions or reference data)
    const componentState = engine.getComponentState(id);
    const dynamicOptions = useMemo(() => {
        // Priority: state.options > schema.data.definitions > state data props > props.data > props.options (legacy) > default
        const stateOptions = componentState?.options;

        // Check if state has options set (from reference data or remote calls)
        // State options take precedence to allow runtime changes
        if (stateOptions) {
            // If options is already in the correct format
            if (stateOptions.data && Array.isArray(stateOptions.data)) {
                return stateOptions;
            }
            // If state.options is a plain array, wrap it in the expected format
            if (Array.isArray(stateOptions)) {
                return {
                    data: stateOptions,
                    displayField: displayField || 'value',
                    displayValue: displayValue || 'key',
                };
            }
        }

        // Check if component has a definition in schema.data.definitions using component's id
        // This is the primary source for static options defined in EBML
        if (id && engine.schema?.data?.definitions) {
            const definition = engine.schema.data.definitions.find(def => def.id === id);
            if (definition && definition.options && definition.options.length > 0) {
                return {
                    data: definition.options.map(opt => ({
                        key: opt.value,
                        value: opt.text
                    })),
                    displayField: displayField || 'value',
                    displayValue: displayValue || 'key',
                };
            }
        }

        // Check if state.value is an array (alternative way to set options)
        const stateValue = componentState?.value;
        if (Array.isArray(stateValue)) {
            return {
                data: stateValue,
                displayField: displayField || 'value',
                displayValue: displayValue || 'key',
            };
        }

        // Check if data prop is provided (new format)
        if (data && Array.isArray(data)) {
            return {
                data: data,
                displayField: displayField || 'value',
                displayValue: displayValue || 'key',
            };
        }

        // Fall back to legacy options prop or default
        if (options) {
            // If options is already in correct format
            if (options.data && Array.isArray(options.data)) {
                return options;
            }
            // If options is a plain array
            if (Array.isArray(options)) {
                return {
                    data: options,
                    displayField: displayField || 'value',
                    displayValue: displayValue || 'key',
                };
            }
        }

        // Default empty options
        return {
            data: [],
            displayField: displayField || 'value',
            displayValue: displayValue || 'key',
        };
    }, [componentState?.options, componentState?.value, data, displayField, displayValue, options, id, engine.schema]);

    // IMPORTANT: Do NOT pass 'value' prop when control is present - the control manages the value
    const safeProps = {
        ...props,
        label: label || '',
        name: safeName,
        options: dynamicOptions,
        control: control as any,
        setValue: setValue as any,
    };
    return <Select {...safeProps} />;
};
