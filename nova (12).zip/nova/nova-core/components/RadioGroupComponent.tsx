/* eslint-disable */
/**
 * RadioGroup Component
 * Renders EBML ButtonGroup components as RadioGroup container
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { GridItem, RadioGroup }   from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';
import { boundsToGridSize } from '..';

// Helper to parse color from EBML format (R,G,B)
const parseColor = (colorStr?: string): string => {
    if (!colorStr) return 'transparent';
    const parts = colorStr.split(',').map(p => parseInt(p.trim()));
    if (parts.length === 3) {
        return `rgb(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }
    return colorStr;
};

export const RadioGroupComponent: React.FC<NovaComponentProps> = ({
    id,
    name,
    label,
    title,
    value,
    selectedValue,
    background,
    helperText,
    orientation,
    bounds,
    parentBounds,
    useAbsolutePositioning = false,
    children,
    xs,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;
    const containerWidth = parentBounds?.width || 960;
    const bgColor = parseColor(background || '236,233,216');
    const fieldName = name || id || 'radioGroup';

    const radioGroupContent = (
        <RadioGroup
            name={fieldName}
            control={control}
            helperText={helperText}
            labelPlacement="top"
            label={title || label}
            row={orientation !== 'vertical'}
            sx={{
                p: 1,
                height: useAbsolutePositioning ? '100%' : 'auto',
            }}
            {...props}
        >
            {children}
        </RadioGroup>
    );

    if (useAbsolutePositioning) {
        return radioGroupContent;
    }

    if (!bounds) {
        return (
             <GridItem xs={12}>
                {radioGroupContent}
            </GridItem>
        );
    }

    const gridSize = boundsToGridSize(bounds, containerWidth);
    const resolvedXs = xs ?? gridSize.xs;
    return (
        <GridItem
            xs={resolvedXs}
            sx={{ minHeight: gridSize.minHeight }}
        >
            {radioGroupContent}
        </GridItem>
    );
};
