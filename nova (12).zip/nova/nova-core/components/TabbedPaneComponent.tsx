/* eslint-disable */
/**
 * TabbedPane Component
 * Renders EBML TabbedPane components with custom Tab and TabItem components
 * Supports both absolute positioning and responsive grid layout
 */

import React from 'react';
import { Paper, Tab, TabItem, Box } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const TabbedPaneComponent: React.FC<NovaComponentProps> = ({
    bounds,
    useAbsolutePositioning = false,
    children,
    designComponent,
}) => {
    const [value, setValue] = React.useState(0);

    const handleChange = (newValue: number) => {
        setValue(newValue);
    };

    // Use designComponent to inspect children definitions for tab titles
    // If designComponent is missing (e.g. legacy), we can't get titles easily unless passed via other means
    const tabDefinitions = designComponent?.children || [];

    const childArray = React.Children.toArray(children);

    // Calculate tab content height (total height minus tabs header)
    const tabHeaderHeight = 48;
    const contentHeight = bounds ? bounds.height - tabHeaderHeight : 400;

    return (
        <Paper
            sx={{
                width: '100%',
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                boxSizing: 'border-box',
            }}
        >
            <Tab
                value={value}
                onChange={handleChange}
                variant="scrollable"
                sx={{ borderBottom: 1, borderColor: 'divider', minHeight: tabHeaderHeight }}
            >
                {tabDefinitions.map((childDef, index) => {
                    const childProps = childDef.props || {};
                    const tabLabel = childProps.title || childProps.tabTitle || childProps.label || childProps.text || childProps.name || `Tab ${index + 1}`;
                    return <TabItem key={childDef.id} text={tabLabel} value={index} />;
                })}
                 {/* Fallback if no designComponent but we have children (legacy mode unlikely here) */}
                {tabDefinitions.length === 0 && childArray.map((_, index) => (
                    <TabItem key={index} text={`Tab ${index + 1}`} value={index} />
                ))}
            </Tab>

            {childArray.map((child, index) => {
                // Each child in childArray corresponds to a TabPage (one tab content per child)
                // Only show the child that matches the active tab index
                return (
                    <Box
                        key={index}
                        hidden={value !== index}
                        sx={{
                            position: 'relative',
                            width: '100%',
                            height: useAbsolutePositioning ? `${contentHeight}px` : 'auto',
                            flex: useAbsolutePositioning ? undefined : 1,
                            overflow: 'auto',
                            p: 1
                        }}
                    >
                        {child}
                    </Box>
                );
            })}
        </Paper>
    );
};
