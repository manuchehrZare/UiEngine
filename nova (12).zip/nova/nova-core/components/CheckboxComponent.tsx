/* eslint-disable */
/**
 * Checkbox Component Wrapper
 * Wraps the lib Checkbox component to handle EBML property conversions
 * and ensure all required properties have safe defaults to prevent undefined errors
 */

import React from 'react';
import { useFormContext } from 'react-hook-form';
import { Checkbox } from '../../../seker-ui-lib';
import type { NovaComponentProps } from '..';

export const CheckboxComponent: React.FC<NovaComponentProps> = ({
    id,
    label,
    name,
    value,
    checked,
    ...props
}) => {
    const context = useFormContext();
    const control = context ? context.control : undefined;

    // Ensure string properties are never undefined to prevent .substring() errors
    // Generate a fallback name if both name and id are undefined
    const safeName = name || id || `checkbox_${Math.random().toString(36).substring(2, 11)}`;

    // IMPORTANT: Do NOT pass 'checked' prop when control is present - the control manages the value
    const safeProps = {
        ...props,
        label: label || props.text || name || 'Checkbox',
        name: safeName,
        control: control as any,
    };

    return <Checkbox {...safeProps} />;
};
