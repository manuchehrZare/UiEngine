/* eslint-disable */
/**
 * Nova UI Schema Type Definitions
 * This is the unified schema format for Nova UI Studio
 */
// import type { EbmlEvents, EbmlRuleset, EbmlData } from './ebml.types';

import type { ComponentBounds, ParsedComponent } from "./ebml-parse.types";

/**
 * Nova UI Schema - Unified format for UI definitions
 * This schema maintains all aspects of the UI definition including:
 * - UI components
 * - Events/Actions
 * - Business rules
 * - Variables
 */
export interface NovaUiSchema {
    /** UI component tree */
    ui: DesignComponent[];

    /** Events and actions - Array of NovaEvent */
    events: NovaEvent[];

    /** Business rules (compatible with EbmlContent.Ruleset) */
    ruleset: NovaRuleset;

    /** Data section (compatible with EbmlContent.Data) */
    data: NovaData;

    /** Optional custom JavaScript code */
    jsCode?: string;

    /** Optional custom CSS code */
    cssCode?: string;

    /** Metadata about the schema */
    metadata?: {
        version: string;
        name?: string;
        description?: string;
        createdAt?: string;
        updatedAt?: string;
    };
}

export interface DesignComponent {
    id: string;
    type: string; // Key in COMPONENT_REGISTRY
    props: Record<string, any>;
    children: DesignComponent[];
    parentId?: string | null;
    // Note: Event bindings are stored separately in schema.events.bindings, not in components
}

/**
 * Rule - Business rule definition
 */
export interface Rule {
    id: string;
    name: string;
    type: 'Simple' | 'Message' | 'Combination';
    // Simple rule fields
    source?: string;
    sourceMethod?: string;
    operator?: 'ISEMPTY' | 'GTE' | 'LTE' | 'NE' | 'LT' | 'GT' | 'EQ';
    target?: string;
    targetType?: 'constant' | 'variable' | 'component';
    targetMethod?: string;
    // Message rule fields
    messageTitle?: string;
    messageType?: 'OK' | 'OK_CANCEL' | 'YES_NO';
    messageAppearance?: 'INFO' | 'WARNING' | 'ERROR';
    messageContent?: string;
    messageContentType?: 'constant' | 'variable';
    // Combination rule fields
    combinationExpression?: string;
}

/**
 * Data - Data definition
 */
export interface Variable {
    name: string;
    type: 'string' | 'integer' | 'boolean' | 'object' | 'array';
    initialValue?: any;
}

export interface SubAction {
    id: string;
    type: 'BeanAction' | 'RemoteCall' | 'ReferenceCall' | 'VariableSetting' | 'PageCall';
    rule?: string;
    // BeanAction fields
    beanValue?: string;
    method?: string;
    parameters?: Array<{ name: string; value: string; valueType: string; valueMethod?: string }>;
    // RemoteCall fields
    service?: string;
    inputs?: Array<{ bagKey: string; value: string; valueType: string; componentId?: string }>;
    outputs?: Array<{ bagKey: string; targetVariable?: string; targetId?: string; targetType: string }>;
    // ReferenceCall fields
    referencedAction?: string;
    // VariableSetting fields
    variableName?: string;
    variableValue?: string;
    variableValueType?: 'constant' | 'variable' | 'component' | 'rule';
    variableValueMethod?: string;
    // PageCall fields
    pageName?: string;
    pageTitle?: string;
    returnAction?: string;
    pageParameters?: Array<{ variableName: string; value: string; valueMethod: string }>;
}

/**
 * Action - Action definition with sub-actions
 * @deprecated This type is kept for backward compatibility with existing code
 * New implementations should use NovaEvent directly from NovaUiSchema.events array
 */
export interface Action {
    id: string;
    name: string;
    type?: string; // Event type from EBML (e.g., 'event', 'action')
    ref?: string; // Reference value from EBML events
    rule?: string; // Rule condition for triggering this action
    // Component event binding info (from EBML <lC>)
    componentId?: string; // id: Component that triggers this action
    eventName?: string; // n: Event name (e.g., 'pageLoad', 'onClick')
    eventType?: string; // type: 'event' or 'action'
    /** @deprecated Use actions instead. SubActions cause data loss during conversion. */
    subActions: SubAction[];
    /** Use this for new code - preserves all action step data */
    actions?: NovaEventActionStep[];
}

/**
 * Nova Event Action Step Types
 * These types mirror NovaEbmlActionStep structure but are separate for UI schema
 */
export type NovaEventActionStep =
    | { type: 'BeanAction', action: NovaBeanAction }
    | { type: 'RemoteCall', call: NovaRemoteCall }
    | { type: 'ReferenceCall', reference: string }
    | { type: 'VariableSetting', setting: NovaVariableSetting }
    | { type: 'PageCall', call: NovaPageCall };

export interface NovaBeanAction {
    targetId: string;
    method: string;
    value?: string | number | boolean;
    property?: string;
    sourceVar?: string;
    description?: string;
}

export interface NovaRemoteCall {
    serviceName: string;
    status?: string | number;
    /** Input parameters - each has type 'var' or 'p' */
    inputs?: NovaIOProperty[];
    /** Output parameters - each has type 'var' or 'p' */
    outputs?: NovaIOProperty[];
    description?: string;
}

// export interface NovaReferenceCall {
//     actionReference: string; // Referenced action ID
// }

export interface NovaVariableSetting {
    variableId: string;
    value?: string | number | boolean;
    rule?: string;
    sourceComp?: {
        componentId: string;
        method: string;
    };
    description?: string;
}

export interface NovaPageCall {
    pageName?: string;
    method?: string;
    params?: any[];
    description?: string;
}

/** @deprecated Use NovaIOProperty[] with type field instead */
export interface NovaIOCollection {
    var?: NovaIOProperty[];
    p?: NovaIOProperty[];
}

export interface NovaIOProperty {
    name: string;
    text: string;
    /** Property type: 'var' for variable, 'p' for parameter/constant */
    type?: 'var' | 'p';
    id?: string | null;
    m?: any;
    rule?: any;
    var?: any;
    n?: any;
    comp?: any;
}

/**
 * Nova Event - Event definition (separate from NovaEbmlEvent)
 * This is the UI schema representation of events
 */
export interface NovaEvent {
    id?: string;
    name?: string;
    type: string; // 'action' or 'event'
    refId?: string;
    actions: NovaEventActionStep[];
}

/**
 * Nova Ruleset - Business rules
 */
export interface NovaRuleset {
    /** List of rules */
    rules: Rule[];
}

/**
 * Nova Data - Data definitions (mirrors NovaEbmlDataSection structure)
 */
export interface NovaData {
    /** List of variables/data items */
    var: Variable[];
    /** Optional data definitions (for dropdowns, etc.) */
    definitions?: NovaDataDefinition[];
}

/**
 * Nova Data Definition - For defining data source options
 */
export interface NovaDataDefinition {
    id: string;
    options: NovaDataOption[];
    /** Column-specific definitions for table components */
    columnDefinitions?: NovaColumnDefinition[];
}

/**
 * Nova Column Definition - For table column data options
 */
export interface NovaColumnDefinition {
    columnId: string;
    options: NovaDataOption[];
}

/**
 * Nova Data Option - Individual option in a data definition
 */
export interface NovaDataOption {
    value: string;
    text: string;
}

export interface NovaComponentProps {
    id: string;
    name?: string;
    type?: string;
    label?: string;
    text?: string;
    value?: any;
    placeholder?: string;
    enabled?: string | boolean;
    bounds?: ComponentBounds;
    parentBounds?: ComponentBounds;
    useAbsolutePositioning?: boolean;
    xs?: number;
    children?: React.ReactNode;
    designComponent?: DesignComponent;
    // Legacy or specific props
    component?: ParsedComponent;
    componentKey?: string;
    [key: string]: any;
}

/**
 * Helper to convert NovaUiSchema to EBML format (for backward compatibility)
 */
// export interface EbmlCompatibleSchema {
//     Interface: {
//         Structure: {
//             Bean: any; // Will be converted from DesignComponent
//         };
//         Events?: EbmlEvents;
//     };
//     Data?: EbmlData;
//     Ruleset?: EbmlRuleset;
// }
