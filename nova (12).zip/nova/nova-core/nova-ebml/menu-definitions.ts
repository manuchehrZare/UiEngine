/* eslint-disable */
export const menuDefinitions =[
  {
    "menuName": "Müşteri Ana Grup Öncelik Düzenleme",
    "screenName": "PRD025_PROD_DEDUCTION_CUSTOMER_MAIN_GROUP_ORDER",
    "screenCode": "PRD025",
    "screenDescription": "MÜŞTERİ ANA GRUPLARININ ÖNCELİKLENDİRİLMESİ"
  },
     {
    "menuName": "Karekod CVM Parametre Tanımlama",
    "screenName": "CPS100_CCC_CVM_PARAMETER",
    "screenCode": "CPS100",
    "screenDescription": "CVM PARAMETRELERİNİN TANIMLARININ YAPILMASI İÇİN KULLANILAN EKRAN"
  },
   {
        "menuName": "Gerçek Müşteri Düzenleme",
        "screenName": "CUS001_PERS_INDV_DEFINITION",
        "screenCode": "CUS001",
        "screenDescription": "GERÇEK MÜŞTERİ DÜZENLEME"
    },
    {
        "menuName": "Yeniden Yapılandırma Talep  Formu",
        "screenName": "CRD001_CREDIT_KTF",
        "menuKey": "4",
        "screenCode": "CRD001"
    },
  {
    "menuName": "Kısıt Kaldırma",
    "screenName": "MEV004_DEPOSIT_HOLD_RELEASE",
    "screenCode": "MEV004"
  },
  {
    "menuName": "Kısıt Koyma",
    "screenName": "MEV003_DEPOSIT_HOLD_MONEY",
    "screenCode": "MEV003"
  },
  {
    "menuName": "Bloke Koyma",
    "screenName": "MEV007_DEPOSIT_MONEY_BLOCKING",
    "screenCode": "MEV007"
  },
  {
    "menuName": "Bloke Çözme",
    "screenName": "MEV008_DEPOSIT_BLOCK_RELEASE",
    "screenCode": "MEV008"
  },
  {
    "menuName": "Gece Gündüz Hesap Tanımlama/ Güncelleme Ekranı",
    "screenName": "MEV221_DEPOSIT_DAY_NIGHT_ACC",
    "screenCode": "MEV221"
  },
  {
    "menuName": "Vadeli Hesap Temdit Edilen Hesap İşlemleri",
    "screenName": "MEV122_TIME_DEPOSIT_RENEWAL_LIST_NEW",
    "screenCode": "MEV122"
  },
  {
    "menuName": "Gece Gündüz Parametre Girişi",
    "screenName": "MEV202_DEPOSIT_DAY_NIGHT_PARAMETERS_DEF",
    "screenCode": "MEV202",
    "screenDescription": "GECE-GÜNDÜZ HESAP PARAMETRE TANIMLAMA"
  },
  {
    "menuName": "Kısıt Gözlem Raporu",
    "screenName": "MEV038_DEPOSIT_HOLD_LIST",
    "screenCode": "MEV038",
    "screenDescription": "MEV038_DEPOSIT_HOLD_LIST"
  },
  {
    "menuName": "Bloke Gözlem Raporu",
    "screenName": "MEV027_DEPOSIT_BLOCK_LIST",
    "screenCode": "MEV027",
    "screenDescription": "MEV027_DEPOSIT_BLOCK_LIST"
  },
  {
    "menuName": "KMH Gecikme Listesi",
    "screenName": "MEV026_DEPOSIT_KRM_BKS_CHASING",
    "screenCode": "MEV026"
  },
  {
    "menuName": "KMH Tahakkuk Listesi",
    "screenName": "MEV017_DEPOSIT_KRM_ASSESSMENT_LIST",
    "screenCode": "MEV017"
  },
  {
    "menuName": "KMH Hesapları Gözlem",
    "screenName": "MEV047_DEPOSIT_KRM_ACCOUNT_LIST",
    "screenCode": "MEV047"
  },
  {
    "menuName": "Vadesiz Hesap Tarihçe Gözlem",
    "screenName": "MEV010_DEPOSIT_ACCOUNT_HISTORY",
    "screenCode": "MEV010"
  },
  {
    "menuName": "KMH Hareketleri",
    "screenName": "MEV019_DEPOSIT_KRM_TRANSACTIONS",
    "screenCode": "MEV019"
  },
  {
    "menuName": "KMH Reeskont Listesi",
    "screenName": "MEV015_DEPOSIT_KRM_REESKONT_LIST",
    "screenCode": "MEV015"
  },
  {
    "menuName": "Vadesiz Hesap Tahakkuk Gözlem",
    "screenName": "MEV023_DEPOSIT_ASSESSMENT_LIST",
    "screenCode": "MEV023"
  },
  {
    "menuName": "Vadesiz Hesap Reeskont Gözlem",
    "screenName": "MEV022_DEPOSIT_REESKONT_LIST",
    "screenCode": "MEV022"
  },
  {
    "menuName": "Vadesiz Hesap Hareketleri",
    "screenName": "MEV002_DEPOSIT_ACCOUNT_TRANSACTIONS",
    "screenCode": "MEV002"
  },
  {
    "menuName": "Vadesiz Hesap Bakiye Gözlem",
    "screenName": "MEV200_DEPOSIT_CURRENT_BALANCE_LIST",
    "screenCode": "MEV200",
    "screenDescription": "VADESİZ HESAP BAKİYE GÖZLEM EKRANI"
  },
  {
    "menuName": "Vadesiz Hesap Listesi",
    "screenName": "MEV012_DEPOSIT_ACCOUNT_LIST",
    "screenCode": "MEV012"
  },
  {
    "menuName": "Hesap işletim/Ekstre/Geçmiş ekstre/Gecikme ücreti Gözlem",
    "screenName": "MEV013_DEPOSIT_CHARGE_LIST",
    "screenCode": "MEV013"
  },
  {
    "menuName": "Kampanya Müşteri Listesi",
    "screenName": "MEV049_DEPOSIT_CAMPAIGN_CUST_LIST",
    "screenCode": "MEV049"
  },
  {
    "menuName": "Birikimli Gelecek / Şeker Çocuk Hesap Tahsil Edilmemiş Dönemler Listesi",
    "screenName": "MEV069_TIME_DEPOSIT_CUMULATIVE_UNPAID_MONTH_PAYMENT",
    "screenCode": "MEV069",
    "screenDescription": "BİRİKİMLİ VADELİ ÖDENMEMİŞ DÖNEM GÖZLEM EKRANI"
  },
  {
    "menuName": "ArtanHesap Tanımlama/Güncelleme",
    "screenName": "MEV100_SEKERHESAP_DEFINITION",
    "screenCode": "MEV100"
  },
  {
    "menuName": "ArtanHesap Fon İşlemleri Gözlem",
    "screenName": "MEV101_SEKERHESAP_FUND_TRANSACTIONS",
    "screenCode": "MEV101"
  },
  {
    "menuName": "ArtanHesap Ödeme Talimatları Gözlem",
    "screenName": "MEV102_SEKERHESAP_PAY_ORDERS_LIST",
    "screenCode": "MEV102"
  },
  {
    "menuName": "ArtanHesap Fon İşlemleri",
    "screenName": "MEV103_SEKERHESAP_FUND_OPERATIONS",
    "screenCode": "MEV103"
  },
  {
    "menuName": "Hesap Gizlilik Profil İlişkisi",
    "screenName": "MEV037_DEPOSIT_CURRENT_ACC_PRIVACY",
    "screenCode": "MEV037"
  },
  {
    "menuName": "Ekstre Bilgileri Tanımlama",
    "screenName": "MEV041_DEPOSIT_EKSTRE_INFORMATION",
    "screenCode": "MEV041",
    "screenDescription": "EKSTE BİLGİLERİ"
  },
  {
    "menuName": "Manuel Ekstre Üretme",
    "screenName": "MEV025_DEPOSIT_CREATE_EKSTRE",
    "screenCode": "MEV025"
  },
  {
    "menuName": "Hesap işletim/Ekstre/Geçmiş ekstre/Gecikme ücreti iptal",
    "screenName": "MEV028_DEPOSIT_CANCEL_CHARGE",
    "screenCode": "MEV028"
  },
  {
    "menuName": "Yeni Gece Gündüz Parametre Düzenleme",
    "screenName": "MEV227_DEPOSIT_GG_PARAMETERS",
    "screenCode": "MEV227",
    "screenDescription": "YENİ GECE GÜNDÜZ PARAMETRE EKRANI"
  },
  {
    "menuName": "Hesap İşletim Ücreti Parametre Tanımlama",
    "screenName": "MEV215_DEPOSIT_ACC_MAN_FEE_PARAMETERS_DEF",
    "screenCode": "MEV215",
    "screenDescription": "HESAP İŞLETİM ÜCRETİ PARAMETRE TANIMLAMA EKRANI"
  },
  {
    "menuName": "KMH Nakit Kullandırım Gözlem",
    "screenName": "MEV203_DEPOSIT_KRM_USAGE_CHARGE_LIST",
    "screenCode": "MEV203",
    "screenDescription": "KMH NAKİT KULLANDIRIM GÖZLEM EKRANI"
  },
  {
    "menuName": "Bankalar Hesabı Açma",
    "screenName": "MEV039_DEPOSIT_CURRENT_BANK_ACCOUNT",
    "screenCode": "MEV039",
    "screenDescription": "BANKA KRM HESABI AÇMA/GÜNCELLEME"
  },
  {
    "menuName": "TKMH Yönetsel",
    "screenName": "MEV030_DEPOSIT_KRM_INSTALLMENT",
    "screenCode": "MEV030"
  },
  {
    "menuName": "KMH Manuel Tahakkuk Hesapla",
    "screenName": "MEV018_DEPOSIT_KRM_MANUEL_ASSESSMENT",
    "screenCode": "MEV018"
  },
  {
    "menuName": "KMH kampanya Müşteri Ekleme/Çıkarma",
    "screenName": "MEV218_DEPOSIT_KRM_ACC_CAMPAIGN_UPDATE",
    "screenCode": "MEV218"
  },
  {
    "menuName": "Kampanya Müşteri Ekleme",
    "screenName": "MEV043_DEPOSIT_CAMPAIGN_CUST_ADDITION",
    "screenCode": "MEV043"
  },
  {
    "menuName": "Kampanya Tanımlama/Güncelleme",
    "screenName": "MEV042_DEPOSIT_CAMPAIGN_DEFINITION",
    "screenCode": "MEV042"
  },
  {
    "menuName": "KMH Kampanya Tanımlama Parametre Ekranı",
    "screenName": "MEV219_DEPOSIT_KRM_CAMPAIGN_DEF",
    "screenCode": "MEV219"
  },
  {
    "menuName": "KMH Hesap İşletim Ücreti İstisnası Düzenleme",
    "screenName": "MEV029_DEPOSIT_CURRENT_BRANCH_KRM",
    "screenCode": "MEV029"
  },
  {
    "menuName": "Vadesiz Hesap Açma/Güncelleme",
    "screenName": "MEV001_DEPOSIT_CURRENT_ACC_DEFINITION",
    "screenCode": "MEV001"
  },
  {
    "menuName": "Vadesiz Hesap Süpürme",
    "screenName": "MEV216_DEPOSIT_SWEEP_CREATE",
    "screenCode": "MEV216"
  },
  {
    "menuName": "Taksitli KMH Tanımlama ve Güncelleme",
    "screenName": "MEV031_DEPOSIT_KRM_INSTALLMENT_ACCOUNT",
    "screenCode": "MEV031"
  },
  {
    "menuName": "Koruma Hesabı Bloke Talimat Gözlem",
    "screenName": "MEV224_DEPOSIT_PROTECTED_ACC_BLOCK_ORDER_LIST",
    "screenCode": "MEV224"
  },
  {
    "menuName": "KMH Nakit Kullandırım İptal",
    "screenName": "MEV204_DEPOSIT_KRM_CANCEL_USAGE_CHARGE",
    "screenCode": "MEV204",
    "screenDescription": "KMH NAKİT KULLANDIRIM İPTAL EKRANI"
  },
  {
    "menuName": "Koruma Hesabı İstisna Bloke Talimatı",
    "screenName": "MEV223_DEPOSIT_RATE_PROTECTED_ACC_BLOCK_ORDER",
    "screenCode": "MEV223"
  },
  {
    "menuName": "Bütçem Taksitli Debit KMH Virman/Virman İptali",
    "screenName": "MEV210_DEPOSIT_BUDGET_TKMH_VIRMAN_OPERATIONS",
    "screenCode": "MEV210",
    "screenDescription": "BÜTÇEM TAKSİTLİ DEBİT KMH VİRMAN / VİRMAN İPTALİ"
  },
  {
    "menuName": "Bütçem Debit KMH Toplu Tahsilat",
    "screenName": "MEV212_DEPOSIT_KRM_BUDGET_COLLECTIVE_PAYMENT",
    "screenCode": "MEV212",
    "screenDescription": "BÜTÇEM DEBİT KMH TOPLU TAHSİLAT"
  },
  {
    "menuName": "Bütçem Taksitli Debit KMH Gözlem",
    "screenName": "MEV211_DEPOSIT_KRM_BUDGET_TKMH_ACC_INFO",
    "screenCode": "MEV211",
    "screenDescription": "BÜTÇEM TAKSİTLİ DEBİT KMH GÖZLEM EKRANI"
  },
  {
    "menuName": "Taksitli KMH İptal",
    "screenName": "MEV034_DEPOSIT_KRM_CANCEL_INSTALLMENT_PAYMENT",
    "screenCode": "MEV034",
    "screenDescription": "TKMH İPTAL EKRANI"
  },
  {
    "menuName": "KMH Limit Dondurma",
    "screenName": "MEV048_DEPOSIT_KRM_LIMIT_CANCEL",
    "screenCode": "MEV048"
  },
  {
    "menuName": "KMH İşlem Listesi",
    "screenName": "MEV046_DEPOSIT_KRM_PROCESS_LIST",
    "screenCode": "MEV046"
  },
  {
    "menuName": "KMH Limitinden Tahsilat Yönetimi",
    "screenName": "MEV006_DEPOSIT_KRM_COLLECT_MANAGEMENT",
    "screenCode": "MEV006"
  },
  {
    "menuName": "Taksitli KMH Simülasyon",
    "screenName": "MEV201_DEPOSIT_KRM_INSTALLMENT_SIMULATION",
    "screenCode": "MEV201"
  },
  {
    "menuName": "KMH Tahakkuk Tarihi Güncelleme",
    "screenName": "MEV044_DEPOSIT_KRM_UPDATE_ASSESSMENT_DATE",
    "screenCode": "MEV044"
  },
  {
    "menuName": "Vadesiz Mevduat Taahhüt Giriş/Gözlem",
    "screenName": "MEV220_DEPOSIT_CURRENT_ACC_CONTRACT",
    "screenCode": "MEV220",
    "screenDescription": "MÜŞTERİ MEVDUAT ORTALAMA"
  },
  {
    "menuName": "Taksitli KMH Ödeme",
    "screenName": "MEV032_DEPOSIT_KRM_INSTALLMENT_PAYMENT",
    "screenCode": "MEV032"
  },
  {
    "menuName": "Eşit Taksitli KMH Ödeme",
    "screenName": "MEV206_DEPOSIT_TKMH_PAYMENT",
    "screenCode": "MEV206",
    "screenDescription": "YENİ TKMH TAKSİT ÖDEME"
  },
  {
    "menuName": "Eşit Taksitli KMH Tanımlama / Güncelleme",
    "screenName": "MEV205_DEPOSIT_TKMH_ACCOUNT",
    "screenCode": "MEV205",
    "screenDescription": "YENİ TKMH TANIMLAMA / GÜNCELLEME"
  },
  {
    "menuName": "Eşit Taksitli KMH Simülasyon",
    "screenName": "MEV209_DEPOSIT_TKMH_SIMULATION",
    "screenCode": "MEV209",
    "screenDescription": "TAKSİTLİ KMH SİMULASYON"
  },
  {
    "menuName": "Eşit Taksitli KMH Tahsilat İptal",
    "screenName": "MEV208_DEPOSIT_TKMH_CANCEL_PAYMENT",
    "screenCode": "MEV208",
    "screenDescription": "TAKSİTLİ KMH TAHSİLAT İPTAL"
  },
  {
    "menuName": "Eşit Taksitli KMH Kullandırım İptal",
    "screenName": "MEV207_DEPOSIT_TKMH_CANCEL_CREATE",
    "screenCode": "MEV207",
    "screenDescription": "YENİ TKMH KULLANDIRIM İPTAL"
  },
  {
    "menuName": "Vadesiz Hesap Faiz Güncelleme",
    "screenName": "MEV020_DEPOSIT_CURRENT_ACC_UPDATE_INT_RATE",
    "screenCode": "MEV020"
  },
  {
    "menuName": "KMH Ürün Parametreleri Tanımlama-Bireysel",
    "screenName": "MEV014_DEPOSIT_KRM_DEFINITION",
    "menuKey": "BKS",
    "screenCode": "MEV014"
  },
  {
    "menuName": "Banka Hesapları Açma",
    "screenName": "MEV001_DEPOSIT_CURRENT_ACC_DEFINITION",
    "menuKey": "GM",
    "screenCode": "MEV001"
  },
  {
    "menuName": "Koruma Hesabı Bloke Talimatı",
    "screenName": "MEV222_DEPOSIT_RATE_PROTECTED_ACC_BLOCK_ORDER",
    "screenCode": "MEV222"
  },
  {
    "menuName": "KMH Ürün Parametreleri Tanımlama-Ticari",
    "screenName": "MEV014_DEPOSIT_KRM_DEFINITION",
    "menuKey": "CCS",
    "screenCode": "MEV014"
  },
  {
    "menuName": "Kurumsal KMH Güncelleme",
    "screenName": "MEV033_DEPOSIT_KRM_UPDATE_EXPIRED_CORPORATE_KRM",
    "screenCode": "MEV033",
    "screenDescription": "KURUMSAL KMH GÜNCELLEME"
  },
  {
    "menuName": "Vadesiz Hesap Parametre Tanımlama",
    "screenName": "MEV005_DEPOSIT_PARAMETERS",
    "screenCode": "MEV005"
  },
  {
    "menuName": "ATM İşlem Gözlem",
    "screenName": "ATM002_ATM_TRANSACTION_INFO",
    "screenCode": "ATM002"
  },
  {
    "menuName": "ATM Gişeden Masraf İade İşlemi",
    "screenName": "ATM064_ATM_COMMISSION_REFUND_CASH",
    "screenCode": "ATM064",
    "screenDescription": "ATM NAKİT MASRAF İADE İŞLEMLERİNDE ŞUBELERİN İŞLEM YAPACAĞI EKRAN."
  },
  {
    "menuName": "ATM Masraf İade İşlemleri Gözlem",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM063",
    "screenCode": "ATM063",
    "screenDescription": "ATM KOMİSYON İŞLEMLERİNİ LİSTELEYEN EKRAN."
  },
  {
    "menuName": "ATM İşlem Aktivite Gözlem",
    "screenName": "ATM057_ATM_TRANSACTION_ACTIVITY_LOG",
    "screenCode": "ATM057",
    "screenDescription": "HAREKET İŞLEMLERİ LOG GÖZLEM EKRANI"
  },
  {
    "menuName": "ATM FTP Hata Gözlem",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM054",
    "screenCode": "ATM054",
    "screenDescription": "ATM FTP HATA GÖZLEM"
  },
  {
    "menuName": "ATM Alıkonulan Kartlar",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM004",
    "screenCode": "ATM004"
  },
  {
    "menuName": "ATM Gözlem",
    "screenName": "ATM001_ATM_MONITORING",
    "screenCode": "ATM001"
  },
  {
    "menuName": "ATM Arıza Raporu (NCR'a Bildirilen)",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM092",
    "screenCode": "ATM092"
  },
  {
    "menuName": "ATM Masraf İade İşlemi",
    "screenName": "ATM062_ATM_COMMISSION_REFUND",
    "screenCode": "ATM062",
    "screenDescription": "ATM MASRAF İADE İŞLEMLERİNİN GİRİLECEĞİ EKRAN."
  },
  {
    "menuName": "ATM Online Hareket Görüntüleme",
    "screenName": "ATM030_ATM_ONLINE_ACTION_MONITORING",
    "screenCode": "ATM030"
  },
  {
    "menuName": "ATM Hat Durumu İzleme Ekran",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM009",
    "screenCode": "ATM009"
  },
  {
    "menuName": "ATM Gün Sonu Bilgi Görüntüleme",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM056",
    "screenCode": "ATM056"
  },
  {
    "menuName": "ATM Manuel Takas İşlemleri",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM024",
    "screenCode": "ATM024",
    "screenDescription": "ATM MANUEL TAKAS İŞLEMLERİ"
  },
  {
    "menuName": "ATM Arıza Raporu (NCR'a Bildirilmeyen)",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM091",
    "screenCode": "ATM091"
  },
  {
    "menuName": "ATM Gider Verileri",
    "screenName": "ATM095_ATM_COSTS",
    "screenCode": "ATM095",
    "screenDescription": "ATM GİDER VERİLERİNİN TUTULDUĞU SAYFA"
  },
  {
    "menuName": "ATM Kontrol Formu",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM026",
    "screenCode": "ATM026"
  },
  {
    "menuName": "ATM Hareket Görüntüleme",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM003",
    "screenCode": "ATM003"
  },
  {
    "menuName": "ATM-Fatura Kurumları Tanımlama",
    "screenName": "ATM047_ATM_PAYMENT_INSTITUTION",
    "screenCode": "ATM047"
  },
  {
    "menuName": "Memo Log Gözlem",
    "screenName": "ATM017_ATM_MEMO_LOG",
    "screenCode": "ATM017"
  },
  {
    "menuName": "ATM Domestic Bin Tanımlama",
    "screenName": "ATM032_ATM_DOMESTIC_BIN_DEFINITION",
    "screenCode": "ATM032"
  },
  {
    "menuName": "ATM Bin Sorgulama",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM043 ",
    "screenCode": "ATM043",
    "screenDescription": "VISA MASTER BIN SORGULAMA"
  },
  {
    "menuName": "ATM Tanımlama",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM011",
    "screenCode": "ATM011"
  },
  {
    "menuName": "ATM Sunucu Yönetim",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM060",
    "screenCode": "ATM060",
    "screenDescription": "ATMCOMM SUNUCULARININ BİLGİLERİNİN YÖNETİLDİĞİ EKRAN"
  },
  {
    "menuName": "ATM Organizasyon Bilgileri Teknik Tanımlar",
    "screenName": "ATM021_ATM_ORGANIZATION_TECH_INFO",
    "screenCode": "ATM021"
  },
  {
    "menuName": "ATM Sistem Parametreleri Ekle/Güncelle",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM052",
    "screenCode": "ATM052"
  },
  {
    "menuName": "ATM Kampanya Tanımlama",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM053",
    "screenCode": "ATM053"
  },
  {
    "menuName": "ATM Response Kod/İşlem Kod Tanımlama",
    "screenName": "https://atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM046",
    "screenCode": "ATM046",
    "screenDescription": "RESPONSE KOD İŞLEM KOD TANIMLAMA"
  },
  {
    "menuName": "ATM Test",
    "screenName": "ATM999_ATM_TEST_SERVICE",
    "screenCode": "ATM999"
  },
  {
    "menuName": "ATM E-Journal Görüntüleme",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM042",
    "screenCode": "ATM042"
  },
  {
    "menuName": "ATM'e Komut ve Veri Gönderim İşlemleri",
    "screenName": "ATM040_ATM_SEND_CUSTOMISATION_DATA",
    "screenCode": "ATM040"
  },
  {
    "menuName": "Fraud  Kart İşlemleri",
    "screenName": "ATM036_ATM_FRAUD_CARD_ENTRY_AND_MONITORING",
    "screenCode": "ATM036"
  },
  {
    "menuName": "ATM'lere Komut Gönderme Log Gözlem",
    "screenName": "https://nova-atmsystems-atm-ui-set-alfa.nprd.ocp.sekerbank.com.tr/ATMSystems/ATM051",
    "screenCode": "ATM051"
  },
  {
    "menuName": "Müşteri Dokümanları Raporu",
    "screenName": "DMS028_SEARCH_ATTR_WITH_MULTI_USER",
    "screenCode": "DMS028",
    "screenDescription": "MÜŞTERİLERİN KAYITLI DOKÜMANLARINI VE ÖZNİTELİKLERİNİ LİSTELER"
  },
  {
    "menuName": "Doküman Tip İstatistikleri",
    "screenName": "DMS027_DOC_STATS_ICM",
    "screenCode": "DMS027",
    "screenDescription": "DMS TİP VE DOKÜMAN İSTATİSTİKLERİ EKRANI"
  },
  {
    "menuName": "Döküman Formatları Tanımlama",
    "screenName": "DMS009_DOC_FORMAT",
    "screenCode": "DMS009",
    "screenDescription": "DOKÜMAN FORMATLARI"
  },
   {
    "menuName": "Kapanan Provizyonlar",
    "screenName": "AMS006_CLOSED_AUTHORIZATION",
    "screenCode": "AMS006"
  },
  {
    "menuName": "Issuer Provizyon İsteği",
    "screenName": "AMS051_ISSUER_AUTHORIZATION_REQUEST",
    "screenCode": "AMS051"
  },
  {
    "menuName": "Manuel Reversal",
    "screenName": "AMS102_MANUAL_REVERSAL",
    "screenCode": "AMS102"
  },
  {
    "menuName": "Bekleyen Provizyonlar",
    "screenName": "AMS002_OUTSTANDING_AUTHORIZATION",
    "screenCode": "AMS002"
  },
  {
    "menuName": "Pin By Pass - Pin Block",
    "screenName": "AMS038_MCC_FILTER_FOR_PIN_BYPASS",
    "screenCode": "AMS038"
  },
  {
    "menuName": "Provizyon Filtre Parametreleri",
    "screenName": "AMS037_PROVISION_FILTER_PARAMETERS",
    "screenCode": "AMS037"
  },
  {
    "menuName": "Provizyon Parametreleri Log Görüntüleme",
    "screenName": "AMS032_AUTHORIZATION_PROCESS_LOG",
    "screenCode": "AMS032"
  },
  {
    "menuName": "Parametre Yükleme",
    "screenName": "AMS031_AMS_LOAD_AUTH_PARAMS",
    "screenCode": "AMS031"
  },
  {
    "menuName": "Birincil Parametreler",
    "screenName": "AMS021_PRIMARY_AUTHORIZATION_PARAMETERS",
    "screenCode": "AMS021"
  },
  {
    "menuName": "Limit Aşım Parametreleri",
    "screenName": "AMS026_OVERLIMIT_PARAMETERS",
    "screenCode": "AMS026"
  },
  {
    "menuName": "İşyeri Tanımlama",
    "screenName": "AMS030_MERCHANT_DEFINITIONS",
    "screenCode": "AMS030"
  },
  {
    "menuName": "Çip Parametreleri",
    "screenName": "AMS029_CHIP_PROVISION_PARAMETERS",
    "screenCode": "AMS029"
  },
  {
    "menuName": "Decline Codes",
    "screenName": "AMS036_DECLINE_CODES",
    "screenCode": "AMS036"
  },
  {
    "menuName": "Kart Bazlı Parametreler",
    "screenName": "AMS035_CARD_BASED_PARAMETERS",
    "screenCode": "AMS035"
  },
  {
    "menuName": "Provizyon Log Görüntüleme",
    "screenName": "https://nova-cps-ams-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/AMS/AMS003",
    "screenCode": "AMS003"
  },
  {
    "menuName": "Şekerbonus Limit Değişikliği",
    "screenName": "SKBNS019_SKBNS_LIMIT_INCREASE",
    "screenCode": "SKBNS019"
  },
  {
    "menuName": "Şekerkart Limit Değişikliği PC",
    "screenName": "CCMS109_CCMS_LIMIT_INCREASE",
    "screenCode": "CCMS109",
    "screenDescription": "PC ÜZERİNDEN YAPILAN LİMİT ARTTIRIMLARI"
  },
  {
    "menuName": "Limit Sorgulama",
    "screenName": "CCMS102_CCMS_LIMIT_QUERY",
    "screenCode": "CCMS102"
  },
  {
    "menuName": "Şekerkart Limit Değişikliği",
    "screenName": "CCMS101_CCMS_LIMIT_INCREASE",
    "screenCode": "CCMS101",
    "screenDescription": "CCMS LIMIT DEĞİŞİKLİK EKRANI"
  },
  {
    "menuName": "Kredi Kartları Yenileme Başvuru",
    "screenName": "CCMS110_CCMS_CARD_RENEW_DIFFERENCE",
    "screenCode": "CCMS110",
    "screenDescription": "KART YENILEME EKRANI"
  },
  {
    "menuName": "Acil Giriş",
    "screenName": "CCMS103_CCMS_LIMIT_QUICK_MANAGE",
    "screenCode": "CCMS103",
    "screenDescription": "ACİL GİRİŞ EKRANI"
  },
  {
    "menuName": "TCC Limit Tanımlama",
    "screenName": "CCMS508_TCC_LIMIT_DEFINITIONS",
    "screenCode": "CCMS508",
    "screenDescription": "TCC_LIMIT TANIMLARININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Ticari Kart Logo Tanımlama",
    "screenName": "CCMS117_LOGO_MANAGEMENT",
    "screenCode": "CCMS117",
    "screenDescription": "TİCARİ KART LOGO BASIM TANIMLARI"
  },
  {
    "menuName": "MCC-TCC Eşleştirme",
    "screenName": "CCMS507_MCC_TCC_MAPPING",
    "screenCode": "CCMS507",
    "screenDescription": "TCC MCC MAPPING ININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Puan Aktarılacak Kart Tanımlama",
    "screenName": "CCMS509_BC_DEFINE_REWARDED_CARD",
    "screenCode": "CCMS509",
    "screenDescription": "BUSINESS CARD PUAN ALACAK MÜŞTERİ TANIMLAMA"
  },
  {
    "menuName": "TCC Tanımlama",
    "screenName": "CCMS506_TCC_DESCRIPTION",
    "screenCode": "CCMS506",
    "screenDescription": "TCC TANIMLAMALARININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Mutabakat Raporları",
    "screenName": "RPT002_MUTABAKAT_RAPORLARI",
    "screenCode": "RPT002"
  },
  {
    "menuName": "Outgoing Dataları Özeti",
    "screenName": "ITS032_OUTGOING_SEARCH",
    "screenCode": "ITS032",
    "screenDescription": "OUTGOING DATALARI GÖRÜNTÜLEME EKRANI"
  },
  {
    "menuName": "Takas Arama_Ekleme",
    "screenName": "ITS001_EXCEPTION_ITEM_SEARCH",
    "screenCode": "ITS001",
    "screenDescription": "KULLANICI TARAFINDAN VE BATCH'DE TANIMLANAN TÜM AKSİYONLARIN LİSTELENDİĞİ EKRAN"
  },
  {
    "menuName": "Gelen/Giden Takas Dosyaları Özeti",
    "screenName": "TMS011_FILE_DETAIL_SEARCH",
    "screenCode": "TMS011",
    "screenDescription": "INCOMING VE OUTGOING DATA'LARIN ÖZET BİLGİLERİNİN VE DETAYININ GÖSTERİLDİĞİ EKRAN"
  },
  {
    "menuName": "Takas Hata Alan Kayıtlar",
    "screenName": "https://nova-cps-interchange-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/interChange/TMS020",
    "screenCode": "TMS020",
    "screenDescription": "TAKAS HATA ALAN KAYITLAR LİSTESİ"
  },
  {
    "menuName": "TMS Arama",
    "screenName": "TMS010_ACTION_SEARCH",
    "screenCode": "TMS010"
  },
  {
    "menuName": "Bonusnet Takas Muhasebesi",
    "screenName": "CCMS215_INTCHNG_ACCOUNTING_BNS",
    "screenCode": "CCMS215",
    "screenDescription": "BONUS NET TAKAS MUHASEBE EKRANI"
  },
  {
    "menuName": "Bkm Takas Muhasebesi",
    "screenName": "CCMS216_INTCHNG_ACCOUNTING_BKM",
    "screenCode": "CCMS216",
    "screenDescription": "BKM TAKAS MUHASEBESİ  EKRANI"
  },
  {
    "menuName": "Batch Ve Post Tarihleri Şeması",
    "screenName": "TMS002_BATCH_POST_PROCESSING_SCHEDULE_RECORD",
    "screenCode": "TMS002"
  },
  {
    "menuName": "Takas Dosya Yükleme",
    "screenName": "TMS001_FILE_UPLOAD",
    "screenCode": "TMS001"
  },
  {
    "menuName": "Reject Olmuş Kayıt Arama",
    "screenName": "TMS006_COMMON_INPUT_SEARCH_REJECTED",
    "screenCode": "TMS006"
  },
  {
    "menuName": "Takas Komisyon Oranları",
    "screenName": "CLR001_CLEARING_COMM_RATE",
    "screenCode": "CLR001",
    "screenDescription": "TAKAS KOMİSYON ORANLARI"
  },
  {
    "menuName": "Batch İşi İptal Etme",
    "screenName": "TMS008_BATCH_JOBS",
    "screenCode": "TMS008"
  },
  {
    "menuName": "Common Input Kolon Eşleştirme",
    "screenName": "TMS004_COMMON_INPUT_MATCH_COLONS",
    "screenCode": "TMS004"
  },
  {
    "menuName": "Mastercard Member ID Tablosu",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/TMS014",
    "screenCode": "TMS014"
  },
  {
    "menuName": "Mastercard Issuer Accont Range Tablosu",
    "screenName": "TMS012_MASTERCARD_ISSUER_ACCOUNT_RANGE",
    "screenCode": "TMS012"
  },
  {
    "menuName": "Mastercard Acquirer Bin Tablosu",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/TMS013",
    "screenCode": "TMS013"
  },
  {
    "menuName": "Visa Bin Tablosu",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/TMS016",
    "screenCode": "TMS016"
  },
  {
    "menuName": "Visa Account Range Tablosu",
    "screenName": "TMS017_VISA_ACCOUNT_RANGE",
    "screenCode": "TMS017"
  },
  {
    "menuName": "Domestic Bin Tablosu",
    "screenName": "TMS003_DOMESTIC_BIN",
    "screenCode": "TMS003"
  },
  {
    "menuName": "Domestic Bin",
    "screenName": "TMS003_DOMESTIC_BIN",
    "screenCode": "TMS003"
  },
  {
    "menuName": "Takas Dosya Geri Alma",
    "screenName": "TMS009_TMS_REVERSAL",
    "screenCode": "TMS009"
  },
  {
    "menuName": "Reject Kayıt Yetkilendirme",
    "screenName": "TMS005_COMMON_INPUT_UPDATE_REJECT_DEFINITIONS",
    "screenCode": "TMS005"
  },
  {
    "menuName": "Aktif Satış Personeli",
    "screenName": "CCA025_ACTIVE_SALES_MANAGEMENT",
    "screenCode": "CCA025"
  },
  {
    "menuName": "Başvuru Kontrolü",
    "screenName": "CCA007_APPLICATION_CONTROL",
    "screenCode": "CCA007",
    "screenDescription": "BAŞVURU KONTROL EKRANI"
  },
  {
    "menuName": "Belge Geçmişi",
    "screenName": "CCA840_DOCUMENT_BRANCH_HISTORY",
    "screenCode": "CCA840",
    "screenDescription": "BELGE GEÇMİŞİ TAKİP EKRANI"
  },
  {
    "menuName": "Bireysel Giriş",
    "screenName": "CCA900_APPLICATION_CREATE",
    "screenCode": "CCA900",
    "screenDescription": "KK BASVURU ILK GIRIS"
  },
  {
    "menuName": "Bilgi ve Belge Tamamlama",
    "screenName": "CCA800_COMPLETE_MISSING_INFO",
    "screenCode": "CCA800",
    "screenDescription": "BİLGİ VE BELGE TAMAMLAMA EKRANI"
  },
  {
    "menuName": "ADK Kanalı Başvuru Giriş",
    "screenName": "CCA003_ADK_APP_INFO",
    "screenCode": "CCA003",
    "screenDescription": "ÇAĞRI MERKEZİ BAŞVURU BİLGİLERİ GİRİŞ EKRANI"
  },
  {
    "menuName": "İade Yönetimi",
    "screenName": "CCA008_APPLICATION_RETURN_MANAGEMENT",
    "screenCode": "CCA008",
    "screenDescription": "İADE YÖNETİMİ EKRANI"
  },
  {
    "menuName": "Şekerbonus Business Ek kart",
    "screenName": "CCA910_BUSINESS_APP_SUPPLEMENTARY_CARD",
    "screenCode": "CCA910"
  },
  {
    "menuName": "Bireysel Kredi Kartı Başvuru",
    "screenName": "CCA916_CREDIT_CARD_APPLICATION",
    "screenCode": "CCA916",
    "screenDescription": "ŞUBE KANALI KREDİ KART BAŞVURU EKRANI"
  },
  {
    "menuName": "Bağımsız Ek Kart",
    "screenName": "CCA002_APPLICATION_SUPPLEMENTARY_CARD",
    "screenCode": "CCA002",
    "screenDescription": "BAĞIMSIZ EK KART BAŞVURU GİRİŞİ"
  },
  {
    "menuName": "ÇM Kanalından KK Başvuru Talebi Alma",
    "screenName": "CCA027_ADK_CM_INSERT",
    "screenCode": "CCA027",
    "screenDescription": "ÇM  KANALINDAN KK BAŞVURU TALEBİ ALMA"
  },
  {
    "menuName": "Şube İade Canlandırma",
    "screenName": "CCA843_BRANCH_RETURNED_APP_RECREATE",
    "screenCode": "CCA843",
    "screenDescription": "ŞUBE İADE DURUMUNDAKİ BAŞVURUY YENİDEN CANLANDIRMA EKRANI"
  },
  {
    "menuName": "Bireysel Değişiklik",
    "screenName": "CCA901_APP_INFO",
    "screenCode": "CCA901",
    "screenDescription": "KK BAŞVURU DÜZENLEME"
  },
  {
    "menuName": "Bireysel Karar",
    "screenName": "CCA031_APPLICATION_DECISION_INDIVIDUAL",
    "screenCode": "CCA031",
    "screenDescription": "BİREYSEL BASVURULAR ICIN KARAR EKRANI"
  },
  {
    "menuName": "Bağımsız Ek Kart Değerlendirme",
    "screenName": "CCA032_SUPP_CARD_DECISION",
    "screenCode": "CCA032",
    "screenDescription": "BAGIMSIZ EK KART DEGERLENDIRME"
  },
  {
    "menuName": "İptal Başvuru Canlandırma",
    "screenName": "CCA037_CANCELED_APPLICATION_RECREATE",
    "screenCode": "CCA037"
  },
  {
    "menuName": "KKTC Ön Değerlendirme",
    "screenName": "CCA092_KKTC_APP_DECISION",
    "screenCode": "CCA092"
  },
  {
    "menuName": "Ret Başvuru Canlandırma",
    "screenName": "CCA033_REJECTED_APPLICATION_RECREATE",
    "screenCode": "CCA033",
    "screenDescription": "RED EDİLMİŞ BİR BAŞVURUYU YENİDEN CANLANDIRMA"
  },
  {
    "menuName": "Bildirim Metni Düzenleme",
    "screenName": "CCA051_APPLICATION_NOTIFICATION_FORMATS",
    "screenCode": "CCA051",
    "screenDescription": "BILDIRIM FORMATLARI"
  },
  {
    "menuName": "Tahsis Kuralları Gözlem",
    "screenName": "CCA030_POLICY_CONTROL_RESULT",
    "screenCode": "CCA030"
  },
  {
    "menuName": "Başvuru Süreç İzleme",
    "screenName": "CCA061_APPLICATION_INQUIRY",
    "screenCode": "CCA061",
    "screenDescription": "BAŞVURU İZLEME EKRANI"
  },
  {
    "menuName": "Başvuru Gözlem",
    "screenName": "CCA060_APPLICATION_MONITORING",
    "screenCode": "CCA060",
    "screenDescription": "YAPILAN BASVURULARI GOZLEMİNİN YAPILDIGI EKRAN"
  },
  {
    "menuName": "Kayıt İzleme",
    "screenName": "CCA062_APPLICATION_LOG_MONITORING",
    "screenCode": "CCA062"
  },

  {
    "menuName": "Tahsis Kuralları Yönetimi",
    "screenName": "CCA009_POLICY_CONTROL_ADMIN",
    "screenCode": "CCA009"
  },
  {
    "menuName": "Müşteri Bankacılık Talepleri",
    "screenName": "CCA034_BANKING_APPLICATION_REQUEST",
    "screenCode": "CCA034",
    "screenDescription": "BASVURU SIRASINDA ALINAN MÜŞTERİ TALEPLERİNİN TAKİP EKRANIDIR. (ATM,İNTERNET BANK., TEL.BANKACILIGI)"
  },
  {
    "menuName": "Gelir Taksit Analizi Yönetimi",
    "screenName": "https://nova-cps-application-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/application/CCA088",
    "screenCode": "CCA088",
    "screenDescription": "GELİR TAKSİT ANALİZİ PARAMETRE YÖNETİMİ"
  },
  {
    "menuName": "Kredi Kartı Ürün Bazlı Kart Limit Yönetimi",
    "screenName": "CCA095_PRODUCT_BASED_CARD_LIMIT_MANAGEMENT",
    "screenCode": "CCA095",
    "screenDescription": "KREDİ KARTI ÜRÜN BAZLI KART LİMİT YÖNETİM EKRANI"
  },
  {
    "menuName": "Politika Kuralları Yönetimi",
    "screenName": "CCA009_POLICY_CONTROL_ADMIN",
    "screenCode": "CCA009"
  },
  {
    "menuName": "Belge Yönetimi",
    "screenName": "CCA087_APPLICATION_DOCUMENT_MANAGEMENT",
    "screenCode": "CCA087"
  },
  {
    "menuName": "Collection Parametre Ekranı",
    "screenName": "CCA073_COLLECTION_PARAMETERS",
    "screenCode": "CCA073",
    "screenDescription": "COLLECTION PARAMETRE EKRANI"
  },
  {
    "menuName": "Parametre Yönetimi",
    "screenName": "CCA080_APPLICATION_PARAMETERS",
    "screenCode": "CCA080"
  },
  {
    "menuName": "Ürün İlişkilendirme",
    "screenName": "CCA086_PRODUCT_GROUP_MANAGEMENT",
    "screenCode": "CCA086",
    "screenDescription": "ÜRÜN İLİŞKİLENDİRME EKRANI"
  },
  {
    "menuName": "Başvuru Gözlem Raporu",
    "screenName": "CCA010_RPRT_OPERATION_APP_MONITORING",
    "screenCode": "CCA010",
    "screenDescription": "BİREYSEL OPERASYON BAŞVURU DETAY RAPORU"
  },
  {
    "menuName": "LKS İşlem Süreleri Raporu",
    "screenName": "CCMS120_LIMIT_CHANGE_REPORT",
    "screenCode": "CCMS120",
    "screenDescription": "LİMİT DEĞİŞİKLİĞİ İŞLEM SÜRELERİ RAPORU"
  },
  {
    "menuName": "Başvuru Adet Raporu",
    "screenName": "CCA024_RPRT_APP_COUNT",
    "screenCode": "CCA024",
    "screenDescription": "BAŞVURU ADET RAPORU"
  },
  {
    "menuName": "Sektör Dağılım Raporu",
    "screenName": "CCA020_RPRT_SECTOR",
    "screenCode": "CCA020",
    "screenDescription": "SEKTÖR DAĞILIM RAPORU"
  },
  {
    "menuName": "Müşteri Bilgileri Raporu",
    "screenName": "CCA021_RPRT_CUSTOMER",
    "screenCode": "CCA021",
    "screenDescription": "MÜŞTERİ BİLGİLERİ RAPORU"
  },
  {
    "menuName": "Ret Nedenleri Dağılım Raporu",
    "screenName": "CCA018_RPRT_REFUSE_REASONS",
    "screenCode": "CCA018",
    "screenDescription": "RET NEDENLERİ DAĞILIM RAPORU"
  },
  {
    "menuName": "Şube Bazında Başvuru Adet Raporu",
    "screenName": "CCA023_RPRT_BRANCHAPP_COUNT",
    "screenCode": "CCA023",
    "screenDescription": "ŞUBE BAZINDA BAŞVURU ADET RAPORU"
  },
  {
    "menuName": "Meslek ve Çalışma Şekli Dağılım Raporu",
    "screenName": "CCA019_RPRT_OCCUPATION",
    "screenCode": "CCA019",
    "screenDescription": "MESLEK VE ÇALIŞMA ŞEKLİ DAĞILIM RAPORU"
  },
  {
    "menuName": "Ortalama Kredi Kartı Tahsis Limiti Raporu",
    "screenName": "CCA022_RPRT_AVGLIMIT",
    "screenCode": "CCA022",
    "screenDescription": "ORTALAMA KREDİ KARTI TAHSİS LİMİTİ RAPORU"
  },
  {
    "menuName": "Bireysel Krediler Tahsis Performans Raporu",
    "screenName": "CCA017_RPRT_PERFORMANCE",
    "screenCode": "CCA017",
    "screenDescription": "BİREYSEL KREDİLER TAHSİS PERFORMANS RAPORU"
  },
  {
    "menuName": "Bireysel Pazarlama"
  },
  {
    "menuName": "Manuel Sorgulama",
    "screenName": "CCA012_MANUEL_INQUIRY",
    "screenCode": "CCA012",
    "screenDescription": "BAŞVURU SORGULAMA YAPAR"
  },
  {
    "menuName": "Telefonla İstihbarat",
    "screenName": "CCA013_TELEPHONE_INQUIRY",
    "screenCode": "CCA013",
    "screenDescription": "TELEFONLA ISTIHBARAT EKRANI"
  },
  {
    "menuName": "ADK İstihbarat",
    "screenName": "CCA028_ADK_INQUIRY",
    "screenCode": "CCA028"
  },
  {
    "menuName": "Ticari Kart Başvuru Giriş Tanımı",
    "screenName": "CCA912_BUSINESS_CARD_NEW_APPLICATION",
    "menuKey": "BSS",
    "screenCode": "CCA912"
  },
  {
    "menuName": "Çalışma Koşulları",
    "screenName": "SKBNS036_MERCHANT_WORK_CONDITIONS",
    "screenCode": "SKBNS036"
  },
  {
    "menuName": "Taraftar Pos Destek Kurum Bilgileri",
    "screenName": "SKBNS059_MERCHANT_SUPPORTER",
    "screenCode": "SKBNS059",
    "screenDescription": "TARAFTAR POS HESAP BİLGİLERİ EKRANI"
  },
  {
    "menuName": "Üye İşyeri Ekstre Görüntüleme Ekranı",
    "screenName": "SKBNS060_MERCHANT_STATEMENT",
    "screenCode": "SKBNS060"
  },
  {
    "menuName": "Hesap Yönetimi",
    "screenName": "SKBNS040_MERCHANT_ACCOUNT_MANAGEMENT",
    "screenCode": "SKBNS040"
  },
  {
    "menuName": "Hareket Listesi",
    "screenName": "SKBNS038_MERCHANT_TRANSACTIONS",
    "screenCode": "SKBNS038"
  },
  {
    "menuName": "Maliye Verisi Oluşturma",
    "screenName": "SKBNS055_POS_DATA_OPERATIONS",
    "screenCode": "SKBNS055"
  },
  {
    "menuName": "İstatistik",
    "screenName": "SKBNS037_MERCHANT_STATISTICS",
    "screenCode": "SKBNS037"
  },
  {
    "menuName": "POS Talebi",
    "screenName": "POS001_POS_REQUEST",
    "screenCode": "POS001",
    "screenDescription": "POS TALEP EKRANI"
  },
  {
    "menuName": "Üye İşyeri bilgileri",
    "screenName": "SKBNS034_MERCHANT_INFOS",
    "screenCode": "SKBNS034"
  },
  {
    "menuName": "Terminal Bilgileri",
    "screenName": "SKBNS039_MERCHANT_TERMINAL_INFOS",
    "screenCode": "SKBNS039"
  },
  {
    "menuName": "Ekstre Dosya İşlemleri",
    "screenName": "CMS967_STATEMENT_LIST_STATEMENT_FILES",
    "screenCode": "CMS967",
    "screenDescription": "EKSTRE DOSYA İŞLEMLERİ"
  },
  {
    "menuName": "Ekstre iade İşlemleri",
    "screenName": "CMS005_RETURN_STATEMENT",
    "screenCode": "CMS005"
  },
  {
    "menuName": "Ekstre Özet Bilgileri",
    "screenName": "CMS966_STATEMENT_LIST",
    "screenCode": "CMS966"
  },
  {
    "menuName": "Business Kart Müşteri Yükleme",
    "screenName": "https://nova-cps-cms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/CMS/CCMS530",
    "screenCode": "CCMS530"
  },
  {
    "menuName": "Muhasebe Yönetimi",
    "screenName": "CCMS209_ACCOUNTING_MANAGEMENT",
    "screenCode": "CCMS209"
  },
  {
    "menuName": "Takip Kart Borç Yükleme",
    "screenName": "CCMS602_LOAD_DEBIT_KTS",
    "screenCode": "CCMS602",
    "screenDescription": "TAKIP KART BORÇ YUKLEME"
  },
  {
    "menuName": "Takip Kart Tahsilat",
    "screenName": "CCMS601_DEBIT_KTS",
    "screenCode": "CCMS601",
    "screenDescription": "TAKIP KART TAHSILAT EKRANI"
  },
  {
    "menuName": "Müşteri Tipi Değişikliği",
    "screenName": "CCMS211_ACCOUNTING_CORRECTION",
    "screenCode": "CCMS211",
    "screenDescription": "KREDİ KARTLARI MÜŞTERİ MUHASEBE BAKİYELERİ DÜZELTME  EKRANI"
  },
  {
    "menuName": "BMA Aktarım",
    "screenName": "CCMS210_PUCRT_ACCOUNTING",
    "screenCode": "CCMS210"
  },
  {
    "menuName": "Finansalı Gelen İşlemleri Listele",
    "screenName": "CCMS803_FINANCIAL_TRANSACTIONS_CYPRUS",
    "screenCode": "CCMS803"
  },
  {
    "menuName": "Şube Ödeme",
    "screenName": "CCMS809_DEBIT_CYPRUS",
    "screenCode": "CCMS809"
  },
  {
    "menuName": "Bekleyen Şube İşlemi İptali",
    "screenName": "CCMS810_OUTSTANDING_BRANCH_CANCEL",
    "screenCode": "CCMS810"
  },
  {
    "menuName": "Kart Borcu Hesaplama",
    "screenName": "CCMS805_CARD_DEBIT_CALCUL_CYPRUS",
    "screenCode": "CCMS805",
    "screenDescription": "KIBRIS KART BORCU HESAPLAMA"
  },
  {
    "menuName": "Kart Gözlem",
    "screenName": "CCMS801_CARD_INFO_CYPRUS",
    "screenCode": "CCMS801"
  },
  {
    "menuName": "Ekstre Özet Bilgileri",
    "screenName": "CCMS802_STATEMENT_LIST_CYPRUS",
    "screenCode": "CCMS802"
  },
  {
    "menuName": "Çağrı Merkezi Nakit Avans",
    "screenName": "CCMS707_CMI_MANUAL_CASH_ADVANCE",
    "screenCode": "CCMS707",
    "screenDescription": "ÇAĞRI MERKEZİ NAKİT AVANS İŞLEMİ"
  },
  {
    "menuName": "Şube İşlemleri",
    "screenName": "CCMS140_BRANCH_PROCESS",
    "screenCode": "CCMS140",
    "screenDescription": "KREDİ KARTLARI ŞUBE ÖDEME VE NAKİT AVANS İŞLEMLERİ"
  },
  {
    "menuName": "Taksitli Nakit Avans",
    "screenName": "CCMS505_INSTALLMENT_CASH_ADVANCE",
    "screenCode": "CCMS505",
    "screenDescription": "TAKSİTLİ NAKİT AVANSI TABLOLARA İŞLEYEN SERVİS"
  },
  {
    "menuName": "Şube Ödeme",
    "screenName": "CCMS040_DEBIT",
    "screenCode": "CCMS040"
  },
  {
    "menuName": "Bekleyen Şube İşlemi İptali",
    "screenName": "AMS005_OUTSTANDING_BRANCH_CANCEL",
    "screenCode": "AMS005"
  },
  {
    "menuName": "SMS Şifre Gönderim",
    "screenName": "CCMS041_SEND_SMS_PASSWORD",
    "screenCode": "CCMS041"
  },
  {
    "menuName": "Şube Nakit Çekim",
    "screenName": "CCMS007_MANUAL_CASH_ADVANCE",
    "screenCode": "CCMS007"
  },
  {
    "menuName": "SMS Nakit Avans İptali",
    "screenName": "CCMS512_SMS_CASH_ADVANCED_CANCEL",
    "screenCode": "CCMS512",
    "screenDescription": "SMS NAKİT AVANS İPTAL EKRANI"
  },
  {
    "menuName": "TNA Ödeme Ekranı",
    "screenName": "CCMS065_TNA_PAYMENT",
    "screenCode": "CCMS065"
  },
  {
    "menuName": "TNA Ödeme Simülasyonu",
    "screenName": "CCMS069_TNA_PAYMENT_SIMULATION",
    "screenCode": "CCMS069"
  },
  {
    "menuName": "Çağrı Merkezi Taksitli Nakit Avans",
    "screenName": "CCMS511_CMI_INSTALLMENT_CASH_ADVANCE",
    "screenCode": "CCMS511"
  },
  {
    "menuName": "Posting Test",
    "screenName": "CCMS_BATCH_POSTING",
    "screenCode": "CCMS607",
    "screenDescription": "POSTING TEST EKRANI"
  },
  {
    "menuName": "Takas Test",
    "screenName": "CCMS_BATCH_INTERCHANGE",
    "screenCode": "CCMS605",
    "screenDescription": "TAKAS TEST EKRANI"
  },
  {
    "menuName": "Manuel Kart Tarihi Girişi",
    "screenName": "CCC101_CARD_DATE_MANUALLY_SETTING",
    "screenCode": "CCC101"
  },
  {
    "menuName": "Log Gözlem",
    "screenName": "CCMS009_CARD_LOG_INFO",
    "screenCode": "CCMS009",
    "screenDescription": "LOG GÖZLEM EKRANI"
  },
  {
    "menuName": "Müşteri Kredi ve Nakit Limit Bilgileri",
    "screenName": "CCMS017_CMS_CUSTOMER",
    "screenCode": "CCMS017",
    "screenDescription": "MÜŞTERİ KREDİ VE NAKİT LİMİT BİLGİLERİ"
  },
  {
    "menuName": "Sözüne Bonus Tanımlama Tablosu",
    "screenName": "CCC055_SCMP_MANAGEMENT",
    "screenCode": "CCC055",
    "screenDescription": "SOZUNE BONUS PARAMETRE EKRANI"
  },
  {
    "menuName": "Minimum Ödeme Tablosu",
    "screenName": "CCC046_MINIMUM_PAYMENT_CALCULATION_TABLE",
    "screenCode": "CCC046"
  },
  {
    "menuName": "Ürün Alt Ürün Tanımlama Tablosu",
    "screenName": "CCC042_DEFINE_PRODUCTGROUP_PRODUCT",
    "screenCode": "CCC042",
    "screenDescription": "ÜRÜN GRUBU/ ÜRÜN TANIMLAMA"
  },
  {
    "menuName": "İl Bazlı Kurye Tanımı",
    "screenName": "CCC065_COURIER_PARAMETERS",
    "screenCode": "CCC065",
    "screenDescription": "İL BAZLI KURYE PARAMETRELERİ"
  },
  {
    "menuName": "Kart Status Yetki Tanımlama",
    "screenName": "CCC109_CMS_STATUS_USAGE",
    "screenCode": "CCC109",
    "screenDescription": "CCC109_CMS_STATUS_USAGE"
  },
  {
    "menuName": "Kart Yenileme Ürün Geçişleri",
    "screenName": "CCC067_RENEW_PRODUCT_CRITERIA",
    "screenCode": "CCC067",
    "screenDescription": "KART YENİLEME ÜRÜN GEÇİŞLERİ"
  },
  {
    "menuName": "Terfi Parametre Tanımlama",
    "screenName": "CCC052_DEFINE_PROMOTION_PARAMETER",
    "screenCode": "CCC052",
    "screenDescription": "TERFİ PARAMETRE YÖNETİM EKRANI"
  },
  {
    "menuName": "Kart Ücret İade Önerileri",
    "screenName": "CCMS082_FEE_REFUND_OFFERS",
    "screenCode": "CCMS082",
    "screenDescription": "KART ÜCRETİ İADE ÖNERİ EKRANI"
  },
  {
    "menuName": "Ücret Tanımlama Tablosu",
    "screenName": "CCC045_FEE_TABLE",
    "screenCode": "CCC045"
  },
  {
    "menuName": "Ekstre Dönem Takvimi",
    "screenName": "CCC073_CYCLE_CALENDAR",
    "screenCode": "CCC073",
    "screenDescription": "EKSTRE DÖNEM TAKVİMİ"
  },
  {
    "menuName": "Ülke  Kodu Tanımlama Tablosu",
    "screenName": "CCC105_COUNTRY_CODE",
    "screenCode": "CCC105"
  },
  {
    "menuName": "Blok Kodu Tanımlama",
    "screenName": "CCMS013_BLOCK_INFO",
    "screenCode": "CCMS013",
    "screenDescription": "BLOK KODU TANIMLAMA EKRANI"
  },
  {
    "menuName": "On Us Bin Tablosu",
    "screenName": "CCC010_ON_US_ACCOUNT_NUMBER_BINS_TABLE",
    "screenCode": "CCC010"
  },
  {
    "menuName": "Ürün Limit Tanımlama Ekranı",
    "screenName": "CCC006_CCC_PRODUCT_LIMIT",
    "screenCode": "CCC006"
  },
  {
    "menuName": "Kart Yenileme Kriterleri Tanımlama Tablosu",
    "screenName": "CCC064_REISSUE_CRITERIA",
    "screenCode": "CCC064"
  },
  {
    "menuName": "Kurum Tablosu",
    "screenName": "CCC000_CORPORATION_DEFINITION_TABLE",
    "screenCode": "CCC000"
  },
  {
    "menuName": "İşlem Taksitlendirme Parametre Ekranı",
    "screenName": "CCC116_ISLEM_TAKSITLENDIRME_PARAMETRE",
    "screenCode": "CCC116"
  },
  {
    "menuName": "İşlem Yönlendirim Kodu Tablosu"
  },
  {
    "menuName": "İşlem Ücretleri Tanım Tablosu",
    "screenName": "CCC050_TRANSACTION_FEE",
    "screenCode": "CCC050"
  },
  {
    "menuName": "Otomatik Mektup Tanımlama Tablosu",
    "screenName": "CCC016_AUTOMATIC_LETTER_TABLE",
    "screenCode": "CCC016"
  },
  {
    "menuName": "Risk Skoru Tanımlama",
    "screenName": "CCC107_RISK_SKOR",
    "screenCode": "CCC107"
  },
  {
    "menuName": "SMS Gönderim Yönetim Ekranı",
    "screenName": "https://nova-cps-cms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/CMS/CCMS520",
    "screenCode": "CCMS520"
  },
  {
    "menuName": "Ekstra Puan Kazanım Parametreleri",
    "screenName": "CCC075_EXTRA_BONUS_DEFINITION",
    "screenCode": "CCC075"
  },
  {
    "menuName": "Ödeme Dağılımı Tablosu",
    "screenName": "CCC035_APPLICATION_OF_PAYMENT_CREDIT_TABLE",
    "screenCode": "CCC035"
  },
  {
    "menuName": "Ekstre Kesim Gün Kodu Tablosu",
    "screenName": "CCC005_CYCLE_DAYS_TABLE",
    "screenCode": "CCC005"
  },
  {
    "menuName": "İşyeri Kategori Kodu tanımlama",
    "screenName": "CCMS053_MCC_DEFINITIONS",
    "screenCode": "CCMS053"
  },
  {
    "menuName": "Puan Türü Tanımlama Tablosu",
    "screenName": "CCC038_ACCOUNT_BONUS_CODE",
    "screenCode": "CCC038",
    "screenDescription": "PUAN TÜRÜ TANIMLAMA"
  },
  {
    "menuName": "Emboss Name 2 Yönetim Ekranı",
    "screenName": "CCA035_EMBOSS_NAME_MANAGEMENT",
    "screenCode": "CCA035"
  },
  {
    "menuName": "Özel Limit Ücret Tanımlama Ekranı",
    "screenName": "CCMS075_SPECIAL_LIMIT_FEE",
    "screenCode": "CCMS075",
    "screenDescription": "ÖZEL LİMİT ÜCRETİ EKRANI"
  },
  {
    "menuName": "Blok Kod Geçiş Tanımlama",
    "screenName": "CCMS014_BLOCK_CODE_TRANSITION",
    "screenCode": "CCMS014",
    "screenDescription": "BLOK KOD GEÇİŞ TANIMLAMA"
  },
  {
    "menuName": "Ekstrelendirme Kodu Tablosu",
    "screenName": "CCC001_BILLING_CODE_TABLE",
    "screenCode": "CCC001"
  },
  {
    "menuName": "Taksitli Nakit Avans Parametre Giriş",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/CCC110",
    "screenCode": "CCC110",
    "screenDescription": "TAKSİTLİ NAKİT AVANS PARAMETRE TANIMLAMA EKRANI"
  },
  {
    "menuName": "Formül Tanımlama Tablosu",
    "screenName": "CCC108_FORMUL_KEY",
    "screenCode": "CCC108"
  },
  {
    "menuName": "Gecikme Ücreti Tablosu",
    "screenName": "CCC045_FEE_TABLE",
    "screenCode": "CCC045"
  },
  {
    "menuName": "Faiz Oran Tablosu",
    "screenName": "CCC004_RATE_CODE_TABLE",
    "screenCode": "CCC004"
  },
  {
    "menuName": "Kart Segmantasyon Parametre Ekranı",
    "screenName": "CCA130_PRODUCT_GROUP_DEPOSIT_MANAGEMENT",
    "screenCode": "CCA130",
    "screenDescription": "URUN MEVDUAT PARAMETRE EKRANI"
  },
  {
    "menuName": "İşlem Kodu Tablosu",
    "screenName": "CCC048_TRAN_CODE_DATA_TABLE",
    "screenCode": "CCC048"
  },
  {
    "menuName": "Ürün Ekstre Kesim Kodu Eşleştirme Ekranı",
    "screenName": "https://nova-cps-cardcore-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/cardCore/CCC008",
    "screenCode": "CCC008",
    "screenDescription": "ÜRÜN-EKSTRE KESİM KODU EŞLEŞTİRME EKRANI"
  },
  {
    "menuName": "Profil Tanımlama",
    "screenName": "CCMS010_PROFILE_INFO",
    "screenCode": "CCMS010",
    "screenDescription": "KART PROFILI TANIM EKRANI"
  },
  {
    "menuName": "İşyeri Grup Kodu Tanımlama",
    "screenName": "AMS023_MERCHANT_GROUP_CODE_AND_DESCRIPTIONS",
    "screenCode": "AMS023"
  },
  {
    "menuName": "Chergeback Neden kodu Tablosu",
    "screenName": "CCC040_CHARGEBACK_REASON_CODE_TABLE",
    "screenCode": "CCC040"
  },
  {
    "menuName": "Artı Bakiye Aktar",
    "screenName": "CCMS510_TRANSFER_POSITIVE_AMOUNT",
    "screenCode": "CCMS510"
  },
  {
    "menuName": "Proses Edilmeyen Açık Statülü Finansal İşlemler",
    "screenName": "CCMS002_NOT_PROCESSED_OPEN_STATUS_FINANCIAL_PROCESSES",
    "screenCode": "CCMS002"
  },
  {
    "menuName": "Taksit Planı",
    "screenName": "CCMS042_TRANSACTION_INSTALLMENT_DETAIL",
    "screenCode": "CCMS042",
    "screenDescription": "TAKSİT PLANI"
  },
  {
    "menuName": "Karttan Para Transfer",
    "screenName": "CCMS039_MONEY_TRANSFER",
    "screenCode": "CCMS039",
    "screenDescription": "KARTTAN PARA TRANSFER EKRANI."
  },
  {
    "menuName": "Finansal Bilgiler",
    "screenName": "CCMS023_ACCOUNT_FINANCIAL_DETAIL",
    "screenCode": "CCMS023"
  },
  {
    "menuName": "Reeskont Bilgileri",
    "screenName": "CCMS060_ACCOUNT_REDISCOUNT",
    "screenCode": "CCMS060"
  },
  {
    "menuName": "Puan  Birleştirme / Transfer",
    "screenName": "CCMS026_BONUS_TRANSFER",
    "screenCode": "CCMS026"
  },
  {
    "menuName": "Manual İşlem Listeleme",
    "screenName": "CCMS055_MANUAL_TRANSACTION_LIST",
    "screenCode": "CCMS055"
  },
  {
    "menuName": "Manuel İşlem Giriş",
    "screenName": "CCMS037_MANUEL_FINANCIAL_TRANSACTION",
    "screenCode": "CCMS037"
  },
  {
    "menuName": "ÇM Kart Kapama İsteği İptali",
    "screenName": "CCMS114_CHURNED_ACCOUNT_MANAGMENT",
    "screenCode": "CCMS114"
  },
  {
    "menuName": "Kart Gözlem",
    "screenName": "CCMS001_CARD_INFO",
    "screenCode": "CCMS001",
    "screenDescription": "KART INQUIRE EKRANI"
  },
  {
    "menuName": "Bilgi Güncelleme",
    "screenName": "CCMS051_UPDATE_ACCOUNT",
    "screenCode": "CCMS051",
    "screenDescription": "BİLGİ GÜNCELLEME"
  },
  {
    "menuName": "Bütçem Benim Tanım Ekranı",
    "screenName": "CCMS099_PRODUCT_NHNKK_ADMINISTRATION",
    "screenCode": "CCMS099",
    "screenDescription": "NE HARCADIGINI BILEN KREDI KARTI TANIMLAMA EKRANI"
  },
  {
    "menuName": "Başka Banka Borç Transferi",
    "screenName": "CCMS025_BANK_OUT_PAYMENT",
    "screenCode": "CCMS025"
  },
  {
    "menuName": "BKM / Visa  Bildirim Ekranı",
    "screenName": "CCMS052_BKM_VISA_ANNOUNCEMENT",
    "screenCode": "CCMS052",
    "screenDescription": "BKM / VİSA  BİLDİRİM EKRANI"
  },
  {
    "menuName": "Kart Borcu Hesaplama",
    "screenName": "CCMS012_CARD_DEBIT_CALCUL",
    "screenCode": "CCMS012"
  },
  {
    "menuName": "Dekont Gözlem",
    "screenName": "CCMS200_DEKONT_MONITORING",
    "screenCode": "CCMS200"
  },
  {
    "menuName": "Banka içi Borç Yeniden Yapılandırma",
    "screenName": "CCMS024_BANK_IN_PAYMENT",
    "screenCode": "CCMS024"
  },
  {
    "menuName": "BKM / Visa Bildirim Görüntüleme",
    "screenName": "CCMS011_STOP_LIST",
    "screenCode": "CCMS011",
    "screenDescription": "BKM-VİSA BİLDİRİM GÖRÜNTÜLEME"
  },
  {
    "menuName": "Blok Kod Değiştirme",
    "screenName": "CCMS050_CHANGE_BLOCK_CODE",
    "screenCode": "CCMS050",
    "screenDescription": "BLOK KOD DEĞİŞTİRME"
  },
  {
    "menuName": "Sözünüze Bonus Güncelleme",
    "screenName": "CCMS095_SCMP_SPEND_UPDATE",
    "screenCode": "CCMS095"
  },
  {
    "menuName": "Otomatik Odeme Talimatı",
    "screenName": "CMS027_AUTO_PAYMENT",
    "screenCode": "CMS027"
  },
  {
    "menuName": "Müşteri No Değişikliği",
    "screenName": "CCMS090_CMS_CUSTOMER_NO_UPD",
    "screenCode": "CCMS090",
    "screenDescription": "MUSTERI NO DEGISIKLIGI"
  },
  {
    "menuName": "Kart Ücret İade Önerileri Gözlem",
    "screenName": "CCMS087_FEE_REFUND_OPERATIONS",
    "screenCode": "CCMS087",
    "screenDescription": "KART ÜCRET İADE İŞLEMLERİ GÖZLEM"
  },
  {
    "menuName": "Sözünüze Bonus",
    "screenName": "CCMS091_SCMP_SPEND_COMMITM",
    "screenCode": "CCMS091",
    "screenDescription": "SOZUNE BONUS SORGULAMA EKRANI"
  },
  {
    "menuName": "Reject Olmuş İşlem Listeleme",
    "screenName": "https://nova-cps-cms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/CMS/CCMS003",
    "screenCode": "CCMS003"
  },
  {
    "menuName": "BDDK Kredi Kartı Limiti ve Kart Sayıları",
    "screenName": "CCMS302_REPORT_KK_LIMIT_VE_KART_SAYILARI",
    "screenCode": "CCMS302"
  },
  {
    "menuName": "BDDK Kredi Kartları Kullanım Hacmi",
    "screenName": "CCMS304_REPORT_KK_KULLANIM_HACMI",
    "screenCode": "CCMS304"
  },
  {
    "menuName": "BDDK Taksitli İşlemler",
    "screenName": "CCMS303_REPORT_CURRENT_PERIOD_INSTALLEMENT",
    "screenCode": "CCMS303"
  },
  {
    "menuName": "BDDK Kredi Kartı Ödenmeyen Toplam Borç",
    "screenName": "CCMS305_REPORT_KK_UNPAID_TOTAL_DEBIT",
    "screenCode": "CCMS305",
    "screenDescription": "ÖDENMEYEN TOPLAM BORÇ RAPOR EKRANI"
  },
  {
    "menuName": "Otomatik Ödeme Talimatı Olanların Listesi",
    "screenName": "https://nova-cps-cms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/CMS/CCMS307",
    "screenCode": "CCMS307",
    "screenDescription": "OTOMATIK ODEME TALIMAT RAPOR EKRANI"
  },
  {
    "menuName": "Günsonu İşlemleri",
    "screenName": "PROD_MANUAL_BATCH_RUN",
    "screenCode": "CCMS502"
  },
  {
    "menuName": "TEST",
    "screenName": "CCMS_BATCH_RUN2",
    "screenCode": "CCMS501"
  },
  {
    "menuName": "BATCH",
    "screenName": "CCMS_BATCH_RUN",
    "screenCode": "CCMS500"
  },
  {
    "menuName": "Manuel HTI",
    "screenName": "CCMS_MANUAL_HTI",
    "screenCode": "CCMS333"
  },
  {
    "menuName": "Kart Basım Batch",
    "screenName": "CCMS107_CARD_PRESS_BATCH",
    "screenCode": "CCMS107"
  },
  {
    "menuName": "Kart Basım Grubu",
    "screenName": "CMS028_CARD_ISSUE_GROUP",
    "screenCode": "CMS028"
  },
  {
    "menuName": "Basılacak Kartlar İzleme",
    "screenName": "CCMS057_REISSUE_CARD_PRESS",
    "screenCode": "CCMS057"
  },
  {
    "menuName": "Toplu Yenileme",
    "screenName": "https://nova-cps-cms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/CMS/CCMS105",
    "screenCode": "CCMS105"
  },
  {
    "menuName": "Kartı Tekrar Gönder",
    "screenName": "CMS030_CARD_RESEND",
    "screenCode": "CMS030"
  },
  {
    "menuName": "Yenilenecek Kartların Listesi",
    "screenName": "CCMS056_REISSUE_CARD_LIST",
    "screenCode": "CCMS056"
  },
  {
    "menuName": "Gruplanan Kartların Listesi",
    "screenName": "CCMS058_REISSUE_CARD_GROUP",
    "screenCode": "CCMS058"
  },
  {
    "menuName": "Kart Basım Key Üretme",
    "screenName": "CCMS503_GENERATE_KEY_PAIR",
    "screenCode": "CCMS503"
  },
  {
    "menuName": "Basımda Hata Alan Kartlar Listelesi",
    "screenName": "CCMS063_FAILED_ISSUES",
    "screenCode": "CCMS063"
  },
  {
    "menuName": "Sözleşme Teslimat Girişi",
    "screenName": "CCMS093_BARCODE_READING",
    "screenCode": "CCMS093"
  },
  {
    "menuName": "Kartın Dağıtım Durumu",
    "screenName": "CMS031_CARD_RETURNED_LIST",
    "screenCode": "CMS031"
  },
  {
    "menuName": "İade Kart Girişi",
    "screenName": "CMS029_CARD_RETURN",
    "screenCode": "CMS029"
  },
  {
    "menuName": "Toplu Blok Kod Değişikliği",
    "screenName": "CCMS077_BLOCK_CODE_SET",
    "screenCode": "CCMS077"
  },
  {
    "menuName": "Yenilenemeyen Kartlar Listesi",
    "screenName": "CCMS059_DENIED_REISSUE_CARD_LIST",
    "screenCode": "CCMS059"
  },
  {
    "menuName": "Kart Yenileme İşlemleri",
    "screenName": "CCMS045_CARD_RENEW_OPERATIONS",
    "screenCode": "CCMS045"
  },
  {
    "menuName": "Basılacak Şifreler Listesi",
    "screenName": "CCMS062_PRINT_PIN",
    "screenCode": "CCMS062"
  },
  {
    "menuName": "Tek Karta Script Gönderimi",
    "screenName": "SCR002_SEND_SCRIPT_FOR_ONE_CARD",
    "screenCode": "SCR002",
    "screenDescription": "SCR002_SEND_SCRIPT_FOR_ONE_CARD"
  },
  {
    "menuName": "Script Yönetimi Parametre Tanım",
    "screenName": "SCR001_SCRIPT_PARAMETER_DEFINITION",
    "screenCode": "SCR001",
    "screenDescription": "SCR001_SCRIPT_PARAMETER_DEFINITION"
  },
  {
    "menuName": "Script Gönderim Bilgileri İzleme",
    "screenName": "SCR004_SCRIPT_DETAIL",
    "screenCode": "SCR004",
    "screenDescription": "SCR004_SCRIPT_DETAIL"
  },
  {
    "menuName": "Toplu Karta Script Gönderimi",
    "screenName": "SCR003_SEND_SCRIPT_FOR_SELECTED_CARD",
    "screenCode": "SCR003",
    "screenDescription": "SCR003_SEND_SCRIPT_FOR_SELECTED_CARD"
  },
  {
    "menuName": "Kredi Kartları",
    "screenName": "CCMS140_BRANCH_PROCESS",
    "screenCode": "CCMS140",
    "screenDescription": "KREDİ KARTLARI ŞUBE ÖDEME VE NAKİT AVANS İŞLEMLERİ"
  },
  {
    "menuName": "Memo Log Toplam Raporu",
    "screenName": "MEMO06_MEMOLOG_TOTAL_RAPOR",
    "screenCode": "MEMO004",
    "screenDescription": "MEMO LOG ÖZET RAPORU"
  },
  {
    "menuName": "Memo Kod Tanımları",
    "screenName": "MEMO01_MEMOCODE_ADMIN",
    "screenCode": "MEMO001",
    "screenDescription": "MEMO KOD TANIMLARI"
  },
  {
    "menuName": "Müşteri Memo Sorgulama",
    "screenName": "MEMO02_MEMOLOG_MUSTERI",
    "screenCode": "MEMO002",
    "screenDescription": "MÜŞTERİ MEMO LOG SORGULAMA"
  },
  {
    "menuName": "Memo Log Raporu",
    "screenName": "MEMO05_MEMOLOG_RAPOR",
    "screenCode": "MEMO003",
    "screenDescription": "MEMO LOG RAPORU"
  },
  {
    "menuName": "Giriş Log Raporu",
    "screenName": "COLL120_INPUT_LOG_REPORT",
    "screenCode": "COLL120",
    "screenDescription": "GİRİŞ VERİLERİ RAPORU"
  },
  {
    "menuName": "Collection Dosya Raporu",
    "screenName": "COLL101_COLLECTION_FILE_REPORT",
    "screenCode": "COLL101",
    "screenDescription": "COLLECTION DOSYA RAPORU"
  },
  {
    "menuName": "Gerçekleşen Tahsilatlar Raporu",
    "screenName": "COLL102_REALIZED_PAYMENTS_REPORT",
    "screenCode": "COLL102",
    "screenDescription": "GERÇEKLEŞEN TAHSİLATLAR RAPORU"
  },
  {
    "menuName": "Delegasyon İşlemleri Raporu",
    "screenName": "COLL109_DELEGATION_REPORT",
    "screenCode": "COLL109",
    "screenDescription": "DELEGASYON RAPORU"
  },
  {
    "menuName": "KYP Dönem Başı Atanan Hedefler Raporu",
    "screenName": "COLL124_KYP_STOCK_OBJECTIVES_REPORT",
    "screenCode": "COLL124"
  },
  {
    "menuName": "Borç Yapılandırma Talepleri Raporu",
    "screenName": "COLL116_PAYMENT_PLAN_DEMAND_REPORT",
    "screenCode": "COLL116",
    "screenDescription": "BORÇ YAPILANDIRMA TALEPLERİ RAPORU"
  },
  {
    "menuName": "Aksiyon İstatistikleri Raporu",
    "screenName": "COLL119_ACTION_STATISTICS_REPORT",
    "screenCode": "COLL119",
    "screenDescription": "AKSİYON İSTATİSTİKLERİ RAPORU"
  },
  {
    "menuName": "Collector İş Dağılım Raporu",
    "screenName": "COLL105_COLLECTOR_WORK_OBSERVATION_REPORT",
    "screenCode": "COLL105",
    "screenDescription": "COLLECTOR İŞ DAĞILIM RAPORU"
  },
  {
    "menuName": "Collector İzleme Raporu",
    "screenName": "COLL104_COLLECTOR_OBSERVATION_REPORT",
    "screenCode": "COLL104",
    "screenDescription": "KOLLEKTÖR İZLEME RAPORU"
  },
  {
    "menuName": "Dosya İstatistikleri Raporu",
    "screenName": "COLL118_FILE_STATISTICS_REPORT",
    "screenCode": "COLL118",
    "screenDescription": "DOSYA İSTATİSTİKLERİ RAPORU"
  },
  {
    "menuName": "Aksiyon Detayları Raporu",
    "screenName": "COLL106_ACTION_DETAIL_REPORT",
    "screenCode": "COLL106",
    "screenDescription": "AKSYON DETAY RAPORU"
  },
  {
    "menuName": "KYP Güncel Akış Listesi Raporu",
    "screenName": "COLL125_KYP_CURRENT_OBJECTIVES_REPORT",
    "screenCode": "COLL125"
  },
  {
    "menuName": "SMS / Posta / E-Mail Raporu",
    "screenName": "COLL117_SMS_MAIL_EMAIL_REPORT",
    "screenCode": "COLL117",
    "screenDescription": "SMS / POSTA / E-MAIL RAPORU"
  },
  {
    "menuName": "Aksiyon Performans Raporu",
    "screenName": "COLL123_ACTION_PERFORMANCE_REPORT",
    "screenCode": "COLL123",
    "screenDescription": "AKSİYON PERFORMANS RAPORU"
  },
  {
    "menuName": "Collector Performans Raporu",
    "screenName": "COLL121_COLLECTOR_PERFORMANCE_REPORT",
    "screenCode": "COLL121",
    "screenDescription": "KOLLEKTÖR PERFORMANS RAPORU"
  },
  {
    "menuName": "Tarihçe Gözlem",
    "screenName": "COLL003_COLLECTION_HISTORY",
    "screenCode": "COLL003",
    "screenDescription": "TARİHÇE GÖZLEM EKRANI"
  },
  {
    "menuName": "Collection Genel Raporu",
    "screenName": "COLL122_COLLECTION_GENERAL_REPORT",
    "screenCode": "COLL122",
    "screenDescription": "COLLECTION MODÜLÜ GENEL RAPORU"
  },
  {
    "menuName": "KYP Kollektör Aksiyon Sayıları Raporu",
    "screenName": "COLL127_KYP_COLLECTOR_ACTIONS_REPORT",
    "screenCode": "COLL127"
  },
  {
    "menuName": "Müşteri Ek Bilgi Raporu",
    "screenName": "COLL103_CUSTOMER_ADDITIONAL_INFO_REPORT",
    "screenCode": "COLL103",
    "screenDescription": "MÜŞTERİ EK BİLGİ RAPORU"
  },
  {
    "menuName": "KYP Tahsilat/İyileşme Raporu",
    "screenName": "COLL126_KYP_PAYMENT_REPORT",
    "screenCode": "COLL126"
  },
  {
    "menuName": "Collection Risk Gözlem",
    "screenName": "COLL130_COLLECTION_RISK_OBSERVATION",
    "screenCode": "COLL130",
    "screenDescription": "COLLECTION RİSK GÖZLEM"
  },
  {
    "menuName": "Risk Düzenleme",
    "screenName": "COLL006_RISK_DEFINITION",
    "screenCode": "COLL006",
    "screenDescription": "RİSK TANIMLAMA EKRANI"
  },
  {
    "menuName": "Borç Yapılandırma Parametreleri Düzenleme",
    "screenName": "COLL014_PAYMENT_PLAN_PARAMETERS",
    "screenCode": "COLL014",
    "screenDescription": "BORÇ YAPILANDIRMA PARAMETRELERİ DÜZENLEME"
  },
  {
    "menuName": "Kollektör Tercih Kriteri Düzenleme",
    "screenName": "COLL010_COLLECTOR_PREFRENCE_CRITERIA",
    "screenCode": "COLL010",
    "screenDescription": "COLLECTOR TERCİH KRİTERİ TANIMLAMA"
  },
  {
    "menuName": "Aksiyon Düzenleme",
    "screenName": "COLL007_ACTION_DEFINITION",
    "screenCode": "COLL007",
    "screenDescription": "AKSİYON TANIMLAMA"
  },
  {
    "menuName": "Uyarı Bildirim Mesajı Düzenleme",
    "screenName": "COLL018_WARNING_MESSAGES_DEFINITION",
    "screenCode": "COLL018",
    "screenDescription": "UYARI BİLDİRİM MESAJI TANIMLAMA"
  },
  {
    "menuName": "Kollektör Düzenleme",
    "screenName": "COLL011_COLLECTOR_DEFINITION",
    "screenCode": "COLL011",
    "screenDescription": "KOLLEKTÖR DÜZENLEME EKRANI"
  },
  {
    "menuName": "Müşteri Ek Bilgi Düzenleme",
    "screenName": "COLL012_CUSTOMER_ADDITIONAL_INFO",
    "screenCode": "COLL012",
    "screenDescription": "MÜŞTERİ EK BİLGİ DÜZENLEME"
  },
  {
    "menuName": "Aksiyon Kümesi Düzenleme",
    "screenName": "COLL002_ACTION_SET_DEFINITION",
    "screenCode": "COLL002",
    "screenDescription": "AKSİYON SETİ TANIMLAMA"
  },
  {
    "menuName": "Şablon Düzenleme",
    "screenName": "COLL013_TEMPLATE_DEFINITION",
    "screenCode": "COLL013",
    "screenDescription": "ŞABLON TANIMLAMA"
  },
  {
    "menuName": "Sınıf Düzenleme",
    "screenName": "COLL001_CLASS_DEFINITION",
    "screenCode": "COLL001",
    "screenDescription": "COLLECTION SINIFI TANIMLAMA"
  },
  {
    "menuName": "Borç Yapılandırma Talebi Giriş",
    "screenName": "COLL015_PAYMENT_PLAN_DEMAND",
    "screenCode": "COLL015",
    "screenDescription": "BORÇ YAPILANDIRMA TALEBİ GİRİŞ"
  },
  {
    "menuName": "Manuel Arama Aksiyonu Giriş",
    "screenName": "COLL020_MANUEL_ACTION_ENTRY",
    "screenCode": "COLL020",
    "screenDescription": "MANUEL ARAMA AKSİYONU GİRİŞİ"
  },
  {
    "menuName": "Toplu Dosya Delegasyon",
    "screenName": "COLL016_BATCH_FILE_DELEGATION",
    "screenCode": "COLL016",
    "screenDescription": "TOPLU DOSYA DELEGASYON"
  },
  {
    "menuName": "Toplu Aksiyon Delegasyonu",
    "screenName": "COLL019_DAILY_ACTION_DISTRIBUTION",
    "screenCode": "COLL019",
    "screenDescription": "TOPLU AKSİYON DELEGASYONU"
  },
  {
    "menuName": "Kollektör Aksiyon Gerçekleştirme",
    "screenName": "COLL004_COLLECTOR_ACTION_REALIZATION",
    "screenCode": "COLL004",
    "screenDescription": "KOLLEKTÖR AKSİYON GERÇEKLEŞTİRME"
  },
  {
    "menuName": "Dosya Güncelleme",
    "screenName": "COLL009_MANUAL_FILE_UPDATE",
    "screenCode": "COLL009",
    "screenDescription": "DOSYA BİLGİLERİ MANUEL GÜNCELLEME"
  },
  {
    "menuName": "Aksiyon Takibi ve Yönetimi",
    "screenName": "COLL005_SUPERVISOR_ACTION_REALIZATION",
    "screenCode": "COLL005",
    "screenDescription": "AKSİYON TAKİBİ VE YÖNETİMİ"
  },
  {
    "menuName": "Manuel Aksiyon Giriş",
    "screenName": "COLL008_MANUEL_ACTION_CREATE",
    "screenCode": "COLL008",
    "screenDescription": "MANUEL AKSİYON GİRİŞİ"
  },
  {
    "menuName": "KGF BUSINESS KART TEMİNAT BAĞLAMA/ÇÖZME",
    "screenName": "ALL035_COLLATERAL_BINDING_FOR_CREDIT",
    "menuKey": "KGFC",
    "screenCode": "ALL035",
    "screenDescription": "KULLANDIRIM TEMİNAT BAĞLAMA"
  },
  {
    "menuName": "Ticari Kart Teminat Bağlama/Çözme Tanımı",
    "screenName": "ALL035_COLLATERAL_BINDING_FOR_CREDIT",
    "menuKey": "BSS",
    "screenCode": "ALL035",
    "screenDescription": "KULLANDIRIM TEMİNAT BAĞLAMA"
  },
  {
    "menuName": "Kampanya Puan Yükleme",
    "screenName": "CMP009_BONUS_UPLOAD",
    "screenCode": "CMP009"
  },
  {
    "menuName": "Secondary Bonus",
    "screenName": "CMP004_DEFINE_SECONDARY_BONUS",
    "screenCode": "CMP004"
  },
  {
    "menuName": "İşlem Kampanya",
    "screenName": "CMP001_ISLEM_KAMPANYA_TANIM",
    "screenCode": "CMP001"
  },
  {
    "menuName": "Kart Puan Bilgileri",
    "screenName": "CMP011_REWARD_INFOS",
    "screenCode": "CMP011"
  },
  {
    "menuName": "Kart Ödül Bilgileri",
    "screenName": "CMP012_REWARD_INFO",
    "screenCode": "CMP012",
    "screenDescription": "REWARD INFO"
  },
  {
    "menuName": "Kart İptalden Vazgeçirme Onay",
    "screenName": "CMP010_KART_IPTAL_ONAY",
    "screenCode": "CMP010",
    "screenDescription": "KART İPTAL VAZGEÇİRME ONAY EKRANI"
  },
  {
    "menuName": "Otomatik Taksitlendirme İptal",
    "screenName": "CMP016_AUTOINST_CAMPAIGN_CANCEL",
    "screenCode": "CMP016"
  },
  {
    "menuName": "Kampanya Dosyası Yükleme İptal",
    "screenName": "CMP152_BONUS_UPLOAD_CANCEL",
    "screenCode": "CMP152"
  },
  {
    "menuName": "Kampanya Dosya Yükleme",
    "screenName": "CMP015_POSTPONE_CAMPAIGN_LOAD",
    "screenCode": "CMP015"
  },
  {
    "menuName": "Kart İptalden Vazgeçirme",
    "screenName": "CMP008_KART_IPTAL_VAZGECIRME",
    "screenCode": "CMP008"
  },
  {
    "menuName": "Kart Kampanya Gözlem",
    "screenName": "CMP006_KART_KAMPANYA_GOZLEM",
    "screenCode": "CMP006"
  },
  {
    "menuName": "TNA Kampanya Dosya Yükleme",
    "screenName": "CMP151_INST_CASH_ADVANCED_CAMP_UPLOAD",
    "screenCode": "CMP151"
  },
  {
    "menuName": "Öteleme Kampanya Katılm İptal",
    "screenName": "CMP014_POSTPONE_CAMPAIGN_CANCEL",
    "screenCode": "CMP014"
  },
  {
    "menuName": "Kart Satış",
    "screenName": "CMP003_KART_SATIS_KAMPANYA_TANIM",
    "screenCode": "CMP003"
  },
  {
    "menuName": "Kampanya Simülasyon",
    "screenName": "CMP007_KAMPANYA_SIMULASYON",
    "screenCode": "CMP007",
    "screenDescription": "KAMPANYA SİMÜLASYON"
  },
  {
    "menuName": "TNA Kampanya Tanımlama",
    "screenName": "CCC150_INSTALLMENT_CASH_ADVANCED_PARAMS",
    "screenCode": "CCC150"
  },
  {
    "menuName": "Mesaj Log",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW001",
    "screenCode": "SKRSW001"
  },
  {
    "menuName": "Servis Log",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW003",
    "screenCode": "SKRSW003"
  },
  {
    "menuName": "Anlık Mesaj Log",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW005",
    "screenCode": "SKRSW005"
  },
  {
    "menuName": "HSM Log",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW004",
    "screenCode": "SKRSW004"
  },
  {
    "menuName": "Mesaj İstatistik",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW010",
    "screenCode": "SKRSW010"
  },
  {
    "menuName": "Parametre",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW011",
    "screenCode": "SKRSW011"
  },
  {
    "menuName": "Düğüm",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW012",
    "screenCode": "SKRSW012"
  },
  {
    "menuName": "Anahtar",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW008",
    "screenCode": "SKRSW008"
  },
  {
    "menuName": "Yönlendirme",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW006",
    "screenCode": "SKRSW006"
  },
  {
    "menuName": "Servis",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW002",
    "screenCode": "SKRSW002"
  },
  {
    "menuName": "Hsm",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW009",
    "screenCode": "SKRSW009"
  },
  {
    "menuName": "Bağlantı",
    "screenName": "https://nova-cps-switch-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/switch/SKRSW007",
    "screenCode": "SKRSW007"
  },
  {
    "menuName": "Ticari Kart Gözlem Tanımı",
    "screenName": "https://nova-cps-application-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/application/CCA913",
    "screenCode": "CCA913"
  },
  {
    "menuName": "Log Gözlem",
    "screenName": "SKBNS018_SWITCH_MESSAGE_LOG",
    "screenCode": "SKBNS018"
  },
  {
    "menuName": "Performans Yönetim",
    "screenName": "SKBNS022_SWITCH_MANAGEMENT",
    "screenCode": "SKBNS022"
  },
  {
    "menuName": "Ekstre Listeleme",
    "screenName": "SKBNS008_STATEMENT_LIST",
    "screenCode": "SKBNS008"
  },
  {
    "menuName": "Dönemiçi",
    "screenName": "SKBNS007_FINANCIAL_TRANSACTIONS",
    "screenCode": "SKBNS007"
  },
  {
    "menuName": "Kart Bilgileri Güncelleme",
    "screenName": "SKBNS006_UPDATE_ACCOUNT",
    "screenCode": "SKBNS006"
  },
  {
    "menuName": "Kart Bilgileri",
    "screenName": "SKBNS005_CARD_INFO",
    "screenCode": "SKBNS005",
    "screenDescription": "KART BİLGİLERİ"
  },
  {
    "menuName": "Güncellenen Müşteri Numaralarının Gönderimi",
    "screenName": "SKBNS053_CREATE_CUST_NO_UPDATE_INFO",
    "screenCode": "SKBNS053",
    "screenDescription": "GÜNCELLENMESI GEREKEN MUSTERI NUMARALARINI TABLOYA YAZMAK İÇİN KULLANILAN EKRAN"
  },
  {
    "menuName": "Kart Not Bilgileri Görüntüleme",
    "screenName": "SKBNS027_LIST_CARD_NOTES",
    "screenCode": "SKBNS027",
    "screenDescription": "KART NOTLARINI LİSTELER."
  },
  {
    "menuName": "Ödül Bilgileri",
    "screenName": "SKBNS021_REWARD_INFOS",
    "screenCode": "SKBNS021"
  },
  {
    "menuName": "Ekstre Detayı",
    "screenName": "SKBNS009_STATEMENT_TRANSACTIONS",
    "screenCode": "SKBNS009"
  },
  {
    "menuName": "EOD İşlemleri",
    "screenName": "SKBNS047_EOD_ACCOUNTING",
    "screenCode": "SKBNS047",
    "screenDescription": "EOD MUHASEBE   İŞLEMLERİ  YAPILIR"
  },
  {
    "menuName": "Günlük Muhasebe",
    "screenName": "https://nova-cps-sekerbonus-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/sekerBonus/SKBNS020",
    "screenCode": "SKBNS020"
  },
  {
    "menuName": "Pos Ciro Geçiş Gözlem",
    "screenName": "SKBNS056_POS_ACCOUNTING",
    "screenCode": "SKBNS056",
    "screenDescription": "POS ACCOUNTING"
  },
  {
    "menuName": "Dış Transfer",
    "screenName": "SKBNS026_OUTER_TRANFER_MANUAL_EXECUTER",
    "screenCode": "SKBNS026"
  },
  {
    "menuName": "Şube Onay Ekranı",
    "screenName": "FTS003_COLLECTIVE_PAYMENT_TRANSFER_MANAGEMENT",
    "screenCode": "FTS003"
  },
  {
    "menuName": "Parametre Yönetimi",
    "screenName": "FTS001_PARAMETER_MANAGEMENT_SCREEN",
    "screenCode": "FTS001"
  },
  {
    "menuName": "Firma Yönetimi",
    "screenName": "FTS002_COLLECTIVE_PAYMENT_FIRM_MANAGEMENT",
    "screenCode": "FTS002"
  },
  {
    "menuName": "YP Toplu Ödeme İzleme",
    "screenName": "FTS004_COLLECTIVE_PAYMENT_TRANSFER_REPORT",
    "screenCode": "FTS004"
  },
  {
    "menuName": "DAB/DSB Gözlem ve Basım",
    "screenName": "FTT009_TRADE_REPORT_FETDEC",
    "screenCode": "FTT009",
    "screenDescription": "DAB GÖZLEM VE BASIM EKRANI"
  },
  {
    "menuName": "Komisyon Masraf Tahsilat İptali (Gelen/Giden YP Havale)",
    "screenName": "FTC019_COMMON_DEDUCTION_OPERATION_FOR_BUSINESS_REF_NO",
    "screenCode": "FTC019"
  },
  {
    "menuName": "Dış Ticaret Taahhüt Tanımlama ve Gözlem",
    "screenName": "FTT052_TRADE_CONTRACT",
    "screenCode": "FTT052"
  },
  {
    "menuName": "Garanti Tazmin Bildirimi",
    "screenName": "FTI040_PERIODIC_NOTIFICATON_GUARANTEE_RESTITUTION",
    "screenCode": "FTI040",
    "screenDescription": "HAZİNE VE MALİYE BAKANLIĞI SÜRELİ BİLDİRİMLER ENTEGRASYONU KAPSAMINDA GARANTİ TAZMİN BİLDİRİMLERİNİN DİJİTAL OLARAK KURUMA GÖNDERİLMESİNİ SAĞLAR."
  },
  {
    "menuName": "Talep Oluşturma",
    "screenName": "FTG002_OUTGOING_COUNTER_GUARANTEE",
    "screenCode": "FTG002"
  },
  {
    "menuName": "Talep Oluşturma",
    "screenName": "FTG001_OUTGOING_DIRECT_GUARANTEE",
    "screenCode": "FTG001"
  },
  {
    "menuName": "Para Gönderme / Para Alma Sorgulama",
    "screenName": "SWF304_WU_OBSERVATION",
    "screenCode": "SWF304"
  },
  {
    "menuName": "Para Gönderme / Para Alma Sorgulama (YENİ)",
    "screenName": "FTW070_WU_SEARCH",
    "screenCode": "FTW070"
  },
  {
    "menuName": "Şube YP Gelen Havale İzleme",
    "screenName": "SWF254_SWIFT_COMING_BRANCH_QUERY",
    "screenCode": "SWF254"
  },
  {
    "menuName": "Fon Rezervasyon Sorgulama",
    "screenName": "SWF216_SWIFT_FUND_RESERVATION_QUERY",
    "screenCode": "SWF216"
  },
  {
    "menuName": "Fon Rezervasyonu",
    "screenName": "SWF215_SWIFT_FUND_RESERVATION",
    "screenCode": "SWF215"
  },
  {
    "menuName": "Yabancı Para Giden Havale Talep Girişi",
    "screenName": "SWF211_SWIFT_REQUEST_ENTER",
    "screenCode": "SWF211",
    "screenDescription": "EFT TALEBİNİN ALINDIĞI EKRANDIR."
  },
  {
    "menuName": "Yabancı Para Giden Havale Sorgulama",
    "screenName": "SWF214_SWIFT_OUTGOING_QUERY",
    "screenCode": "SWF214",
    "screenDescription": "YP GIDEN HAVALE ISLEMLERININ SORGULANMASI/LISTELENMESI"
  },
  {
    "menuName": "YP Havale Kesinti Düzenleme",
    "screenName": "SWF253_SWIFT_COMMISSION_MANAGEMENT",
    "screenCode": "SWF253"
  },
  {
    "menuName": "İhracat Dosya Komisyonları Tahsili",
    "screenName": "FTC021_COMMON_COLLECT_FILE_DEDUCTION",
    "screenCode": "FTC021",
    "screenDescription": "İHRACAT DOSYA KOMİSYON TAHSİLİ"
  },
  {
    "menuName": "İhracat Dosya Komisyonları Yönetimi",
    "screenName": "FTT045_TRADE_COMMISSION_MANAGEMENT",
    "screenCode": "FTT045",
    "screenDescription": "İHRACAT DOSYA MASRAFLARI YÖNETİMİ"
  },
  {
    "menuName": "Exim Taahhüt İşlemleri",
    "screenName": "EXM005_COMMITMENT",
    "screenCode": "EXM005",
    "screenDescription": "TAAHHÜT İŞLEMLERİ"
  },
  {
    "menuName": "Talep Giriş",
    "screenName": "FTT005_TRADE_DISCOUNT_OPERATIONS",
    "screenCode": "FTT005",
    "screenDescription": "İSKONTO TALEP GİRİŞ"
  },
  {
    "menuName": "Kullandırım",
    "screenName": "FTT012_TRADE_DISCOUNT_USAGE",
    "screenCode": "FTT012",
    "screenDescription": "İSKONTO KULLANDIRIM EKRANI"
  },
  {
    "menuName": "Dosya Düzenleme",
    "screenName": "FTT004_TRADE_COMMERCIAL_LETTER_OF_CREDIT",
    "screenCode": "FTT004",
    "screenDescription": "AKREDİTİF"
  },
  {
    "menuName": "Tahsilat",
    "screenName": "FTT008_TRADE_SPSF_DEDUCTION",
    "screenCode": "FTT008",
    "screenDescription": "DFİF KESİNTİLERİNİN ÖDENDİĞİ EKRANDIR."
  },
  {
    "menuName": "İhracat Dosya Gözlem",
    "screenName": "FTT014_TRADE_FILE_OBSERVATION",
    "screenCode": "FTT014",
    "screenDescription": "DOSYA GÖZLEM"
  },
  {
    "menuName": "Gelen Havale Bakiye Gözlem",
    "screenName": "FTT061_TRADE_SWIFT_BALANCE",
    "screenCode": "FTT061",
    "screenDescription": "GELEN HAVALE BAKİYE GÖZLEM"
  },
  {
    "menuName": "KKVM-VM-AKR-Şube-Firma Alış Gözlem",
    "screenName": "FTT021_TRADE_LC_OR_DOCUMENTS_AGAINTS_FILE_OBSERVATION",
    "screenCode": "FTT021",
    "screenDescription": "FTT021_TRADE_LC_OR_DOCUMENTS_AGAINTS_FILE_OBSERVATION"
  },
  {
    "menuName": "İhracatçı Döviz Alış Gözlem",
    "screenName": "FTT024_TRADE_REPORT_EXPORTER_TRADE",
    "screenCode": "FTT024"
  },
  {
    "menuName": "İhracatçı Döviz Alış İstatistik Kodları Gözlem",
    "screenName": "FTT023_TRADE_REPORT_EXPORTER_DAB",
    "screenCode": "FTT023"
  },
  {
    "menuName": "Döviz Beyan Tutanağı Gözlem",
    "screenName": "FTT011_TRADE_REPORT_FEDEC_MINUTE",
    "screenCode": "FTT011",
    "screenDescription": "DÖVİZ BEYAN TUTANAĞI İZLEME"
  },
  {
    "menuName": "Belgeli İhracat Kredileri",
    "screenName": "FTT055_CERTIFIED_EXPORT_LOANS",
    "screenCode": "FTT055"
  },
  {
    "menuName": "Dekont Gözlem",
    "screenName": "FTT040_TRADE_DEKONT_OBSERVATION",
    "screenCode": "FTT040"
  },
  {
    "menuName": "Döviz Satış",
    "screenName": "FTI002_IMPORT_EXCHANGE",
    "screenCode": "FTI002",
    "screenDescription": "DÖVİZ SATIŞ"
  },
  {
    "menuName": "Teklif İzleme",
    "screenName": "FTI035_IMPORT_LC_PROPOSAL_OBSERVATION",
    "screenCode": "FTI035"
  },
  {
    "menuName": "Teklif Giriş/Güncelleme",
    "screenName": "FTI008_IMPORT_LC_PROPOSAL",
    "screenCode": "FTI008",
    "screenDescription": "AKREDİTİF TALEP FORMU"
  },
  {
    "menuName": "Transfer",
    "screenName": "FTI007_IMPORT_TRANSFER",
    "screenCode": "FTI007",
    "screenDescription": "TRANSFER"
  },
  {
    "menuName": "KKDF Tahsilatı",
    "screenName": "FTI013_IMPORT_KKDF_COLLECTION",
    "screenCode": "FTI013",
    "screenDescription": "KKDF TAHSİLAT EKRANI"
  },
  {
    "menuName": "Transfer Bildirim Formu",
    "screenName": "FTI037_TRANSFER_DECLARATION_FORM_SCREEN",
    "screenCode": "FTI037",
    "screenDescription": "MANUEL TRANSFER BİLDİRİM FORMU OLUŞTURMA GÖZLEM İPTAL EKRANI"
  },
  {
    "menuName": "Vesaik-Poliçe Düzenleme",
    "screenName": "FTI005_IMPORT_DOCUMENTS",
    "screenCode": "FTI005",
    "screenDescription": "VESAİK GİRİŞ"
  },
  {
    "menuName": "Transfer Hareket Gözlem",
    "screenName": "FTI020_IMPORT_REPORT_TRANSFER",
    "screenCode": "FTI020",
    "screenDescription": "TRANSFER HAREKET GÖZLEM EKRANI"
  },
  {
    "menuName": "Dosya ve Vesaik Bakiyeleri Raporu",
    "screenName": "FTI031_IMPORT_DOCUMENT_BALANCE_REPORTS",
    "screenCode": "FTI031"
  },
  {
    "menuName": "Dosya Gözlem",
    "screenName": "FTI010_IMPORT_FILE_OBSERVATION",
    "screenCode": "FTI010",
    "screenDescription": "İTHALAT DOSYA GÖZLEM"
  },
  {
    "menuName": "Dosya Hareket Gözlem",
    "screenName": "FTI011_IMPORT_FILE_TRANSACTIONS",
    "screenCode": "FTI011",
    "screenDescription": "DOSYA HAREKET GÖZLEM"
  },
  {
    "menuName": "Gümrük Yazısı / İhbar Mektubu Gözlem",
    "screenName": "FTI036_IMPORT_FILE_DOC_LIST_OBSERVATION",
    "screenCode": "FTI036"
  },
  {
    "menuName": "Müşteri İthalat Rakamları",
    "screenName": "FTI023_IMPORT_FILE_CUST_OBSRV_SEVERAL_MONTHS",
    "screenCode": "FTI023",
    "screenDescription": "İTHALAT RAKAMLARI"
  },
  {
    "menuName": "Vesaik ve Poliçe Raporu",
    "screenName": "FTI030_IMPORT_REPORTS",
    "screenCode": "FTI030",
    "screenDescription": "İTHALAT POLİÇE VE VESAİK BİLGİLERİ GÖZLEM"
  },
  {
    "menuName": "Dosya Rapor",
    "screenName": "FTI022_IMPORT_FILE_REPORT_BY_IMPORTER",
    "screenCode": "FTI022",
    "screenDescription": "DOSYA RAPORU"
  },
  {
    "menuName": "TBF Response Request Gözlem",
    "screenName": "FTI038_WS_RUNTIME",
    "screenCode": "FTI038"
  },
  {
    "menuName": "Talimat Havuz Yönetimi",
    "screenName": "UTL073_ORDER_POOL_MANAGEMENT",
    "screenCode": "UTL073"
  },
  {
    "menuName": "Ekleme/Güncelleme",
    "screenName": "UTL070_DOC_FAX_ORDER_MANAGEMENT",
    "screenCode": "UTL070"
  },
  {
    "menuName": "Eksik Talimat Raporu",
    "screenName": "UTL071_DOC_FAX_ORDER_REPORT",
    "screenCode": "UTL071"
  },
  {
    "menuName": "Günsonu Yönetimi",
    "screenName": "BCH001_BATCH_ENDOFDAY_MANAGEMENT",
    "screenCode": "BCH001",
    "screenDescription": "GÜNSONU YÖNETİM EKRANI"
  },
  {
    "menuName": "Günsonu Geçmişi",
    "screenName": "BCH006_BATCH_ENDOFDAY_HISTORY",
    "screenCode": "BCH006",
    "screenDescription": "GÜNSONU GEÇMİŞİNİ GÖRÜNTÜLER"
  },
  {
    "menuName": "Kayıt İzleme",
    "screenName": "BCH003_BATCH_LOG_VIEWER",
    "screenCode": "BCH003",
    "screenDescription": "KAYIT İZLEME EKRANI"
  },
  {
    "menuName": "Günsonu Monitör",
    "screenName": "BCH002_BATCH_ENDOFDAY_MONITOR",
    "screenCode": "BCH002",
    "screenDescription": "GÜNSONU MONİTOR EKRANI"
  },
  {
    "menuName": "Hata Mesajı Gözlem",
    "screenName": "UTL075_LOGGER_ERROR_MESSAGE",
    "screenCode": "UTL075"
  },
  {
    "menuName": "Günsonu-Batch İşlem Kilit Yönetimi",
    "screenName": "BCH012_BATCH_PROCESS_LOCK_MONITOR",
    "screenCode": "BCH012",
    "screenDescription": "BATCH-GÜNSONU İŞLEM KİLİT DENETİM EKRANI"
  },
  {
    "menuName": "Günsonu Sistem Yönetimi",
    "screenName": "BCH099_BATCH_ENDOFDAY_DIAGNOSTIC",
    "screenCode": "BCH099",
    "screenDescription": "GÜNSONU SİSTEM YÖNETİM EKRANI"
  },
  {
    "menuName": "Günsonu Gözlem",
    "screenName": "BCH011_BATCH_ENDOFDAY_MONITOR_SORGULAMA",
    "screenCode": "BCH011"
  },
  {
    "menuName": "Talimat Gözlem",
    "screenName": "BCH007_ORDER_CUSTOMER",
    "screenCode": "BCH007",
    "screenDescription": "TALİMAT GÖZLEM EKRANI"
  },
  {
    "menuName": "Talimat Tipi Düzenleme",
    "screenName": "BCH008_ORDER_DEFINITION",
    "screenCode": "BCH008",
    "screenDescription": "TALİMAT GRUBU TANIMLAMA"
  },
  {
    "menuName": "Talimat Yönetim",
    "screenName": "BCH010_ORDER_MANAGEMENT",
    "screenCode": "BCH010",
    "screenDescription": "TALİMAT YÖNETİM EKRANI"
  },
  {
    "menuName": "Log İzleme",
    "screenName": "INFRA004_AUDIT_VIEW_LOG",
    "screenCode": "INFRA004"
  },
  {
    "menuName": "Kural Düzenleme",
    "screenName": "INFRA005_AUDIT_MAPPING_RULE",
    "screenCode": "INFRA005"
  },
  {
    "menuName": "Talimat Gözlem",
    "screenName": "CSA021_ORDER_CUSTOMER",
    "screenCode": "CSA021"
  },
  {
    "menuName": "Talimat Yönetim",
    "screenName": "CSA020_ORDER_MANAGEMENT",
    "screenCode": "CSA020"
  },
  {
    "menuName": "Talimat Tipi Düzenleme",
    "screenName": "CSA019_ORDER_DEFINITION",
    "screenCode": "CSA019",
    "screenDescription": "TALİMAT"
  },
  {
    "menuName": "Kilit Yönetimi",
    "screenName": "CSA012_BATCH_PROCESS_LOCK_MONITOR",
    "screenCode": "CSA012",
    "screenDescription": "CSA012_BATCH_PROCESS_LOCK_MONITOR"
  },
  {
    "menuName": "Günsonu Geçmişi",
    "screenName": "CSA006_EOD_ENDOFDAY_HISTORY",
    "screenCode": "CSA006",
    "screenDescription": "122"
  },
  {
    "menuName": "Günsonu Yönetimi",
    "screenName": "CSA001_EOD_ENDOFDAY_MANAGEMENT",
    "screenCode": "CSA001",
    "screenDescription": "YENI GUNSONU EKRANI"
  },
  {
    "menuName": "Günsonu Kayıt İzleme",
    "screenName": "CSA003_BATCH_LOG_VIEWER",
    "screenCode": "CSA003",
    "screenDescription": "BATCH KAYIT İZLEME"
  },
  {
    "menuName": "Günsonu Dashboard",
    "screenName": "CSA016_EOD_DASHBOARD",
    "screenCode": "CSA016",
    "screenDescription": "CSA016"
  },
  {
    "menuName": "Günsonu Monitör",
    "screenName": "CSA002_EOD_ENDOFDAY_MONITOR",
    "screenCode": "CSA002",
    "screenDescription": "CSA002_EOD_ENDOFDAY_MONITOR"
  },
  {
    "menuName": "Sunucu Yönetimi",
    "screenName": "CSA017_EOD_MACHINE_DEFINITION",
    "screenCode": "CSA017",
    "screenDescription": "SUNUCU YÖNETİMİ"
  },
  {
    "menuName": "Kayıt İzleme",
    "screenName": "BCH003_BATCH_LOG_VIEWER",
    "screenCode": "BCH003",
    "screenDescription": "KAYIT İZLEME EKRANI"
  },
  {
    "menuName": "Batch Monitor",
    "screenName": "BCH005_BATCH_GROUP_MONITOR",
    "screenCode": "BCH005",
    "screenDescription": "BATCH MONITOR EKRANI"
  },
  {
    "menuName": "Batch Yönetim",
    "screenName": "BCH004_BATCH_GROUP",
    "screenCode": "BCH004",
    "screenDescription": "BATCH YÖNETİM EKRANI"
  },
  {
    "menuName": "Batch Yönetimi",
    "screenName": "CSA004_BATCH_GROUP",
    "screenCode": "CSA004",
    "screenDescription": "BATCH YONETIM EKRANI"
  },
  {
    "menuName": "Batch Kayıt İzleme",
    "screenName": "CSA003_BATCH_LOG_VIEWER",
    "screenCode": "CSA003",
    "screenDescription": "BATCH KAYIT İZLEME"
  },
  {
    "menuName": "Makine Tanımlama",
    "screenName": "CSA013_BATCH_MACHINE_DEFINITION",
    "screenCode": "CSA013",
    "screenDescription": "BATCH MAKİNE TANIMLAMA EKRANI"
  },
  {
    "menuName": "Batch Monitor",
    "screenName": "CSA005_BATCH_GROUP_MONITOR",
    "screenCode": "CSA005",
    "screenDescription": "BATCH MONITOR EKRANI"
  },
  {
    "menuName": "Batch Dashboard",
    "screenName": "CSA014_BATCH_DASHBOARD",
    "screenCode": "CSA014",
    "screenDescription": "KUŞBAKIŞI BATCH SİSTEMİ"
  },
  {
    "menuName": "Makine Grup Yönetimi",
    "screenName": "CSA018_BATCH_MACHINE_GROUP_DEFINITION",
    "screenCode": "CSA018",
    "screenDescription": "MAKINE GRUP TANIMLAMA EKRANI"
  },
  {
    "menuName": "Batch Sistem Konfigürasyon",
    "screenName": "CSA015_BATCH_CONFIGURATION",
    "screenCode": "CSA015",
    "screenDescription": "BATCH SİSTEM CONFİGURASYONU"
  },
  {
    "menuName": "Anket Soru Tanımlama",
    "screenName": "UTL096_SURVEY_QUESTIONS",
    "screenCode": "UTL096"
  },
  {
    "menuName": "Anket Tanımlama",
    "screenName": "UTL095_SURVEY_DEFINITION",
    "screenCode": "UTL095"
  },
  {
    "menuName": "Web Servisi Yetkilendirme",
    "screenName": "INFRA002_WS_AUTHORIZATION",
    "screenCode": "INFRA002",
    "screenDescription": "WEB SERVİSİ YETKİLENDİRME"
  },
  {
    "menuName": "Menü Yenileme",
    "screenName": "ADM999_ADMIN_MENU_REFRESH",
    "screenCode": "ADM999",
    "screenDescription": "SÜRÜM SONRASI MENÜLERİ YENİLEME EKRANI"
  },
  {
    "menuName": "Muhasebe Fiş Kayıt Testi",
    "screenName": "ACCOUNTING_VOUCHER_PARAM_TEST",
    "screenCode": "ACCOUNT003",
    "screenDescription": "Muhasebe Fiş Kayıt Testi"
  },
  {
    "menuName": "Servis Testi",
    "screenName": "INVESTCORE_ASSET_TEST_ANY_SERVICE",
    "screenCode": "INVCORE105",
    "screenDescription": "Servis Testi"
  },
  {
    "menuName": "İşlem Kıymet Hareketleri Test",
    "screenName": "INVESTCORE_ASSET_TRANSACTION_TEST",
    "screenCode": "INVCORE107",
    "screenDescription": "İşlem Kıymet Hareketleri Test"
  },
  {
    "menuName": "TEST İSTE",
    "screenName": "DENEME",
    "screenCode": "DEX999",
    "screenDescription": "SANANE"
  },
  {
    "menuName": "Gün Sonu Servisleri",
    "screenName": "INVESTCORE999_INVCMN_END_OF_DAY_SERVICES",
    "screenCode": "INVCORE999",
    "screenDescription": "GÜN SONU SERVİSLERİ"
  },
  {
    "menuName": "Numaratör Yönetim",
    "screenName": "UTL001_UTL_NUMERATOR",
    "screenCode": "UTL001",
    "screenDescription": "SAYAÇ DEĞER DÜZENLEME EKRANI"
  },
  {
    "menuName": "IP Bazlı Tarih Tanımlama",
    "screenName": "ADM002_DATE_MANAGEMENT",
    "screenCode": "ADM002",
    "screenDescription": "IP BAZLI TARİH YÖNETİM EKRANI."
  },
  {
    "menuName": "Dinamik Kriter Tanımlama",
    "screenName": "ADM017_ADMIN_UTIL_DYNAMIC_CRITERIA",
    "screenCode": "ADM017",
    "screenDescription": "DİNAMİK KRİTER TANIMLAMA EKRANI."
  },
  {
    "menuName": "Hesap Tutarlılık Kontrolü",
    "screenName": "ACC099_MIGRATION_CHECK",
    "screenCode": "ACC099",
    "screenDescription": "HESAP İLİŞKİLERİNİN TUTARLILIĞINI KONTROL EDİP SONUCU MİGRASYON CHECK ADINDA BİR TABLOYA LOGLAR."
  },
  {
    "menuName": "Web Servisi Yetki Raporu",
    "screenName": "INFRA003_WS_LIST_ALL",
    "screenCode": "INFRA003",
    "screenDescription": "YETKİ TANIMLARINI LİSTELE"
  },
  {
    "menuName": "Veri Tabanı Karşılaştırma",
    "screenName": "INF004_DATA_COMPARE",
    "screenCode": "INF004",
    "screenDescription": "SEÇİLEN PROJENİN 2 VERİ KAYNAĞI ARASINDA  SERVİS,REFERANS VERİ VEYA MESAJ FARKINI GÖSTERİR."
  },
  {
    "menuName": "KKB Token Bilgileri",
    "screenName": "https://nova-fgw-kkbgw-ui-set-alfa.nprd.ocp.sekerbank.com.tr/foreignTrade/KKBGW/KKB035",
    "screenCode": "KKB035",
    "screenDescription": "KKB WEB SERVİSLERİNE ERİŞİMDE KULLANILACAK TOKEN BİLGİLERİNİN DÜZENLENECEĞİ EKRAN"
  },
  {
    "menuName": "Hata Kodları",
    "screenName": "UTL022_UTL_ERROR_CODES",
    "screenCode": "UTL022",
    "screenDescription": "HATA KODU EKRANI"
  },
  {
    "menuName": "Bag Şifreleme Tanım Ekranı",
    "screenName": "UTL021_BAG_ENCODE_MAP",
    "screenCode": "UTL021",
    "screenDescription": "BAG KEY ŞİFRELEME TANIM EKRANI"
  },
  {
    "menuName": "WSDL Üretme ve Telafi Servisi Tanımlama",
    "screenName": "INFRA001_WSDL_GENERATION",
    "screenCode": "INFRA001",
    "screenDescription": "WSDL ÜRETME VE TELAFİ SERVİSİ TANIMLAMA"
  },
  {
    "menuName": "Konfigürasyon Kontrolleri",
    "screenName": "ADM034_ADMIN_UTIL_CONF_MANAGEMENT",
    "screenCode": "ADM034",
    "screenDescription": "SÜRÜM SONRASINDA KONFİGÜRASYONLA İLGİLİ TANIMLARIN KONTROL EDİLDİĞİ EKRANDIR."
  },
  {
    "menuName": "Proje Tanımları",
    "screenName": "UTL080_SQL_LOADER_DEFINITION",
    "screenCode": "UTL080",
    "screenDescription": "SQLLOADER İÇİN PROJE TANIMLARININ YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Transfer Yönetim",
    "screenName": "UTL081_SQL_LOADER_MONITOR",
    "screenCode": "UTL081",
    "screenDescription": "SQL LOADER YÖNETİM EKRANI"
  },
  {
    "menuName": "Transfer Gözlem Ekranı",
    "screenName": "UTL083_SQL_LOADER_MULTI_JOB_MONITORING",
    "screenCode": "UTL083",
    "screenDescription": "SQLLOADER TOPLU İŞLEM GÖZLEM EKRANI"
  },
  {
    "menuName": "Birim Tanımlama",
    "screenName": "ADM005_ADMIN_ORG_ORGANIZATION",
    "screenCode": "ADM005",
    "screenDescription": "BİRİM TANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Birim Servis Tanımlama",
    "screenName": "ADM007_ADMIN_ORG_ORGANIZATION_UNIT",
    "screenCode": "ADM007",
    "screenDescription": "BİRİM SERVİS TANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Birim Bağlılık Tipi Tanımlama",
    "screenName": "ADM004_ADMIN_ORG_DEPENDENCE",
    "screenCode": "ADM004",
    "screenDescription": "BİRİM BAĞLILIK TİPLERİNİN TANIMLANDIĞI EKRAN."
  },
  {
    "menuName": "Banka Genel Tanımları",
    "screenName": "ADM020_ADMIN_ORG_COMMON_DEFINITIONS",
    "screenCode": "ADM020",
    "screenDescription": "BANKA GENEL TANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Birim Grup Tanımlama",
    "screenName": "ADM006_ADMIN_ORG_ORGANIZATION_GROUP",
    "screenCode": "ADM006",
    "screenDescription": "BİRİM GRUP TANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Ortak Birim Grupları Tanım",
    "screenName": "ADM023_ADMIN_COMMON_ORGANIZATION_GROUPS",
    "screenCode": "ADM023",
    "screenDescription": "ORTAK BİRİM GRUPLARI TANIMLAMA EKRANI."
  },
  {
    "menuName": "İşlem Bazlı Kesinti Düzenleme",
    "screenName": "PRD009_PROD_DEDUCTION_DEDUCTIONS",
    "screenCode": "PRD009",
    "screenDescription": "İŞLEM BAZLI KESİNTİLERİN TANIMLANDIĞI EKRANDIR"
  },
  {
    "menuName": "Kesinti Genel Tanım Düzenleme",
    "screenName": "PRD007_PROD_DEDUCTION_ITEM_DEFINITION",
    "screenCode": "PRD007",
    "screenDescription": "KESİNTİ TANIMLAMA EKRANI. KOMİSYON, BSMV, SSDF,VB. KESİNTİLERİNİN GENEL TANIMININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Kesinti Tanım Raporu",
    "screenName": "PRD017_COMM_DEDUCTION_REPORT",
    "screenCode": "PRD017",
    "screenDescription": "İŞLEM BAZLI KESİNTİ RAPORU EKRANI."
  },
  {
    "menuName": "Dinamik Kriter Listesi",
    "screenName": "PRD029_PROD_DYNAMIC_CRITERIA",
    "screenCode": "PRD029",
    "screenDescription": "DİNAMİK KRİTERLER LİSTELEME EKRANI"
  },
  {
    "menuName": "Müşteri Ana Grup Öncelik Düzenleme",
    "screenName": "PRD025_PROD_DEDUCTION_CUSTOMER_MAIN_GROUP_ORDER",
    "screenCode": "PRD025",
    "screenDescription": "MÜŞTERİ ANA GRUPLARININ ÖNCELİKLENDİRİLMESİ"
  },
  {
    "menuName": "İşlem Kesinti İlişkisi Düzenleme",
    "screenName": "PRD008_PROD_DEDUCTION_PROCESS_RELATIONSHIP",
    "screenCode": "PRD008",
    "screenDescription": "İŞLEM KESİNTİ İLİŞKİSİNİN TANIMLANDIĞI EKRAN."
  },
  {
    "menuName": "Müşteri İstisnası Düzenleme",
    "screenName": "PRD010_PROD_DEDUCTION_CUSTOMER_DEDUCTIONS",
    "screenCode": "PRD010",
    "screenDescription": "KESİNTİLER İÇİN MÜŞTERİ İSTİSNALARININ TANIMLANDIĞI EKRANDIR."
  },
  {
    "menuName": "Kesinti Log İzleme",
    "screenName": "PRD028_PROD_DEDUCTION_LOGS",
    "screenCode": "PRD028",
    "screenDescription": "KESİNTİ LOG İZLEME EKRANIDIR."
  },
  {
    "menuName": "Komisyon Raporu",
    "screenName": "PRD019_COMM_REPORT",
    "screenCode": "PRD019",
    "screenDescription": "KOMİSYON RAPORU."
  },
  {
    "menuName": "Ortak Kullanılan Kesinti Düzenleme",
    "screenName": "PRD006_PROD_DEDUCTION_COMMON_DEDUCTIONS",
    "screenCode": "PRD006",
    "screenDescription": "İŞLEMLER TARAFINDAN ORTAK OLARAK KULLANILACAK OLAN KESİNTİLERİN TANIMLANDIĞI EKRANDIR."
  },
  {
    "menuName": "Manuel İşlem İptal",
    "screenName": "EPR029_PROCESSES_MANUALLY_REFUSE",
    "screenCode": "EPR029"
  },
  {
    "menuName": "İşlem Kısıt Düzenleme",
    "screenName": "UTL005_RESTRICTION_OPERATION_DEFINITION",
    "screenCode": "UTL005",
    "screenDescription": "İŞLEM KISIT TANIM EKRANI"
  },
  {
    "menuName": "İşlem Ekran Tanımlama",
    "screenName": "EPR004_PROCESS_SCREEN_DEFINITIONS",
    "screenCode": "EPR004",
    "screenDescription": "PROCESS BAZINDA ONAY/DÜZELTME EKRAN/REGION TANIMLAMA EKRANI"
  },
  {
    "menuName": "İşlem Kontrol Yönetimi",
    "screenName": "EPR002_PROCESS_DEFINITION_BUSINESS",
    "screenCode": "EPR002",
    "screenDescription": "BANKA PERSONELİ İÇİN PROCESS TANIMLAMA EKRANI"
  },
  {
    "menuName": "İşlem Grubu Düzenleme",
    "screenName": "EPR003_PROCESS_GROUP_DEFINITION",
    "screenCode": "EPR003",
    "screenDescription": "PROCESS GRUPLARI TANIMLAMA EKRANI"
  },
  {
    "menuName": "İşlem Düzenleme",
    "screenName": "EPR001_PROCESS_DEFINITION",
    "screenCode": "EPR001",
    "screenDescription": "PROCESS TANIMLAMA EKRANI"
  },
  {
    "menuName": "İşlem Zaman Limitleri Tanımlama",
    "screenName": "EPR023_PROCESS_TIME_CONTROL_RESTRICTED",
    "screenCode": "EPR023",
    "screenDescription": "SGMK TARAFINDAKİ PROCESSLERDEN BİR KISMININ ZAMAN KISITLAMALARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "İşlem Parametre Tanımlama",
    "screenName": "APP002_PROCESS_CONTROL",
    "screenCode": "APP002",
    "screenDescription": "İŞLEM PARAMETRE TANIMLAMA EKRANI."
  },
  {
    "menuName": "İşlem Kayıt Kilit Tanımlama",
    "screenName": "EPR017_PROCESS_LOCKED_OBJECTS",
    "screenCode": "EPR017",
    "screenDescription": "PROCESS BAZINDA KAYIT KİLİT TANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Onay Kural Düzenleme",
    "screenName": "EPR007_RULE_DEFINITION",
    "screenCode": "EPR007",
    "screenDescription": "KURAL TANIMLAMA EKRANI"
  },
  {
    "menuName": "Onay Tanım Taşıma(Alfa Yedek ten)",
    "screenName": "APP004_MOVE_APPROVEMENT_DEFINITIONS",
    "screenCode": "APP004",
    "screenDescription": "ALFA-YEDEK ORTAMINDAN ONAY TANIMLARININ ÇALIŞTIRILDIĞI ORTAMA  AKTARILMASINI SAĞLAR. ALFA YEDEK ARTAMINDA ÇALIŞTIRILMAMALIDIR."
  },
  {
    "menuName": "Evrak Tanımlama",
    "screenName": "PRD015_PROD_PRODUCT_PAPER_DEFINITION",
    "screenCode": "PRD015",
    "screenDescription": "EVRAK TANIMLAMA EKRANI"
  },
  {
    "menuName": "Farklı Dilde Ürün Ana Grup, Ürün Grup ve Ürün Tanımı Düzenleme",
    "screenName": "PRD021_PROD_PRODUCT_GROUPS_LANG",
    "screenCode": "PRD021",
    "screenDescription": "ÜRÜN ANA GRUPLARININ, ÜRÜN GRUPLARININ VE ÜRÜNLERİN FARKLI DİLLERDE TANIMLARININ YAPILDIĞI EKRANDIR."
  },
  {
    "menuName": "Ürün Satılabilirlik Kuralı Düzenleme",
    "screenName": "PRD012_PROD_PRODUCT_SALE_RULES",
    "screenCode": "PRD012",
    "screenDescription": "ÜRÜN SATILABİLİRLİK KURALLARININ DÜZENLENDİĞİ EKRANDIR."
  },
  {
    "menuName": "Ürün-Evrak İlişkisi Düzenleme",
    "screenName": "PRD016_PROD_PRODUCT_PAPER_RELATIONSHIP",
    "screenCode": "PRD016",
    "screenDescription": "ÜRÜN EVRAK İLİŞKİSİ EKRANI"
  },
  {
    "menuName": "Ürün Ana Grup, Ürün Grup ve Ürün Düzenleme",
    "screenName": "PRD011_PROD_PRODUCT_GROUPS",
    "screenCode": "PRD011",
    "screenDescription": "ÜRÜN ANA GRUBU, ÜRÜN GRUBU VE ÜRÜN TANIMLARININ YAPILDIĞI EKRANDIR."
  },
  {
    "menuName": "KKB Gsm-Iban Sorgulama",
    "screenName": "https://nova-fgw-kkbgw-ui-set-alfa.nprd.ocp.sekerbank.com.tr/fgw/kkbgw/KKB038",
    "screenCode": "KKB038",
    "screenDescription": "KKB GSM,IBAN SORGULAMA-VE YENİ EKLENECEK SORGULAMALAR"
  },
  {
    "menuName": "Mesaj Alıcı Grubu Tanımlama",
    "screenName": "UTL013_MESSAGE_RECEIVER",
    "screenCode": "UTL013",
    "screenDescription": "MESAJ ALICI GRUBU DÜZENLEME"
  },
  {
    "menuName": "Mesaj Tanımlama",
    "screenName": "UTL012_MESSAGE_DEFINITION",
    "screenCode": "UTL012",
    "screenDescription": "TANIMLI MESAJ DÜZENLEME"
  },
  {
    "menuName": "Mesaj Gönderme",
    "screenName": "UTL014_MESSAGE_SEND",
    "screenCode": "UTL014",
    "screenDescription": "MESAJ GÖNDERME EKRANI"
  },
  {
    "menuName": "Ekran Elemanı Tanımlama",
    "screenName": "UTL009_PORG_BREG_BEAN_REGISTRY",
    "screenCode": "UTL009"
  },
  {
    "menuName": "Kural Tanımlama",
    "screenName": "UTL011_PORG_RULE_DEFINITION",
    "screenCode": "UTL011"
  },
  {
    "menuName": "Ekran Kural-İşleyiş Düzenleme",
    "screenName": "UTL010_PORG_RULE_FUNCTIONALITY_DEFINITION",
    "screenCode": "UTL010"
  },
  {
    "menuName": "Düzenleme",
    "screenName": "ADM003_ADMIN_MENU_DEFINITION",
    "screenCode": "ADM003",
    "screenDescription": "MENÜ TANIMLAMA EKRANI."
  },
  {
    "menuName": "Ekran Eylemi Düzenleme",
    "screenName": "ADM026_ADMIN_SCREEN_ACTION_DEFINITION",
    "screenCode": "ADM026",
    "screenDescription": "EKRAN EYLEM ATANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "React Ekran Menü Tanımları",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM067",
    "screenCode": "ADM067",
    "screenDescription": "REACT MENÜ EKRANLARININ URI PATHLERİ"
  },
  {
    "menuName": "Ekran Düzenleme",
    "screenName": "ADM024_ADMIN_SCREEN_DEFINITION",
    "screenCode": "ADM024",
    "screenDescription": "EKRAN TANIMLARININ YAPILDIĞI EKRAN."
  },
  {
    "menuName": "Araç Marka_Model Düzenleme",
    "screenName": "UTL017_UTL_CAR_BRAND_MODELS",
    "screenCode": "UTL017",
    "screenDescription": "ARAÇ MARKA-MODEL DÜZENLEME EKRANI"
  },
  {
    "menuName": "Kanal Düzenleme",
    "screenName": "EPR016_CHANNELS_DEFINITION",
    "screenCode": "EPR016",
    "screenDescription": "KANAL TANIM EKRANI"
  },
  {
    "menuName": "Kurum Fonsiyonu Düzenleme",
    "screenName": "UTL004_INSTITUTION_INST_DEF",
    "screenCode": "UTL004",
    "screenDescription": "KURUM FONKSİYONU DÜZENLEME"
  },
  {
    "menuName": "Ülke İl-İlçe Düzenleme",
    "screenName": "UTL002_LOCATION_DEFINITION",
    "screenCode": "UTL002",
    "screenDescription": "ÜLKE/İL/İLÇE DÜZENLEME"
  },
  {
    "menuName": "Tatil Günleri Listeleme",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM021",
    "screenCode": "ADM021",
    "screenDescription": "TATİL GÜNLERİ LİSTELEME EKRANI."
  },
  {
    "menuName": "Uluslararası Organizasyonlar",
    "screenName": "UTL090_INTERNATIONAL_ORGS",
    "screenCode": "UTL090",
    "screenDescription": "ULUSLARARASI ORGANİZASYONLAR VE ÜLKE İLİŞKİLERİNİN TANIMLANDIĞI EKRAN"
  },
  {
    "menuName": "Tatil Günleri Tanımlama",
    "screenName": "ADM001_UTIL_DATE_HOLIDAY_MANAGEMENT",
    "screenCode": "ADM001",
    "screenDescription": "TATİL GÜNLERİ DÜZENLEME EKRANI."
  },
  {
    "menuName": "Çalışma Saatleri ve İstisna Yönetimi",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM065",
    "screenCode": "ADM065"
  },
  {
    "menuName": "Kullanıcı Delegasyon Raporu",
    "screenName": "ADM060_ADMIN_USR_USER_DELEGATION_REPORT",
    "screenCode": "ADM060",
    "screenDescription": "DELEGASYON RAPORU"
  },
  {
    "menuName": "Kullanıcı Profil Tanımları Tarihçesi Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM046",
    "screenCode": "ADM046",
    "screenDescription": "KULLANICI PROFİLİ TANIMLAMA TARİHÇESİ RAPOR EKRANIDIR."
  },
  {
    "menuName": "Kullanıcı Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM033",
    "screenCode": "ADM033",
    "screenDescription": "KULLANICI RAPORU EKRANI"
  },
  {
    "menuName": "Kullanıcı Login Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM022",
    "screenCode": "ADM022",
    "screenDescription": "KULLANICI LOG-IN RAPORU EKRANI."
  },
  {
    "menuName": "Kullanıcı İşlemleri Raporu",
    "screenName": "ADM058_ADMIN_USR_USER_PROCESS_REPORT",
    "screenCode": "ADM058",
    "screenDescription": "KULLANICI İŞLEMLERİ RAPORU"
  },
  {
    "menuName": "Süresi Dolmuş Delegasyonlar",
    "screenName": "ADM013_ADMIN_USR_EXPIRED_DELEGATIONS",
    "screenCode": "ADM013",
    "screenDescription": "SÜRESİ DOLMUŞ DELEGASYONLAR EKRANI."
  },
  {
    "menuName": "Kullanıcı Durum Tarihçesi Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM047",
    "screenCode": "ADM047",
    "screenDescription": "KULLANICI DURUMU TARİHÇESİ RAPOR EKRANIDIR."
  },
  {
    "menuName": "İşlem Kontrol Yönetimi Raporu",
    "screenName": "EPR025_BUSINESS_DEFINITION_REPORT",
    "screenCode": "EPR025",
    "screenDescription": "İŞLEM RAPORU"
  },
  {
    "menuName": "İşlem Parametre Tanım Tarihçe Raporu",
    "screenName": "APP005_PROCESS_CONTROL_HISTORY_REPORT",
    "screenCode": "APP005",
    "screenDescription": "İŞLEM KONTROL TARİHÇESİ RAPORU."
  },
  {
    "menuName": "Tarih Bazlı İşlem Zaman Kısıtları Raporu",
    "screenName": "EPR018_PROCESS_TIME_LIMITS_LOG_REPORT",
    "screenCode": "EPR018"
  },
  {
    "menuName": "İşlem Tutar Kısıtları Raporu",
    "screenName": "EPR026_PROCESS_AMOUNT_RESTRICTIONS_REPORT",
    "screenCode": "EPR026"
  },
  {
    "menuName": "İşlem Tutar-Zaman Tarihçesi Raporu",
    "screenName": "EPR028_PROCESS_TIME_AMOUNT_RESTRICTIONS_REPORT",
    "screenCode": "EPR028",
    "screenDescription": "İŞLEM TUTAR VE ZAMAN TARİHÇESİ RAPORU"
  },
  {
    "menuName": "İşlem Zaman Kısıtları Raporu",
    "screenName": "EPR027_PROCESS_TIME_RESTRICTIONS_REPORT",
    "screenCode": "EPR027"
  },
  {
    "menuName": "Kurum Fonksiyon Raporu",
    "screenName": "UTL016_RPRT_INSTITUTION_FUNCTIONS",
    "screenCode": "UTL016",
    "screenDescription": "KURUM FONKSİYON RAPORU"
  },
  {
    "menuName": "Birim_Servis_Profil Raporu",
    "screenName": "ADM050_ADMIN_ORG_UNIT_PROFILES_REPORT",
    "screenCode": "ADM050"
  },
  {
    "menuName": "Birim Grubu Tanımları Tarihçesi",
    "screenName": "ADM043_ADMIN_ORG_GROUP_HISTORY_REPORT",
    "screenCode": "ADM043",
    "screenDescription": "BİRİM GRUP TANIMLAMA TARİHÇESİ EKRANIDIR."
  },
  {
    "menuName": "Ünvan Tanımları Tarihçesi",
    "screenName": "ADM039_ADMIN_USR_TITLE_HISTORY_REPORT",
    "screenCode": "ADM039",
    "screenDescription": "ÜNVAN TANIMLARI RAPOR EKRANIDIR."
  },
  {
    "menuName": "Servis Tanımları Tarihçesi",
    "screenName": "ADM040_ADMIN_ORG_ORG_UNIT_HISTORY_REPORT",
    "screenCode": "ADM040",
    "screenDescription": "SERVİS TANIMLAMA TARİHÇESİ RAPOR EKRANIDIR."
  },
  {
    "menuName": "Birim Bağlılık Tipi Tanımları Tarihçesi",
    "screenName": "ADM041_ADMIN_ORG_DEPENDENCE_TYPE_HISTORY_REPORT",
    "screenCode": "ADM041",
    "screenDescription": "BİRİM BAĞLILIK TİPİ TANIMLAMA TARİHÇESİ RAPOR EKRANIDIR."
  },
  {
    "menuName": "Birim Tanımları Tarihçesi",
    "screenName": "ADM045_ADMIN_ORG_ORGANIZATION_HISTORY_REPORT",
    "screenCode": "ADM045",
    "screenDescription": "BİRİM TANIMLAMA TARİHÇESİ EKRANIDIR."
  },
  {
    "menuName": "Birim Bağlılık Tipi Raporu",
    "screenName": "ADM032_ADMIN_ORG_GROUP_DEPENDENCE_REPORT",
    "screenCode": "ADM032",
    "screenDescription": "BİRİM BAĞLILIK TİPİ RAPOR EKRANI"
  },
  {
    "menuName": "Onay Durumuna Göre İşlemler",
    "screenName": "EPR020_APPROVEMENT_REPORT",
    "screenCode": "EPR020",
    "screenDescription": "ONAY DURUMUNA GÖRE İŞLEM GÖZLEM EKRANI"
  },
  {
    "menuName": "Onay Tanımları Raporu",
    "screenName": "APP003_APPROVEMENT_DEFINITIONS",
    "screenCode": "APP003",
    "screenDescription": "ONAY TANIMLARI RAPORU EKRANI"
  },
  {
    "menuName": "Ekran/İşlem Yetkilendirme Detay Raporu",
    "screenName": "ADM066_AUTH_GROUP_MENU_PROC_ACTION_LOG",
    "screenCode": "ADM066",
    "screenDescription": "EKRAN VE İŞLEM YETKİLENDİRMELERİ LOG GÖZLEM EKRANI"
  },
  {
    "menuName": "Profil Listesi",
    "screenName": "ADM049_ADMIN_USR_PROFILE_REPORT",
    "screenCode": "ADM049",
    "screenDescription": "PROFİL TANIMLARININ RAPOR EKRANIDIR."
  },
  {
    "menuName": "İşlem Bazlı Yetki Grupları Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM036",
    "screenCode": "ADM036",
    "screenDescription": "İŞLEM BAZLI YETKİ GRUPLARININ RAPORLANDIĞI EKRAN."
  },
  {
    "menuName": "Ekran Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM038",
    "screenCode": "ADM038",
    "screenDescription": "EKRANLARDAKİ İŞLEM VE EKRAN EYLEMLERİNİ RAPORLAYAN EKRANDIR."
  },
  {
    "menuName": "Ekran Eylemi Raporu",
    "screenName": "ADM055_ADMIN_SCREEN_AUTHORIZATION_REPORT",
    "screenCode": "ADM055",
    "screenDescription": "EKRAN EYLEMİ YETKİLENDİRME RAPORU"
  },
  {
    "menuName": "Yetki Grubu Tanımları Tarihçesi",
    "screenName": "ADM042_ADMIN_USR_AUTHORITY_GROUP_HISTORY_REPORT",
    "screenCode": "ADM042",
    "screenDescription": "YETKİ GRUPLARI TANIMLAMA TARİHÇESİ RAPOR EKRANIDIR."
  },
  {
    "menuName": "Ekran Eylem - Veri Yetklendirme Log Raporu",
    "screenName": "ADM059_ADMIN_ACT_AUTH_DATA_REST_LOG",
    "screenCode": "ADM059",
    "screenDescription": "EKRAN EYLEM VERİ YETKİLENDİRME LOG RAPORU"
  },
  {
    "menuName": "Menü Bazlı Yetki Grupları Raporu",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM037",
    "screenCode": "ADM037",
    "screenDescription": "MENÜ BAZLI YETKİ GRUPLARININ RAPORLANDIĞI EKRAN."
  },
  {
    "menuName": "Profil Yetkileri",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM062",
    "screenCode": "ADM062",
    "screenDescription": "ADM062_ADMIN_USR_PROFILE_AUTHORITY"
  },
  {
    "menuName": "Profil Tanımları Tarihçesi",
    "screenName": "ADM044_ADMIN_USR_PROFILE_HISTORY_REPORT",
    "screenCode": "ADM044",
    "screenDescription": "KULLANICI PROFİL TANIMLAMA TARİHÇESİ RAPOR EKRANIDIR."
  },
  {
    "menuName": "Veri Yetkilendirme Raporu",
    "screenName": "ADM054_ADMIN_UTIL_RESTRICTION_AUTHORIZATION_REPORT",
    "screenCode": "ADM054",
    "screenDescription": "VERİ YETKİLENDİRME TANIMLARI RAPORU"
  },
  {
    "menuName": "Kullanıcı Tatil Erişim Raporu",
    "screenName": "ADM057_ADMIN_USR_LOGIN_IN_HOLIDAY_REPORT",
    "screenCode": "ADM057",
    "screenDescription": "İZİN DÖNEMİNDE SİSTEME LOGİN OLAN ULLANICILAR LİSTESİNİ VEREN RAPOR EKRANI"
  },
  {
    "menuName": "Kullanıcı Düzenleme",
    "screenName": "ADM016_ADMIN_USR_USER",
    "screenCode": "ADM016",
    "screenDescription": "KULLANICI TANIMLAMA EKRANI."
  },
  {
    "menuName": "Ünvan Düzenleme",
    "screenName": "ADM015_ADMIN_USR_TITLE",
    "screenCode": "ADM015",
    "screenDescription": "ÜNVAN TANIMLAMA EKRANI."
  },
  {
    "menuName": "Kullanıcı Şifresi Yaratma",
    "screenName": "ADM019_ADMIN_USR_ADMIN_CHANGE_PASSWORD",
    "screenCode": "ADM019",
    "screenDescription": "KULLANICI ŞİFRESİ DEĞİŞTİRME EKRANI."
  },
  {
    "menuName": "Veri Yetkilendirme",
    "screenName": "ADM051_ADMIN_UTIL_RESTRICTION_AUTHORIZATION",
    "screenCode": "ADM051",
    "screenDescription": "PROFİL - VERİ  YETKİLENDİRİLMESİ EKRANI"
  },
  {
    "menuName": "Kullanıcı Profil Atama",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM025",
    "screenCode": "ADM025",
    "screenDescription": "KULLANICI PROFİLİ ATAMA EKRANI."
  },
  {
    "menuName": "Veri Grubu Tanımlama",
    "screenName": "ADM053_UTIL_RESTRICTION",
    "screenCode": "ADM053",
    "screenDescription": "VERİ GRUBU TANIM EKRANI"
  },
  {
    "menuName": "Yetki Grubu - İşlem İlişkilendirme",
    "screenName": "ADM010_ADMIN_USR_AUTHORITY_GROUP_PROCESS",
    "screenCode": "ADM010",
    "screenDescription": "KULLANICI YETKİ GRUBU-İŞLEM İLİŞKİLENDİRME EKRANI."
  },
  {
    "menuName": "Yetki Grubu - Menü İlişkilendirme",
    "screenName": "ADM009_ADMIN_USR_AUTHORITY_GROUP_MENU",
    "screenCode": "ADM009",
    "screenDescription": "KULLANICI YETKİ GRUBU-MENÜ İLİŞKİLENDİRME EKRANI."
  },
  {
    "menuName": "İşlem-Yetki Grubu İlişkilendirme",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM064",
    "screenCode": "ADM064",
    "screenDescription": "İŞLEME YETKİ GRUBU İLİŞKİLENDİRME EKRANI"
  },
  {
    "menuName": "Menü-Yetki Grubu İlişkilendirme",
    "screenName": "ADM063_ADMIN_USR_MENU_AUTHORITY_GROUP",
    "screenCode": "ADM063",
    "screenDescription": "MENÜ'YE YETKİ GRUBU İLİŞKİLENDİRME EKRANI"
  },
  {
    "menuName": "Ekran Eylem Yetki Düzenleme",
    "screenName": "ADM048_ADMIN_SCREEN_AUTORIZATION_EXTENSION",
    "screenCode": "ADM048",
    "screenDescription": "EKRAN EYLEMİ  YETKİLENDİRME EKRANI"
  },
  {
    "menuName": "Veri Grubu Kümesi Tanımlama",
    "screenName": "ADM052_UTIL_RESTRICTION_SELECTION",
    "screenCode": "ADM052",
    "screenDescription": "VERİ YETKİ KISIT TANIM EKRANI"
  },
  {
    "menuName": "Profil Tanımlama",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM014",
    "screenCode": "ADM014",
    "screenDescription": "KULLANICI PROFİLİ TANIMLAMA EKRANI."
  },
  {
    "menuName": "Yetki Grubu Tanımlama",
    "screenName": "ADM008_ADMIN_USR_AUTHORITY_GROUP",
    "screenCode": "ADM008",
    "screenDescription": "KULLANICI YETKİ GRUBU TANIMLAMA EKRANI."
  },
  {
    "menuName": "Kesinti İşlem Grubu Düzenleme",
    "screenName": "PRC008_PRICING_DEDUCTION_OPERATION_GROUP_DEFINITION",
    "screenCode": "PRC008"
  },
  {
    "menuName": "Şube İndirim Oranı Tanımlama",
    "screenName": "PRC009_PRICING_BRANCH_DISCOUNT_RATE_DEFINITION",
    "screenCode": "PRC009"
  },
  {
    "menuName": "İşlem Bazlı Kesinti Düzenleme",
    "screenName": "PRC005_PRICING_OPERATION_DEDUCTION_DEFINITION",
    "screenCode": "PRC005"
  },
  {
    "menuName": "Sistem Parametre Düzenleme",
    "screenName": "PRC011_PRICING_SYSTEM_PARAMETER_DEFINITION",
    "screenCode": "PRC011"
  },
  {
    "menuName": "İstisna Tanımlama",
    "screenName": "PRC007_PRICING_EXCEMPTION_DEFINITION",
    "screenCode": "PRC007"
  },
  {
    "menuName": "İşlem Kesinti İlişkisi Düzenleme",
    "screenName": "PRC004_PRICING_OPERATION_DEDUCTION_RELATION_DEFINITION",
    "screenCode": "PRC004"
  },
  {
    "menuName": "Kesinti İptal İade Yetkileri Düzenleme",
    "screenName": "PRC010_PRICING_CANCEL_REBATE_DEFINITION",
    "screenCode": "PRC010"
  },
  {
    "menuName": "Kesinti Tanımlama",
    "screenName": "PRC002_PRICING_DEDUCTION_DEFINITION",
    "screenCode": "PRC002"
  },
  {
    "menuName": "Yönetsel Parametre Düzenleme",
    "screenName": "PRC012_PRICING_ADMINISTRATIVE_PARAMETER_DEFINITION",
    "screenCode": "PRC012"
  },
  {
    "menuName": "Ortak Kesinti Düzenleme",
    "screenName": "PRC006_PRICING_SHARED_OPERATION_DEDUCTION_DEFINITION",
    "screenCode": "PRC006"
  },
  {
    "menuName": "Kriter Tanımlama",
    "screenName": "PRC003_PRICING_CRITERIA_DEFINITION",
    "screenCode": "PRC003"
  },
  {
    "menuName": "Onay Mercii - Profil İlişkisi Düzenleme",
    "screenName": "PRC016_PRICING_AUTHORITY_PROFILE_DEFINITION",
    "screenCode": "PRC016"
  },
  {
    "menuName": "Tanımları Ortamlar Arası Taşıma",
    "screenName": "PRC017_PRICING_DEFINITION_TRANSFER",
    "screenCode": "PRC017"
  },
  {
    "menuName": "İptal İade İşlemleri",
    "screenName": "PRC014_PRICING_CANCEL_REBATE",
    "screenCode": "PRC014"
  },
  {
    "menuName": "Müşteri Bazında İstisna Detay Gözlem Raporu",
    "screenName": "PRC025_CUSTOMER_BASED_EXCEMPTION_DETAIL_REPORT",
    "screenCode": "PRC025"
  },
  {
    "menuName": "Komisyon Gelir Raporu",
    "screenName": "PRC026_BRANCH_BANK_SERVICE_INCOME_REPORT",
    "screenCode": "PRC026"
  },
  {
    "menuName": "Müşteri Bazlı Komisyon Gelir Raporu",
    "screenName": "PRC027_BRANCH_CUSTOMER_BASED_BANK_SERVICE_INCOME_REPORT",
    "screenCode": "PRC027"
  },
  {
    "menuName": "Manüel Tahsilat İşlemleri",
    "screenName": "PRC013_PRICING_MANUAL_COLLECTION",
    "screenCode": "PRC013"
  },
  {
    "menuName": "Dosyayı Servise Gönderme",
    "screenName": "UTL063_FILE_TRANSFER_PARSE_AND_SEND",
    "screenCode": "UTL063"
  },
  {
    "menuName": "Dosya Desen Düzenleme",
    "screenName": "UTL061_FILE_TRANSFER_INSERT_FILE_PATTERN",
    "screenCode": "UTL061"
  },
  {
    "menuName": "Ara Tabloya Alma",
    "screenName": "UTL062_FILE_TRANSFER_IN",
    "screenCode": "UTL062"
  },
  {
    "menuName": "Zaman ve Tutar Limitleri Taşıma",
    "screenName": "UTL058_DATA_TRANSFER_AMOUNT_TIME_LIMIT_TRANSFER",
    "screenCode": "UTL058"
  },
  {
    "menuName": "Kontrol Değişken Taşıma",
    "screenName": "UTL055_DATA_TRANSFER_CONTROL_VARIABLE_TRANSFER",
    "screenCode": "UTL055"
  },
  {
    "menuName": "Meta Hesap Taşıma",
    "screenName": "UTL051_DATA_TRANSFER_META_ACC_TRANSFER",
    "screenCode": "UTL051"
  },
  {
    "menuName": "Dış Sistem Veri Aktar Tanımları Taşıma",
    "screenName": "UTL056_DATA_TRANSFER_OUTER_SYS_TRANS_DEF",
    "screenCode": "UTL056"
  },
  {
    "menuName": "Master Tablo Taşıma",
    "screenName": "UTL059_DATA_TRANSFER_MASTER_TABLES",
    "screenCode": "UTL059"
  },
  {
    "menuName": "Process Taşıma",
    "screenName": "UTL049_DATA_TRANSFER_BETWEEN_ENVIRONMENT",
    "screenCode": "UTL049"
  },
  {
    "menuName": "Onay Taşıma",
    "screenName": "UTL057_DATA_TRANSFER_APPROVEMENT_TRANSFER",
    "screenCode": "UTL057"
  },
  {
    "menuName": "Kural Taşıma",
    "screenName": "UTL054_DATA_TRANSFER_RULES_TRANSFER",
    "screenCode": "UTL054"
  },
  {
    "menuName": "Menu Taşıma",
    "screenName": "UTL052_DATA_TRANSFER_MENU_TRANSFER",
    "screenCode": "UTL052"
  },
  {
    "menuName": "Muhasebe Fiş Taşıma",
    "screenName": "UTL050_DATA_TRANSFER_ACCOUNTING_TRANSFER",
    "screenCode": "UTL050"
  },
  {
    "menuName": "Kullanıcı / Password Tanımlama",
    "screenName": "UTL053_DATA_TRANSFER_ENVIRONMENT_DEFINITION",
    "screenCode": "UTL053"
  },
  {
    "menuName": "Dış Sistem Veri Aktarımı Parametre Tanımlama",
    "screenName": "UTL007_OUTER_SYSTEM_TRANSFER_PARAM_DEF",
    "screenCode": "UTL007",
    "screenDescription": "DIŞ SİSTEM VERİ AKTARIMI PARAMETRE TANIMLAMA"
  },
  {
    "menuName": "FTP Log Gözlem",
    "screenName": "UTL038_OUTER_SYSTEM_FTP_LOG_VIEWER",
    "screenCode": "UTL038",
    "screenDescription": "FTP LOG GÖZLEM"
  },
  {
    "menuName": "FTP Server Tanımlama",
    "screenName": "UTL029_OUTER_SYSTEM_FTP_DEF",
    "screenCode": "UTL029",
    "screenDescription": "UTL029_OUTER_SYSTEM_FTP_DEF"
  },
  {
    "menuName": "Şifreleme Anahtar Yönetimi",
    "screenName": "UTL072_UTL_ENCRYPTION_KEYFILE_MANAGEMENT",
    "screenCode": "UTL072"
  },
  {
    "menuName": "Dış Sistem Veri Aktarımı İzleme",
    "screenName": "UTL008_OUTER_SYSTEM_TRANSFER_RECORD",
    "screenCode": "UTL008",
    "screenDescription": "DIŞ SİSTEM VERİ AKTARIMI İZLEME"
  },
  {
    "menuName": "Dış Sistem Veri Aktarımı",
    "screenName": "https://nova-infra-utility-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/utility/UTL006",
    "screenCode": "UTL006",
    "screenDescription": "DIŞ SİSTEM VERİ AKTARIMI"
  },
  {
    "menuName": "Pin Bypass - Pin Block Tanımlama",
    "screenName": "AMSD005_MCC_FILTER_FOR_PIN_BYPASS",
    "screenCode": "AMSD005"
  },
  {
    "menuName": "Provizyon Filtre Parametreleri",
    "screenName": "AMSD004_PROVISION_FILTER_PARAMETERS",
    "screenCode": "AMSD004",
    "screenDescription": "PROVİZYON FİLTRE PARAMETRELERİ"
  },
  {
    "menuName": "Decline Codes",
    "screenName": "AMSD003_DECLINE_CODES",
    "screenCode": "AMSD003",
    "screenDescription": "DECLINE CODES"
  },
  {
    "menuName": "Birincil Parametreler",
    "screenName": "AMSD001_PRIMARY_AUTHORIZATION_PARAMETERS",
    "screenCode": "AMSD001",
    "screenDescription": "BİRİNCİL PARAMETRELER"
  },
  {
    "menuName": "Chip Parametreleri",
    "screenName": "AMSD002_CHIP_PROVISION_PARAMETERS",
    "screenCode": "AMSD002",
    "screenDescription": "ÇİP PARAMETRELERİ"
  },
  {
    "menuName": "Ticari Kart Başvuru",
    "screenName": "DCMS100_BUSINESS_CARD_APPLICATION",
    "screenCode": "DCMS100",
    "screenDescription": "TİCARİ DEBİT KART BAŞVURU EKRANI"
  },
  {
    "menuName": "Ticarti Kart Başvuru Gözlem",
    "screenName": "DCMS101_BUSINESS_CARD_APPLICATION_INFO",
    "screenCode": "DCMS101",
    "screenDescription": "TİCARİ DEBIT KART BAŞVURU GÖZLEM EKRANI"
  },
  {
    "menuName": "Script Gönderim Bilgileri İzleme",
    "screenName": "DSCR004_DBT_SCRIPT_DETAIL",
    "screenCode": "DSCR004"
  },
  {
    "menuName": "Tek Karta Script Gönderim",
    "screenName": "DSCR002_DBT_SEND_SCRIPT_FOR_ONE_CARD",
    "screenCode": "DSCR002"
  },
  {
    "menuName": "Script Yönetim Parametre Tanım",
    "screenName": "DSCR001_DBT_SCRIPT_PARAMETER_DEFINITION",
    "screenCode": "DSCR001"
  },
  {
    "menuName": "Banka Kartı İade Ekranı",
    "screenName": "DCMS022_DEBIT_CARD_CHARGEBACK_OPERATIONS",
    "screenCode": "DCMS022",
    "screenDescription": "DEBIT CARD İŞLEMLERİNİN İADESİNİN YAPILDIĞI EKRAN"
  },
  {
    "menuName": "Yeniden Kart Baskı Dosyası Oluştur",
    "screenName": "DCMS017_RECREATE_CARD_GROUP",
    "screenCode": "DCMS017"
  },
  {
    "menuName": "Basılacak Şifreler Listesi",
    "screenName": "DCMS016_PRINT_PIN",
    "screenCode": "DCMS016"
  },
  {
    "menuName": "Şifre Zarfı Basım Talebi",
    "screenName": "DCMS021_DEBIT_CARD_PIN_REQUEST",
    "screenCode": "DCMS021"
  },
  {
    "menuName": "Basılacak Kartlar İzleme",
    "screenName": "DCMS014_REISSUE_CARD_PRESS",
    "screenCode": "DCMS014"
  },
  {
    "menuName": "Gruplanan Kartların Listesi",
    "screenName": "DCMS015_REISSUE_CARD_GROUP",
    "screenCode": "DCMS015"
  },
  {
    "menuName": "Kart Yenileme",
    "screenName": "DCMS018_DEBIT_RENEW_CARD",
    "screenCode": "DCMS018"
  },
  {
    "menuName": "Hazır Debit Kart Toplu Basım",
    "screenName": "DCMS028_PREPARED_CARD_PRINT",
    "screenCode": "DCMS028"
  },
  {
    "menuName": "Kurye Datası Oluşturma Ekranı",
    "screenName": "DCMS024_DEBIT_CARD_COURIER_DATA",
    "screenCode": "DCMS024"
  },
  {
    "menuName": "Kart Yenileme Parametreleri",
    "screenName": "DCMS019_DEBIT_RENEW_CARD_PARAMETER",
    "screenCode": "DCMS019"
  },
  {
    "menuName": "Debit Kart Ürün Tanımlama",
    "screenName": "DCMS002_DBT_CARD_PRODUCT_DEFINITION",
    "screenCode": "DCMS002"
  },
  {
    "menuName": "İl Bazlı Kurye Tanımı",
    "screenName": "DCMS025_COURIER_PARAMETERS",
    "screenCode": "DCMS025"
  },
  {
    "menuName": "Kart Range Ürün İlişkilendirme",
    "screenName": "DCMS031_PRODUCT_CARD_RANGE",
    "screenCode": "DCMS031"
  },
  {
    "menuName": "Kart Bayi Düzenleme",
    "screenName": "DCMS032_DEALER_PARAMETER",
    "screenCode": "DCMS032"
  },
  {
    "menuName": "Debit Kart Organizasyon Çalışma Parametreleri",
    "screenName": "https://nova-cps-debitcardsms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/debitCardSMS/DCMS001",
    "screenCode": "DCMS001"
  },
  {
    "menuName": "Kart Gruplama Kriterleri Tanımı",
    "screenName": "DCMS027_ISSUE_GROUP",
    "screenCode": "DCMS027"
  },
  {
    "menuName": "Para Çekme Limit Yönetim Ekranı - Segment",
    "screenName": "DCMS059_DBT_CARD_CASH_LIMIT_FOR_SEGMENTS",
    "screenCode": "DCMS059"
  },
  {
    "menuName": "Debit Kart Bin Tanımlama",
    "screenName": "DCMS005_DBT_CARD_BIN_DEFINITION",
    "screenCode": "DCMS005"
  },
  {
    "menuName": "Debit Kart Statü Geçiş Parametreleri",
    "screenName": "DCMS004_DBTCARD_TRANSITION_PARAM_DEFINITION",
    "screenCode": "DCMS004"
  },
  {
    "menuName": "Debit Kart Statü Tanımlama",
    "screenName": "https://nova-cps-debitcardsms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/debitCardSMS/DCMS003",
    "screenCode": "DCMS003"
  },
  {
    "menuName": "Log Gözlem",
    "screenName": "AMSD009_CARD_LOG_INFO",
    "screenCode": "AMSD009",
    "screenDescription": "LOG GÖZLEM"
  },
  {
    "menuName": "Provizyon Log Görüntüleme",
    "screenName": "AMSD007_AUTHORIZATION_LOGS_INQUIRY",
    "screenCode": "AMSD007",
    "screenDescription": "PROVİZYON LOG GÖRÜNTÜLEME"
  },
  {
    "menuName": "Genel Müdürlük Şube Takip Ekranı",
    "screenName": "DCMS030_STOCK_GENERAL",
    "screenCode": "DCMS030",
    "screenDescription": "GENEL MÜDÜRLÜK STOK TAKİP EKRANI"
  },
  {
    "menuName": "Şube Stok Takip Ekranı",
    "screenName": "DCMS029_STOCK_BRANCH",
    "screenCode": "DCMS029"
  },
  {
    "menuName": "Kart Hareket Bilgileri",
    "screenName": "DCMS008_DEBIT_CARD_TRXN_INFO",
    "screenCode": "DCMS008"
  },
  {
    "menuName": "BKM 3D Online Bildirim",
    "screenName": "AMSD006_BKM_3D_ONLINE",
    "screenCode": "AMSD006",
    "screenDescription": "BKM YAPILAN BILDIRIMLERIN ONLINE HALI"
  },
  {
    "menuName": "Müşteri No Değişikliği",
    "screenName": "DCMS010_DEBIT_CARD_CHANGE_CUSTOMER",
    "screenCode": "DCMS010"
  },
  {
    "menuName": "Blok Kod Değişiklik",
    "screenName": "DCMS011_DEBIT_CARD_STATUS_INFO_CHANGE",
    "screenCode": "DCMS011"
  },
  {
    "menuName": "Kart Hesap Bağlama/Silme",
    "screenName": "DCMS013_DEBIT_CARD_ACCOUNT_BINDING",
    "screenCode": "DCMS013"
  },
  {
    "menuName": "Toplu Block Kod Değişiklik",
    "screenName": "https://nova-cps-debitcardsms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/debitCardSMS/DCMS012",
    "screenCode": "DCMS012"
  },
  {
    "menuName": "Hasat Kart Limit Güncelleme",
    "screenName": "DCMS026_DEBIT_CARD_LIMIT_UPDATE_HASAT",
    "screenCode": "DCMS026"
  },
  {
    "menuName": "Tek Kullanımlık Şifre Talebi",
    "screenName": "https://nova-cps-debitcardsms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/debitCardSMS/DCMS041",
    "screenCode": "DCMS041"
  },
  {
    "menuName": "Kart Bilgileri Gözlem(Debit)",
    "screenName": "DCMS006_DBT_CARD_INFO",
    "screenCode": "DCMS006"
  },
  {
    "menuName": "Memo Gözlem",
    "screenName": "https://nova-cps-debitcardsms-ui-set-alfa.nprd.ocp.sekerbank.com.tr/cardPaymentSystems/debitCardSMS/DCMS020",
    "screenCode": "DCMS020"
  },
  {
    "menuName": "Yükle Kullan Dosya ile Alacak/Borç Oluşturma",
    "screenName": "DCMS053_FILE_PAYMENT_UPLOAD",
    "screenCode": "DCMS053",
    "screenDescription": "YÜKLE KULLAN KART DOSYADAN YÜKLEME"
  },
  {
    "menuName": "Toplu Başvuru",
    "screenName": "DCMS057_BRANCH_CREATE_CARD_WITH_FILE",
    "screenCode": "DCMS057"
  },
  {
    "menuName": "Banka Kartı Aktivasyon",
    "screenName": "DCMS044_PREPAID_CARD_ACTIVATION",
    "screenCode": "DCMS044"
  },
  {
    "menuName": "ADK Kanalından Gelen Başvurular",
    "screenName": "DCMS048_PREPAID_APPLICATION_ADK",
    "screenCode": "DCMS048"
  },
  {
    "menuName": "Harçlık Kart Şube Başvuru",
    "screenName": "DCMS055_POCKET_MONEY_CARD_APPLICATION",
    "screenCode": "DCMS055"
  },
  {
    "menuName": "Yükle Kullan Para Transfer",
    "screenName": "DCMS045_BRANCH_MONEY_TRANSFER",
    "screenCode": "DCMS045",
    "screenDescription": "KARTTAN KARTA PARA TRANSFER"
  },
  {
    "menuName": "Kapalı Yükle Kullan Para Transferi",
    "screenName": "DCMS063_CLOSED_PREPAID_CARD_MONEY_TRANSFER",
    "screenCode": "DCMS063"
  },
  {
    "menuName": "Yükle Kullan Para Çekme",
    "screenName": "DCMS043_BRANCH_CASH_MANUAL",
    "screenCode": "DCMS043",
    "screenDescription": "ÖN ÖDEMELİ KART ŞUBE PARA ÇEKME EKRANI"
  },
  {
    "menuName": "Yükle Kullan Kart Ücreti İadesi",
    "screenName": "DCMS054_DEDUCTION_CANCEL",
    "screenCode": "DCMS054",
    "screenDescription": "KART ÜCRETİ İADESİ"
  },
  {
    "menuName": "Yükle Kullan İşlem İptal",
    "screenName": "DCMS046_BRANCH_TRANSACTION_CANCEL",
    "screenCode": "DCMS046",
    "screenDescription": "ŞUBE İŞLEM İPTAL EKRANI"
  },
  {
    "menuName": "Yükle Kullan Para Yükleme",
    "screenName": "DCMS042_BRANCH_OPERATION",
    "screenCode": "DCMS042",
    "screenDescription": "ÖN ÖDEMELİ KART ŞUBE PARA YÜKLEME EKRANI"
  },
  {
    "menuName": "Toplu Kart Para Yükleme",
    "screenName": "DCMS047_BRANCH_PAYMENT_UPLOAD",
    "screenCode": "DCMS047",
    "screenDescription": "ÖN ÖDEMELİ TOPLU KART YÜKLEME EKRANI"
  },
  {
    "menuName": "Toplu Borç Kaydı Oluşturma",
    "screenName": "DCMS049_BRANCH_CREATE_BATCH_DEPT",
    "screenCode": "DCMS049",
    "screenDescription": "ŞUBE TOPLU BORÇ KAYDI YARATMA EKRANI"
  },
  {
    "menuName": "Harçlık Kart Yükleme Talimatı",
    "screenName": "DCMS056_POCKET_MONEY_CARD_ORDER",
    "screenCode": "DCMS056"
  },
  {
    "menuName": "Karbon Saydamlık Şube Bilgi Giriş Ekranı",
    "screenName": "CDP003_BRANCH_INPUT",
    "screenCode": "CDP003"
  },
  {
    "menuName": "Karbon Saydamlık Lokasyon Yönetim",
    "screenName": "CDP007_LOCATION_MANAGEMENT",
    "screenCode": "CDP007",
    "screenDescription": "LOKASYON VE YETKİLİ YÖNETİM EKRANI"
  },
  {
    "menuName": "Gayrimenkul Satın Alma ve İnşaat Bilgi Ekranı",
    "screenName": "CDP002_GM_INPUT",
    "screenCode": "CDP002"
  },
  {
    "menuName": "Lojistik Bilgi Giriş Ekranı",
    "screenName": "CDP001_LOJISTIK_INPUT",
    "screenCode": "CDP001"
  },
  {
    "menuName": "Fatura Görüntüleme",
    "screenName": "CDP006_BILL_MONITORING",
    "screenCode": "CDP006"
  },
  {
    "menuName": "Fatura Yükleme Ekranı",
    "screenName": "CDP005_ADDING_BILL_TO_DYS",
    "screenCode": "CDP005",
    "screenDescription": "DYS FATURA EKLEME EKRANI"
  },
  {
    "menuName": "Karbon Saydamlık Bilgi Giriş Ekranı",
    "screenName": "CDP004_MIN_MAX_PARAMETERS",
    "screenCode": "CDP004"
  },
  {
    "menuName": "Şifre Değiştirme",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM018",
    "screenCode": "ADM018",
    "screenDescription": "KİŞİSEL ŞİFRE DEĞİŞTİRME EKRANI."
  },
  {
    "menuName": "Muhtemel Onay Listesi",
    "screenName": "EPR013_PROCESSES_WAITING_FOR_PROBABLE_APPROVING",
    "screenCode": "EPR013",
    "screenDescription": "MUHTEMEL ONAYA DÜŞECEKLER EKRANI"
  },
  {
    "menuName": "Yetki Delegasyon",
    "screenName": "https://nova-infra-administration-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/administration/ADM012",
    "screenCode": "ADM012",
    "screenDescription": "YETKİ DELEGASYON TANIMLAMA EKRANI."
  },
  {
    "menuName": "Onayımda Bekleyen İşlemler",
    "screenName": "EPR012_PROCESSES_WAITING_FOR_APPROVING",
    "screenCode": "EPR012",
    "screenDescription": "ONAYDA BEKLEYEN İŞLEMLER EKRANI"
  },
  {
    "menuName": "Kendi İşlemlerim Gözlem",
    "screenName": "EPR011_PROCESSES_STARTED_BY_ME",
    "screenCode": "EPR011",
    "screenDescription": "İŞLEM GÖZLEM EKRANI"
  },
  {
    "menuName": "Bildirimlerim",
    "screenName": "AUR001_UTIL_NOTIFICATION_INSTANCE_QUERY",
    "menuKey": "anahtar",
    "screenCode": "AUR001"
  },
  {
    "menuName": "Mesajlarım",
    "screenName": "https://nova-infra-utility-ui-set-alfa.nprd.ocp.sekerbank.com.tr/infrastructure/utility/UTL015",
    "screenCode": "UTL015",
    "screenDescription": "GELEN MESAJLARIN OKUNDUĞU EKRAN"
  },
  {
    "menuName": "Delegasyonla Yapılan İşlemler Raporu",
    "screenName": "EPR021_PROCESS_USER_REPORT",
    "screenCode": "EPR021",
    "screenDescription": "İŞLEMLERİN KİM TARAFINDAN KİMİN ADINA YAPILDIĞININ RAPORLANDIĞI EKRANDIR."
  },
  {
    "menuName": "Organizasyon Bazında İşlem Gözlem",
    "screenName": "EPR024_PROCESS_MONITOR",
    "screenCode": "EPR024",
    "screenDescription": "BİR BİRİMİN HERHANGİ BİR SERVİSİNE YA DA TÜM SERVİSLERİNE ONAYA GELEREK TAMAMLANMIŞ YA DA HALİHAZIRDA ONAYA GELMİŞ İŞLEMLERİNİN LİSTELENDİĞİ EKRAN"
  },
  {
    "menuName": "Birim Kadrosu Gözlem",
    "screenName": "ADM035_ADMIN_USR_ORGANIZATION_STAFF",
    "screenCode": "ADM035",
    "screenDescription": "KULLANICILARIN DAHİL OLDUKLARI BİRİMİN KADROSUNDAKİ KULLANICI BİLGİLERİNİ GÖRÜNTÜLEYEN EKRANDIR."
  },
  {
    "menuName": "Dekont İzleme",
    "screenName": "EPR015_UTILITY_STATEMENTS_LIST",
    "screenCode": "EPR015",
    "screenDescription": "DEKONT GÖZLEM EKRANI"
  },
  {
    "menuName": "Ürün-Ürün İşlem Log",
    "screenName": "PRD013_PROD_PRODUCT_PROCESS_LOG",
    "screenCode": "PRD013",
    "screenDescription": "ÜRÜN-ÜRÜN İŞLEM LOG'U GÖSTEREN EKRANDIR."
  },
  {
    "menuName": "Mizan Sorgulama",
    "screenName": "MUH015_ACCOUNTING_TRIAL_BALANCE_REPORT",
    "screenCode": "MUH015",
    "screenDescription": "MİZAN SORGULAMA"
  },
  {
    "menuName": "Muhasebe Hesap Detay Listesi",
    "screenName": "MUH025_ACCOUNTING_ACCOUNT_DETAIL_REPORT",
    "screenCode": "MUH025",
    "screenDescription": "MUHASEBE HESAP DETAY LİSTESİ"
  },
  {
    "menuName": "Muhasebe Banka Raporları",
    "screenName": "MUH028_ACCOUNTING_BANK_REPORTS",
    "screenCode": "MUH028"
  },
  {
    "menuName": "Kontrol Raporları",
    "screenName": "MUH018_ACCOUNTING_CONTROL_REPORT",
    "screenCode": "MUH018",
    "screenDescription": "KONTROL RAPORLARI"
  },
  {
    "menuName": "Transfer Fişi Sorgulama",
    "screenName": "MUH039_ACCOUNTING_BULK_VOUCHER_REPORT",
    "screenCode": "MUH039",
    "screenDescription": "TOPLU FİŞ RAPORU"
  },
  {
    "menuName": "Detaylı Fiş Sorgulama",
    "screenName": "MUH038_ACCOUNTING_VOUCHER_DETAIL_REPORT",
    "screenCode": "MUH038",
    "screenDescription": "DETAYLI FİŞ RAPORU"
  },
  {
    "menuName": "Muavin Sorgulama",
    "screenName": "MUH016_ACCOUNTING_SUBSIDIARY_REPORT",
    "screenCode": "MUH016",
    "screenDescription": "MUAVİN SORGULAMA"
  },
  {
    "menuName": "Fiş Sorgulama",
    "screenName": "MUH017_ACCOUNTING_VOUCHER_REPORT",
    "screenCode": "MUH017",
    "screenDescription": "FİŞ SORGULAMA"
  },
  {
    "menuName": "Fiş Sorgulama/Yazdırma",
    "screenName": "MUH042_ACCOUNTING_NEW_VOUCHER_DETAIL_REPORT",
    "screenCode": "MUH042",
    "screenDescription": "YENİ FİŞ DEKONTU"
  },
  {
    "menuName": "Meta Hesap Tanımlama",
    "screenName": "MUH004_ACCOUNTING_META_ACC_DEF",
    "screenCode": "MUH004",
    "screenDescription": "MUHASEBE META HESAP TANIMI"
  },
  {
    "menuName": "Fiş Şablonu Tanımlama",
    "screenName": "MUH005_ACCOUNTING_VOUCHER_PARAM_DEF",
    "screenCode": "MUH005",
    "screenDescription": "MUHASEBE FİŞ ŞABLONU TANIMI"
  },
  {
    "menuName": "Adet Nazım İşlemleri",
    "screenName": "MUH041_ACCOUNTING_ITEM_MEMORANDUM",
    "screenCode": "MUH041",
    "screenDescription": "ADET NAZIM İŞLEMLERİ"
  },
  {
    "menuName": "Banka Muhasebe Fiş Raporu",
    "screenName": "INVESTCORE041_INVCMN_ACCOUNTING_VOUCHER_REPORT",
    "screenCode": "INVCORE041",
    "screenDescription": "BANKA MUHASEBE FİŞ RAPORU"
  },
  {
    "menuName": "Muhasebe Mutabakat Raporu",
    "screenName": "ACCOUNTING006_COMPLIANCE_REPORT",
    "screenCode": "ACCOUNT006",
    "screenDescription": "MUHASEBE MUTABAKAT RAPORU"
  },
  {
    "menuName": "Meta Hesap Düzenleme",
    "screenName": "ACCOUNTING_META_ACC_DEF",
    "screenCode": "ACCOUNT001",
    "screenDescription": "META HESAP DÜZENLEME"
  },
  {
    "menuName": "Fiş Düzenleme",
    "screenName": "ACCOUNTING_VOUCHER_PARAM_DEF",
    "screenCode": "ACCOUNT002",
    "screenDescription": "FİŞ DÜZENLEME"
  },
  {
    "menuName": "Kurum Tahsilat Aktarım",
    "screenName": "PYM001_BEDAS_MUHASEBE",
    "screenCode": "PYM001",
    "screenDescription": "ÖDEME SİSTEMLERİ ALTINDA BEDAŞ İÇİN KULLANILIYOR."
  },
  {
    "menuName": "Serbest Fiş Kes",
    "screenName": "MUH006_ACCOUNTING_MANUAL_VOUCHER",
    "screenCode": "MUH006",
    "screenDescription": "MUHASEBE SERBEST FİŞ"
  },
  {
    "menuName": "Muh.Hesabı Devir",
    "screenName": "MUH003_ACCOUNTING_LEAF_CHANGE_MANUAL_TRANSFER",
    "screenCode": "MUH003",
    "screenDescription": "MANUEL VİRMAN"
  },
  {
    "menuName": "THP Düzenleme",
    "screenName": "MUH001_ACCOUNTING_GL_DEF",
    "screenCode": "MUH001",
    "screenDescription": "THP TANIM EKRANI"
  },
  {
    "menuName": "Transfer Fişi",
    "screenName": "MUH030_ACCOUNTING_IMPORT_BULK_VOUCHER",
    "screenCode": "MUH030"
  },
  {
    "menuName": "Geçici Hesap Giriş - Borç",
    "screenName": "MUH021_ACCOUNTING_TRANSITORY_ACCOUNT_OPERATION_DEBIT",
    "screenCode": "MUH021",
    "screenDescription": "GEÇİCİ HESAP GİRİŞ - BORÇ"
  },
  {
    "menuName": "Geçici Hesap Giriş - Alacak",
    "screenName": "MUH022_ACCOUNTING_TRANSITORY_ACCOUNT_OPERATION_CREDIT",
    "screenCode": "MUH022",
    "screenDescription": "GEÇİCİ HESAP GİRİŞ - ALACAK"
  },
  {
    "menuName": "Geçici Hesap İşlem Kapama",
    "screenName": "MUH023_ACCOUNTING_TRANSITORY_ACCOUNT_MANAGEMENT",
    "screenCode": "MUH023",
    "screenDescription": "GEÇİCİ HESAPLAR YÖNETİMİ - İŞLEM YÖNETİMİ"
  },
  {
    "menuName": "Geçici Hesap Raporlama",
    "screenName": "MUH024_ACCOUNTING_TRANSITORY_ACCOUNT_REPORT",
    "screenCode": "MUH024",
    "screenDescription": "GEÇİCİ HESAPLAR YÖNETİMİ - RAPORLAMA"
  },
  {
    "menuName": "Müşteri Devir Talebi Sorgulama",
    "screenName": "MUH010_ACCOUNTING_CUSTOMER_TRANSFER_LIST",
    "screenCode": "MUH010",
    "screenDescription": "MÜŞTERİ DEVİR SORGULAMA"
  },
  {
    "menuName": "Müşteri Devir Talebi",
    "screenName": "MUH009_ACCOUNTING_CUSTOMER_TRANFER",
    "screenCode": "MUH009",
    "screenDescription": "MÜŞTERİ DEVRETME"
  },
  {
    "menuName": "Şube Devir Talebi Sorgulama",
    "screenName": "MUH011_ACCOUNTING_BRANCH_TRANSFER_LIST",
    "screenCode": "MUH011",
    "screenDescription": "ŞUBE DEVİR SORGULAMA"
  },
  {
    "menuName": "Firme Ekstre Görüntüleme",
    "screenName": "TK039_FIRM_VIEW_EXTRE_HTML_FORMAT",
    "screenCode": "TK039"
  },
  {
    "menuName": "Müşteri Ekstre Html Görüntüleme",
    "screenName": "TK036_VIEW_STATEMENT_HTML",
    "screenCode": "TK036"
  },
  {
    "menuName": "Para Yatırma",
    "screenName": "TK019_INVESTMENT",
    "screenCode": "TK019",
    "screenDescription": "ŞUBEDEN PARA YATIRMA EKRANI"
  },
  {
    "menuName": "Ödeme İşlemleri Gözlem",
    "screenName": "TK046_VIEW_MASAK",
    "screenCode": "TK046"
  },
  {
    "menuName": "Gecikme Gözlem",
    "screenName": "TK043_TOA_CUSTOMER_RISK",
    "screenCode": "TK043"
  },
  {
    "menuName": "Provizyon ve Hareket Gözlem",
    "screenName": "TK015_VIEW_PROVISIONS_AND_ACTIONS",
    "screenCode": "TK015",
    "screenDescription": "PROVİZYON VE HAREKET BİLGİLERİ EKRANI"
  },
  {
    "menuName": "Hareket Gözlem",
    "screenName": "TK023_CUSTOMER_TRANSACTIONS",
    "screenCode": "TK023",
    "screenDescription": "MÜŞTERİ HAREKETLERİNİ LİSTELEME EKRANI"
  },
  {
    "menuName": "Müşteri Bilgileri Yönetimi",
    "screenName": "TK027_CUSTOMER_INFO_MANAGEMENT",
    "screenCode": "TK027",
    "screenDescription": "TİCARİKART MÜŞTERİ YÖNETİM EKRANI"
  },
  {
    "menuName": "Parametre Tanımlama",
    "screenName": "TK011_PARAMETERS",
    "screenCode": "TK011",
    "screenDescription": "PARAMETRE EKRANI"
  },
  {
    "menuName": "Borç Gözlem",
    "screenName": "TK034_VIEW_DEPT",
    "screenCode": "TK034",
    "screenDescription": "BORÇ GÖZLEM"
  },
  {
    "menuName": "Log Gözlem",
    "screenName": "TK017_LOG_DETAILS",
    "screenCode": "TK017",
    "screenDescription": "LOG BİLGİLERİ EKRANI"
  },
  {
    "menuName": "Kayıp Çalıntı Bildirimi",
    "screenName": "TK025_LOST_STOLEN_CARD_DECLERATION",
    "screenCode": "TK025",
    "screenDescription": "KAYIT/ÇALINTI BİLDİRİMLERİ"
  },
  {
    "menuName": "Limit Yönetimi",
    "screenName": "TK012_LIMIT_MANAGEMENT",
    "screenCode": "TK012",
    "screenDescription": "LİMİT YÖNETİM EKRANI"
  },
  {
    "menuName": "Blok Kod Tanımlama",
    "screenName": "TK032_BLOCK_CODE",
    "screenCode": "TK032"
  },
  {
    "menuName": "Blok Kod Geçiş Ekranı",
    "screenName": "TK033_BLOCK_CODE_TRANSITION",
    "screenCode": "TK033"
  },
  {
    "menuName": "Firma Tanımlama",
    "screenName": "TK020_SUPPLIER_ENTRY",
    "screenCode": "TK020"
  },
  {
    "menuName": "Başvuru Sorgulama",
    "screenName": "TK003_APPLICATION_INQUIRY",
    "screenCode": "TK003"
  },
  {
    "menuName": "Kart Basım Raporu",
    "screenName": "TK009_CARD_GROUP_LIST",
    "screenCode": "TK009"
  },
  {
    "menuName": "BKM Üye İşyeri Ciro Sorgulama",
    "screenName": "https://nova-fgw-kkbgw-ui-set-alfa.nprd.ocp.sekerbank.com.tr/foreignTrade/KKBGW/KKB033",
    "screenCode": "KKB033",
    "screenDescription": "BKM CİRO BİLGİLERİ SORGULAMA EKRANI"
  },
  {
    "menuName": "KKB Çapraz Çek Sorgulama",
    "screenName": "KKB032_CROSS_CHEQUE_QUERY",
    "screenCode": "KKB032",
    "screenDescription": "ÇAPRAZ ÇEK SORGULAMA EKRANI"
  },
  {
    "menuName": "KKB Ticaret Sicil Sorgulama",
    "screenName": "KKB024_TSP_ONLINE_SEARCH",
    "screenCode": "KKB024",
    "screenDescription": "KKB TİCARİ SİCİL SORGULAMA"
  },
  {
    "menuName": "KKB Telco Münferit Sorgulama",
    "screenName": "KKB034_KKB_TELCO_QUERY",
    "screenCode": "KKB034",
    "screenDescription": "TELCO MÜNFERİT SORGULAMA"
  },
  {
    "menuName": "Referans Veri Eşleştirme",
    "screenName": "CCSUTL052_CKKB_REFERENCE_DATA_MATCH",
    "screenCode": "CCSUTL052"
  },
  {
    "menuName": "KKB Senet Raporu Sorgulama ve Gözlem",
    "screenName": "KKB036_BILL_REPORT_REQUEST",
    "screenCode": "KKB036",
    "screenDescription": "KKB SENET RAPORU SORGU VE GÖZLEM EKRANI"
  },
  {
    "menuName": "KKB Çek Raporu",
    "screenName": "KKB023_CHEQUE_QUERY_REPORT",
    "screenCode": "KKB023"
  },
  {
    "menuName": "Ticari Krediler Yapılandırma",
    "screenName": "ARL355_ARL_RSK_RBD_CORP_RISK_MAIN_SCREEN",
    "screenCode": "ARL355",
    "screenDescription": "TİCARİ KREDİLER YAPILANDIRMA EKRANI"
  },
  {
    "menuName": "Bireysel Krediler Yapılandırma",
    "screenName": "ARL350_RSK_RBD_INDV_REBUILD_MAIN_SCREEN",
    "screenCode": "ARL350",
    "screenDescription": "BİREYSEL KREDİLER YAPILANDIRMA EKRANI"
  },
  {
    "menuName": "Toa Kredilerine Reeskont Hesaplama",
    "screenName": "ARL126_CREDIT_LOANS_REDISCOUNT_CALCULATE",
    "screenCode": "ARL126",
    "screenDescription": "TOA YA AKTARILAN KREDILER ICIN REESKONT HESAPLAMASI"
  },
  {
    "menuName": "Yeniden Yapılandırma Parametre Tanımlama",
    "screenName": "CRD303_UTILITY_PRODUCT_CONVERSION_PARAMETERS",
    "menuKey": "4",
    "screenCode": "CRD303",
    "screenDescription": "ÜRÜN DÖNÜŞÜM PARAMETRELERİ"
  },
  {
    "menuName": "İtfa Grubu Tanımlama",
    "screenName": "ARL122_COMMON_AMORTIZATION_GROUP_DEF",
    "screenCode": "ARL122",
    "screenDescription": "İTFA GRUBU TANIMLAMA"
  },
  {
    "menuName": "Müşteri Parametre Düzenleme",
    "screenName": "ARL071_COMMON_CUSTOMER_EXCLUSION_DEFINITION",
    "screenCode": "ARL071",
    "screenDescription": "MÜŞTERİ İSTİSNA DÜZENLEME"
  },
  {
    "menuName": "ŞBM Risk Yönetim Raporu Parametre Düzenleme",
    "screenName": "SKS0011_SUBE_MUDURLERI_PARAMETRE",
    "screenCode": "SKS0011"
  },
  {
    "menuName": "Kontrol Süreç Eşleştir",
    "screenName": "ARL077_COMMON_CONTROL_UNIT_ASSOCIATION_DEFINITION",
    "screenCode": "ARL077",
    "screenDescription": "KONTROL SÜREÇ EŞLEŞTİR"
  },
  {
    "menuName": "Farklılık Süreç Eşleştir",
    "screenName": "ARL075_COMMON_EXCEPTION_UNIT_ASSOCIATION_DEFINITION",
    "screenCode": "ARL075",
    "screenDescription": "FARKLILIK SÜREÇ EŞLEŞTİR"
  },
  {
    "menuName": "Kredi Durdurma Sebebi Olumsuzluk Tanımlama",
    "screenName": "ARL115_COMMON_CREDIT_STOP_REASON_DEFINITION",
    "screenCode": "ARL115"
  },
  {
    "menuName": "Temerrüt Faiz Oranı Tanımlama",
    "screenName": "ARL072_COMMON_DEFAULT_INTEREST_DEFINITION",
    "screenCode": "ARL072",
    "screenDescription": "TEMERRÜT FAİZ ORANI TANIMLA"
  },
  {
    "menuName": "Farklılık Grubu Tanımla",
    "screenName": "ARL073_COMMON_EXCEPTION_GROUP_DEFINITION",
    "screenCode": "ARL073",
    "screenDescription": "FARKLILIK GRUBU TANIMLAMA"
  },
  
]

