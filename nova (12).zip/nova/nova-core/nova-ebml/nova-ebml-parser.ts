/* eslint-disable */

import { XMLParser } from 'fast-xml-parser';
import type {
    NovaEbml,
    NovaEbmlInterface,
    NovaEbmlStructure,
    NovaEbmlBean,
    NovaEbmlEvent,
    NovaEbmlRemoteCall,
    NovaEbmlManipulation,
    NovaEbmlRuleset,
    NovaEbmlProperty,
    NovaEbmlData,
    NovaEbmlColumn,
} from './types';

/**
 * Parses raw EBML XML content into a structured TypeScript object.
 * @param xmlContent The raw XML string from an .ebml file.
 * @returns The parsed NovaEbmlConfig object.
 */
export function parseEbml(xmlContent: string): NovaEbml {
    const parser = new XMLParser({
        ignoreAttributes: false,
        attributeNamePrefix: '@_',
        textNodeName: '#text',
        processEntities: true,
        htmlEntities: true,
        attributeValueProcessor: (name, val) => {
            return  val;
        },
        tagValueProcessor: (name, val) => {
            return val;
        },
        isArray: (name) => {
            return ['bean','p', 'lC', 'd', 'data', 'ref', 'input', 'output', 'rC','rule','message','combination','var', 'column'].indexOf(name) !== -1;}
    });

    const raw = parser.parse(xmlContent);
    const root = raw.ebml;

    if (!root) {
        throw new Error('Invalid EBML file: Missing <ebml> root.');
    }

    return {
        language: root['@_language'],
        pid: root['@_pid'],
        size: root['@_size'],
        techVersion: root['@_techVersion'],
        type: root['@_type'],
        v: root['@_v'],
        interface: parseInterface(root.interface),
        data: root.data ? parseDataSection(root.data[0]) : undefined,
        ruleset: root.ruleset ? parseRuleset(root.ruleset) : undefined
    };
}

function parseInterface(rawInterface: any): NovaEbmlInterface {
    return {
        structure: parseStructure(rawInterface.structure),
        events: rawInterface.events && rawInterface.events.lC ? rawInterface.events.lC.map(parseEvent) : [],
    };
}

function parseStructure(rawStructure: any): NovaEbmlStructure {
    if (!rawStructure || !rawStructure.bean || rawStructure.bean.length === 0) {
        throw new Error('Invalid structure: Missing root bean.');
    }
    return {
        rootBean: parseBean(rawStructure.bean[0]),
    };
}

function parseBean(rawBean: any): NovaEbmlBean {
    const bean: NovaEbmlBean = {
        id: rawBean['@_id'],
        class: rawBean['@_class'],
        text: rawBean['@_text'] || rawBean['#text'],
        children: [],
    };

    // Parse Style properties
    if (rawBean.style && rawBean.style.p) {
        bean.style = { properties: [] };
        rawBean.style.p.forEach((p: any) => {
            if (p) bean.style?.properties.push(parseProperty(p));
        });
    }

    // Parse nested beans (children)
    if (rawBean.bean) {
        bean.children = rawBean.bean.map((child: any) => parseBean(child));
    }

    return bean;
}

function parseProperty(p: any): NovaEbmlProperty {
    const prop: NovaEbmlProperty = {
        name: p['@_n'] || p['@_name'] || '',
        text:  p['#text'] ==undefined ? '' :p['#text'],
        id: p['@_id'] || null,
        m: p['@_m'],
        rule: p['@_rule'],
        var: p['@_var'],
        n: p['@_n'],
        comp: p['@_comp'],
        columns: p['@_columns'],
    };

    if (p.columns && p.columns.column) {
        prop.columns =  p.columns.column.map((c: any) => parseColumn(c)) ;
    }

    return prop;
}

function parseColumn(c: any): NovaEbmlColumn {
    const col: NovaEbmlColumn = {
        id: c["@_id"],
        title: c["@_title"],
        type: c["@_type"],
        width: c["@_width"],
        editable: c["@_editable"] === "true",
        visible: c["@_visible"] !== "false", // Default true usually
        order: parseInt(c["@_order"] || "0"),
    };

    if (c.style && c.style.p) {
        col.style = { properties: [] };
        // Assuming style.p is array (parser config handles 'p')
        const props = Array.isArray(c.style.p) ? c.style.p : [c.style.p];
        col.style.properties = props.map((p: any) => parseProperty(p));
    }

    return col;
}

function parseEvent(rawLc: any): NovaEbmlEvent {
    const eventType = rawLc['@_type'];

    // For type='event', this is just a reference to an action - no action steps
    // Example: <lC id="btnUpdate" n="actionPerformed" type="event"><ref>actUpdateRow</ref></lC>
    if (eventType === 'event') {
        // Get refId from <ref> element or @_ref attribute
        let refId = rawLc['@_ref'];
        if (rawLc.ref) {
            const ref = Array.isArray(rawLc.ref) ? rawLc.ref[0] : rawLc.ref;
            refId = typeof ref === 'string' ? ref : ref['#text'] || ref;
        }

        return {
            id: rawLc['@_id'],
            name: rawLc['@_n'],
            type: 'event',
            refId: refId,
            actions: [], // Event bindings don't have actions - they reference an action by refId
        };
    }

    // For type='action' or undefined (default to 'action' for lC elements with action steps)
    // This handles standalone action definitions like: <lC id="actUpdateRow" n="actUpdateRow" type="action">
    const event: NovaEbmlEvent = {
        id: rawLc['@_id'] ?? rawLc['@_ref'],
        name: rawLc['@_n'] ?? rawLc['@_ref'],
        type: eventType || 'action', // Default to 'action' if type is not specified
        refId: rawLc['@_ref'],
        actions: [],
    };

    // <ref> - Only for non-event types, these become ReferenceCall actions
    if (rawLc.ref) {
        const refs = Array.isArray(rawLc.ref) ? rawLc.ref : [rawLc.ref];
        refs.forEach((r: any) => {
            const refId = typeof r === 'string' ? r : r['#text'] || r;
            event.actions.push({
                type: 'ReferenceCall',
                reference: refId
            });
        });
    }

    // <rC> (Remote Calls)
    if (rawLc.rC) {
        const rcs = Array.isArray(rawLc.rC) ? rawLc.rC : [rawLc.rC];
        rcs.forEach((rc: any) => {
            event.actions.push({
                type: 'RemoteCall',
                call: parseRemoteCall(rc),
            });
        });
    }

    // <p> (Manipulations -> BeanAction)
    if (rawLc.p) {
        const ps = Array.isArray(rawLc.p) ? rawLc.p : [rawLc.p];
        ps.forEach((p: any) => {
            const manip = parseManipulation(p);
            event.actions.push({
                type: 'BeanAction',
                action: {
                    targetId: manip.targetId,
                    method: manip.method || '',
                    value: manip.value,
                    property: manip.property,
                    sourceVar: manip.sourceVar,
                    description: undefined
                }
            });
        });
    }

    // <page> (Page Calls)
    if (rawLc.page) {
        const pages = Array.isArray(rawLc.page) ? rawLc.page : [rawLc.page];
        pages.forEach((page: any) => {
            event.actions.push({
                type: 'PageCall',
                call: {
                    pageName: page.value || page['#text'],
                    method: page['@_popup'] === '1' ? 'showPopup' : 'open',
                    params: page.p ? (Array.isArray(page.p) ? page.p : [page.p]) : [],
                    description: undefined
                }
            });
        });
    }

    // <var> (Variable Setting - direct var elements in actions)
    if (rawLc.var) {
        const vars = Array.isArray(rawLc.var) ? rawLc.var : [rawLc.var];
        vars.forEach((v: any) => {
            event.actions.push({
                type: 'VariableSetting',
                setting: {
                    variableId: v['@_id'] || '',
                    value: v['#text'],
                    rule: v['@_rule'],
                    sourceComp: v['@_comp'] ? {
                        componentId: v['@_comp'],
                        method: v['@_m'] || ''
                    } : undefined,
                    description: undefined
                }
            });
        });
    }

    return event;
}

function parseRemoteCall(rawRc: any): NovaEbmlRemoteCall {
    const rc: NovaEbmlRemoteCall = {
        serviceName: rawRc['@_s'],
        status: rawRc['@_status'],
    };

    // Inputs - flatten p and var into single array with type field
    if (rawRc.inputs) {
        rc.inputs = [];
        if (rawRc.inputs.p) {
            const pItems = rawRc.inputs.p.map((p: any) => ({
                ...parseProperty(p),
                type: 'p' as const
            }));
            rc.inputs.push(...pItems);
        }
        if (rawRc.inputs.var) {
            const varItems = rawRc.inputs.var.map((v: any) => ({
                ...parseProperty(v),
                type: 'var' as const
            }));
            rc.inputs.push(...varItems);
        }
    }

    // Outputs - flatten p and var into single array with type field
    if (rawRc.outputs) {
        rc.outputs = [];
        if (rawRc.outputs.p) {
            const pItems = rawRc.outputs.p.map((p: any) => ({
                ...parseProperty(p),
                type: 'p' as const
            }));
            rc.outputs.push(...pItems);
        }
        if (rawRc.outputs.var) {
            const varItems = rawRc.outputs.var.map((v: any) => ({
                ...parseProperty(v),
                type: 'var' as const
            }));
            rc.outputs.push(...varItems);
        }
    }

    return rc;
}

function parseManipulation(rawP: any): NovaEbmlManipulation {
    const manip: NovaEbmlManipulation = {
        targetId: rawP['@_id'],
        method: rawP['@_m'],
        property: rawP['@_n'],
    };

    if (rawP['#text']) {
        manip.value = rawP['#text'];
    }
    // <var>
    if (rawP.var) {
        const v = Array.isArray(rawP.var) ? rawP.var[0] : rawP.var;
        if (v) {
            manip.sourceVar = v['@_id'] || v['#text'];
        }
    }

    return manip;
}

function parseDataSection(rawData: any): NovaEbmlData {
    // rawData is an array of data sections because "data" is in isArray list
    const section: NovaEbmlData = { variables: [], definitions: [] };
    const dataItems = Array.isArray(rawData) ? rawData : [rawData];
    let vars: any[] = [];
    let defs: any[] = [];

    dataItems.forEach((item: any) => {
        if (item.var) {
            vars = vars.concat(item.var);
        }
        if (item.d) {
            // 'd' elements represent definitions for components (e.g. ComboBox selections)
            defs = defs.concat(item.d);
        }
    });
    
    section.variables = vars.map((v: any) => ({
        id: v["@_id"],
        n: v["@_n"],
        comp: v["@_comp"],
        text: v["#text"],
        rule: v["@_rule"]
    }));

    section.definitions = defs.map((d: any) => {
        const definition: any = {
            id: d["@_id"],
            options: [],
            columnDefinitions: []
        };

        // Check if this has direct data elements (simple definition)
        if (d.data && d.data.length > 0) {
            definition.options = d.data.map((opt: any) => ({
                value: opt["@_n"],
                text: opt["#text"]
            }));
        }

        // Check if this has nested d elements (table column definitions)
        if (d.d && d.d.length > 0) {
            definition.columnDefinitions = d.d.map((nestedD: any) => ({
                columnId: nestedD["@_id"],
                options: (nestedD.data || []).map((opt: any) => ({
                    value: opt["@_n"],
                    text: opt["#text"]
                }))
            }));
        }

        return definition;
    });
    return section;
}

function parseRuleset(rawRuleset: any): NovaEbmlRuleset {
    const ruleset: NovaEbmlRuleset = {
        rules: [],
        messages: [],
        combinations: [],
    };

    if (rawRuleset.rule) {
        ruleset.rules = rawRuleset.rule.map((r: any) => ({
            id: r['@_id'],
            op: r['@_op'],
            source: r['@_source'],
            target: r['@_target'],
            targetType: r['@_targetType'],
        }));
    }

    if (rawRuleset.message) {
        ruleset.messages = rawRuleset.message.map((m: any) => ({
            id: m['@_id'],
            var: m['@_var'],
            messageType: m['@_messageType'],
            title: m['@_title'],
            type: m['@_type'],
            text: m['#text'] || m['@_text'] || '',
        }));
    }

    if (rawRuleset.combination) {
        ruleset.combinations = rawRuleset.combination.map((c: any) => ({
            id: c['@_id'],
            expression: c['#text'] || c['@_expression'],
        }));
    }

    return ruleset;
}
