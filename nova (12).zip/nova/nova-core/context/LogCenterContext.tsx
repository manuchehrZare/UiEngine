/* eslint-disable */
/**
 * Log Center Context
 * Centralized logging system for Nova UI
 * Captures all logs from execution system for debugging
 */

import React, { createContext, useContext, useState, useCallback, useRef, useMemo } from 'react';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
    id: string;
    timestamp: Date;
    level: LogLevel;
    category: string;
    message: string;
    data?: any;
}

interface LogCenterContextType {
    logs: LogEntry[];
    clearLogs: () => void;
    filterByCategory: (category: string | null) => LogEntry[];
    filterByLevel: (level: LogLevel | null) => LogEntry[];
}

// Separate context for the log function to avoid re-renders
interface LogFunctionContextType {
    log: (level: LogLevel, category: string, message: string, data?: any) => void;
}

const LogCenterContext = createContext<LogCenterContextType | undefined>(undefined);
const LogFunctionContext = createContext<LogFunctionContextType | undefined>(undefined);

export const useLogCenter = () => {
    const context = useContext(LogCenterContext);
    if (!context) {
        throw new Error('useLogCenter must be used within LogCenterProvider');
    }
    return context;
};

export const useLogFunction = () => {
    const context = useContext(LogFunctionContext);
    if (!context) {
        throw new Error('useLogFunction must be used within LogCenterProvider');
    }
    return context;
};

interface LogCenterProviderProps {
    children: React.ReactNode;
    maxLogs?: number;
}

export const LogCenterProvider: React.FC<LogCenterProviderProps> = ({
    children,
    maxLogs = 1000
}) => {
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const logIdCounter = useRef(0);

    // Use useRef to create a stable log function that never changes reference
    const logRef = useRef<((level: LogLevel, category: string, message: string, data?: any) => void) | null>(null);

    logRef.current = (level: LogLevel, category: string, message: string, data?: any) => {
        const entry: LogEntry = {
            id: `log-${logIdCounter.current++}`,
            timestamp: new Date(),
            level,
            category,
            message,
            data
        };

        setLogs(prev => {
            const newLogs = [...prev, entry];
            // Keep only the last maxLogs entries
            if (newLogs.length > maxLogs) {
                return newLogs.slice(-maxLogs);
            }
            return newLogs;
        });

        // Also log to console for development
        const consoleMsg = `[${category}] ${message}`;
        switch (level) {
            case 'debug':
                console.debug(consoleMsg, data);
                break;
            case 'info':
                console.log(consoleMsg, data);
                break;
            case 'warn':
                console.warn(consoleMsg, data);
                break;
            case 'error':
                console.error(consoleMsg, data);
                break;
        }
    };

    // Create a stable wrapper function that calls the ref
    const log = useCallback((level: LogLevel, category: string, message: string, data?: any) => {
        logRef.current?.(level, category, message, data);
    }, []);

    const clearLogs = useCallback(() => {
        setLogs([]);
        logIdCounter.current = 0;
    }, []);

    const filterByCategory = useCallback((category: string | null) => {
        if (!category) return logs;
        return logs.filter(log => log.category === category);
    }, [logs]);

    const filterByLevel = useCallback((level: LogLevel | null) => {
        if (!level) return logs;
        return logs.filter(log => log.level === level);
    }, [logs]);

    const logsValue: LogCenterContextType = {
        logs,
        clearLogs,
        filterByCategory,
        filterByLevel
    };

    const logFunctionValue: LogFunctionContextType = useMemo(() => ({
        log
    }), [log]);

    return (
        <LogFunctionContext.Provider value={logFunctionValue}>
            <LogCenterContext.Provider value={logsValue}>
                {children}
            </LogCenterContext.Provider>
        </LogFunctionContext.Provider>
    );
};

// Convenience logging functions
export const useLogger = (category: string) => {
    const { log } = useLogFunction(); // Use the separate log function context

    // Use useMemo to create a stable logger object
    return useMemo(() => ({
        debug: (message: string, data?: any) => log('debug', category, message, data),
        info: (message: string, data?: any) => log('info', category, message, data),
        warn: (message: string, data?: any) => log('warn', category, message, data),
        error: (message: string, data?: any) => log('error', category, message, data),
    }), [log, category]);
};
