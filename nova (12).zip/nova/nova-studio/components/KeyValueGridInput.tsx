/* eslint-disable */
/**
 * KeyValueGridInput Component
 * A grid editor for entering key-value pairs for Select component options
 */

import React, { useState, useEffect } from 'react';
import {
    Box,
    TextField,
    IconButton,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon } from '@mui/icons-material';

interface KeyValuePair {
    key: string;
    value: string;
}

interface KeyValueGridInputProps {
    label?: string;
    value: KeyValuePair[];
    onChange: (value: KeyValuePair[]) => void;
    keyLabel?: string;
    valueLabel?: string;
}

export const KeyValueGridInput: React.FC<KeyValueGridInputProps> = ({
    label,
    value = [],
    onChange,
    keyLabel = 'Key',
    valueLabel = 'Value',
}) => {
    const [rows, setRows] = useState<KeyValuePair[]>([]);
    const [initialized, setInitialized] = useState(false);

    // Initialize rows from value only once
    useEffect(() => {
        if (!initialized) {
            if (Array.isArray(value) && value.length > 0) {
                setRows(value);
            } else {
                // Start with one empty row
                setRows([{ key: '', value: '' }]);
            }
            setInitialized(true);
        }
    }, [value, initialized]);

    const handleAddRow = () => {
        const newRows = [...rows, { key: '', value: '' }];
        setRows(newRows);
        // Don't call onChange here - wait for user to fill the row
    };

    const handleDeleteRow = (index: number) => {
        const newRows = rows.filter((_, i) => i !== index);
        // Keep at least one empty row
        const finalRows = newRows.length === 0 ? [{ key: '', value: '' }] : newRows;
        setRows(finalRows);
        // Filter out empty rows before saving
        const nonEmptyRows = finalRows.filter(row => row.key || row.value);
        onChange(nonEmptyRows);
    };

    const handleChangeRow = (index: number, field: 'key' | 'value', newValue: string) => {
        const newRows = [...rows];
        newRows[index] = { ...newRows[index], [field]: newValue };
        setRows(newRows);
        // Filter out empty rows before saving
        const nonEmptyRows = newRows.filter(row => row.key || row.value);
        onChange(nonEmptyRows);
    };

    return (
        <Box sx={{ width: '100%' }}>
            {label && (
                <Typography variant="body2" sx={{ mb: 1, fontWeight: 500 }}>
                    {label}
                </Typography>
            )}
            <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 300 }}>
                <Table size="small" stickyHeader>
                    <TableHead>
                        <TableRow>
                            <TableCell sx={{ fontWeight: 600, width: '40%' }}>{keyLabel}</TableCell>
                            <TableCell sx={{ fontWeight: 600, width: '50%' }}>{valueLabel}</TableCell>
                            <TableCell sx={{ width: '10%', textAlign: 'center' }}>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row, index) => (
                            <TableRow key={index} hover>
                                <TableCell sx={{ p: 1 }}>
                                    <TextField
                                        fullWidth
                                        size="small"
                                        value={row.key}
                                        onChange={(e) => handleChangeRow(index, 'key', e.target.value)}
                                        placeholder="Enter key"
                                        variant="standard"
                                        inputProps={{
                                            style: { fontSize: 13 }
                                        }}
                                    />
                                </TableCell>
                                <TableCell sx={{ p: 1 }}>
                                    <TextField
                                        fullWidth
                                        size="small"
                                        value={row.value}
                                        onChange={(e) => handleChangeRow(index, 'value', e.target.value)}
                                        placeholder="Enter value"
                                        variant="standard"
                                        inputProps={{
                                            style: { fontSize: 13 }
                                        }}
                                    />
                                </TableCell>
                                <TableCell sx={{ p: 1, textAlign: 'center' }}>
                                    <IconButton
                                        size="small"
                                        onClick={() => handleDeleteRow(index)}
                                        disabled={rows.length === 1}
                                        color="error"
                                    >
                                        <DeleteIcon fontSize="small" />
                                    </IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <Button
                startIcon={<AddIcon />}
                onClick={handleAddRow}
                size="small"
                sx={{ mt: 1 }}
                variant="outlined"
                fullWidth
            >
                Add Row
            </Button>
        </Box>
    );
};
