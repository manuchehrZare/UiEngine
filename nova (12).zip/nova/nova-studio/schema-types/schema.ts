/* eslint-disable */
// Re-export from nova-core for backward compatibility
export type {
    PropertySchema,
    ComponentSchema,
    EventSchema
} from '../../nova-core/types/property-schema.types';

export {
    BASE_PROPERTIES,
    createSchema
} from '../../nova-core/types/property-schema.types';
